## 1.字体

去jetbrain官网下载字体：https://www.jetbrains.com/lp/mono/

解压后：

![image-20250904175056725](C:\Users\lw0135478\AppData\Roaming\Typora\typora-user-images\image-20250904175056725.png)

移动到

![image-20250904175115775](C:\Users\lw0135478\AppData\Roaming\Typora\typora-user-images\image-20250904175115775.png)

vscode设置里搜font：

![image-20250904175314946](C:\Users\lw0135478\AppData\Roaming\Typora\typora-user-images\image-20250904175314946.png)

## 2.连字

搜ligatures，在settings.json中编辑：

![image-20250904175347297](C:\Users\lw0135478\AppData\Roaming\Typora\typora-user-images\image-20250904175347297.png)

```json
{
    "remote.SSH.remotePlatform": {
        "pre-41": "linux"
    },
    "clangd.detectExtensionConflicts": false,
    "clangd.arguments": [
        "--compile-commands-dir=${workspaceFolder}/build/${buildType}",
        "--query-driver=/usr/bin/g++*"
    ],
    "workbench.editor.enablePreview": false,
    "editor.wordWrap": "on",
    "editor.fontFamily": "Jetbrains Mono",
    "editor.fontLigatures": true,
    "editor.semanticHighlighting.enabled": true
}
```

保存并重启

## 3.重载运算符换颜色

搜semantic highlighting：

![image-20250904175700585](C:\Users\lw0135478\AppData\Roaming\Typora\typora-user-images\image-20250904175700585.png)

![image-20250904175924007](C:\Users\lw0135478\AppData\Roaming\Typora\typora-user-images\image-20250904175924007.png)

加上：

```json
"C_Cpp.errorSquiggles": "disabled",
    "editor.semanticTokenColorCustomizations": {
    "[Default Dark Modern]": {
        "rules": {
        "operator.overloaded": "#ffffff",  // 为重载运算符设置橙色
        "operator": "#fffb00"              // 普通运算符保持白色
        }
    }
```

