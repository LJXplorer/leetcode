## ad_dict


### 一、模块整体认知
- **目标**: 提供广告相关多种“字典”数据（adinfo、appinfo、adunit、统计、分词等）的统一加载、热更新与查询能力。
- **核心组件**:
  - `AdDict::AdDictTemplate<KeyT, ValueT>`: 通用模板，负责从文本行解析为 protobuf 或结构体，存入 `unordered_map<KeyT, shared_ptr<ValueT>>`。
  - `AdDict::AdDictCollectorInstance`: 全局单例，实际持有并管理所有注册的字典实例（底层基类来自 `hidict`）。
  - `AdDict::AdDictCollector`: 业务侧“句柄/视图”，维护“业务名 -> 实际词典路径”的映射，并提供便捷查询函数。
  - `hidict` 框架: 提供 `Dict` 抽象基类、注册管理、版本切换、后台加载、计数器等基础设施。

常见字典类型（均继承自 `AdDictTemplate` 或自定义）:
- `AdinfoDict`、`AppinfoDict`、`AdunitDict`、`AdStatDict`、`AdQueryStatsInfoDict`、`AdQueryCrossAppInfoDict`、`PackageName2AppIdInfoDict`、`JieBaDict`、`PlaintextKvDict`、`GameStatsDict`。


### 二、关键类与函数详解

#### 1. AdDictTemplate<KeyType, ValueType>
文件: `phx-fe/ad_dict/ad_dict_template.h`
- **继承**: `hidict::Dict<std::unordered_map<KeyType, std::shared_ptr<ValueType>>>`
- **类型别名**:
  - `ContainerType = std::unordered_map<KeyType, std::shared_ptr<ValueType>>`
  - `KeyT = KeyType`，`ValueT = ValueType`
- **init(dict_name, path)**: 保存名称与路径。
- **get_value_reflection / get_value_descriptor**: 返回 protobuf 的反射/描述符指针（用于通用统计或调试）。
- **fill_dict_data(src, data)**: 将一行拆分出的 `vector<string>` 解析：
  - 期望至少2列: `src[0]=key`，`src[1]=base64编码的ValueType序列化结果`；
  - 解码、`ParseFromString` 成功后写入 `unordered_map`；
  - 使用 `ConvertKey<KeyType>(src[0])` 支持 `int64_t` 与 `string` 两种主键；
  - 成功/失败会更新 `load_succ_num` 与 `parse_failed_num` 计数。
- **gen_data_info()**: 构造双缓冲 `m_dict[0]` 与 `m_dict[1]`，支持热切换。
- **reset(idx)**: 清理并重建某个缓冲区。

辅助: `key_convert.h`
- `ConvertKey<int64_t>(s) -> stol(s)`；`ConvertKey<string>(s) -> s`。

#### 2. 具体字典类型与别名
- `adinfo_dict.h`
  - `using adinfo_dict_type = AdDictTemplate<int64_t, phx::AdInfoDict>::ContainerType;`
  - `class AdinfoDict : public AdDictTemplate<int64_t, phx::AdInfoDict> {};`
  - `DICT_REGISTER(AdinfoDict);` 完成在 `hidict` 框架内的类型注册。
- `appinfo_dict.h`、`adunit_dict.h`、`adstat_dict.h`、`adquerystatsinfo_dict.h`、`adquerycrossapp_dict.h`、`gamestatsdict.h` 类似，区别在于 Key/Value 的类型。
- `packagename2appid_dict.*`
  - 重载 `fill_dict_data`，不走 base64+proto，而是 `key=package_name`，`value=app_id` 两列文本直接落表。
- `plaintext_kv_dict.*`
  - `Key=string`，`Value=tensorflow::Feature`；
  - 第2列为 `value_type`（string/int64），第3列为逗号分隔的值列表，解析后填充 `Feature`。
- `jieba_dict.*`
  - 继承 `hidict::Dict<cppjieba::MixSegment>`；
  - `init` 校验路径与 `jieba.dict.utf8`、`hmm_model.utf8`、`user.dict.utf8` 三文件；
  - `gen_data_info` 实例化两个 `MixSegment`；`fill_dict_data` 恒为 true（无行级数据，基于文件集合加载）。

#### 3. AdDictCollectorInstance（单例）
文件: `ad_dict_manager.h/.cpp`
- **get_dict(dict_name)**: 返回 `hidict::DictInfo*`（包含版本、状态、数据指针等）。
- **get_data<T>(dict_name)**: 直接拿到底层 `T` 类型的数据容器指针（如 `adinfo_dict_type*`）。
- **init(name, vector<DictConfig>, off)**: 委托给底层 `hidict` 初始化，注册并启动加载线程（off=true 为离线模式也会实际加载）。

#### 4. AdDictCollector（业务侧句柄）
- **_dict_name2path_map: unordered_map<string, string>**
  - 将“业务名 dict_name”映射为“底层实际路径 path”。对每个 `AdDictCollector` 实例，这个映射是一致的。
- **init(name, cfgs, off=true)**
  - 保存映射；若 `off==true` 则把每条 `DictConfig` 的 `m_name` 改写成 `m_path`，并调用全局单例实际加载（在线场景 off=false 不在此处加载，由预测服务统一加载）。
- 便捷查询接口（内部统一做空指针/未注册检查并打点计数）:
  - `get_appinfo(dict_name, id)` 返回 `const phx::AppInfoDict*`
  - `get_adinfo(dict_name, id)` 返回 `const phx::AdInfoDict*`
  - `get_adunitinfo(dict_name, id)` 返回 `const phx::AdunitInfoDict*`
  - `get_adstatinfo(dict_name, key)` 返回 `const phx::ItemStatsDict*`（Key 为 string）
  - `get_adquerystats_info(dict_name, query)` 返回 `const phx::AdQueryStatsInfo*`
  - `get_adquerycrossapp_info(dict_name, query)` 返回 `const phx::AdQueryCrossAppDict*`
  - `get_packagename2appid_info(dict_name, pkg)` 返回 `const phx::PackageName2AppIdDict*`
  - `get_segment_info(dict_name)` 返回 `const cppjieba::MixSegment*`
  - `seg_cut(dict_name, src, words)` 使用 MixSegment 分词
- 通用模板接口：
  - `template <typename AdDictType> const AdDictType::ValueT* get_value(dict_name, key)`
    - 自动推导底层容器类型 `AdDictType::ContainerType` 并查找，返回 `shared_ptr<ValueT>` 的裸指针。

#### 5. 计数器与监控
文件: `dict_counters_provider.cpp`（C++17 及以上）/ `offline_dict_counters_provider.h`（降级）
- 全局 `hidict::g_counters` 提供 `inc(path, Metric, x)` 接口；
- 在各查询函数中针对如下场景打点：
  - `TOTAL` 每次查询；`MAP_OR_KEY_EMPTY` 入参为空；
  - `MAP_NOT_FOUND` 业务名未映射到路径或底层 map 缺失；
  - `KEY_NOT_FOUND` 查不到 key；`KEY_FOUND` 命中。
- 在线计数器实现会调用 `AdDictCollectorInstance` 获取词典版本进行上报。


### 三、端到端工作流程（离线与在线）

#### 1) 词典注册
- 每个字典类在头文件末尾 `DICT_REGISTER(ClassName);` 完成类型注册，使 `hidict` 能按 `m_clazz` 反射构造。

#### 2) 初始化配置（DictConfig）
`hidict::DictConfig` 字段：
- `m_name`: 业务侧可见的字典名（AdDictCollector 场景）或内部使用名；
- `m_path`: 词典目录（底层实际唯一标识，在线监控也按 path 维度聚合）；
- `m_clazz`: 注册的类名（如 `AdinfoDict`）。

#### 3) 离线流程（off=true）
- 构造 `std::vector<DictConfig>`（业务名一般是简短别名，如 `"adinfo"`）。
- `AdDictCollector::init(name, cfgs, /*off=*/true)`：
  - 记录 `dict_name -> path`；
  - 组装新 `DictConfig`，把 `m_name` 重写为 `m_path`（确保全局唯一）；
  - 调用 `AdDictCollectorInstance::init(...)` 实际加载所有字典：
    - `init -> load -> gen_data_info -> 后台监控 SUCCESS 文件/版本目录 -> 双缓冲切换`。

#### 4) 在线流程（off=false）
- 由服务进程统一调用 `AdDictCollectorInstance::init(handle, cfgs, /*off=*/false)` 完成全局加载；
- 业务线程内仅创建 `AdDictCollector` 并调用 `init(collect_name, cfgs, false)` 建立“业务名 -> path”映射，不触发重复加载；
- 可通过 `get_first_load_done()` 等待首轮加载完成。

#### 5) 数据文件格式
- Proto 型字典：每行 `key \t base64(proto.SerializeToString())`；
- `PackageName2AppId`：每行 `package_name \t app_id`；
- `PlaintextKvDict`：每行 `key \t value_type(string|int64) \t v1,v2,...`；
- `JieBaDict`：目录下存在 `jieba.dict.utf8`、`hmm_model.utf8`、`user.dict.utf8` 三文件。

#### 6) 查询路径
以 `get_adinfo("adinfo", creative_id)` 为例：
- `AdDictCollector::_dict_name2path_map["adinfo"] -> "/data/.../adinfo"`
- `AdDictCollectorInstance::get_data<adinfo_dict_type>(path)` 拿到 `unordered_map<int64_t, shared_ptr<AdInfoDict>>*`
- `unordered_map::find(id)` 命中后返回 `shared_ptr->get()` 的裸指针。

#### 7) 热更新与版本
- 底层 `hidict::Dict` 采用双缓冲 `m_dict[0/1]`；新版本加载到备用缓冲，校验完成后原子切换；
- 目录结构通常包含日期/批次（如 `.../20250821/0000`）与 `SUCCESS` 标记；
- 计数器上报会带上 `get_latest_version()`。


### 四、常见易错点与排查
- **dict_name 为空或未注册**: `MAP_OR_KEY_EMPTY` 或 `MAP_NOT_FOUND`，注意先 `init` 并确认映射键一致。
- **数据行列数不够**: `DICT_DATA_SIZE_LESS2`；确保行内字段与类型匹配（尤其 `PlaintextKvDict` 需要3列）。
- **base64/Parse 失败**: `DICT_PARSE_FAILED`；检查是否二进制串/协议版本一致。
- **重复 key**: `PlaintextKvDict` 显式拒绝重复键；其它字典会覆盖旧值。
- **Jieba 目录/文件缺失**: `init` 会直接返回负码，注意三文件齐全且路径为目录。
- **在线/离线混用**: 在线模式请确保全局已加载，再在业务线程 `init(..., false)` 建立映射。


### 五、最小可用示例（离线）
```cpp
std::vector<hidict::DictConfig> cfgs;
{
  hidict::DictConfig c{};
  c.m_name = "adinfo";                         // 业务名
  c.m_path = "/data/.../adinfo";               // 实际目录
  c.m_clazz = "AdinfoDict";                    // 注册类名
  cfgs.emplace_back(c);
}
AdDict::AdDictCollector collector;
collector.init("my_job", cfgs, /*off=*/true);
// 等待加载完成后
if (auto info = collector.get_adinfo("adinfo", 123456789); info) {
  // 使用 info->... 字段
}
```


### 六、API 速查表
- **初始化**: `bool AdDictCollector::init(name, cfgs, off=true)`
- **通用取容器**: `template<class T> const T* get_data(dict_name)`
- **通用取值**: `template<class AdDictType> const AdDictType::ValueT* get_value(dict_name, key)`
- **便捷查询**: `get_adinfo / get_appinfo / get_adunitinfo / get_adstatinfo / get_adquerystats_info / get_adquerycrossapp_info / get_packagename2appid_info`
- **分词**: `get_segment_info` 与 `seg_cut`


### 七、与 hidict 的关系
- `hidict` 管理注册、生命周期、后台加载与热切换，`AdDict` 专注于各业务字典的解析与二次封装；
- `DICT_REGISTER` 使 `m_clazz` -> 具体类的反射构造成为可能；
- 计数器 `g_counters` 在 C++17 下具备真实上报能力（含版本）。


### 八、建议的开发调试步骤
- 先用小样本生成器（见 `ad_test.cpp` 中的写文件逻辑）产出测试数据，确认单个字典能成功加载；
- 打通 `AdDictCollector::init` + 若干 `get_*` 查询，观察命中与计数；
- 再接入线上统一加载（off=false），只做映射绑定；
- 最后接入监控，验证 `TOTAL/KEY_FOUND/KEY_NOT_FOUND` 指标是否合理。