## 粗排（prerank）

本文分两部分：
- 关键类/函数/变量的用途说明（按模块：在线 Online、离线 Offline、截断 Truncation、特征缓存 Embedding Cache）
- 从离线到在线的一条龙完整流程串讲（并标注关键类与函数）

为便于定位，文内均标注代码所在文件路径。

### 一、关键组件与 API 说明

#### 1) 在线服务（Online）

- `core/core_services/prerank/online/prerank_user_embedding_service.h`
  - 类：`Core::PrerankUserEmbeddingService`（继承 `ServiceBaseInfo`）
    - 作用：在在线请求中，负责召回后对“用户侧 embedding”进行特征抽取与模型推理，请求外部模型服务生成用户向量；将结果写入 `CoreContext` 的 `PrerankContext`。
    - 主要成员：
      - `ExperimentModelType model_type_`：区分 CTR 用户向量或 CVR 用户向量。
    - 主要方法：
      - `initialize(ConfigXmlPtr)`、`initialize(GraphContextPtr)`：节点初始化。
      - `do_service(GraphContextPtr)`：节点执行入口，内部通常会调用 `extractor()`、`inference()` 等。
      - `skip(GraphContextPtr)`：是否跳过该节点。
      - `extractor(CoreContextPtr)`：构造 FE 请求（`build_user_embedding_fe_request`），抽取用户侧特征。
      - `inference(CoreContextPtr, ModelInfoPtr, ExtractorResponse*)`：调用预测服务（见 `PredictService`）拿到用户 embedding。
      - `get_fe_model_info(...)`、`get_emb_model_version(...)`：获取模型信息与版本。
      - `process_predict_response(CoreContextPtr, PredictResponse&)`：解析模型返回，将 `user_vec` 写入 `PrerankContext`。

- `core/core_services/prerank/online/prerank_user_callback.h`
  - 结构体：`Core::PrerankUserCallBack`（继承 `google::protobuf::Closure`）
    - 作用：异步模型调用的回调对象。解析 `PredictResponse` 的 `outputs`，把 `user_vec` 写入 `context->get_prerank_context()` 中：
      - `USER_EMBEDDING` -> `MutableUserEmbeddingVec()`
      - `CVR_USER_EMBEDDING` -> `MutableCvrUserEmbeddingVec()`
    - 同时上报耗时、错误码、模型时延等监控，并在结束时唤醒图中的后继节点：`node->run_output_nodes_if_ready(context)`。

- `core/core_services/prerank/online/online_item_embedding_service.h`
  - 类：`Core::OnlineItemEmbeddingService`（继承 `ServiceBaseInfo`）
    - 作用：在线时为每个候选广告从缓存中取出 item embedding（或构造需要的请求/上下文），并写入上下文，为后续打分使用。
    - 关键方法：`do_service(GraphContextPtr)`、`skip(GraphContextPtr)`、`initialize*`。

- `core/core_services/prerank/online/online_embedding_inner_products_service.h`
  - 类：`Core::OnlineEmbeddingInnerProductsService`（继承 `ServiceBaseInfo`）
    - 作用：将用户向量与每个广告的 item 向量做内积，得到粗排分数（CTR、CVR 皆可）。
    - 关键方法：
      - `do_service(GraphContextPtr)`：主流程（取用户向量与 item 向量，做内积，填充分数）。
      - `set_prerank_ctr_score(...)`、`set_prerank_cvr_score(...)`：分别设置 CTR、CVR 的预估分数，支持默认值聚合统计（计数与和）。
      - `skip(GraphContextPtr)`：是否跳过。

#### 2) 截断模块（Truncation）

- `core/core_services/prerank/truncation/prerank_truncation_service.h`
  - 类：`Core::TruncationService`（继承 `ServiceBaseInfo`）
    - 作用：执行粗排后的“截断/保障/兜底”等策略组合，产出用于进入精排的候选集合；支持是否返回丢弃广告、打点抽样等。
    - 关键成员：
      - `_split_size`：批大小（可用于并行/分片处理）。
      - `_return_discarded_ads`：是否返回被丢弃的广告集合。
      - `_is_truncation`：是否启用截断。
      - 策略相关抽样参数等。
    - 关键方法：
      - `do_service(GraphContextPtr)`：主流程。
      - `item_model_list(CoreContextPtr, const PredictorItemInfo&, PredictorItemData&)`：填充每个 item 的模型列表或必要属性（可被子类覆盖）。
      - 内部解析 JSON 配置到策略上下文：`parse_json_params`、`parse_nested_json_params`。
      - `convert_proto(CoreContextPtr)`：把处理结果写回上下文/响应。

- `core/core_services/prerank/truncation/alloc_item_service.h`
  - 类：`Core::AllocItemService`（继承 `TruncationService`）
    - 作用：在粗排阶段为 item 分配/声明所需的模型列表等属性，覆盖 `item_model_list(...)`。

- `core/core_services/prerank/truncation/include/TruncationLogic.h`
  - 类：`Core::prerank::TruncationLogic`
    - 作用：真正的策略编排与执行单元。构造时注入：候选广告、策略配置 `Config`、上下文 `CoreContextPtr`。
    - 内部持有多种策略模板：`ClassifyTemplate`、`MergeTemplate`、`TruncationTemplate`、`GuaranteeTemplate`、`FallbackTemplate`，对应策略由 `StrategyFactory` 生成。
    - 关键方法：
      - `execute(CoreContextPtr&, std::unordered_map<std::string, std::shared_ptr<std::vector<AdsPairPtr>>>& result)`：执行分类、排序、合并、截断、保障与兜底，产出各类目的候选列表与丢弃列表。
      - `convert_return_to_common_form(...)`：将内部 `AdGroup` 转成对外更通用的数据结构。
      - 一系列 `print_*` 方法用于调试输出。

- `core/core_services/prerank/truncation/include/strategy/TruncationStrategy.h`
  - 抽象类：`TruncationStrategy` 以及实现类：`TopMTruncation`、`TopMAndLimitAppIdTruncation`
    - 作用：承载截断策略，如保留前 M 个、同包名限制出现次数等。
    - 关键方法：`do_operation(AdGroup&)` 对广告组进行实际的截断。

- `core/core_services/prerank/truncation/include/strategy/StrategyFactory.h`
  - 类：`StrategyFactory`
    - 作用：根据配置名创建对应的分类/排序/截断/合并/保障/兜底策略实例，向 `TruncationLogic` 注入。

- `core/core_services/prerank/truncation/include/AdGroup.h`
  - 类：`AdGroup`
    - 作用：承载某一类目的广告集合，包含：
      - `_ads`：截断前广告集合
      - `_truncated_ads`：截断后保留集合
      - `_discarded_ads`：截断后丢弃集合
    - 同时持有一个类目排序策略 `_ss`。

#### 3) 特征缓存（Embedding Cache）

- `core/core_services/prerank/embedding_cache/feature_cache.h`
  - 命名空间：`Core::prerank`
  - 结构体：`FeatureStruct`
    - 作用：记录一个模型版本的元信息与“双缓冲”的创意 embedding 向量集合：
      - `version`、`model_url`、`timestamp`、`DBuffer<std::unordered_map<int64_t, std::vector<float>>> featureVectors`。
  - 类：`FeatureCache`
    - 作用：管理 item embedding 的版本化双缓冲缓存；支持批量插入、获取、版本切换等：
      - `batch_insert_feature(model_url, model_version, creative_ids, vec, batch_size, vec_size, is_version_update)`：批量写入 embedding。
      - `get_feature(model_url, model_version, ads_map, predict_type)`：将缓存中的 embedding 绑定回广告 `AdsPair`（通常写入每个广告的 embedding 指针或向量）。
      - `pre_allocate(model_url, model_version, is_read_obj)`：为即将写入的版本预分配 buffer。
      - `commit_buffer(model_url, model_version, is_version_update, is_first_rotate)`：完成写入后切换读写 buffer。
      - `clear_double_buffer(...)`：清理旧版本双缓冲。
      - `find(model_url)` / `append(...)`：管理内部 `TBuffer<FeatureStruct>` 容器。

- `core/core_services/prerank/embedding_cache/feature_cache_writer.h`
  - 类：`FeatureCacheWriter` 与全局实例 `g_feature_cache_writer`
    - 作用：按批次将 embedding 写到落盘或持久化目录；内部一个线程 `write_loop()` 消费队列，`write_embedding()` 执行写入。
    - 批结构：`EmbeddingBatch { model_url, model_version, creative_ids, vector<ItemEmbeddingInfo> embedding_info, is_version_update }`。

#### 4) 离线处理（Offline）

- `biz/prerank/prerank_offline_server/prerank_offline_server.h/.cpp`
  - 类：`PrerankOffline::PrerankOfflineServer`（继承 `Core::CoreServer`）
    - 作用：离线周期任务的宿主进程。负责：
      - 初始化字典/模型信息、版本管理、DumpRedis、监控计数器等。
      - 周期性地触发“离线 item embedding 计算任务”，并在完成后把 embedding 载入 `FeatureCache`。
    - 关键方法：
      - `initialize(argc, argv)`：服务初始化。
      - `load_prerank()`：
        - 遍历模型（类型为 ITEM_EMBEDDING），读取当前/备份版本。
        - 首轮：对备份版本 `bak_version`（若存在）与当前版本 `cur_version` 预分配缓存并提交任务。
        - 进入循环等待离线任务完成，后注册周期性检查任务：
          - 版本更新时立即触发一次；
          - 间隔达到 `ServerConfig::_prerank_offline_embedding_scheduled` 分钟也会触发兜底跑一次。
      - `run_offline_item_embedding(model_name, dict_name, model_version, reason, is_version_update, is_first_rotate)`：
        - 构造 `CoreContext` 并标注离线跑 embedding 的上下文字段：`_offline_item_emb_model`、`_offline_item_emb_version`、`_is_version_update`、`_is_first_rotate` 等。
        - 运行离线 graph（由 `GraphManager` 管理，名见 `ServerConfig::_prerank_offline_embedding_graph_name`）。

- `core/core_services/prerank/offline/offline_embedding_start_service.h`
  - 类：`Core::EmbeddingStartService`
    - 作用：离线流程起点节点，从字典取待处理 item，分片 `_split_size`。

- `core/core_services/prerank/offline/offline_embedding_fe_service.h`
  - 类：`Core::OfflineEmbeddingFeService`
    - 作用：为 item 构造 FE 请求（`BuildOfflineFeRequest`），并多线程并行抽取（`s_offline_itemembedding_fe_executor`）。
    - `ExtractorArgs`：并行任务参数包。

- `core/core_services/prerank/offline/offline_item_embedding_service.h`
  - 类：`Core::OfflineItemEmbeddingService`
    - 作用：调用模型服务对 item 侧做 embedding 推理；解析 `TensorProto`，将结果按批组织并入缓存。
    - 关键方法：
      - `do_service(GraphContextPtr)` / `process(CoreContextPtr)`：主流程。
      - `process_prediction(...)`：发起预测请求并处理响应。
      - `process_embeddings(context, model_url, model_version, creative_ids, embedding_result, batch_size, single_vector_size)`：
        将一次模型返回的批量向量写入缓存（通常经 `FeatureCache::batch_insert_feature`）。

- 其他辅助：
  - `core/core_services/prerank/offline/offline_item_emb_dict_loader.h`：从存储（如 Goose）中拉取最新 embedding 并切换缓存（声明 `LoadLatestEmbeddingFromGoose`）。
  - `core/core_services/prerank/offline/offline_emb_done_service.h`：离线 embedding 流程结束标记节点。
  - `core/core_services/prerank/offline/offline_emb_common.h`：公共线程池与常量（如 `g_offline_emb_executor`）。


### 二、完整流程串讲（离线更新 -> 在线请求）

下面以“广告粗排”的实际链路来串起关键模块：

1) 离线 item embedding 周期更新（由 `PrerankOfflineServer` 驱动）
   - 启动：`main.cc` -> `PrerankOfflineServer::start()` -> `initialize()` -> `load_prerank()`。
   - 首次加载：对每个 `ITEM_EMBEDDING` 模型，读取当前/备份版本，`FeatureCache::pre_allocate(model_name, version, is_read_obj)` 预分配双缓冲；随后 `submit_model_task(...)` 投递模型计算任务。
   - 任务执行：`run_offline_item_embedding(...)` 取得对应的 Graph，创建 `CoreContext` 并设置：
     - `CoreContext::_offline_item_emb_model`、`_offline_item_emb_version`、`_is_version_update`、`_is_first_rotate`
     - `context->get_prerank_context()->item_dict_name_` 等
     - 运行离线 Graph。
   - 离线 Graph 典型节点序列：
     - `EmbeddingStartService::do_service/process`：从字典批量读取 item；
     - `OfflineEmbeddingFeService::do_service`：构建 FE 请求并多线程抽取；
     - `OfflineItemEmbeddingService::do_service/process/process_prediction/process_embeddings`：
       发起推理、解析 `TensorProto` 得到批量向量，调用 `FeatureCache::batch_insert_feature` 写入写缓冲；
     - 批量完成后由上层控制调用 `FeatureCache::commit_buffer(model, version, is_version_update, is_first_rotate)` 切换读写缓冲；必要时 `clear_double_buffer` 清理旧版本；
     - `OfflineItemEmbeddingDoneService::do_service`：结束标记，可能伴随监控/上报。
   - 结果：`FeatureCache` 中对应 `model_url`/`model_version` 的 item 向量准备就绪，供在线查询。

2) 在线请求进入粗排（由 Online Graph 驱动）
   - 召回后，进入用户 embedding 节点：
     - `PrerankUserEmbeddingService::do_service`：
       - `extractor()` 构造 FE 请求；
       - `inference()` 调用预测服务；
       - 异步回调 `PrerankUserCallBack::Run()`：从 `PredictResponse` 提取 `user_vec`，写入 `context->get_prerank_context()->MutableUserEmbeddingVec()` 或 `MutableCvrUserEmbeddingVec()`。
   - item embedding 准备：
     - `OnlineItemEmbeddingService::do_service`：
       - 按 `model_url`/`model_version` 从 `FeatureCache` 取出对应创意的 embedding；
       - 绑定到每个 `AdsPair`（如 `item_ads_pair`）的结构中，便于后续内积。
   - 计算粗排分数（内积）：
     - `OnlineEmbeddingInnerProductsService::do_service`：
       - 读取 `PrerankContext` 中的用户向量与 `AdsPair` 里的 item 向量；
       - 逐 item 计算内积；
       - 分别调用 `set_prerank_ctr_score` / `set_prerank_cvr_score` 填充 CTR、CVR 分数（支持默认值聚合统计）。
   - 截断与保障/兜底：
     - `TruncationService::do_service`：
       - 解析策略配置，构建 `TruncationLogic`：
         - `StrategyFactory::create_*_strategy(...)` 生成分类/排序/截断/合并/保障/兜底策略实例；
       - `TruncationLogic::execute(...)`：按类目将广告分组、排序、截断（如 `TopMTruncation`）、保障必出、兜底补齐；
       - `convert_return_to_common_form(...)`：将内部结果转为“进入精排”的候选与丢弃集合；
       - `convert_proto(CoreContextPtr)` 把结果落到响应或上下文供下游使用。

3) 最终产物
   - 进入精排的候选集合（按策略产出），附带粗排分数、必要标记。
   - 可选返回丢弃集合（用于分析/调试）。

### 三、关键数据在 Context 中的落点（便于调试）
- `CoreContext::get_prerank_context()` 下：
  - 用户向量：`UserEmbeddingVec()`、`CvrUserEmbeddingVec()`
  - item 侧映射（如 `ads_map`、`AdsPair` 内部的 embedding 指针/向量）
  - 截断结果：按类目的 `truncated_ads` 与 `discarded_ads`

### 四、你可能会用到的常见排查点
- 用户向量为空：检查 `PrerankUserCallBack::Run()` 是否命中 `output.name() == "user_vec"`，以及 `model_type` 配置是否正确。
- item 向量缺失：检查离线 `FeatureCache::commit_buffer` 是否完成；在线 `OnlineItemEmbeddingService` 是否按正确的 `model_url/model_version` 读取。
- 截断数量不对：检查 `TruncationStrategy` 策略名与参数（如 `TopM` 的 M 值、同包名限制等），以及是否启用了 `_is_truncation`。

——以上即是“粗排 prerank”的模块说明与端到端流程。