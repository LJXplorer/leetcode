### ad_dict 模块

## 模块要解决的问题
- 广告系统里会有大量“词典/字典”类数据（创意、广告单元、应用信息、统计画像、分词器等）。
- 这些数据一般离线产出，在线按需热更新，服务侧需要：
  - 高效读取（内存中的键值表）
  - 安全热更新（双缓冲，不阻塞查询）
  - 统一监控与指标
- `ad_dict` 基于通用框架 `hidict` 做了一层广告业务封装，提供“按字典名取数据”的统一入口与便捷 API。

## 关键概念总览
- **hidict::Dict<T>**: 通用词典基类，支持双缓冲、加载、版本、指标等；`T` 是具体承载的数据类型。
- **AdDictTemplate<Key, Value>**: 在 `hidict::Dict` 上封装的模板，固定把数据承载为 `unordered_map<Key, shared_ptr<Value>>`，并提供通用的“行解析→写入 map”的逻辑（默认 key 与 base64(pb) 两列）。
- **AdDictCollectorInstance**: 单例的“全局字典管理器”，真正持有各个字典实例与数据；
- **AdDictCollector**: 业务侧使用的“句柄/视图”，把“对外的 dict_name”映射到“内部真正加载的 path”，并提供若干快捷查询函数。
- **DICT_REGISTER(Clazz)**: 将字典类注册到全局工厂，便于按类名加载（由 `hidict` 提供）。
- **计数器 g_counters**: 记录查询总数、命中/未命中、map 未就绪、参数为空等，支持统一上报。

## 代码结构与主要类职责
- `ad_dict_manager.h/.cpp`
  - `AdDictCollectorInstance`: 继承自 `hidict::DictCollector` 的单例，真正“存、管、载”字典。
  - `AdDictCollector`: 面向业务。维持 `dict_name -> path` 的映射；提供通用 `get_data<T>` 和业务友好的 `get_appinfo/get_adinfo/...` 等查询方法；内部大量调用 `g_counters` 打点。
  - `init(name, cfg, off)`：
    - 把外部的 `cfg.m_name`（业务使用的逻辑名）映射到 `cfg.m_path`（真实加载名/路径）。
    - `off=true`（离线/本地）时，会把所有词典直接注册给全局实例去加载；`off=false`（在线）时，只做映射，不触发加载（通常由 Predictor 的全局流程统一初始化）。
- `ad_dict_template.h`
  - `AdDictTemplate<Key, Value>`：
    - 容器类型：`unordered_map<Key, shared_ptr<Value>>`（双缓冲在基类里）。
    - `fill_dict_data(src, data)`：默认支持“二列格式”：`src[0]=key`，`src[1]=base64(ProtoBuf)`，内部完成 base64→protobuf 解析并写入 map。
    - `gen_data_info()`：准备双缓冲两个空 map。
    - `reset(idx)`：清空并重建某个缓冲，便于热更新切换。
    - `get_value_reflection/descriptor()`：返回 protobuf 的反射/描述符（由 `Value` 类型提供）。
  - `key_convert.h`：`ConvertKey<T>(string)` 专门把文本行里的 key 转为目标类型（目前特化了 `int64_t` 和 `std::string`）。
- 具体业务字典（全部基于 `AdDictTemplate`，只定义键值类型）
  - `adinfo_dict.h`：`unordered_map<int64_t, phx::AdInfoDict>`
  - `appinfo_dict.h`：`unordered_map<int64_t, phx::AppInfoDict>`
  - `adunit_dict.h`：`unordered_map<int64_t, phx::AdunitInfoDict>`
  - `adstat_dict.h`：`unordered_map<string, phx::ItemStatsDict>`
  - `adquerystatsinfo_dict.h`：`unordered_map<string, phx::AdQueryStatsInfo>`
  - `adquerycrossapp_dict.h`：`unordered_map<string, phx::AdQueryCrossAppDict>`
  - `gamestatsdict.h`：`unordered_map<string, phx::GameStatsDict>`
- 特殊字典
  - `packagename2appid_dict.*`：重写了 `fill_dict_data`，支持“纯文本两列”格式：`package_name\tapp_id`。
  - `plaintext_kv_dict.*`：重写 `fill_dict_data` 支持“纯文本三列”：`key\t(string|int64)\tvalue1,value2,...`，并落成 `tensorflow::Feature`。
  - `jieba_dict.*`：不是 map，而是直接把 `cppjieba::MixSegment` 作为 `Dict` 的值；`init` 校验目录下三个文件是否存在；`gen_data_info` 构造两个 `MixSegment` 实例（双缓冲）。
- 计数器桥接：`dict_counters_provider.cpp`
  - 每次“抽干”指标会附带词典版本（从 `DictInfo` 拿 `get_latest_version()`），用于线上监控。

## 初始化与加载流程（离线 vs 在线）
1) 组装配置：`std::vector<hidict::DictConfig>`，每项包含：
   - `m_name`: 业务使用的逻辑名（例如 "adinfo"、"adstats"）。
   - `m_path`: 实际目录/路径或唯一名（hidict 按它来做分桶与加载）。
   - `m_clazz`: 注册的类名（如 "AdinfoDict"、"AdStatDict"、"JieBaDict"）。
2) `AdDictCollector::init(collectName, cfgs, off)`：
   - 建立 `dict_name -> path` 映射。
   - 如果 `off=true`（常见于本地/工具或“离线服务”），会把 `path/clazz` 交给 `AdDictCollectorInstance::init` 立即加载；
   - 如果 `off=false`（线上），这里只做映射，实际加载通常在更早的系统层完成；随后你只需用逻辑名去查。
3) 首次加载完成后，再查数据。`online_dict_test.cpp` 展示了典型流程（等待 `get_first_load_done()` 为 true 再开始业务）。

## 数据文件格式与目录约定
- 模板类默认格式（适用于大多数 protobuf 字典）
  - 文本行：`key\t<base64(protobuf)>`
  - 样例：`50029291201\tAAAA...`（第二列是把 protobuf 序列化后 base64 编码的字节串）
- `PlaintextKvDict`
  - 文本行：`key\t<string|int64>\tvalue1,value2,...`
  - 解析到 `tensorflow::Feature` 中的 `bytes_list` 或 `int64_list`。
- `PackageName2AppIdInfoDict`
  - 文本行：`package_name\tapp_id`（例如 `com.foo.app\t123456`）。
- `JieBaDict`
  - 不是“行文件”，而是一个目录，需包含：`jieba.dict.utf8`、`hmm_model.utf8`、`user.dict.utf8`。
- 成功标记
  - 测试代码里会在数据目录写 `SUCCESS` 文件，hidict 在一些实现里会以它为“这批数据已就绪”的约定（具体以 hidict 版本为准）。

## 查询 API 用法
- 通过 `AdDictCollector` 的快捷函数：
  - `get_appinfo(dict_name, appId)` / `get_adinfo(dict_name, creativeId)` / `get_adunitinfo(dict_name, adUnitId)`
  - `get_adstatinfo(dict_name, key)` / `get_adquerystats_info(dict_name, query)` / `get_adquerycrossapp_info(dict_name, query)`
  - `get_packagename2appid_info(dict_name, package)`
  - `get_segment_info(dict_name)` / `seg_cut(dict_name, text, words)`（Jieba 分词）
- 通用模板查询（适用于任何基于 `AdDictTemplate` 的字典）
  - `get_value<YourDictType>(dict_name, key)` 返回 `const ValueT*`：

```cpp
// 以 AdinfoDict 为例：
AdDict::AdDictCollector collector;
collector.init("my_collect", cfgs, /*off=*/false);

const auto* ad = collector.get_value<AdDict::AdinfoDict>("adinfo", /*creative_id=*/50029291201);
if (ad != nullptr) {
  // 使用 ad->... 字段
}
```

说明：`YourDictType::ContainerType` 决定键值类型；`get_value` 内部会把 `dict_name` 映射为真实 `path`，再到全局实例中取对应 map 并查找 key。

## 监控与指标
- 访问接口内部统一打点到 `g_counters`：
  - `TOTAL`：总查询次数
  - `MAP_OR_KEY_EMPTY`：入参空或 key 空
  - `MAP_NOT_FOUND`：对应字典容器尚未就绪
  - `KEY_NOT_FOUND` / `KEY_FOUND`：命中与未命中
- 在线环境下，`dict_counters_provider.cpp` 会把每个字典的指标与版本号一起“抽干”上报，便于监控不同版本的表现。

## 常见坑与注意事项
- **dict_name 与 path 不一致**：
  - 对外你用 `dict_name` 查；内部真正的数据是按 `path` 这把“真实名”注册与存储的。务必保证 `init` 时的映射正确。
- **key 类型要匹配**：
  - `ConvertKey<int64_t>` 和 `ConvertKey<string>` 会把行文本转为对应类型；数据文件里 key 的文本必须与定义一致。
- **重复 key**：
  - 模板默认“若存在则覆盖”；部分实现（如 `PlaintextKvDict`）会检测重复并上报错误。
- **双缓冲与重置**：
  - 加载切换是无锁替换整个容器，不要持有容器的可变引用；业务保持 `const*` 的只读访问即可。
- **Jieba 字典是目录**：
  - 三个文件缺一不可；`init` 会逐一校验。
- **等待首次加载完成**：
  - 线上通常要等待 `get_first_load_done()`，否则 map 可能为空导致大量 `MAP_NOT_FOUND`。

## 最小可用示例（离线本地加载一个字典并查询）

```cpp
#include "phx-fe/ad_dict/ad_dict_manager.h"
#include "phx-fe/ad_dict/adinfo_dict.h"
using namespace AdDict;

int main() {
  std::vector<hidict::DictConfig> cfgs;
  hidict::DictConfig c{};
  c.m_name = "adinfo";                 // 业务名
  c.m_path = "/path/to/adinfo";        // 实际目录（包含数据文件与 SUCCESS）
  c.m_clazz = "AdinfoDict";            // 注册类名
  cfgs.emplace_back(c);

  AdDictCollector collector;
  collector.init("demo_collect", cfgs, /*off=*/true); // 离线：本进程内直接加载

  const auto* ad = collector.get_adinfo("adinfo", /*creative_id=*/50029291201);
  if (ad) {
    // 使用 ad->... 字段
  }
}
```

## 构建与可执行样例
- 参见 `phx-fe/ad_dict/BUILD`：
  - `cc_library(name = "ad_dict", ...)` 暴露模块；
  - `cc_binary(name = "ad_dict_test" | "offline_dict_test" | "online_dict_test")` 提供示例主程序。

## 快速检索：常用文件索引
- 核心封装：`ad_dict_manager.h/.cpp`，`ad_dict_template.h`，`key_convert.h`
- 字典实现：`adinfo_dict.h`、`appinfo_dict.h`、`adunit_dict.h`、`adstat_dict.h`、`adquerystatsinfo_dict.h`、`adquerycrossapp_dict.h`、`gamestatsdict.h`
- 特殊实现：`packagename2appid_dict.*`、`plaintext_kv_dict.*`、`jieba_dict.*`
- 计数器：`dict_counters_provider.cpp`
- 测试样例：`ad_test.cpp`、`offline_dict_test.cpp`、`online_dict_test.cpp`

如果你只想“先跑通”：
1) 准备一个数据目录，按对应字典的格式生成数据文件，并放置 `SUCCESS` 文件（若 hidict 要求）。
2) 组装 `DictConfig`（name/path/clazz）。
3) `AdDictCollector.init(..., off=true)`；
4) 用 `get_xxx` 或 `get_value<YourDict>` 查询。

