## 粗排 prerank（离线 Item Embedding）源码讲解

粗排 prerank 的离线 Item Embedding 流程：整体架构、关键类/函数职责、任务调度与并发控制、特征缓存双缓冲机制、词典预热与常见排查点。
阅读顺序建议按“入口 -> 初始化 -> 任务触发 -> 图执行 -> 数据加载/提交 -> 完成回调”的主线。

### 1. 代码位置与目标
- **入口二进制**：`biz/prerank/BUILD` 中的 `cc_binary(name = "PrerankOfflineStoreServer")`
- **main 入口**：`biz/prerank/main.cc`
- **服务实现**：`biz/prerank/prerank_offline_server/prerank_offline_server.{h,cpp}`
- **离线流程核心服务**（Graph 节点链路）：`core/core_services/prerank/offline/*`
  - 加载最新 Embedding：`offline/offline_item_emb_dict_loader.cpp`
  - 完成回调与词典预热：`offline/offline_emb_done_service.cpp`、`offline/offline_dict_warmup_notifier.cpp`
- **特征缓存（双缓冲）**：`embedding_cache/feature_cache.{h,cpp}`

目标：定时/按版本触发离线任务，拉取并解析新的 Item Embedding，批量写入本地内存缓存（双缓冲），安全切换对外可读版本，同时触发下游词典预热。

### 2. 运行主线（鸟瞰）
1) 进程启动：
   - `main` 中构造全局 `PrerankOfflineServer`，调用 `start(argc, argv)`。
2) 初始化阶段（`PrerankOfflineServer::initialize`）：
   - 初始化配置中心、模型信号量、词典配置、模型信息、模型版本、DumpRedis、特征上报时间窗任务等。
3) 加载并触发任务（`PrerankOfflineServer::load_prerank`）：
   - 首次根据 `ModelInfoManager` 遍历 ITEM_EMBEDDING 模型，按当前/备份版本提交离线任务；
   - 等待首次批量任务结束；
   - 注册周期任务：按模型维度检查“新版本变更”或“兜底调度时间到达”，触发新的离线任务。
4) 任务执行（`submit_model_task` -> `run_offline_item_embedding`）：
   - 通过信号量限流并发模型数；
   - 在线程里构造 `CoreContext`，设置离线标志、版本、原因等，执行指定 Graph。
5) Graph 节点链路：
   - 在离线链路中，解析外部产出的 `itemEmb.txt`（每行 protobuf）到内存；
   - 批量写入 `FeatureCache` 的备份缓冲，提交切换成可读版本；
   - 完成回调服务释放并发槽位，触发词典预热 HTTP 通知。

### 3. 关键入口与初始化
- `biz/prerank/main.cc`

```cpp
// 关键点：进程入口，启动 Offline Server
// 文件：biz/prerank/main.cc
g_prerank_offline_server.start(argc, argv);
```

- `PrerankOfflineServer::initialize`（`biz/prerank/prerank_offline_server/prerank_offline_server.cpp`）
  - 配置中心接入（Nacos 等）：`AdDictConfigMgr::init`、`ModelInfoManager::init`
  - 并发控制：`ModelSemaphoreManager::Init(ServerConfig::_max_models)`
  - 词典计数器与指标上报：`hidict::g_counters`、`MetricsFlusher`
  - 版本体系：`ModelVersion::new_init()`
  - Dump/上报：`DumpRedisManager::init()`、`feature_report_task_run()`

这一阶段不涉及具体 Embedding 数据，只是确保后续任务所需的配置、模型信息、并发/指标框架已就绪。

### 4. 首次加载与周期调度（load_prerank）
- 遍历 `ModelInfoManager::get_model_infos()`，挑选 `_model_type == ITEM_EMBEDDING` 的模型：
  - 读取 `(cur_version, bak_version)`：`ModelVersion::get_available_model_versions(model_name)`
  - 首次启动策略：
    - 如果 `cur>1 且 bak>=1`，先为 `bak_version` 预分配缓存并提交一次任务（用于兼容/回读场景），随后再为 `cur_version` 提交任务；
    - 对每个提交前，用 `FeatureCache::pre_allocate(model_name, version, is_read_obj)` 预建/清空写入缓冲。
  - 阻塞等待首次任务全部结束：依赖 `_offline_item_emb_cnt` 计数归零。
- 周期任务：
  - 以模型为粒度维护 `last_versions` 与 `last_trigger_times`；
  - 条件一：检测到模型版本变更，立即触发；
  - 条件二：距离上次触发超过 `ServerConfig::_prerank_offline_embedding_scheduled` 分钟，兜底触发；
  - 调度周期由 `ServerConfig::_prerank_offline_embedding_interval` 控制（定时检查）。

并发控制在 `submit_model_task` 中进行，采用信号量限制同时运行的模型任务数，避免资源挤兑。

### 5. 任务提交与 Graph 执行
- `submit_model_task(model_name, dict_name, version, reason, is_version_update, is_first_rotate)`：
  - 获取信号量（不足则阻塞），打印并发监控日志；
  - 启动线程执行 `run_offline_item_embedding(...)`；
  - 线程内异常被捕获并记录，线程为 detached。

- `run_offline_item_embedding(...)` 核心动作：
  - 从 `GraphManager` 取出离线 Graph：`ServerConfig::_prerank_offline_embedding_graph_name`；
  - 构造 `CoreContext`，写入：
    - `ctx->_offline_item_emb_model`、`ctx->_offline_item_emb_version`
    - `ctx->_is_version_update`、`ctx->_is_first_rotate`
    - `ctx->get_prerank_context()->item_dict_name_`、`offline_item_emb_reason_`
    - 开启离线落盘：`set_offline_embedding_dump(true)`（供节点按需使用）
  - 调用 `graph->run(...)` 触发整条离线链路。

Graph 内部会串联若干服务节点，其中与本流程密切相关的：
1) 加载 Embedding 到缓存：`Core::prerank::LoadLatestEmbeddingFromGoose(model_name, version)`
2) 完成回调：`Core::OfflineItemEmbeddingDoneService`

### 6. 加载最新 Embedding（解析与入库）
文件：`core/core_services/prerank/offline/offline_item_emb_dict_loader.cpp`

核心逻辑：
- 扫描词典根路径（来自 `ModelInfoManager` 的 `dict_name`，例如 `/ad/ad_phx_predictor_dict/adinfo/...`），
  - 先按日目录 `yyyyMMdd`，再按分钟目录 `HHmm`，定位带有 `SUCCESS` 标志的最新产出目录；
  - 读取 `_TASK_INFO` 第二行，解析 `model_name,model_version,item_count`（若失败回退到配置传入值）；
- 逐行读取 `itemEmb.txt`：每行是一个 `phx::ItemEmbeddingInfo` 的 protobuf 二进制串；
  - 提取 `cid` 与 `float_val`，按 4096 批量积攒；
  - 调用 `FeatureCache::batch_insert_feature(model_name, model_version, creative_ids, vec_ptr, batch, dim, /*is_version_update=*/true或false)` 写入“备份缓冲”；
- 全量写入完成后：`FeatureCache::commit_buffer(model_name, model_version, is_version_update, is_first_rotate)` 执行双缓冲切换，发布为对外可读数据。

常见问题与日志提示：
- 未找到 `SUCCESS`：日志会提示对应层级；
- `_TASK_INFO` 解析失败：会继续用入参回退；
- `ParseFromString` 失败：单行跳过并打印 WARNING；
- 成功后会打印“commit buffer”与加载行数统计。

### 7. FeatureCache 双缓冲机制（线程安全发布）
文件：`embedding_cache/feature_cache.{h,cpp}`，核心类型 `FeatureCache` 与 `FeatureStruct`。

- `FeatureStruct`：
  - `version`、`model_url`、`timestamp`
  - `featureVectors`：`DBuffer<std::unordered_map<int64_t, std::vector<float>>>`，即一份“读缓冲 + 备份写缓冲”。

- 重要方法：
  - `pre_allocate(model, version, is_read_obj)`：
    - 若找不到模型对应的 `TBuffer<FeatureStruct>`，创建后放入内部环形数组；
    - 选择写入对象（首次可直接写当前写对象；也可选择从活跃读对象恢复），写入版本与时间戳，清空当前写 map。
  - `batch_insert_feature(...)`：
    - 依据 `is_version_update` 或 `model_version` 获取目标 `FeatureStruct`；
    - 向“备份写缓冲”（bak）写入 `creative_id -> 向量`；
  - `commit_buffer(model, version, is_version_update, is_first_rotate)`：
    - `featureVectors.change()` 切换“读/写”角色，将刚写好的 bak 发布为可读；
    - 首次旋转调用 `first_rotate_buffers()`，后续版本更新调用 `rotate_buffers()`；
  - `get_feature(model, version, ads_map, predict_type)`：
    - 在线召回/打分读取时按版本从“当前读缓冲”查向量，填充到 `AdsPair` 对象中。

双缓冲的核心价值：写入与读取互不干扰，提交时常数时间切换句柄，避免长时间加锁或读写竞争。

### 8. 任务完成与词典预热
- 完成服务：`offline/offline_emb_done_service.cpp`
  - 首次加载完成时：`_offline_item_emb_cnt--` 用于 `load_prerank` 的阻塞等待；
  - 释放信号量槽位（打印释放前后并发计数日志）；
  - 触发预热：`Core::prerank::NotifyDictWarmup(model_name, model_version)`。

- 预热通知：`offline/offline_dict_warmup_notifier.cpp`
  - 依据当前日期与 30 分钟区间拼装 `cosPath`；
  - 向 `ServerConfig::_dict_warmup_url + _dict_warmup_uri` 发 HTTP POST，Body 里包含 `cosPath` 与 `serviceCode`；
  - 返回码非 2xx 或超时会打印错误日志；成功会打印 `Warmup notify success`。

### 9. 并发与调度核心点
- 并发上限：`ServerConfig::_max_models`，通过 `ModelSemaphoreManager` 控制；
- 首次加载计数：`ServerConfig::_offline_item_emb_cnt` 与 `_first_load_offline_item_emb` 配合，确保启动期加载完成后再进入稳定态；
- 周期调度：
  - 扫描周期：`_prerank_offline_embedding_interval`（分钟）
  - 兜底触发阈值：`_prerank_offline_embedding_scheduled`（分钟）
  - Graph 名称：`_prerank_offline_embedding_graph_name`

### 10. 构建关系（BUILD）
- `biz/prerank/BUILD`：
  - `PrerankOfflineStoreServer` 依赖 `//biz/prerank/prerank_offline_server:prerank_offline_server`
- `core/core_services/prerank/BUILD`：
  - `cc_library(name = "core_prerank")` 聚合 `embedding_cache`、`online`、`offline`、`truncation` 等子模块，供 Graph 链路节点使用。

### 11. 运行与配置要点（示例）
- 关键 ServerConfig：
  - `_prerank_offline_embedding_graph_name`：离线 Graph 名，必须在 HLFrame 配置里可被 `GraphManager` 获取；
  - `_max_models`：并发模型任务上限；
  - `_prerank_offline_embedding_interval`：周期检查频率（分钟）；
  - `_prerank_offline_embedding_scheduled`：兜底触发间隔（分钟）；
  - `_dict_group_id/_dict_data_id`、`_model_info_group_id/_model_info_data_id`：配置中心键；
  - `_dict_warmup_url/_dict_warmup_uri`：词典预热 HTTP 目的地；
  - `_feature_report_enable/_feature_report_start_h/_feature_report_period_h`：特征上报时间窗。

运行时常见日志位置与关键字：
- 信号量并发："Before acquire/Before release/After release"；
- Graph 获取失败："graph not found"；
- 解析失败："ParseFromString failed"；
- 目录扫描："No day/minute directory with SUCCESS"；
- 提交切换："FeatureCache::commit_buffer — committed"；
- 预热通知："Warmup notify success/failed"。

### 12. 常见排查清单（Checklist）
- Graph 名是否正确配置，`GraphManager` 能否拿到；
- `ModelInfoManager` 中该模型 `_model_type` 是否为 `ITEM_EMBEDDING`；
- 词典根目录是否存在符合规范的 `yyyyMMdd/HHmm/SUCCESS` 层级；
- `_TASK_INFO` 第二行格式：`{model_name},{model_version},{item_count}`；
- `itemEmb.txt` 每行是否是 `phx::ItemEmbeddingInfo` 的序列化二进制；
- `ServerConfig::_max_models` 是否过小导致任务饥饿；
- FeatureCache 是否成功 `pre_allocate`、`batch_insert_feature`、`commit_buffer`；
- 首次启动是否卡在 `_offline_item_emb_cnt` 等待：检查各模型任务是否都走到 `OfflineItemEmbeddingDoneService`；
- 预热 HTTP 配置与连通性；

### 13. 给新手的阅读路径建议
1) 先读 `prerank_offline_server.cpp`，把握“调度与并发控制”的整体节奏；
2) 再读 `offline_item_emb_dict_loader.cpp` 与 `feature_cache.cpp`，理解“数据从磁盘到内存”以及“双缓冲切换”；
3) 最后看 `offline_emb_done_service.cpp` 与 `offline_dict_warmup_notifier.cpp`，理解“任务善后与下游触发”。

如需更深入：结合实际 Graph 配置，跟踪每个节点在离线模式下的输入输出，观察 `CoreContext` 中离线相关标志如何被节点使用。


