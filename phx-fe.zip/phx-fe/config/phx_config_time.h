#pragma once
#include "config.h"
#include <time.h>

namespace phx_fe {

    //返回时间戳所在小时
    class TimeHourConfig final : public OneInputConfig {
    public:
        explicit TimeHourConfig(const std::string &output, const std::vector<std::string> &source,
                                DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                const std::vector<std::string> &strategy)
            : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy) {
        }
        ~TimeHourConfig() override = default;

        std::string get_config() override {
            return "time_hour";
        }

    private:
        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;
        virtual void fill_value_dtype(tensorflow::DataType &data_type) override {
            data_type = tensorflow::DT_INT64;
        }
    };

    //返回时间戳所在小时的时间区间
    class TimeHourScopeConfig final : public OneInputConfig {
    public:
        explicit TimeHourScopeConfig(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy,
                                     const std::vector<int64_t> &hour_boundaries,
                                     const std::vector<std::string> &name_boundaries)
            : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
              hour_boundaries_(hour_boundaries), name_boundaries_(name_boundaries) {
        }
        ~TimeHourScopeConfig() override = default;

        std::string get_config() override {
            std::string display = "time_hour_scope:hour_boundaries:[";
            for (auto &f: hour_boundaries_) {
                display.append(std::to_string(f)).append(",");
            }
            display.pop_back();
            display.append("]");

            display.append(", name_boundaries:[");
            for (auto &str: name_boundaries_) {
                display.append(str).append(",");
            }
            display.pop_back();
            display.append("]");

            return display;
        }

    private:
        //时间区间
        std::vector<int64_t> hour_boundaries_;
        //时间区间的命名
        std::vector<std::string> name_boundaries_;

        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;
        void fill_value_dtype(tensorflow::DataType &data_type) override {
            data_type = tensorflow::DT_STRING;
        }
    };

    //返回时间戳属于一个月的哪一天
    class TimeDayConfig final : public OneInputConfig {
    public:
        explicit TimeDayConfig(const std::string &output, const std::vector<std::string> &source,
                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                               const std::vector<std::string> &strategy)
            : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy) {
        }
        ~TimeDayConfig() override = default;

        std::string get_config() override {
            return "time_day";
        }

    private:
        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;
        void fill_value_dtype(tensorflow::DataType &data_type) override {
            data_type = tensorflow::DT_INT64;
        }
    };

    //返回时间戳属于一个月的哪个日期区间
    class TimeDayScopeConfig final : public OneInputConfig {
    public:
        explicit TimeDayScopeConfig(const std::string &output, const std::vector<std::string> &source,
                                    DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                    const std::vector<std::string> &strategy,
                                    const std::vector<int64_t> &day_boundaries,
                                    const std::vector<std::string> &name_boundaries)
            : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
              day_boundaries_(day_boundaries), name_boundaries_(name_boundaries) {
        }
        ~TimeDayScopeConfig() = default;

        std::string get_config() override {
            std::string display = "time_day_scope:day_boundaries:[";
            for (auto &f: day_boundaries_) {
                display.append(std::to_string(f)).append(",");
            }
            display.pop_back();
            display.append("]");

            display.append(", name_boundaries:[");
            for (auto &str: name_boundaries_) {
                display.append(str).append(",");
            }
            display.pop_back();
            display.append("]");

            return display;
        }

    private:
        //日期区间
        std::vector<int64_t> day_boundaries_;
        //日期区间的命名
        std::vector<std::string> name_boundaries_;

        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;
        void fill_value_dtype(tensorflow::DataType &data_type) override {
            data_type = tensorflow::DT_STRING;
        }
    };

    //返回时间戳属于一周内的星期几
    class TimeWeekConfig final : public OneInputConfig {
    public:
        explicit TimeWeekConfig(const std::string &output, const std::vector<std::string> &source,
                                DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                const std::vector<std::string> &strategy)
            : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy) {
        }
        ~TimeWeekConfig() override = default;

        std::string get_config() override {
            return "time_week";
        }

    private:
        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;
        void fill_value_dtype(tensorflow::DataType &data_type) override {
            data_type = tensorflow::DT_INT64;
        }
    };

    //返回时间戳属于一周内的哪个区间
    class TimeWeekScopeConfig final : public OneInputConfig {
    public:
        explicit TimeWeekScopeConfig(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy,
                                     const std::vector<int64_t> &week_boundaries,
                                     const std::vector<std::string> &name_boundaries)
            : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
              week_boundaries_(week_boundaries), name_boundaries_(name_boundaries) {
        }
        ~TimeWeekScopeConfig() = default;

        std::string get_config() override {
            std::string display = "time_week_scope:week_boundaries:[";
            for (auto &f: week_boundaries_) {
                display.append(std::to_string(f)).append(",");
            }
            display.pop_back();
            display.append("]");

            display.append(", name_boundaries:[");
            for (auto &str: name_boundaries_) {
                display.append(str).append(",");
            }
            display.pop_back();
            display.append("]");

            return display;
        }

    private:
        //一周的区间
        std::vector<int64_t> week_boundaries_;
        //一周内区间的命名
        std::vector<std::string> name_boundaries_;

        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;
        void fill_value_dtype(tensorflow::DataType &data_type) override {
            data_type = tensorflow::DT_STRING;
        }
    };

    //返回时间戳属于一年内的月份
    class TimeMonthConfig final : public OneInputConfig {
    public:
        explicit TimeMonthConfig(const std::string &output, const std::vector<std::string> &source,
                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                 const std::vector<std::string> &strategy)
            : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy) {
        }
        virtual ~TimeMonthConfig() = default;

        std::string get_config() override {
            return "time_month";
        }

    private:
        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;
        void fill_value_dtype(tensorflow::DataType &data_type) override {
            data_type = tensorflow::DT_INT64;
        }
    };

    //返回时间戳属于全年的哪个季度区间
    class TimeMonthScopeConfig final : public OneInputConfig {
    public:
        explicit TimeMonthScopeConfig(const std::string &output, const std::vector<std::string> &source,
                                      DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                      const std::vector<std::string> &strategy,
                                      const std::vector<int64_t> &month_boundaries,
                                      const std::vector<std::string> &name_boundaries)
            : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
              month_boundaries_(month_boundaries), name_boundaries_(name_boundaries) {
        }
        ~TimeMonthScopeConfig() override = default;

        std::string get_config() override {
            std::string display = "time_month_scope:month_boundaries:[";
            for (auto &f: month_boundaries_) {
                display.append(std::to_string(f)).append(",");
            }
            display.pop_back();
            display.append("]");

            display.append(", name_boundaries:[");
            for (auto &str: name_boundaries_) {
                display.append(str).append(",");
            }
            display.pop_back();
            display.append("]");

            return display;
        }

    private:
        //一年的季度区间
        std::vector<int64_t> month_boundaries_;
        //一年季度区间的命名
        std::vector<std::string> name_boundaries_;

        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;
        void fill_value_dtype(tensorflow::DataType &data_type) override {
            data_type = tensorflow::DT_STRING;
        }
    };

    //返回时间戳属于全年的哪个节假日区间
    class TimeHolidayScopeConfig final : public OneInputConfig {
    public:
        //节假日起始日期、结束日期和命名
        struct HolidayData {
            int64_t month_start_;
            int64_t day_start_;
            int64_t month_end_;
            int64_t day_end_;
            std::string holiday_name_;

            HolidayData(int64_t month_start, int64_t day_start, int64_t month_end, int64_t day_end,
                        std::string holiday_name)
                : month_start_(month_start), day_start_(day_start), month_end_(month_end), day_end_(day_end),
                  holiday_name_(holiday_name) {
            }
        };
        explicit TimeHolidayScopeConfig(const std::string &output, const std::vector<std::string> &source,
                                        DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                        const std::vector<std::string> &strategy,
                                        const std::map<std::string, std::vector<int64_t>> &holiday_boundaries,
                                        const std::vector<std::string> &name_boundaries,
                                        const std::string &default_value)
            : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
              default_value_(default_value) {
            int64_t num;
            for (auto &pair: holiday_boundaries) {
                for (uint64_t i = 0; i < pair.second.size() / 4; i++) {
                    if (unlikely(!Calc::convert_int64(pair.first, num))) {
                        THROW_ERROR("convert int64 failed, string:" + pair.first + ", name:" + output_);
                    }
                    holiday_boundaries_[num].emplace_back(pair.second[4 * i], pair.second[4 * i + 1],
                                                          pair.second[4 * i + 2], pair.second[4 * i + 3],
                                                          name_boundaries[i]);
                }
            }
        }
        ~TimeHolidayScopeConfig() = default;

        std::string get_config() override {
            std::string display = "time_holiday_scope:holiday_boundaries:{";
            for (auto &pair: holiday_boundaries_) {
                display.append(std::to_string(pair.first)).append(":[");
                for (auto &date: pair.second) {
                    display.append(std::to_string(date.month_start_)).append(",");
                    display.append(std::to_string(date.day_start_)).append(",");
                    display.append(std::to_string(date.month_end_)).append(",");
                    display.append(std::to_string(date.day_end_)).append(",");
                    display.append(date.holiday_name_).append(",");
                }
                display.pop_back();
                display.append("],");
            }
            display.pop_back();
            display.append("}");

            display.append(", default_value:").append(default_value_);
            return display;
        }

    private:
        //n年的节假日区间和命名
        std::map<int64_t, std::vector<HolidayData>> holiday_boundaries_;
        //非假期的命名
        std::string default_value_;

        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;
        void fill_value_dtype(tensorflow::DataType &data_type) override {
            data_type = tensorflow::DT_STRING;
        }
    };

    void nolocks_localtime(struct tm *result, time_t t);

}// namespace phx_fe