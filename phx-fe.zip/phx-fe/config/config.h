#ifndef FE_CONFIG
#define FE_CONFIG

#include "common/hidict/dict_manager.h"
#include "phx-fe/ad_dict/ad_dict_manager.h"
#include "strategy.h"
#include "phx-fe/util/json_mgr.h"
#include "phx-fe/util/xml_mgr.h"
#include "phx-fe/util/util.h"
#include "phx-fe/util/log.h"
#include "phx-fe/util/map_dict.h"

#include <map>
#include <unordered_map>
#include <memory>
#include <queue>
#include <set>
#include <string>
#include <vector>

enum FEA_ATTR_TYPE {
  ATTR_TYPE_UNKNOWN = -1,
  ATTR_TYPE_USER,
  ATTR_TYPE_ITEM,
  ATTR_TYPE_CROSS,
};

struct ConfigPostInitParam {
  AdDict::AdDictCollector* dict_handle = nullptr;

  explicit ConfigPostInitParam() = default;

  explicit ConfigPostInitParam(AdDict::AdDictCollector* const handle) : dict_handle(handle) {}
};

class Config {
 public:
  int32_t slot_id_ = -1;
  std::vector<Input> inputs_;
  std::string output_;
  std::vector<std::shared_ptr<Strategy>> strategy_;     //策略集合，在compute后进一步处理
  bool save_ = true;
  bool allow_empty_output_ = false;  //输出是否可以为空feature或空feature_list
  bool auto_type_ = false;           //在线处理时，输出类型是否根据value中数据的类型自动适配
  bool int32_ = false;               //在线处理时，输出类型是否从int64转换为int32
  std::string operator_type_;              //算子类型
  tensorflow::DataType defalut_type_ = tensorflow::DT_INVALID;            //在线处理，输出为空auto_type无法获取数据类型时，指定默认数据类型
  FEA_ATTR_TYPE attr_type_ = ATTR_TYPE_UNKNOWN;  //特征产出类型

  explicit Config(const std::string& output,
                  const std::vector<std::string>& source,
                  DefaultValue& default_input_value,
                  bool save,
                  bool allow_empty_output,
                  const std::vector<std::string>& strategy)
      : output_(output), save_(save), allow_empty_output_(allow_empty_output) {
    bool last_feature = false;
    for (uint32_t i = 0; i < strategy.size(); i++) {
      if (strategy[i] == "feature" && i != strategy.size() -1) {
        last_feature = true;
        continue;
      }
      create_strategy(strategy[i], this);
    }
    if (last_feature) {
      create_strategy("feature", this);
    }

    for (const std::string& str : source) {
      LogDebug("{}", str);
      if (allow_empty_output_) {
        inputs_.emplace_back(str, default_input_value, output_, allow_empty_output_);
      } else {
        inputs_.emplace_back(str, default_input_value, output_);
      }
    }

    LogDebug("load output:{} save:{}", output_, save_);
  }
  virtual ~Config() {}

  void set_operator_type(const std::string& operator_type) {
    operator_type_ = operator_type;
  }

  void set_attr_type(FEA_ATTR_TYPE &attr_type) {
    attr_type_ = attr_type;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) {
    THROW_ERROR("no compute, name:" + output_);
    return false;
  }

  virtual std::string get_config() {
    return "";
  }

  virtual void post_init(const ConfigPostInitParam& param) {}

 protected:
  const InputFeature* get_first_ifeature(const std::vector<InputFeature>& ifeatures) {
    if (unlikely(ifeatures.empty())) {
      THROW_ERROR("no ifeature, name:" + output_);
      return nullptr;
    }

    // 确保返回的不为nullptr
    return &ifeatures[0];
  }

  const Value* get_value(const std::vector<const Output*>& input_values, const std::vector<Input>& inputs_, int32_t index) {
    if (unlikely(index < 0 || (int32_t)input_values.size() <= index || (int32_t)inputs_.size() <= index)) {
      THROW_ERROR("input size:" + std::to_string(input_values.size()) + "," + std::to_string(inputs_.size()) + ",index:" + std::to_string(index) + ",name:" + output_);
      return nullptr;
    }

    const int32_t input_idx = inputs_[index].idx;

    if (unlikely(input_idx < 0 || input_idx >= (int32_t)input_values[index]->values.size())) {
      THROW_ERROR("invalid idx:" + std::to_string(input_idx) + ",name:" + output_);
      return nullptr;
    }

    LogDebug("index:{} input_idx:{}", index, input_idx);

    return &input_values[index]->values[input_idx];
  }

  void get_value_feature(const InputFeature* inf_value, int32_t idx, const tensorflow::Feature*& feature) {
    if (inf_value) {
      if (inf_value->feature_list && inf_value->feature_list->feature_size() > idx) {
        feature = &inf_value->feature_list->feature(idx);
        return;
      } else if (inf_value->feature) {
        feature = inf_value->feature;
        return;
      }
    }
    feature = nullptr;
  }

  int64_t get_feature_one_int64(const std::vector<const Output*>& input_values, const std::vector<Input>& inputs_, int32_t index) {
    const Value* value = get_value(input_values, inputs_, index);
    const InputFeature* first = get_first_ifeature(value->ifeatures);

    if (unlikely(nullptr == first->feature)) {
      THROW_ERROR("no feature, name:" + output_);
      return 0;
    }

    auto& vec = first->feature->int64_list().value();

    if (unlikely(vec.empty())) {
      THROW_ERROR("feature no data, name:" + output_);
      return 0;
    }

    return vec[0];
  }

  const InputFeature* get_idx_ifeatures(const Value* value, int32_t idx) {
    if (unlikely(value->ifeatures.empty())) {
      THROW_ERROR("no ifeature, name:" + output_);
      return nullptr;
    }

    int32_t num = value->ifeatures.size();
    if (num == 1) {
      return &value->ifeatures[0];
    } else if (num > idx) {
      return &value->ifeatures[idx];
    } else {
      THROW_ERROR("out ouf range ifeature_size, idx:" + std::to_string(idx) + ", name:" + output_);
      return nullptr;
    }
  }

    bool get_ifeature_one_int64(const InputFeature* ifeature, int64_t& num) {
    const tensorflow::Feature* feature = nullptr;
    get_value_feature(ifeature, 0, feature);

    if (unlikely(!feature)) {
      return false;
    }

    auto& vec = feature->int64_list().value();
    if (unlikely(vec.empty())) {
      return false;
    }

    num = vec[0];
    return true;
  }

  bool get_ifeature_one_string(const InputFeature* ifeature, std::string& str) {
    const tensorflow::Feature* feature = nullptr;
    get_value_feature(ifeature, 0, feature);

    if (unlikely(!feature)) {
      return false;
    }

    auto& vec = feature->bytes_list().value();
    if (unlikely(vec.empty())) {
      return false;
    }

    str = vec[0];
    return true;
  }

  int64_t get_feature_size(const tensorflow::Feature& feature) {
    switch (feature.kind_case()) {
        case tensorflow::Feature::kBytesList: {
          return feature.bytes_list().value_size();
        }

        case tensorflow::Feature::kFloatList: {
          return feature.float_list().value_size();            
        }

        case tensorflow::Feature::kInt64List: {
          return feature.int64_list().value_size();
        }
  
        case tensorflow::Feature::KIND_NOT_SET: {
          return 0;
        }
    }
    return 0;
  }

  int64_t get_ifeature_date_size(const InputFeature* ifeature) {
    int64_t count = 0;

    if (ifeature) {
      if (ifeature->feature_list) {
        for (auto& feat : ifeature->feature_list->feature()) {
          count += get_feature_size(feat);
        }
      } else if (ifeature->feature) {
        count += get_feature_size(*ifeature->feature);
      }
    }

    return count;
  }

  int32_t diff_days(const int64_t now, const int64_t before) {
    return (now - before) / (int64_t)(60 * 60 * 24);
  }

  float diff_days_flaot(const int64_t now, const int64_t before) {
    return (now - before) / (float)(60 * 60 * 24);
  }

  float diff_hours_flaot(const int64_t now, const int64_t before) {
    return (now - before) / (float)(60 * 60);
  }

  static void create_strategy(const std::string& type, Config* config_ptr);
  using StrategyCreatorFunc = std::function<void (Config*)>;
  static const std::map<std::string, StrategyCreatorFunc> strategy_creator_map;
};

class OneInputConfig : public Config {
 public:
  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) {
    const Value* input_value = get_value(input_values, inputs_, 0);
    const uint32_t batch_size = input_value->ifeatures.size();
    const InputFeature* inf = nullptr;
    tensorflow::Feature* out_feature = nullptr;
    tensorflow::FeatureList* out_featurelist = nullptr;

    // Output output;
    output.values.resize(1);
    auto& value = output.values[0];
    value.ifeatures.resize(batch_size);

    for (uint32_t i = 0; i < batch_size; i++) {
      inf = &input_value->ifeatures[i];

      if (likely(inf->feature)) {
        //PointTimer t("OneInputConfig");
        out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        //t.point("arena");
        value.ifeatures[i].feature = out_feature;
        compute_one_feature(*inf->feature, out_feature);
        //t.point("compute");
        //t.display();
      } else if (likely(inf->feature_list)) {
        out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        value.ifeatures[i].feature_list = out_featurelist;
        for (auto& feat : inf->feature_list->feature()) {
          compute_one_feature(feat, out_featurelist->add_feature());
        }
      }
    }

    fill_value_dtype(value.defalut_type);

    LogDebug("------------ compute {} done ------------", output_);
    return true;
  }
 protected:
  explicit OneInputConfig(const std::string& output,
                          const std::vector<std::string>& source,
                          DefaultValue& default_input_value,
                          bool save,
                          bool allow_empty_output,
                          const std::vector<std::string>& strategy)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy) {}
  virtual ~OneInputConfig() {}

  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) = 0;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) {}
};

class TowInputConfig : public Config {
 public:
  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) {
    LogDebug("------------ compute {} start ------------", output_);

    const Value* input_value1 = get_value(input_values, inputs_, 0);
    const Value* input_value2 = get_value(input_values, inputs_, 1);
    uint32_t batch_size = 0;

    if (cross_) {
      batch_size = std::max(input_value1->ifeatures.size(), input_value2->ifeatures.size());
    } else {
      batch_size = std::min(input_value1->ifeatures.size(), input_value2->ifeatures.size());
    }

    output.values.resize(1);
    Value& value = output.values[0];
    value.ifeatures.resize(batch_size);
    tensorflow::Feature* out_feature = nullptr;
    tensorflow::FeatureList* out_featurelist = nullptr;

    const InputFeature* inf_value1 = nullptr;
    const InputFeature* inf_value2 = nullptr;

    //输出
    for (uint32_t i = 0; i < batch_size; i++) {
      if (0 == i || batch_size == input_value1->ifeatures.size()) {
        inf_value1 = &input_value1->ifeatures[i];
      }
      if (0 == i || batch_size == input_value2->ifeatures.size()) {
        inf_value2 = &input_value2->ifeatures[i];
      }

      if (likely(inf_value1->feature_list && inf_value2->feature_list)) {
        out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        value.ifeatures[i].feature_list = out_featurelist;
        uint32_t list_size = std::min(inf_value1->feature_list->feature_size(), inf_value2->feature_list->feature_size());

        for (uint32_t j = 0; j < list_size; j++) {
          compute_one_feature(inf_value1->feature_list->feature(j), inf_value2->feature_list->feature(j), out_featurelist->add_feature());
        }
      } else {
        out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        value.ifeatures[i].feature = out_feature;

        if (likely(inf_value1->feature && inf_value2->feature)) {
          compute_one_feature(*inf_value1->feature, *inf_value2->feature, out_feature);
        }
      }
    }

    fill_value_dtype(value.defalut_type);

    LogDebug("------------ compute {} done ------------", output_);
    return true;
  }

 protected:
  bool cross_; //是否是user特征和item特征交叉，默认为false
  explicit TowInputConfig(const std::string& output,
                          const std::vector<std::string>& source,
                          DefaultValue& default_input_value,
                          bool save,
                          bool allow_empty_output,
                          const std::vector<std::string>& strategy,
                          bool cross = false)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), cross_(cross) {}
  virtual ~TowInputConfig() {}

  virtual void compute_one_feature(const tensorflow::Feature& input_feat1,
                                    const tensorflow::Feature& input_feat2,
                                    tensorflow::Feature* out) = 0;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) {}
};

class AppIdWithEventTime {
 public:
  AppIdWithEventTime() : appid(nullptr), eventtime(0) {}
  AppIdWithEventTime(const std::string* id, int64_t time) : appid(id), eventtime(time) {}
  const std::string* appid;
  int64_t eventtime;
};

class MessageCompute {
 public:
  explicit MessageCompute() {}

  virtual ~MessageCompute() {}

  static void message_fill_fields_dtype_to_value(const Value* message_value,
                                                 const std::vector<std::string>& fields,
                                                 std::vector<Value>& values,
                                                 const std::string& output_name) {
    const google::protobuf::Message* mess = nullptr;
    for (uint32_t i = 0; i < message_value->ifeatures.size(); i++) {
      if (message_value->ifeatures[i].messages.size() > 0) {
        mess = message_value->ifeatures[i].messages[0];
        break;
      }
    }

    if (mess) {
      auto desc = mess->GetDescriptor();
      auto ref = mess->GetReflection();

      if (unlikely(nullptr == ref)) {
        THROW_ERROR("failed, get null_ptr on ref, name:" + output_name);
        return;
      }

      for (uint32_t i = 0; i < fields.size(); i++) {
        auto field = desc->FindFieldByName(fields[i]);

        if (unlikely(nullptr == field || field->is_repeated())) {
          THROW_ERROR("failed, get null_ptr on fields or is repeated field:" + fields[i] + ", name:" + output_name);
          return;
        }

        switch (field->cpp_type()) {
          case google::protobuf::FieldDescriptor::CPPTYPE_INT64:
          case google::protobuf::FieldDescriptor::CPPTYPE_INT32: {
            values[i].defalut_type = tensorflow::DT_INT64;
          }
          break;

          case google::protobuf::FieldDescriptor::CPPTYPE_FLOAT:
          case google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE: {
            values[i].defalut_type = tensorflow::DT_FLOAT;
          }
          break;

          case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
            values[i].defalut_type = tensorflow::DT_STRING;
          }
          break;

          default: {
            THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " filed:" + fields[i] + " name:" + output_name);
            return;
          }
          break;
        }
      }
    }
  }
  
  static void message_fill_fields_to_feature(const google::protobuf::Message* mess,
                                             const std::vector<std::string>& fields,
                                             const std::string& output_name,
                                             std::vector<tensorflow::Feature*>& out_feat) {
    auto desc = mess->GetDescriptor();
    auto ref = mess->GetReflection();

    if (unlikely(nullptr == ref)) {
      THROW_ERROR("failed, get null_ptr on ref, name:" + output_name);
      return;
    }

    for (uint32_t i = 0; i < fields.size(); i++) {
      auto field = desc->FindFieldByName(fields[i]);

      if (unlikely(nullptr == field || field->is_repeated())) {
        THROW_ERROR("failed, get null_ptr on fields or is repeated field:" + fields[i] + ", name:" + output_name);
        return;
      }

      switch (field->cpp_type()) {
        case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
          out_feat[i]->mutable_int64_list()->add_value(ref->GetInt64(*mess, field));
        }
        break;

        case google::protobuf::FieldDescriptor::CPPTYPE_INT32: {
          out_feat[i]->mutable_int64_list()->add_value(ref->GetInt32(*mess, field));
        }
        break;

        case google::protobuf::FieldDescriptor::CPPTYPE_FLOAT: {
          out_feat[i]->mutable_float_list()->add_value(ref->GetFloat(*mess, field));
        }
        break;

        case google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE: {
          out_feat[i]->mutable_float_list()->add_value(static_cast<float>(ref->GetDouble(*mess, field)));
        }
        break;

        case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
          out_feat[i]->mutable_bytes_list()->add_value(ref->GetString(*mess, field));
        }
        break;

        default: {
          THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " filed:" + fields[i] + " name:" + output_name);
          return;
        }
        break;
      }
    }
  }

  static void message_fill_to_int64(const google::protobuf::Message* mess,
                                    const std::string& field_name,
                                    const std::string& output_name,
                                    int64_t& value) {
    auto desc = mess->GetDescriptor();
    auto ref = mess->GetReflection();
    auto field = desc->FindFieldByName(field_name);

    if (unlikely(nullptr == ref)) {
      THROW_ERROR("failed, get null_ptr on ref, name:" + output_name);
      return;
    }

    if (unlikely(nullptr == field || field->is_repeated())) {
      THROW_ERROR("failed, get null_ptr on field or is repeated field:" + field_name + ", name:" + output_name);
      return;
    }

    if (field->cpp_type() == google::protobuf::FieldDescriptor::CPPTYPE_INT64) {
      value = ref->GetInt64(*mess, field);
    } else if (field->cpp_type() == google::protobuf::FieldDescriptor::CPPTYPE_INT32) {
      value = ref->GetInt32(*mess, field);
    } else {
      THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " field:" + field_name + " name:" + output_name);
      return;
    }
  }

  static void message_fill_to_string(const google::protobuf::Message* mess,
                                     const std::string& field_name,
                                     const std::string& output_name,
                                     std::string& str) {
    auto desc = mess->GetDescriptor();
    auto ref = mess->GetReflection();
    auto field = desc->FindFieldByName(field_name);

    if (unlikely(nullptr == ref)) {
      THROW_ERROR("failed, get null_ptr on ref, name:" + output_name);
      return;
    }

    if (unlikely(nullptr == field || field->is_repeated())) {
      THROW_ERROR("failed, get null_ptr on field or is repeated field:" + field_name + ", name:" + output_name);
      return;
    }

    if (field->cpp_type() == google::protobuf::FieldDescriptor::CPPTYPE_STRING) {
      str = ref->GetString(*mess, field);
    } else {
      THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " field:" + field_name + " name:" + output_name);
      return;
    }
  }

  template <typename T, typename std::enable_if<std::is_same<T, std::string>::value, bool>::type = true>
  static void one_message_filter(const std::string& config_name,
                                 const std::string& filter_name,
                                 const google::protobuf::FieldDescriptor* field,
                                 const google::protobuf::Reflection* ref,
                                 const bool filter_hit,
                                 const std::set<T>& filter_set,
                                 const google::protobuf::Message* mess,
                                 std::vector<const google::protobuf::Message*>& temp_messages) {
    switch (field->cpp_type()) {
      case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
        if (filter_hit && (filter_set.empty() || filter_set.find(static_cast<T>(ref->GetString(*mess, field))) != filter_set.end())) {
          temp_messages.emplace_back(mess);
        } else if (!filter_hit && (filter_set.empty() || filter_set.find(ref->GetString(*mess, field)) == filter_set.end())) {
          temp_messages.emplace_back(mess);
        }
      }
      break;

      default: {
        THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " filter:" + filter_name + " name:" + config_name);
        return;
      }
      break;
    }
  }

  template <typename T, typename std::enable_if<std::is_same<T, int64_t>::value, bool>::type = true>
  static void one_message_filter(const std::string& config_name,
                                 const std::string& filter_name,
                                 const google::protobuf::FieldDescriptor* field,
                                 const google::protobuf::Reflection* ref,
                                 const bool filter_hit,
                                 const std::set<T>& filter_set,
                                 const google::protobuf::Message* mess,
                                 std::vector<const google::protobuf::Message*>& temp_messages) {
    switch (field->cpp_type()) {
      case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
        if (filter_hit && (filter_set.empty() || filter_set.find(static_cast<T>(ref->GetInt64(*mess, field))) != filter_set.end())) {
          temp_messages.emplace_back(mess);
        } else if (!filter_hit && (filter_set.empty() || filter_set.find(ref->GetInt64(*mess, field)) == filter_set.end())) {
          temp_messages.emplace_back(mess);
        }
      }
      break;

      case google::protobuf::FieldDescriptor::CPPTYPE_INT32: {
        if (filter_hit && (filter_set.empty() || filter_set.find(static_cast<T>(ref->GetInt32(*mess, field))) != filter_set.end())) {
          temp_messages.emplace_back(mess);
        } else if (!filter_hit && (filter_set.empty() || filter_set.find(ref->GetInt32(*mess, field)) == filter_set.end())) {
          temp_messages.emplace_back(mess);
        }
      }
      break;

      default: {
        THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " filter:" + filter_name + " name:" + config_name);
        return;
      }
      break;
    }
  }

  template <typename T, typename std::enable_if<!std::is_same<T, std::string>::value && !std::is_same<T, int64_t>::value, bool>::type = true>
  static void one_message_filter(const std::string& config_name,
                                 const std::string& filter_name,
                                 const google::protobuf::FieldDescriptor* field,
                                 const google::protobuf::Reflection* ref,
                                 const bool filter_hit,
                                 const std::set<T>& filter_set,
                                 const google::protobuf::Message* mess,
                                 std::vector<const google::protobuf::Message*>& temp_messages) {}


  template <typename T, typename std::enable_if<std::is_same<T, std::string>::value, bool>::type = true>
  static bool one_message_filter(const std::string& config_name,
                                 const std::string& filter_name,
                                 const google::protobuf::FieldDescriptor* field,
                                 const google::protobuf::Reflection* ref,
                                 const bool filter_hit,
                                 const std::unordered_set<T>& filter_set,
                                 const google::protobuf::Message* mess) {
    switch (field->cpp_type()) {
      case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
        if (filter_hit && (!filter_set.empty() && filter_set.find(ref->GetString(*mess, field)) == filter_set.end())) {
          // 命中，filter_set不为空且在filter_set中找不到，该索引位置的mess需要被删除
          return true;
        } else if (!filter_hit && (!filter_set.empty() && filter_set.find(ref->GetString(*mess, field)) != filter_set.end())) {
          // 不命中，filter_set不为空且在filter_set中可以找到，该索引位置的mess需要被删除
          return true;
        }
      }
      break;

      default: {
        THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " filter:" + filter_name + " name:" + config_name);
      }
      break;
    }
    return false; // 默认不删除
  }

  template <typename T, typename std::enable_if<std::is_same<T, int64_t>::value, bool>::type = true>
  static bool one_message_filter(const std::string& config_name,
                                 const std::string& filter_name,
                                 const google::protobuf::FieldDescriptor* field,
                                 const google::protobuf::Reflection* ref,
                                 const bool filter_hit,
                                 const std::unordered_set<T>& filter_set,
                                 const google::protobuf::Message* mess) {
      switch (field->cpp_type()) {
      case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
        if (filter_hit && (!filter_set.empty() && filter_set.find(static_cast<T>(ref->GetInt64(*mess, field))) == filter_set.end())) {
          // 命中，filter_set不为空且在filter_set中找不到，该索引位置的mess需要被删除
          return true;
        } else if (!filter_hit && (!filter_set.empty() && filter_set.find(static_cast<T>(ref->GetInt64(*mess, field))) != filter_set.end())) {
          // 不命中，filter_set不为空且在filter_set中可以找到，该索引位置的mess需要被删除
          return true;
        }
      }
      break;

      case google::protobuf::FieldDescriptor::CPPTYPE_INT32: {
        if (filter_hit && (!filter_set.empty() && filter_set.find(static_cast<T>(ref->GetInt32(*mess, field))) == filter_set.end())) {
          // 命中，filter_set不为空且在filter_set中找不到，该索引位置的mess需要被删除
          return true;
        } else if (!filter_hit && (!filter_set.empty() && filter_set.find(static_cast<T>(ref->GetInt32(*mess, field))) != filter_set.end())) {
          // 不命中，filter_set不为空且在filter_set中可以找到，该索引位置的mess需要被删除
          return true;
        }
      }
      break;

      default: {
        THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " filter:" + filter_name + " name:" + config_name);
      }
      break;
    }
    return false; // 默认不删除
  }

  template <typename T, typename std::enable_if<!std::is_same<T, std::string>::value && !std::is_same<T, int64_t>::value, bool>::type = true>
  static bool one_message_filter(const std::string& config_name,
                                 const std::string& filter_name,
                                 const google::protobuf::FieldDescriptor* field,
                                 const google::protobuf::Reflection* ref,
                                 const bool filter_hit,
                                 const std::unordered_set<T>& filter_set,
                                 const google::protobuf::Message* mess) {
    return false;
  }

  template <typename T>
  static void message_filter_to_message(const std::string& config_name,
                                        const std::string& filter_name,
                                        const bool filter_hit,
                                        const std::set<T>& filter_set,
                                        std::vector<const google::protobuf::Message*>& filter_vec) {
    std::vector<const google::protobuf::Message*> temp_messages;
    const google::protobuf::Message* mess = nullptr;

    for (uint32_t i = 0; i < filter_vec.size(); i++) {
      mess = filter_vec[i];
      auto desc = mess->GetDescriptor();
      auto ref = mess->GetReflection();
      auto field = desc->FindFieldByName(filter_name);

      if (unlikely(nullptr == ref || nullptr == field)) {
        THROW_ERROR("failed, get null_ptr on filter:" + filter_name + ", name:" + config_name);
        return;
      }

      if (unlikely(field->is_repeated())) {
        THROW_ERROR("failed, is repeated filter:" + filter_name + ", name:" + config_name);
        return;
      }

      one_message_filter<T>(config_name, filter_name, field, ref, filter_hit, filter_set, mess, temp_messages);
    }

    //获取符合条件的message
    filter_vec.swap(temp_messages);
  }

  template <typename T>
  static void message_filter_to_message(const std::string& config_name,
                                        const std::string& filter_name,
                                        const bool filter_hit,
                                        const std::unordered_set<T>& filter_set,
                                        const std::vector<const google::protobuf::Message*>& filter_vec,
                                        std::unordered_set<std::size_t>& index_set) {
    const google::protobuf::Message* mess;
    for (std::size_t i = 0; i < filter_vec.size(); ++i) {
      if (index_set.find(i) != index_set.end())
        continue; // 如果index_set已经有该索引，说明已经被排除了，无需再检查
      mess = filter_vec[i];
      auto desc = mess->GetDescriptor();
      auto ref = mess->GetReflection();
      auto field = desc->FindFieldByName(filter_name);

      if (unlikely(nullptr == ref || nullptr == field)) {
        THROW_ERROR("failed, get null_ptr on filter:" + filter_name + ", name:" + config_name);
        return;
      }

      if (unlikely(field->is_repeated())) {
        THROW_ERROR("failed, is repeated filter:" + filter_name + ", name:" + config_name);
        return;
      }

      if (one_message_filter<T>(config_name, filter_name, field, ref, filter_hit, filter_set, mess))
        index_set.emplace(i);
    }
  }

};

#endif  // FE_CONFIG