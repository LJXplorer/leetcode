#pragma once
#include "common/hidict/dict.h"
#include "common/hidict/dict_manager.h"
#include "config.h"
#include "dict/item_info_dict.pb.h"
#include "dict/item_stats_dict.pb.h"
#include "phx-fe/ad_dict/ad_dict_manager.h"
#include "phx-fe/util/invisible_character.h"
#include "phx-fe/util/log.h"
#include <vector>

namespace phx_fe {

    struct DictQueryBase {
    public:
        virtual ~DictQueryBase() = default;

        [[nodiscard]] const google::protobuf::Reflection *GetValueTypeReflection() const {
            return static_cast<const google::protobuf::Reflection *>(dict_->get_value_reflection());
        }

        [[nodiscard]] const google::protobuf::Descriptor *GetValueTypeDescriptor() const {
            return static_cast<const google::protobuf::Descriptor *>(dict_->get_value_descriptor());
        }

        void PostInit() {
            dict_ = _dict_collector->get_dict(_dict_name);
            if (!dict_) {
                THROW_ERROR("dict handler init failed! dict name = [" + _dict_name + "]");
            }
            PostInitImpl();
        }

        const std::string &GetDictName() const {
            return _dict_name;
        }

    protected:
        explicit DictQueryBase(AdDict::AdDictCollector *dict_collector, const std::string &dict_name)
            : _dict_collector(dict_collector), _dict_name(dict_name), dict_(nullptr) {
        }
        virtual void PostInitImpl() = 0;

    protected:
        AdDict::AdDictCollector *_dict_collector;
        std::string _dict_name;
        const DictInfo *dict_;
    };

    struct DictQueryHandler : public DictQueryBase {
    public:
        explicit DictQueryHandler(AdDict::AdDictCollector *dict_collector, const std::string &dict_name)
            : DictQueryBase(dict_collector, dict_name), _dict_type(DictType::kUnknow) {
        }

        ~DictQueryHandler() override = default;

        void QueryDict(const tensorflow::Feature &fea_key,
                       std::vector<const google::protobuf::Message *> *messages) const {
            switch (_dict_type) {
                case (DictQueryHandler::DictType::kAdInfo): {
                    if (fea_key.has_int64_list() && fea_key.int64_list().value_size() > 0) {
                        for (const auto int_key: fea_key.int64_list().value()) {
                            messages->emplace_back(_dict_collector->get_adinfo(_dict_name, int_key));
                        }
                    }
                    return;
                }
                case (DictQueryHandler::DictType::kAppInfo): {
                    if (fea_key.has_int64_list() && fea_key.int64_list().value_size() > 0) {
                        for (const auto int_key: fea_key.int64_list().value()) {
                            messages->emplace_back(_dict_collector->get_appinfo(_dict_name, int_key));
                        }
                    }
                    return;
                }
                case (DictQueryHandler::DictType::kAdunitInfo): {
                    if (fea_key.has_int64_list() && fea_key.int64_list().value_size() > 0) {
                        for (const auto int_key: fea_key.int64_list().value()) {
                            messages->emplace_back(_dict_collector->get_adunitinfo(_dict_name, int_key));
                        }
                    }
                    return;
                }
                case (DictQueryHandler::DictType::kAdStatInfo): {
                    if (fea_key.has_bytes_list() && fea_key.bytes_list().value_size() > 0) {
                        for (const auto &string_key: fea_key.bytes_list().value()) {
                            messages->emplace_back(_dict_collector->get_adstatinfo(_dict_name, string_key));
                        }
                    }
                    return;
                }
                case (DictQueryHandler::DictType::kPackageName2AppIdInfo): {
                    if (fea_key.has_bytes_list() && fea_key.bytes_list().value_size() > 0) {
                        for (const auto &string_key: fea_key.bytes_list().value()) {
                            messages->emplace_back(_dict_collector->get_packagename2appid_info(_dict_name, string_key));
                        }
                    }
                    return;
                }
                case (DictQueryHandler::DictType::kUnknow): {
                    THROW_ERROR("unknow dict type, dict name = [" + _dict_name + "]");
                    break;
                }
            }
        }

    protected:
        void PostInitImpl() override {
            if (dict_->get_value_descriptor() == phx::AppInfoDict::GetDescriptor()) {
                _dict_type = DictType::kAppInfo;
            } else if (dict_->get_value_descriptor() == phx::AdInfoDict::GetDescriptor()) {
                _dict_type = DictType::kAdInfo;
            } else if (dict_->get_value_descriptor() == phx::AdunitInfoDict::GetDescriptor()) {
                _dict_type = DictType::kAdunitInfo;
            } else if (dict_->get_value_descriptor() == phx::ItemStatsDict::GetDescriptor()) {
                _dict_type = DictType::kAdStatInfo;
            } else if (dict_->get_value_descriptor() == phx::PackageName2AppIdDict::GetDescriptor()) {
                _dict_type = DictType::kPackageName2AppIdInfo;
            } else {
                THROW_ERROR("dict handler init failed! dict name = [" + _dict_name + "]");
            }
        }

    private:
        enum class DictType { kUnknow, kAppInfo, kAdInfo, kAdunitInfo, kAdStatInfo, kPackageName2AppIdInfo };
        DictType _dict_type;
    };

    struct StatsDictQueryHandler : public DictQueryBase {
    public:
        explicit StatsDictQueryHandler(AdDict::AdDictCollector *dict_collector, const std::string &dict_name)
            : DictQueryBase(dict_collector, dict_name), _dict_type(DictType::kUnknow) {
        }

        ~StatsDictQueryHandler() override = default;
        void QueryDict(const std::vector<std::string> &vec,
                       std::vector<const google::protobuf::Message *> &messages) const {
            switch (_dict_type) {
                case (StatsDictQueryHandler::DictType::kAdStatInfo): {
                    for (const auto &str_key: vec) {
                        messages.emplace_back(_dict_collector->get_adstatinfo(_dict_name, str_key));
                    }
                    break;
                }
                case (StatsDictQueryHandler::DictType::kAdQueryStatInfo): {
                    for (const auto &str_key: vec) {
                        messages.emplace_back(_dict_collector->get_adquerystats_info(_dict_name, str_key));
                    }
                    break;
                }
                case (StatsDictQueryHandler::DictType::kAdQueryCrossAppInfo): {
                    for (const auto &str_key: vec) {
                        messages.emplace_back(_dict_collector->get_adquerycrossapp_info(_dict_name, str_key));
                    }
                    break;
                }
                case (StatsDictQueryHandler::DictType::kGameStatsInfo): {
                    for (const auto &str_key: vec) {
                        messages.emplace_back(_dict_collector->get_value<AdDict::GameStatsDict>(_dict_name, str_key));
                    }
                    break;
                }
                case (StatsDictQueryHandler::DictType::kUnknow): {
                    THROW_ERROR("unknow dict type, dict name = [" + _dict_name + "]");
                    break;
                }
                default: {
                    THROW_ERROR("unsupport dict type, dict name = [" + _dict_name + "]");
                    break;
                }
            }
        }

    protected:
        void PostInitImpl() override {
            if (dict_->get_value_descriptor() == phx::AppInfoDict::GetDescriptor()) {
                _dict_type = DictType::kAppInfo;
            } else if (dict_->get_value_descriptor() == phx::AdInfoDict::GetDescriptor()) {
                _dict_type = DictType::kAdInfo;
            } else if (dict_->get_value_descriptor() == phx::AdunitInfoDict::GetDescriptor()) {
                _dict_type = DictType::kAdunitInfo;
            } else if (dict_->get_value_descriptor() == phx::ItemStatsDict::GetDescriptor()) {
                _dict_type = DictType::kAdStatInfo;
            } else if (dict_->get_value_descriptor() == phx::AdQueryStatsInfo::GetDescriptor()) {
                _dict_type = DictType::kAdQueryStatInfo;
            } else if (dict_->get_value_descriptor() == phx::AdQueryCrossAppDict::GetDescriptor()) {
                _dict_type = DictType::kAdQueryCrossAppInfo;
            } else if (dict_->get_value_descriptor() == phx::GameStatsDict::GetDescriptor()) {
                _dict_type = DictType::kGameStatsInfo;
            } else {
                THROW_ERROR("dict handler init failed! dict name = [" + _dict_name + "]");
            }
        }

    private:
        enum class DictType {
            kUnknow,
            kAppInfo,
            kAdInfo,
            kAdunitInfo,
            kAdStatInfo,
            kAdQueryStatInfo,
            kAdQueryCrossAppInfo,
            kGameStatsInfo
        };
        DictType _dict_type;
    };

    struct CustomDictQueryHandle : public DictQueryBase {
    public:
        explicit CustomDictQueryHandle(AdDict::AdDictCollector *dict_collector, const std::string &dict_name,
                                       const std::string &prefix)
            : DictQueryBase(dict_collector, dict_name), _prefix(prefix) {
        }
        ~CustomDictQueryHandle() override = default;

        const tensorflow::Feature *QueryDict(const tensorflow::Feature &fea_key, const std::string &type) const {
            if (fea_key.has_bytes_list() && fea_key.bytes_list().value_size() > 0) {
                std::string key;
                if (!_prefix.empty()) {
                    key.append(_prefix).append("_");
                }
                key.append(type).append("_").append(fea_key.bytes_list().value(0));
                return _dict_collector->get_value<AdDict::PlaintextKvDict>(_dict_name, key);

            } else if (fea_key.has_int64_list() && fea_key.int64_list().value_size() > 0) {
                std::string key;
                if (!_prefix.empty()) {
                    key.append(_prefix).append("_");
                }
                key.append(type).append("_").append(std::to_string(fea_key.int64_list().value(0)));
                return _dict_collector->get_value<AdDict::PlaintextKvDict>(_dict_name, key);
            } else {
                return nullptr;
            }
        }

        const std::string _prefix;

    protected:
        void PostInitImpl() override {
            if (dict_->get_value_descriptor() != tensorflow::Feature::GetDescriptor()) {
                THROW_ERROR("dict handler init failed! custom_dict_query's dict content must be feature");
            }
        }
    };

    class QueryDictConfig : public Config {
    private:
        /**
     * @brief 输出field的field descriptor列表，第一维为输出域编号，第二维是某个输出域的field_descriptor,类似creative_stats_14d.num_expose
     * 
     */
        std::vector<std::vector<const google::protobuf::FieldDescriptor *>> output_field_desc_index_;
        int64_t default_int64_value_;
        float default_float_value_;
        std::string default_string_value_;
        DictQueryHandler handler_;
        const google::protobuf::Reflection *reflection_;
        std::string output_fields_str_;

        bool FillDefaultValue(const google::protobuf::FieldDescriptor *field_desc, tensorflow::Feature *output_feature);

    public:
        explicit QueryDictConfig(const std::string &output, const std::vector<std::string> &source,
                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                 const std::vector<std::string> &strategy, hidict::DictCollector *dict_collector,
                                 const std::string &_dict_name, const std::string &output_fields_str,
                                 int64_t default_int64_value, float default_float_value,
                                 std::string default_string_value);
        bool compute(const std::vector<const Output *> &input_values, Output &output) override;
        void post_init(const ConfigPostInitParam &param) override;
    };

    class PreConnectToStringConfig : public Config {
    public:
        explicit PreConnectToStringConfig(const std::string &output, const std::vector<std::string> &source,
                                          DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                          const std::vector<std::string> &strategy, const std::string &connector,
                                          const std::vector<std::string> &prefixs)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              org_connector_(connector), connector_(connector), prefixs_(prefixs) {
            InvisibleCharacter::character_replace(connector_);
        }
        virtual ~PreConnectToStringConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "pre_connect_to_string:connector:";
            display.append(org_connector_);
            display.append(", prefixs:[");
            for (auto &prefix: prefixs_) {
                display.append(prefix).append(",");
            }
            display.pop_back();
            display.append("]");

            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        /**
     * @brief pb全拼接到一个string，每个输入内使头部支持添加自定义前缀，不同输入间使用连接符一拼接，连接符支持自定义，支持全数据类型
     * 
     */
        std::string org_connector_;       //原始连接符
        std::string connector_;           //连接符
        std::vector<std::string> prefixs_;//前缀
        void compute_one_feature(const tensorflow::Feature &feat, size_t idx, std::string &str);
    };

    class QueryStatsDictConfig : public Config {
    public:
        struct KeyType {
            bool from_source_ = false;
            std::size_t source_index_ = 0;
            std::string value_;
            std::string type_;
        };

        explicit QueryStatsDictConfig(const std::string &output, const std::vector<std::string> &source,
                                      DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                      const std::vector<std::string> &strategy, hidict::DictCollector *dict_collector,
                                      const std::string &_dict_name, const std::string &output_fields_str,
                                      const std::string &keys, const std::string &types, int64_t default_int64_value,
                                      float default_float_value, const std::string &default_string_value);

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;
        void post_init(const ConfigPostInitParam &param) override;

    private:
        bool FillDefaultValue(const google::protobuf::FieldDescriptor *field_desc, tensorflow::Feature *output_feature);

        static std::string GetSourceKey(const Value *key, size_t batch_size, size_t feature_index);

        void WriteRepeatedToFeature(tensorflow::Feature *output_feature, const google::protobuf::Message &cur_msg,
                                    const google::protobuf::FieldDescriptor *field_desc,
                                    const google::protobuf::Reflection *reflection);

        void WriteSingleToFeature(tensorflow::Feature *output_feature, const google::protobuf::Message &cur_msg,
                                  const google::protobuf::FieldDescriptor *field_desc,
                                  const google::protobuf::Reflection *reflection);

        std::vector<std::pair<std::vector<const google::protobuf::FieldDescriptor *>, bool>>
                output_field_desc_index_;// <bool表示链路上是否有repeated类型>
        std::vector<KeyType> keys_;
        int64_t default_int64_value_;
        float default_float_value_;
        std::string default_string_value_;
        StatsDictQueryHandler handler_;
        const google::protobuf::Reflection *reflection_;
        std::string output_fields_str_;

        static const std::unordered_map<std::string, std::string> types_map_;
        friend class QueryCustomDictConfig;
    };

    class QueryCustomDictConfig final : public Config {
    public:
        explicit QueryCustomDictConfig(const std::string &output, const std::vector<std::string> &source,
                                       DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                       const std::vector<std::string> &strategy, hidict::DictCollector *dict_collector,
                                       const std::string &_dict_name, const std::string &prefix,
                                       int64_t default_int64_value, const std::string &default_string_value,
                                       float default_float_value, int type, const std::string &key_type);

        ~QueryCustomDictConfig() override = default;

        std::string get_config() override {
            std::string display = "query_custom_dict: prefix: [" + _handler._prefix + "]";

            return display;
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;
        void post_init(const ConfigPostInitParam &param) override;
    private:
        CustomDictQueryHandle _handler;
        const google::protobuf::Reflection *_reflection;
        int _type;// 0: int64 , 1: string, 2: float
        std::string _key_type;
        int64_t _default_int64_value;
        std::string _default_string_value;
        float _default_float_value;
    };

}// namespace phx_fe
