#include "ad_store_server.h"
#include "common/hidict/dict_counters_provider.h"
#include "core/core_context/core_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/dict/dict_mgr.h"
#include "core/core_services/dict/metrics_flusher.h"
#include "core/core_services/dump/dump_redis_manager/dump_redis_manager.h"
#include "core/core_services/predict/utils/model_version.h"
#include "core/core_services/prerank/embedding_cache/feature_cache.h"
#include "core/core_services/prerank/offline/offline_item_emb_dict_loader.h"
#include "core/utils/monitor_mgr.h"
#include "hlframe/graph_manager.h"
#include <bthread/types.h>
#include <chrono>
#include <debug_utils.h>
#include <filesystem>
#include <fstream>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
namespace fs = std::filesystem;

using namespace Core;
static AdDict::MetricsFlusher g_flusher(60);
extern hidict::RealCounters g_real;

namespace ADStore {
    static std::unordered_map<std::string, std::string> g_last_marker_filename;
    static std::unordered_map<std::string, bool> g_last_load_success;
    static std::mutex g_offline_loader_mutex;
    static std::chrono::steady_clock::time_point g_last_load_start_time;
    static std::unordered_map<std::string, std::pair<int, std::string>> g_latest_scanned_info;
    static std::mutex g_scanned_info_mutex;
    static bool g_is_loading = false;
    const int MAX_LOAD_MINUTES = 3;

    // Base_dir文件信息
    struct BaseDirInfo {
        std::string filename;
        std::string filepath;
        std::string base_dir;
        bool is_version_update;
        bool is_first_rotate;
        int32_t model_version;
        bool is_read_obj;
    };

    ADStoreServer::ADStoreServer() {
    }

    ADStoreServer::~ADStoreServer() {
        g_flusher.stop();
    }

    int ADStoreServer::initialize(int argc, char *argv[]) {
        config::ConfigServiceCfg cfg{.server_adder = ServerConfig::_server_adder,
                                     .auth_user_name = ServerConfig::_auth_user_name,
                                     .auth_passwd = ServerConfig::_auth_passwd,
                                     .name_space = ServerConfig::_name_space};

        // 在线时才会创建
        hidict::g_counters = &hidict::g_real;

        if (Core::AdDictConfigMgr::instance().init(cfg, ServerConfig::_dict_group_id, ServerConfig::_dict_data_id) !=
            ERROR_SUCCESS) {
            std::cerr << "dict xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        }

        // 这里已经词典计数器已经注册完成
        g_flusher.start();

        if (Core::Info::ModelInfoManager::instance().init(cfg, ServerConfig::_model_info_group_id,
                                                          ServerConfig::_model_info_data_id) != ERROR_SUCCESS) {
            std::cerr << "model_info xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        } else {
            std::cerr << "ModelInfoManager init success" << std::endl;
        }
        ModelVersion::instance().new_init();

        Core::DumpRedisManager::instance().init();
        if (ServerConfig::_feature_report_enable.load()) {
            feature_report_task_run();
        }
        start_offline_embedding_loader_task();
        return 0;
    }

    int ADStoreServer::load_prerank() {
        LOG_INFO << "Loading prerank models, graph name: "
                        << ServerConfig::_prerank_offline_embedding_graph_name;

        if (ServerConfig::_prerank_offline_embedding_graph_name.empty()) {
            LOG_ERROR << "Prerank offline embedding graph name is empty!";
            return -1;
        }

        auto &model_info_manager = Core::Info::ModelInfoManager::instance();
        auto &channel_map = model_info_manager.get_model_infos();
        std::vector<std::string> model_names;

        // 记录每个模型的版本
        static std::unordered_map<std::string, int32_t> last_versions;
        // 记录每个模型的上次触发时间
        static std::unordered_map<std::string, std::chrono::steady_clock::time_point> last_trigger_times;

        // 初始加载
        for (const auto &channel_pair: channel_map) {
            const std::string &model_name = channel_pair.first;
            if (channel_pair.second->_model_type != Core::Info::ModelType::ITEM_EMBEDDING) {
                continue;
            }
            model_names.push_back(model_name);
            auto [cur_version, bak_version] = ModelVersion::instance().get_available_model_versions(model_name);
            LOG_INFO << "cur_version " << cur_version << " bak_version " << bak_version;
            last_versions[model_name] = cur_version;
            last_trigger_times[model_name] = std::chrono::steady_clock::now();
            bool is_version_update = true;
            bool is_read_obj = false;
            if (cur_version > 1 && bak_version >= 1) {
                LOG_ERROR << "need to run offline embedding for model: " << model_name
                                 << ", version: " << cur_version;
                ServerConfig::_offline_item_emb_cnt.fetch_add(1);
                prerank::FeatureCache::get_instance().pre_allocate(model_name, bak_version, false);
                run_offline_item_embedding(model_name, channel_pair.second->_dict_name, bak_version,
                                           Core::kInitialLaunch, is_version_update, true);
                is_version_update = false;
                is_read_obj = true;
            }
            ServerConfig::_offline_item_emb_cnt.fetch_add(1);
            prerank::FeatureCache::get_instance().pre_allocate(model_name, cur_version, is_read_obj);
            run_offline_item_embedding(model_name, channel_pair.second->_dict_name, cur_version, Core::kInitialLaunch,
                                       is_version_update, false);
        }
        if (!ServerConfig::_preank_item_emb_enable) {

            while (true) {
                if (ServerConfig::_offline_item_emb_cnt.load() < 1) {
                    ServerConfig::_first_load_offline_item_emb = false;
                    break;
                }
                sleep(1);
            }
        }

        LOG_INFO << "Models participating in offline item embedding: " << debug::printer::ToString(model_names);

        // 定时检查任务（每个模型单独计时）
        auto offline_item_emb_task = [&]() mutable {
            auto &model_info_manager = Core::Info::ModelInfoManager::instance();
            auto &channel_map = model_info_manager.get_model_infos();

            for (const auto &channel_pair: channel_map) {
                if (channel_pair.second->_model_type != Core::Info::ModelType::ITEM_EMBEDDING) {
                    continue;
                }

                const std::string &model_name = channel_pair.first;
                int32_t current_version = ModelVersion::instance().get_model_version(model_name);

                bool triggered = false;

                // 版本更新立即触发
                if (current_version != last_versions[model_name]) {
                    prerank::FeatureCache::get_instance().pre_allocate(model_name, current_version, false);

                    LOG_ERROR << "Model " << model_name << " version updated: " << last_versions[model_name]
                                     << " -> " << current_version;
                    run_offline_item_embedding(model_name, channel_pair.second->_dict_name, current_version,
                                               Core::kPeriodicTask, true, false);
                    last_versions[model_name] = current_version;
                    last_trigger_times[model_name] = std::chrono::steady_clock::now();
                    triggered = true;
                }

                // 按模型单独的兜底时间触发
                auto now = std::chrono::steady_clock::now();
                if (!triggered &&
                    std::chrono::duration_cast<std::chrono::minutes>(now - last_trigger_times[model_name]).count() >=
                            ServerConfig::_prerank_offline_embedding_scheduled) {

                    LOG_ERROR << ServerConfig::_prerank_offline_embedding_scheduled
                                     << " minutes passed since last run for " << model_name
                                     << ", triggering offline embedding";
                    bool is_version_update = false;

                    if (current_version != last_versions[model_name]) {
                        is_version_update = true;
                        prerank::FeatureCache::get_instance().pre_allocate(model_name, current_version, false);
                        last_versions[model_name] = current_version;
                    }
                    run_offline_item_embedding(model_name, channel_pair.second->_dict_name, current_version,
                                               Core::kPeriodicTask, is_version_update, false);
                    last_trigger_times[model_name] = now;
                }
            }
        };

        // 定时执行
        _offline_embedding_task = common::g_backgroud_task_executor.PostPeriodic(
                std::chrono::minutes(ServerConfig::_prerank_offline_embedding_interval), offline_item_emb_task);
        _offline_embedding_task->Start();

        return 0;
    }

    void ADStoreServer::run_offline_item_embedding(const std::string &model_name, const std::string &dict_name,
                                                   int32_t model_version, OfflineItemEmbTaskReason reason,
                                                   bool is_version_update, bool is_first_rotate) {

        if (ServerConfig::_preank_item_emb_enable) {
            return;
        }

        auto graph = GraphManager::instance().get_graph(ServerConfig::_prerank_offline_embedding_graph_name);
        if (graph == nullptr) {
            LOG_ERROR << "Item offline embedding service graph not found! graph name: offline_item_emb";
            return;
        }

        LOG_ERROR << "Running offline item embedding, dict_name: " << dict_name << ", model_name: " << model_name
                         << ", model_version: " << model_version;

        phx::PredictorRequest *fake_predict_request = new phx::PredictorRequest();
        phx::PredictorResponse *fake_predict_response = new phx::PredictorResponse();
        CoreContextPtr core_context = std::make_shared<CoreContext>();
        int64_t timestamp = gettimeofday_ms();
        fake_predict_request->mutable_reqid()->assign(std::to_string(timestamp));// 离线校验点上报，请求id填充时间戳
        core_context->make_request_context(nullptr, fake_predict_request, fake_predict_response, nullptr);
        core_context->_need_relase_rank_req_manually = true;
        core_context->_need_release_rank_res_manually = true;
        core_context->_offline_item_emb_model = model_name;
        core_context->_offline_item_emb_version = model_version;
        core_context->_is_version_update = is_version_update;
        core_context->_is_first_rotate = is_first_rotate;
        core_context->init();
        core_context->get_prerank_context()->item_dict_name_ = dict_name;
        core_context->get_prerank_context()->offline_item_emb_reason_ = reason;
        core_context->get_prerank_context()->set_offline_embedding_dump(true);

        graph->run(core_context, nullptr, fake_predict_request, fake_predict_response, nullptr);
    }
    void ADStoreServer::feature_report_task_run() {
        auto feature_report_start_task = []() {
            LOG_ERROR << "[feature_report] feature_report_start_task";
            if (ServerConfig::_feature_report_enable.load()) {
                ServerConfig::_feature_report_running.store(true);
            }
        };

        auto feature_report_end_task = []() {
            LOG_ERROR << "[feature_report] feature_report_end_task";
            ServerConfig::_feature_report_running.store(false);
        };

        int32_t start_h = ServerConfig::_feature_report_start_h;
        int32_t end_h = (start_h + ServerConfig::_feature_report_period_h) % 24;
        _feature_report_start_task =
                common::g_backgroud_task_executor.PostPeriodicCron(1, 0, start_h, feature_report_start_task);
        _feature_report_start_task->Start();

        _feature_report_end_task =
                common::g_backgroud_task_executor.PostPeriodicCron(0, 0, end_h, feature_report_end_task);
        _feature_report_end_task->Start();
    }

    void ADStoreServer::start_offline_embedding_loader_task() {
        auto task = [this]() {
            std::unique_lock<std::mutex> lock(g_offline_loader_mutex, std::try_to_lock);
            if (!lock.owns_lock()) {
                auto now = std::chrono::steady_clock::now();
                if (g_is_loading) {
                    auto elapsed_minutes =
                            std::chrono::duration_cast<std::chrono::minutes>(now - g_last_load_start_time).count();
                    auto elapsed_seconds =
                            std::chrono::duration_cast<std::chrono::seconds>(now - g_last_load_start_time).count();

                    if (elapsed_minutes >= MAX_LOAD_MINUTES) {
                        LOG_ERROR  << "上一次加载已超过" << MAX_LOAD_MINUTES << "分钟仍未完成（已用时"
                                         << elapsed_seconds << "秒），可能卡住了！跳过本次扫描";
                    } else {
                        LOG_ERROR  << "上一次扫描任务还未完成（已用时" << elapsed_seconds << "秒），跳过本次扫描";
                    }
                } else {
                    LOG_ERROR  << "上一次扫描任务还未完成，跳过本次扫描";
                }
                return;
            }

            g_last_load_start_time = std::chrono::steady_clock::now();
            g_is_loading = true;

            try {
                if (!ServerConfig::_preank_item_emb_enable) {
                    g_is_loading = false;
                    return;
                }
                LOG_ERROR  << "开始定时每分钟扫描";
                auto &model_info_manager = Core::Info::ModelInfoManager::instance();
                auto &channel_map = model_info_manager.get_model_infos();
                for (const auto &channel_pair: channel_map) {
                    if (channel_pair.second->_model_type != Core::Info::ModelType::ITEM_EMBEDDING) {
                        continue;
                    }
                    const std::string &model_name = channel_pair.first;

                    // 获取当前日期和时间窗口
                    std::string current_date = get_current_date_yyyymmdd();
                    std::string current_interval = get_current_30min_interval();

                    // 获取当前可用版本
                    auto [cur_version, bak_version] = ModelVersion::instance().get_available_model_versions(model_name);

                    // 检查是否为该模型的首次运行
                    bool is_first_run_for_model = false;
                    int last_scanned_version = -1;
                    {
                        std::lock_guard<std::mutex> info_lock(g_scanned_info_mutex);
                        auto it = g_latest_scanned_info.find(model_name);
                        is_first_run_for_model = (it == g_latest_scanned_info.end());
                        if (!is_first_run_for_model) {
                            last_scanned_version = it->second.first;// 获取上次扫描的版本
                        }
                    }

                    // 如果是首次运行，执行初始化扫描
                    if (is_first_run_for_model) {
                        LOG_ERROR  << "模型首次运行或尚无扫描记录。model=" << model_name;

                        // 先尝试扫描当前时间窗口
                        bool current_scanned = false;
                        bool is_version_update = true;
                        bool is_read_obj = false;

                        if (cur_version > 1 && bak_version >= 1) {
                            bool bak_current_scanned =
                                    scan_version_window(model_name, bak_version, current_date, current_interval,
                                                        is_version_update, true, is_read_obj);
                            if (!bak_current_scanned) {
                                std::string prev_interval = get_prev_30min_interval(current_interval);
                                if (!prev_interval.empty()) {
                                    scan_version_window(model_name, bak_version, current_date, prev_interval,
                                                        is_version_update, true, is_read_obj);
                                }
                            }
                            is_version_update = false;
                            is_read_obj = true;
                        }

                        current_scanned = scan_version_window(model_name, cur_version, current_date, current_interval,
                                                              is_version_update, false, is_read_obj);

                        // 如果当前时间窗口没有数据，尝试扫描上一个时间窗口
                        if (!current_scanned) {
                            std::string prev_interval = get_prev_30min_interval(current_interval);
                            if (!prev_interval.empty() && cur_version > 0) {
                                scan_version_window(model_name, cur_version, current_date, prev_interval,
                                                    is_version_update, false, is_read_obj);
                            }
                        }

                    } else {
                        // 非首次运行：检查版本是否更新
                        bool is_model_version_updated = (cur_version != last_scanned_version);

                        if (is_model_version_updated) {
                            LOG_ERROR  << "检测到model_version更新，开始扫描。model=" << model_name
                                             << ", 新model_version=" << cur_version
                                             << ", 旧model_version=" << last_scanned_version;
                            // 版本更新，需要全量加载
                            scan_current_window(model_name, cur_version, current_date, current_interval,
                                                true, // is_version_update
                                                false,// is_first_rotate
                                                false // is_read_obj
                            );
                        } else {
                            LOG_ERROR  << "未检测到model_version更新，开始扫描。model=" << model_name
                                             << ", model_version=" << cur_version;
                            // 版本未更新，正常增量扫描
                            scan_current_window(model_name, cur_version, current_date, current_interval,
                                                false,// is_version_update
                                                false,// is_first_rotate
                                                false // is_read_obj
                            );
                        }
                    }
                }
            } catch (const std::exception &e) {
                LOG_ERROR  << "OfflineTask: exception: " << e.what();
            }

            g_is_loading = false;
            auto end_time = std::chrono::steady_clock::now();
            auto duration_ms =
                    std::chrono::duration_cast<std::chrono::milliseconds>(end_time - g_last_load_start_time).count();
            LOG_ERROR  << "本次扫描加载完成，总耗时: " << duration_ms << "ms)";
        };

        // 首次手动调用
        LOG_ERROR  << "首次同步加载开始";
        task();
        LOG_ERROR  << "首次同步加载完成，进入异步定时扫描";

        // 定时任务
        _offline_loader_task = common::g_backgroud_task_executor.PostPeriodic(std::chrono::minutes(1), task);
        _offline_loader_task->Start();
    }

    bool ADStoreServer::scan_version_window(const std::string &model_name, int model_version, const std::string &date,
                                            const std::string &interval, bool is_version_update, bool is_first_rotate,
                                            bool is_read_obj) {
        fs::path base_dir =
                fs::path(ServerConfig::_emb_cos_path) / model_name / std::to_string(model_version) / date / interval;

        std::string window_identifier = date + "_" + interval;

        {
            std::lock_guard<std::mutex> lock(g_scanned_info_mutex);
            auto it = g_latest_scanned_info.find(model_name);
            if (it != g_latest_scanned_info.end() && it->second.first == model_version &&
                it->second.second == window_identifier) {
                LOG_ERROR  << "窗口已扫描，跳过。model=" << model_name << ", version=" << model_version
                                 << ", window=" << window_identifier;
                return true;
            }
        }

        fs::path success_file = base_dir / "SUCCESS";
        if (fs::exists(success_file)) {
            LOG_ERROR  << "找到success文件，开始加载。model=" << model_name << ", version=" << model_version
                             << ", window=" << window_identifier;

            int ret = Core::prerank::LoadLatestEmbeddingFromGoose(model_name, model_version, base_dir.string(),
                                                                  is_version_update, is_first_rotate, is_read_obj);
            if (ret == 0) {
                {
                    std::lock_guard<std::mutex> lock(g_scanned_info_mutex);
                    g_latest_scanned_info[model_name] = std::make_pair(model_version, window_identifier);
                }
                LOG_ERROR  << "加载成功，记录窗口。model=" << model_name << ", version=" << model_version
                                 << ", window=" << window_identifier;
                return true;
            } else {
                LOG_ERROR  << "加载失败。model=" << model_name << ", version=" << model_version
                                 << ", window=" << window_identifier;
                return false;
            }
        } else {
            LOG_ERROR  << "未找到success文件，跳过。model=" << model_name << ", version=" << model_version
                             << ", window=" << window_identifier;
            return false;
        }
    }

    void ADStoreServer::scan_current_window(const std::string &model_name, int model_version,
                                            const std::string &current_date, const std::string &current_interval,
                                            bool is_version_update, bool is_first_rotate, bool is_read_obj) {

        std::string target_interval = current_interval;

        std::string last_scanned_window_identifier;
        {
            std::lock_guard<std::mutex> lock(g_scanned_info_mutex);
            auto it = g_latest_scanned_info.find(model_name);
            if (it != g_latest_scanned_info.end() && it->second.first == model_version) {
                last_scanned_window_identifier = it->second.second;
            }
        }

        if (!last_scanned_window_identifier.empty()) {
            size_t last_underscore = last_scanned_window_identifier.find_last_of('_');
            if (last_underscore != std::string::npos) {
                std::string scanned_interval = last_scanned_window_identifier.substr(last_underscore + 1);
                std::string next_interval = get_next_30min_interval(scanned_interval);
                if (!next_interval.empty() && next_interval <= current_interval) {
                    target_interval = next_interval;
                    LOG_ERROR  << "版本 " << model_version << " 已扫描过 " << scanned_interval
                                     << "，本次扫描下一个时间窗口: " << target_interval;
                }
            }
        }

        LOG_ERROR  << "开始扫描时间窗口。model=" << model_name << ", date=" << current_date
                         << ", interval=" << target_interval << ", version=" << model_version;

        scan_version_window(model_name, model_version, current_date, target_interval, is_version_update,
                            is_first_rotate, is_read_obj);
    }
}// namespace ADStore