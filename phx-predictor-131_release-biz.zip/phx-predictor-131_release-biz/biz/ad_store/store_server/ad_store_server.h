#ifndef _AD_STORE_SERVER_H
#define _AD_STORE_SERVER_H
#include "core/core_context/prerank_context.h"
#include "core/core_server/core_server.h"
#include <vector>

namespace ADStore {

    struct BaseDirInfo;

    class ADStoreServer : public Core::CoreServer {
    public:
        ADStoreServer();
        ~ADStoreServer();
        virtual int initialize(int argc, char *argv[]);
        virtual int load_prerank() override;
        bool scan_version_window(const std::string &model_name, int model_version, const std::string &date,
                                 const std::string &interval, bool is_version_update, bool is_first_rotate,
                                 bool is_read_obj);
        void scan_current_window(const std::string &model_name, int model_version, const std::string &current_date,
                                 const std::string &current_interval, bool is_version_update, bool is_first_rotate,
                                 bool is_read_obj);

    private:
        std::shared_ptr<common::PeriodicTask> _offline_embedding_task;
        std::shared_ptr<common::PeriodicCronTask> _feature_report_start_task;
        std::shared_ptr<common::PeriodicCronTask> _feature_report_end_task;
        static void run_offline_item_embedding(const std::string &model_name, const std::string &dict_name,
                                               int32_t model_version,
                                               Core::OfflineItemEmbTaskReason offline_item_emb_reason,
                                               bool is_version_update, bool is_first_rotate);
        void feature_report_task_run();
        void start_offline_embedding_loader_task();
        std::shared_ptr<common::PeriodicTask> _offline_loader_task;
    };

}// namespace ADStore

#endif
