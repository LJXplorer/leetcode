#include "biz/recall/recall_server/recall_server.h"

Recall::RecallServer g_recall_server;
using namespace Core;

int main(int argc, char* argv[]){
    g_recall_server.start(argc, argv);
    return 0;
}