#include "recall_server.h"
#include "common/dictionary_reader/dictionary_reader.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/dump/dump_redis_manager/dump_redis_manager.h"
#include "hlframe/graph_manager.h"
#include "core/core_server/embedding_imp.h"
#include "core/core_services/dict/dict_mgr.h"
#include "core/core_services/recall/dict/emb_info_dict_manager.h"
#include "core/core_services/predict/utils/model_version.h"
#include <json2pb/pb_to_json.h>

using namespace Core;
namespace Recall {
    int RecallServer::initialize(int argc, char *argv[]) {
        config::ConfigServiceCfg cfg{.server_adder = ServerConfig::_server_adder,
                                     .auth_user_name = ServerConfig::_auth_user_name,
                                     .auth_passwd = ServerConfig::_auth_passwd,
                                     .name_space = ServerConfig::_name_space};
        
        if (Core::AdDictConfigMgr::instance().init(cfg, ServerConfig::_dict_group_id,
                                                       ServerConfig::_dict_data_id) != ERROR_SUCCESS) {
            std::cerr << "dict xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        }

        if (Core::Info::ModelInfoManager::instance().init(cfg, ServerConfig::_model_info_group_id,
                                                       ServerConfig::_model_info_data_id) != ERROR_SUCCESS) {
            std::cerr << "model_info xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        }else{
            std::cerr << "ModelInfoManager init success" << std::endl;
        }
        ModelVersion::instance().new_init();
        return 0;
    }

    int RecallServer::load_recall() {
        LOG_ERROR << "_recall_offline_embedding_graph_name = [" << ServerConfig::_recall_offline_embedding_graph_name
                << "]";

        if (!ServerConfig::_recall_offline_embedding_graph_name.empty()) {
            // 服务第一次启动时不做加载，仅在每天特定时间加载
            auto vector_recall_offline_item_emb = []() {
                EmbInfoDictManager::taskRunning.fetch_add(1);

                auto &model_info_manager = Core::Info::ModelInfoManager::instance();
                auto &channel_map = model_info_manager.get_model_infos();
                for (auto& ad_embedding_info_path : ServerConfig::_recall_ad_embedding_info_paths) {
                    int32_t max_retries = 5; // 读词典重试5次
                    honor::retrieval::annindex::EmbeddingInfoData embedding_info_data;
                    int ret = -1;
                    while (max_retries-- > 0) {
                        ret = EmbInfoDictManager::GetInstance().readDict(ad_embedding_info_path, &embedding_info_data);
                        if (ret == 0) break;
                        embedding_info_data.Clear();
                        if (max_retries != 0) {
                            sleep(60);
                            LOG_ERROR << "Retrying for reading ad_info_dict, " << max_retries << " times left";
                        }
                    }
                    if (ret != 0) {
                        LOG_ERROR << "Read ad_info_dict failed, ret:" << ret;
                        continue;
                    }

                    for (const auto &channel_pair: channel_map) {
                        if (channel_pair.second->_model_type !=Core::Info::ModelType::ITEM_EMBEDDING) {
                            continue;
                        }
                        EmbInfoDictManager::offlineItemEmbRun(ad_embedding_info_path, channel_pair.second, embedding_info_data);
                        sleep(60);
                    }
                }
                EmbInfoDictManager::taskRunning.fetch_sub(1);
            };
            _recall_offline_embedding_task =
                    common::g_backgroud_task_executor.PostPeriodicCron(0,30,-1, vector_recall_offline_item_emb);
            _recall_offline_embedding_task->Start();
        } else {
            LOG_ERROR<< "ServerConfig::_recall_offline_embedding_graph_name is empty!";
        }
        return 0;
    }

}// namespace Recall
