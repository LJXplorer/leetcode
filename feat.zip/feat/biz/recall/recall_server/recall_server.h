#pragma once
#include "core/core_server/core_server.h"
#include "ranking/embedding_info.pb.h"

namespace Recall {
    class RecallServer : public Core::CoreServer {
    public:
        RecallServer() = default;
        virtual ~RecallServer() = default;
        int load_recall() override;
        int initialize(int argc, char *argv[]) override;
    
    private:
        std::shared_ptr<common::PeriodicCronTask> _recall_offline_embedding_task;

    };
}// namespace Recall