#ifndef _AD_STORE_SERVER_H
#define _AD_STORE_SERVER_H
#include "core/core_server/core_server.h"

namespace Callback {

class CallbackServer : public Core::CoreServer {
public:
  CallbackServer();
  ~CallbackServer();
  virtual int initialize(int argc, char *argv[]);


};

} // namespace ADStore

#endif
