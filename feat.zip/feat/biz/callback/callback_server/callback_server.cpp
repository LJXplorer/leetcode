#include "callback_server.h"
#include "common/dictionary_reader/dictionary_reader.h"
#include "common/hicache/cache_helper.h"
#include "common/hikafka/kafka_helper.h"
#include "core/core_context/core_context.h"
#include "core/core_server/server_config/server_config.h"
#include "hlframe/graph_manager.h"
#include "hlframe/gtransport_manager.h"
#include "core/core_services/dump/feature_dump_retry_manager/featuredump_retry_manager.h"
#include "core/core_services/dump/dump_manager/dump_manager.h"
#include <chrono>
using namespace Core;

namespace Callback {

    CallbackServer::CallbackServer() {
    }

    CallbackServer::~CallbackServer() {
    }

    int CallbackServer::initialize(int argc, char *argv[]) {
        config::ConfigServiceCfg cfg{.server_adder = ServerConfig::_server_adder,
                                     .auth_user_name = ServerConfig::_auth_user_name,
                                     .auth_passwd = ServerConfig::_auth_passwd,
                                     .name_space = ServerConfig::_name_space};
        Core::DumpManager::instance().init();
        Core::FeatureDumpRetryManager::instance().init();
        return 0;
    }

}// namespace Callback
