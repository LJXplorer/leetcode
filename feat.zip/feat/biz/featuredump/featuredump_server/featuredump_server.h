#ifndef _AD_STORE_SERVER_H
#define _AD_STORE_SERVER_H
#include "core/core_server/core_server.h"

namespace Featuredump {

class FeaturedumpServer : public Core::CoreServer {
public:
  FeaturedumpServer();
  ~FeaturedumpServer();
  virtual int initialize(int argc, char *argv[]);

};

} // namespace ADStore

#endif
