#include "featuredump_server.h"
#include "core/core_context/core_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/dump/dump_redis_manager/dump_redis_manager.h"
#include "core/core_services/predict/utils/model_version.h"
#include "hlframe/graph_manager.h"
#include <bthread/types.h>
#include <chrono>
#include <vector>

using namespace Core;

namespace Featuredump {

    FeaturedumpServer::FeaturedumpServer() {
    }

    FeaturedumpServer::~FeaturedumpServer() {
    }

    int FeaturedumpServer::initialize(int argc, char *argv[]) {
        config::ConfigServiceCfg cfg{.server_adder = ServerConfig::_server_adder,
                                     .auth_user_name = ServerConfig::_auth_user_name,
                                     .auth_passwd = ServerConfig::_auth_passwd,
                                     .name_space = ServerConfig::_name_space};

        Core::DumpRedisManager::instance().init();
        return 0;
    }

}// namespace ADStore
