#include "biz/featuredump/featuredump_server/featuredump_server.h"
#include "core/core_context/core_context.h"
#include "core/core_server/core_server.h"
Featuredump::FeaturedumpServer g_store_server;
using namespace Core;
//CoreServer  g_store_server;

int main(int argc, char* argv[]){
    g_store_server.start(argc,argv);
    std::cout<<"test xml"<<std::endl;
    return 0;
}

