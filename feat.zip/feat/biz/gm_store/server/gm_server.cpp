#include "gm_server.h"
#include "common/hidict/dict_counters_provider.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/dict/dict_mgr.h"
#include "core/core_context/core_context.h"
#include "core/core_services/dict/metrics_flusher.h"
#include "core/core_services/predict/utils/model_version.h"
#include "core/core_services/dump/dump_redis_manager/dump_redis_manager.h"



using namespace Core;
static AdDict::MetricsFlusher g_flusher(60);
extern hidict::RealCounters g_real;
namespace GM {


    int GMServer::initialize(int argc, char *argv[]) {
        config::ConfigServiceCfg cfg{
            .server_adder = ServerConfig::_server_adder,
            .auth_user_name = ServerConfig::_auth_user_name,
            .auth_passwd = ServerConfig::_auth_passwd,
            .name_space = ServerConfig::_name_space
        };

        // 词典监控上报
        hidict::g_counters = &hidict::g_real;

        if (Core::AdDictConfigMgr::instance().init(cfg, ServerConfig::_dict_group_id, 
                                            ServerConfig::_dict_data_id) != ERROR_SUCCESS) {
            std::cerr << "dict xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        }

        g_flusher.start();

        if (Core::Info::ModelInfoManager::instance().init(cfg, ServerConfig::_model_info_group_id,
                                                          ServerConfig::_model_info_data_id) != ERROR_SUCCESS) {
            std::cerr << "model_info xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        } 

        if(ModelVersion::instance().new_init() != ERROR_SUCCESS) {
            std::cerr << "model version init error" << std::endl;
            return ERROR_SYS_NOT_FIND_SERVICE;
        }

        Core::DumpRedisManager::instance().init();
        
        if (ServerConfig::_feature_report_enable.load()) {
            feature_report_task_run();
        }
        return 0;
    }

    void GMServer::feature_report_task_run() {
         auto feature_report_start_task = []() {
            LOG_ERROR << "[feature_report] feature_report_start_task";
            if (ServerConfig::_feature_report_enable.load()) {
                ServerConfig::_feature_report_running.store(true);
            }
        };

        auto feature_report_end_task = []() {
            LOG_ERROR << "[feature_report] feature_report_end_task";
            ServerConfig::_feature_report_running.store(false);
        };

        int32_t start_h = ServerConfig::_feature_report_start_h;
        int32_t end_h = (start_h + ServerConfig::_feature_report_period_h) % 24;
        _feature_report_start_task =
                common::g_backgroud_task_executor.PostPeriodicCron(1, 0, start_h, feature_report_start_task);
        _feature_report_start_task->Start();

        _feature_report_end_task =
                common::g_backgroud_task_executor.PostPeriodicCron(0, 0, end_h, feature_report_end_task);
        _feature_report_end_task->Start();
    }


}