#ifndef _GM_SERVER_H
#define _GM_SERVER_H
#include "core/core_server/core_server.h"

namespace GM {

class GMServer : public Core::CoreServer {
public:
  GMServer() = default;
  ~GMServer() = default;
  virtual int initialize(int argc, char *argv[]);
private:
  std::shared_ptr<common::PeriodicCronTask> _feature_report_start_task;
  std::shared_ptr<common::PeriodicCronTask> _feature_report_end_task;
  void feature_report_task_run();

};

} // namespace ADStore

#endif
