#include "biz/gm_store/server/gm_server.h"
GM::GMServer g_store_server;
using namespace Core;
//CoreServer  g_store_server;

int main(int argc, char* argv[]){
    g_store_server.start(argc,argv);
    return 0;
}
