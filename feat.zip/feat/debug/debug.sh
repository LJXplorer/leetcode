SOURCE="../bazel-bin/biz/ad_store/StoreServer"
BUILD_OPTIONS="-c dbg --copt=-O0"

for arg in "$@";do
    case $arg in
        elm)
            BUILD_OPTIONS="${BUILD_OPTIONS} --define enable_latency_monitor=true"
            ;;
        edp)
            BUILD_OPTIONS="${BUILD_OPTIONS} --define enable_debug_print=true"
            ;;
    esac
done

bazel build //biz/ad_store:StoreServer ${BUILD_OPTIONS}

# 检查命令的执行结果
if [ $? -eq 0 ]; then
    echo "debug 编译成功"
    # 替换 可执行文件 到此文件夹
    ./clean.sh
    cp "$SOURCE" "."
    echo "文件 $SOURCE 已复制到 当前文件夹。"
else
    echo "debug 编译失败 不执行替换StoreServer"
fi
