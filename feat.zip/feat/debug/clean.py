import os
import shutil

# 定义要保留的文件和文件夹列表
keep_files_folders = ['model_input_config.yaml','fe_config.xml', 'conf', 'ad' , '.', '..']

# 获取当前目录下的所有文件和文件夹
all_items = os.listdir('.')

# 遍历所有文件和文件夹
for item in all_items:
    # 如果文件或文件夹不在保留列表中，则删除它
    if item not in keep_files_folders:
        # 如果是文件夹，则使用shutil.rmtree进行删除
        if os.path.isdir(item):
            shutil.rmtree(item)
        # 如果是文件，则使用os.remove进行删除
        else:
            # 检查文件扩展名，如果是.py或.sh结尾的文件则不删除
            if not (item.endswith('.py') or item.endswith('.sh')):
                os.remove(item)

print("Clean up completed.")