#include "core/core_services/start/start_service.h"
#include "common/hilog/log_helper.h"
#include "common/hilog/spdlog_helper.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/core_context.h"
#include "core/core_context/fe_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/predict/utils/model_version.h"
#include "core/core_services/prerank/truncation/include/Config.h"
#include "core/utils/defs.h"
#include "core/utils/error.h"
#include "core/utils/monitor_mgr.h"
#include "core/utils/prehandle_query.h"
#include "core/utils/util.h"
#include "hlframe/gtransport_manager.h"
#include "json2pb/json_to_pb.h"
#include "nlohmann/json.hpp"
#include "third_party/protobuf/include/google/protobuf/util/json_util.h"
#include <boost/algorithm/string.hpp>
#include <debug_utils.h>
#include <glog/logging.h>
#include <google/protobuf/util/json_util.h>
#include <memory>
#include <nlohmann/json.hpp>
#include <nlohmann/json_fwd.hpp>
#include <string>
#include <unordered_set>
using json = nlohmann::json;

namespace Core {

    SERVICE_REGISTER(StartService);
    void StartService::initialize(ConfigXmlPtr xml) {
        xml->attr<int32_t>("split_size", _split_size);
        initialize_xml(xml);
    }

    void StartService::initialize_xml(ConfigXmlPtr xml) {
    }

    void StartService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
        return;
    }

    int StartService::do_service(GraphContextPtr context) {
        LOG_INFO
                << "=====================phx StartService::do_service  start===================================="
                << std::endl;
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int32_t ret = 0;
        try {
            ctx->gen_log_head();
            ret = process(ctx);
        } catch (const std::exception &e) {
            LOG_ERROR << LOG_HEAD(ctx) << get_name() << "phx do service fail: " << ret << "," << e.what();
        }
        LOG_INFO << "=====================phx StartService::do_service  end===================================="
                        << std::endl;
        return ret;
    }

    int StartService::process(CoreContextPtr context) {
        google::protobuf::Arena *arena = context->get_context_arena();
        LOG_INFO << "in start_service, arena = [" << arena << "]; space used = [" << arena->SpaceUsed()
                        << "]; space allocated = [" << arena->SpaceAllocated() << "]\n";
        int ret = 0;
        BizLatency *lat = get_node_stat(context)->get_lat();
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);
            ret = check_data(context);
            if (ret != ERROR_SUCCESS && context->get_route() == 1) {
                LOG_ERROR << LOG_HEAD(context) << get_name() << " check_proto fail: " << ret;
                context->set_ex_req(true);
                return ret;
            }

            if (context->_task_type != PredictTaskType::kFeatureDump) {
                ret = parse_ab_param(context);
                if (ret != ERROR_SUCCESS) {
                    LOG_ERROR << LOG_HEAD(context) << get_name() << " parse_ab_param fail: " << ret;
                    return ret;
                }
            }
        }

        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_DESTROY);
            ret = convert_proto(context);
            if (ret != ERROR_SUCCESS) {
                LOG_ERROR << LOG_HEAD(context) << get_name() << " convert_proto fail: " << ret;
                context->set_ex_req(true);
                //report
                return ret;
            }
            const auto fs_ctx_req = context->get_rank_request();
            auto fs_ctx = context->get_fs_context();
            // 填充req_id & algo_trace_id
            fs_ctx->get_feature_dump()->mutable_req_id()->assign(context->get_req_id());
            fs_ctx->get_feature_dump()->mutable_algo_trace_id()->assign(fs_ctx_req->algotraceid());
            //填上下文特征
            genContextFeat(context, fs_ctx, fs_ctx_req);
        }
        return ERROR_SUCCESS;
    }

    int StartService::check_data(CoreContextPtr context) {
        auto rank_req = context->get_rank_request();

        if (rank_req->oaid().empty()) {
            context->_response_code = ERROR_BIZ_PROTO_OAID_EMPTY;
            return ERROR_BIZ_PROTO_OAID_EMPTY;
        }

        if (rank_req->reqid().empty()) {
            context->_response_code = ERROR_BIZ_PROTO_REQID_EMPTY;
            return ERROR_BIZ_PROTO_REQID_EMPTY;
        }

        if (rank_req->algotraceid().empty()) {
            context->_response_code = ERROR_BIZ_PROTO_ALGID_EMPTY;
            return ERROR_BIZ_PROTO_ALGID_EMPTY;
        }

        if (rank_req->predictorslotinfo().predictoriteminfos_size() == 0) {
            LOG_ERROR << "item_size is 0!!!!!!!!";
            context->_response_code = ERROR_BIZ_PROTO_ADS_EMPTY;
            return ERROR_BIZ_PROTO_ADS_EMPTY;
        }

        if (context->is_test_request()) {
            context->get_mutable_rank_request()->mutable_oaid()->assign(
                    "oaid" + std::to_string(get_hash(rank_req->oaid(), _TEN_THOUSAND)));
            if (!rank_req->query().empty()) {
                context->get_mutable_rank_request()->mutable_query()->assign(
                        "query" + std::to_string(get_hash(rank_req->query(), _ONE_THOUSAND)));
            }
        }

        return ERROR_SUCCESS;
    }

    int StartService::convert_proto(CoreContextPtr context) {
        auto rank_req = const_cast<phx::PredictorRequest *>(context->get_rank_request());
        int32_t item_size = rank_req->predictorslotinfo().predictoriteminfos_size();
        report(context, "req_item", item_size);
        if (item_size == 0) {
            return ERROR_BIZ_PROTO_ADS_EMPTY;
        }
        std::unordered_set<int64_t> check_set;
        std::unordered_set<int64_t> appid_set;

        for (int32_t i = 0; i < item_size; i++) {
            auto item = rank_req->mutable_predictorslotinfo()->mutable_predictoriteminfos(i);
            auto result = check_set.insert(item->creativeid());
            if (!result.second) {
                LOG_ERROR << LOG_HEAD(context) << get_name() << " repeated creativeId in request!!!";
                context->_response_code = ERROR_BIZ_REPEATED_MATERIALID;
                return ERROR_BIZ_REPEATED_MATERIALID;
            }
            auto *rsp_dump = context->_bak_response_dump->mutable_responsedumpdata()->Add();
            auto ads_pair = std::make_shared<AdsPair>(item, rsp_dump);
            context->_ads_map.insert({item->creativeid(), ads_pair});
            context->get_fs_context()->alloc_item_fea(item->creativeid());
            context->get_fs_context()->alloc_app_fea(item->appid());
            appid_set.insert(item->appid());
        }
        // 上报appid数量
        report(context, "appid_num", static_cast<int>(appid_set.size()));

        // 预分配user特征抽取的session
        {
            auto &fe_sessions_map = *context->get_fe_context()->MutableSessions();
            if (!context->_cpc_ctr_model_map.empty()) {
                for (const auto &[_, model_info]: context->_cpc_ctr_model_map) {
                    fe_sessions_map[ExperimentModelType::CPC_CTR].insert(
                            {model_info, FeSession(context->get_context_arena())});
                }
            }

            if (!context->_cpc_cvr_model_map.empty()) {
                for (const auto &[_, model_info]: context->_cpc_cvr_model_map) {
                    fe_sessions_map[ExperimentModelType::CPC_CVR].insert(
                            {model_info, FeSession(context->get_context_arena())});
                }
            }
            if (!context->_cpd_ctr_model_map.empty()) {
                for (const auto &[_, model_info]: context->_cpd_ctr_model_map) {
                    fe_sessions_map[ExperimentModelType::CPD_CTR].insert(
                            {model_info, FeSession(context->get_context_arena())});
                }
            }
            if (!context->_cpd_cvr_model_map.empty()) {
                for (const auto &[_, model_info]: context->_cpd_cvr_model_map) {
                    fe_sessions_map[ExperimentModelType::CPD_CVR].insert(
                            {model_info, FeSession(context->get_context_arena())});
                }
            }
            if (!context->_ltv_model_map.empty()) {
                for (const auto &[_, model_info]: context->_ltv_model_map) {
                    fe_sessions_map[ExperimentModelType::LTV].insert(
                            {model_info, FeSession(context->get_context_arena())});
                }
            }
        }

        LOG_WARNING << "phx request:" << rank_req->DebugString();
        auto prerank_context_ptr = context->get_prerank_context();
        if (!prerank_context_ptr->GetUsePrerank()) {
            // 不执行粗排
            return ERROR_SUCCESS;
        }

        init_prerank_items(context);
        if (prerank_context_ptr->GetConfigPtr()) {
            prerank_context_ptr->GetConfigPtr()->skip_prerank_ = !prerank_context_ptr->GetUsePrerank();
        }
        return ERROR_SUCCESS;
    }

    void StartService::genContextFeat(CoreContextPtr context, FSContextPtr fs_ctx, const phx::PredictorRequest *req) {
        auto feature_dump = fs_ctx->get_feature_dump();

        feature_dump->set_req_time(req->predictorslotinfo().predicttimestamp());

        feature_dump->mutable_context()->set_adunit_id(req->predictorslotinfo().slotid());

        feature_dump->mutable_context()->set_media_id(req->mediaid());

        if (!req->rtrequestfeature().activationflag().empty()) {
            try {
                int64_t activationFlagInt = std::stoll(req->rtrequestfeature().activationflag());
                feature_dump->mutable_context()->set_activation_flag(activationFlagInt);
            } catch (const std::exception &e) {
                LOG_WARNING << get_name() << "activationflag string parse to int has exception " << e.what();
            }
        }

        feature_dump->mutable_context()->mutable_launch_type()->assign(req->rtrequestfeature().launchtype());

        if (!req->rtrequestfeature().requestsceneout().empty()) {
            try {
                int64_t requestSceneOutInt = std::stoll(req->rtrequestfeature().requestsceneout());
                feature_dump->mutable_context()->set_request_scene_out(requestSceneOutInt);
            } catch (const std::exception &e) {
                LOG_WARNING << get_name() << "activationflag string parse to int has exception " << e.what();
            }
        }

        feature_dump->mutable_context()->set_is_preload(req->predictorslotinfo().rtadunitfeature().ispreload());

        feature_dump->mutable_context()->set_refresh_times(req->rtrequestfeature().refreshtimes());

        feature_dump->mutable_context()->set_shake_switch(req->rtrequestfeature().shakeswitch());

        feature_dump->mutable_context()->set_user_installed_appid(req->hostappid());

        feature_dump->mutable_context()->set_user_installed_pkg_size(req->rtrequestfeature().userinstalledpkgsize());

        feature_dump->mutable_context()->mutable_osv()->assign(req->deviceinfo().osv());

        feature_dump->mutable_context()->mutable_model()->assign(req->deviceinfo().model());

        feature_dump->mutable_context()->set_device_type(req->deviceinfo().devicetype());

        feature_dump->mutable_context()->set_screen_width(req->deviceinfo().screenwidth());

        feature_dump->mutable_context()->set_screen_height(req->deviceinfo().screenheight());

        feature_dump->mutable_context()->set_ppi(req->deviceinfo().ppi());

        feature_dump->mutable_context()->set_orientation(req->deviceinfo().orientation());

        feature_dump->mutable_context()->mutable_carrier()->assign(req->deviceinfo().carrier());

        feature_dump->mutable_context()->set_connection_type(req->deviceinfo().connectiontype());

        feature_dump->mutable_context()->mutable_ip()->assign(req->deviceinfo().ip());

        feature_dump->mutable_context()->mutable_query()->assign(req->query());

        if (req->rtrequestfeature().has_scene_id()) {
            feature_dump->mutable_context()->set_scene_id(req->rtrequestfeature().scene_id());
        }

        Utf8Processing::Utf8Handler handler;
        const std::string &result = handler.pre_handled_query(req->query());
        context->set_handled_query(result);
        feature_dump->mutable_handled_query()->assign(result);

        if (!req->deviceinfo().geo().city().empty()) {
            try {
                int64_t cityInt = std::stoll(req->deviceinfo().geo().city());
                feature_dump->mutable_context()->set_city_code(cityInt);
            } catch (const std::exception &e) {
                LOG_WARNING << get_name() << "activationflag string parse to int has exception " << e.what();
            }
        }

        feature_dump->mutable_context()->set_trigger_scene(req->triggerscene());

        switch (req->predictorslotinfo().route()) {
            case 1: {
                feature_dump->mutable_context()->mutable_traffic_id()->assign("cloud");
                break;
            }
            case 2: {
                feature_dump->mutable_context()->mutable_traffic_id()->assign("byte");
                break;
            }
            case 3: {
                feature_dump->mutable_context()->mutable_traffic_id()->assign("it");
                break;
            }
            case 4: {
                feature_dump->mutable_context()->mutable_traffic_id()->assign("s1");
                break;
            }
            default: {
                feature_dump->mutable_context()->mutable_traffic_id()->assign("默认值");
                break;
            }
        }

        std::string expIds_str;
        for (auto &algo_exp: req->algoexperiments()) {
            expIds_str.append(algo_exp.targetedpolicy());
            expIds_str.append(",");
        }
        if (!expIds_str.empty()) {
            expIds_str.pop_back();
        }
        feature_dump->mutable_context()->mutable_exp_ids()->assign(expIds_str);

        feature_dump->mutable_context()->mutable_oaid()->assign(req->oaid());

        feature_dump->mutable_context()->set_timestamp(req->deviceinfo().timestamp());

        feature_dump->mutable_context()->set_media_type(req->mediatype());

        feature_dump->mutable_context()->mutable_magicui_version()->assign(req->deviceinfo().magicuiversion());

        if (!req->rtrequestfeature().honorboardfeedlist().empty()) {
            try {
                std::string json_str = req->rtrequestfeature().honorboardfeedlist();
                google::protobuf::util::JsonParseOptions options;
                auto status = google::protobuf::util::JsonStringToMessage(
                        json_str, feature_dump->mutable_context()->mutable_info_flow_context(), options);
                if (!status.ok()) {
                    LOG_ERROR << "parse info_flow_context feat failed: "
                                     << req->rtrequestfeature().honorboardfeedlist().c_str();
                }

            } catch (const std::exception &e) {
                LOG_ERROR << "parse info_flow_context feat failed: "
                                 << req->rtrequestfeature().honorboardfeedlist().c_str();
            }
        }

        if (!req->rtrequestfeature().trackext().empty()) {
            butil::rapidjson::Document doc;
            doc.Parse(req->rtrequestfeature().trackext().c_str());
            if (!doc.HasParseError() && doc.IsObject()) {
                try {
                    addTrackExtFeat(doc, feature_dump, "sessionId");
                    addTrackExtFeat(doc, feature_dump, "detailType");
                    addTrackExtFeat(doc, feature_dump, "visitSource");
                    addTrackExtFeat(doc, feature_dump, "sourcePackageName");
                } catch (const std::exception &e) {
                    LOG_ERROR << "add track_ext feat has exception " << e.what();
                }
            }
        }

        // 体验新增上下文特征
        feature_dump->mutable_context()->mutable_assid()->assign(req->predictorslotinfo().assid());      
        feature_dump->mutable_context()->set_pagesceneno(req->predictorslotinfo().pagesceneno());
    }

    void StartService::addTrackExtFeat(const butil::rapidjson::Document &doc, phx::FeRequest *feature_dump,
                                       const std::string &rtFeatureName) {
        if (doc.HasMember(rtFeatureName.c_str())) {
            const butil::rapidjson::Value &value = doc[rtFeatureName.c_str()];
            if (rtFeatureName == "sessionId") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0)
                    feature_dump->mutable_context()->mutable_session_id()->assign(value.GetString());
            } else if (rtFeatureName == "detailType") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0) {
                    try {
                        feature_dump->mutable_context()->set_detail_type(std::stoi(value.GetString()));
                    } catch (const std::exception &e) {
                        LOG_WARNING << get_name() << "detailType string parse to int has exception " << e.what();
                    }
                }
            } else if (rtFeatureName == "visitSource") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0)
                    feature_dump->mutable_context()->mutable_visit_source()->assign(value.GetString());
            } else if (rtFeatureName == "sourcePackageName") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0)
                    feature_dump->mutable_context()->mutable_source_package_name()->assign(value.GetString());
            }
        }
    }

    template<typename MapType>

    void process_models(const nlohmann::json &json_data, Core::ExperimentModelType model_type,
                        Core::CoreContext &context, MapType &model_map) {
        static const std::unordered_map<Core::ExperimentModelType, std::string_view> KEY_MAP = {
                {ExperimentModelType::CPC_CTR, "ctr"},
                {ExperimentModelType::CPD_CTR, "dtr"},
                {ExperimentModelType::CPC_CVR, "cvr"},
                {ExperimentModelType::CPD_CVR, "cpd_cvr"},
                {ExperimentModelType::LTV, "ltv"}};

        const auto &key = KEY_MAP.at(model_type);
        if (!json_data.contains(key))
            return;

        //entry e.g. [{\"conv_type\":[1,2,3,4,12,13,18],\"model\":\"cvr_cpc_fea764_v1_100000_0815_zwj\",\"adjust_file\":\"/models/adjust_files_v2/cvr_cpc_fea764_v1_100000_0815_zwj\"}]
        for (const auto &entry: json_data[key]) {
            try {
                if (!entry.contains("model") || !entry["model"].is_string() ||
                    entry["model"].get<std::string>().empty()) {
                    LOG_ERROR << "Invalid or empty model field: " << static_cast<int>(model_type);
                    continue;
                }
                auto model = std::make_unique<Core::ExperimentModelInfo>(entry, model_type);

                model->_model_info = Info::ModelInfoManager::instance().get_model_info(model->_model_name);
                if (model->_model_info == nullptr || model->_model_info->get_config_info_ptr() == nullptr) {
                    LOG_ERROR << "do not find model, name = [" << model->_model_name << "]";
                    MonitorMgr::common_report_model(model->_model_name, context.GetUploadSlotName(),
                                                    std::to_string(context.get_algo_scene_id()), "default", -1,
                                                    "model_not_found", 1);
                    continue;
                }
                //_supported_conv_types 实验参数里带的
                for (int conv_type: model->_supported_conv_types) {
                    if (model_map.find(conv_type) != model_map.end()) {
                        LOG_ERROR << "ConvType " << conv_type << " has been cover";
                    }
                    model_map[conv_type] = model.get();
                }
                context._model_info_vec.push_back(std::move(model));
            } catch (const std::exception &e) {
                LOG_ERROR << "model_info init fail: " << e.what();
            }
        }
    }

    int StartService::parse_ab_param(CoreContextPtr context) {
        const auto *rank_req = context->get_rank_request();
        context->reserve_model_capacity(rank_req->algoexperiments_size() * 4);

        for (const auto &experiment: rank_req->algoexperiments()) {
            // 参数提取
            std::unordered_map<std::string, std::string> param_map;
            for (const auto &param: experiment.expparam()) {
                param_map.emplace(param.key(), param.val());
            }
            try {
                auto ctr_it = param_map.find("ctr_models");
                auto cvr_it = param_map.find("cvr_models");
                auto prerank_it = param_map.find("prerank");
                auto sample_ratio_it = param_map.find("sample_ratio");
                auto is_appid_dim_it = param_map.find("is_appid_dimension");
                auto ltv_it = param_map.find("ltv_models");
                if (ctr_it == param_map.end() && cvr_it == param_map.end() && prerank_it == param_map.end() &&
                    ltv_it == param_map.end()) {
                    continue;
                }

                // ctr
                if (ctr_it != param_map.end() && !ctr_it->second.empty()) {
                    auto ctr_models = nlohmann::json::parse(ctr_it->second);
                    process_models(ctr_models, Core::ExperimentModelType::CPC_CTR, *context,
                                   context->_cpc_ctr_model_map);
                    process_models(ctr_models, Core::ExperimentModelType::CPD_CTR, *context,
                                   context->_cpd_ctr_model_map);
                    if (sample_ratio_it != param_map.end()) {
                        try {
                            if (!sample_ratio_it->second.empty()) {
                                context->_ctr_sample_ratio = std::stoi(sample_ratio_it->second);
                            }
                        } catch (const std::exception &e) {
                            LOG_WARNING
                                    << get_name() << "ctr sample_ratio string parse to int has exception " << e.what();
                        }
                    }
                    if (is_appid_dim_it != param_map.end()) {
                        if(is_appid_dim_it->second == "true"){
                            context->_appid_dim_enabled = true;
                        }
                    }
                    context->_ctr_policy = experiment.targetedpolicy();
                }

                //cvr
                if (cvr_it != param_map.end() && !cvr_it->second.empty()) {
                    auto cvr_models = nlohmann::json::parse(cvr_it->second);
                    process_models(cvr_models, Core::ExperimentModelType::CPC_CVR, *context,
                                   context->_cpc_cvr_model_map);
                    process_models(cvr_models, Core::ExperimentModelType::CPD_CVR, *context,
                                   context->_cpd_cvr_model_map);
                    if (sample_ratio_it != param_map.end()) {
                        try {
                            if (!sample_ratio_it->second.empty()) {
                                context->_cvr_sample_ratio = std::stoi(sample_ratio_it->second);
                            }
                        } catch (const std::exception &e) {
                            LOG_WARNING
                                    << get_name() << "cvr sample_ratio string parse to int has exception " << e.what();
                        }
                    }
                    if (is_appid_dim_it != param_map.end()) {
                        if(is_appid_dim_it->second == "true"){
                            context->_appid_dim_enabled = true;
                        }
                    }
                    context->_cvr_policy = experiment.targetedpolicy();
                }

                //ltv
                if (ltv_it != param_map.end() && !ltv_it->second.empty()) {
                    auto ltv_models = nlohmann::json::parse(ltv_it->second);
                    process_models(ltv_models, Core::ExperimentModelType::LTV, *context, context->_ltv_model_map);

                    if (sample_ratio_it != param_map.end()) {
                        try {
                            if (!sample_ratio_it->second.empty()) {
                                context->_ltv_sample_ratio = std::stoi(sample_ratio_it->second);
                            }
                        } catch (const std::exception &e) {
                            LOG_WARNING
                                    << get_name() << "cvr sample_ratio string parse to int has exception " << e.what();
                        }
                    }
                    context->_ltv_policy = experiment.targetedpolicy();
                }

                // prerank
                if (prerank_it != param_map.end() && !prerank_it->second.empty()) {
                    auto prerank_param = nlohmann::json::parse(prerank_it->second);
                    process_prerank(context, prerank_param);
                    if (sample_ratio_it != param_map.end()) {
                        try {
                            if (!sample_ratio_it->second.empty()) {
                                context->_prerank_sample_ratio = std::stoi(sample_ratio_it->second);
                            }
                        } catch (const std::exception &e) {
                            LOG_WARNING << get_name()
                                               << "prerank sample_ratio string parse to int has exception " << e.what();
                        }
                    }
                }
            } catch (const nlohmann::json::exception &e) {

                LOG_ERROR << "to json failed: ";

                return ERROR_SUCCESS;
            }
        }

        return ERROR_SUCCESS;
    }

    void StartService::process_prerank(CoreContextPtr context, nlohmann::json &prerank_exp_json) {
        auto prerank_context_ptr = context->get_prerank_context();
        prerank_context_ptr->SetUsePrerank(false);
        std::shared_ptr<prerank::Config> config_ptr = std::make_shared<prerank::Config>();

        try {
            // 1. 解析 ltr_default_params
            if (!prerank_exp_json.contains("ltr_default_params")) {
                LOG_INFO << "Missing ltr_default_params";
                return;
            }
            const auto &ltr_params = prerank_exp_json["ltr_default_params"];

            if (!ltr_params.contains("prerank_ltr_item_model_name") ||
                !ltr_params.contains("prerank_ltr_user_model_name")) {
                LOG_INFO << "Missing item or user model name in ltr_default_params";
                return;
            }

            const std::string &item_model_name = ltr_params["prerank_ltr_item_model_name"].get<std::string>();
            const std::string &user_model_name = ltr_params["prerank_ltr_user_model_name"].get<std::string>();

            if (item_model_name.empty() || user_model_name.empty()) {
                LOG_INFO << "Item or user model name is empty in ltr_default_params";
                return;
            }

            auto item_model_info = Info::ModelInfoManager::instance().get_model_info(item_model_name);
            if (item_model_info == nullptr || item_model_info->get_config_info_ptr() == nullptr) {
                LOG_ERROR << LOG_HEAD(context) << item_model_name << " is invalid prerank model";
                return;
            }
            auto user_model_info = Info::ModelInfoManager::instance().get_model_info(user_model_name);
            if (user_model_info == nullptr || user_model_info->get_config_info_ptr() == nullptr) {
                LOG_ERROR << LOG_HEAD(context) << user_model_name << " is invalid prerank model";
                return;
            }

            // 赋值给上下文
            prerank_context_ptr->item_emb_model_name_ = item_model_name;
            prerank_context_ptr->user_emb_model_name_ = user_model_name;

            LOG_INFO << "Parsed ltr_default_params: item_emb_model_name_ = "
                            << prerank_context_ptr->item_emb_model_name_
                            << ", user_emb_model_name_ = " << prerank_context_ptr->user_emb_model_name_;

            // 2. 处理 prerank_trunc_media_ids 和 prerank_force
            bool prerank_force = false;
            if (prerank_exp_json.contains("prerank_force")) {
                prerank_force = prerank_exp_json["prerank_force"].get<bool>();
                LOG_INFO << "Parsed prerank_force: " << prerank_force;
            }

            if (prerank_exp_json.contains("prerank_trunc_black_media_ids")) {
                const auto &val = prerank_exp_json["prerank_trunc_black_media_ids"];
                if (val.is_string()) {
                    std::string not_allowed_media_ids_str = val.get<std::string>();
                    int64_t media_id = context->get_media_id();

                    LOG_INFO << "Parsed prerank_trunc_media_ids: " << not_allowed_media_ids_str;

                    if (prerank_force) {
                        prerank_context_ptr->SetUsePrerank(true);
                        LOG_INFO << "prerank_force is true, setting UsePrerank to true";
                    } else if (not_allowed_media_ids_str == "all") {
                        LOG_INFO << "Media id blocked by 'all' in prerank_trunc_media_ids";
                        return;
                    } else {
                        auto split = [](const std::string &s, char delimiter) -> std::vector<std::string> {
                            std::vector<std::string> tokens;
                            size_t start = 0;
                            while (start < s.size()) {
                                size_t end = s.find(delimiter, start);
                                if (end == std::string::npos) {
                                    end = s.size();
                                }
                                tokens.emplace_back(s.substr(start, end - start));
                                start = end + 1;
                            }
                            return tokens;
                        };
                        auto tokens = split(not_allowed_media_ids_str, ',');
                        std::unordered_set<int64_t> not_allowed_media_ids_set;
                        for (const auto &item: tokens) {
                            try {
                                not_allowed_media_ids_set.insert(std::stoll(item));
                            } catch (...) {
                                LOG_WARNING << "Invalid media id in prerank_trunc_media_ids: " << item;
                            }
                        }
                        if (not_allowed_media_ids_set.count(media_id) > 0) {
                            LOG_INFO << "Media id " << media_id << " blocked by prerank_trunc_media_ids";
                            return;
                        }
                        prerank_context_ptr->SetUsePrerank(true);
                        LOG_INFO << "Media id " << media_id << " not blocked, setting UsePrerank to true";
                    }
                }
            } else {
                // 未配置字段，默认允许
                prerank_context_ptr->SetUsePrerank(true);
                LOG_INFO << "prerank_trunc_media_ids not configured, setting UsePrerank to true";
            }

            // 3. prerank配置解析
            if (prerank_context_ptr->GetUsePrerank()) {
                int64_t media_id = context->get_media_id();
                int64_t slot_id = context->get_slot_id();

                LOG_INFO << "config_ptr->parse start";
                if (!config_ptr->parse(prerank_exp_json, media_id, slot_id, 1, 0)) {
                    LOG_INFO << "config_ptr->parse failed";
                    prerank_context_ptr->SetUsePrerank(false);
                }
                LOG_INFO << "config_ptr->parse end";
            }
            
            // 3.1 处理动态耗时
            if(prerank_context_ptr->GetUsePrerank()) {
                int truncReserve = context->get_rank_request()->predictorslotinfo().truncreserve();
                config_ptr->trunc_reserve(truncReserve);
            }

            // 4. 粗排截断配置判断
            if (context->get_rank_request()->predictorslotinfo().predictoriteminfos_size() <=
                        config_ptr->prerank_trunc_count &&
                !config_ptr->prerank_force) {
                LOG_INFO << "jump prerank due to item count <= prerank_trunc_count and no prerank_force";
                prerank_context_ptr->SetUsePrerank(false);
            }

        } catch (const nlohmann::json::parse_error &e) {
            prerank_context_ptr->SetUsePrerank(false);
            LOG_ERROR << "json parse error : " << e.what();
        } catch (const std::exception &e) {
            prerank_context_ptr->SetUsePrerank(false);
            LOG_ERROR << "exception caught : " << e.what();
        }

        config_ptr->skip_prerank_ = !prerank_context_ptr->GetUsePrerank();
        prerank_context_ptr->SetConfigPtr(config_ptr);

        LOG_INFO << "prerank_context_ptr->GetUsePrerank(): " << prerank_context_ptr->GetUsePrerank()
                        << "config_ptr->skip_prerank_" << config_ptr->skip_prerank_;
    }

    void StartService::init_prerank_items(CoreContextPtr context) {
        if (!context->get_prerank_context()->GetUsePrerank()) {
            return;
        }
        const auto &user_emb_model_name = context->get_prerank_context()->user_emb_model_name_;

        auto &model_info_manager = Core::Info::ModelInfoManager::instance();
        auto &channel_map = model_info_manager.get_model_infos();
        if (auto iter = channel_map.find(context->get_prerank_context()->item_emb_model_name_);
            iter != channel_map.cend()) {
            if (iter->second->_dict_name.empty()) {
                LOG_INFO << "The _dict_name is empty.";
                context->get_prerank_context()->SetUsePrerank(false);
                return;
            }
            context->get_prerank_context()->item_dict_name_ = iter->second->_dict_name;
        } else {
            LOG_ERROR << LOG_HEAD(context) << get_name()
                             << " not find model :" << context->get_prerank_context()->item_emb_model_name_;
            MonitorMgr::common_report_model(context->get_prerank_context()->item_emb_model_name_,
                                            context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()),
                                            "default", -1, "model_not_found", 1);
            context->get_prerank_context()->SetUsePrerank(false);
            return;
        }

        context->get_prerank_context()->max_common_version_ =
                ModelVersion::instance().get_max_common_version(context->get_prerank_context()->item_emb_model_name_,
                                                                context->get_prerank_context()->user_emb_model_name_);
        LOG_INFO << "ADStartService::init_prerank_items end";
    }

}// namespace Core
