#include "biz/prerank/prerank_offline_server/prerank_offline_server.h"

PrerankOffline::PrerankOfflineServer g_prerank_offline_server;
using namespace Core;

int main(int argc, char* argv[]){
    g_prerank_offline_server.start(argc, argv);
    return 0;
}