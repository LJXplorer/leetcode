#include "prerank_offline_server.h"
#include "common/hidict/dict_counters_provider.h"
#include "core/core_context/core_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/dict/dict_mgr.h"
#include "core/core_services/dict/metrics_flusher.h"
#include "core/core_services/dump/dump_redis_manager/dump_redis_manager.h"
#include "core/core_services/predict/utils/model_version.h"
#include "core/core_services/prerank/embedding_cache/feature_cache.h"
#include "hlframe/graph_manager.h"
#include "model_semaphore_manager.h"
#include <bthread/types.h>
#include <chrono>
#include <debug_utils.h>
#include <memory>
#include <string>
#include <vector>

using namespace Core;
static AdDict::MetricsFlusher g_flusher(60);
extern hidict::RealCounters g_real;

namespace PrerankOffline {

    PrerankOfflineServer::PrerankOfflineServer() {
    }

    PrerankOfflineServer::~PrerankOfflineServer() {
        g_flusher.stop();
    }

    int PrerankOfflineServer::initialize(int argc, char *argv[]) {
        config::ConfigServiceCfg cfg{.server_adder = ServerConfig::_server_adder,
                                     .auth_user_name = ServerConfig::_auth_user_name,
                                     .auth_passwd = ServerConfig::_auth_passwd,
                                     .name_space = ServerConfig::_name_space};
        ModelSemaphoreManager::Init(ServerConfig::_max_models);

        // 在线时才会创建
        hidict::g_counters = &hidict::g_real;

        if (Core::AdDictConfigMgr::instance().init(cfg, ServerConfig::_dict_group_id, ServerConfig::_dict_data_id) !=
            ERROR_SUCCESS) {
            std::cerr << "dict xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        }

        // 这里已经词典计数器已经注册完成
        g_flusher.start();

        if (Core::Info::ModelInfoManager::instance().init(cfg, ServerConfig::_model_info_group_id,
                                                          ServerConfig::_model_info_data_id) != ERROR_SUCCESS) {
            std::cerr << "model_info xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        } else {
            std::cerr << "ModelInfoManager init success" << std::endl;
        }

        ModelVersion::instance().new_init();

        Core::DumpRedisManager::instance().init();
        if (ServerConfig::_feature_report_enable.load()) {
            feature_report_task_run();
        }
        return 0;
    }

    void PrerankOfflineServer::submit_model_task(const std::string &model_name, const std::string &dict_name,
                                                 int bak_version, OfflineItemEmbTaskReason type, bool is_version_update,
                                                 bool is_first_rotate) {
        HILOG_APP(ERROR) << "Submitting model task: " << model_name << ", dict: " << dict_name
                        << ", bak_version: " << bak_version;

        auto sema = ModelSemaphoreManager::GetSemaphore();
        if (!sema) {
            HILOG_APP(ERROR) << "Failed to get semaphore for model task: " << model_name;
            return;
        }

        int available_before = sema->available();
        int running_tasks_before = ServerConfig::_max_models - available_before;

        HILOG_APP(ERROR) << "Before acquire: max_count=" << ServerConfig::_max_models
                        << ", available=" << available_before << ", running_tasks=" << running_tasks_before;

        sema->acquire();

        int available_after = sema->available();
        int running_tasks_after = ServerConfig::_max_models - available_after;

        HILOG_APP(ERROR) << "Semaphore acquired for model task: " << model_name
                        << ", max_count=" << ServerConfig::_max_models << ", available=" << available_after
                        << ", running_tasks=" << running_tasks_after << ", starting thread";

        std::thread([=]() {
            try {
                run_offline_item_embedding(model_name, dict_name, bak_version, type, is_version_update,
                                           is_first_rotate);
                HILOG_APP(ERROR) << "Model task completed successfully: " << model_name;
            } catch (const std::exception &e) {
                HILOG_APP(ERROR) << "Error running model " << model_name << ": " << e.what();
            }
        }).detach();

        HILOG_APP(ERROR) << "Thread detached for model task: " << model_name;
    }

    int PrerankOfflineServer::load_prerank() {
        HILOG_APP(INFO) << "Loading prerank models, graph name: "
                        << ServerConfig::_prerank_offline_embedding_graph_name;

        if (ServerConfig::_prerank_offline_embedding_graph_name.empty()) {
            HILOG_APP(ERROR) << "Prerank offline embedding graph name is empty!";
            return -1;
        }

        auto &model_info_manager = Core::Info::ModelInfoManager::instance();
        auto &channel_map = model_info_manager.get_model_infos();
        std::vector<std::string> model_names;

        // 记录每个模型的版本
        static std::unordered_map<std::string, int32_t> last_versions;
        // 记录每个模型的上次触发时间
        static std::unordered_map<std::string, std::chrono::steady_clock::time_point> last_trigger_times;

        // 初始加载
        for (const auto &channel_pair: channel_map) {
            const std::string &model_name = channel_pair.first;
            if (channel_pair.second->_model_type != Core::Info::ModelType::ITEM_EMBEDDING) {
                continue;
            }
            model_names.push_back(model_name);
            auto [cur_version, bak_version] = ModelVersion::instance().get_available_model_versions(model_name);
            HILOG_APP(INFO) << "cur_version " << cur_version << " bak_version " << bak_version;
            last_versions[model_name] = cur_version;
            last_trigger_times[model_name] = std::chrono::steady_clock::now();
            bool is_version_update = true;
            bool is_read_obj = false;
            if (cur_version > 1 && bak_version >= 1) {
                HILOG_APP(ERROR) << "need to run offline embedding for model: " << model_name
                                 << ", version: " << cur_version;
                ServerConfig::_offline_item_emb_cnt.fetch_add(1);
                prerank::FeatureCache::get_instance().pre_allocate(model_name, bak_version, false);
                submit_model_task(model_name, channel_pair.second->_dict_name, bak_version, Core::kInitialLaunch,
                                  is_version_update, true);
                is_version_update = false;
                is_read_obj = true;
            }
            ServerConfig::_offline_item_emb_cnt.fetch_add(1);
            prerank::FeatureCache::get_instance().pre_allocate(model_name, cur_version, is_read_obj);
            submit_model_task(model_name, channel_pair.second->_dict_name, cur_version, Core::kInitialLaunch,
                              is_version_update, false);
        }

        while (true) {
            if (ServerConfig::_offline_item_emb_cnt.load() < 1) {
                ServerConfig::_first_load_offline_item_emb = false;
                break;
            }
            sleep(1);
        }

        HILOG_APP(INFO) << "Models participating in offline item embedding: " << debug::printer::ToString(model_names);

        // 定时检查任务（每个模型单独计时）
        auto offline_item_emb_task = [&]() mutable {
            auto &model_info_manager = Core::Info::ModelInfoManager::instance();
            auto &channel_map = model_info_manager.get_model_infos();

            for (const auto &channel_pair: channel_map) {
                if (channel_pair.second->_model_type != Core::Info::ModelType::ITEM_EMBEDDING) {
                    continue;
                }

                const std::string &model_name = channel_pair.first;
                int32_t current_version = ModelVersion::instance().get_model_version(model_name);

                bool triggered = false;

                // 版本更新立即触发
                if (current_version != last_versions[model_name]) {
                    prerank::FeatureCache::get_instance().pre_allocate(model_name, current_version, false);

                    HILOG_APP(ERROR) << "Model " << model_name << " version updated: " << last_versions[model_name]
                                     << " -> " << current_version;
                    submit_model_task(model_name, channel_pair.second->_dict_name, current_version, Core::kPeriodicTask,
                                      true, false);
                    last_versions[model_name] = current_version;
                    last_trigger_times[model_name] = std::chrono::steady_clock::now();
                    triggered = true;
                }

                // 按模型单独的兜底时间触发
                auto now = std::chrono::steady_clock::now();
                if (!triggered &&
                    std::chrono::duration_cast<std::chrono::minutes>(now - last_trigger_times[model_name]).count() >=
                            ServerConfig::_prerank_offline_embedding_scheduled) {

                    HILOG_APP(ERROR) << ServerConfig::_prerank_offline_embedding_scheduled
                                     << " minutes passed since last run for " << model_name
                                     << ", triggering offline embedding";
                    bool is_version_update = false;

                    if (current_version != last_versions[model_name]) {
                        is_version_update = true;
                        prerank::FeatureCache::get_instance().pre_allocate(model_name, current_version, false);
                        last_versions[model_name] = current_version;
                    }
                    submit_model_task(model_name, channel_pair.second->_dict_name, current_version, Core::kPeriodicTask,
                                      is_version_update, false);
                    last_trigger_times[model_name] = now;
                }
            }
        };

        // 定时执行
        _offline_embedding_task = common::g_backgroud_task_executor.PostPeriodic(
                std::chrono::minutes(ServerConfig::_prerank_offline_embedding_interval), offline_item_emb_task);
        _offline_embedding_task->Start();

        return 0;
    }

    void PrerankOfflineServer::run_offline_item_embedding(const std::string &model_name, const std::string &dict_name,
                                                          int32_t model_version, OfflineItemEmbTaskReason reason,
                                                          bool is_version_update, bool is_first_rotate) {

        auto graph = GraphManager::instance().get_graph(ServerConfig::_prerank_offline_embedding_graph_name);
        if (graph == nullptr) {
            HILOG_APP(ERROR) << "Item offline embedding service graph not found! graph name: offline_item_emb";
            return;
        }

        HILOG_APP(ERROR) << "Running offline item embedding, dict_name: " << dict_name << ", model_name: " << model_name
                         << ", model_version: " << model_version;

        phx::PredictorRequest *fake_predict_request = new phx::PredictorRequest();
        phx::PredictorResponse *fake_predict_response = new phx::PredictorResponse();
        CoreContextPtr core_context = std::make_shared<CoreContext>();
        int64_t timestamp = gettimeofday_ms();
        fake_predict_request->mutable_reqid()->assign(std::to_string(timestamp));// 离线校验点上报，请求id填充时间戳
        core_context->make_request_context(nullptr, fake_predict_request, fake_predict_response, nullptr);
        core_context->_need_relase_rank_req_manually = true;
        core_context->_need_release_rank_res_manually = true;
        core_context->_offline_item_emb_model = model_name;
        core_context->_offline_item_emb_version = model_version;
        core_context->_is_version_update = is_version_update;
        core_context->_is_first_rotate = is_first_rotate;
        core_context->init();
        core_context->get_prerank_context()->item_dict_name_ = dict_name;
        core_context->get_prerank_context()->offline_item_emb_reason_ = reason;
        core_context->get_prerank_context()->set_offline_embedding_dump(true);

        graph->run(core_context, nullptr, fake_predict_request, fake_predict_response, nullptr);
    }
    void PrerankOfflineServer::feature_report_task_run() {
        auto feature_report_start_task = []() {
            HILOG_APP(ERROR) << "[feature_report] feature_report_start_task";
            if (ServerConfig::_feature_report_enable.load()) {
                ServerConfig::_feature_report_running.store(true);
            }
        };

        auto feature_report_end_task = []() {
            HILOG_APP(ERROR) << "[feature_report] feature_report_end_task";
            ServerConfig::_feature_report_running.store(false);
        };

        int32_t start_h = ServerConfig::_feature_report_start_h;
        int32_t end_h = (start_h + ServerConfig::_feature_report_period_h) % 24;
        _feature_report_start_task =
                common::g_backgroud_task_executor.PostPeriodicCron(1, 0, start_h, feature_report_start_task);
        _feature_report_start_task->Start();

        _feature_report_end_task =
                common::g_backgroud_task_executor.PostPeriodicCron(0, 0, end_h, feature_report_end_task);
        _feature_report_end_task->Start();
    }

}// namespace PrerankOffline