#ifndef _AD_STORE_SERVER_H
#define _AD_STORE_SERVER_H
#include "common/comm/counting_semaphore.h"
#include "core/core_context/prerank_context.h"
#include "core/core_server/core_server.h"
namespace PrerankOffline {

    class PrerankOfflineServer : public Core::CoreServer {
    public:
        PrerankOfflineServer();
        ~PrerankOfflineServer();
        virtual int initialize(int argc, char *argv[]);
        virtual int load_prerank() override;

    private:
        std::shared_ptr<common::PeriodicTask> _offline_embedding_task;
        std::shared_ptr<common::PeriodicCronTask> _feature_report_start_task;
        std::shared_ptr<common::PeriodicCronTask> _feature_report_end_task;
        static void run_offline_item_embedding(const std::string &model_name, const std::string &dict_name,
                                               int32_t model_version,
                                               Core::OfflineItemEmbTaskReason offline_item_emb_reason,
                                               bool is_version_update, bool is_first_rotate);
        void feature_report_task_run();
        void submit_model_task(const std::string &model_name, const std::string &dict_name, int bak_version,
                               Core::OfflineItemEmbTaskReason reason, bool is_version_update, bool is_first_rotate);
    };

}// namespace ADStore

#endif
