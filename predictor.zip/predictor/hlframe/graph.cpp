#include "hlframe/graph.h"

namespace HLframe {
    int Graph::init(Node* node, const std::string& name) {
        if (!name.empty()) {
            this->_name = name;
        }
        _root_node = node;
        _all_nodes.clear();
        auto cur_node = _root_node;
        std::queue<Node*> q;
        q.push(cur_node);
        std::set<Node*> set;
        while(!q.empty()) {
            cur_node = q.front();
            q.pop();
            if (set.find(cur_node) == set.end()) {
                set.insert(cur_node);
                _all_nodes.push_back(cur_node);
            }
            for (auto node : cur_node->get_output_nodes()) {
                q.push(node);
            }
        }

        HILOG_APP(INFO) <<"graph: " << _name <<  " all_nodes size: " << _all_nodes.size();
        std::cout <<"graph: " << _name <<  " all_nodes size: " << _all_nodes.size() << endl;
        return 0;
    }

}//end HLframe
