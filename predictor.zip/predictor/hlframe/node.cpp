#include "hlframe/node.h"

namespace HLframe {

static void* b_func(void * args_tmp) {
    Bargs* args = (Bargs*)args_tmp;
    // std::cout << " bthread run output node: " << args->node->get_name().c_str() << std::endl;
    args->_node->run(args->_context);
    delete args;
    return nullptr;
}

void Node::init(ConfigXmlPtr config) {
}

void Node::run(GraphContextPtr context) {
    if (!skip(context)) {
        do_service(context);
        // io nodes call run_output_nodes_if_ready themselves
        if (type() == NODE_TYPE_CPU) {
            run_output_nodes_if_ready(context);
        }
        HILOG_APP(INFO)<< _name<<",type:"<<type();
    } else {
        HILOG_APP(INFO) << "skip " << _name;
        run_output_nodes_if_ready(context);
    }
}

int Node::do_service(GraphContextPtr context)  {
    HILOG_APP(INFO) << _name << " do service; input_num:  " << _input_num << " out_nodes size:" << _out_nodes.size() ;
    return 0;
}

bool Node::skip(GraphContextPtr context) {
     HILOG_APP(INFO) << _name << " _skip_flag:  " << _skip_flag ;
    if (_skip_flag) {
        return true;
    }
    return false;
}

bool Node::notify(GraphContextPtr context) {
    auto it = context->_node_input_num_map.find(this);
    if (it == context->_node_input_num_map.end()) {
        HILOG_APP(ERROR) << "node:" << this << " not found in node_input_num_map, this should not happen";
        return false;
    }
    auto input_num = it->second;
    int old_value = input_num->fetch_sub(1);
    HILOG_APP(INFO) << get_name() << " notified; " << " old_value: " << old_value;
    if (old_value == 1) {
        return true;
    } else if (old_value <= 0) {
        HILOG_APP(ERROR)<<get_name() << " too many notify, old_value: " << old_value << ", this should not happen";
    } 
    return false;
}

void Node::run_output_nodes_if_ready(GraphContextPtr context) {
    int ready_nodes_num = 0;
    Node* last_ready_node = nullptr;
    std::vector<bthread_t> bt_vec;
    bt_vec.reserve(_out_nodes.size());
    HILOG_APP(INFO) << get_name() << " _out_nodes.size: " << _out_nodes.size();
    for (size_t i = 0; i < _out_nodes.size(); i++) {
        auto output_node = _out_nodes[i];
        HILOG_APP(INFO) << get_name() << " notify " << output_node->get_name();
        auto ready = output_node->notify(context);
        if (ready) {
            HILOG_APP(INFO) << output_node->get_name() << " is ready";
            ++ready_nodes_num;
            if (last_ready_node != nullptr) {
                bthread_t tid;
                Bargs* args = new Bargs(last_ready_node, context);
                bthread_start_background(&tid, &BTHREAD_ATTR_SMALL, b_func, args);
                bt_vec.push_back(tid);
            }
            last_ready_node = output_node;

        }
    }
    if (last_ready_node != nullptr) {
        last_ready_node->run(context);
    }
    return;
}


}//end HLframe

