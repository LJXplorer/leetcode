#ifndef _HLFRAME_GRAPH_CONTEXT_H
#define _HLFRAME_GRAPH_CONTEXT_H
#include <vector>
#include <valarray>
#include <string>
#include <unordered_map>
#include <memory>
#include <utility>

namespace HLframe {
    class Node;
    class GraphContext {
        public:
        std::unordered_map<Node*, std::shared_ptr<std::atomic<int>>> _node_input_num_map;
        virtual int init() = 0;
    };
    using GraphContextPtr = std::shared_ptr<GraphContext>;
  
} // end  HLframe


#endif