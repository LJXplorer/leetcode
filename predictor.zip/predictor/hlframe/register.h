#ifndef _HLFRAME_REGISTER_H
#define _HLFRAME_REGISTER_H
#include <map>
#include <memory>
#include <iostream>
namespace HLframe {
    class Node;
    class ServiceFactory {
    public:
        virtual Node* create() = 0;
    };
    class NodeFactory_map{
    public:
        std::map<std::string, ServiceFactory*> global_node_map;
        static std::shared_ptr<NodeFactory_map> instance();
    private:
        NodeFactory_map() = default;
    };


    #define SERVICE_REGISTER(ServiceClass) class ServiceClass##Factory : public ServiceFactory { \
    public: \
    Node* create() override { \
        return new ServiceClass(); \
    } \
    }; \
    class ServiceClass##Register { \
    public: \
    ServiceClass##Register() { \
        NodeFactory_map::instance()->global_node_map.insert({#ServiceClass, new ServiceClass##Factory()}); \
    } \
    }; \
    static ServiceClass##Register ServiceClass##_inst_;

    #define GET_SERVICE_FACTORY(ServiceClassName) NodeFactory_map::instance()->global_node_map[ServiceClassName];

} // end HLframe
#endif
