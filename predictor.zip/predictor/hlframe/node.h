#ifndef _HLFRAME_NODE_H
#define _HLFRAME_NODE_H
#include <atomic>
#include <unordered_map>
#include <vector>
#include <functional>
#include <memory>
#include <queue>
#include <set>
#include <string>
#include "bthread/bthread.h"
#include "bthread/id.h"
#include "common/hilog/log_helper.h"
#include "hlframe/graph_context.h"
#include "common/comm/config_xml.h"
#include "hlframe/register.h"
using namespace hilog;

namespace HLframe {
    struct Bargs {
        Bargs(Node* n, GraphContextPtr ctx) : _node(n), _context(ctx) {
        }
        Node* _node;
        GraphContextPtr _context;
    };
    
    enum Node_Type{
        NODE_TYPE_CPU = 0,
        NODE_TYPE_IO = 1,
    };

    class Node {
        private:
            int _input_num = 0;
            std::vector<Node*> _out_nodes;
            std::string _name;
            bool _skip_flag = false;//跳过节点标识，默认为0/false，不跳过
        public:
            Node(const std::string& name = "") : _name(name){
            }
            virtual void init(ConfigXmlPtr xml);
            virtual void initialize(GraphContextPtr context){}
            void run(GraphContextPtr context);
            virtual int do_service(GraphContextPtr context) ;
            virtual bool skip(GraphContextPtr context);
            bool notify(GraphContextPtr context);

            const std::vector<Node*>& get_output_nodes() {
                return _out_nodes;
            }
            void set_name(const std::string& name) {
                this->_name = name;
            }

            const std::string& get_name() {
                return _name;
            }

            void set_skip_flag(bool& is_skip) {
                this->_skip_flag = is_skip;
            }

            void add_output(Node * node) {
                _out_nodes.push_back(node);
                node->incr_input_num();
            }
            size_t get_out_nodes_size() {
                return _out_nodes.size();
            }
            void run_output_nodes_if_ready(GraphContextPtr context);

            void incr_input_num() {
                _input_num++;
            }

            int get_input_num() {
                return _input_num;
            }

            virtual const Node_Type type() {
                return NODE_TYPE_CPU ;
            }
    };

} // end of namespace HLframe

#endif

