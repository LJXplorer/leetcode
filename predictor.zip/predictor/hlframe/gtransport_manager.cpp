#include "hlframe/gtransport_manager.h"
#include "boost/algorithm/string.hpp"
#include "common/comm/config_xml.h"
#include "common/hilog/log_helper.h"
#include <boost/uuid/random_generator.hpp>
#include <boost/uuid/uuid_io.hpp>
#include <brpc/options.pb.h>
#include <exception>
#include <iostream>
#include <shared_mutex>
using namespace hilog;
namespace HLframe {

    int TransportInfo::init_polaris() {
        try {
            _options.connection_type = _connection_type.c_str();
            _options.protocol = _protocol_type.c_str();

            HILOG_APP(INFO) << "initialize polaris channel"
                            << " _polaris_addr: " << _polaris_addr;
            if (!_polaris_addr.empty()) {
                if (_polaris_channel.Init(_polaris_addr.c_str(), "rr", &_options) != 0) {
                    HILOG_APP(ERROR) << _name << " initialize polaris channel fail";
                    return -1;
                }
            }
        } catch (const std::exception &exp) {
            HILOG_APP(ERROR) << _name << " initialize polaris channel fail";
            return -1;
        }

        return 0;
    }

    //增加接口而不放在get_channel里面的目的之一是需要监控拿到的channel是北极星的channel还是clb的channel
    brpc::Channel *TransportInfo::get_polaris_channel() {
        return &_polaris_channel;
    }

    GtransportManager &GtransportManager::instance() {
        static GtransportManager inst;
        return inst;
    }

    int GtransportManager::init(const std::string &conf_path) noexcept {
        ConfigXml xml_conf;
        std::cout << "node path:" << conf_path << std::endl;
        xml_conf.init(conf_path);
        ConfigXml main;
        if (!xml_conf.find("main", main)) {
            HILOG_APP(ERROR) << "main not found in " << conf_path;
            return -1;
        }

        ConfigXml channel_conf;
        if (!main.child("channel", channel_conf)) {
            HILOG_APP(ERROR) << "channel not exist in channel_config in file: " << conf_path;
            return -2;
        }
        bool has_next = false;
        auto back_hannel_map = _channel_map.get_bak_obj();
        do {
            auto trans_ptr = std::make_shared<TransportInfo>();
            channel_conf.attr<std::string>("name", trans_ptr->_name);
            channel_conf.attr<std::string>("lb", trans_ptr->_lb);
            channel_conf.attr<int>("timeout_ms", trans_ptr->_options.timeout_ms);
            channel_conf.attr<int>("backup_timeout_ms", trans_ptr->_options.backup_request_ms);
            channel_conf.attr<std::string>("connection_type", trans_ptr->_connection_type);
            channel_conf.attr<int>("max_retry", trans_ptr->_options.max_retry);
            channel_conf.attr<std::string>("protocol", trans_ptr->_protocol_type);
            channel_conf.attr<std::string>("model_type", trans_ptr->_model_type);
            channel_conf.attr<std::string>("pair_model", trans_ptr->_pair_model);
            channel_conf.attr<std::string>("dict_name", trans_ptr->_dict_name);
            channel_conf.attr<std::string>("dict_path", trans_ptr->_dict_path);

            if (trans_ptr->init_polaris() != 0) {
                HILOG_APP(ERROR) << "Fail to initialize " << trans_ptr->_name << " channel";
            } else {
                back_hannel_map->insert({trans_ptr->_name, trans_ptr});
            }

            has_next = channel_conf.next("channel", channel_conf);
        } while (has_next);
        _channel_map.change();
        HILOG_APP(ERROR) << "channel_map size: " << back_hannel_map->size();
        std::cout << "channel_map size: " << back_hannel_map->size() << std::endl;
        return 0;
    }

    brpc::Channel *GtransportManager::get_transport(const std::string &transport_name) {
        auto curr_channel_map = _channel_map.get_current_obj();
        auto it = curr_channel_map->find(transport_name);

        if (it == curr_channel_map->end()) {
            return nullptr;
            LOG(ERROR) << "transport_name: " << transport_name.c_str() << " not found";
        }
        return it->second->get_polaris_channel();
    }

    std::shared_ptr<TransportInfo> GtransportManager::get_transport_conf(const std::string &transport_name) {
        auto curr_channel_map = _channel_map.get_current_obj();
        auto it = curr_channel_map->find(transport_name);

        if (it == curr_channel_map->end()) {
            return nullptr;
            LOG(ERROR) << "transport_name: " << transport_name.c_str() << " not found";
        }
        return it->second;
    }

    //遍历整个 _channel_map 并返回 名称和通道 的对应关系
    std::unordered_map<std::string, std::shared_ptr<TransportInfo>> &GtransportManager::get_transports() {
        auto trs_map = _channel_map.get_current_obj();
        return *(trs_map.get());
    }

    int GtransportManager::new_init(const config::ConfigServiceCfg &cfg, const std::string &group_id,
                                    const std::string &data_id) {
        auto ptr = std::make_shared<GtransportNacosConfig>(group_id, data_id);
        config::RegisterResponse regist_ret = config::ConfigManager::getInstance().RegisterConfig(cfg, ptr);
        if (regist_ret != config::RegisterResponse::kSuccess) {
            std::cerr << "register graph transport manager nacos failed" << std::endl;
            HILOG_APP(ERROR) << "register graph transport manager nacos failed";
            return -1;
        }
        return 0;
    }

    int GtransportManager::update(const std::string &content) noexcept {
        ConfigXml xml_conf;
        if(!xml_conf.parse(content)) {
            HILOG_APP(ERROR) << "parse gtransport.xml failed, content: " << content;
            return -1;
        }
        ConfigXml main;
        if (!xml_conf.find("main", main)) {
            HILOG_APP(ERROR) << "main not found in gtransport.xml on Nacos";
            return -1;
        }

        ConfigXml channel_conf;
        if (!main.child("module", channel_conf)) {
            HILOG_APP(ERROR) << "channel not exist in channel_config in gtransport.xml on Nacos ";
            return -2;
        }
        bool has_next = false;
        auto back_hannel_map = _channel_map.get_bak_obj();
        do {
            auto trans_ptr = std::make_shared<TransportInfo>();
            channel_conf.attr<std::string>("name", trans_ptr->_name);
            channel_conf.attr<std::string>("lb", trans_ptr->_lb);
            channel_conf.attr<int>("timeout_ms", trans_ptr->_options.timeout_ms);
            channel_conf.attr<int>("backup_timeout_ms", trans_ptr->_options.backup_request_ms);
            channel_conf.attr<std::string>("connection_type", trans_ptr->_connection_type);
            channel_conf.attr<int>("max_retry", trans_ptr->_options.max_retry);
            ;
            channel_conf.attr<std::string>("protocol", trans_ptr->_protocol_type);
            channel_conf.attr<std::string>("model_type", trans_ptr->_model_type);
            channel_conf.attr<std::string>("pair_model", trans_ptr->_pair_model);
            channel_conf.attr<std::string>("dict_name", trans_ptr->_dict_name);
            channel_conf.attr<std::string>("dict_path", trans_ptr->_dict_path);

            std::string request_compress_type{};
            channel_conf.attr<std::string>("request_compress_type", request_compress_type);
            if (request_compress_type == "gzip") {
                trans_ptr->_request_compress_type = brpc::COMPRESS_TYPE_GZIP;
            } else if (request_compress_type == "lz4") {
                trans_ptr->_request_compress_type = brpc::COMPRESS_TYPE_LZ4;
            } else if (request_compress_type == "snappy") {
                trans_ptr->_request_compress_type = brpc::COMPRESS_TYPE_SNAPPY;
            } else if (request_compress_type == "zlib") {
                trans_ptr->_request_compress_type = brpc::COMPRESS_TYPE_ZLIB;
            } else {
                trans_ptr->_request_compress_type = brpc::COMPRESS_TYPE_NONE;
            }
            channel_conf.attr<std::string>("polaris_addr", trans_ptr->_polaris_addr);
            if (trans_ptr->init_polaris() != 0) {
                HILOG_APP(ERROR) << "Fail to initialize " << trans_ptr->_name << " channel";
            } else {
                back_hannel_map->insert_or_assign(trans_ptr->_name, trans_ptr);
            }

            has_next = channel_conf.next("module", channel_conf);
        } while (has_next);
        std::unique_lock<std::shared_mutex> lock(_mtx);
        _channel_map.change();
        HILOG_APP(ERROR) << "channel_map size: " << back_hannel_map->size();
        std::cout << "channel_map size: " << back_hannel_map->size() << std::endl;
        return 0;
    }

}// namespace HLframe
