#include <iostream>
#include <string>
#include "hlframe/node_manager.h"
#include "hlframe/gtransport_manager.h"
namespace HLframe {
int NodeManager::init(const std::string& file_path) {
    auto nodes_obj_ptr = _nodes_map.get_bak_obj();
    std::cout << nodes_obj_ptr << std::endl;
    nodes_obj_ptr->_xml_conf_ptr = std::make_shared<ConfigXml>();

    ConfigXml& xml_conf = *(nodes_obj_ptr->_xml_conf_ptr);
    xml_conf.init(file_path);
    ConfigXml main;
    if (!xml_conf.find("main", main)) {
        HILOG_APP(ERROR) << "main not found in " << file_path;
        return -1;
    }
    ConfigXmlPtr node_conf_ptr = std::make_shared<ConfigXml>();
    if (!main.child("node", *node_conf_ptr)) {
        HILOG_APP(ERROR) << "nodes_config not exist in file: " << file_path;
        return -2;
    }
    
    bool has_next = false;
    do {
        std::string name;
        node_conf_ptr->attr<std::string>("name", name);
        std::string clazz;
        node_conf_ptr->attr<std::string>("class", clazz);
        if(name.empty() || clazz.empty()){
            HILOG_APP(ERROR) << "node : " << name << " clazz:"<<clazz<<" empty";
            continue;
        }

        auto it = nodes_obj_ptr->_node_map.find(name);
        if (it != nodes_obj_ptr->_node_map.end()) {
            HILOG_APP(ERROR) << "node: " << name << " already exists";
        } else {
            nodes_obj_ptr->_node_map.insert({name, node_conf_ptr});
        }

        auto next_node_conf_ptr = std::make_shared<ConfigXml>();
        has_next = node_conf_ptr->next("node", *next_node_conf_ptr);
        node_conf_ptr = std::move(next_node_conf_ptr);

    } while(has_next);
    _nodes_map.change();
    HILOG_APP(ERROR) << "nodes_map size: " << nodes_obj_ptr->_node_map.size() << std::endl;
    std::cout<<"nodes_map size: " << nodes_obj_ptr->_node_map.size() << std::endl;

    return 0;
}


int NodeManager::init_nacos(const std::string& file_path) {
    auto nodes_obj_ptr = _nodes_map.get_bak_obj();
    std::cout << nodes_obj_ptr << std::endl;
    nodes_obj_ptr->_xml_conf_ptr = std::make_shared<ConfigXml>();

    ConfigXml& xml_conf = *(nodes_obj_ptr->_xml_conf_ptr);
    xml_conf.parse(file_path);
    ConfigXml main;
    if (!xml_conf.find("main", main)) {
        HILOG_APP(ERROR) << "main not found in " << file_path;
        std::cout << "main not found in " << file_path;
        return -1;
    }
    ConfigXmlPtr node_conf_ptr = std::make_shared<ConfigXml>();
    if (!main.child("node", *node_conf_ptr)) {
        HILOG_APP(ERROR) << "nodes_config not exist in file: " << file_path;
        std::cout << "nodes_config not exist in file: " << file_path;
        return -2;
    }
    
    bool has_next = false;
    do {
        std::string name;
        node_conf_ptr->attr<std::string>("name", name);
        std::string clazz;
        node_conf_ptr->attr<std::string>("class", clazz);
        if(name.empty() || clazz.empty()){
            HILOG_APP(ERROR) << "node : " << name << " clazz:"<<clazz<<" empty";
            std::cout << "node : " << name << " clazz:"<<clazz<<" empty";

            continue;
        }

        auto it = nodes_obj_ptr->_node_map.find(name);
        if (it != nodes_obj_ptr->_node_map.end()) {
            HILOG_APP(ERROR) << "node: " << name << " already exists";
            std::cout << "node: " << name << " already exists";
        } else {
            nodes_obj_ptr->_node_map.insert({name, node_conf_ptr});
        }

        auto next_node_conf_ptr = std::make_shared<ConfigXml>();
        has_next = node_conf_ptr->next("node", *next_node_conf_ptr);
        node_conf_ptr = std::move(next_node_conf_ptr);

    } while(has_next);
    _nodes_map.change();
    HILOG_APP(ERROR) << "nodes_map size: " << nodes_obj_ptr->_node_map.size() << std::endl;
    std::cout<<"nodes_map size: " << nodes_obj_ptr->_node_map.size() << std::endl;

    return 0;
}

int NodeManager::new_init(
    const config::ConfigServiceCfg& cfg,
    const std::string& group_id,
    const std::string& data_id
){
    // 注册nacos
    auto ptr = std::make_shared<NodeNacosConfig>(group_id, data_id);
    config::RegisterResponse regist_ret = config::ConfigManager::getInstance().RegisterConfig(cfg, ptr);
    if(regist_ret != config::RegisterResponse::kSuccess){
        std::cerr << "register node manager nacos failed" <<std::endl;
        HILOG_APP(ERROR) << "register node manager nacos failed";
        return -1;
    }
    return 0;
}

int NodeManager::update(const std::string& content) {
    // static std::unordered_map<std::string, std::shared_ptr<ConfigXml>> s_xml_conf_map;
    // std::shared_ptr<ConfigXml> xml_conf_ptr = std::make_shared<ConfigXml>();
    // s_xml_conf_map.insert({"node.xml", xml_conf_ptr});

    auto nodes_obj_ptr = _nodes_map.get_bak_obj();
    nodes_obj_ptr->_xml_conf_ptr = std::make_shared<ConfigXml>();

    ConfigXml& xml_conf = *(nodes_obj_ptr->_xml_conf_ptr);
    if(!xml_conf.parse(content)) {
            HILOG_APP(ERROR) << "parse node.xml failed, content: " << content;
            return -1;
        }
    ConfigXml main;
    if (!xml_conf.find("main", main)) {
        HILOG_APP(ERROR) << "main not found in node.xml on Nacos";
        return -1;
    }
    ConfigXmlPtr node_conf_ptr = std::make_shared<ConfigXml>();
    if (!main.child("node", *node_conf_ptr)) {
        HILOG_APP(ERROR) << "nodes_config not exist in node.xml on Nacos";
        return -2;
    }
    nodes_obj_ptr->_node_map.clear();
    bool has_next = false;
    do {
        std::string name;
        node_conf_ptr->attr<std::string>("name", name);
        std::string clazz;
        node_conf_ptr->attr<std::string>("class", clazz);
        if(name.empty() || clazz.empty()){
            HILOG_APP(ERROR) << "node : " << name << " clazz:"<<clazz<<" empty";
            continue;
        }

        auto it = nodes_obj_ptr->_node_map.find(name);
        if (it != nodes_obj_ptr->_node_map.end()) {
            HILOG_APP(ERROR) << "node: " << name << " already exists";
        } else {
            nodes_obj_ptr->_node_map.insert({name, node_conf_ptr});
        }

        auto next_node_conf_ptr = std::make_shared<ConfigXml>();
        has_next = node_conf_ptr->next("node", *next_node_conf_ptr);
        node_conf_ptr = std::move(next_node_conf_ptr);

    } while(has_next);
    _nodes_map.change();
    HILOG_APP(ERROR) << "nodes_map size: " << nodes_obj_ptr->_node_map.size() << std::endl;
    std::cout<<"nodes_map size: " << nodes_obj_ptr->_node_map.size() << std::endl;

    return 0;
}






} // end HLFrame

