#include "hlframe/context.h"
namespace HLframe {
    
    RequestContext::RequestContext(brpc::Controller* cntl,const google::protobuf::Message* req,google::protobuf::Message* rsp,
                google::protobuf::Closure* done): 
                _cntl(cntl),_request(req),_response(rsp),_done(done){
    }
    
    RequestContext::~RequestContext(){
    }

    void RequestContext::done(){
        _done->Run();
    }
    
    RequestContextPtr Context::get_request_context(){
	    return _request_context_ptr;
    }

    int Context::init(){
	    return 0 ;
    }

    void Context::set_context_status(bool s){ 
	    _is_valid = s; 
    }

    bool Context::get_context_status(){
	    return _is_valid;
    }

    void Context::gen_log_head(){
    }

    const std::string& Context::get_log_head(){
	    return _log_header;   
    }

    Context::Context(){
    }
    
    Context::~Context(){
    }


} // end  HLframe

