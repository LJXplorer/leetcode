#ifndef _HLFRAME_CONTEXT_H
#define _HLFRAME_CONTEXT_H
#include "google/protobuf/message.h"
#include "hlframe/graph_context.h"
#include "brpc/channel.h"
#include "brpc/callback.h"
#include "bthread/bthread.h"
#include "bthread/id.h"
#include <type_traits>
namespace HLframe {
    class RequestContext{
    private:
        brpc::Controller* _cntl;
        const google::protobuf::Message* _request;
        google::protobuf::Message* _response;
        google::protobuf::Closure* _done;
    public:
        RequestContext(brpc::Controller* cntl,const google::protobuf::Message* req,google::protobuf::Message* rsp,
                google::protobuf::Closure* done);
        ~RequestContext();
    public:
        template<typename Request>
        const Request*  get_request(){return ((Request*)_request);}

        template<typename Request>
        Request*  mutable_request(){return ((Request*)_request);}

        template<typename Response>
        Response*  get_response(){return ((Response*)_response);}
        void done();
    };
    

    using RequestContextPtr = std::shared_ptr<RequestContext>;

    class Context : public GraphContext{
        public:
            bool _is_valid = true;
            RequestContextPtr _request_context_ptr;
            std::string _log_header;
        public:
            Context();
            virtual ~Context();
        public:
            RequestContextPtr get_request_context();
            virtual int init();
            void set_context_status(bool s);
            bool get_context_status();
            virtual void gen_log_head();
            const std::string& get_log_head();
            template <typename Request, typename Response>
            void make_request_context(brpc::Controller* cntl,const Request* request,Response* response,
                google::protobuf::Closure* done){
                    _request_context_ptr = std::make_shared<RequestContext>(cntl, request, response, done);
                }
    };

    using ContextPtr = std::shared_ptr<Context>;
    
    #define LOG_HEAD(CTX) CTX->get_log_head()
} // end  HLframe


#endif
