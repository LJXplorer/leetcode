#ifndef _HLFRAME_GRAPH_H
#define _HLFRAME_GRAPH_H
#include <atomic>
#include <unordered_map>
#include <vector>
#include <functional>
#include <memory>
#include <queue>
#include <set>
#include <string>
#include "common/hilog/log_helper.h"
#include "hlframe/context.h"
#include "hlframe/register.h"
#include "hlframe/node.h"
using namespace hilog;

namespace HLframe {
    class Graph {
    private:
        Node* _root_node = nullptr;
        std::vector<Node*> _all_nodes;
        std::string _name = "default";
    public:
        static Graph& instance() {
            static Graph g;
            return g;
        }

        void set_name(const std::string& name) {
            this->_name = name;
        }

        int init(const std::string& path) {
            return 0;
        }

        int init(Node* node, const std::string& name = "") ;
            
        template<typename Request, typename Response>
        int run(ContextPtr context,brpc::Controller* cntl, 
                const Request* request,Response* response,
                google::protobuf::Closure* done) {
            // 1. 构造图的上下文
            if(context->get_context_status() == false){
                HILOG_APP(ERROR) << "CTX  not Derived Context";
                return -1;
            }

            if (_root_node == nullptr) {
                HILOG_APP(ERROR) << "root_node is nullptr";
                return -2;
            }

            for (auto node : _all_nodes) {
                auto it = context->_node_input_num_map.find(node);
                if (it == context->_node_input_num_map.end()) {
                    context->_node_input_num_map[node] = std::make_shared<std::atomic<int>>(node->get_input_num());
                    HILOG_APP(INFO) << "node: " << node->get_name() << " input_num:" << context->_node_input_num_map[node]->load();
                }
                node->initialize(context);
            }

            // 2. run
            _root_node->run(context);
            return 0;
        }
    };

    using GraphPtr = std::shared_ptr<Graph>;

} // end of namespace HLframe

#endif
