#ifndef _HLFRAME_NODE_MANAGER_H
#define _HLFRAME_NODE_MANAGER_H
#include "common/config/base_config.h"
#include "common/config/service_config.h"
#include "common/config/config_manager.h"
#include "common/hilog/log_helper.h"
#include "common/comm/config_xml.h"
#include <unordered_map>
#include <memory>
#include <iostream>
#include "common/comm/double_buffer.h"
using namespace hilog;
namespace HLframe {
    using node_map = std::unordered_map<std::string, ConfigXmlPtr >;

    struct NodeObj {
        node_map _node_map;
        std::shared_ptr<ConfigXml> _xml_conf_ptr = nullptr;  
    };

    class NodeManager {
    private:
        NodeManager() {
        };
        DBuffer<NodeObj> _nodes_map;
    public:
        static NodeManager& instance() {
            static NodeManager inst;
            return inst;
        }

        int init(const std::string& file_path);
        int init_nacos(const std::string& file_path);
        int new_init(const config::ConfigServiceCfg& cfg,
                     const std::string& group_id,
                     const std::string& data_id);
        int update(const std::string& content);

        ConfigXmlPtr get_node_info(const std::string& node_name) {
            auto node_obj_ptr = _nodes_map.get_current_obj();
            auto it = node_obj_ptr->_node_map.find(node_name);
            if (it != node_obj_ptr->_node_map.end()) {
                return it->second;
            } else {
                std::cout << "node_name: " << node_name << " found in nodes_map" << std::endl;
                return nullptr;
            }
        }
    };


     struct NodeNacosConfig : public config::ListenableConfig {
        std::string group_id;
        std::string data_id;

        NodeNacosConfig(const std::string& group_id, const std::string& data_id)
            : group_id(group_id), data_id(data_id) {}

        int OnConfigChanged(const std::string& new_config) override {
            HILOG_APP(INFO) << "new content: \n" << new_config << std::endl;
            return NodeManager::instance().update(new_config);
        }

        config::ConfigSource GetConfigSource() override {
            return {
                .group_id = group_id,
                .data_id = data_id
            };
        }

    };

} // end HLFrame

#endif
