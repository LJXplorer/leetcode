#ifndef _HLFRAME_TRANS_MANAGER_H
#define _HLFRAME_TRANS_MANAGER_H
#include "brpc/callback.h"
#include "butil/base64.h"
#include "butil/time/time.h"
#include "common/comm/config_xml.h"
#include "common/comm/double_buffer.h"
#include "common/config/base_config.h"
#include "common/config/config_manager.h"
#include "common/config/error_code.h"
#include "common/config/service_config.h"
#include "common/hilog/log_helper.h"
#include <brpc/channel.h>
#include <brpc/channel_base.h>
#include <brpc/options.pb.h>
#include <random>
#include <shared_mutex>
#include <string>
#include <unordered_map>

namespace HLframe {
    struct TransportInfo {
        std::string _name;
        std::string _lb;
        std::string _connection_type = "single";
        std::string _protocol_type = "h2:grpc";
        std::string _model_type;
        std::string _pair_model;
        std::string _dict_name;
        std::string _dict_path;
        brpc::CompressType _request_compress_type = brpc::COMPRESS_TYPE_NONE;
        brpc::ChannelOptions _options;
        brpc::Channel _polaris_channel;//北极星命名服务channel
        std::string _polaris_addr;

    public:
        TransportInfo() {
            _options.timeout_ms = 80;
            _options.backup_request_ms = -1;
            _options.max_retry = 0;
        }
        int init_polaris();
        brpc::Channel *get_polaris_channel();
    };

    using trans_map = std::unordered_map<std::string, std::shared_ptr<TransportInfo>>;
    class GtransportManager {
    private:
        DBuffer<trans_map> _channel_map;
        int32_t _SEED = 0x7f3a21eaL;
        int32_t _ONE_HUNDRED = 100;

    public:
        static GtransportManager &instance();
        std::unordered_map<std::string, std::shared_ptr<TransportInfo>> &get_transports();
        int init(const std::string &conf_path) noexcept;
        int new_init(const config::ConfigServiceCfg &cfg, const std::string &group_id, const std::string &data_id);
        int update(const std::string &content) noexcept;
        brpc::Channel *get_transport(const std::string &transport_name);
        std::shared_ptr<TransportInfo> get_transport_conf(const std::string &transport_name);
        std::shared_mutex _mtx;
    };

    struct GtransportNacosConfig : public config::ListenableConfig {
        std::string group_id;
        std::string data_id;

        GtransportNacosConfig(const std::string &group_id, const std::string &data_id)
            : group_id(group_id), data_id(data_id) {
        }

        int OnConfigChanged(const std::string &new_config) override {
            HILOG_APP(INFO) << "new content: \n" << new_config << std::endl;
            return GtransportManager::instance().update(new_config);
        }

        config::ConfigSource GetConfigSource() override {
            return {.group_id = group_id, .data_id = data_id};
        }
    };

}// namespace HLframe

#endif
