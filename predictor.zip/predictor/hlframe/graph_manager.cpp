#include "hlframe/graph.h"
#include "common/comm/config_xml.h"
#include "hlframe/graph_manager.h"
#include "hlframe/node_manager.h"
#include <boost/algorithm/string.hpp>

namespace HLframe {

int GraphManager::init(const std::string& file_path) {
    ConfigXml xml_conf;
    xml_conf.init(file_path);
    ConfigXml main;
    if (!xml_conf.find("main", main)) {
        HILOG_APP(ERROR) << "main not found in " << file_path;
        return -1;
    }

    ConfigXml graph_conf;
    if (!main.child("graph", graph_conf)) {
        HILOG_APP(ERROR) << "graph not exist in graph: " << file_path;
        return -2;
    }
    bool has_next = false;


    do {
        std::string graph_name;
        graph_conf.attr<std::string>("name", graph_name);
        create_graph(graph_name,graph_conf);
        has_next = graph_conf.next("graph", graph_conf);
    } while(has_next);
    _graph_map.change();

    HILOG_APP(ERROR) <<file_path<< " graph size: " << _graph_map.get_current_obj()->size();
    return 0;
}

void GraphManager::create_graph(const std::string&graph_name,const ConfigXml&graph_conf){
    bool has_next_node = false;
    ConfigXml node_conf;
    if (!graph_conf.child("node", node_conf)) {
        HILOG_APP(ERROR) << "node not exist in graph: " << graph_name;
        return;
    }
    GraphPtr graph = std::make_shared<Graph>();
    Node* root = nullptr;
    std::unordered_map<std::string, Node*> nodes_map;
    auto create_service_if_not_exist = [&nodes_map,&graph_name](const std::string name) -> Node* {
        auto it = nodes_map.find(name);
        if (it != nodes_map.end()) {
            return it->second;
        }
        auto node_config = NodeManager::instance().get_node_info(name);
        if (!node_config) {
            HILOG_APP(ERROR) << graph_name<<" node name: " << name << " not found in node manager";
            std::cout <<graph_name<< " node name: " << name << " not found in node manager"<<std::endl;
            return nullptr;
        }

        std::string clazz;
        node_config->attr<std::string>("class", clazz);
        auto service_fac = GET_SERVICE_FACTORY(clazz);
        if (!service_fac) {
            HILOG_APP(ERROR) << graph_name<<" unregistered class: " << clazz;
            std::cout << graph_name<<" unregistered class: " << clazz<<std::endl;
            return nullptr;
        }
        //bool skip_flag = false;
        //node_config->attr<bool>("skip_flag", skip_flag);
        auto service_node = service_fac->create();
        service_node->init(node_config);
        service_node->set_name(name);
        //service_node->set_skip_flag(skip_flag);
        nodes_map[name] = service_node;
        return service_node;
    };

    do {
        std::string name;
        node_conf.attr<std::string>("name", name);
        Node* service = create_service_if_not_exist(name);
        if (!service) {
            HILOG_APP(ERROR) <<graph_name << " graph node name: " << name << " create failed";
            std::cout <<graph_name << "graph node name: " << name << " create failed" << std::endl;
            has_next_node = node_conf.next("node", node_conf);
            continue;
        }
        if (root == nullptr) {
            // first node is root by default
            root = service;
        }
        {
            std::string children = "";
            node_conf.attr<std::string>("children", children);
            if (!children.empty()) {
                boost::trim(children);
                std::vector<std::string> child_vec;
                boost::split(child_vec, children, boost::is_any_of(","));
                for (std::string& c : child_vec) {
                    boost::trim(c);
                    Node* child = create_service_if_not_exist(c);
                    if (!child) {
                        continue;
                    }
                    service->add_output(child);
                }
            }
        }
        has_next_node = node_conf.next("node", node_conf);
    } while(has_next_node);

    graph->init(root, graph_name);
    auto back_graph = _graph_map.get_bak_obj();
    back_graph->insert({graph_name, graph});
}

std::shared_ptr<Graph> GraphManager::get_graph(const std::string& graph_name) {
    auto curr_graph = _graph_map.get_current_obj();
    auto it = curr_graph->find(graph_name);
    if (it == curr_graph->end()) {
        return std::shared_ptr<Graph>();
    }

    return it->second;
}

int GraphManager::new_init(
    const config::ConfigServiceCfg& cfg,
    const std::string& group_id,
    const std::string& data_id
){
    auto ptr = std::make_shared<GraphNacosConfig>(group_id, data_id);
    config::RegisterResponse regist_ret = config::ConfigManager::getInstance().RegisterConfig(cfg, ptr);
    if(regist_ret != config::RegisterResponse::kSuccess){
        std::cerr << "register graph nacos failed" <<std::endl;
        HILOG_APP(ERROR) << "register graph nacos failed";
        return -1;
    }
    return 0;
}


int GraphManager::update(const std::string& content) {
    tinyxml2::XMLDocument doc;
    if (doc.Parse(content.c_str()) != tinyxml2::XML_SUCCESS) {
        HILOG_APP(ERROR) << "Invalid XML: failed to parse XML content";
        return -3;
    }
    
    ConfigXml xml_conf;
    if(!xml_conf.parse(content)) {
        HILOG_APP(ERROR) << "parse  graph.xml failed, conent: " << content;
        return -1;
    }
    ConfigXml main;
    if (!xml_conf.find("main", main)) {
        HILOG_APP(ERROR) << "main not found in graph.xml on Nacos ";
        return -1;
    }

    ConfigXml graph_conf;
    if (!main.child("graph", graph_conf)) {
        HILOG_APP(ERROR) << "graph not exist in graph.xml on Nacos ";
        return -2;
    }
    bool has_next = false;


    do {
        std::string graph_name;
        graph_conf.attr<std::string>("name", graph_name);
        create_graph(graph_name,graph_conf);
        has_next = graph_conf.next("graph", graph_conf);
    } while(has_next);
    _graph_map.change();

    HILOG_APP(ERROR) <<"graph.xml on Nacos graph size: " << _graph_map.get_current_obj()->size();
    return 0;
}



} // end HLframe


