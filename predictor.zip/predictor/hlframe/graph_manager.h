#ifndef _HLFRAME_GRAPH_MANAGER_H
#define _HLFRAME_GRAPH_MANAGER_H
#include <string>
#include <unordered_map>
#include <memory>
#include "common/comm/config_xml.h"
#include "common/config/base_config.h"
#include "common/config/service_config.h"
#include "hlframe/graph.h"
#include "common/comm/double_buffer.h"
namespace HLframe {
    using graph_map = std::unordered_map<std::string, GraphPtr >;
    class GraphManager {
    private:
        DBuffer<graph_map> _graph_map;
    private:
        GraphManager(){}
    public:
        static GraphManager& instance() {
            static GraphManager inst;
            return inst;
        }

        int init(const std::string& conf_path);
        GraphPtr get_graph(const std::string& topo_name);
        int new_init(const config::ConfigServiceCfg& cfg,
                     const std::string& group_id,
                     const std::string& data_id);
        int update(const std::string& content);
    private:
        void create_graph(const std::string&name,const ConfigXml&graph_conf);
        Node* create_service(const std::string name){return nullptr;};

    };

    struct GraphNacosConfig : public config::ListenableConfig {
        std::string group_id;
        std::string data_id;


        GraphNacosConfig(const std::string& group_id, const std::string& data_id)
            : group_id(group_id), data_id(data_id) {}

        int OnConfigChanged(const std::string& new_config) override {
            HILOG_APP(INFO) << "new content: \n" << new_config << std::endl;
            return GraphManager::instance().update(new_config);
        }

        config::ConfigSource GetConfigSource() override {
            return {
                .group_id = group_id,
                .data_id = data_id
            };
        }
    };


} // end HLframe


#endif
