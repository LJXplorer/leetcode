#include "dict_manager.h"
#include "dict.h"
#include "dict_logger.h"
#include <exception>
#include <pthread.h>
#include <string>
#include <sys/sysinfo.h>
#if __cplusplus >= 201703L
#include "dict_counters_provider.h"
#endif
//#include <gflags/gflags.h>

namespace hidict {
    //DEFINE_int32(reload_sleep_s, 5, "dict reload sleep time in seconds");
    const int32_t FLAGS_reload_sleep_s = 10;

    bool DictCollector::init(const std::string &name, const std::vector<DictConfig> &cfgs, bool off, CallbackRegisterFactory callback_register_factory) {
        if (!off && callback_register_factory == nullptr) {
            LOG_DICT("off = [" + std::to_string(off) + "]; call back register factory is null!");
            return false;
        }
        m_name = name;
        for (const auto &config: cfgs) {
            DictInfo* dict_info = register_dict(config.m_name, config.m_clazz, config.m_path);
            if (dict_info == nullptr) {
                if(off) {
                    throw std::invalid_argument("register_dict failed! config.m_name: ["+ config.m_name +"]; config.m_clazz: ["+ config.m_clazz + "]; config.m_path: "+ config.m_path);
                }
                LOG_DICT("dict [" + m_name + "]; register fail class: [" + config.m_clazz + "]");
                return false;
            } else {
                #if __cplusplus >= 201703L
                    // 在线时 将创建的新词典注册到计数器中 离线时 No-Op 实现 目前先跳过结巴词典监控计数
                    if (dict_info->m_clazz_name != "JieBaDict") {
                        hidict::g_counters->register_cell(dict_info->m_path, dict_info->m_clazz_name);
                    }
                #endif

                if (callback_register_factory != nullptr) {
                    //todo: 在线需要传入callback_register_factory
                    auto* dict_callback = callback_register_factory(config.m_clazz);
                    if (dict_callback == nullptr) {
                        LOG_DICT("dict [" + m_name + "]; register call back failed: clazz_name = [" + config.m_clazz + "]");
                        return false;
                    }
                    dict_info->register_callback(dict_callback);
                    LOG_DICT("dict [" + m_name + "]; dict class: [" + config.m_clazz + "], register callback success");
                }
                 
            }
        }

        return run(off);
    }

    bool DictCollector::run(bool off) {
        is_offline = off;
        if (is_offline) {
            return load_dict();
        }
        //no need to create thread while first load dict done
        if (first_load_done) {
            return true;
        }
        pthread_create(&m_pid, NULL, &check, (void *) this);
        if (m_pid == 0) {
            return false;
        }
        return true;
    }

    DictInfo* DictCollector::register_dict(const std::string &dict_name, const std::string &clazz, const std::string &path) {
        if(dict_name.empty() || clazz.empty() || path.empty()) {

            LOG_DICT("[" +std::to_string(time(NULL)) +"] dict [" +  dict_name + "] "+"class [" +clazz + "] "+" empty, register failed");
            // throw std::invalid_argument("[dict_name or clazz or path empty]");
            return nullptr;
        }

        if (m_dict_hash.find(dict_name) != m_dict_hash.end()) {
            LOG_DICT("[" +std::to_string(time(NULL)) +"] dict [" +  dict_name + "] "+"class [" +clazz + "] "+" exist, register failed");
            // throw std::invalid_argument("[dict]: "+dict_name+" exist");
            return nullptr;
        }
        auto dict_fac = GET_DICT_FACTORY(clazz);
        if (!dict_fac) {
            LOG_DICT("[" +std::to_string(time(NULL)) +"] dict [" + dict_name + "] "+"class [" +clazz + "]  unregistered , register failed");
            // throw std::invalid_argument("dict ["+dict_name+"] unregistered class: [" + clazz + "]" );
            return nullptr;
        }
        DictInfo *info = dict_fac->create();
        info->m_clazz_name = clazz;
        if (info->init(dict_name, path) != 0) {
              LOG_DICT("[" +std::to_string(time(NULL)) +"] dict [" + dict_name + "] "+"class [" +clazz + "]  init faied" );
            // throw std::invalid_argument("dict [" + dict_name + "]init failt"  );
            delete info;
            return nullptr;
        }
        info->gen_data_info();
        m_dict_hash[dict_name] = info;
        return info;
    }

    DictInfo *DictCollector::get_dict(const std::string &dict_name) {
        if(dict_name.empty()) return nullptr;
        auto iter = m_dict_hash.find(dict_name);
        if (iter == m_dict_hash.end()) {
            LOG_DICT( "get [dict] falied dict_name=" + dict_name);
            return nullptr;
        }
        return iter->second;
    }

    bool DictCollector::load_dict() {
        bool load_all_succ = true;
        //DictLogger::getLogger()->hiLogWriter("ssss, offline: "+ std::to_string(is_offline));
        for (auto &dict: m_dict_hash) {
            time_t now = time(NULL);
            //没有版本的不需要定时加载，在初始化时候加载完成
            if(dict.second->is_no_version) {
                // std::cout <<"[" <<now <<"]"<<" [" <<dict.first  <<"]"<<
                //         " [" <<dict.second->m_clazz_name  <<
                //         " [" <<dict.second->m_latest_dir  <<"] "<< " no need load " << std::endl;
                continue;
            }
            //加载判断,条件：在线，非第一次，60s后&& first_load_done
            if (!is_offline && first_load_done && dict.second->load_by_condition(now, is_offline) == false) {
                // std::cout<< "file condic,is_offline: "<< is_offline <<std::endl;
                if(dict.second->dictErrorManager.getErrorField() > 0) {
                    dict.second->error_call_back();
                }
                continue;
            }
            //释放
            if (dict.second->pre_free(now)) {
            }
            //加载
            bool load_suc = false;
            if (dict.second->load(is_offline)) {
                dict.second->exchange(now);
                load_suc = true;
            } else {
                load_all_succ = false;
            }
            if(!is_offline) {
                dict.second->post_load(now, load_suc);
            } 
            LOG_DICT("[" +std::to_string(now) +"]"+" dict [" +dict.first  +"], class "+
                        " [" +dict.second->m_clazz_name  +"], latest dir ["
                        +dict.second->m_latest_dir  +"] "+ " load result: "+ std::to_string(load_suc) + ", load succ num: "+ std::to_string(dict.second->load_succ_num));
        }
        return load_all_succ;
    }

    void *DictCollector::check(void *arg) {
        if (arg == nullptr)
            return nullptr;
        DictCollector *mgr = (DictCollector *) arg;
        cpu_set_t mask;
        CPU_ZERO(&mask);
        CPU_SET(sysconf(_SC_NPROCESSORS_CONF) - 1, &mask);
        if (pthread_setaffinity_np(mgr->m_pid, sizeof(cpu_set_t), &mask) != 0) {
           LOG_DICT("[" + std::to_string(time(NULL)) +"]"+ " DictCollector set cpu affinity failed");
        }
        while (true) {
            bool load_all_succ = mgr->load_dict();
            // first load
            if(!mgr->first_load_done) {
                // load failed
                if(!load_all_succ) {
                    LOG_DICT("[" +std::to_string(time(NULL)) +"]"+ " First loading dict failed, please handle it..." );
                } else {
                    //flag to dict_mgr.cpp to warning, not blocking main progress lanuch
                    mgr->load_all_succ_flag = true;
                }
                mgr->first_load_done = true;
            }
            
            sleep(FLAGS_reload_sleep_s);
        }
    }

    DictCollectorManager::DictCollectorManager() {
    }

    DictCollectorManager::~DictCollectorManager() {
    }

    DictCollectorManager &DictCollectorManager::get_instance() {
        static DictCollectorManager g_dict_Collector_manager;
        return g_dict_Collector_manager;
    }
    std::shared_ptr<DictCollector> DictCollectorManager::alloc_collector(const std::string &name) {
        auto coll = std::make_shared<DictCollector>();
        m_dict_coll_hash.insert({name, coll});
        return coll;
    }

    std::shared_ptr<DictCollector> DictCollectorManager::get_collector(const std::string &name) {
        auto it = m_dict_coll_hash.find(name);
        if (it == m_dict_coll_hash.end())
            return nullptr;
        return it->second;
    }

}// namespace hidict
