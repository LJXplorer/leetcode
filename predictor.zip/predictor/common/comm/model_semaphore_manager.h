#pragma once
#include <memory>
#include "counting_semaphore.h"

class ModelSemaphoreManager {
public:
    // 初始化信号量，设置最大并发数
    static void Init(int max_concurrent_models);

    // 获取信号量指针
    static CountingSemaphore* GetSemaphore();

private:
    // 禁止实例化
    ModelSemaphoreManager() = delete;
    ~ModelSemaphoreManager() = delete;
    ModelSemaphoreManager(const ModelSemaphoreManager&) = delete;
    ModelSemaphoreManager& operator=(const ModelSemaphoreManager&) = delete;

    static std::unique_ptr<CountingSemaphore> model_sema_;
};
