#include "model_semaphore_manager.h"

std::unique_ptr<CountingSemaphore> ModelSemaphoreManager::model_sema_ = nullptr;

void ModelSemaphoreManager::Init(int max_concurrent_models) {
    model_sema_ = std::make_unique<CountingSemaphore>(max_concurrent_models);
}

CountingSemaphore *ModelSemaphoreManager::GetSemaphore() {
    return model_sema_.get();
}