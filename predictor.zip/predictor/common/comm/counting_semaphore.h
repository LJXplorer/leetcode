#pragma once
#include <condition_variable>
#include <log_helper.h>
#include <mutex>

class CountingSemaphore {
public:
    explicit CountingSemaphore(int count) : count_(count), max_count_(count) {
    }

    void acquire() {
        std::unique_lock<std::mutex> lock(mtx_);
        cv_.wait(lock, [this]() { return count_ > 0; });
        --count_;
    }

    void release() {
        {
            std::lock_guard<std::mutex> lock(mtx_);
            if (count_ < max_count_) {
                ++count_;
            } else {
                HILOG_APP(ERROR) << "CountingSemaphore release called too many times, count_ already at max_count_";
            }
        }
        cv_.notify_one();
    }

    // 新增：返回当前可用资源数，线程安全
    int available() {
        std::lock_guard<std::mutex> lock(mtx_);
        return count_;
    }

    // 新增：返回最大信号量数
    int max_count() const {
        return max_count_;
    }

private:
    std::mutex mtx_;
    std::condition_variable cv_;
    int count_;
    const int max_count_;
};
