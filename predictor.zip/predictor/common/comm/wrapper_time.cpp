#include "wrapper_time.h"
int64_t get_cur_time_us() {
    struct timespec tp;
    clock_gettime(CLOCK_REALTIME, &tp);
    return tp.tv_sec * 1000000 + tp.tv_nsec / 1000;
}

int64_t gettimeofday_us() {
    timeval now;
    gettimeofday(&now, nullptr);
    return now.tv_sec * 1000000L + now.tv_usec;
}

int64_t gettimeofday_ms() {
    return gettimeofday_us() / 1000L;
}

int64_t gettimeofday_s() {
    return gettimeofday_us() / 1000000L;
}

std::string get_timestamp_from_ms(int64_t ms) {
    // 将毫秒转换为秒
    time_t seconds = ms / 1000;

    // 获取当前时间的结构体
    std::tm *tm_now = std::localtime(&seconds);

    // 格式化为 YYYY-MM-DD-HH-mm
    char buffer[20];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d-%H-%M-%S", tm_now);

    return std::string(buffer);
}

std::string get_current_date_yyyymmdd() {
    int64_t ms = gettimeofday_ms();
    time_t seconds = ms / 1000;

    // 获取当前时间的结构体
    std::tm *tm_now = std::localtime(&seconds);

    // 格式化为 YYYYMMDD
    char buffer[9];
    std::strftime(buffer, sizeof(buffer), "%Y%m%d", tm_now);

    return std::string(buffer);
}

std::string get_current_30min_interval() {
    int64_t ms = gettimeofday_ms();
    time_t seconds = ms / 1000;

    // 获取当前时间的结构体
    std::tm *tm_now = std::localtime(&seconds);

    int total_minutes = tm_now->tm_hour * 60 + tm_now->tm_min;
    int interval_index = total_minutes / 30;
    int interval_start_minute = interval_index * 30;

    int hour = interval_start_minute / 60;
    int minute = interval_start_minute % 60;

    char buffer[5];
    std::snprintf(buffer, sizeof(buffer), "%02d%02d", hour, minute);

    return std::string(buffer);
}