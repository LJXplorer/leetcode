#ifndef _WRAPPER_TIME_H
#define _WRAPPER_TIME_H
#include <time.h>
#include <sys/time.h>
#include <stdint.h>
#include <string>
#include <sys/time.h>
#include <iomanip>

int64_t get_cur_time_us();
int64_t gettimeofday_us();
int64_t gettimeofday_ms();
int64_t gettimeofday_s();
std::string get_timestamp_from_ms(int64_t ms);
std::string get_current_date_yyyymmdd();
std::string get_current_30min_interval();
#endif