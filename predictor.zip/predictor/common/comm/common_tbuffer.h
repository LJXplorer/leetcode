#ifndef _COMMON_TBUFFER_H
#define _COMMON_TBUFFER_H

#include <atomic>
#include <log_helper.h>
#include <memory>
#include <vector>

template<typename T>
class TBuffer {
private:
    std::vector<std::shared_ptr<T>> vec;
    std::atomic<uint8_t> write_index;
    std::atomic<uint8_t> read1_index;
    std::atomic<uint8_t> read2_index;
    std::atomic<uint8_t> active_read_slot;// 1 = read1, 2 = read2

public:
    TBuffer() {
        vec.resize(3);
        vec[0] = std::make_shared<T>();
        vec[1] = std::make_shared<T>();
        vec[2] = std::make_shared<T>();
        write_index.store(0);
        read1_index.store(1);
        read2_index.store(2);
    }

    std::shared_ptr<T> get_obj_by_version(int64_t version) {
        auto active_read_obj = get_active_read_obj();
        auto other_read_obj = get_other_read_obj();
        HILOG_APP(INFO) << "get_obj_by_version called with version: " << version
                        << ",Checking active_read_obj with version: " << active_read_obj->get_version()
                        << ",Checking write_obj with version: " << get_current_write_obj()->get_version()
                        << ",Checking other_read_obj with version: " << other_read_obj->get_version();

        if (active_read_obj->get_version() == version) {
            return active_read_obj;
        }
        if (other_read_obj->get_version() == version) {
            return other_read_obj;
        }

        return nullptr;
    }

    std::shared_ptr<T> get_current_write_obj() {
        return vec[write_index.load()];
    }

    std::shared_ptr<T> get_active_read_obj() {
        return vec[read1_index.load()];
    }

    std::shared_ptr<T> get_other_read_obj() {
        return vec[read2_index.load()];
    }

    void rotate_buffers() {
        uint8_t old_write = write_index.load();
        uint8_t old_read1 = read1_index.load();
        uint8_t old_read2 = read2_index.load();

        write_index.store(old_read2);
        read1_index.store(old_write);
        read2_index.store(old_read1);
    }

    void first_rotate_buffers() {
        uint8_t old_write = write_index.load();
        uint8_t old_read2 = read2_index.load();

        write_index.store(old_read2);
        read2_index.store(old_write);
    }
};

#endif