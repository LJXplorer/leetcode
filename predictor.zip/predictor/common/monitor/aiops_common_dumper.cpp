#include "aiops_common_dumper.h"
#include "common/hilog/log_helper.h"
#include "monitor_logger.h"
#include <cctype>
#include <cstddef>

namespace monitor {
bool AiopsCommonDumper::dump(const std::string &name,
                             const butil::StringPiece &description) {
  nlohmann::json json_log_container{};


  std::string_view name_sv{name.data(), name.size()};
  std::string_view desc_sv{description.data(), description.size()};
  HILOG_APP(INFO) << "name = " << name_sv << "; desc = " << desc_sv;
  std::string dumped_container_key{};

  std::vector<std::string_view> name_splited = split(name_sv, '{');
  if (name_splited.size() == 2) {
    auto full_name = name_splited[0];
    const auto split_point = full_name.find_first_of("_");
    auto service_name = full_name.substr(0, split_point);
    if (!service_name.empty()) {
      std::string final_service_name{service_name};
      final_service_name[0] = std::toupper(final_service_name[0]);
      json_log_container["s"] = final_service_name;
      dumped_container_key.append(final_service_name).append("_");
    }
    std::string metrics_monitor_name =
        std::string{full_name.substr(split_point + 1)};
    auto pairs_str = name_splited[1].substr(0, name_splited[1].size() - 1);
    auto pairs = split(pairs_str, ',');

    const size_t len = pairs.size();
    std::string quantile_key{};
    for (size_t i = 0; i < len; i++) {
      const auto pair = pairs[i];
      auto kv = split(pair, '=');
      auto key = kv[0];
      auto value = kv[1].substr(1, kv[1].size() - 2);
      if (i == len - 1 && key == "quantile") {
        quantile_key.append("quantile_").append(value);
        continue;
      }
      json_log_container[key] = value;
      dumped_container_key.append(key).append("_").append(value).append("_");
    }

    if (auto iter = json_container_map_.find(dumped_container_key);
        iter == json_container_map_.end()) {
      json_container_map_[dumped_container_key] = json_log_container;
    }

    auto &json_container_in_map = json_container_map_[dumped_container_key];

    if (!quantile_key.empty()) {
      metrics_monitor_name.append("_").append(quantile_key);
    }
    HILOG_APP(INFO) << "dumped_container_key = [" << dumped_container_key << "], metrics_monitor_name = [" << metrics_monitor_name << "]";
    //指标为0不上报
    if(desc_sv !="0"){
       json_container_in_map[metrics_monitor_name] = desc_sv;
    }
  }
  return true;
};

std::unordered_map<std::string, nlohmann::json> &
AiopsCommonDumper::GetDumpedJsonMap() {
  return json_container_map_;
}

std::vector<std::string_view>
AiopsCommonDumper::split(const std::string_view &str, char delimiter) {
  std::vector<std::string_view> result;
  size_t start = 0;
  size_t end = str.find(delimiter);

  while (end != std::string_view::npos) {
    result.emplace_back(str.substr(start, end - start));
    start = end + 1;
    end = str.find(delimiter, start);
  }

  result.emplace_back(str.substr(start));
  return result;
}

} // namespace monitor