#pragma once
#include "nlohmann/json.hpp"

#include <bvar/variable.h>
#include <string_view>
#include <unordered_map>

namespace monitor {
class AiopsCommonDumper : public bvar::Dumper {
public:
  bool dump(const std::string &name,
            const butil::StringPiece &description) override;
  std::unordered_map<std::string, nlohmann::json>& GetDumpedJsonMap();
  ~AiopsCommonDumper() {}

private:
  std::unordered_map<std::string, nlohmann::json> json_container_map_;
  static std::vector<std::string_view> split(const std::string_view &str,
                                             char delimiter);
};
} // namespace monitor
