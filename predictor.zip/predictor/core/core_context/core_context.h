#ifndef _CORE_CORE_CONTEXT_H
#define _CORE_CORE_CONTEXT_H

#include "common/comm/wrapper_time.h"
#include "common/hilog/log_helper.h"
#include "context_defs.h"
#include "core/core_context/fe_context.h"
#include "core/core_context/fs_context.h"
#include "core/core_context/infer_context.h"
#include "core/core_context/monitor_context.h"
#include "core/core_context/prerank_context.h"
#include "core/utils/defs.h"
#include "core/utils/util.h"
#include "hlframe/context.h"
#include "json2pb/pb_to_json.h"
#include "ranking/predict_service.pb.h"
#include <cstdint>
#include <debug_utils.h>
#include <google/protobuf/arena.h>
#include <map>
#include <memory>
#include <nlohmann/json.hpp>
#include <string>
#include <unordered_map>

using json = nlohmann::json;
using namespace phx;
using namespace hilog;
using namespace HLframe;
namespace Core {

    struct AdsPair {
    public:
        ::phx::PredictorItemInfo *_reqeust_adv;
        ::phx::ResponseDumpData *_response_dump_adv;

        //Todo 临时使用
        std::string _category;
        std::shared_ptr<std::vector<float>> _item_embedding_vec_;
        std::shared_ptr<std::vector<float>> _cvr_item_embedding_vec_;

        float _preRankingScore_cvr_score = 0.0f;
        float _preRankingScore_cvr_score_raw = 0.0f;
        int32_t _preRankingScore_cvr_status = 0;

    public:
        AdsPair(phx::PredictorItemInfo *a, ::phx::ResponseDumpData *rsp_adv)
            : _reqeust_adv(a), _response_dump_adv(rsp_adv) {
        }

        const ::phx::PredictorItemInfo *get_request_adv() {
            return _reqeust_adv;
        }

        ::phx::ResponseDumpData &get_response_adv() {
            return *_response_dump_adv;
        }

        std::string to_string() const {
            std::string result;
            result.append("AdsPair { ");
            result.append("MATERIAL ID: ").append(std::to_string(get_creative_id())).append(", ");
            result.append("CATEGORY: ").append(get_category()).append(", ");
            result.append("APP ID: ").append(std::to_string(get_appid())).append(", ");
            result.append("Is New: ").append(is_new() ? "true" : "false").append(", ");
            result.append("Is Guaranteed: ").append(_reqeust_adv->guaranteed() ? "true" : "false").append(", ");
            result.append("item_embedding_vec: ").append(vector_to_string(_item_embedding_vec_)).append(", ");
            result.append("Billing Mode: ").append(std::to_string(get_billing_mode())).append(", ");
            result.append("score: ").append(std::to_string(get_inner_score())).append(" }");
            return result;
        }

        std::string vector_to_string(const std::shared_ptr<std::vector<float>> &vec) const {
            if (!vec)
                return "null";
            std::ostringstream oss;
            oss << "[";
            for (size_t i = 0; i < vec->size(); ++i) {
                if (i > 0)
                    oss << ", ";
                oss << (*vec)[i];
            }
            oss << "]";
            return oss.str();
        }

        std::string get_category() const {
            return "";
        }

        bool is_new() const {
            return (_reqeust_adv->recalltype() != 0);
        }
        int32_t get_billing_mode() const {
            return _reqeust_adv->billingmode();
        }

        int32_t get_appid() const {
            return _reqeust_adv->appid();
        }

        int64_t get_creative_id() const {
            return _reqeust_adv->creativeid();
        }

        float get_inner_score() const {
            return _response_dump_adv->prerankscore();
        }

        // 获取 embedding 的绝对值和
        float get_embedding_abs_avg() const {
            if (!_item_embedding_vec_ || _item_embedding_vec_->empty()) {
                return 0.0f;
            }
            return std::accumulate(_item_embedding_vec_->begin(), _item_embedding_vec_->end(), 0.0f,
                                   [](float acc, float val) { return acc + std::fabs(val); })/get_embedding_size();
        }

        // 获取 embedding 的 size
        size_t get_embedding_size() const {
            return _item_embedding_vec_ ? _item_embedding_vec_->size() : 0;
        }
    };

    struct ReportInfo {

        size_t new_ads_added_num = 0; //进入保送队列的广告个数
        size_t new_ads_not_added_num = 0; //未能进入保送队列的广告个数

        size_t fallback_added_num = 0;//兜底添加的广告个数

        size_t reserved_after_truncate_num = 0; //截断后保留个数
        size_t discarded_after_truncate_num = 0;//截断后丢弃个数

        size_t reserved_after_hold_num = 0; //保位后保留个数
        size_t discarded_after_hold_num = 0;//保位后丢弃个数

        size_t reserved_after_fallback_num = 0; //兜底后保留个数
        size_t discarded_after_fallback_num = 0;//兜底后丢弃个数

        size_t prerank_candidate_num = 0;//进入截断的广告个数

        size_t truncated_ads_num = 0;//最终选中个数
        size_t discarded_ads_num = 0;//最终丢弃个数

        //仅供测试时使用
        std::string to_string() const {
            std::ostringstream oss;
            oss << "ReportInfo { "
                << "new_ads_added_num: " << new_ads_added_num << ", "
                << "new_ads_not_added_num: " << new_ads_not_added_num << ", "
                << "fallback_added_num: " << fallback_added_num << ", "
                << "reserved_after_truncate_num: " << reserved_after_truncate_num << ", "
                << "discarded_after_truncate_num: " << discarded_after_truncate_num << ", "
                << "reserved_after_hold_num: " << reserved_after_hold_num << ", "
                << "discarded_after_hold_num: " << discarded_after_hold_num << ", "
                << "reserved_after_fallback_num: " << reserved_after_fallback_num << ", "
                << "discarded_after_fallback_num: " << discarded_after_fallback_num << ", "
                << "prerank_candidate_num: " << prerank_candidate_num << ", "
                << "truncated_ads_num: " << truncated_ads_num << ", "
                << "discarded_ads_num: " << discarded_ads_num << " }";
            return oss.str();
        };
    };

    class CoreContext : public HLframe::Context {
    private:
    public:
        //bak info
        int _response_code = 200;
        phx::PredictorRequest _bak_request;
        phx::PredictorResponse *_bak_response;
        phx::PredictorResponseDump *_bak_response_dump;

        int64_t _begin_ts = gettimeofday_ms();
        int64_t _end_ts = gettimeofday_ms();
        //context
        MonitorContextPtr _monitor_context_ptr;
        FSContextPtr _fs_context_ptr;
        PrerankContextPtr _prerank_context_ptr;
        FeContextPtr _fe_context_ptr;
        InferContextPtr _infer_context_ptr;
        google::protobuf::Arena _context_arena;
        bool _is_callback = false;
        bool _is_retrying = false;
        PredictTaskType _task_type;
        bool _is_all_dsp = false;
        bool _is_all_inner = false;
        int32_t _predict_time;
        bool _is_ex_req = false;// 异常请求标记
        bool _has_missed_query = false;
        bool _need_fs_truncation = false;

        bool _is_skip_prerank_cvr = false;
        bool _dump_verify = false;// 校验点上报
        int _prerank_sample_ratio = 0;
        int _ctr_sample_ratio = 0;
        int _cvr_sample_ratio = 0;
        int _ltv_sample_ratio = 0;
        std::unordered_map<std::string, const ::phx::PredictorRequest_Experiment *> _experiment;
        std::unordered_map<std::string, ::phx::PredictorRequest_Experiment> _experiment_copy;
        std::unordered_map<std::string, std::string> _experiment_model_name;
        std::unordered_map<ExperimentModelInfo *, std::vector<ItemWrapper>> _model_predict_cpc_cvr_map;
        std::unordered_map<ExperimentModelInfo *, std::vector<ItemWrapper>> _model_predict_cpd_cvr_map;
        std::unordered_map<ExperimentModelInfo *, std::vector<ItemWrapper>> _model_predict_cpc_ctr_map;
        std::unordered_map<ExperimentModelInfo *, std::vector<ItemWrapper>> _model_predict_cpd_ctr_map;
        std::unordered_map<ExperimentModelInfo *, std::vector<ItemWrapper>> _model_predict_ltv_map;

        std::unordered_map<int64_t, ::phx::PredictorItemData> _creative_id_item_score_map;
        std::unordered_map<Node*, std::shared_ptr<std::atomic<int> > > _node_split_num_map;

        void reserve_model_capacity(size_t expected_models) {
            _model_info_vec.reserve(expected_models);
            _cpc_ctr_model_map.reserve(expected_models);
            _cpc_cvr_model_map.reserve(expected_models);
            _cpd_ctr_model_map.reserve(expected_models);
            _cpd_cvr_model_map.reserve(expected_models);
        }
        std::vector<std::unique_ptr<ExperimentModelInfo>> _model_info_vec;
        std::unordered_map<int, ExperimentModelInfo *> _cpc_ctr_model_map;
        std::unordered_map<int, ExperimentModelInfo *> _cpc_cvr_model_map;
        std::unordered_map<int, ExperimentModelInfo *> _cpd_cvr_model_map;
        std::unordered_map<int, ExperimentModelInfo *> _cpd_ctr_model_map;
        std::unordered_map<int, ExperimentModelInfo *> _ltv_model_map;

        std::unordered_map<int64_t, AdsPairPtr> _ads_map;
        std::shared_ptr<ReportInfo> _report_info;

        std::string _offline_item_emb_model;
        int32_t _offline_item_emb_version;
        bool _need_relase_rank_req_manually = false;
        bool _need_release_rank_res_manually = false;
        bool _is_version_update= false;
        bool _is_first_rotate=true;
        std::string _handled_query;

        std::string _ctr_policy;
        std::string _cvr_policy;
        std::string _ltv_policy;

    public:
        CoreContext();
        virtual ~CoreContext();
        virtual int init();
        void gen_log_head() override;
        MonitorContextPtr get_monitor_context();
        PrerankContextPtr get_prerank_context();
        FSContextPtr get_fs_context();
        FeContextPtr get_fe_context();
        InferContextPtr get_infer_context();
        const phx::PredictorRequest *get_rank_request();
        phx::PredictorRequest *get_mutable_rank_request();
        phx::PredictorRequest *mutable_rank_request();
        phx::PredictorResponse *get_rank_response();
        const phx::PredictorRequest &get_raw_request();
        phx::PredictorResponse *get_raw_response();
        const std::string &get_oaid();
        const std::string &get_req_id();
        const std::string &get_query();
        const std::string &get_handled_query();
        void set_handled_query(const std::string &query);
        int64_t get_slot_id();
        int64_t get_pctr_in_pos_num();
        int64_t get_media_id();
        int32_t get_algo_scene_id();
        int32_t get_scene_type();
        int32_t get_route();
        const std::vector<ItemWrapper> *get_split_list(PredictType t, const std::string &key);
        void set_predicttime(int64_t predict_time);
        int64_t get_predicttime();
        void set_ex_req(bool is_ex_req);
        bool get_is_ex_req();
        void set_has_missed_query(bool has_missed_query);
        bool get_has_missed_query();
        void set_dump_verify(bool dump_verify);
        bool get_dump_verify();
        bool is_test_request();
        google::protobuf::Arena *get_context_arena();
        void reserve_ads_map(size_t s);

        int64_t get_begin_time() {
            return _begin_ts;
        }

        int64_t get_end_time() {
            return _end_ts;
        }

        bool is_game() {
            return get_rank_request()->businesstype() == 2;
        }

        bool is_experience() {
            return get_rank_request()->businesstype() == 3;
        }

        std::string GetUploadSlotName() {// 按值返回
            if (this->is_game()) {
                return GAME_DEFAULT_SLOT;// 假设这是std::string类型常量
            }
            if (this->get_rank_request()->mediatype() == 2) {
                return "adsAffiliate";// 直接返回字面量
            }
            return std::to_string(this->get_slot_id());// 按值返回临时对象
        }

        inline BillingMode to_billing_mode(int mode) {
            return static_cast<BillingMode>(mode);
        }
    };

    using CoreContextPtr = std::shared_ptr<CoreContext>;

    struct BatchFetchArgs {
        int index = 0;
        int start = 0;
        int end = 0;
        int result_code = 0;
        bthread_t tid;
        //这里取智能指针的引用
        CoreContextPtr context;
        int start_fetch_status = 0;
        std::unordered_map<std::string, int> exception_report;
        Node *node;
    };
}// namespace Core

#endif
