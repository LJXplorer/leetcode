#pragma once

#include "context_defs.h"
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "core/utils/defs.h"
#include "fe_request.pb.h"
#include "phx-fe/src/session.h"
#include <cstdint>
#include <google/protobuf/arena.h>
#include <unordered_map>
namespace Core {
    struct ExtractorWrapper {
        std::vector<phx::ItemFeature *> items;
        phx::ExtractorResponse *extractor_response;
        int error_code = FE_NORMAL;

        std::string to_json() const {
            std::ostringstream oss;
            oss << "{";

            // items 数组
            oss << "\"items\": [";
            for (size_t i = 0; i < items.size(); ++i) {
                if (items[i]) {
                    std::string json_str;
                    google::protobuf::util::MessageToJsonString(*items[i], &json_str);
                    oss << json_str;
                } else {
                    oss << "null";
                }
                if (i != items.size() - 1) {
                    oss << ", ";
                }
            }
            oss << "], ";

            // extractor_response
            oss << "\"extractor_response\": ";
            if (extractor_response) {
                std::string json_str;
                google::protobuf::util::MessageToJsonString(*extractor_response, &json_str);
                oss << json_str;
            } else {
                oss << "null";
            }
            oss << ", ";

            // error_code
            oss << "\"error_code\": " << error_code;

            oss << "}";
            return oss.str();
        }
    };

    struct FeSession {
        FeSession() = default;
        FeSession(google::protobuf::Arena *arena) {
            this->user_feature_extractor_response =
                    google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(arena);
        }
        phx_fe::Session session;
        phx::ExtractorResponse *user_feature_extractor_response;
    };

    using FeSplitMap = std::unordered_map<ExperimentModelType,
                                          std::unordered_map<ExperimentModelInfo *, std::vector<ExtractorWrapper>>>;
    using FeSessionMap = std::unordered_map<ExperimentModelType, std::unordered_map<ExperimentModelInfo *, FeSession>>;
    class FeContext {
    public:
        google::protobuf::Arena *_arena;
        FeSplitMap fe_split_;
        FeSessionMap fe_session_map_;

    public:
        FeContext(google::protobuf::Arena *arena) {
            this->_arena = arena;
        };
        virtual ~FeContext() {};
        const FeSplitMap &GetSplit() {
            return fe_split_;
        }

        FeSplitMap *MutableSplit() {
            return &fe_split_;
        }

        const FeSessionMap &GetSessions() {
            return fe_session_map_;
        }

        FeSessionMap *MutableSessions() {
            return &fe_session_map_;
        }
        bool exist(ExperimentModelType p) {
            return fe_split_.find(p) != fe_split_.end();
        };
    };

    using FeContextPtr = std::shared_ptr<FeContext>;
}// namespace Core
