#ifndef _CORE_FS_CONTEXT_H
#define _CORE_FS_CONTEXT_H
#include "core/utils/service_pair.h"
#include "core/utils/util.h"
#include "itemfeature/item_feature.pb.h"
#include "ranking/callback_service.pb.h"
#include "fe_request.pb.h"
#include <memory>
#include <unordered_map>
#include <vector>
namespace Core {

    class FSContext {
    public:
        google::protobuf::Arena *_arena;
        std::unordered_map<int64_t, ::phx::ItemFeature *> _item_fea;//item
        std::unordered_map<int64_t, ::phx::AppFeature *> _app_fea;//app
        std::vector<::phx::ItemFeature *> _zero_creativeid_item_fea; // creative id为0的item特征
        std::vector<const ::phx::CallbackItemInfo*> _zero_creativeid_items;

        //feature dump servcie
        std::unordered_set<int64_t> _item_direct_inv;//直投item
        int _index_size = 0;                             //index的大小
        ::phx::FeRequest *feature_dump;

        // 特征快照
        std::shared_ptr<::phx::FeRequest> _snapshot_feature;

    public:
        FSContext(google::protobuf::Arena *arena);
        virtual ~FSContext();
        const std::unordered_map<int64_t, ::phx::ItemFeature *> &get_item_fea();
        const std::unordered_map<int64_t, ::phx::AppFeature *> &get_app_fea();
        const std::vector<::phx::ItemFeature *> &get_zero_creativeid_item_fea();

        ::phx::ItemFeature *alloc_item_fea(int64_t k, bool add = true);
        ::phx::AppFeature *alloc_app_fea(int64_t k, bool add = true);
        ::phx::ItemFeature *alloc_zero_creativeid_item_fea();
        ::phx::FeRequest* get_feature_dump();
        void reserve_item_fea(size_t s);
        void reserve_app_fea(size_t s);

        std::shared_ptr<::phx::FeRequest> get_feature_snapshot();
    };

    using FSContextPtr = std::shared_ptr<FSContext>;
}// namespace Core

#endif
