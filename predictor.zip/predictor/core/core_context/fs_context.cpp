#include "core/core_context/fs_context.h"
#include "common/hilog/log_helper.h"
#include <memory>
using namespace hilog;
namespace Core {

    FSContext::FSContext(google::protobuf::Arena *arena) : _arena(arena) {
        this->feature_dump = google::protobuf::Arena::CreateMessage<::phx::FeRequest>(arena);
    }

    FSContext::~FSContext() {
    }

    const std::unordered_map<int64_t, ::phx::ItemFeature *> &FSContext::get_item_fea() {
        return _item_fea;
    }

    const std::unordered_map<int64_t, ::phx::AppFeature *> &FSContext::get_app_fea() {
        return _app_fea;
    }

    const std::vector<::phx::ItemFeature *> &FSContext::get_zero_creativeid_item_fea() {
        return _zero_creativeid_item_fea;
    }

    ::phx::ItemFeature *FSContext::alloc_item_fea(int64_t k, bool add) {
        auto it = _item_fea.find(k);
        if (it != _item_fea.end())
            return it->second;
        if (add == false)
            return nullptr;
        auto item = feature_dump->add_item_fea();
        _item_fea.insert({k, item});
        return item;
    }

    ::phx::AppFeature *FSContext::alloc_app_fea(int64_t k, bool add) {
        auto it = _app_fea.find(k);
        if (it != _app_fea.end())
            return it->second;
        if (add == false)
            return nullptr;
        auto item = feature_dump->add_app_fea();
        _app_fea.insert({k, item});
        return item;
    }

    ::phx::ItemFeature *FSContext::alloc_zero_creativeid_item_fea() {
        auto item = feature_dump->add_item_fea();
        _zero_creativeid_item_fea.emplace_back(item);
        return item;
    }

    void FSContext::reserve_item_fea(size_t s) {
        _item_fea.reserve(s);
    }

    void FSContext::reserve_app_fea(size_t s) {
        _app_fea.reserve(s);
    }

    ::phx::FeRequest *FSContext::get_feature_dump() {
        return feature_dump;
    }

    std::shared_ptr<::phx::FeRequest> FSContext::get_feature_snapshot() {
        return _snapshot_feature;
    }

}// namespace Core
