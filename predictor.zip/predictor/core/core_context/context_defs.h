#pragma once
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "ranking/predict_service.pb.h"
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
namespace Core {
    enum class PredictTaskType {
        kUnknown = 0,
        kPrerankAndRank = 1,
        kRank = 2,
        kItemEmbedding = 3,
        kUserEmbedding = 4,
        kFeatureDump = 5,
        kItemMultiOutput = 6,
        kUserMultiOutput = 7,
    };
    enum class ExperimentModelType {
        MODEL_INFO_UNKNOWN = 0,
        CPC_CTR = 1,
        CPC_CVR = 2,
        CPD_CTR = 3,
        CPD_CVR = 4,
        ITEM_EMBEDDING = 5,//item embedding
        USER_EMBEDDING = 6,
        CVR_ITEM_EMBEDDING = 7,
        CVR_USER_EMBEDDING = 8,
        LTV,
    };

    struct ExtractorResult {
        phx::ExtractorResponse *extractor_response;
        /**
         * @brief fe错误码
         * -1: 错误码未设置
         * 0: 正常
         * 1. fe异常
         * 2. 未知异常
         */
        int32_t error_code;
    };

    inline ExperimentModelType stringToExperimentModelType(const std::string &str) {
        static const std::unordered_map<std::string_view, ExperimentModelType> reverse_key_map = {
                {"ctr", ExperimentModelType::CPC_CTR},
                {"dtr", ExperimentModelType::CPD_CTR},
                {"cvr", ExperimentModelType::CPC_CVR},
                {"cpd_cvr", ExperimentModelType::CPD_CVR},
                {"item_embedding", ExperimentModelType::ITEM_EMBEDDING},
                {"user_embedding", ExperimentModelType::USER_EMBEDDING},
                {"cvr_item_embedding", ExperimentModelType::CVR_ITEM_EMBEDDING},
                {"cvr_user_embedding", ExperimentModelType::CVR_USER_EMBEDDING},
                {"ltv", ExperimentModelType::LTV}
            };

        auto it = reverse_key_map.find(str);
        if (it != reverse_key_map.end()) {
            return it->second;
        } else {
            HILOG_APP(ERROR) << "Invalid string for ExperimentModelType conversion: " << str;
            return ExperimentModelType::MODEL_INFO_UNKNOWN;
        }
    }

    inline std::string experimentModelTypeToString(ExperimentModelType type) {
        static const std::unordered_map<ExperimentModelType, std::string_view> key_map = {
                {ExperimentModelType::CPC_CTR, "ctr"},
                {ExperimentModelType::CPD_CTR, "dtr"},// 注意：这里应该是 "ctr" 还是 "dtr"？根据上下文我假设是 "dtr"
                {ExperimentModelType::CPC_CVR, "cvr"},
                {ExperimentModelType::CPD_CVR, "cpd_cvr"},
                {ExperimentModelType::ITEM_EMBEDDING, "item_embedding"},
                {ExperimentModelType::USER_EMBEDDING, "user_embedding"},
                {ExperimentModelType::CVR_ITEM_EMBEDDING, "cvr_item_embedding"},
                {ExperimentModelType::CVR_USER_EMBEDDING, "cvr_user_embedding"},
                {ExperimentModelType::LTV, "ltv"}
            };
        auto it = key_map.find(type);
        if (it != key_map.end()) {
            return std::string(it->second);
        } else {
            // 对于未知的枚举值，可以返回一个特殊字符串或抛出异常
            // 这里选择返回 "unknown"
            return "unknown";
        }
    }

    enum BillingMode {
        UNKNOWN = 0,
        CPC = 1,
        OCPC_1 = 2,
        OCPC_2 = 3,
        OCPC_3 = 4,
        CPD = 5,
        OCPD_1 = 6,
        OCPD_2 = 7,
        OCPD_3 = 8,
        CPM = 9
    };

    inline BillingMode stringToBillingMode(const std::string &str) {
        int billing_mode_number;
        std::istringstream iss(str);
        if (!(iss >> billing_mode_number)) {
            HILOG_APP(ERROR) << "Invalid string for BillingMode conversion: " << str;
            return BillingMode::UNKNOWN;
        }

        // 检查转换后的整数是否在有效的枚举值范围内
        if (billing_mode_number < BillingMode::UNKNOWN || billing_mode_number > BillingMode::CPM) {
            HILOG_APP(ERROR) << "Invalid string for BillingMode conversion: " << str;
            return BillingMode::UNKNOWN; 
        }

        return static_cast<BillingMode>(billing_mode_number);
    }

    enum DebugLevel : int32_t {
        kDumpFeResponse = 10000,
        kDumpPredictService = 20000,
        kPrintModelRequestInfo = 20001,
        kRecallOfflineManually = 30000,
        kRecallDumpProto = 30001,
        kRecallDumpEmb = 30002,
        kPrerank=113,
    };

    struct ExperimentModelInfo {
        ExperimentModelType _model_type;
        std::vector<int32_t> _supported_conv_types;
        std::string _model_name;
        std::shared_ptr<Info::ModelInfo> _model_info;
        explicit ExperimentModelInfo(const nlohmann::json &entry, ExperimentModelType type) : _model_type(type) {
            const auto *key = entry.contains("conv_type") ? "conv_type" : "ctr_type";
            if (entry.contains(key)) {
                const auto &arr = entry[key];
                _supported_conv_types.reserve(arr.size());
                for (const auto &t: arr) {
                    _supported_conv_types.push_back(t.get<int32_t>());
                }
            } else if (entry.contains("outputs")) {
                const auto& arr = entry["outputs"];
                _supported_conv_types.reserve(arr.size());
                for (const auto& t: arr) {
                    _supported_conv_types.push_back(t.get<int32_t>());
                }
            }
            _model_name = entry["model"].get<std::string>();
        }
    };

    struct ItemWrapper {
        const phx::PredictorItemInfo *item;
        std::vector<ExperimentModelInfo *> model_info;
        ::phx::PredictorItemData *item_data;
        ItemWrapper(const phx::PredictorItemInfo *item, ::phx::PredictorItemData *item_data,
                    const std::vector<ExperimentModelInfo *> &model_info)
            : item(item), model_info(model_info), item_data(item_data) {
        }
        ItemWrapper(const phx::PredictorItemInfo *item) : item(item), model_info(), item_data(nullptr) {
        }
    };
}// namespace Core