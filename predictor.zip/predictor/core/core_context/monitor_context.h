#ifndef _CORE_STRING_CONTEXT_H
#define _CORE_STRING_CONTEXT_H
#include "core/utils/monitor_mgr.h"
#include "core/utils/service_pair.h"
#include "common/comm/wrapper_time.h"
#include <cstdint>
#include <unordered_map>
namespace Core  {
    enum LatStage{
        LAT_STAGE_CREATE = 0,
        LAT_STAGE_DESTROY = 1,
    };

    class BizLatency{
    public:
        int64_t _req_begin_tm = 0;
        int64_t _req_end_tm = 0;
        int64_t _rsp_begin_tm = 0;
        int64_t _rsp_end_tm = 0;
    public:   
        int64_t get_request_lat();
        int64_t get_response_lat();
        int64_t get_lat();
        std::string toString();
    };

    class BizLatencyGaurd{
        public:
            BizLatencyGaurd(BizLatency*lat,LatStage stage);
            ~BizLatencyGaurd();
        public:
            BizLatency *m_lat;
            LatStage m_stage = LAT_STAGE_CREATE;
    };

    struct StatRpc{
        int _ret = 0;
        int64_t _lat = 0;
        int32_t _up_size = 0;
        int64_t _redis_response_size = 0;
        FsSource _source;
    };

    struct UpRpc{
        int _ret = 0;
        int64_t _feat_size = 0;
        int64_t _response_size = 0;
        std::string _cluster_id;
        FsSource _source;
    };

    struct AdjustedInfo{
        int64_t _adj_cnt = 0;
        int64_t _total_cnt = 0;
        AdjustedInfo(int64_t _adj_cnt, int64_t _total_cnt)
        : _adj_cnt(_adj_cnt), _total_cnt(_total_cnt) {}
    };

    struct StatItem{
        BizLatency _lat;
        std::unordered_map<std::string,std::string> _extra_map;
        std::unordered_map<std::string,float> _f_extra_map;
        std::unordered_map<std::string,int64_t> _l_extra_map;
        std::unordered_map<std::string,StatRpc> _redis_extra_map;
        std::unordered_map<std::string,UpRpc> _up_extra_map;
        std::unordered_map<std::string,AdjustedInfo> _adjusted_extra_map;
    public:
        int64_t request_lat(){
            return _lat.get_request_lat();
        }

        int64_t response_lat(){
            return _lat.get_response_lat();
        }

        int64_t lat(){
            return _lat.get_lat();
        }

        BizLatency* get_lat(){
            return &_lat;
        }

        void report_int(const std::string&k,int v);
        void report_float(const std::string&k,float v);
        void report_string(const std::string&k,const std::string& v);
        void report_redis_rpc(const std::string&k,int ret,int64_t lat,int32_t up_size, int64_t redis_response_size);
        void report_up_rpc(const std::string&k, const std::string& cluster_id, int ret, int64_t feat_value_size, int64_t feat_response_size);
        void report_adjusted(const std::string&k, int adj_cnt, int total_cnt);
    };

    using StatItemPtr = std::shared_ptr<StatItem>;
    class MonitorContext {
    private:
       std::unordered_map<std::string,StatItemPtr > _stat_pair;//node->StatItem
    public:
        MonitorContext();
        ~MonitorContext();
        StatItemPtr get_node_stat(const std::string&k);
        void alloc_node(const std::string&k,PredictType p = PREDICT_TYPE_UNKNOWN);
        std::unordered_map<std::string,StatItemPtr >& get_stat_pair();
    };
    
    using MonitorContextPtr = std::shared_ptr<MonitorContext>;
}

#endif
