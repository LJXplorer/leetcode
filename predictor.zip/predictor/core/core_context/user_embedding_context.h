#pragma once
#include "core/core_context/core_context.h"
#include "core/core_context/item_embedding_context.h"
#include "core/utils/defs.h"
#include "ranking/embedding_service.pb.h"

namespace Core {

    class UserEmbeddingContext : public CoreContext {
    private:
        qinglongv2::UserEmbeddingRequest *_bak_user_embedding_request;
        qinglongv2::UserEmbeddingResponse *_bak_user_embedding_response;
    public:
        std::string _real_user_model_name;
        std::shared_ptr<Info::ModelInfo> _user_emb_model_info;
        phx::ExtractorResponse* _user_extractor_response = nullptr;
        // std::unordered_map<int64_t, ItemEmbeddingAdPair> _emb_ads_map;

    public:
        UserEmbeddingContext();
        virtual ~UserEmbeddingContext();
        const qinglongv2::UserEmbeddingRequest &GetUserEmbeddingRequest() const;

        qinglongv2::UserEmbeddingRequest *MutableUserEmbeddingRequest();

        const qinglongv2::UserEmbeddingResponse &GetUserEmbeddingResponse() const;

        qinglongv2::UserEmbeddingResponse *MutableUserEmbeddingResponse();

        const qinglongv2::UserEmbeddingRequest &GetRawUserRequest();

        qinglongv2::UserEmbeddingRequest* MutableRawUserRequest();

        qinglongv2::UserEmbeddingResponse *GetRawUserResponse();

        const std::string &GetUserEmbeddingModelName() const;

        const std::string &GetRealUserModelName() const;

        const int32_t GetUserEmbeddingVersion() const;

        const int32_t GetAlgoSceneId() const;

        std::string GetUploadSlotName() {// 按值返回
            return STRING_DEFAULT;
        }
        

        // const std::string &get_req_id() const;
        // const std::string &get_oaid() const;
        // const std::string &get_slot_id() const;
        // const std::string &get_media_id() const;
        // const std::string &get_query() const;
        // const ::qinglongv2::EmbeddingType get_embedding_type() const;
        // const int32_t get_user_embedding_version() const;


        int init() override;
        void gen_log_head() override;
    };
    using UserEmbeddingContextPtr = std::shared_ptr<UserEmbeddingContext>;
}// namespace Core