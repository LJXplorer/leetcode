#include "core/core_context/callback_context.h"
namespace Core  {

    CallbackContext::CallbackContext(){
        _begin_ts = gettimeofday_ms();
        _end_ts = gettimeofday_ms();
    }
    
    CallbackContext::~CallbackContext(){
        
    }
    
    int CallbackContext::init() {
        _monitor_context_ptr = std::make_shared<MonitorContext>();
        _fs_context_ptr = std::make_shared<FSContext>(&_context_arena);
        _callback_bak_request.CopyFrom(get_raw_callback_request());
        if (auto* raw_rsp_ptr = get_raw_callback_response(); raw_rsp_ptr != nullptr) {
            _callback_bak_response.CopyFrom(*(raw_rsp_ptr));
        }
	    return 0;
    }

    void  CallbackContext::gen_log_head() {
        const auto * aicallback_req = get_callback_request();
        _log_header.append("[").append(aicallback_req->reqid()).append("]");
        _log_header.append("[").append(std::to_string(aicallback_req->callbackslotinfo().slotid())).append("]");
        _log_header.append("[").append(aicallback_req->oaid()).append("]");
    }
    
    const phx::CallbackRequest& CallbackContext::get_raw_callback_request(){
         return *(get_request_context()->get_request<phx::CallbackRequest>());
    }


    phx::CallbackResponse* CallbackContext::get_raw_callback_response(){
         return get_request_context()->get_response<phx::CallbackResponse>();
    }

    const phx::CallbackRequest* CallbackContext::get_callback_request(){
        return &_callback_bak_request;
    }

    phx::CallbackRequest* CallbackContext::get_mutable_callback_request(){
        return &_callback_bak_request;
    }

    phx::CallbackRequest* CallbackContext::mutable_callback_request() {
        return get_request_context()->mutable_request<phx::CallbackRequest>();
    }

    phx::CallbackResponse* CallbackContext::get_callback_response(){
         return &_callback_bak_response;
    }

}//end core