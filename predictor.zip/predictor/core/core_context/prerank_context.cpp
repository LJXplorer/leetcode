#include "prerank_context.h"

namespace Core {
    // 初始化静态成员
    ThreadSafeMap<std::string, std::shared_ptr<std::mutex>> PrerankContext::_model_mutex_map;

    // 返回用户嵌入向量
    const std::vector<float> &Core::PrerankContext::UserEmbeddingVec() const {
        return user_embedding_vec_;
    }

    const std::vector<float> &Core::PrerankContext::CvrUserEmbeddingVec() const {
        return cvr_user_embedding_vec_;
    }

    // 返回可修改的用户嵌入向量
    std::vector<float> *PrerankContext::MutableUserEmbeddingVec() {
        return &user_embedding_vec_;
    }

    std::vector<float> *PrerankContext::MutableCvrUserEmbeddingVec() {
        return &cvr_user_embedding_vec_;
    }

    // 根据 creative_id 返回项目嵌入向量
    const std::vector<float> &Core::PrerankContext::ItemEmbeddingVec(const std::string &creative_id) const {
        auto it = items_embedding_vecs.find(creative_id);
        if (it != items_embedding_vecs.end()) {
            return it->second;
        }
        throw std::out_of_range("Creative ID not found");
    }

    // 根据 creative_id 返回可修改的项目嵌入向量
    std::vector<float> *Core::PrerankContext::MutableItemEmbeddingVec(const std::string &creative_id) {
        return &items_embedding_vecs[creative_id];
    }

    // 返回所有项目嵌入向量
    const std::unordered_map<std::string, std::vector<float>> &Core::PrerankContext::ItemEmbeddingVecs() const {
        return items_embedding_vecs;
    }

    // 返回可修改的所有项目嵌入向量
    std::unordered_map<std::string, std::vector<float>> *Core::PrerankContext::MutableItemEmbeddingVecs() {
        return &items_embedding_vecs;
    }
    bool PrerankContext::GetUsePrerank() const {
        return use_prerank_;
    }
    void PrerankContext::SetUsePrerank(bool use_prerank) {
        use_prerank_ = use_prerank;
    }

    // void PrerankContext::SetAbTestConfigJson(const nlohmann::json& config) {
    //   ab_test_config_json_ = config;
    // }

    std::shared_ptr<prerank::Config> PrerankContext::GetConfigPtr() {
        return config_ptr_;
    }

    void PrerankContext::SetConfigPtr(std::shared_ptr<prerank::Config> config_ptr) {
        this->config_ptr_ = config_ptr;
    }

    void PrerankContext::AddItemEmbSplitSuccessCount(int count) {
        this->item_emb_split_success_count_.fetch_add(count);
    }

    int PrerankContext::GetItemEmbSplitSuccessCount() {
        return this->item_emb_split_success_count_.load();
    }

    void PrerankContext::set_offline_embedding_dump (const bool is_dump) {
        _offline_embedding_dump = is_dump;
    }
    bool PrerankContext::get_offline_embedding_dump (){
        return _offline_embedding_dump;
    }
}// namespace Core