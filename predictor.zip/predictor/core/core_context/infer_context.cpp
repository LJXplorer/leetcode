#include "infer_context.h"

namespace Core {
    void InferContext::all_node(ExperimentModelType t){
        _split_map.insert({t,{}});
    }

    std::unordered_map<ExperimentModelInfo *, ModelInfer>& InferContext::get_node(ExperimentModelType t) {
        return _split_map[t];
    }

    void InferContext::alloc_model_infer(ExperimentModelType t, ExperimentModelInfo* m) {
        auto& model_map = get_node(t);
        model_map.insert({m, {}});
    }

    ModelInfer& InferContext::get_model_infer(ExperimentModelType t, ExperimentModelInfo* m) {
        return _split_map[t][m];
    }
}