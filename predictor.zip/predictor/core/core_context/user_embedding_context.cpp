#include "user_embedding_context.h"
#include "core/core_services/fe/model_info/model_info_manager.h"
#include <cstdint>
#include <string>
namespace Core {

    UserEmbeddingContext::UserEmbeddingContext() = default;
    UserEmbeddingContext::~UserEmbeddingContext() = default;

    const qinglongv2::UserEmbeddingRequest &UserEmbeddingContext::GetUserEmbeddingRequest() const {
        return *_bak_user_embedding_request;
    }

    qinglongv2::UserEmbeddingRequest *UserEmbeddingContext::MutableUserEmbeddingRequest() {
        return _bak_user_embedding_request;
    }

    const qinglongv2::UserEmbeddingResponse &UserEmbeddingContext::GetUserEmbeddingResponse() const {
        return *_bak_user_embedding_response;
    }

    qinglongv2::UserEmbeddingResponse *UserEmbeddingContext::MutableUserEmbeddingResponse() {
        return _bak_user_embedding_response;
    }
    const qinglongv2::UserEmbeddingRequest &UserEmbeddingContext::GetRawUserRequest() {
        return *(get_request_context()->get_request<qinglongv2::UserEmbeddingRequest>());
    }

    qinglongv2::UserEmbeddingRequest* UserEmbeddingContext::MutableRawUserRequest() {
        return get_request_context()->mutable_request<qinglongv2::UserEmbeddingRequest>();
    }

    qinglongv2::UserEmbeddingResponse *UserEmbeddingContext::GetRawUserResponse() {
        return get_request_context()->get_response<qinglongv2::UserEmbeddingResponse>();
    }

    // const std::string & UserEmbeddingContext::get_req_id() const {
    //     return GetUserEmbeddingRequest().reqid();
    // }

    // const std::string & UserEmbeddingContext::get_oaid() const {
    //     return GetUserEmbeddingRequest().oaid();
    // }
    // const std::string & UserEmbeddingContext::get_slot_id() const {
    //     return GetUserEmbeddingRequest().userembeddingrtfeatures().adunitid();
    // }
    // const std::string & UserEmbeddingContext::get_media_id() const {
    //     return GetUserEmbeddingRequest().userembeddingrtfeatures().mediaid();
    // }
    // const std::string & UserEmbeddingContext::get_query() const {
    //     return GetUserEmbeddingRequest().userembeddingrtfeatures().query();
    // }

    // const int32_t UserEmbeddingContext::get_user_embedding_version() const {
    //     return GetUserEmbeddingRequest().userembeddingversion();
    // }

    const int32_t UserEmbeddingContext::GetUserEmbeddingVersion() const {
        return GetUserEmbeddingRequest().userembeddingversion();
    }
    const std::string &UserEmbeddingContext::GetUserEmbeddingModelName() const {
        return GetUserEmbeddingRequest().userembeddingmodelname();
    }

    const std::string &UserEmbeddingContext::GetRealUserModelName() const {
        return _real_user_model_name;
    }

    const int32_t UserEmbeddingContext::GetAlgoSceneId() const {
        return static_cast<int32_t>(Info::ModelType::USER_EMBEDDING);
    }

    

    int UserEmbeddingContext::init() {
        _monitor_context_ptr = std::make_shared<MonitorContext>();
        _fs_context_ptr = std::make_shared<FSContext>(&_context_arena);
        _fe_context_ptr = std::make_shared<FeContext>(&_context_arena);
        _infer_context_ptr = std::make_shared<InferContext>(&_context_arena);
        _bak_user_embedding_request = google::protobuf::Arena::CreateMessage<qinglongv2::UserEmbeddingRequest>(&_context_arena);
        _bak_user_embedding_request->CopyFrom(GetRawUserRequest());
        _bak_user_embedding_response = google::protobuf::Arena::CreateMessage<qinglongv2::UserEmbeddingResponse>(&_context_arena);
        Info::ModelInfoManager::instance().get_emb_model_name(GetUserEmbeddingModelName(), Info::ModelType::USER_EMBEDDING, _real_user_model_name);
        return ERROR_SUCCESS;
    }

    void  UserEmbeddingContext::gen_log_head() {
        _log_header.append("[").append(GetUserEmbeddingRequest().reqid()).append("]");
        _log_header.append("[").append(GetUserEmbeddingRequest().oaid()).append("]");
        _log_header.append("[").append(GetUserEmbeddingRequest().userembeddingrtfeatures().adunitid()).append("]");
        _log_header.append("[").append(GetUserEmbeddingModelName()).append("]");
        _log_header.append("[").append(GetRealUserModelName()).append("]");
        _log_header.append("[").append(std::to_string(GetUserEmbeddingVersion())).append("]");
    }

}// namespace Core