#include "item_embedding_context.h"
#include "core/core_context/fe_context.h"
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "core/utils/error.h"
#include <google/protobuf/arena.h>
#include <memory>
#include <utility>
namespace Core {

    ItemEmbeddingContext::ItemEmbeddingContext() {
        
    }

    ItemEmbeddingContext::~ItemEmbeddingContext() {
        if(_is_offline_emb_task) {
            delete MutableRawRequest();
            delete GetRawResponse();
        }
    }

    const qinglongv2::ItemEmbeddingRequest &ItemEmbeddingContext::GetItemEmbeddingRequest() const {
        return *_bak_item_embedding_request;
    }

    qinglongv2::ItemEmbeddingRequest *ItemEmbeddingContext::MutableItemEmbeddingRequest() {
        return _bak_item_embedding_request;
    }

    const qinglongv2::ItemEmbeddingResponse &ItemEmbeddingContext::GetItemEmbeddingResponse() const {
        return *_bak_item_embedding_response;
    }

    qinglongv2::ItemEmbeddingResponse *ItemEmbeddingContext::MutableItemEmbeddingResponse() {
        return _bak_item_embedding_response;
    }
    const qinglongv2::ItemEmbeddingRequest &ItemEmbeddingContext::GetRawRequest() {
        return *(get_request_context()->get_request<qinglongv2::ItemEmbeddingRequest>());
    }

    qinglongv2::ItemEmbeddingRequest* ItemEmbeddingContext::MutableRawRequest() {
        return get_request_context()->mutable_request<qinglongv2::ItemEmbeddingRequest>();
    }

    qinglongv2::ItemEmbeddingResponse *ItemEmbeddingContext::GetRawResponse() {
        return get_request_context()->get_response<qinglongv2::ItemEmbeddingResponse>();
    }


    const std::string &ItemEmbeddingContext::GetItemEmbeddingModelName() const {
        return GetItemEmbeddingRequest().itemembeddingmodelname();
    }

    const std::string &ItemEmbeddingContext::GetRealItemModelName() const {
        return _real_item_model_name;
    }


    // void ItemEmbeddingContext::SetItemEmbeddingModelConfig(std::shared_ptr<FEConfig> model_config) {
    //     item_embedding_model_config = std::move(model_config);
    // }

    // std::shared_ptr<FEConfig> ItemEmbeddingContext::GetItemEmbeddingModelConfig() {
    //     return item_embedding_model_config;
    // }
    // auto ItemEmbeddingContext::GetSplitAdInfosIndex()
    //         -> const std::unordered_map<std::string, std::vector<ItemEmbeddingAdPair>> & {
    //     return split_ad_infos_index_;
    // }

    // auto ItemEmbeddingContext::MutableSplitAdInfosMap()
    //         -> std::unordered_map<std::string, std::vector<ItemEmbeddingAdPair>> * {
    //     return &split_ad_infos_index_;
    // }

    // auto ItemEmbeddingContext::MutableNodeSplitNumMap() -> std::unordered_map<Node *, std::shared_ptr<std::atomic<int>>> * {
    //     return &node_split_num_map_;
    // }

    // auto ItemEmbeddingContext::GetNodeSplitNumMap() const
    //         -> const std::unordered_map<Node *, std::shared_ptr<std::atomic<int>>> & {
    //     return node_split_num_map_;
    // }

    honor::retrieval::annindex::EmbeddingInfoData* ItemEmbeddingContext::MutableEmbeddingInfoData() {
        return &_embedding_info_data;
    }

    const honor::retrieval::annindex::EmbeddingInfoData& ItemEmbeddingContext::GetEmbeddingInfoData() {
        return _embedding_info_data;
    }

    const int32_t ItemEmbeddingContext::getItemEmbeddingVersion() const {
        return GetItemEmbeddingRequest().itemembeddingversion();
    }

    int ItemEmbeddingContext::init() {
        _monitor_context_ptr = std::make_shared<MonitorContext>();
        _fs_context_ptr = std::make_shared<FSContext>(&_context_arena);
        _fe_context_ptr = std::make_shared<FeContext>(&_context_arena);
        _infer_context_ptr = std::make_shared<InferContext>(&_context_arena);
        _bak_item_embedding_request = google::protobuf::Arena::CreateMessage<qinglongv2::ItemEmbeddingRequest>(&_context_arena);
        _bak_item_embedding_request->CopyFrom(GetRawRequest());
        _bak_item_embedding_response = google::protobuf::Arena::CreateMessage<qinglongv2::ItemEmbeddingResponse>(&_context_arena);
        Info::ModelInfoManager::instance().get_emb_model_name(GetItemEmbeddingModelName(), Info::ModelType::ITEM_EMBEDDING, _real_item_model_name);
        return ERROR_SUCCESS;
    }

    void ItemEmbeddingContext::gen_log_head() {
        _log_header.append("[").append(GetItemEmbeddingRequest().reqid()).append("]");
        _log_header.append("[").append(GetItemEmbeddingRequest().oaid()).append("]");
        _log_header.append("[").append(GetItemEmbeddingModelName()).append("]");
        _log_header.append("[").append(GetRealItemModelName()).append("]");
        _log_header.append("[").append(std::to_string(getItemEmbeddingVersion())).append("]");
    }

    const std::int32_t ItemEmbeddingContext::GetAlgoSceneId() const {
        return static_cast<int32_t>(Info::ModelType::ITEM_EMBEDDING);
    }

}// namespace Core