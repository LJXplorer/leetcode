#pragma once

#include "context_defs.h"
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "core/utils/defs.h"
#include "tf/flow.pb.h"
#include <cstddef>
#include <unordered_map>
namespace Core {
    enum class SlotDataType {
        UNKNOWN,
        INT_64,
        FLOAT,
        STRING,
    };

    inline std::string slotDataTypeToString(SlotDataType type) {
        static const std::unordered_map<SlotDataType, std::string_view> key_map = {
                {SlotDataType::UNKNOWN, "unknown"},
                {SlotDataType::INT_64, "int_64"},// 注意：这里应该是 "ctr" 还是 "dtr"？根据上下文我假设是 "dtr"
                {SlotDataType::FLOAT, "float"},
                {SlotDataType::STRING, "string"}};
        auto it = key_map.find(type);
        if (it != key_map.end()) {
            return std::string(it->second);
        } else {
            HILOG_APP(ERROR) << "unknown SlotDataType";
            return "unknown";
        }
    }
    struct SlotInfo {
        std::shared_ptr<std::vector<std::vector<int64_t>>> int_values;
        std::shared_ptr<std::vector<std::vector<float>>> float_values;
        std::shared_ptr<std::vector<std::vector<std::string>>> string_values;

        std::shared_ptr<std::vector<const google::protobuf::RepeatedField<int64_t> *>> int_values_repeated;
        std::shared_ptr<std::vector<const google::protobuf::RepeatedField<float> *>> float_values_repeated;
        std::shared_ptr<std::vector<const google::protobuf::RepeatedPtrField<std::string> *>> string_values_repeated;

        int64_t slot_id;
        SlotDataType slot_data_type = SlotDataType::UNKNOWN;
        SlotInfo() = default;

        SlotDataType get_data_type() const {
            return slot_data_type;
        }

        // 将一个 SlotInfo ，根据分包中需要的 item 个数，拆分成多段的 SlotInfo TODO: 后续可优化
        std::vector<SlotInfo> split(size_t batch_size) const {
            // HILOG_APP(INFO) << "split start, batch_size: " << batch_size;
            std::vector<SlotInfo> result;

            SlotDataType dataType = get_data_type();
            // HILOG_APP(INFO) << "dataType:" << slotDataTypeToString(dataType);

            switch (dataType) {
                case SlotDataType::INT_64: {
                    if (this->int_values) {
                        const auto &values = *this->int_values;
                        size_t total_size = values.size();
                        for (size_t i = 0; i < total_size; i += batch_size) {
                            SlotInfo new_slot_info;
                            new_slot_info.int_values = std::make_shared<std::vector<std::vector<int64_t>>>();
                            new_slot_info.slot_data_type = SlotDataType::INT_64;
                            for (size_t j = i; j < i + batch_size && j < total_size; ++j) {
                                new_slot_info.int_values->push_back(values[j]);
                            }
                            new_slot_info.slot_id = this->slot_id;
                            result.push_back(new_slot_info);
                        }
                    }
                    break;
                }
                case SlotDataType::FLOAT: {
                    if (this->float_values) {
                        const auto &values = *this->float_values;
                        size_t total_size = values.size();
                        for (size_t i = 0; i < total_size; i += batch_size) {
                            SlotInfo new_slot_info;
                            new_slot_info.float_values = std::make_shared<std::vector<std::vector<float>>>();
                            new_slot_info.slot_data_type = SlotDataType::FLOAT;
                            for (size_t j = i; j < i + batch_size && j < total_size; ++j) {
                                new_slot_info.float_values->push_back(values[j]);
                            }
                            new_slot_info.slot_id = this->slot_id;
                            result.push_back(new_slot_info);
                        }
                    }
                    break;
                }
                case SlotDataType::STRING: {
                    if (this->string_values) {
                        const auto &values = *this->string_values;
                        size_t total_size = values.size();
                        for (size_t i = 0; i < total_size; i += batch_size) {
                            SlotInfo new_slot_info;
                            new_slot_info.string_values = std::make_shared<std::vector<std::vector<std::string>>>();
                            new_slot_info.slot_data_type = SlotDataType::STRING;

                            for (size_t j = i; j < i + batch_size && j < total_size; ++j) {
                                new_slot_info.string_values->push_back(values[j]);
                            }
                            new_slot_info.slot_id = this->slot_id;
                            result.push_back(new_slot_info);
                        }
                    }
                    break;
                }
                default: {
                    HILOG_APP(ERROR) << "unknown slot data type";
                    break;
                }
            }
            // HILOG_APP(INFO) << "split end";
            return result;
        }

        void split(const int batch_num, const size_t batch_size, std::vector<std::shared_ptr<SlotInfo>> &result) const {
            // HILOG_APP(INFO) << "split start, batch_size: " << batch_size;
            SlotDataType dataType = get_data_type();
            // HILOG_APP(INFO) << "dataType:" << slotDataTypeToString(dataType);

            switch (dataType) {
                case SlotDataType::INT_64: {
                    if (this->int_values_repeated) {
                        const auto &values = *this->int_values_repeated;
                        size_t total_size = values.size();
                        for (size_t i = 0; i < batch_num; i++) {
                            result[i] = std::make_shared<SlotInfo>();
                            auto &new_slot_info_ptr = result[i];
                            new_slot_info_ptr->int_values_repeated =
                                    std::make_shared<std::vector<const google::protobuf::RepeatedField<int64_t> *>>();
                            new_slot_info_ptr->slot_data_type = SlotDataType::INT_64;
                            for (size_t j = i * batch_size; j < std::min(total_size, (i + 1) * batch_size); ++j) {
                                new_slot_info_ptr->int_values_repeated->push_back(values[j]);
                            }
                            new_slot_info_ptr->slot_id = this->slot_id;
                        }
                    }
                    break;
                }
                case SlotDataType::FLOAT: {
                    if (this->float_values_repeated) {
                        const auto &values = *this->float_values_repeated;
                        size_t total_size = values.size();
                        for (size_t i = 0; i < batch_num; i++) {
                            result[i] = std::make_shared<SlotInfo>();
                            auto &new_slot_info_ptr = result[i];
                            new_slot_info_ptr->float_values_repeated =
                                    std::make_shared<std::vector<const google::protobuf::RepeatedField<float> *>>();
                            new_slot_info_ptr->slot_data_type = SlotDataType::FLOAT;
                            for (size_t j = i; j < i + batch_size && j < total_size; ++j) {
                                new_slot_info_ptr->float_values_repeated->push_back(values[j]);
                            }
                            new_slot_info_ptr->slot_id = this->slot_id;
                        }
                    }
                    break;
                }
                case SlotDataType::STRING: {
                    if (this->string_values_repeated) {
                        const auto &values = *this->string_values_repeated;
                        size_t total_size = values.size();
                        for (size_t i = 0; i < batch_num; i++) {
                            result[i] = std::make_shared<SlotInfo>();
                            auto &new_slot_info_ptr = result[i];
                            new_slot_info_ptr->string_values_repeated = std::make_shared<
                                    std::vector<const google::protobuf::RepeatedPtrField<std::string> *>>();
                            new_slot_info_ptr->slot_data_type = SlotDataType::STRING;

                            for (size_t j = i; j < i + batch_size && j < total_size; ++j) {
                                new_slot_info_ptr->string_values_repeated->push_back(values[j]);
                            }
                            new_slot_info_ptr->slot_id = this->slot_id;
                        }
                    }
                    break;
                }
                default: {
                    HILOG_APP(ERROR) << "unknown slot data type";
                    break;
                }
            }
            // HILOG_APP(INFO) << "split end";
            return;
        }

        std::string to_string() const {
            std::ostringstream oss;
            oss << "SlotInfo { "
                << "slot_id: " << slot_id << ", "
                << "data_type: " << slotDataTypeToString(get_data_type()) << ", "
                << "int_values: ";

            if (int_values) {
                oss << "[";
                for (const auto &vec: *int_values) {
                    oss << "[";
                    for (const auto &val: vec) {
                        oss << val << ", ";
                    }
                    oss << "], ";
                }
                oss << "]";
            } else {
                oss << "nullptr";
            }

            oss << ", float_values: ";

            if (float_values) {
                oss << "[";
                for (const auto &vec: *float_values) {
                    oss << "[";
                    for (const auto &val: vec) {
                        oss << val << ", ";
                    }
                    oss << "], ";
                }
                oss << "]";
            } else {
                oss << "nullptr";
            }

            oss << ", string_values: ";

            if (string_values) {
                oss << "[";
                for (const auto &vec: *string_values) {
                    oss << "[";
                    for (const auto &val: vec) {
                        oss << val << ", ";
                    }
                    oss << "], ";
                }
                oss << "]";
            } else {
                oss << "nullptr";
            }

            if(int_values_repeated) {
                oss << "[";
                for (const auto &vec: *int_values_repeated) {
                    oss << "[";
                    for (const auto &val: *vec) {
                        oss << val << ", ";
                    }
                    oss << "], ";
                }
                oss << "]";
            }else {
                oss << "nullptr";
            }

            if(float_values_repeated) {
                oss << "[";
                for (const auto &vec: *float_values_repeated) {
                    oss << "[";
                    for (const auto &val: *vec) {
                        oss << val << ", ";
                    }
                    oss << "], ";
                }
                oss << "]";
            }else {
                oss << "nullptr";
            }

             if(string_values_repeated) {
                oss << "[";
                for (const auto &vec: *string_values_repeated) {
                    oss << "[";
                    for (const auto &val: *vec) {
                        oss << val << ", ";
                    }
                    oss << "], ";
                }
                oss << "]";
            }else {
                oss << "nullptr";
            }

            oss << " }";
            return oss.str();
        }

        size_t size() const {
            if (int_values) {
                return int_values->size();
            } else if (float_values) {
                return float_values->size();
            } else if (string_values) {
                return string_values->size();
            } else {
                return 0;
            }
        }

        //浅拷贝
        SlotInfo &operator=(const SlotInfo &other) {
            if (this != &other) {
                slot_id = other.slot_id;
                int_values = other.int_values;
                float_values = other.float_values;
                string_values = other.string_values;
                slot_data_type = other.slot_data_type;

                int_values_repeated = other.int_values_repeated;
                float_values_repeated = other.float_values_repeated;
                string_values_repeated = other.string_values_repeated;
            }
            return *this;
        }

        std::shared_ptr<SlotInfo> sub_slot_info(size_t start, size_t sub_size) const {
            auto slot_info_ptr = std::make_shared<SlotInfo>();
            SlotInfo &sub_slot_info = *slot_info_ptr;
            sub_slot_info.slot_data_type = this->slot_data_type;
            sub_slot_info.slot_id = this->slot_id;
            switch (sub_slot_info.slot_data_type) {
                case (SlotDataType::INT_64): {
                    sub_slot_info.int_values_repeated =
                            std::make_shared<std::vector<const google::protobuf::RepeatedField<int64_t> *>>();
                    sub_slot_info.int_values_repeated->reserve(sub_size);
                    for (size_t sub_idx = start; sub_idx < start + sub_size; sub_idx++) {
                        sub_slot_info.int_values_repeated->emplace_back(this->int_values_repeated->operator[](sub_idx));
                    }

                } break;
                case (SlotDataType::FLOAT): {
                    sub_slot_info.float_values_repeated =
                            std::make_shared<std::vector<const google::protobuf::RepeatedField<float> *>>();
                    sub_slot_info.float_values_repeated->reserve(sub_size);
                    for (size_t sub_idx = start; sub_idx < start + sub_size; sub_idx++) {
                        sub_slot_info.float_values_repeated->emplace_back(
                                this->float_values_repeated->operator[](sub_idx));
                    }
                } break;
                case (SlotDataType::STRING): {
                    sub_slot_info.string_values_repeated =
                            std::make_shared<std::vector<const google::protobuf::RepeatedPtrField<std::string> *>>();
                    sub_slot_info.string_values_repeated->reserve(sub_size);
                    for (size_t sub_idx = start; sub_idx < start + sub_size; sub_idx++) {
                        sub_slot_info.string_values_repeated->emplace_back(
                                this->string_values_repeated->operator[](sub_idx));
                    }

                } break;
                default:
                    break;
            }
            return slot_info_ptr;
        }
    };

    struct InferPair{
        int _start_index = 0;
        int _end_index = 0;
        int _ret=0;
        ::proto::flow::ModelPredictRequest* _request;
        ::proto::flow::ModelPredictResponse* _reponse;
        const ::proto::flow::PredictRequest *_predict_request;
        const ::proto::flow::PredictResponse *_predict_response;
        std::vector<float> _pos_score;
        float _pctr_scores;
        float _pcvr_scores;
        float _pdcvr_scores;
        float _pecvr_scores;
        float _pcvr1_scores;
        float _pcvr2_scores;
        float _ltv1_scores;
        float _ltv2_scores;
        int32_t _predict_ctr_success_cnt=0;
        int32_t _predict_cvr_success_cnt=0;
        int32_t _predict_pcvr1_success_cnt=0;
        int32_t _predict_pcvr2_success_cnt=0;
        int32_t _predict_deep_cvr_success_cnt=0;
        int32_t _predict_enhance_cvr_success_cnt=0;
        int32_t _predict_ltv1_success_cnt=0;
        int32_t _predict_ltv2_success_cnt=0;
        int32_t _predict_ctr_cnt=0;
        int32_t _predict_cvr_cnt=0;
        int32_t _predict_deep_cvr_cnt=0;
        int32_t _predict_enhance_cvr_cnt=0;
        int32_t _predict_pcvr1_cnt=0;
        int32_t _predict_pcvr2_cnt=0;
        int32_t _predict_ltv1_cnt=0;
        int32_t _predict_ltv2_cnt=0;
        int32_t _model_no_optput=0;
        int32_t _zero_ctr=0;
        int32_t _zero_cvr=0;
        int32_t _zero_dcvr=0;
        int32_t _zero_ecvr=0;

        int32_t _zero_pcvr1=0;
        int32_t _zero_pcvr2=0;
        int32_t _zero_ltv1=0;
        int32_t _zero_ltv2=0;


    };

    struct ModelInfer{        
        int32_t _total_item = 0;
        std::vector<phx::ItemFeature*> _items;
        std::vector<SlotInfo> _user_slot_list;
        std::vector<SlotInfo> _item_slot_list ;
        std::unordered_map<size_t, InferPair> _infer_pairs;
    };

    using InferSplitMap =
            std::unordered_map<ExperimentModelType,
                               std::unordered_map<ExperimentModelInfo *, ModelInfer>>;
    class InferContext {
    public:
        google::protobuf::Arena *_arena;
        InferSplitMap _split_map;

    public:
        InferContext(google::protobuf::Arena *arena) {
            this->_arena = arena;
        };

        virtual ~InferContext(){};
        void all_node(ExperimentModelType t);
        void alloc_model_infer(ExperimentModelType t, ExperimentModelInfo* m);
        std::unordered_map<ExperimentModelInfo *, ModelInfer>& get_node(ExperimentModelType t);
        ModelInfer& get_model_infer(ExperimentModelType t, ExperimentModelInfo* m);
    };

    using InferContextPtr = std::shared_ptr<InferContext>;
}// namespace Core