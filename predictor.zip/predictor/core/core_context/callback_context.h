#pragma once
#include "core/core_context/core_context.h"
#include "ranking/callback_service.pb.h"
#include <unordered_map>

namespace Core {

//feature dump 优化的callback service context
class CallbackContext : public Core::CoreContext {
public:
    phx::CallbackRequest _callback_bak_request;
    phx::CallbackResponse _callback_bak_response;
    int64_t mask = 1;
    int retry_cnt = 1;
    int origin_retry_cnt = 1;
    int64_t request_time = -1;
    bool is_skip = false;
    bool _ready_send = false;
    bool _dump_feature = false;
    
public:
    CallbackContext();
    ~CallbackContext();
    int init() override;
    void gen_log_head() override;
    const phx::CallbackRequest& get_raw_callback_request();
    phx::CallbackResponse* get_raw_callback_response();
    const phx::CallbackRequest* get_callback_request();
    phx::CallbackRequest* get_mutable_callback_request();
    phx::CallbackRequest* mutable_callback_request();
    phx::CallbackResponse* get_callback_response();
    void set_mask(int64_t& mask){this->mask = mask;}
    void set_retry_cnt(int& retry_cnt){this->retry_cnt = retry_cnt;}
    void set_origin_retry_cnt(int& origin_retry_cnt){this->origin_retry_cnt = origin_retry_cnt;}
};
using CallbackContextPtr = std::shared_ptr<CallbackContext>;

} // namespace Core