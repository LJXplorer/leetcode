#pragma once

#include "common/comm/threadsafe_map.h"
#include "context_defs.h"
#include "core/utils/service_pair.h"
#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <nlohmann/json.hpp>
#include <nlohmann/json_fwd.hpp>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

namespace Core {
    struct AdsPair;
    using AdsPairPtr = std::shared_ptr<AdsPair>;

    namespace prerank {
        class Config;
    }
    enum OfflineItemEmbTaskReason : int32_t {
        kUnknown = 0,
        kPeriodicTask = 1,
        kDictUpdate = 2,
        kInitialLaunch = 3,
    };

    class PrerankContext {
        google::protobuf::Arena *_arena;

        // user embedding
        std::vector<float> user_embedding_vec_;
        std::vector<float> cvr_user_embedding_vec_;
        // creative_id 到 item embedding的映射
        std::unordered_map<std::string, std::vector<float>> items_embedding_vecs;
        bool use_prerank_ = false;
        std::shared_ptr<prerank::Config> config_ptr_;// 解析的ab参数
        bool _offlien_embedding_lock = false;
        bool _offline_embedding_dump = false;
        std::atomic_int item_emb_split_success_count_{0};
        //std::unique_lock

    public:
        PrerankContext(google::protobuf::Arena *arena) : _arena(arena) {
        }
        virtual ~PrerankContext() {
            if (!item_dict_name_.empty()) {
                if (_offlien_embedding_lock) {
                    auto model_mutex = _model_mutex_map.get(item_dict_name_);
                    if (model_mutex) {
                        (*model_mutex)->unlock();
                    }
                }
            }
            if (!cvr_item_dict_name_.empty()) {
                if (_offlien_embedding_lock) {
                    auto model_mutex = _model_mutex_map.get(cvr_item_dict_name_);
                    if (model_mutex) {
                        (*model_mutex)->unlock();
                    }
                }
            }
        }

        phx::ExtractorResponse* user_extractor_response = nullptr;

        const nlohmann::json &GetAbTestConfigJson() const;
        void SetAbTestConfigJson(const nlohmann::json &config);
        bool GetUsePrerank() const;
        void SetUsePrerank(bool use_prerank);
        const std::vector<float> &UserEmbeddingVec() const;
        const std::vector<float> &CvrUserEmbeddingVec() const;
        std::vector<float> *MutableUserEmbeddingVec();
        std::vector<float> *MutableCvrUserEmbeddingVec();
        const std::vector<float> &ItemEmbeddingVec(const std::string &creative_id) const;
        std::vector<float> *MutableItemEmbeddingVec(const std::string &creative_id);
        const std::unordered_map<std::string, std::vector<float>> &ItemEmbeddingVecs() const;
        std::unordered_map<std::string, std::vector<float>> *MutableItemEmbeddingVecs();
        std::shared_ptr<prerank::Config> GetConfigPtr();
        void SetConfigPtr(std::shared_ptr<prerank::Config> config_ptr);
        std::unordered_map<int32_t, std::vector<ItemWrapper>> _offline_item_embedding_map;
        std::unordered_map<int32_t, phx::ExtractorResponse*> _offline_item_embedding_fe_response_map;
        std::shared_ptr<Info::ModelInfo> _offline_item_model_info;
        void LockMutexDict();
        void AddItemEmbSplitSuccessCount(int count = 1);
        int GetItemEmbSplitSuccessCount();
        void set_offline_embedding_dump (const bool is_dump);
        bool get_offline_embedding_dump ();
        std::unordered_map<int64_t, std::vector<float>> offline_items_embeddings;
        const std::vector<ItemWrapper> *get_split_list(const std::string & key);

        bool is_cvr_prerank_req = false;
        bool enable_skip_cvr_prerank = false;

        //在start service中填充
        std::string item_emb_model_name_;
        std::string user_emb_model_name_;
        //cvr模型
        std::string cvr_item_emb_model_name_;
        std::string cvr_user_emb_model_name_;

        std::string item_dict_name_;
        std::string cvr_item_dict_name_;
        int32_t max_common_version_;
        //在fs service中填充
        long emb_model_version_;
        long cvr_emb_model_version_;
        //在start service中填充
        std::vector<int32_t> items_creative_ids;
        //在truncation service中填充
        std::unordered_map<std::string, std::shared_ptr<std::vector<AdsPairPtr>>> truncated_results;
        // 静态成员变量，用于存储每个模型对应的锁
        static ThreadSafeMap<std::string, std::shared_ptr<std::mutex>> _model_mutex_map;
        //用于存储粗排截断模块完成时的系统时间，供monitor计算粗排整体耗时
        int64_t prerank_end_ts_ = 0;
        OfflineItemEmbTaskReason offline_item_emb_reason_;
        bool return_discarded_ads = true;
    };
    using PrerankContextPtr = std::shared_ptr<PrerankContext>;
}// namespace Core
