
#include "core/utils/util.h"
#include <unordered_map>
#include "core/core_context/monitor_context.h"
namespace Core  {

    int64_t BizLatency::get_request_lat(){
        return _req_end_tm - _req_begin_tm;
    }

    int64_t BizLatency::get_response_lat(){
        return _rsp_end_tm - _rsp_begin_tm;
    }
    int64_t BizLatency::get_lat(){
        return _rsp_end_tm - _req_begin_tm;
    }

    std::string BizLatency::toString(){
        std::ostringstream str;
        str<<"[req:"<<_req_begin_tm<<","<<_req_end_tm<<",rsp:"<<_rsp_begin_tm<<","<<_rsp_end_tm<<",lat<"<<get_request_lat()
            <<","<<get_response_lat()<<","<<get_lat()<<">]";
        return str.str();
    };
    
    BizLatencyGaurd::BizLatencyGaurd(BizLatency*lat,LatStage stage){
        m_lat = lat;
        m_stage = stage;
        if(m_lat != nullptr ){
            if(m_stage == LAT_STAGE_CREATE){
                m_lat->_req_begin_tm = gettimeofday_us();
            }else if(m_stage == LAT_STAGE_DESTROY){
                    m_lat->_rsp_begin_tm = gettimeofday_us();
            } 
        }
    }

    BizLatencyGaurd::~BizLatencyGaurd(){
        if(m_lat != nullptr ){
            if(m_stage == LAT_STAGE_CREATE){
                m_lat->_req_end_tm = gettimeofday_us();
            }else if(m_stage == LAT_STAGE_DESTROY){
                m_lat->_rsp_end_tm = gettimeofday_us();
            } 
        }
    } 

    void StatItem::report_int(const std::string&k,int v){
        _l_extra_map.insert({k,v});
    }

    void StatItem::report_float(const std::string&k,float v){
        _f_extra_map.insert({k,v});
    }

    void StatItem::report_string(const std::string&k,const std::string& v){
        _extra_map.insert({k,v});
    }

    void StatItem::report_redis_rpc(const std::string&k,int ret,int64_t lat,int32_t up_size, int64_t redis_response_size){
       auto it = _redis_extra_map.find(k);
       if(it == _redis_extra_map.end()) return;
       it->second._ret = ret;
       it->second._lat = lat;
       it->second._up_size = up_size;
       it->second._redis_response_size = redis_response_size;
    }

    void StatItem::report_up_rpc(const std::string&k, const std::string& cluster_id, int ret, int64_t feat_value_size, int64_t feat_response_size){
       auto it = _up_extra_map.find(k);
       if(it == _up_extra_map.end()) return;
       it->second._cluster_id = cluster_id;
       it->second._ret = ret;
       it->second._feat_size = feat_value_size;
       it->second._response_size = feat_response_size;
    }

    void StatItem::report_adjusted(const std::string&k, int adj_cnt, int total_cnt){
        AdjustedInfo adjusted_info(adj_cnt, total_cnt);
        _adjusted_extra_map.insert({k,adjusted_info});
    }

    MonitorContext::MonitorContext(){
    }
    
    MonitorContext::~MonitorContext(){
        
    }

    StatItemPtr MonitorContext::get_node_stat(const std::string&k){
        return _stat_pair[k];
    }

    void MonitorContext::alloc_node(const std::string&k,PredictType p){
        _stat_pair.insert({k,std::make_shared<StatItem>()});
    }

    std::unordered_map<std::string,StatItemPtr >& MonitorContext::get_stat_pair(){
        return _stat_pair;
    }
}//end core
