#ifndef _CORE_PREDICT_CONTEXT_H
#define _CORE_PREDICT_CONTEXT_H
#include "core/utils/util.h"
#include "tf/prediction_service.pb.h"
#include "core/utils/service_pair.h"
namespace Core  {

    using PredictServicePair = ServiceRequestResponsePair_Arena<::tensorflow::serving::PredictRequest,::tensorflow::serving::PredictResponse>;
    using PredictServiceBatchPair = ServiceBatchRequestResponsePair<::tensorflow::serving::PredictRequest,::tensorflow::serving::PredictResponse>;

    class PredictContext {
    private:
        //PredictType->split_index->PredictServicePair
        std::unordered_map<PredictType,std::unordered_map<std::string,PredictServicePair > > _predict_split;
    public:
        PredictContext(google::protobuf::Arena* arena);
        virtual ~PredictContext();
    public:
        google::protobuf::Arena* _arena;
        std::unordered_map<std::string,PredictServicePair >& get_node_batch(PredictType p = PREDICT_TYPE_UNKNOWN);
        void alloc_node(PredictType p );
        PredictServicePair& alloc_node_pair(const std::string&k,PredictType p = PREDICT_TYPE_UNKNOWN);
        PredictServicePair* get_node_pair(const std::string&k,PredictType p );
        const std::unordered_map<PredictType,std::unordered_map<std::string,PredictServicePair > >& get_predict_split(){
            return _predict_split;
        }

        std::unordered_map<PredictType,std::unordered_map<std::string,PredictServicePair > >& get_mutable_predict_split(){
            return _predict_split;
        }
    };
    
    using PredictContextPtr = std::shared_ptr<PredictContext>;
}

#endif
