
#include "core/core_context/core_context.h"
#include "core/core_context/fe_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/defs.h"
#include "core/utils/prehandle_query.h"
#include <log_helper.h>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
namespace Core {

    CoreContext::CoreContext() {
        _begin_ts = gettimeofday_ms();
        _end_ts = gettimeofday_ms();
    }

    CoreContext::~CoreContext() {
        if (_need_relase_rank_req_manually) {
            delete mutable_rank_request();
        }
        if (_need_release_rank_res_manually) {
            delete get_raw_response();
        }
    }

    int CoreContext::init() {
        _monitor_context_ptr = std::make_shared<MonitorContext>();
        _fs_context_ptr = std::make_shared<FSContext>(&_context_arena);
        _fe_context_ptr = std::make_shared<FeContext>(&_context_arena);
        _prerank_context_ptr = std::make_shared<PrerankContext>(&_context_arena);
        _infer_context_ptr = std::make_shared<InferContext>(&_context_arena);
        _bak_request.CopyFrom(get_raw_request());
        _bak_response = google::protobuf::Arena::CreateMessage<::phx::PredictorResponse>(get_context_arena());
        _bak_response_dump = google::protobuf::Arena::CreateMessage<::phx::PredictorResponseDump>(get_context_arena());

        return 0;
    }

    void CoreContext::gen_log_head() {
        _log_header.append("[").append(get_oaid()).append("]");
        _log_header.append("[").append(get_req_id()).append("]");
    }

    MonitorContextPtr CoreContext::get_monitor_context() {
        return _monitor_context_ptr;
    }

    FSContextPtr CoreContext::get_fs_context() {
        return _fs_context_ptr;
    }

    FeContextPtr CoreContext::get_fe_context() {
        return _fe_context_ptr;
    }

    InferContextPtr CoreContext::get_infer_context(){
        return _infer_context_ptr;
    }

    PrerankContextPtr CoreContext::get_prerank_context() {
        return _prerank_context_ptr;
    }

    const phx::PredictorRequest *CoreContext::get_rank_request() {
        return &_bak_request;
    }

    phx::PredictorRequest *CoreContext::get_mutable_rank_request() {
        return &_bak_request;
    }

    phx::PredictorRequest *CoreContext::mutable_rank_request() {
        return get_request_context()->mutable_request<phx::PredictorRequest>();
    }

    phx::PredictorResponse *CoreContext::get_rank_response() {
        return _bak_response;
    }

    const phx::PredictorRequest &CoreContext::get_raw_request() {
        return *(get_request_context()->get_request<phx::PredictorRequest>());
    }

    phx::PredictorResponse *CoreContext::get_raw_response() {
        return get_request_context()->get_response<phx::PredictorResponse>();
    }

    const std::string &CoreContext::get_oaid() {
        return get_rank_request()->oaid();
    }

    int64_t CoreContext::get_slot_id() {
        return get_rank_request()->predictorslotinfo().slotid();
    }

    int64_t CoreContext::get_pctr_in_pos_num() {
        return get_rank_request()->predictorslotinfo().pctrinposnum();
    }

    int32_t CoreContext::get_route() {
        return get_rank_request()->predictorslotinfo().route();
    }

    const std::string &CoreContext::get_req_id() {
        return get_rank_request()->reqid();
    }

    int64_t CoreContext::get_media_id() {
        return get_rank_request()->mediaid();
    }

    const std::string &CoreContext::get_query() {
        return get_rank_request()->query();
    }

    const std::string &CoreContext::get_handled_query() {
        return _handled_query;
    }

    void CoreContext::set_handled_query(const std::string &handled_query) {
        _handled_query = std::move(handled_query);
    }

    int32_t CoreContext::get_algo_scene_id() {
        return get_rank_request()->predictorslotinfo().algosceneid();
    }

    google::protobuf::Arena *CoreContext::get_context_arena() {
        return &_context_arena;
    }

    void CoreContext::set_predicttime(int64_t predict_time) {
        _predict_time = predict_time;
    }

    int64_t CoreContext::get_predicttime() {
        return _predict_time;
    }

    void CoreContext::set_ex_req(bool is_ex_req) {
        _is_ex_req = is_ex_req;
    }

    bool CoreContext::get_is_ex_req() {
        return _is_ex_req;
    }

    void CoreContext::set_has_missed_query(bool has_missed_query) {
        _has_missed_query = has_missed_query;
    }

    bool CoreContext::get_has_missed_query() {
        return _has_missed_query;
    }

    void CoreContext::set_dump_verify(bool dump_verify) {
        _dump_verify = dump_verify;
    }

    bool CoreContext::get_dump_verify() {
        return _dump_verify;
    }

    bool CoreContext::is_test_request() {
        auto &reqid = get_rank_request()->reqid();
        return !reqid.empty() && reqid[0] == '*';
    }

}// namespace Core
