#pragma once
#include "core/core_context/fe_context.h"
#include "core_context.h"
#include "ranking/embedding_service.pb.h"
#include "ranking/embedding_info.pb.h"
#include <cstdint>
#include <google/protobuf/arena.h>
#include <memory>
#include <unordered_map>
namespace Core {
    // struct ItemEmbeddingAdPair {
    //     const qinglongv2::EmbeddingAdInfo *ad_info;
    //     qinglongv2::ItemEmbedding *ad_embedding;
    // };
    struct EmbItemWrapper {
        const phx::PredictorItemInfo *item;
        const qinglongv2::EmbeddingAdInfo *ad_info;
        qinglongv2::ItemEmbedding *ad_embedding;
        EmbItemWrapper(const phx::PredictorItemInfo *item, const qinglongv2::EmbeddingAdInfo *ad_info, qinglongv2::ItemEmbedding *ad_embedding) : item(item), ad_info(ad_info), ad_embedding(ad_embedding) {
        }
    };
    class ItemEmbeddingContext : public CoreContext {
    private:
    
    public:
        qinglongv2::ItemEmbeddingRequest *_bak_item_embedding_request;
        qinglongv2::ItemEmbeddingResponse *_bak_item_embedding_response;
        int _embedding_size = 0;
        bool _is_offline_emb_task = false;
        honor::retrieval::annindex::EmbeddingInfoData _embedding_info_data;
        // std::shared_ptr<Core::FEConfig> _offline_item_emb_feconfig;
        std::unordered_map<std::string, honor::retrieval::annindex::EmbeddingInfo*> _offline_item_emb_info_map;
        // std::unordered_map<int64_t, ItemEmbeddingAdPair> _emb_ads_map;
        std::unordered_map<int32_t, std::vector<EmbItemWrapper>> _item_embedding_map;
        std::unordered_map<int32_t, phx::ExtractorResponse*> _item_embedding_fe_response_map;
        // std::unordered_map<Node *, std::shared_ptr<std::atomic<int>>> node_split_num_map_;
        std::string _offline_ad_embedding_info_path;
        std::string _real_item_model_name;
        std::shared_ptr<Info::ModelInfo> _item_emb_model_info;
        int32_t _model_req_cnt = 0;
        int32_t _model_success_cnt = 0;

    public:
        ItemEmbeddingContext();
        virtual ~ItemEmbeddingContext();

        const qinglongv2::ItemEmbeddingRequest &GetItemEmbeddingRequest() const;

        qinglongv2::ItemEmbeddingRequest *MutableItemEmbeddingRequest();

        const qinglongv2::ItemEmbeddingResponse &GetItemEmbeddingResponse() const;

        qinglongv2::ItemEmbeddingResponse *MutableItemEmbeddingResponse();

        const qinglongv2::ItemEmbeddingRequest &GetRawRequest();

        qinglongv2::ItemEmbeddingRequest* MutableRawRequest();

        qinglongv2::ItemEmbeddingResponse *GetRawResponse();


        // void SetItemEmbeddingModelConfig(std::shared_ptr<FEConfig> model_config);
        // std::shared_ptr<FEConfig> GetItemEmbeddingModelConfig();

        const std::string &GetItemEmbeddingModelName() const;

        const std::string &GetRealItemModelName() const;

        void SetRealItemModelName();

        const int32_t getItemEmbeddingVersion() const;

        // auto GetSplitAdInfosIndex() -> const std::unordered_map<std::string, std::vector<ItemEmbeddingAdPair>> &;

        // auto MutableSplitAdInfosMap() -> std::unordered_map<std::string, std::vector<ItemEmbeddingAdPair>> *;

        auto MutableNodeSplitNumMap() -> std::unordered_map<Node *, std::shared_ptr<std::atomic<int>>> *;

        auto GetNodeSplitNumMap() const -> const std::unordered_map<Node *, std::shared_ptr<std::atomic<int>>> &;

        honor::retrieval::annindex::EmbeddingInfoData* MutableEmbeddingInfoData();

        const honor::retrieval::annindex::EmbeddingInfoData& GetEmbeddingInfoData();

        const int32_t GetAlgoSceneId() const;

        int init() override;
        void gen_log_head() override;

        std::string GetUploadSlotName() {// 按值返回
            return STRING_DEFAULT;
        }
    };
    using ItemEmbeddingContextPtr = std::shared_ptr<ItemEmbeddingContext>;
}// namespace Core