#ifndef _CORE_UTILS_DEF_H
#define _CORE_UTILS_DEF_H
#include <atomic>
#include <unordered_map>
#include <vector>
#include <functional>
#include <memory>
#include <queue>
#include <set>
#include <string>
namespace Core {

    enum SCENEID{
        OWN_TRAFFIC_REC = 10001, // 自有流量-推荐基本场景
        OWN_TRAFFIC_SEARCH = 20001, // 自有流量-搜索基本场景
        UNION = 30001, // 联盟流量
        INTEGRATED_REC = 100013, // 融合场景-推荐
        APP_SUGGEST_REC = 100014, // App建议-推荐
        APP_STORE_REC = 100015, // 应用市场-推荐（包括应用市场，安装器，只能短信）
        UNION_YOUKU = 300011, // 联盟流量-优酷视频媒体
    };

    enum FeErrorCode{
        FE_NORMAL = 0,
        FE_SPLIT_EXTRASCTOR_ERROR = 1, // FE抽取异常
        FE_UNKNOWN_ERROR = 2, // FE抽取未知异常
    };
    
    enum PredictScoreStatus{
        PREDICT_SCORE_UNKOWN = 0,
        FE_FAIL = 1, // FE抽取失败
        PREDICT_SCORE_SCUCESS = 2, // 精排打分成功
        PREDICT_SCORE_FAIL = 3, // 精排打分失败
    };

    enum WatchPointType{
        MIXER_REQUEST = 0, // 商推给Mixer的请求
        MIXER_TO_PREDICTOR_REQUEST = 1, // Mixer给预估的请求
        PREDICTOR_REQUEST = 2, // 预估收到的请求
        PREDICTOR_FEATURE_DUMP = 3, // 预估featuredump
        CALLBACK_PROXY_REQUEST = 4, // 商推给CallbackProxy的请求
        CALLBACK_PROXY_RT_FEATURE = 5, // CallbackProxy从redis拿到的特征
        CALLBACK_TO_SERVICE_REQUEST = 6, // CallbackProxy给CallbackService的请求
        CALLBACK_SERVICE_REQUEST = 7, // CallbackService收到的请求
        CALLBACK_FEATURE_DUMP = 8,// CallbackService落的featuredump
        EXPERIMENT_INFO = 9,// 预估实验trace能力

    };

    enum DumpMessageType{
        SAMPLE_DUMP_UNKNOWN = 0,
        SAMPLE_DUMP_NORMAL_REQ_RES = 1, // 正常请求
        SAMPLE_DUMP_FEATUREDUMP = 2, // featuredump
        SAMPLE_DUMP_EXCEPTION_REQ_RES = 3, // 异常请求
        SAMPLE_DUMP_VERIFY = 4,//校验
        SAMPLE_DUMP_PREDICT = 5,//精排推理请求响应
    };

    const std::string STRING_EMPTY("");
    const std::string STRING_UNKNOWN("unknown");
    const std::string STRING_DEFAULT("default");
    const std::string STRING_TOTALUP("total_up");
    const std::string GRAPH_FEA("dump_fea");
    const std::string GRAPH_BASELINE_FEA("dump_fea");
    const std::string GRAPH_NO_FEA("no_dump_fea");
    const std::string GRAPH_CALLBACK("callback");
    const std::string GRAPH_EXTEND_FEA("dump_extend_fea");
    const std::string GRAPH_CONSIST_CHECK_SCORE("consist_check_score");
    
    //请求
    const std::string INDUSTTY_L1_CODE_EMPTY("IndustryL1Code");
    const std::string INDUSTTY_L2_CODE_EMPTY("IndustryL2Code");
    const std::string DEVICE_ID("deviceId");
    const std::string PKG_NAME("adCreativePkgName");
    const std::string RTA_ID("rtaId");
    const std::string KW_TYPE("kwType");
    const std::string KEY_WORD("keyword");
    const std::string RTA_URL_ID("rtaUrlId");
    const std::string GAME_DEFAULT_SLOT("game_default_slot");

    //report
    const std::string REQ_ITEM_COUNT("req_count");
    const std::string CPC_REQ_ITEM_COUNT("cpc_req_count");
    const std::string CPD_REQ_ITEM_COUNT("cpd_req_count");
    const std::string RSP_ITEM_COUNT("rsp_count");
    const std::string CPC_RSP_ITEM_COUNT("cpc_rsp_count");
    const std::string CPD_RSP_ITEM_COUNT("cpd_rsp_count");

    const std::string REQ_COST("req_cost");
    const std::string RSP_COST("rsp_cost");
    const std::string TOTAL_COST("total_cost");

    const std::string CTR_SCORE("ctr_score");
    const std::string CVR_SCORE("cvr_score");
    const std::string DEEP_CVR_SCORE("deep_cvr_score");
    const std::string ENHANCE_SCORE("enhance_score");
    //model
    const std::string experiment_name_cpc_ctr("ctr");
    const std::string experiment_name_cpc_cvr("cvr");

    const std::string experiment_name_cpd_ctr("dtr");
    const std::string experiment_name_cpd_cvr("cpd_cvr");
    static const std::vector<std::string> experiment_names = {experiment_name_cpc_ctr, experiment_name_cpc_cvr,
                                                              experiment_name_cpd_ctr, experiment_name_cpd_cvr};

    // prerank
    const std::string kPrerankExperimentName("prerank");
    const std::string kItemModelNameKey("prerank_item_model_name");
    const std::string kUserModelNameKey("prerank_user_model_name");
    const std::string kDefaultPrerankParamsKey("default");
    const std::string kMediaIdsToMatchKey("prerank_trunc_media_ids");

    //truncation
    const std::string PRERANK_TRUNC_KEEP_MIN_COUNT("prerank_trunc_count");
    const std::string PRERANK_TRUNC_MODEL_COUNT("prerank_model_count");
    const std::string PRERANK_PK_CANDIDATE("prerank_pk_candidate");
    const std::string PRERANK_TRUNC_NEW_COUNT("prerank_new_count");
    const std::string PRERANK_TRUNC_DEFAULT_PDTR("prerank_default_value");
    const std::string PRERANK_TRUNC_DEFAULT_STAT_DOWN_PRICE("prerank_trunc_default_stat_down_price");
    const std::string PRERANK_TRUNC_DEFAULT_PRED("prerank_trunc_default_pred");
    const std::string PRERANK_PD_FACTOR("prerank_pd_factor");
    const std::string PRERANK_ITEM_MODEL_NAME("prerank_ltr_item_model_name");
    const std::string PRERANK_USER_MODEL_NAME("prerank_ltr_user_model_name");
    const std::string PRERANK_COUNT("prerank_count");
    const std::string PRERANK_TRUNC_MEDIA_IDS("prerank_trunc_black_media_ids");
    const std::string CATEGORY_SORT_STRATEGY_MAP("category_sort_strategy_map");
    const std::string CATEGORY_SORT_CONTEXT_MAP("category_sort_context_map");
    const std::string CLASSIFY_STRATEGY_NAME("classify_strategy_name");
    const std::string MERGE_STRATEGY_NAME("merge_strategy_name");
    const std::string TRUNCATION_STRATEGY_NAME("truncation_strategy_name");
    const std::string HOLD_STRATEGY_NAME("hold_strategy_name");
    const std::string FALLBACK_STRATEGY_NAME("fallback_strategy_name");
    const std::string RETURN_DISCARDED_ADS("return_discarded_ads");

    // embedding
    const std::string kItemEmbeddingNameKey{"item_embedding"};
    const std::string kUserEmbeddingNameKey{"user_embedding"};
    const std::string kItemMultiOutputNameKey{"item_multi_emb"};
    const std::string kUserMultiOutputNameKey{"user_multi_emb"};


    //配置
    const std::string frame_graph_conf("graph_conf");
    const std::string frame_node_conf("node_conf");
    const std::string frame_trans_conf("trans_conf");
    const std::string kafka_conf("kafka_conf");
    const std::string redis_clent_conf("redis_client_conf");
    const std::string redis_fetch_conf("redis_fetch_conf");

    //redis group
    const std::string group_gamerecom("gamerecom");
    const std::string group_behavior_statistics("behavior_statistics");
    const std::string group_search_behavior_statistics("search_behavior_statistics");
    const std::string group_search_item_v4_statistics("search_item_v4_statistics");
    const std::string group_game_item_offline_feature("game_item_offline_feature");
    const std::string group_item_pay_statistics("item_pay_statistics");

    const std::string group_appmarket_if_apprecom_tag_akv("appmarket_if_apprecom_tag_akv");
    const std::string group_appmarket_if_appsearch_info_d("appmarket_if_appsearch_info_d");
    const std::string group_appmarket_search_cross_stats("appmarket_search_cross_stats");

    const std::string group_item_stats("stats");
    const std::string group_item_platform("platform");
    const std::string group_item_stats_hour("stats_hour");
    const std::string group_item_creative_pctr_nearline("creativeid_pctr_nearline");
    const std::string group_item_ad_stats("item_ad_stats");

    const std::string group_pkg_appmarket("pkg_appmarket");
    const std::string group_pkg_stats_hour("pkg_stats_hour");
    const std::string group_pkg_type1_stat_fs("type1_stats_fs");
    const std::string group_pkg_type2_stat_fs("type2_stats_fs");
    const std::string group_pkg_type3_stat_fs("type3_stats_fs");
    const std::string group_pkg_packagename_pctr_nearline("packagename_pctr_nearline");
    const std::string group_pkg_stats_fs_v2("pkg_stats_fs_v2");
    
    const std::string group_adunit_most("adunit_most");
    const std::string group_adunit_platform_type_offline("platform_type_offline");
    const std::string group_adunit_adunit_type_offline("adunit_type_offline");

    const std::string group_adunit_channel_type_offline("channel_type_offline");
    const std::string group_adunit_alliance_account_name_offline("alliance_account_name_offlin");
    const std::string group_adunit_platform_type_offine("platform_type_offine");
    const std::string group_adunit_platform_adunit_type("platform_adunit_type");
    
    const std::string group_media_stats("media_stats");
    const std::string group_media_scene("media_scene");
    const std::string group_media_feature("mediaid_feature");

    const std::string group_adunit_media_industry_name_l1_offline("media_industry_name_l1_offline");
    const std::string group_adunit_media_industry_name_l2_offline("media_industry_name_l2_offline");

    const std::string group_group_groupid_pctr_nearline("groupid_pctr_nearline");
    const std::string group_group_groupid_conversion_rate_offline("groupid_conversion_rate_offline");

    const std::string group_item_ad_stats_offline("item_ad_stats_offline");
    const std::string group_ad_pkg_adt("ad_pkg_adt");
    const std::string group_ad_pkg_adt_nl("ad_pkg_adt_nl");
    const std::string group_ad_pkg_nl("ad_pkg_nl");
    const std::string group_ad_pkg_intent("ad_pkg_intent");
    const std::string group_ad_pkg_cty("ad_pkg_cty");
    const std::string group_ad_pkg_prov("ad_pkg_prov");
    
    const std::string model_config_type_fc("fc");
    const std::string model_config_type_fe("fe");
    const std::string model_config_type_fe_fc("fefc");
    const std::string kFeatureSuffix{"_sd89OIcvNM7f"};
    const float DEFAULT_SCORE = 0.0;
    const std::string pod_ip("POD_IP");
    const std::string zone("ZONE");
    const std::string campus("CAMPUS");

    const std::string limit_prefix("limit");
    const std::string limit_metric("qps");

    //判断float为0的阈值
    const float epsilon = 1e-10;
    
    // 定义实验中的模型类型到其枚举编号的映射
    inline const std::unordered_map<std::string, int> kExpnameEnumNumberMapper = [] {
        std::unordered_map<std::string, int> tmp_map;
        tmp_map[experiment_name_cpc_ctr] = 1;
        tmp_map[experiment_name_cpc_cvr] = 2;
        tmp_map[experiment_name_cpd_ctr] = 3;
        tmp_map[experiment_name_cpd_cvr] = 4;
        return tmp_map;
    }();


    inline static const std::unordered_map<int, std::string> kNumberExpnameEnumMapper = [] {
        return std::unordered_map<int, std::string>{
            {1, experiment_name_cpc_ctr},
            {2, experiment_name_cpc_cvr},
            {3, experiment_name_cpd_ctr},
            {4, experiment_name_cpd_cvr},
        };
   }();


    const int PRINT_FEATURE_TENSOR_SOCRE = 3;  //打印特征、tensor和打分
    const int PRINT_AICALLBACK_INFO = 4; // 打印aicallback信息
    const int PRINT_EXTEND_INFO = 10;  //打印转化后的请求


    enum ServiceProtoType{
        SERVICE_PROTO_TYPE_UNKNOWN = 0,   //默认
        SERVICE_PROTO_TYPE_FS = 1,   //特征服务
        SERVICE_PROTO_TYPE_FE = 2,   //FE服务
        SERVICE_PROTO_TYPE_TF = 3,   //预估服务
    };

    enum ServiceStage{
        SERVICE_STAGE_UNKNOWN = 100,   //默认
        SERVICE_STAGE_START = 101,   //开始
        SERVICE_STAGE_FE = 102,   //FE
        SERVICE_STAGE_FS = 103,   //特征
        SERVICE_STAGE_PREDICT = 104,   //精排
        SERVICE_STAGE_DONE = 105,   //done
        SERVICE_STAGE_MONITOR = 106,   //监控
    };

    enum PredictType{
        PREDICT_TYPE_UNKNOWN = 0,   //ctr
        PREDICT_TYPE_CTR = 1,   //ctr
        PREDICT_TYPE_CVR = 2,   //cvr
        PREDICT_TYPE_DEEP_CVR = 3,   //deep cvr
        PREDICT_TYPE_ENCHANCED_CVR = 4,   //enchance cvr
        PREDICT_TYPE_ITEM_EMBEDDING = 5, //item embedding
        PREDICT_TYPE_USER_EMBEDDING = 6, 
        PREDICT_TYPE_ITEM_MULTI_OUTPUT = 7, // multi_output
        PREDICT_TYPE_USER_MULTI_OUTPUT = 8,
        PREDICT_TYPE_LTV = 9, // game ltv
        PREDICT_TYPE_MULTI_CVR = 10, // game multi cvr
        PREDICT_TYPE_CVR_USER_EMBEDDING = 11,//区别于上面的ctr
        PREDICT_TYPE_CVR_ITEM_EMBEDDING = 12,//区别于上面的ctr
    };

    enum FeaType{
        FEA_TYPE_USER,
        FEA_TYPE_ITEM,
        FEA_TYPE_BOTH,
    };

    enum FeType{
        FE_TYPE_USER,
        FE_TYPE_ITEM,
        FE_TYPE_BOTH,
        FE_TYPE_CROSS,
    };


    enum TypeEnum {
        STRING,
        INT,
        FLOAT
    };

    // honor_board_feed_list这个实时特征在fe链路喂给模型和featureDump出来，fc链路没有
    const std::unordered_map<std::string, TypeEnum> rtFeatureEnumMap = {
    {"userInstalledPkgName", TypeEnum::STRING},
    {"userInstalledPkgSize", TypeEnum::INT},
    {"useragent", TypeEnum::STRING},
    {"countrycode", TypeEnum::STRING},
    {"os", TypeEnum::STRING},
    {"osv", TypeEnum::STRING},
    {"model", TypeEnum::STRING},
    {"make", TypeEnum::STRING},
    {"devicetype", TypeEnum::STRING},
    {"screenwidth", TypeEnum::INT},
    {"screenheight", TypeEnum::INT},
    {"ppi", TypeEnum::INT},

    {"language", TypeEnum::STRING},
    {"orientation", TypeEnum::STRING},
    {"carrier", TypeEnum::STRING},
    {"connectiontype", TypeEnum::STRING},
    {"deviceid", TypeEnum::STRING},
    {"ip", TypeEnum::STRING},
    {"country", TypeEnum::STRING},
    {"region", TypeEnum::STRING},


    {"city", TypeEnum::STRING},
    {"honorlmt", TypeEnum::INT},
    {"devicemode", TypeEnum::INT},
    {"pt_h", TypeEnum::STRING},
    {"pt_w", TypeEnum::STRING},
    {"workday", TypeEnum::STRING},
    {"activation_flag",TypeEnum::STRING},
    {"launch_type",TypeEnum::STRING},


    {"request_scene_out",TypeEnum::STRING},
    {"traffic_tag_l1_id",TypeEnum::STRING},
    {"is_preload",TypeEnum::INT},
    {"industry_ids",TypeEnum::STRING},
    {"refresh_times",TypeEnum::INT},
    {"shake_switch",TypeEnum::INT},
    {"experiment_algo_id",TypeEnum::STRING},
    {"honor_board_feed_list",TypeEnum::STRING},

    {"track_ext",TypeEnum::STRING},
    {"activityId",TypeEnum::STRING},
    {"visitSource",TypeEnum::STRING},
    {"mainApp",TypeEnum::STRING},
    {"innerAdId",TypeEnum::STRING},
    {"pushId",TypeEnum::STRING},
    {"pluginV",TypeEnum::STRING},
    {"sessionId",TypeEnum::STRING},

    {"expIds",TypeEnum::STRING},
    {"mediaPkgName",TypeEnum::STRING},
    {"gaid",TypeEnum::STRING},
    {"cityCode",TypeEnum::STRING},
    {"oaid",TypeEnum::STRING},
    {"magicuiversion",TypeEnum::STRING},
    {"honoroaid",TypeEnum::STRING},
    {"honoroaidmd5",TypeEnum::STRING},
    {"xaid",TypeEnum::STRING},
    {"imei",TypeEnum::STRING},
    {"sdkVisitSrc",TypeEnum::STRING},
    {"timestampV2",TypeEnum::INT},
    {"xaidtypeV2",TypeEnum::INT},
    {"detailType",TypeEnum::INT},
    {"sourcePackageName",TypeEnum::STRING},
    {"ownPackageName",TypeEnum::STRING},
    {"installType",TypeEnum::INT},
    {"modeType",TypeEnum::INT}
  };

} //end Core

#endif
