#include "monitor_mgr.h"
#include "common/monitor/monitors.h"
#include "common/monitor/named_monitor.h"
#include <gflags/gflags_declare.h>
#include <string>
    namespace Core {
    DECLARE_string(az_info);
    monitor::PercentileMonitor* MonitorMgr::_model_percent_monitor = nullptr;
    monitor::DoubleCommonMonitor* MonitorMgr::_model_common_monitor = nullptr;
    monitor::PercentileMonitor* MonitorMgr::_stage_percent_monitor = nullptr;
    monitor::DoubleCommonMonitor* MonitorMgr::_stage_common_monitor = nullptr;
    monitor::PercentileMonitor* MonitorMgr::_redis_percent_monitor = nullptr;
    monitor::DoubleCommonMonitor* MonitorMgr::_redis_common_monitor = nullptr;
    monitor::DoubleCommonMonitor* MonitorMgr::_slot_policy_common_monitor = nullptr;
    monitor::DoubleCommonMonitor* MonitorMgr::_dict_common_monitor = nullptr;
    monitor::PercentileMonitor* MonitorMgr::_dict_percent_monitor = nullptr;

    std::list<std::string> sys_percent_keys = {"route", "stage","slot", "policy","sceneId","ret","az" };
    std::list<std::string> biz_key = { "model", "group", "ret","az","sceneId", "pos"};
    std::list<std::string> redis_keys = {"route", "group","ret","source", "sceneId", "up","az" };    
    std::list<std::string> slot_policy_key = {"route", "slot",  "policy","az" };
    std::list<std::string> dict_keys = {"dict_class", "dict_path", "dict_version","ret","az"};

    void MonitorMgr::init(const std::string& svr,const std::string&biz_rule,const std::string&slot_rule,
        const std::string&sys_rule,const std::string&redis_rule, const std::string&dict_rule){
        if(!biz_rule.empty()){
            _model_common_monitor = new monitor::CommonMonitor<double>(svr,biz_rule,
                                                biz_key,
                                                monitor::ADDER);
            _model_percent_monitor = new monitor::PercentileMonitor(svr,biz_rule,
                                                        biz_key);

        }
        if(!dict_rule.empty()) {
            _dict_common_monitor = new monitor::CommonMonitor<double>(svr,dict_rule,
                                                dict_keys,
                                                monitor::ADDER);
            _dict_percent_monitor = new monitor::PercentileMonitor(svr,dict_rule,
                                                        dict_keys);                                    
        }
        if(!sys_rule.empty()){
            _stage_percent_monitor = new monitor::PercentileMonitor(svr,sys_rule,
                                                        sys_percent_keys);
            _stage_common_monitor = new monitor::CommonMonitor<double>(svr,sys_rule,
                                                sys_percent_keys,
                                                monitor::ADDER);
        }

        if(!slot_rule.empty()) {
            _slot_policy_common_monitor = new monitor::CommonMonitor<double>(svr, slot_rule, slot_policy_key, monitor::ADDER);
        }

        if(!redis_rule.empty()){
            _redis_percent_monitor = new monitor::PercentileMonitor(svr,redis_rule,
                                                        redis_keys);
            _redis_common_monitor = new monitor::CommonMonitor<double>(svr, redis_rule, redis_keys, monitor::ADDER);
        }
        monitor::MonitorManager::getInstance().StartDump();
        return ;
    }

    void MonitorMgr::common_report_model(const std::string& model, const std::string& group, const std::string& sceneid, const std::string& pos, int ret, const std::string& metrics_name, double val){
        std::list<std::string> dim_val;
        dim_val.emplace_back(model);
        // 目前只有版本上报需要填充default信息，其余的上报都只上报default的group
        dim_val.emplace_back(group);
        dim_val.emplace_back(std::to_string(ret));
        dim_val.emplace_back(FLAGS_az_info);
        dim_val.emplace_back(sceneid);
        dim_val.emplace_back(pos);
        _model_common_monitor->push(dim_val,  metrics_name, val);
    }

    void MonitorMgr::percent_report_model(const std::string& model, const std::string& group, const std::string& sceneid, int ret , const std::string& metrics_name, double val){
        std::list<std::string> dim_val;
        dim_val.emplace_back(model);
        dim_val.emplace_back(group);
        dim_val.emplace_back(std::to_string(ret));
        dim_val.emplace_back(FLAGS_az_info);
        dim_val.emplace_back(sceneid);
        dim_val.emplace_back("default");
        _model_percent_monitor->push(dim_val, metrics_name, static_cast<long>(val));
    }

    void MonitorMgr::percent_report_model(const std::string& model, int ret , const std::string& metrics_name, double val){
        std::list<std::string> dim_val;
        dim_val.emplace_back(model);
        // 目前只有版本上报需要填充default信息，其余的上报都只上报default的group
        dim_val.emplace_back("default");
        dim_val.emplace_back(std::to_string(ret));
        dim_val.emplace_back(FLAGS_az_info);
        dim_val.emplace_back("default");
        dim_val.emplace_back("default");
        _model_percent_monitor->push(dim_val, metrics_name, static_cast<long>(val));
    }

    //广告位维度+策略的监控
   void MonitorMgr::common_report_slot(const std::string& route, const std::string& slot, const std::string& policy, const std::string& metrics_name, double val){
        std::list<std::string> dim_val;
        dim_val.emplace_back(route);
        dim_val.emplace_back(slot);
        dim_val.emplace_back("default");
        dim_val.emplace_back(FLAGS_az_info);
        _slot_policy_common_monitor->push(dim_val,  metrics_name, val);
    }
    
    void MonitorMgr::percent_report_stage(const std::string& route, const std::string& sceneid, const std::string& policy, const std::string& stage, const std::string& slot,int ret, const std::string& metrics_name, double val){
        std::list<std::string> dim_val;
        dim_val.emplace_back(route);
        dim_val.emplace_back(stage);
        dim_val.emplace_back(slot);
        dim_val.emplace_back("default");
        dim_val.emplace_back(sceneid);
        dim_val.emplace_back(std::to_string(ret));
        dim_val.emplace_back(FLAGS_az_info);
        _stage_percent_monitor->push(dim_val, metrics_name, static_cast<long>(val));
    }

    void MonitorMgr::common_report_stage(const std::string& route, const std::string& sceneid, const std::string& policy, const std::string& stage, const std::string& slot, int ret, const std::string& metrics_name, double val) {
        std::list<std::string> dim_val;
        dim_val.emplace_back(route);
        dim_val.emplace_back(stage);
        dim_val.emplace_back(slot);
        dim_val.emplace_back("default");
        dim_val.emplace_back(sceneid);
        dim_val.emplace_back(std::to_string(ret));
        dim_val.emplace_back(FLAGS_az_info);
        _stage_common_monitor->push(dim_val, metrics_name, val);
    }


    void MonitorMgr::redis_report_percent(const std::string& route, const std::string &group,
                int code,const std::string&metric,double metric_val,FsSource source, const std::string& sceneId, const std::string& up){
        std::list<std::string> dim_val;
        dim_val.emplace_back(route);
        dim_val.push_back(group);
        dim_val.push_back(std::to_string(code));

        dim_val.push_back(fsSourceToString(source));
        dim_val.push_back(sceneId);
        dim_val.push_back(up);
        dim_val.emplace_back(FLAGS_az_info);
        redis_report_percent(dim_val,metric,static_cast<long>(metric_val));
    }

    void MonitorMgr::redis_report_common(const std::string& route, const std::string &group,
                int code,const std::string&metric,double metric_val,FsSource source, const std::string& sceneId, const std::string& up){
        std::list<std::string> dim_val;
        dim_val.emplace_back(route);
        dim_val.push_back(group);
        dim_val.push_back(std::to_string(code));
        dim_val.push_back(fsSourceToString(source));
        dim_val.push_back(sceneId);
        dim_val.push_back(up);
        dim_val.emplace_back(FLAGS_az_info);
        _redis_common_monitor->push(dim_val, metric, metric_val);
    }

    void MonitorMgr::redis_report_percent(std::list<std::string>&dim_val,
            const std::string&metric,long metric_val){
        if(_redis_percent_monitor == nullptr) return;
         _redis_percent_monitor->push(dim_val,metric,static_cast<long>(metric_val));
    }

    void MonitorMgr::redis_report_percent_batch(std::list<std::string>&dim_val,
            const std::map<std::string,long>& metric_val){
        if(_redis_percent_monitor == nullptr) return;
        for(auto&m : metric_val){
            _redis_percent_monitor->push(dim_val,m.first,m.second);
        }
    }

    void MonitorMgr::common_report_dict(const std::string& dict_class, const std::string& dict_path,const std::string& version, int ret, const std::string& metrics_name, double val) {
        std::list<std::string> dim_val;
        dim_val.emplace_back(dict_class);
        dim_val.emplace_back(dict_path);
        dim_val.emplace_back(version);
        dim_val.emplace_back(std::to_string(ret));
        dim_val.emplace_back(FLAGS_az_info);
        _dict_common_monitor->push(dim_val, metrics_name, val);
    }

    void MonitorMgr::percent_report_dict(const std::string& dict_class, const std::string& dict_path, const std::string& version,int ret, const std::string& metrics_name, double val){
        std::list<std::string> dim_val;
        dim_val.emplace_back(dict_class);
        dim_val.emplace_back(dict_path);
        dim_val.emplace_back(version);
        dim_val.emplace_back(std::to_string(ret));
        dim_val.emplace_back(FLAGS_az_info);
        _dict_percent_monitor->push(dim_val, metrics_name, static_cast<long>(val));
    }
}