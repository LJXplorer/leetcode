#pragma once

#include <algorithm>
#include <butil/third_party/murmurhash3/murmurhash3.h>
#include <cstdint>
#include <iostream>
#include <random>
#include <string>
#include <vector>

class SamplingTool {
public:
    // 随机采样函数，从[start, end]区间内采样count个索引
    static void sampleIndices(int32_t start, int32_t end, int32_t count, std::vector<int32_t> &out_indices) {
        int32_t n = end - start + 1;
        if (count > n) {
            count = n;
        }
        out_indices.resize(n);
        for (int32_t i = 0; i < n; ++i) {
            out_indices[i] = start + i;
        }
        thread_local static std::mt19937 gen(std::random_device{}());
        std::shuffle(out_indices.begin(), out_indices.end(), gen);
        out_indices.resize(count);
    }
};
