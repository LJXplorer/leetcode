#ifndef _CORE_SERVICE_PAIR_H
#define _CORE_SERVICE_PAIR_H
#include "core/utils/util.h"
#include <cstdint>
#include <google/protobuf/arena.h>
#include <map>
#include <unordered_map>
namespace Core {
    
    template<typename REQUEST,typename RESPONSE>
    struct ServiceRequestResponsePair{
    public:
        REQUEST _request;
        REQUEST* _request_ptr = nullptr;
        RESPONSE _response;
        int64_t _start_tm = 0;
        int64_t _end_tm = 0;
        int32_t _ret = 0;
        int32_t _predict_item_cnt = 0;
        float _predict_score = 0;
        std::string _service_name;
    public:
        ServiceRequestResponsePair(){
            
        }

        ~ServiceRequestResponsePair(){

        }
        
        void set_service_request(REQUEST* r){
            _request_ptr = r;
        }

        REQUEST& get_service_request(){
            if(_request_ptr != nullptr) return *_request_ptr;
            return _request;
        }

        RESPONSE& get_service_response(){
            return _response;
        }
        
        void set_service_name(const std::string&n){
            _service_name = n;
        }

        const std::string& get_service_name(){
            return _service_name;
        }

    };

    template<typename REQUEST,typename RESPONSE>
    struct ServiceRequestResponsePair_Arena{
    public:
        REQUEST* _request;
        REQUEST* _request_ptr = nullptr;
        RESPONSE* _response;
        RESPONSE* _response2 = nullptr;
        int64_t _start_tm = 0;
        int64_t _end_tm = 0;
        int32_t _ret = 0;
        int32_t _predict_item_cnt = 0;
        int32_t _predict_ctr_success_cnt=0;
        int32_t _predict_cvr_success_cnt=0;
        int32_t _predict_deep_cvr_success_cnt=0;
        int32_t _predict_enhance_cvr_success_cnt=0;
        int32_t _predict_ltv_success_cnt=0;
        int32_t _score_zero_cnt = 0;
        float _predict_score = 0;
        int64_t _predict_time = 0;
        std::string _service_name;
        std::string _model_type;
        google::protobuf::Arena* _arena;
    public:
        ServiceRequestResponsePair_Arena() : _arena(nullptr) {
            _request = new REQUEST();
            _response = new RESPONSE();
            _response2 = new RESPONSE();
        }

        ServiceRequestResponsePair_Arena(google::protobuf::Arena* arena) : _arena(arena) {
            _request = google::protobuf::Arena::CreateMessage<REQUEST>(_arena);
            _response = google::protobuf::Arena::CreateMessage<RESPONSE>(_arena);
            _response2 = google::protobuf::Arena::CreateMessage<RESPONSE>(_arena);
        }

        virtual ~ServiceRequestResponsePair_Arena(){
            if (!_arena) {
                if (_request) {
                    delete _request;
                    _request = nullptr;
                }

                if (_response) {
                    delete _response;
                    _response = nullptr;
                }

                if (_response2) {
                    delete _response2;
                    _response2 = nullptr;
                }
            }
        }
        
        void set_service_request(REQUEST* r){
            _request_ptr = r;
        }

        REQUEST& get_service_request(){
            if(_request_ptr != nullptr) return *_request_ptr;
            return *_request;
        }

        RESPONSE& get_service_response(){
            return *_response;
        }
        
        void set_service_name(const std::string&n){
            _service_name = n;
        }

        const std::string& get_service_name(){
            return _service_name;
        }

        void set_model_type(const std::string&m){
            _model_type = m;
        }

        const std::string& get_model_type(){
            return _model_type;
        }

        void set_start_time(const int64_t s_t){
            _start_tm = s_t;
        }

        int64_t get_start_time(){
            return _start_tm;
        }

        void set_end_time(const int64_t e_t){
            _end_tm = e_t;
        }

        int64_t get_end_time(){
            return _end_tm;
        }

    };

    template<typename REQUEST,typename RESPONSE>
    struct ServiceBatchRequestResponsePair{
    public:
        std::map<std::string,ServiceRequestResponsePair<REQUEST,RESPONSE> > _batch;//index-><request，respons>
        int64_t _make_start_tm = 0;
        int64_t _make_end_tm = 0;
        int64_t _process_start_tm = 0;
        int64_t _process_end_tm = 0;
    public:    
        ServiceBatchRequestResponsePair(){

        }

        ~ServiceBatchRequestResponsePair(){

        }

        ServiceRequestResponsePair<REQUEST,RESPONSE>* get(const std::string&k){
            auto it = _batch.find(k);
            if(it == _batch.end()){ 
               return nullptr;
            }
            return it->second;
        }
        
        std::map<std::string,ServiceRequestResponsePair<REQUEST,RESPONSE> >& get_batch(){
            return _batch;
        }

        ServiceRequestResponsePair<REQUEST,RESPONSE>* alloc(const std::string&k){
            auto it = _batch.find(k);
            if(it == _batch.end()){ 
               auto&p = _batch[k];
               return &p;
            }
            return it->second;
        }


        void erase(const std::string&k){
            _batch.erase(k);
        }

        size_t batch_size(){
            return _batch.size();
        }
    };

} //end core

#endif
