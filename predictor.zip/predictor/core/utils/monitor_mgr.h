#ifndef _CORE_UTILS_MONITOR_H
#define _CORE_UTILS_MONITOR_H
#include <atomic>
#include <unordered_map>
#include <vector>
#include <functional>
#include <memory>
#include <queue>
#include <set>
#include <string>
#include "common/monitor/monitors.h"
namespace Core {

    enum class FsSource{
        UNKNOWN,LOCAL_CACHE,REDIS,AKV
    };
    inline const char* fsSourceNames[] = {"UNKNOWN", "LOCAL_CACHE", "REDIS","AKV"};
    inline std::string fsSourceToString(FsSource source) {
        return fsSourceNames[static_cast<int>(source)];
    }
    struct MonitorMgr{
    public:
        static void init(const std::string&svr,const std::string&biz_rule,const std::string&slot_rule,
            const std::string&sys_rule,const std::string&redis_rule, const std::string&dict_rule);
       
        static void redis_report_percent(const std::string& route, const std::string &group,
                int code,const std::string&metric,double metric_val,FsSource source, 
                const std::string& sceneId, const std::string& up);
        static void redis_report_percent(std::list<std::string>&dim_val,
            const std::string&metric,long metric_val);
        static void redis_report_common(const std::string& route, const std::string &group,
                int code,const std::string&metric,double metric_val,FsSource source, 
                const std::string& sceneId, const std::string& up);
        static void redis_report_percent_batch(std::list<std::string>&dim_val,
            const std::map<std::string,long>& metric_val);
        
        static void common_report_model(const std::string& model, const std::string& group, const std::string& sceneid, const std::string& pos, int ret, const std::string& metrics_name, double val);

        static void percent_report_model(const std::string& model, int ret , const std::string& metrics_name, double val);
        static void percent_report_model(const std::string& model, const std::string& group, const std::string& sceneid, int ret , const std::string& metrics_name, double val);

        static void common_report_slot(const std::string& route, const std::string& slot, const std::string& policy, const std::string& metrics_name, double val);
        
        static void percent_report_stage(const std::string& route, const std::string& sceneid, const std::string& policy, const std::string& stage, const std::string& slot, int ret, const std::string& metrics_name, double val);
        static void common_report_stage(const std::string& route, const std::string& sceneid, const std::string& policy, const std::string& stage, const std::string& slot, int ret, const std::string& metrics_name, double val);

        static void common_report_dict(const std::string& dict_class, const std::string& dict_path,const std::string& dict_version, int ret, const std::string& metrics_name, double val);
        static void percent_report_dict(const std::string& dict_class, const std::string& dict_path,const std::string& dict_version, int ret, const std::string& metrics_name, double val);
    
    public:
        static monitor::PercentileMonitor* _model_percent_monitor;
        static monitor::DoubleCommonMonitor* _model_common_monitor;

        static monitor::PercentileMonitor* _stage_percent_monitor;
        static monitor::DoubleCommonMonitor* _stage_common_monitor;

        static monitor::PercentileMonitor* _redis_percent_monitor;
        static monitor::DoubleCommonMonitor* _redis_common_monitor;
        static monitor::DoubleCommonMonitor* _slot_policy_common_monitor;

        static monitor::DoubleCommonMonitor* _dict_common_monitor;
        static monitor::PercentileMonitor* _dict_percent_monitor;

    
    };
}
#endif