#include "debug_param_manager.h"
#include <log_helper.h>
#include <mutex>
namespace debug {

    // 总是拷贝而非引用，避免外部修改本地维护的参数表
    nlohmann::json DebugParamManager::Get(const std::string &key) {
        // 读操作使用共享锁（允许多线程并发读）
        std::shared_lock lock(rd_mtx_);

        if (auto it = param_map_.find(key); it != param_map_.end()) {
            return it->second;
        }
        return {};// 返回空JSON对象表示未找到
    }

    nlohmann::json DebugParamManager::GetAll() {
        // 读操作使用共享锁（允许多线程并发读）
        std::shared_lock lock(rd_mtx_);
        return param_map_;
    }

    void DebugParamManager::Set(const std::string &key, const nlohmann::json &json_param) {
        std::unique_lock lock(rd_mtx_);
        param_map_[key] = json_param;// 直接覆盖整个JSON对象
    }

    void DebugParamManager::Update(const std::string &key, const nlohmann::json &json_param) {
        std::unique_lock lock(rd_mtx_);
        if (json_param.is_object()) {
            param_map_[key].update(json_param);
        } else {
            HILOG_APP(ERROR) << "do not update, key = [" << key << "], value = [" << json_param << "]";
        }
    }

    void DebugParamManager::Remove(const std::string &key) {
        std::unique_lock lock(rd_mtx_);
        param_map_.erase(key);
    }

}// namespace debug