#include "core/utils/util.h"
#include "core/utils/defs.h"
namespace Core {

    std::map<ServiceStage,std::string> ServiceConvertor::_service_stage_2_str;
    std::map<std::string,ServiceStage> ServiceConvertor::_service_str2_stage;
	std::map<PredictType,std::string> ServiceConvertor::_service_predict_2_str;
	std::map<std::string,PredictType> ServiceConvertor::_service_str_2_predict;
    std::map<ServiceProtoType,std::string> ServiceConvertor::_service_proto_2_str;
    std::map<std::string,ServiceProtoType> ServiceConvertor::_service_str_2_proto;		
    void ServiceConvertor::registerStage(){
        _service_stage_2_str.insert({SERVICE_STAGE_UNKNOWN,STRING_UNKNOWN});_service_str2_stage.insert({STRING_UNKNOWN,SERVICE_STAGE_UNKNOWN});
        _service_stage_2_str.insert({SERVICE_STAGE_START,"start"});_service_str2_stage.insert({"start",SERVICE_STAGE_START});
        _service_stage_2_str.insert({SERVICE_STAGE_FS,"fs"});_service_str2_stage.insert({"fs",SERVICE_STAGE_FS});
        _service_stage_2_str.insert({SERVICE_STAGE_FE,"fe"});_service_str2_stage.insert({"fe",SERVICE_STAGE_FE});
        _service_stage_2_str.insert({SERVICE_STAGE_PREDICT,"predict"});_service_str2_stage.insert({"predict",SERVICE_STAGE_PREDICT});
        _service_stage_2_str.insert({SERVICE_STAGE_DONE,"done"});_service_str2_stage.insert({"done",SERVICE_STAGE_DONE});
        _service_stage_2_str.insert({SERVICE_STAGE_MONITOR,"monitor"});_service_str2_stage.insert({"monitor",SERVICE_STAGE_MONITOR});
        
        //predict
         _service_predict_2_str.insert({PREDICT_TYPE_UNKNOWN,STRING_UNKNOWN});_service_str_2_predict.insert({STRING_UNKNOWN,PREDICT_TYPE_UNKNOWN});
        _service_predict_2_str.insert({PREDICT_TYPE_CTR,"ctr"});_service_str_2_predict.insert({"ctr",PREDICT_TYPE_CTR});
        _service_predict_2_str.insert({PREDICT_TYPE_CVR,"cvr"});_service_str_2_predict.insert({"cvr",PREDICT_TYPE_CVR});
        _service_predict_2_str.insert({PREDICT_TYPE_DEEP_CVR,"deep_cvr"});_service_str_2_predict.insert({"deep_cvr",PREDICT_TYPE_DEEP_CVR});
        _service_predict_2_str.insert({PREDICT_TYPE_ENCHANCED_CVR,"enchance_cvr"});_service_str_2_predict.insert({"enchance_cvr",PREDICT_TYPE_ENCHANCED_CVR});
        _service_predict_2_str.insert({PREDICT_TYPE_ITEM_EMBEDDING, "item_embedding"});_service_str_2_predict.insert({"item_embedding", PREDICT_TYPE_ITEM_EMBEDDING});
        _service_predict_2_str.insert({PREDICT_TYPE_USER_EMBEDDING, "user_embedding"});_service_str_2_predict.insert({"user_embedding",PREDICT_TYPE_USER_EMBEDDING});
        _service_predict_2_str.insert({PREDICT_TYPE_ITEM_MULTI_OUTPUT, "item_multi_output"});_service_str_2_predict.insert({"item_multi_output", PREDICT_TYPE_ITEM_MULTI_OUTPUT});
        _service_predict_2_str.insert({PREDICT_TYPE_USER_MULTI_OUTPUT, "user_multi_output"});_service_str_2_predict.insert({"user_multi_output", PREDICT_TYPE_USER_MULTI_OUTPUT});
        _service_predict_2_str.insert({PREDICT_TYPE_LTV, "ltv"});_service_str_2_predict.insert({"ltv", PREDICT_TYPE_LTV});
        _service_predict_2_str.insert({PREDICT_TYPE_CVR_USER_EMBEDDING, "cvr_user_embedding"});_service_str_2_predict.insert({"cvr_user_embedding", PREDICT_TYPE_CVR_USER_EMBEDDING});
        _service_predict_2_str.insert({PREDICT_TYPE_CVR_ITEM_EMBEDDING, "cvr_item_embedding"});_service_str_2_predict.insert({"cvr_item_embedding", PREDICT_TYPE_CVR_ITEM_EMBEDDING});
        _service_predict_2_str.insert({PREDICT_TYPE_MULTI_CVR, "multi_cvr"});_service_str_2_predict.insert({"multi_cvr", PREDICT_TYPE_MULTI_CVR});
        //proto
         _service_proto_2_str.insert({SERVICE_PROTO_TYPE_UNKNOWN,STRING_UNKNOWN});_service_str_2_proto.insert({STRING_UNKNOWN,SERVICE_PROTO_TYPE_UNKNOWN});
        _service_proto_2_str.insert({SERVICE_PROTO_TYPE_FS,"fs"});_service_str_2_proto.insert({"fs",SERVICE_PROTO_TYPE_FS});
        _service_proto_2_str.insert({SERVICE_PROTO_TYPE_FE,"fe"});_service_str_2_proto.insert({"fe",SERVICE_PROTO_TYPE_FE});
        _service_proto_2_str.insert({SERVICE_PROTO_TYPE_TF,"tf"});_service_str_2_proto.insert({"tf",SERVICE_PROTO_TYPE_TF});
    }

    const std::string& ServiceConvertor::stage2String(ServiceStage s){
        auto it = _service_stage_2_str.find(s);
        if(it == _service_stage_2_str.end()) return STRING_UNKNOWN;
        return it->second;
    }

    ServiceStage ServiceConvertor::string2Stage(const std::string& s){
        auto it = _service_str2_stage.find(s);
        if(it == _service_str2_stage.end()) return SERVICE_STAGE_UNKNOWN;
        return it->second;
    }


	const std::string& ServiceConvertor::predict2String(PredictType s){
		auto it = _service_predict_2_str.find(s);
		if(it == _service_predict_2_str.end()) return STRING_UNKNOWN;
		return it->second;
    }

	PredictType ServiceConvertor::string2predict(const std::string& s){
        auto it = _service_str_2_predict.find(s);
        if(it == _service_str_2_predict.end()) return PREDICT_TYPE_UNKNOWN;
        return it->second;
    }

    const std::string& ServiceConvertor::proto2String(ServiceProtoType s){
		auto it = _service_proto_2_str.find(s);
		if(it == _service_proto_2_str.end()) return STRING_UNKNOWN;
		return it->second;
    }

    ServiceProtoType ServiceConvertor::string2proto(const std::string& s){
        auto it = _service_str_2_proto.find(s);
        if(it == _service_str_2_proto.end()) return SERVICE_PROTO_TYPE_UNKNOWN;
        return it->second;
    }

} //end Core
