#include "prehandle_query.h"
#include "phx-fe/config/phx_config_utf8.h"
#include <cctype>

namespace Utf8Processing {

    const std::pair<uint32_t, size_t> Utf8Handler::_invalid_decode = {0xFFFD, 1};// 替换字符 �

    std::pair<uint32_t, size_t> Utf8Handler::decode_utf8(const std::string &str, const size_t pos) const {
        const uint8_t lead = static_cast<uint8_t>(str[pos]);
        int32_t width = phx_fe::Utf8BaseCompute::byte_width(str[pos]);
        // 越界检查
        if (pos + width > str.size()) {
            return _invalid_decode;
        }

        switch (width) {
            case 1:
                return {lead, 1};

            case 2:
                return {((lead & 0x1F) << 6) | (str[pos + 1] & 0x3F), 2};

            case 3:
                return {((lead & 0x0F) << 12) | ((str[pos + 1] & 0x3F) << 6) | (str[pos + 2] & 0x3F), 3};

            case 4:
                return {((lead & 0x07) << 18) | ((str[pos + 1] & 0x3F) << 12) | ((str[pos + 2] & 0x3F) << 6) |
                                (str[pos + 3] & 0x3F),
                        4};

            default:
                return _invalid_decode;
        }
    }

    std::string Utf8Handler::filter_utf8(const std::string &input) const {
        std::string output;
        output.reserve(input.size());
        size_t pos = 0;

        while (pos < input.size()) {
            // 解码当前字符
            std::pair<uint32_t, size_t> pair = decode_utf8(input, pos);

            // 合法字符处理
            if (phx_fe::Utf8BaseCompute::is_allowed_codepoint(pair.first)) {
                output.append(input.substr(pos, pair.second));
            }

            pos += pair.second;
        }

        // 将结果转换为小写
        std::transform(output.begin(), output.end(), output.begin(), ::tolower);

        return output;
    }

    std::string Utf8Handler::utf8_substr(const std::string &word, std::size_t pos, std::size_t n) const {
        std::string result;
        const char *c_str_ptr = word.c_str();
        const char *const c_str_end = c_str_ptr + word.length();
        while (pos && c_str_ptr < c_str_end) {
            std::size_t byte_wid = phx_fe::Utf8BaseCompute::byte_width(*c_str_ptr);
            if (c_str_ptr + byte_wid > c_str_end)
                break;
            c_str_ptr += byte_wid;
            --pos;
        }
        if (pos)
            return result;
        while (n && c_str_ptr < c_str_end) {
            std::size_t byte_wid = phx_fe::Utf8BaseCompute::byte_width(*c_str_ptr);
            if (c_str_ptr + byte_wid > c_str_end)
                break;
            result.append(c_str_ptr, byte_wid);
            c_str_ptr += byte_wid;
            --n;
        }
        return result;
    }

    std::string Utf8Handler::pre_handled_query(const std::string &query) const {
        // 先调用 filter_utf8 方法
        std::string filtered = filter_utf8(query);

        // 再调用 utf8_substr 方法
        std::string substring = utf8_substr(filtered, 0, 20);
        return substring;
    }
}// namespace Utf8Processing
