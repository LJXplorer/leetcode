#pragma once
#include <nlohmann/json.hpp>
#include <nlohmann/json_fwd.hpp>
#include <shared_mutex>
#include <unordered_map>

namespace debug {
    class DebugParamManager {

    private:
        // 私有构造函数
        DebugParamManager() = default;
        std::unordered_map<std::string, nlohmann::json> param_map_;
        std::shared_mutex rd_mtx_;

    public:
        // 禁用拷贝构造和赋值运算符
        DebugParamManager(const DebugParamManager &) = delete;
        DebugParamManager &operator=(const DebugParamManager &) = delete;

    public:
        // 使用magic static获取单例（C++11起线程安全）
        static DebugParamManager &GetInstance() {
            static DebugParamManager instance;// 线程安全的初始化
            return instance;
        }
        nlohmann::json Get(const std::string &key);
        nlohmann::json GetAll();
        void Set(const std::string &key, const nlohmann::json &json_param);
        void Update(const std::string &key, const nlohmann::json &json_param);
        void Remove(const std::string &key);
    };
}// namespace debug
