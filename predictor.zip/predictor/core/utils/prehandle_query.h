#ifndef PRE_HANDLE_QUERY_H
#define PRE_HANDLE_QUERY_H

#include <algorithm>
#include <cstdint>
#include <string>
#include <utility>

namespace Utf8Processing {

    class Utf8Handler {
    public:
        static const std::pair<uint32_t, size_t> _invalid_decode;

        std::string filter_utf8(const std::string &input) const;
        std::string utf8_substr(const std::string &word, std::size_t pos, std::size_t n = std::string::npos) const;
        std::string pre_handled_query(const std::string &query) const;

    private:
        std::pair<uint32_t, size_t> decode_utf8(const std::string &str, const size_t pos) const;
    };

}// namespace Utf8Processing

#endif// PRE_HANDLE_QUERY_H
