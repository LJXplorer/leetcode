#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <algorithm>
#include <cmath>
#include <vector>
#include <unordered_map>


namespace ScoreCmpUtils {
    
    // 转换为科学计数法，分别提取有效数字和指数部分
    std::pair<std::string, int> toScientificComponents(float value, int precision) {
        if (precision <= 0) return {"0", 0};
        std::ostringstream oss;
        oss.precision(precision - 1); 
        oss << std::scientific << value;
        std::string scientificStr = oss.str();

        size_t ePos = scientificStr.find('e');
        if (ePos == std::string::npos) {
            return {"0", 0};
        }

        std::string digitsStr = scientificStr.substr(0, ePos);
        digitsStr.erase(std::remove(digitsStr.begin(), digitsStr.end(), '+'), digitsStr.end());

        int exponent;
        std::string exponentStr = scientificStr.substr(ePos + 1);
        std::istringstream(exponentStr) >> exponent;

        return {digitsStr, exponent};
    }

    // 比较两个浮点数在指定有效数字位数内是否一致，并且指数部分也相同
    bool areScoresEqual(float a, float b, int precision_type, int precision) {
        if (precision_type == 0) {
            // 小数点位数作为精度
            double tolerance = std::pow(10.0, -precision);
            return std::abs(a - b) < tolerance;
        } else {
            // 有效数字作为精度
            auto [aDigits, aExponent] = toScientificComponents(a, precision);
            auto [bDigits, bExponent] = toScientificComponents(b, precision);
            return aDigits == bDigits && aExponent == bExponent;
        }
    }

    bool areEmbeddingsEqual(const std::vector<float>& emb1, const std::vector<float>& emb2, int precision_type, int precision) {
        if (emb1.size() != emb2.size()) return false;
        for (size_t i = 0; i < emb1.size(); i++) {
            if (!areScoresEqual(emb1[i], emb2[i], precision_type, precision)) {
                return false;
            }
        }
        return true;
    }

    bool areEmbeddingMapsEqual(
        const std::unordered_map<std::string, std::vector<float>>& emb_map1, 
        const std::unordered_map<std::string, std::vector<float>>& emb_map2,
        int precision_type, int precision) {
        if (emb_map1.size() != emb_map2.size()) return false;
        for (const auto& [target, emb1] : emb_map1) {
            auto it = emb_map2.find(target);
            if (it == emb_map2.end()) return false;
            const std::vector<float>& emb2 = it->second;
            if (!areEmbeddingsEqual(emb1, emb2, precision_type, precision)) {
                return false;
            }
        }
        return true;
    }
}
