#ifndef _CORE_UTILS_UTIL_H
#define _CORE_UTILS_UTIL_H
#include "core/utils/defs.h"
#include "core/utils/error.h"
#include <string>
#include <map>
#include <time.h>
#include <sys/time.h>
#include <sstream>
namespace Core {
class ServiceConvertor{
    private:
        static std::map<ServiceStage,std::string> _service_stage_2_str;
        static std::map<std::string,ServiceStage> _service_str2_stage;

        static std::map<PredictType,std::string> _service_predict_2_str;
        static std::map<std::string,PredictType> _service_str_2_predict;

        static std::map<ServiceProtoType,std::string> _service_proto_2_str;
        static std::map<std::string,ServiceProtoType> _service_str_2_proto;		
    public:
        ServiceConvertor(){
        }
        ~ServiceConvertor(){}
        public:
        static void registerStage();
        static const std::string& stage2String(ServiceStage s);
        static ServiceStage string2Stage(const std::string& s);

        static const std::string& predict2String(PredictType s);
        static PredictType string2predict(const std::string& s);

        static const std::string& proto2String(ServiceProtoType s);
        static ServiceProtoType string2proto(const std::string& s);


};


} //end Core

#endif
