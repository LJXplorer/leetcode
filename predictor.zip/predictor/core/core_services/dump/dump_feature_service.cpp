#include "core/core_context/core_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/dump/dump_redis_manager/dump_redis_manager.h"
#include "core/core_services/fs/redis_client/redis_client.h"
#include "core/core_services/fs/redis_client/redis_client_manager.h"
#include "hlframe/context.h"
#include "hlframe/graph_context.h"
#include "hlframe/register.h"
#include <brpc/controller.h>
#include <config_xml.h>
#include <cstdint>
#include <debug_utils.h>
#include <exception>
#include <glog/logging.h>
#include <log_helper.h>
#include <memory>
#include <string>
#include <unordered_map>
#include <wrapper_time.h>
#include <zstd.h> 
#include "core/core_services/dump/dump_feature_service.h"
namespace Core {
SERVICE_REGISTER(DumpFeatureService);

void DumpFeatureService::initialize(ConfigXmlPtr xml) {
    xml->attr<int32_t>("sample_verify2_ratio", _sample_verify2_ratio);
    xml->attr<int32_t>("max_sample_ratio", _max_sample_ratio, 0);
    initialize_xml(xml);
}

void DumpFeatureService::initialize_xml(ConfigXmlPtr xml) {
    xml->attr<int32_t>("dump_value_expire_time", _dump_value_expire_time, 60);
    xml->attr<int32_t>("dump_value_timeout_ms", _dump_value_timeout_ms, 100);
    xml->attr<int32_t>("dump_value_max_retry", _dump_value_max_retry, 0);
    xml->attr<std::string>("redis_client_id", _redis_client_id, "");
    xml->attr<std::string>("add_algosceneid", _add_algosceneid, "false");
}

void DumpFeatureService::initialize(GraphContextPtr ctx) {
    auto context = std::dynamic_pointer_cast<CoreContext>(ctx);
}

bool DumpFeatureService::skip(GraphContextPtr ctx) {
    return false;
}

int DumpFeatureService::do_service(GraphContextPtr context) {
    auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
    int32_t ret = 0;
    try { // 使用dump redis manager 异步处理
        DumpInfo* dump_info = new DumpInfo();
        dump_info->_ctx = ctx;
        dump_info->_service = this;
        if (ServerConfig::_dump_monitor_enable) {
            DumpRedisManager::dump_redis_counter << 1;
        }
        bool ret = DumpRedisManager::instance().push_to_data_queue(dump_info);
        if(!ret) {
            delete dump_info;
            if (ServerConfig::_dump_monitor_enable && DumpRedisManager::dump_redis_counter.get_value() > 0) {
                DumpRedisManager::dump_redis_counter << -1;
            }
        }
    } catch (const std::exception& e) {
        HILOG_APP(ERROR)<<LOG_HEAD(ctx) <<get_name() << " dump fe task submit to exector failed: " << ret << ","<<e.what();
        ret = -1;
    }
    return ret;
}

int DumpFeatureService::process(CoreContextPtr context) {
    int32_t ret = 0;
    try{
        BizLatency lat;
        {
            BizLatencyGaurd lat_guard(&lat,LAT_STAGE_CREATE);
            ret = dump(context);
        }
        {
            BizLatencyGaurd lat_guard(&lat,LAT_STAGE_DESTROY);
        }    
        // TODO: monitor  
        const std::string& route = std::to_string(context->get_route());
        const std::string& upload_aggrated_slotid = context->GetUploadSlotName();
        const std::string& algo_sceneId = std::to_string(context->get_algo_scene_id());

        for (auto policy: context->get_rank_request()->algoexperiments()) {
            MonitorMgr::percent_report_stage(route, algo_sceneId, policy.targetedpolicy(), get_name(), upload_aggrated_slotid, 0, "req_cost", lat.get_request_lat());
            MonitorMgr::percent_report_stage(route, algo_sceneId, policy.targetedpolicy(), get_name(), upload_aggrated_slotid, 0, "rsp_cost", lat.get_response_lat());
            MonitorMgr::percent_report_stage(route, algo_sceneId, policy.targetedpolicy(), get_name(), upload_aggrated_slotid, 0, "stage_total_cost", lat.get_lat());
        }
        
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << " dump exception:  " << e.what();
        ret = -1;
    }
    return ret;
}

int DumpFeatureService::dump(CoreContextPtr context) { 
    auto fs_ctx = context->get_fs_context();
    ::phx::FeRequest* fe_request = fs_ctx->get_feature_dump();

    if (is_verify2_sample(context)) {
        context->set_dump_verify(true);
        fe_request->set_verify_flag(2);

    }

    if(context->get_rank_request()->debuglevel() == 111) {
        debug::pb::SavePbToFile("phx_fe_snapshot.json", *fe_request);
    }
  
    int ret = dump_sink(context);
    return ret;
}

int DumpFeatureService::compress_value(const std::string& src, std::string& output) {
    size_t src_size = src.size();
    size_t compressed_size = ZSTD_compressBound(src_size);
    output.resize(compressed_size, '\0');
    compressed_size = ZSTD_compress( // success return compressed size, fail return error code
        output.data(), 
        compressed_size, 
        src.data(), 
        src_size, 
        3
    );
    if(ZSTD_isError(compressed_size)) {
        HILOG_APP(ERROR) << "ZSTD COMPRESS error: " << ZSTD_getErrorName(compressed_size);
        return -1;
    }
    output.resize(compressed_size);
    HILOG_APP(INFO) << "compressed_size: " << compressed_size << " , src.size(): " << src_size;
    return 0;
}

int DumpFeatureService::dump_sink(CoreContextPtr context) {
    auto fs_ctx = context->get_fs_context();
    ::phx::FeRequest* fe_request = fs_ctx->get_feature_dump();
    const auto* req = context->get_rank_request();
    const int32_t route = req->predictorslotinfo().route();
    std::string route_str = std::to_string(route);
    std::string slot_id;
    if (req->mediatype() == 2) {
        slot_id = "adsAffiliate";// 直接返回字面量
    }
    else {
        slot_id = req->predictorslotinfo().slotid();
    }
    std::shared_ptr<RedisClient> redis_client = RedisClientManager::instance().get_client(_redis_client_id);
    if(redis_client == nullptr) {
        HILOG_APP(ERROR) << LOG_HEAD(context) << "get redis client failed! client_id: " << _redis_client_id;
        return -1;
    }

    std::string algosceneId = std::to_string(context->get_algo_scene_id());
    std::string prefix("phx_");
    std::string key;
    if (_add_algosceneid == "true") {
        // redis_key: phx_{$reqid}_{$slotid}_{$algosceneid}
        key = prefix + context->get_req_id(); 
        key.append("_").append(std::to_string(context->get_slot_id()));
        key.append("_").append(std::to_string(context->get_algo_scene_id()));
    }
    else {
        // redis_key: phx_{$reqid}_{$slotid}
        key = prefix + context->get_req_id(); 
        key.append("_").append(std::to_string(context->get_slot_id()));
    }

    if(redis_client->_running) {
        std::string feature_str = fe_request->SerializeAsString();
        std::string compress_feature_str;
        int ret = compress_value(feature_str, compress_feature_str);
        if(ret != 0) {
            HILOG_APP(ERROR) << LOG_HEAD(context) << "compress failed!";
            context->set_ex_req(true);
            return -2;
        }
        int64_t feature_size = compress_feature_str.size();
        std::string& route_id = route_str;
        std::string& algo_sceneId = algosceneId;
        auto callback = [key, feature_size, route_id, algo_sceneId, context](std::shared_ptr<brpc::RedisResponse> rsp, std::shared_ptr<brpc::Controller> cntl) {
            // TODO: monitor
            HILOG_APP(WARNING) << key << " write done!!! ";
            MonitorMgr::redis_report_percent(route_id, "dump_feature_snapshot", cntl->ErrorCode(), "redis_total_cost",
                                                cntl->latency_us(), FsSource::REDIS, algo_sceneId, STRING_TOTALUP);
            MonitorMgr::redis_report_common(route_id, "dump_feature_snapshot", cntl->ErrorCode(), "fetch_num", 1, FsSource::REDIS,
                                            algo_sceneId, STRING_TOTALUP);
            MonitorMgr::redis_report_percent(route_id, "dump_feature_snapshot", cntl->ErrorCode(), "redis_response_size",
                                                feature_size, FsSource::REDIS, algo_sceneId, STRING_TOTALUP);
            if (cntl->ErrorCode() == 0) {
                MonitorMgr::redis_report_common(route_id, "dump_feature_snapshot", cntl->ErrorCode(), "fetch_success_num", 1,
                                                FsSource::REDIS, algo_sceneId, STRING_TOTALUP);
            }
        };

        int error_code = redis_client->set(
            key, 
            compress_feature_str.c_str(), 
            compress_feature_str.size(), 
            callback,
            _dump_value_timeout_ms,
            _dump_value_max_retry,
            _dump_value_expire_time
        );

        if(error_code != 0) {
            HILOG_APP(ERROR) << key << " write redis failed! with error code: " << error_code; 
            context->set_ex_req(true);
            return -3;
        }
        
    } else {
        HILOG_APP(ERROR) << "redis_client_id: " << _redis_client_id << " is not running!";
        context->set_ex_req(true);
        return -4;
    }
    return 0;
}


}