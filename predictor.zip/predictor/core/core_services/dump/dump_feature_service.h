#pragma once

#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"
#include <cstdint>
#include <string>
namespace Core {

class DumpFeatureService : public ServiceBaseInfo {
private:
    int32_t _dump_value_expire_time;
    int32_t _dump_value_timeout_ms;
    int32_t _dump_value_max_retry;
    int32_t _sample_verify2_ratio = 1; //校验点2采样上报比例
    std::string _redis_client_id;
    std::string _add_algosceneid;
    int32_t _max_sample_ratio = 10000; //校验点最大采样比例

    // hash
    int32_t _VERIFY2_SAMPLE_BASE = 10000;
    int32_t _SEED = 0x7f3a21eaL;

public:
    DumpFeatureService() = default;
    virtual ~DumpFeatureService() = default;

    virtual void initialize(ConfigXmlPtr xml) override;
    virtual void initialize_xml(ConfigXmlPtr xml);
    virtual void initialize(GraphContextPtr context) override;
    virtual bool skip(GraphContextPtr context) override;
    virtual int do_service(GraphContextPtr context) override;
    virtual int process(CoreContextPtr context) override;
    int dump(CoreContextPtr ctx);
    virtual int dump_sink(CoreContextPtr ctx);

    int32_t get_verify2_hash(const std::string& salt_str) {
        uint32_t out;
        butil::MurmurHash3_x86_32(salt_str.c_str(), salt_str.length(), _SEED, &out);
        return  out % _VERIFY2_SAMPLE_BASE;
    }

    bool is_verify2_sample(const CoreContextPtr &context) {
        int32_t hash_res = get_verify2_hash(context->get_req_id());
        if (_sample_verify2_ratio > 0) {
            return hash_res < _sample_verify2_ratio;
        }
        else {
            // max(prerank, ctr, cvr, ltv);
            const auto &tmp = std::max(context->_cvr_sample_ratio, context->_ctr_sample_ratio);
            const auto &tmp1 = std::max(context->_ltv_sample_ratio, tmp);
            const auto &max_sample_ratio = std::max(tmp1, context->_prerank_sample_ratio);
            return hash_res < std::min(max_sample_ratio, _max_sample_ratio);
        }
    }

private:
    int compress_value(const std::string& src, std::string& output);
};

}