#include "dump_redis_manager.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/fs/redis_client/redis_client_manager.h"
#include "core/utils/defs.h"
#include "core/utils/monitor_mgr.h"
#include <zstd.h>
namespace Core {
    DEFINE_int32(dump_redis_thread_num, 10, "dump_redis_thread_num");
    DumpRedisManager::DumpRedisManager(){
        _dump_thread_ids.resize(FLAGS_dump_redis_thread_num);
    }
    DumpRedisManager::~DumpRedisManager(){
    }

    void DumpRedisManager::init(){
        _data_queue = std::make_shared<boost::lockfree::queue<DumpInfo*>>(100000);
        for(int32_t i = 0;i < FLAGS_dump_redis_thread_num;i++){
            _dump_thread_ids[i] = std::thread(DumpRedisManager::handle, this);
            _dump_thread_ids[i].detach();
        }  
    }


    void DumpRedisManager::handle(DumpRedisManager* dump_redis_manager){  
        while(true) {
            DumpInfo* dump_info = nullptr;
            bool get = dump_redis_manager->_data_queue->pop(dump_info);
            
            if (get && dump_info != nullptr){
                dump_info->_service->process(dump_info->_ctx);
                if(dump_info != nullptr) {
                    delete dump_info;
                    if (ServerConfig::_dump_monitor_enable && DumpRedisManager::dump_redis_counter.get_value() > 0) {
                            DumpRedisManager::dump_redis_counter << -1;
                        }
                    dump_info = nullptr;
                }
            } else {
                usleep(1000);
                continue;
            }
        }  
    }
    bvar::Adder<int64_t> DumpRedisManager::dump_redis_counter{"oom", "dump_redis_count"};
    bool DumpRedisManager::push_to_data_queue(DumpInfo* data_info){
        if(data_info == nullptr){
            HILOG_APP(INFO)<<"arg,push_dump_to_queue null";
            return false;
        }
        MonitorMgr::redis_report_common(
            "HONOR", 
            "dump_redis_queue", 
            0, "push_num", 1, FsSource::REDIS, STRING_DEFAULT, STRING_TOTALUP);
        bool ret = _data_queue->bounded_push(data_info);
        if (!ret) {
            MonitorMgr::redis_report_common(
                          "HONOR", 
                          "dump_redis_queue", 
                          0, "push_failed_num", 1, FsSource::REDIS, STRING_DEFAULT, STRING_TOTALUP);
        }
        return ret;
    }
}