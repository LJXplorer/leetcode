#ifndef _CORE_REDIS_DUMP_MGR_H
#define _CORE_REDIS_DUMP_MGR_H
#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"
#include <boost/lockfree/queue.hpp>
#include <bvar/reducer.h>
namespace Core{
    struct DumpInfo{
        CoreContextPtr _ctx;
        ServiceBaseInfo* _service;
    };

    class DumpRedisManager{
    private:
        DumpRedisManager();
        ~DumpRedisManager();

    public:
        DumpRedisManager(const DumpRedisManager &) = delete;
        DumpRedisManager &operator=(const DumpRedisManager &) = delete;

        std::shared_ptr<boost::lockfree::queue<DumpInfo*>> _data_queue;
        std::vector<std::thread> _dump_thread_ids;

        void init();

        static DumpRedisManager& instance() {
            static DumpRedisManager inst;
            return inst;
        }

        static void handle(DumpRedisManager* mgr);
        static bvar::Adder<int64_t> dump_redis_counter;
        bool push_to_data_queue(DumpInfo* dataInfo);
    };

}//core
#endif