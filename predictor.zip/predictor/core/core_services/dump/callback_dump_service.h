#pragma once

#include "core/core_context/callback_context.h"
#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"
#include "core/utils/sampling.h"
#include <cstdint>
namespace Core {

    class CallbackDumpService : public ServiceBaseInfo {
    private:
        bool _retry_flag = false;
        std::string _dump_kafka_name; // 默认feature dump kafka（广告商店、游戏、体验）
        std::string _dump_kafka_key;
        std::string _scene_kafka_name; // 场景kafka对应关系
        int32_t _prerank_dump_end_policy = 100;
        int32_t _prerank_dump_base = 100;
        int32_t _prerank_samples_perRange = 10;
        int32_t _prerank_first_batch_size= 5;
        int32_t _SEED = 0x7f3a21eaL;
        int32_t _FE_SAMPLE_BASE = 1000;
        int32_t _ONE_HUNDRED = 100;
        //日志采样上报
        int32_t _sample_req_res_ratio = 1; // request、response采样上报比例
        int32_t _sample_fe_dump_ratio = 1; // fedump采样上报比例
        int32_t _sample_ex_req_ratio = 1; // 异常请求采样上报比例
        std::string _dump_req_res_kafka = "false";
        std::string _dump_fe_dump_kafka = "false";
        std::string _dump_ex_req_kafka = "false";
        //watchpoint上报
        int32_t _watch_point_ratio = 1; // watch point 采样上报比例
        std::string _watch_point_dump = "false"; // watch point是否上报
        std::string _watch_point_json = "false"; // watch point是否采用json上报
        //使用的kafka
        std::string _dump_log_kafka_name = "dump_log";
        std::string _dump_log_kafka_key = "dump_log";
        std::string _internal_watchpoint_kafka_name = "internal_watchpoint";
        std::string _internal_watchpoint_kafka_key = "internal_watchpoint";
        std::string _external_watchpoint_kafka_name = "external_watchpoint";
        std::string _external_watchpoint_kafka_key = "external_watchpoint";
        std::vector<std::pair<int32_t, int32_t>> _base_ranges;
        std::unordered_map<int32_t, std::string> _kafka_map; // scene，kafka_name

    public:
        CallbackDumpService() = default;
        ~CallbackDumpService() = default;

        virtual void initialize(ConfigXmlPtr xml) override;
        virtual void initialize_xml(ConfigXmlPtr xml);
        virtual void initialize(GraphContextPtr context) override;
        virtual bool skip(GraphContextPtr context) override;
        virtual int do_service(GraphContextPtr context) override;
        virtual int process(CoreContextPtr context) override;

        int dump(CallbackContextPtr ctx, std::string& kafka_name);
        bool is_prerank_sampled(const std::string &key) const {
            int32_t hash_res = get_hash(key);
            return hash_res < _prerank_dump_end_policy;
        }

        int32_t get_hash(const std::string &salt_str) const {
            uint32_t out;
            butil::MurmurHash3_x86_32(salt_str.c_str(), salt_str.length(), _SEED, &out);
            return out % _prerank_dump_base;
        }

        int32_t get_fe_hash(const std::string& salt_str) {
            uint32_t out;
            butil::MurmurHash3_x86_32(salt_str.c_str(), salt_str.length(), _SEED, &out);
            return  out % _FE_SAMPLE_BASE;
        }

        int32_t get_sample_hash(const std::string& salt_str) {
            uint32_t out;
            butil::MurmurHash3_x86_32(salt_str.c_str(), salt_str.length(), _SEED, &out);
            return  out % _ONE_HUNDRED;
        }

        bool is_req_res_sample(const std::string& req_id) {
            int32_t hash_res = get_sample_hash(req_id);
            return hash_res < _sample_req_res_ratio;
        }

        bool is_fe_dump_sample(const std::string& req_id) {
            int32_t hash_res = get_fe_hash(req_id);
            return hash_res < _sample_fe_dump_ratio;
        }

        bool is_ex_req_sample(const std::string& req_id) {
            int32_t hash_res = get_sample_hash(req_id);
            return hash_res < _sample_ex_req_ratio;
        }

        bool is_watchpoint_sample(const std::string& oaid) {
            int32_t hash_res = get_sample_hash(oaid);
            return hash_res < _watch_point_ratio;
        }

        void dump_watchpoint(CallbackContextPtr context, const phx::FeRequest& fe_dump);
        bool dump_watchpoint_sample(CallbackContextPtr context, const phx::CallbackRequest* req,
                             const phx::FeRequest& fe_dump, int32_t watchpoint_type, 
                             const std::string& kafka_key, const std::string& kafka_name);
        int dump_log(CallbackContextPtr context, const phx::FeRequest& fe_dump);//dump请求响应        
        bool dump_log_sample(CallbackContextPtr context, const phx::CallbackRequest* req, const phx::CallbackResponse* res,
                             const phx::FeRequest& fe_dump, int32_t message_type);
        bool dump_kafka_sample(CallbackContextPtr context, const phx::CallbackRequest* req, const phx::CallbackResponse* res,
                             const phx::FeRequest& fe_dump, int32_t message_type);
        std::string& get_kafka_name (CoreContextPtr context);

    private:
        void merge_feature(CallbackContextPtr ctx, ::phx::FeRequest &fe_dump, const std::string& slot_id, const std::string& route);
        void fill_prerank_features(CallbackContextPtr ctx, ::phx::FeRequest &fe_dump);
        std::string get_current_time();
        std::vector<const CallbackBiddingAd *> selectCallbackBiddingAds(const CallbackSlotInfo &slotInfo, bool isWinningAds);
        void fill_callback_item (CallbackContextPtr ctx, ::phx::FeRequest &fe_dump);
        void fill_callback_prerank_item(CallbackContextPtr ctx, ::phx::FeRequest &fe_dump, const std::unordered_map<int64_t, ::phx::ItemFeature *> &merged_item_fea_map);
        const phx::CallbackItemInfo* find_req_item_by_id (const phx::CallbackRequest* req, const int64_t creative_id);
    };

}// namespace Core