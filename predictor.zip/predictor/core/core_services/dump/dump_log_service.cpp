#include "core/core_services/dump/dump_log_service.h"
#include "butil/third_party/rapidjson/document.h"
#include "butil/third_party/rapidjson/stringbuffer.h"
#include "butil/third_party/rapidjson/writer.h"
#include "common/hikafka/kafka_helper.h"
#include "common/hilog/log_helper.h"
#include "common/monitor/monitor_logger.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/core_context.h"
#include "core/core_context/monitor_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/dump/dump_log_manager/dump_log_manager.h"
#include "core/core_services/dump/dump_manager/dump_manager.h"
#include "core/core_services/predict/utils/model_version.h"
#include "core/core_services/predict/predict_service.h"
#include "core/utils/monitor_mgr.h"
#include "third_party/protobuf/include/google/protobuf/util/json_util.h"
#include "util/base64.h"
#include "util/str.h"
#include <boost/algorithm/hex.hpp>
#include <boost/algorithm/string.hpp>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <thread_pool.h>
#include <vector>

namespace Core {
    DECLARE_string(az_info);
    SERVICE_REGISTER(DumpLogService);

    bvar::LatencyRecorder g_dump_verify_qps{"dump_log", "verify_qps"};

    void DumpLogService::initialize(ConfigXmlPtr xml) {
        xml->attr<int>("sample_req_res_ratio", _sample_req_res_ratio);
        xml->attr<std::string>("dump_req_res_kafka", _dump_req_res_kafka, "false");
        xml->attr<int>("sample_fe_dump_ratio", _sample_fe_dump_ratio);
        xml->attr<std::string>("dump_fe_dump_kafka", _dump_fe_dump_kafka, "false");
        xml->attr<int>("sample_ex_req_ratio", _sample_ex_req_ratio);
        xml->attr<std::string>("dump_ex_req_kafka", _dump_ex_req_kafka, "false");
        xml->attr<int>("sample_predict_ratio", _sample_predict_ratio, 0);

        xml->attr<int>("sample_verify2_ratio", _sample_verify2_ratio, 0);
        xml->attr<int>("verify_batch_sample_num", _verify_batch_sample_num, 0);
        xml->attr<std::string>("dump_old_verify", _dump_old_verify, "false");

        xml->attr<int>("watch_point_ratio", _watch_point_ratio);
        xml->attr<std::string>("watch_point_dump", _watch_point_dump, "false");
        xml->attr<std::string>("watch_point_json", _watch_point_json, "false");
        xml->attr("max_sample_ratio", _max_sample_ratio, 0);
        xml->attr("max_sample_qps", _max_sample_qps, 0);
        initialize_xml(xml);
    }

    void DumpLogService::initialize_xml(ConfigXmlPtr xml) {
        xml->attr<std::string>("dump_log_kafka_name", _dump_log_kafka_name);
        xml->attr<std::string>("dump_log_kafka_key", _dump_log_kafka_key);
        xml->attr<std::string>("internal_watchpoint_kafka_name", _internal_watchpoint_kafka_name);
        xml->attr<std::string>("internal_watchpoint_kafka_key", _internal_watchpoint_kafka_key);
        xml->attr<std::string>("external_watchpoint_kafka_name", _external_watchpoint_kafka_name);
        xml->attr<std::string>("external_watchpoint_kafka_key", _external_watchpoint_kafka_key);
        xml->attr<std::string>("dump_missed_query_kafka_name", _dump_missed_query_kafka_name, "");
        xml->attr<std::string>("dump_missed_query_kafka_key", _dump_missed_query_kafka_key, "");
        xml->attr<std::string>("dump_verify_kafka_name", _dump_verify_kafka_name, "");
        xml->attr<std::string>("dump_verify_kafka_key", _dump_verify_kafka_key, "");
    }

    void DumpLogService::initialize(GraphContextPtr context) {
        // auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        // ctx->get_monitor_context()->alloc_node(get_name(),get_predict_type());
        // ctx->get_monitor_context()->alloc_node(get_name());
    }

    int DumpLogService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int32_t ret = 0;
        try {
            DumpLogArgs *dump_arg = new DumpLogArgs();
            dump_arg->_dump_type = DUMP_LOG_LOG;
            dump_arg->_ctx = ctx;
            dump_arg->_service = this;
            if (ServerConfig::_dump_monitor_enable) {
                DumpLogManager::dump_log_counter << 1;
            }

            DumpLogManager::instance().push_dump_log_to_queue(dump_arg);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << "dump log task submit to exector fail: " << ret << ","
                             << e.what();
        }
        return ret;
    }

    int DumpLogService::process(CoreContextPtr context) {
        try {
            const phx::PredictorRequest *req = context->get_rank_request();
            BizLatency lat;
            //离线粗排上报校验点
            if (context->get_prerank_context()->get_offline_embedding_dump()) {
                {
                    BizLatencyGaurd lat_guard(&lat, LAT_STAGE_CREATE);
                    // 老链路上报
                    if (_dump_old_verify == "true" ) {
                        dump_offline_log(context); 
                    }
                    // 新链路上报
                    dump_offline_log_new(context); 
                }
                {
                    BizLatencyGaurd lat_guard(&lat, LAT_STAGE_DESTROY);
                }

            }
            else {
                {
                    BizLatencyGaurd lat_guard(&lat, LAT_STAGE_CREATE);
                    if (context->get_has_missed_query()) {
                        //大模型query未命中上报
                        dump_missed_query(context);
                    }
                    dump_log(context);
                }
                {
                    BizLatencyGaurd lat_guard(&lat, LAT_STAGE_DESTROY);
                    dump_watchpoint(context);
                }
            }

            // dump log阶段耗时上报
            const std::string &route = std::to_string(context->get_route());
            const std::string &upload_aggrated_slotid = context->GetUploadSlotName();
            const std::string& algo_sceneId = std::to_string(context->get_algo_scene_id());
            for (auto policy: context->get_rank_request()->algoexperiments()) {
                MonitorMgr::percent_report_stage(route,algo_sceneId, policy.targetedpolicy(),get_name(), upload_aggrated_slotid, 0, "req_cost",
                                             lat.get_request_lat());
                MonitorMgr::percent_report_stage(route,algo_sceneId, policy.targetedpolicy(), get_name(), upload_aggrated_slotid, 0, "rsp_cost",
                                                lat.get_response_lat());
                MonitorMgr::percent_report_stage(route, algo_sceneId, policy.targetedpolicy(), get_name(), upload_aggrated_slotid, 0, "stage_total_cost",
                                                lat.get_lat());
            }
            
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << "do dump log service fail: " << e.what();
        }

        return ERROR_SUCCESS;
    }

    std::string DumpLogService::get_current_time() {
        // 获取当前时间点
        auto now = std::chrono::system_clock::now();
        // 转换为time_t类型，以便使用std::put_time进行格式化
        auto now_c = std::chrono::system_clock::to_time_t(now);
        // 将time_t转换为tm结构体
        std::tm now_tm = *std::localtime(&now_c);

        // 使用stringstream进行格式化
        std::stringstream ss;
        ss << std::put_time(&now_tm, "%Y-%m-%d %H:%M:%S");
        return ss.str();
    }

    bool DumpLogService::dump_log_sample(CoreContextPtr context, const phx::PredictorRequest *req,
                                         const phx::PredictorResponse *res, const phx::FeRequest *fe_dump,
                                         int32_t message_type) {
        std::string result;
        static const std::string sep = "|";

        result.append(get_current_time());
        result.append(sep);
        result.append(ServerConfig::_monitor_service_name);
        result.append(sep);
        result.append(std::to_string(req->predictorslotinfo().scenetype()));
        result.append(sep);
        result.append(req->algotraceid());
        result.append(sep);
        result.append(std::to_string(req->predictorslotinfo().slotid()));
        result.append(sep);
        result.append(req->reqid());
        result.append(sep);
        result.append(req->oaid());
        result.append(sep);
        result.append(std::to_string(req->predictorslotinfo().route()));
        result.append(sep);
        result.append(FLAGS_az_info);
        result.append(sep);
        result.append(std::to_string(message_type));
        result.append(sep);
        if (message_type == SAMPLE_DUMP_NORMAL_REQ_RES) {
            std::string requestString;
            google::protobuf::util::MessageToJsonString(*req, &requestString);
            result.append(requestString);
            result.append(sep);
            std::string responseString;
            google::protobuf::util::MessageToJsonString(*res, &responseString);
            result.append(responseString);
            result.append(sep);
            std::string responseDumpStr;
            google::protobuf::util::MessageToJsonString(*context->_bak_response_dump, &responseDumpStr);
            result.append(responseDumpStr);
            result.append(sep);

        } else if (message_type == SAMPLE_DUMP_FEATUREDUMP) {
            std::string feature_dump_string;
            google::protobuf::util::MessageToJsonString(*fe_dump, &feature_dump_string);
            result.append(feature_dump_string);
            result.append(sep);
        } else if (message_type == SAMPLE_DUMP_EXCEPTION_REQ_RES) {
            std::string requestString;
            google::protobuf::util::MessageToJsonString(*req, &requestString);
            result.append(requestString);
            result.append(sep);
            std::string responseString;
            google::protobuf::util::MessageToJsonString(*res, &responseString);
            result.append(responseString);
            result.append(sep);
        } else {
            result.append(sep);
        }
        result.append(std::to_string(context->get_predicttime()));
        result.append(sep);
        result.append(std::to_string(context->get_begin_time()));
        Util::Str::replace_all(result, "\r\n", "");

        if (req->debuglevel() == 111) {
            std::string file_name = "log_sample_" + std::to_string(message_type) + ".json";
            std::ofstream outFile(file_name);
            if (outFile.is_open()) {
                outFile << result;
                outFile.close();
            } else {
                std::cerr << "DEBUGLEVEL 111 Failed to open file for writing log_sample.txt" << std::endl;
            }
        }

        monitor::details::MonitorLogger::getInstance().WriteToBigdataLogger(result);

        return true;
    }

    bool DumpLogService::dump_verify_sample(CoreContextPtr context, const phx::PredictorRequest *req,
                                           const phx::PredictorResponse *res, const phx::FeRequest *fe_dump,
                                           int32_t message_type) {
        try {
            std::string sample_message_str = "";
            std::vector<std::string> dump_data;

                const auto fe_split_map = context->get_fe_context()->GetSplit();
                for (const auto &[model_type, model_wrappers]: fe_split_map) {
                    for (const auto &[model, wrapper]: model_wrappers) {
                        int32_t start_index = 0;
                        std::vector<ItemWrapper> *item_wrappers = PredictService::get_item_wrappers(context, model, model_type);
                        
                        std::unordered_map<int64_t, std::vector<float>> pos_scores_map; // 按位预估score map
                        if(model->_model_info->_multi_pos_flag) {
                            auto infer_context = context->get_infer_context();
                            if(infer_context != nullptr) {
                                auto& model_infer = infer_context->get_model_infer(model_type, model);
                                auto& infer_pairs = model_infer._infer_pairs;
                                for(const auto& [index, pair] : infer_pairs) {
                                    const ::proto::flow::PredictResponse* rsp = pair._predict_response;
                                    if (rsp != nullptr) {
                                        std::unordered_map<std::string, ::proto::flow::ModelPredictResponse_PredictOutputTensor> tensor_map;
                                        auto &model_predict_responses = rsp->responses();//所有model_name所在的list
                                        for (const auto &model_predict_response: model_predict_responses) {
                                            if(model->_model_name == model_predict_response.model_name()) {
                                                for(const auto& output : model_predict_response.outputs()) {
                                                    tensor_map[output.name()] = output;
                                                }
                                                size_t output_size = model_predict_response.outputs_size();
                                                for(int item_index=pair._start_index; item_index<pair._end_index; ++item_index) {
                                                    int64_t cur_creative_id = (*item_wrappers)[item_index].item->creativeid();
                                                    int score_index = item_index - pair._start_index;
                                                    std::vector<float> score_vec(output_size);
                                                    for(int pos=0; pos<output_size; ++pos) {
                                                        float pos_score = tensor_map[std::to_string(pos)].values().float_val(score_index);
                                                        score_vec[pos] = pos_score;
                                                    }
                                                    pos_scores_map.insert({cur_creative_id, score_vec});
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        std::random_device rd;
                        std::mt19937 gen(rd());
                        std::unordered_set<int> selectedIndices; // 用于存储不重复的随机数

                        if (wrapper.size() > 3 && _verify_batch_sample_num < 10000) {
                            std::uniform_int_distribution<> dis(2, wrapper.size() - 2);
                            while (selectedIndices.size() < _verify_batch_sample_num) {
                                int index = dis(gen);
                                if (selectedIndices.find(index) == selectedIndices.end()) {
                                    selectedIndices.insert(index);
                                }
                                if (selectedIndices.size() == (wrapper.size() - 3)) {
                                    break;
                                }
                            }
                        }
                        
                        for (int i = 0; i < wrapper.size(); i++) {
                            if (i != 0) {
                                wrapper[i].extractor_response->mutable_user_features()->CopyFrom(wrapper[0].extractor_response->user_features());
                            }
                            const auto& wrapper_item = wrapper[i];
                            ::phx::VerifyInfoSample verify_info;
                            int32_t item_size = wrapper_item.items.size();
                            
                            if ((selectedIndices.find(i) == selectedIndices.end() && _verify_batch_sample_num < 10000
                                         && i != 0 && i != 1 && i != (wrapper.size()-1)) 
                                || model->_model_info == nullptr
                                || model->_model_info->_model_dict_collector == nullptr) {
                                start_index += item_size;
                                continue;
                            }

                            for (auto item: wrapper_item.items) {
                                phx::ItemFeature *verify_item = verify_info.mutable_item_ids()->Add();
                                verify_item->CopyFrom(*item);
                            }

                            for (const auto &[name, path]:
                                 model->_model_info->_model_dict_collector->_dict_name2path_map) {
                                auto dict = verify_info.add_dicts();
                                dict->set_name(name);
                                dict->set_path(path);
                                auto dict_info = model->_model_info->_model_dict_collector->get_dict(name);
                                dict->set_version(dict_info->m_task_info.version);
                            }

                            //model
                            verify_info.mutable_models()->mutable_model_name()->assign(model->_model_name);
                            verify_info.mutable_models()->mutable_fe_config_path()->assign(
                                    model->_model_info->get_model_path());
                            verify_info.mutable_models()->mutable_fe_config_md5()->assign(
                                    model->_model_info->_fe_config_content_md5);
                            int model_vesion =
                                    ModelVersion::instance().get_model_version(model->_model_info->get_name());
                            verify_info.mutable_models()->mutable_model_version()->assign(std::to_string(model_vesion));
                            if(model->_model_info->_multi_pos_flag) {
                                verify_info.mutable_models()->set_is_prepos(1);
                            }
                            //extractor response
                            verify_info.mutable_extractor_result()->CopyFrom(*wrapper_item.extractor_response);
                            //score
                            for (int i = start_index; i < start_index + item_size && i < (*item_wrappers).size(); i++) {
                                ::phx::ScoreInfo* score_info = verify_info.mutable_score()->Add();
                                if (model_type == ExperimentModelType::CPC_CTR || model_type == ExperimentModelType::CPD_CTR) {
                                    score_info->set_ctr((*item_wrappers)[i].item_data->pctr());
                                    if(model->_model_info->_multi_pos_flag && !pos_scores_map.empty()) { // 填充按位预估校验点3分数
                                        int64_t id = (*item_wrappers)[i].item->creativeid();
                                        auto it = pos_scores_map.find(id);
                                        if(it != pos_scores_map.end()) {
                                            for(const float score : it->second) {
                                                score_info->mutable_model_prepos()->Add(score);
                                            }
                                        }
                                        for (const auto& pctr : (*item_wrappers)[i].item_data->pctrinpos()) {
                                            score_info->add_prepos(pctr);
                                        }                                        
                                    }

                                }
                                else if (model_type == ExperimentModelType::CPC_CVR || model_type == ExperimentModelType::CPD_CVR) {
                                    score_info->set_cvr((*item_wrappers)[i].item_data->pcvr());
                                    score_info->set_deep((*item_wrappers)[i].item_data->pdcvr());
                                    score_info->set_enhance((*item_wrappers)[i].item_data->pecvr());
                                    score_info->set_cvr1((*item_wrappers)[i].item_data->pcvr1());
                                    score_info->set_cvr2((*item_wrappers)[i].item_data->pcvr2());
                                } else if (model_type == ExperimentModelType::LTV) {
                                    score_info->set_ltv1((*item_wrappers)[i].item_data->pltv1());
                                    score_info->set_ltv2((*item_wrappers)[i].item_data->pltv2());
                                }
                                    
                            }
                            start_index += item_size;
                            //fe_request
                            verify_info.mutable_fe_request()->CopyFrom(*fe_dump);
                            //algosceneid
                            verify_info.set_algoscene_id(req->predictorslotinfo().algosceneid());

                            if (req->debuglevel() == 111) {
                                std::string str;
                                google::protobuf::util::MessageToJsonString(verify_info, &str);
                                dump_data.emplace_back(str);
                            } else {
                                sample_message_str = "";
                                if (verify_info.SerializeToString(&sample_message_str)) {
                                    dump_data.emplace_back(sample_message_str);
                                }
                            }
                        }
                    }
                }
                //粗排
                {
                    ::phx::VerifyInfoSample verify_info;
                    std::string model_name = context->get_prerank_context()->user_emb_model_name_;
                    auto model_info = Info::ModelInfoManager::instance().get_model_info(model_name);
                    if (model_info != nullptr && model_info->_model_dict_collector != nullptr) {
                        for (auto& prerank_dump : *context->_bak_response_dump->mutable_responsedumpdata()) {
                            for(const auto& item : fe_dump->item_fea()) {
                                if(item.item_info().creative_id() == prerank_dump.creativeid()) {
                                    phx::ItemFeature *verify_item = verify_info.mutable_item_ids()->Add();
                                    verify_item->CopyFrom(item);
                                    break;
                                }
                            }
                        }
                        if (verify_info.item_ids_size() != 0) {//有item走粗排，才上报
                            //dict
                            for (const auto &[name, path]: model_info->_model_dict_collector->_dict_name2path_map) {
                                auto dict = verify_info.add_dicts();
                                dict->set_name(name);
                                dict->set_path(path);
                                auto dict_info = model_info->_model_dict_collector->get_dict(name);
                                dict->set_version(dict_info->m_task_info.version);
                            }
                            //model
                            verify_info.mutable_models()->mutable_model_name()->assign(model_name);                    
                            verify_info.mutable_models()->mutable_fe_config_path()->assign(model_info->_model_config_path);
                            verify_info.mutable_models()->mutable_fe_config_md5()->assign(model_info->_fe_config_content_md5);
                            int model_vesion = ModelVersion::instance().get_model_version(model_info->get_name());
                            verify_info.mutable_models()->mutable_model_version()->assign(std::to_string(model_vesion));
                            //extractor response
                            auto user_extractor_response = context->get_prerank_context()->user_extractor_response;
                            if (user_extractor_response != nullptr) {
                                verify_info.mutable_extractor_result()->CopyFrom(*user_extractor_response);
                            }
                            
                            //user_embedding
                            for (const auto& user_emb : context->get_prerank_context()->UserEmbeddingVec()) {
                                verify_info.add_user_embedding(user_emb);
                            }
                            //fe_request
                            verify_info.mutable_fe_request()->CopyFrom(*fe_dump);
                            //algosceneid
                            verify_info.set_algoscene_id(req->predictorslotinfo().algosceneid());
                            
                            if (req->debuglevel() == 111) {
                                std::string str;
                                google::protobuf::util::MessageToJsonString(verify_info, &str);
                                dump_data.emplace_back(str);
                            } else {
                                sample_message_str = "";
                                if (verify_info.SerializeToString(&sample_message_str)) {
                                    dump_data.emplace_back(sample_message_str);
                                }
                            }
                        }                       
                        
                    }                 

                } 

            for (auto &dump: dump_data) {

                 if (req->debuglevel() == 111) {
                    std::string file_name = "new_log_info_" + std::to_string(message_type) + "_" + std::to_string(gettimeofday_us()) + ".json";
                    std::ofstream outFile(file_name);
                    if (!outFile) {
                        std::cerr << "Error: Failed to open the file." << std::endl;
                    }
                    outFile << dump;
                    outFile.close();
                }
                hikafka::KafkaMessage *kafkaMessage = new hikafka::KafkaMessage();
                kafkaMessage->value.assign(dump.data(), dump.size());
                HILOG_APP(INFO) << "sample_dump size" << kafkaMessage->value.size() << endl;
                if (hikafka::KafkaHelper::getInstance().sendMsg(_dump_verify_kafka_name, kafkaMessage) == false) {
                    HILOG_APP(ERROR) << "kafka input queue fail " << _dump_verify_kafka_name;
                    delete kafkaMessage;
                }
            }

        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "Something wrong in sample log dump,  " << e.what();
            return false;
        }

        return true;
    }

    bool DumpLogService::dump_kafka_sample(CoreContextPtr context, const phx::PredictorRequest *req,
                                           const phx::PredictorResponse *res, const phx::FeRequest *fe_dump,
                                           int32_t message_type) {
        try {
            ::phx::SampleDumpInfo log_info;
            log_info.mutable_dumptime()->assign(get_current_time());
            log_info.mutable_service()->assign(ServerConfig::_monitor_service_name);
            log_info.set_scenetype(req->predictorslotinfo().scenetype());
            log_info.mutable_algotraceid()->assign(req->algotraceid());
            log_info.set_slotid(req->predictorslotinfo().slotid());
            log_info.mutable_reqid()->assign(req->reqid());
            log_info.mutable_oaid()->assign(req->oaid());
            log_info.set_route(req->predictorslotinfo().route());
            log_info.mutable_az()->assign(FLAGS_az_info);
            std::string sample_message_str = "";
            log_info.mutable_dumpdata()->assign(sample_message_str);
            log_info.set_costtime(context->get_predicttime());
            log_info.set_msgtype(message_type);

            std::vector<std::string> dump_data;

            if (message_type == SAMPLE_DUMP_VERIFY || message_type == SAMPLE_DUMP_NORMAL_REQ_RES 
                || message_type == SAMPLE_DUMP_EXCEPTION_REQ_RES || message_type == SAMPLE_DUMP_PREDICT) {
                const auto fe_split_map = context->get_fe_context()->GetSplit();
                for (const auto &[model_type, model_wrappers]: fe_split_map) {
                    for (const auto &[model, wrapper]: model_wrappers) {
                        int32_t start_index = 0;
                        std::vector<ItemWrapper> *item_wrappers = PredictService::get_item_wrappers(context, model, model_type);
                        
                        std::unordered_map<int64_t, std::vector<float>> pos_scores_map; // 按位预估score map
                        if(model->_model_info->_multi_pos_flag || message_type == SAMPLE_DUMP_PREDICT) {
                            auto infer_context = context->get_infer_context();
                            if(infer_context != nullptr) {
                                auto& model_infer = infer_context->get_model_infer(model_type, model);
                                auto& infer_pairs = model_infer._infer_pairs;
                                for(const auto& [index, pair] : infer_pairs) {
                                    ::proto::flow::DumpPredict dump_predict;
                                    const ::proto::flow::PredictRequest* predict_req = pair._predict_request;
                                    const ::proto::flow::PredictResponse* rsp = pair._predict_response;
                                    if (req != nullptr) {
                                        dump_predict.mutable_request()->CopyFrom(*predict_req);
                                    }
                                    if (rsp != nullptr) {
                                        dump_predict.mutable_response()->CopyFrom(*rsp);
                                        if (message_type == SAMPLE_DUMP_PREDICT) {
                                            for(int item_index=pair._start_index; item_index<pair._end_index; ++item_index) {
                                                int64_t creative_id = (*item_wrappers)[item_index].item->creativeid();
                                                dump_predict.add_creativeid(creative_id);
                                            }
                                            if (req->debuglevel() == 111) {
                                                std::string str;
                                                google::protobuf::util::MessageToJsonString(dump_predict, &str);
                                                dump_data.emplace_back(str);
                                            } else {
                                                sample_message_str = "";
                                                if (dump_predict.SerializeToString(&sample_message_str)) {
                                                    dump_data.emplace_back(sample_message_str);
                                                }
                                            }
                                            continue;
                                        }
                                        std::unordered_map<std::string, ::proto::flow::ModelPredictResponse_PredictOutputTensor> tensor_map;
                                        auto &model_predict_responses = rsp->responses();//所有model_name所在的list
                                        for (const auto &model_predict_response: model_predict_responses) {
                                            if(model->_model_name == model_predict_response.model_name()) {
                                                for(const auto& output : model_predict_response.outputs()) {
                                                    tensor_map[output.name()] = output;
                                                }
                                                size_t output_size = model_predict_response.outputs_size();
                                                for(int item_index=pair._start_index; item_index<pair._end_index; ++item_index) {
                                                    int64_t cur_creative_id = (*item_wrappers)[item_index].item->creativeid();
                                                    int score_index = item_index - pair._start_index;
                                                    std::vector<float> score_vec(output_size);
                                                    for(int pos=0; pos<output_size; ++pos) {
                                                        float pos_score = tensor_map[std::to_string(pos)].values().float_val(score_index);
                                                        score_vec[pos] = pos_score;
                                                    }
                                                    pos_scores_map.insert({cur_creative_id, score_vec});
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        if (message_type == SAMPLE_DUMP_PREDICT) {
                            continue;
                        }
                        
                        for (int i = 0; i < wrapper.size(); i++) {
                            
                            const auto& wrapper_item = wrapper[i];
                            ::phx::VerifyInfoSample verify_info;
                            for (auto item: wrapper_item.items) {
                                if (wrapper_item.error_code != FE_NORMAL) {
                                    for (auto& prerank_dump : *context->_bak_response_dump->mutable_responsedumpdata()) {
                                        if(item->item_info().creative_id() == prerank_dump.creativeid()) {
                                            if (model_type == ExperimentModelType::CPC_CTR || model_type == ExperimentModelType::CPD_CTR) {
                                                prerank_dump.set_ctrstatus(FE_FAIL);                                            
                                            }
                                            else if (model_type == ExperimentModelType::CPC_CVR || model_type == ExperimentModelType::CPD_CVR) {
                                                prerank_dump.set_cvrstatus(FE_FAIL);
                                            }
                                        }
                                    }  
                                } 
                                phx::ItemFeature *verify_item = verify_info.mutable_item_ids()->Add();
                                verify_item->CopyFrom(*item);
                            }
                            if (message_type == SAMPLE_DUMP_NORMAL_REQ_RES || message_type == SAMPLE_DUMP_EXCEPTION_REQ_RES) {
                                continue; // 请求响应上报只需要填充_bak_response_dump中打分状态，不需要处理下面
                            }

                            int32_t item_size = wrapper_item.items.size();
                            if (model->_model_info == nullptr || model->_model_info->_model_dict_collector == nullptr) {
                                start_index += item_size;
                                continue;
                            }

                            for (const auto &[name, path]:
                                 model->_model_info->_model_dict_collector->_dict_name2path_map) {
                                auto dict = verify_info.add_dicts();
                                dict->set_name(name);
                                dict->set_path(path);
                                auto dict_info = model->_model_info->_model_dict_collector->get_dict(name);
                                dict->set_version(dict_info->m_task_info.version);
                            }

                            //model
                            verify_info.mutable_models()->mutable_model_name()->assign(model->_model_name);
                            verify_info.mutable_models()->mutable_fe_config_path()->assign(
                                    model->_model_info->get_model_path());
                            verify_info.mutable_models()->mutable_fe_config_md5()->assign(
                                    model->_model_info->_fe_config_content_md5);
                            int model_vesion =
                                    ModelVersion::instance().get_model_version(model->_model_info->get_name());
                            verify_info.mutable_models()->mutable_model_version()->assign(std::to_string(model_vesion));
                            if(model->_model_info->_multi_pos_flag) {
                                verify_info.mutable_models()->set_is_prepos(1);
                            }
                            //extractor response
                            verify_info.mutable_extractor_result()->CopyFrom(*wrapper_item.extractor_response);
                            //score
                            for (int i = start_index; i < start_index + item_size && i < (*item_wrappers).size(); i++) {
                                ::phx::ScoreInfo* score_info = verify_info.mutable_score()->Add();
                                if (model_type == ExperimentModelType::CPC_CTR || model_type == ExperimentModelType::CPD_CTR) {
                                    score_info->set_ctr((*item_wrappers)[i].item_data->pctr());
                                    if(model->_model_info->_multi_pos_flag && !pos_scores_map.empty()) { // 填充按位预估校验点3分数
                                        int64_t id = (*item_wrappers)[i].item->creativeid();
                                        auto it = pos_scores_map.find(id);
                                        if(it != pos_scores_map.end()) {
                                            for(const float score : it->second) {
                                                score_info->mutable_model_prepos()->Add(score);
                                            }
                                        }
                                        for (const auto& pctr : (*item_wrappers)[i].item_data->pctrinpos()) {
                                            score_info->add_prepos(pctr);
                                        }                                        
                                    }

                                }
                                else if (model_type == ExperimentModelType::CPC_CVR || model_type == ExperimentModelType::CPD_CVR) {
                                    score_info->set_cvr((*item_wrappers)[i].item_data->pcvr());
                                    score_info->set_deep((*item_wrappers)[i].item_data->pdcvr());
                                    score_info->set_enhance((*item_wrappers)[i].item_data->pecvr());
                                    score_info->set_cvr1((*item_wrappers)[i].item_data->pcvr1());
                                    score_info->set_cvr2((*item_wrappers)[i].item_data->pcvr2());
                                } else if (model_type == ExperimentModelType::LTV) {
                                    score_info->set_ltv1((*item_wrappers)[i].item_data->pltv1());
                                    score_info->set_ltv2((*item_wrappers)[i].item_data->pltv2());
                                }
                                    
                            }
                            start_index += item_size;

                            if (req->debuglevel() == 111) {
                                std::string str;
                                google::protobuf::util::MessageToJsonString(verify_info, &str);
                                dump_data.emplace_back(str);
                            } else {
                                sample_message_str = "";
                                if (verify_info.SerializeToString(&sample_message_str)) {
                                    dump_data.emplace_back(sample_message_str);
                                }
                            }
                        }
                    }
                }
                //粗排
                {
                    ::phx::VerifyInfoSample verify_info;
                    std::string model_name = context->get_prerank_context()->user_emb_model_name_;
                    auto model_info = Info::ModelInfoManager::instance().get_model_info(model_name);
                    if (model_info != nullptr && model_info->_model_dict_collector != nullptr) {
                        for (auto& prerank_dump : *context->_bak_response_dump->mutable_responsedumpdata()) {
                            for(const auto& item : fe_dump->item_fea()) {
                                if(item.item_info().creative_id() == prerank_dump.creativeid()) {
                                    phx::ItemFeature *verify_item = verify_info.mutable_item_ids()->Add();
                                    verify_item->CopyFrom(item);
                                    break;
                                }
                            }
                        }
                        if (verify_info.item_ids_size() != 0) {//有item走粗排，才上报
                            //dict
                            for (const auto &[name, path]: model_info->_model_dict_collector->_dict_name2path_map) {
                                auto dict = verify_info.add_dicts();
                                dict->set_name(name);
                                dict->set_path(path);
                                auto dict_info = model_info->_model_dict_collector->get_dict(name);
                                dict->set_version(dict_info->m_task_info.version);
                            }
                            //model
                            verify_info.mutable_models()->mutable_model_name()->assign(model_name);                    
                            verify_info.mutable_models()->mutable_fe_config_path()->assign(model_info->_model_config_path);
                            verify_info.mutable_models()->mutable_fe_config_md5()->assign(model_info->_fe_config_content_md5);
                            int model_vesion = ModelVersion::instance().get_model_version(model_info->get_name());
                            verify_info.mutable_models()->mutable_model_version()->assign(std::to_string(model_vesion));
                            //extractor response
                            auto user_extractor_response = context->get_prerank_context()->user_extractor_response;
                            if (user_extractor_response != nullptr) {
                                verify_info.mutable_extractor_result()->CopyFrom(*user_extractor_response);
                            }
                            
                            //user_embedding
                            for (const auto& user_emb : context->get_prerank_context()->UserEmbeddingVec()) {
                                verify_info.add_user_embedding(user_emb);
                            }
                            
                            if (req->debuglevel() == 111) {
                                std::string str;
                                google::protobuf::util::MessageToJsonString(verify_info, &str);
                                dump_data.emplace_back(str);
                            } else {
                                sample_message_str = "";
                                if (verify_info.SerializeToString(&sample_message_str)) {
                                    dump_data.emplace_back(sample_message_str);
                                }
                            }
                        }                       
                        
                    }                 

                }
            }

            std::string req_res_str = "";
            context->_bak_response_dump->mutable_response()->CopyFrom(*res);
            context->_bak_response_dump->mutable_request()->CopyFrom(*req);
            if (req->debuglevel() == 111) {
                std::string str;
                google::protobuf::util::MessageToJsonString(*context->_bak_response_dump, &str);
                req_res_str.append(str);
            } else {
                std::string response_dump_str;
                if (context->_bak_response_dump->SerializeToString(&response_dump_str)) {
                    req_res_str.append(response_dump_str);
                }
            }
            if (message_type == SAMPLE_DUMP_NORMAL_REQ_RES) {
                dump_data.emplace_back(req_res_str);
            } else if (message_type == SAMPLE_DUMP_FEATUREDUMP) {
                sample_message_str = "";
                if (fe_dump->SerializeToString(&sample_message_str)) {
                    dump_data.emplace_back(sample_message_str);
                }
            } else if (message_type == SAMPLE_DUMP_EXCEPTION_REQ_RES) {
                dump_data.emplace_back(req_res_str);
            } 

            for (auto &dump: dump_data) {
                log_info.mutable_dumpdata()->clear();
                log_info.mutable_dumpdata()->assign(dump.data(), dump.size());

                 if (req->debuglevel() == 111) {
                    std::string file_name = "log_info_" + std::to_string(message_type) + "_" + std::to_string(gettimeofday_us()) + ".json";
                    debug::pb::SavePbToFile(file_name, log_info);
                }
                hikafka::KafkaMessage *kafkaMessage = new hikafka::KafkaMessage();
                log_info.SerializeToString(&kafkaMessage->value);
                HILOG_APP(INFO) << "sample_dump size" << kafkaMessage->value.size() << endl;
                if (hikafka::KafkaHelper::getInstance().sendMsg(_dump_log_kafka_name, kafkaMessage) == false) {
                    HILOG_APP(ERROR) << "kafka input queue fail " << _dump_log_kafka_name;
                    delete kafkaMessage;
                }
            }

        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "Something wrong in sample log dump,  " << e.what();
            return false;
        }

        return true;
    }

    int DumpLogService::dump_log(CoreContextPtr context) {
        const phx::PredictorRequest *req = context->get_rank_request();
        const phx::PredictorResponse *res = context->get_rank_response();
        const phx::FeRequest *fe_dump = context->get_fs_context()->get_feature_dump();
        const std::string &req_id = context->get_req_id();
        std::string result;

        if (!context->get_is_ex_req() && is_req_res_sample(req_id)) {
            if (_dump_req_res_kafka == "true") {
                dump_kafka_sample(context, req, res, fe_dump, SAMPLE_DUMP_NORMAL_REQ_RES);
            } else {
                dump_log_sample(context, req, res, fe_dump, SAMPLE_DUMP_NORMAL_REQ_RES);
            }
        }

        if (context->get_is_ex_req() && is_ex_req_sample(req_id)) {
            if (_dump_ex_req_kafka == "true") {
                dump_kafka_sample(context, req, res, fe_dump, SAMPLE_DUMP_EXCEPTION_REQ_RES);
            } else {
                dump_log_sample(context, req, res, fe_dump, SAMPLE_DUMP_EXCEPTION_REQ_RES);
            }
        }

        if (is_fe_dump_sample(req_id)) {
            if (_dump_fe_dump_kafka == "true") {
                dump_kafka_sample(context, req, res, fe_dump, SAMPLE_DUMP_FEATUREDUMP);
            } else {
                dump_log_sample(context, req, res, fe_dump, SAMPLE_DUMP_FEATUREDUMP);
            }
        }

        if (is_predict_sample(req_id)) {
            dump_kafka_sample(context, req, res, fe_dump, SAMPLE_DUMP_PREDICT);
        }

        //打标控制校验点2上报比例
        if (context->get_dump_verify()) {
            g_dump_verify_qps << 1;
            if (g_dump_verify_qps.qps() < _max_sample_qps) {
                // 老链路上报
                if (_dump_old_verify == "true" ) {
                    dump_kafka_sample(context, req, res, fe_dump, SAMPLE_DUMP_VERIFY); 
                }
                // 新链路上报                
                dump_verify_sample(context, req, res, fe_dump, SAMPLE_DUMP_VERIFY); 
            }
        }

        //配置控制校验点2上报比例
        // if (is_verify2_sample(context)) {
        //     g_dump_verify_qps << 1;
        //     if (g_dump_verify_qps.qps() < _max_sample_qps) {
        //         dump_kafka_sample(context, req, res, fe_dump, SAMPLE_DUMP_VERIFY);
        //     }
        // }

        return ERROR_SUCCESS;
    }

    int DumpLogService::dump_offline_log(CoreContextPtr context) {
        const phx::PredictorRequest *req = context->get_rank_request();     
        auto prerank_context = context->get_prerank_context();

        try {
            ::phx::SampleDumpInfo log_info;
            log_info.mutable_dumptime()->assign(get_current_time());
            log_info.mutable_service()->assign(ServerConfig::_monitor_service_name);
            log_info.set_scenetype(req->predictorslotinfo().scenetype());
            log_info.mutable_algotraceid()->assign("prerank");
            log_info.set_slotid(req->predictorslotinfo().slotid());
            log_info.mutable_reqid()->assign(req->reqid());
            log_info.mutable_oaid()->assign(req->oaid());
            log_info.set_route(req->predictorslotinfo().route());
            log_info.mutable_az()->assign(FLAGS_az_info);
            std::string sample_message_str = "";
            log_info.mutable_dumpdata()->assign(sample_message_str);
            log_info.set_costtime(context->get_predicttime());
            log_info.set_msgtype(SAMPLE_DUMP_VERIFY);

            std::vector<std::string> dump_data;

            g_dump_verify_qps << 1;
            if (g_dump_verify_qps.qps() < _max_sample_qps) {
                    const std::string &model_name = context->_offline_item_emb_model;
                    log_info.mutable_reqid()->assign(model_name);
                    auto model_info = Info::ModelInfoManager::instance().get_model_info(model_name);                    
                    if (model_info != nullptr && model_info->_model_dict_collector != nullptr) {
                        for (const auto &[index, items]: prerank_context->_offline_item_embedding_map) {
                            auto exctractor_response = prerank_context->_offline_item_embedding_fe_response_map[index];
                            ::phx::VerifyInfoSample verify_info;
                            
                            for(const auto& item : items) {
                                phx::ItemFeature *verify_item = verify_info.mutable_item_ids()->Add();
                                verify_item->mutable_item_info()->set_creative_id(item.item->creativeid());
                                verify_item->mutable_item_info()->set_appid(item.item->appid());                                
                                ::phx::ScoreInfo* score_info = verify_info.mutable_score()->Add();
                                for (const auto item_emb : context->get_prerank_context()->offline_items_embeddings[item.item->creativeid()]) {
                                    //item_embedding
                                    score_info->add_item_embedding(item_emb);
                                }
                            }
                            //dict
                            for (const auto &[name, path]: model_info->_model_dict_collector->_dict_name2path_map) {
                                auto dict = verify_info.add_dicts();
                                dict->set_name(name);
                                dict->set_path(path);
                                auto dict_info = model_info->_model_dict_collector->get_dict(name);
                                dict->set_version(dict_info->m_task_info.version);
                            }
                            //model
                            verify_info.mutable_models()->mutable_model_name()->assign(model_name);                    
                            verify_info.mutable_models()->mutable_fe_config_path()->assign(model_info->_model_config_path);
                            verify_info.mutable_models()->mutable_fe_config_md5()->assign(model_info->_fe_config_content_md5);
                            // int model_vesion = ModelVersion::instance().get_model_version(model_info->get_name());
                            // verify_info.mutable_models()->mutable_model_version()->assign(std::to_string(model_vesion));
                            verify_info.mutable_models()->mutable_model_version()->assign(std::to_string(context->_offline_item_emb_version));
                            //extractor
                            verify_info.mutable_extractor_result()->CopyFrom(*exctractor_response);                       
                                                   
                            
                            
                            sample_message_str = "";
                            if (verify_info.SerializeToString(&sample_message_str)) {
                                dump_data.emplace_back(sample_message_str);
                            }
                        }
                    }                    

                for (auto &dump: dump_data) {
                    log_info.mutable_dumpdata()->clear();
                    log_info.mutable_dumpdata()->assign(dump.data(), dump.size());

                    // if (req->debuglevel() == 111) {
                        // std::string file_name = "log_info_" + std::to_string(SAMPLE_DUMP_VERIFY) + "_offline_" + std::to_string(gettimeofday_us()) + ".json";
                        // debug::pb::SavePbToFile(file_name, log_info);
                    // }
                    hikafka::KafkaMessage *kafkaMessage = new hikafka::KafkaMessage();
                    log_info.SerializeToString(&kafkaMessage->value);
                    HILOG_APP(INFO) << "sample_dump size" << kafkaMessage->value.size() << endl;
                    if (hikafka::KafkaHelper::getInstance().sendMsg(_dump_log_kafka_name, kafkaMessage) == false) {
                        HILOG_APP(ERROR) << "kafka input queue fail " << _dump_log_kafka_name;
                        delete kafkaMessage;
                    }
                }
            }
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "Something wrong in sample offline log dump,  " << e.what();
            return false;
        }

        return ERROR_SUCCESS;
    }

    int DumpLogService::dump_offline_log_new(CoreContextPtr context) {
        const phx::PredictorRequest *req = context->get_rank_request();     
        auto prerank_context = context->get_prerank_context();

        try {
            std::string sample_message_str = "";
            std::vector<std::string> dump_data;

            g_dump_verify_qps << 1;
            if (g_dump_verify_qps.qps() < _max_sample_qps) {
                    const std::string &model_name = context->_offline_item_emb_model;
                    auto model_info = Info::ModelInfoManager::instance().get_model_info(model_name);                    
                    if (model_info != nullptr && model_info->_model_dict_collector != nullptr) {
                        for (const auto &[index, items]: prerank_context->_offline_item_embedding_map) {
                            auto exctractor_response = prerank_context->_offline_item_embedding_fe_response_map[index];
                            ::phx::VerifyInfoSample verify_info;
                            ::phx::FeRequest fe_request;
                            std::string req_id = req->reqid();
                            req_id.append("-");
                            req_id.append(std::to_string(index));
                            fe_request.mutable_req_id()->assign(req_id); // 校验点上报请求Id：时间戳-包序号
                            for(const auto& item : items) {
                                phx::ItemFeature *verify_item = verify_info.mutable_item_ids()->Add();
                                verify_item->mutable_item_info()->set_creative_id(item.item->creativeid());
                                verify_item->mutable_item_info()->set_appid(item.item->appid());
                                phx::ItemFeature *fe_item = fe_request.mutable_item_fea()->Add();
                                fe_item->mutable_item_info()->set_creative_id(item.item->creativeid());
                                fe_item->mutable_item_info()->set_appid(item.item->appid());
                                ::phx::ScoreInfo* score_info = verify_info.mutable_score()->Add();
                                for (const auto item_emb : context->get_prerank_context()->offline_items_embeddings[item.item->creativeid()]) {
                                    //item_embedding
                                    score_info->add_item_embedding(item_emb);
                                }
                            }
                            //dict
                            for (const auto &[name, path]: model_info->_model_dict_collector->_dict_name2path_map) {
                                auto dict = verify_info.add_dicts();
                                dict->set_name(name);
                                dict->set_path(path);
                                auto dict_info = model_info->_model_dict_collector->get_dict(name);
                                dict->set_version(dict_info->m_task_info.version);
                            }
                            //model
                            verify_info.mutable_models()->mutable_model_name()->assign(model_name);                    
                            verify_info.mutable_models()->mutable_fe_config_path()->assign(model_info->_model_config_path);
                            verify_info.mutable_models()->mutable_fe_config_md5()->assign(model_info->_fe_config_content_md5);
                            // int model_vesion = ModelVersion::instance().get_model_version(model_info->get_name());
                            // verify_info.mutable_models()->mutable_model_version()->assign(std::to_string(model_vesion));
                            verify_info.mutable_models()->mutable_model_version()->assign(std::to_string(context->_offline_item_emb_version));
                            //extractor
                            verify_info.mutable_extractor_result()->CopyFrom(*exctractor_response);
                            //fe_request
                            verify_info.mutable_fe_request()->CopyFrom(fe_request);                     
                            
                            
                            sample_message_str = "";
                            if (verify_info.SerializeToString(&sample_message_str)) {
                                dump_data.emplace_back(sample_message_str);
                            }
                        }
                    }                    

                for (auto &dump: dump_data) {
                    hikafka::KafkaMessage *kafkaMessage = new hikafka::KafkaMessage();
                    kafkaMessage->value.assign(dump.data(), dump.size());
                    HILOG_APP(INFO) << "sample_dump size" << kafkaMessage->value.size() << endl;
                    if (hikafka::KafkaHelper::getInstance().sendMsg(_dump_verify_kafka_name, kafkaMessage) == false) {
                        HILOG_APP(ERROR) << "kafka input queue fail " << _dump_verify_kafka_name;
                        delete kafkaMessage;
                    }
                }
            }
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "Something wrong in sample offline log dump,  " << e.what();
            return false;
        }

        return ERROR_SUCCESS;
    }
    bool DumpLogService::dump_missed_query(CoreContextPtr context) {
        try {
            if (context->get_query().empty()||context->get_handled_query().empty()) {// 空query不上报
                return ERROR_SUCCESS;
            }
            phx::queryInfo queryInfo;
            queryInfo.mutable_query()->assign(context->get_query());
            queryInfo.mutable_handled_query()->assign(context->get_handled_query());
            if(context->get_rank_request()->debuglevel() == 111) {
                debug::pb::SavePbToFile("query_info.json", queryInfo);
            }
            else {
                hikafka::KafkaMessage* kafka_message = new hikafka::KafkaMessage();
                queryInfo.SerializePartialToString(&kafka_message->value);                                
                if(hikafka::KafkaHelper::getInstance().sendMsg(_dump_missed_query_kafka_name, kafka_message)==false){
                    HILOG_APP(ERROR) << "kafka input queue fail "<< _dump_missed_query_kafka_name;
                    MonitorMgr::common_report_stage(std::to_string(context->get_route()), "default","default",get_name(), context->GetUploadSlotName(), 0, "dump_kafka_fail_count", 1);
                    delete kafka_message;
                }
            }
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "Something wrong in missed query dump kafka,  " << e.what();
        }

        return ERROR_SUCCESS;
    }
    std::string generate_predict_json(const CoreContextPtr &context) {
        using json = nlohmann::json;
        json root;

        auto build_model_ref = [](const ExperimentModelInfo *model) -> json {
            return model ? json{{"type", model->_model_type}, {"name", model->_model_name}} : nullptr;
        };

        auto process_map = [&](const auto &src_map, const std::string &map_key) {
            json map_node = json::array();

            for (const auto &[model, items]: src_map) {
                if (!model)
                    continue;

                json model_info = {{"type", static_cast<int>(model->_model_type)},
                                   {"name", model->_model_name},
                                   {"supported_conv_types", model->_supported_conv_types}};

                // 構建關聯預測項
                json related_items = json::array();
                for (const auto &item: items) {
                    json item_node;

                    // 結構化處理DebugString
                    if (item.item) {
                        std::stringstream ss(item.item->DebugString());
                        std::string line;
                        json params;
                        while (std::getline(ss, line)) {
                            size_t colon = line.find(':');
                            if (colon != std::string::npos) {
                                std::string key = line.substr(0, colon);
                                std::string value = line.substr(colon + 2);
                                params[key] = value;
                            }
                        }
                        item_node["params"] = params;
                    }

                    // 關聯依賴模型
                    json deps = json::array();
                    for (const auto &dep_model: item.model_info) {
                        deps.push_back(build_model_ref(dep_model));
                    }
                    item_node["dependency_models"] = deps;

                    related_items.push_back(item_node);
                }

                // 將關聯項嵌入模型信息
                model_info["related_items"] = related_items;
                map_node.push_back(model_info);
            }

            root[map_key] = map_node;
        };

        process_map(context->_model_predict_cpc_cvr_map, "_model_predict_cpc_cvr_map");
        process_map(context->_model_predict_cpd_cvr_map, "_model_predict_cpd_cvr_map");
        process_map(context->_model_predict_cpc_ctr_map, "_model_predict_cpc_ctr_map");
        process_map(context->_model_predict_cpd_ctr_map, "_model_predict_cpd_ctr_map");

        return root.dump(4);
    }

    bool DumpLogService::dump_watchpoint_sample(CoreContextPtr context, const phx::PredictorRequest *req,
                                                const phx::FeRequest *fe_dump, int32_t watchpoint_type,
                                                const std::string &kafka_key, const std::string &kafka_name) {
        try {
            butil::rapidjson::Document document;
            document.SetObject();
            butil::rapidjson::Document::AllocatorType &allocator = document.GetAllocator();
            butil::rapidjson::Value reqId(req->reqid().c_str(),
                                          static_cast<butil::rapidjson::SizeType>(req->reqid().length()), allocator);
            document.AddMember("reqId", reqId, allocator);
            document.AddMember("slotId", req->predictorslotinfo().slotid(), allocator);
            document.AddMember("sceneType", req->predictorslotinfo().scenetype(), allocator);
            document.AddMember("route", req->predictorslotinfo().route(), allocator);
            butil::rapidjson::Value service(
                    ServerConfig::_monitor_service_name.c_str(),
                    static_cast<butil::rapidjson::SizeType>(ServerConfig::_monitor_service_name.length()), allocator);
            document.AddMember("service", service, allocator);
            butil::rapidjson::Value az(FLAGS_az_info.c_str(),
                                       static_cast<butil::rapidjson::SizeType>(FLAGS_az_info.length()), allocator);
            document.AddMember("az", az, allocator);
            document.AddMember("watchpoint", watchpoint_type, allocator);
            document.AddMember("reqType", 0, allocator);
            int64_t timestamp = gettimeofday_ms();
            document.AddMember("timestamp", timestamp, allocator);
            butil::rapidjson::Value oaid(req->oaid().c_str(),
                                         static_cast<butil::rapidjson::SizeType>(req->oaid().length()), allocator);
            document.AddMember("oaid", oaid, allocator);
            butil::rapidjson::Value algotraceid(req->algotraceid().c_str(),
                                                static_cast<butil::rapidjson::SizeType>(req->algotraceid().length()),
                                                allocator);
            document.AddMember("algotraceid", algotraceid, allocator);

            if (_watch_point_json == "true") {
                //json上报
                std::string message_string = "";
                if (watchpoint_type == PREDICTOR_REQUEST) {
                    google::protobuf::util::MessageToJsonString(*req, &message_string);
                } else if (watchpoint_type == PREDICTOR_FEATURE_DUMP) {
                    google::protobuf::util::MessageToJsonString(*fe_dump, &message_string);
                } else if (watchpoint_type == EXPERIMENT_INFO) {
                    message_string = generate_predict_json(context);
                }
                butil::rapidjson::Value dump_data(message_string.c_str(),
                                                  static_cast<butil::rapidjson::SizeType>(message_string.length()),
                                                  allocator);
                document.AddMember("dumpData", dump_data, allocator);
            } else {
                //编码上报
                std::string message_string = "";
                std::string encode_message_str = "";
                if (watchpoint_type == PREDICTOR_REQUEST) {
                    if (req->SerializeToString(&message_string)) {
                        encode_message_str = base64_encode(message_string);
                    }
                } else if (watchpoint_type == PREDICTOR_FEATURE_DUMP) {
                    if (fe_dump->SerializeToString(&message_string)) {
                        encode_message_str = base64_encode(message_string);
                    }
                } else if (watchpoint_type == EXPERIMENT_INFO) {
                    std::string message_string = generate_predict_json(context);
                    encode_message_str = base64_encode(message_string);
                }
                butil::rapidjson::Value dump_data(encode_message_str.c_str(),
                                                  static_cast<butil::rapidjson::SizeType>(encode_message_str.length()),
                                                  allocator);
                document.AddMember("dumpData", dump_data, allocator);
            }

            butil::rapidjson::StringBuffer buffer;
            butil::rapidjson::Writer<butil::rapidjson::StringBuffer> writer(buffer);
            document.Accept(writer);

            if (req->debuglevel() == 111) {
                std::string file_name = "watchpoint_" + std::to_string(watchpoint_type) + ".json";
                std::ofstream ofs(file_name);
                if (ofs.is_open()) {
                    ofs << buffer.GetString();
                    ofs.close();
                } else {
                    std::cerr << "DEBUGLEVEL 111 Failed to open file for writing watch_point.txt" << std::endl;
                }
            }

            hikafka::KafkaMessage *kafkaMessage = new hikafka::KafkaMessage();
            kafkaMessage->value = buffer.GetString();
            HILOG_APP(INFO) << "sample_dump size" << kafkaMessage->value.size() << endl;
            if (hikafka::KafkaHelper::getInstance().sendMsg(kafka_name, kafkaMessage) == false) {
                HILOG_APP(ERROR) << "kafka input queue fail " << kafka_name;
                delete kafkaMessage;
            }
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "Something wrong in watch point dump kafka,  " << e.what();
        }

        return ERROR_SUCCESS;
    }

    void DumpLogService::dump_watchpoint(CoreContextPtr context) {
        if("false" == _watch_point_dump) {
            return ;
        }
        const phx::PredictorRequest *req = context->get_rank_request();
        const phx::FeRequest *fe_dump = context->get_fs_context()->get_feature_dump();
        int64_t watch_point = req->predictorslotinfo().watchpoint();
        std::string kafka_key;
        std::string kafka_name;
        if (req->mediatype() == 1) {
            kafka_key = _internal_watchpoint_kafka_key;
            kafka_name = _internal_watchpoint_kafka_name;
        } else if (req->mediatype() == 2) {
            kafka_key = _external_watchpoint_kafka_key;
            kafka_name = _external_watchpoint_kafka_name;
        } else {
            HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << " mediatype is neither 0 nor 1. trace dump failed";
            return;
        }
        if (watch_point != 0 && _watch_point_dump == "true" && is_watchpoint_sample(req->oaid())) {
            if (watch_point & (1ULL << PREDICTOR_REQUEST)) {
                dump_watchpoint_sample(context, req, fe_dump, PREDICTOR_REQUEST, kafka_key, kafka_name);
            }
            if (watch_point & (1ULL << PREDICTOR_FEATURE_DUMP)) {
                dump_watchpoint_sample(context, req, fe_dump, PREDICTOR_FEATURE_DUMP, kafka_key, kafka_name);
            }
            if (watch_point & (1ULL << EXPERIMENT_INFO)) {
                dump_watchpoint_sample(context, req, fe_dump, EXPERIMENT_INFO, kafka_key, kafka_name);
            }
        }
    }

}// namespace Core
