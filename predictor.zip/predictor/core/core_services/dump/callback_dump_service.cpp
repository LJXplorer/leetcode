#include "core/core_services/dump/callback_dump_service.h"
#include "common/hikafka/kafka_producer.h"
#include "common/hikafka/kafka_helper.h"
#include "core/core_context/callback_context.h"
#include "core/core_context/core_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/dump/dump_manager/dump_manager.h"
#include "core/core_services/dump/feature_dump_retry_manager/featuredump_retry_manager.h"
#include "core/utils/defs.h"
#include "hlframe/context.h"
#include "hlframe/graph_context.h"
#include "hlframe/register.h"
#include <boost/algorithm/string.hpp>
#include <chrono>
#include <config_xml.h>
#include <cstdint>
#include <debug_utils.h>
#include <exception>
#include <glog/logging.h>
#include <log_helper.h>
#include <memory>
#include <string>
#include <wrapper_time.h>
#include "butil/third_party/rapidjson/document.h"
#include "butil/third_party/rapidjson/writer.h"
#include "butil/third_party/rapidjson/stringbuffer.h"
#include "util/base64.h"
#include "third_party/protobuf/include/google/protobuf/util/json_util.h"
#include "util/str.h"
namespace Core {
SERVICE_REGISTER(CallbackDumpService);

DECLARE_string(az_info);


void CallbackDumpService::initialize(ConfigXmlPtr xml) {
    std::string retry_flag;
    xml->attr<std::string>("retry_flag", retry_flag, "false");
    if(retry_flag == "true") {
        _retry_flag = true;
    }
    xml->attr<std::string>("dump_kafka_name", _dump_kafka_name, "");
    xml->attr<std::string>("dump_kafka_key", _dump_kafka_key, "");
    xml->attr<std::string>("scene_kafka_name", _scene_kafka_name, "");
    if (!_scene_kafka_name.empty()) {
        std::vector<std::string> scene_kafka_pairs;
        boost::split(scene_kafka_pairs, _scene_kafka_name, boost::is_any_of(","));
        for (const auto& scene_kafka : scene_kafka_pairs) {
            std::vector<std::string> sk;
            boost::split(sk, scene_kafka, boost::is_any_of(":"));
            if (sk.size() == 2 && !sk[0].empty() && !sk[1].empty()) {
                try {
                    int algoscene_id = std::stoi(sk[0]);
                    _kafka_map[algoscene_id] = sk[1];
                } catch (const std::exception &e) {
                    HILOG_APP(WARNING) << " algoscene_id string parse to int has exception " << e.what();
                }
            }
        }
    }
    xml->attr<int32_t>("prerank_dump_end_policy", _prerank_dump_end_policy);
    xml->attr<int32_t>("prerank_dump_base", _prerank_dump_base);
    xml->attr<int32_t>("prerank_samples_perRange", _prerank_samples_perRange);
    xml->attr<int32_t>("prerank_first_batch_size", _prerank_first_batch_size);
    xml->attr<int>("sample_req_res_ratio", _sample_req_res_ratio);
    xml->attr<std::string>("dump_req_res_kafka", _dump_req_res_kafka, "false");
    xml->attr<int>("sample_fe_dump_ratio", _sample_fe_dump_ratio);
    xml->attr<std::string>("dump_fe_dump_kafka", _dump_fe_dump_kafka, "false");
    xml->attr<int>("sample_ex_req_ratio", _sample_ex_req_ratio);
    xml->attr<std::string>("dump_ex_req_kafka", _dump_ex_req_kafka, "false");
    xml->attr<int>("watch_point_ratio", _watch_point_ratio);
    xml->attr<std::string>("watch_point_dump", _watch_point_dump, "false");
    xml->attr<std::string>("watch_point_json", _watch_point_json, "false");
    xml->attr<std::string>("dump_log_kafka_name", _dump_log_kafka_name);
    xml->attr<std::string>("dump_log_kafka_key", _dump_log_kafka_key);
    xml->attr<std::string>("internal_watchpoint_kafka_name", _internal_watchpoint_kafka_name);
    xml->attr<std::string>("internal_watchpoint_kafka_key", _internal_watchpoint_kafka_key);
    xml->attr<std::string>("external_watchpoint_kafka_name", _external_watchpoint_kafka_name);
    xml->attr<std::string>("external_watchpoint_kafka_key", _external_watchpoint_kafka_key);

    std::string base_ranges_str;
    if (xml->attr<std::string>("prerank_base_ranges", base_ranges_str, "")) {
        _base_ranges.clear();
        std::vector<std::string> ranges;
        boost::split(ranges, base_ranges_str, boost::is_any_of(","));

        for (const auto &range_str : ranges) {
            std::string trimmed_range = boost::algorithm::trim_copy(range_str); // 去除首尾空白
            if (trimmed_range.empty()) {
                continue;
            }
            size_t dash_pos = trimmed_range.find('-');
            if (dash_pos == std::string::npos) {
                // 格式错误，跳过
                continue;
            }
            std::string start_str = trimmed_range.substr(0, dash_pos);
            std::string end_str = trimmed_range.substr(dash_pos + 1);
            try {
                int32_t start = std::stoi(boost::algorithm::trim_copy(start_str));
                int32_t end =  std::stoi(boost::algorithm::trim_copy(end_str));
                _base_ranges.emplace_back(start, end);
            } catch (const std::exception &e) {
                HILOG_APP(ERROR) << "Error parsing range: start_str = \"" << start_str << "\", end_str = \"" << end_str 
              << "\", exception: " << e.what();
                continue;
            }
        }
    }
    initialize_xml(xml);
}

void CallbackDumpService::initialize_xml(ConfigXmlPtr xml) { }

void CallbackDumpService::initialize(GraphContextPtr context) {
    auto ctx = std::dynamic_pointer_cast<CallbackContext>(context);
}

bool CallbackDumpService::skip(GraphContextPtr ctx) {
    return false;
}

int CallbackDumpService::do_service(GraphContextPtr context) {
    auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
    int32_t ret = 0;
    try {
        DumpArgs* args = new DumpArgs();
        args->_dump_type = DUMP_FE;
        args->_ctx = ctx;
        args->_service = this;
        if(ServerConfig::_dump_monitor_enable) {
            DumpManager::dump_counter << 1;
        }
        DumpManager::instance().push_dump_to_queue(args);
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << LOG_HEAD(ctx) << "callback dump fe task submit to exector failed: " << e.what();
        ret = -1;
    }
    return ret;
}

int CallbackDumpService::process(CoreContextPtr context) {
    int32_t ret = 0;
    try {
        BizLatency lat;
        {
            BizLatencyGaurd lat_guard(&lat,LAT_STAGE_CREATE);
            std::string& kafka_name = get_kafka_name(context);
            auto ctx = std::dynamic_pointer_cast<CallbackContext>(context);
            ret = dump(ctx, kafka_name);
        }
        {
            BizLatencyGaurd lat_guard(&lat,LAT_STAGE_DESTROY);
        }
        // TODO: monitor
        const std::string& route = std::to_string(context->get_route());
        const std::string& upload_aggrated_slotid = context->GetUploadSlotName();
        const std::string& algo_sceneId = std::to_string(context->get_algo_scene_id());
        for (auto policy: context->get_rank_request()->algoexperiments()) { 
            MonitorMgr::percent_report_stage(route, algo_sceneId, policy.targetedpolicy(), get_name(), upload_aggrated_slotid, 0, "req_cost", lat.get_request_lat());
            MonitorMgr::percent_report_stage(route, algo_sceneId, policy.targetedpolicy(), get_name(), upload_aggrated_slotid, 0, "rsp_cost", lat.get_response_lat());
            MonitorMgr::percent_report_stage(route, algo_sceneId, policy.targetedpolicy(), get_name(), upload_aggrated_slotid, 0, "stage_total_cost", lat.get_lat());
        }
        
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << " callback dump exception:  " << e.what();
        ret = -1;
    }
    return ret;
}

std::string& CallbackDumpService::get_kafka_name (CoreContextPtr context) {
    int32_t algoscene_id = context->get_algo_scene_id();
    auto it = _kafka_map.find(algoscene_id);
    if (it != _kafka_map.end() && !_kafka_map[algoscene_id].empty()) {
        return _kafka_map[algoscene_id];
    }

    return _dump_kafka_name;
}

int CallbackDumpService::dump(CallbackContextPtr context, std::string& kafka_name) {
    const auto* req = context->get_callback_request();
    const int32_t route = req->callbackslotinfo().route();
    std::string route_str = std::to_string(route);
    std::string slot_id;
    if (req->mediatype() == 2) {
        slot_id = "adsAffiliate";// 直接返回字面量
    }
    else {
        slot_id = std::to_string(req->callbackslotinfo().slotid());
    }

    ::phx::FeRequest fe_dump;   
    merge_feature(context, fe_dump, slot_id, route_str);

    const std::string& algo_sceneId = std::to_string(context->get_algo_scene_id());
    if(context->_ready_send){
        MonitorMgr::common_report_stage(std::to_string(route),algo_sceneId, "default", get_name(), context->GetUploadSlotName(), 0, "callback_dump_count", 1);
        if (context->_dump_feature) {            
            MonitorMgr::common_report_stage(route_str,algo_sceneId, "default", get_name(), context->GetUploadSlotName(), 0, "total_dump_kafka_count", 1);
            fe_dump.set_event_time(context->get_begin_time());
            if (fe_dump.item_fea_size() == 0 || context->get_callback_response()->code() == ERROR_BIZ_REPEATED_MATERIALID) {            
                MonitorMgr::common_report_stage(route_str, algo_sceneId, "default",get_name(), context->GetUploadSlotName(), 0, "not_dump_kafka_count", 1);
                dump_watchpoint(context, fe_dump); // trace验证
                dump_log(context, fe_dump); // 日志采样
                return -1;
            }
            hikafka::KafkaMessage* kafka_message = new hikafka::KafkaMessage();
            kafka_message->key = _dump_kafka_key;
            fe_dump.SerializePartialToString(&kafka_message->value);
            if(hikafka::KafkaHelper::getInstance().sendMsg(kafka_name, kafka_message)==false){
                HILOG_APP(ERROR) << "kafka input queue fail "<< kafka_name;
                MonitorMgr::common_report_stage(std::to_string(route),algo_sceneId, "default",get_name(), context->GetUploadSlotName(), 0, "dump_kafka_fail_count", 1);
                delete kafka_message;
            }
            else {
                MonitorMgr::percent_report_stage(std::to_string(route),algo_sceneId, "default", get_name(), context->GetUploadSlotName(), 0, "feature_dump_size", kafka_message->value.size());
            }
            
            if(context->get_callback_request()->debuglevel() == 111) {
                debug::pb::SavePbToFile("callback_fe_dump.json", fe_dump);
            }
        } 
        else {
            MonitorMgr::common_report_stage(route_str,algo_sceneId, "default",get_name(), context->GetUploadSlotName(), 0, "snapshot_null", 1);
        }       

        dump_watchpoint(context, fe_dump); // trace验证
        dump_log(context, fe_dump); // 日志采样
    }
    
    return 0;
}

std::vector<const CallbackBiddingAd *> CallbackDumpService::selectCallbackBiddingAds(const CallbackSlotInfo &slot_info, bool isWinningAds) {
    std::vector<const CallbackBiddingAd *> result;
    int32_t total_size = isWinningAds ? slot_info.callbackwinbiddingads_size() : slot_info.callbacklossbiddingads_size();
    std::unordered_set<int32_t> added_positions;
    std::vector<std::vector<int32_t>> indices_per_range(_base_ranges.size());

    for (int i = 0; i < total_size; ++i) {
        const auto &ad = isWinningAds ? slot_info.callbackwinbiddingads(i) : slot_info.callbacklossbiddingads(i);
        int pos = ad.position();

        if (pos > 0 && pos <= _prerank_first_batch_size) {
            if (added_positions.insert(pos).second) {
                result.emplace_back(&ad);
            }
            continue;
        }

        for (size_t range_idx = 0; range_idx < _base_ranges.size(); ++range_idx) {
            const auto &[start, end] = _base_ranges[range_idx];
            if (pos >= start && pos <= end) {
                indices_per_range[range_idx].push_back(i);
                break;  
            }
        }
    }

    for (size_t range_idx = 0; range_idx < _base_ranges.size(); ++range_idx) {
        const auto &eligible_indices = indices_per_range[range_idx];
        if (eligible_indices.empty()) continue;

        int32_t samples = std::min(_prerank_samples_perRange, (int32_t)eligible_indices.size());
        std::vector<int32_t> sampled_indices;
        SamplingTool::sampleIndices(0, eligible_indices.size() - 1, samples, sampled_indices);

        for (int32_t idx : sampled_indices) {
            const auto &ad = isWinningAds ? slot_info.callbackwinbiddingads(eligible_indices[idx]) : slot_info.callbacklossbiddingads(eligible_indices[idx]);
            if (added_positions.insert(ad.position()).second) {
                result.emplace_back(&ad);
            }
        }
    }

    return result;
}




void addAdsToDump(const std::vector<const CallbackBiddingAd *> &selectedAds, ::phx::FeRequest &fe_dump, int additional) {
    for (const auto &bid_ad : selectedAds) {
        if (bid_ad) {
            auto *dump_prerank = fe_dump.mutable_prerank_item_fea()->Add();
            dump_prerank->mutable_prerank_item_info()->set_appid(bid_ad->appid());
            dump_prerank->mutable_prerank_item_info()->set_creative_id(bid_ad->creativeid());
            dump_prerank->mutable_prerank_item_info()->set_final_ecpm(static_cast<int64_t>(bid_ad->ecpmpirce()));
            dump_prerank->mutable_prerank_item_info()->set_position(bid_ad->position());
            dump_prerank->mutable_prerank_item_info()->set_additional(additional);
        }
    }
}

void CallbackDumpService::fill_prerank_features(CallbackContextPtr ctx, ::phx::FeRequest &fe_dump) {
    if (CallbackDumpService::is_prerank_sampled(ctx->get_req_id())) {
        auto selectedWinAds = selectCallbackBiddingAds(ctx->get_callback_request()->callbackslotinfo(), true);
        addAdsToDump(selectedWinAds, fe_dump, 0);

        auto selectedLossAds = selectCallbackBiddingAds(ctx->get_callback_request()->callbackslotinfo(), false);
        addAdsToDump(selectedLossAds, fe_dump, 1);
    }
}

void CallbackDumpService::fill_callback_item(CallbackContextPtr ctx, ::phx::FeRequest &fe_dump) {
    auto callback_request = ctx->get_callback_request();
    for (int i = 0; i < fe_dump.item_fea_size(); ++i) {
        ::phx::ItemFeature* item_feature = fe_dump.mutable_item_fea(i);
        if (item_feature->has_item_info()) {
            ::phx::ItemInfo* item_info = item_feature->mutable_item_info();
            const int64_t creative_id = item_info->creative_id();
            if (const auto callback_item = find_req_item_by_id(callback_request, creative_id)) {
                item_info->set_data_source(callback_item->datasource());
                item_info->set_advertiser_id(callback_item->advertiserid());
            }            
        }
    }
}

const phx::CallbackItemInfo* CallbackDumpService::find_req_item_by_id (const phx::CallbackRequest* req, const int64_t creative_id) {
    for (const auto& callback_item : req->callbackslotinfo().callbackiteminfos()) {
        if (callback_item.creativeid() == creative_id) {
            return &callback_item;
        }
    }
    return nullptr;
}

void CallbackDumpService::fill_callback_prerank_item(CallbackContextPtr ctx, ::phx::FeRequest &fe_dump, const std::unordered_map<int64_t, ::phx::ItemFeature *> &merged_item_fea_map) {
    for (int i = 0; i < fe_dump.prerank_item_fea_size(); i++) {
        ::phx::PreRankItemFeature* prerank_item_feature = fe_dump.mutable_prerank_item_fea(i);
        if (prerank_item_feature->has_prerank_item_info()) {
            ::phx::PreRankItemInfo* prerank_item_info = prerank_item_feature->mutable_prerank_item_info();
            auto iter = merged_item_fea_map.find(prerank_item_info->creative_id());
            if (iter != merged_item_fea_map.end()) {
                prerank_item_info->set_billing_mode(iter->second->item_info().billing_mode());
                prerank_item_info->set_bid(iter->second->item_info().bid());
                prerank_item_info->set_ocpx_sbp(iter->second->item_info().ocpx_sbp());
            }
        }
    }
}


void CallbackDumpService::merge_feature(CallbackContextPtr ctx, ::phx::FeRequest& fe_dump, const std::string& slot_id, const std::string& route) {
    auto fs_ctx = ctx->get_fs_context();
    std::shared_ptr<::phx::FeRequest> feature_snapshot = fs_ctx->get_feature_snapshot();
    auto callback_dump = fs_ctx->get_feature_dump();

    if(ctx->get_callback_request()->debuglevel() == 111) {
        debug::pb::SavePbToFile("callback_feature.json", *callback_dump);
    }

    if(feature_snapshot == nullptr) { // feature snapshot failed
        //TODO: 是否需要继续retry 获取特征快照？
        if(_retry_flag) { // retry
            if(ctx->retry_cnt > 0) {
                HILOG_APP(WARNING) << "retrying, cnt: " << ctx->retry_cnt;
                FeatureDumpContextInfo* retry_ctx = new FeatureDumpContextInfo(
                    std::chrono::steady_clock::now(),
                    ctx
                );
                bool ret = FeatureDumpRetryManager::instance().push_to_featuredump_queue(retry_ctx);
                if(!ret) {
                    HILOG_APP(ERROR) << " push_to_featuredump_queue error";
                    ctx->set_ex_req(true);
                    delete retry_ctx;
                }
            } else if(ctx->retry_cnt == 0) {
                HILOG_APP(ERROR) << LOG_HEAD(ctx) << "retry failed!!!!";
                ctx->set_ex_req(true);
                const std::string& algo_sceneId = std::to_string(ctx->get_algo_scene_id());
                MonitorMgr::common_report_stage(route,algo_sceneId, "default", get_name(), slot_id, 0, "retry_failed", 1);
                // fe_dump.CopyFrom(*callback_dump);
                // fill_callback_item(ctx, fe_dump);
                // fill_prerank_features(ctx, fe_dump);
                ctx->_ready_send = true;
                ctx->_dump_feature = false;
            }
        } else {
            HILOG_APP(WARNING) << LOG_HEAD(ctx) << " feature snapshot failed";
            // fe_dump.CopyFrom(*callback_dump);
            // fill_callback_item(ctx, fe_dump);
            // fill_prerank_features(ctx, fe_dump);
            ctx->_ready_send = true;
            ctx->_dump_feature = false;
        }
        return ;
    }

    if(ctx->get_callback_request()->debuglevel() == 111) {
        debug::pb::SavePbToFile( "callback_feature_snapshot.json", *feature_snapshot);
    }

    const auto& callback_item_feature = fs_ctx->get_item_fea();
    const auto& callback_app_feature = fs_ctx->get_app_fea();
    const auto& callback_zero_creativeid_item_fea = fs_ctx->get_zero_creativeid_item_fea();
    std::unordered_map<int64_t, ::phx::ItemFeature *> merged_item_fea_map;
    
    fe_dump.CopyFrom(*feature_snapshot); // based on feature snapshot
    fill_prerank_features(ctx, fe_dump);
    fe_dump.clear_item_fea();
    fe_dump.clear_app_fea();
    // merge: snapshot [u, i_a, i_b], cllback [u, i_b, i_c] => [u, i_b, i_c]
    std::unordered_set<int64_t> item_set;
    std::unordered_set<int64_t> app_set;

    int64_t item_size = feature_snapshot->item_fea_size();
    for(int i=0; i<item_size; ++i) {
        auto* item_fea =  feature_snapshot->mutable_item_fea(i);
        int64_t creative_id = item_fea->mutable_item_info()->creative_id();
        merged_item_fea_map.insert({creative_id, item_fea});
        auto it = callback_item_feature.find(creative_id);
        if(it != callback_item_feature.end()) {
            item_set.insert(creative_id);
            auto* dump_item = fe_dump.mutable_item_fea()->Add();
            dump_item->CopyFrom(*item_fea);
            dump_item->mutable_item_info()->set_final_ecpm(it->second->item_info().final_ecpm());
        }
    }

    int64_t app_size = feature_snapshot->app_fea_size();
    for(int i=0; i<app_size; ++i) {
        auto* app_fea = feature_snapshot->mutable_app_fea(i);
        int64_t app_id = app_fea->mutable_ad_info()->app_id();
        if(callback_app_feature.find(app_id) != callback_app_feature.end()) {
            app_set.insert(app_id);
            auto* dump_app = fe_dump.mutable_app_fea()->Add();
            dump_app->CopyFrom(*app_fea);
        }
    }

    for(const auto& [creative_id, item_fea] : callback_item_feature) {
        if(item_set.count(creative_id) > 0) {
            continue;
        } else {
            auto* dump_item = fe_dump.mutable_item_fea()->Add();
            dump_item->CopyFrom(*item_fea);
            merged_item_fea_map.insert({creative_id, dump_item});
        }
    }

    fill_callback_item(ctx, fe_dump);
    fill_callback_prerank_item(ctx, fe_dump, merged_item_fea_map);
    //填充dsp
    for (const auto& item_fea : callback_zero_creativeid_item_fea) {
        auto* dump_item = fe_dump.mutable_item_fea()->Add();
        dump_item->CopyFrom(*item_fea);
    }

    for(const auto& [app_id, app_fea] : callback_app_feature) {
        if(app_set.count(app_id) > 0) {
            continue;
        } else {
            auto* dump_app = fe_dump.mutable_app_fea()->Add();
            dump_app->CopyFrom(*app_fea);
        }
    }
    ctx->_ready_send = true;
    ctx->_dump_feature = true;
}

void CallbackDumpService::dump_watchpoint(CallbackContextPtr context, const phx::FeRequest& fe_dump){
    const phx::CallbackRequest* req = context->get_callback_request();
    int64_t watch_point = req->callbackslotinfo().watchpoint();
    std::string kafka_key;
    std::string kafka_name;
    if (req->mediatype() == 1) {
        kafka_key = _internal_watchpoint_kafka_key;
        kafka_name = _internal_watchpoint_kafka_name;
    }
    else if (req->mediatype() == 2) {
        kafka_key = _external_watchpoint_kafka_key;
        kafka_name = _external_watchpoint_kafka_name;
    }
    else {
        HILOG_APP(ERROR) << LOG_HEAD(context) << " mediatype is neither 1 nor 2. trace dump failed";
        return;
    }
        
    if (watch_point != 0 && _watch_point_dump == "true" && is_watchpoint_sample(req->oaid())) {   
        if (watch_point & (1ULL << CALLBACK_SERVICE_REQUEST)) {
            dump_watchpoint_sample(context, req, fe_dump, CALLBACK_SERVICE_REQUEST, kafka_key, kafka_name);
        } 
        if (watch_point & (1ULL << CALLBACK_FEATURE_DUMP)) {
            dump_watchpoint_sample(context, req, fe_dump, CALLBACK_FEATURE_DUMP, kafka_key, kafka_name);
        }           
    }
}

bool CallbackDumpService::dump_watchpoint_sample(CallbackContextPtr context, const phx::CallbackRequest* req,
                             const phx::FeRequest& fe_dump, int32_t watchpoint_type, 
                             const std::string& kafka_key, const std::string& kafka_name) {
    try {                  
        butil::rapidjson::Document document;
        document.SetObject();
        butil::rapidjson::Document::AllocatorType& allocator = document.GetAllocator();
        butil::rapidjson::Value reqId(req->reqid().c_str(), static_cast<butil::rapidjson::SizeType>(req->reqid().length()), allocator);
        document.AddMember("reqId", reqId, allocator);
        document.AddMember("slotId", req->callbackslotinfo().slotid(), allocator);
        document.AddMember("sceneType", req->callbackslotinfo().scenetype(), allocator);
        document.AddMember("route", req->callbackslotinfo().route(), allocator);
        butil::rapidjson::Value service(ServerConfig::_monitor_service_name.c_str(), static_cast<butil::rapidjson::SizeType>(ServerConfig::_monitor_service_name.length()), allocator);
        document.AddMember("service", service, allocator);
        butil::rapidjson::Value az(FLAGS_az_info.c_str(), static_cast<butil::rapidjson::SizeType>(FLAGS_az_info.length()), allocator);
        document.AddMember("az", az, allocator);
        document.AddMember("watchpoint", watchpoint_type, allocator);
        document.AddMember("reqType", 0, allocator);
        int64_t timestamp = gettimeofday_ms();
        document.AddMember("timestamp", timestamp, allocator);
        butil::rapidjson::Value oaid(req->oaid().c_str(), static_cast<butil::rapidjson::SizeType>(req->oaid().length()), allocator);
        document.AddMember("oaid", oaid, allocator);
        butil::rapidjson::Value algotraceid(req->algotraceid().c_str(), static_cast<butil::rapidjson::SizeType>(req->algotraceid().length()), allocator);
        document.AddMember("algotraceid", algotraceid, allocator);

        if (_watch_point_json == "true") {
            //json上报
            std::string message_string = "";
            if (watchpoint_type == CALLBACK_SERVICE_REQUEST) {
                google::protobuf::util::MessageToJsonString(*req, &message_string);
            }    
            else if (watchpoint_type == CALLBACK_FEATURE_DUMP) {
                google::protobuf::util::MessageToJsonString(fe_dump, &message_string);
            }  
            butil::rapidjson::Value dump_data(message_string.c_str(), static_cast<butil::rapidjson::SizeType>(message_string.length()), allocator); 
            document.AddMember("dumpData", dump_data, allocator);   
        }
        else {
            //编码上报
            std::string message_string = "";                
            std::string encode_message_str = "";
            if (watchpoint_type == CALLBACK_SERVICE_REQUEST) {
                if (req->SerializeToString(&message_string)) {
                    encode_message_str = base64_encode(message_string); 
                }
            }
            else if (watchpoint_type == CALLBACK_FEATURE_DUMP) {
                if (fe_dump.SerializeToString(&message_string)) {
                    encode_message_str = base64_encode(message_string);
                }
            }  
            butil::rapidjson::Value dump_data(encode_message_str.c_str(), static_cast<butil::rapidjson::SizeType>(encode_message_str.length()), allocator);
            document.AddMember("dumpData", dump_data, allocator);
        }  
               
        butil::rapidjson::StringBuffer buffer;
        butil::rapidjson::Writer<butil::rapidjson::StringBuffer> writer(buffer);
        document.Accept(writer); 

        if (req->debuglevel() == 111) {            
            std::string file_name = "watchpoint_" + std::to_string(watchpoint_type) + ".json";
            std::ofstream ofs(file_name);
            if (ofs.is_open()) {
                ofs << buffer.GetString();
                ofs.close();
            } else {
                std::cerr << "DEBUGLEVEL 111 Failed to open file for writing watch_point.txt" << std::endl;
            }                        
        }
                                 
        hikafka::KafkaMessage* kafkaMessage = new hikafka::KafkaMessage();
        kafkaMessage->value = buffer.GetString();
        HILOG_APP(INFO) << "sample_dump size"<< kafkaMessage->value.size() << endl;
        if(hikafka::KafkaHelper::getInstance().sendMsg(kafka_name, kafkaMessage)==false){
            HILOG_APP(ERROR) << "kafka input queue fail "<< kafka_name;
            delete kafkaMessage;
        }
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << "Something wrong in watch point dump kafka,  " << e.what();
    }

    return ERROR_SUCCESS;                  
}

bool CallbackDumpService::dump_log_sample(CallbackContextPtr context, const phx::CallbackRequest* req, const phx::CallbackResponse* res,
                                    const phx::FeRequest& fe_dump, int32_t message_type) {
    std::string result;
    static const std::string sep = "|";

    result.append(get_current_time());
    result.append(sep);
    result.append(ServerConfig::_monitor_service_name);
    result.append(sep);
    result.append(std::to_string(req->callbackslotinfo().scenetype()));
    result.append(sep);
    result.append(req->algotraceid());
    result.append(sep);
    result.append(std::to_string(req->callbackslotinfo().slotid()));
    result.append(sep);
    result.append(req->reqid());
    result.append(sep);
    result.append(req->oaid());
    result.append(sep);
    result.append(std::to_string(req->callbackslotinfo().route()));
    result.append(sep);
    result.append(FLAGS_az_info);
    result.append(sep);
    result.append(std::to_string(message_type));
    result.append(sep);
    if (message_type == SAMPLE_DUMP_NORMAL_REQ_RES) {
        std::string requestString;
        google::protobuf::util::MessageToJsonString(*req, &requestString);                
        result.append(requestString);
        result.append(sep);
        std::string responseString;
        if (res->code() == 200 || res->code() == ERROR_BIZ_PROTO_REQID_EMPTY || 
            res->code() == ERROR_BIZ_PROTO_ADITEMS_EMPTY || res->code() == ERROR_BIZ_REPEATED_MATERIALID){
            google::protobuf::util::MessageToJsonString(*res, &responseString);
        }        
        result.append(responseString);
        result.append(sep);
    }
    else if (message_type == SAMPLE_DUMP_FEATUREDUMP) {
        std::string feature_dump_string;
        google::protobuf::util::MessageToJsonString(fe_dump, &feature_dump_string);                
        result.append(feature_dump_string);
        result.append(sep);
    }
    else if (message_type == SAMPLE_DUMP_EXCEPTION_REQ_RES) {
        std::string requestString;
        google::protobuf::util::MessageToJsonString(*req, &requestString);
        result.append(requestString);
        result.append(sep);
        std::string responseString;
        if (res->code() == 200 || res->code() == ERROR_BIZ_PROTO_REQID_EMPTY || 
            res->code() == ERROR_BIZ_PROTO_ADITEMS_EMPTY || res->code() == ERROR_BIZ_REPEATED_MATERIALID) {
            google::protobuf::util::MessageToJsonString(*res, &responseString);
        }
        result.append(responseString);
        result.append(sep);
    }
    else {
        result.append(sep);
    }
    result.append(std::to_string(context->get_predicttime()));
    result.append(sep);
    result.append(std::to_string(context->get_begin_time()));
    Util::Str::replace_all(result, "\r\n", "");

    if (req->debuglevel() == 111) {
        std::string file_name = "log_sample_" + std::to_string(message_type) + ".json";
        std::ofstream outFile(file_name);
        if (outFile.is_open()) {
            outFile << result;
            outFile.close();
        } else {
            std::cerr << "DEBUGLEVEL 111 Failed to open file for writing log_sample.txt" << std::endl;
        }
    }

    monitor::details::MonitorLogger::getInstance().WriteToBigdataLogger(result);

    return true;
}

bool CallbackDumpService::dump_kafka_sample(CallbackContextPtr context, const phx::CallbackRequest* req, const phx::CallbackResponse* res,
                                    const phx::FeRequest& fe_dump, int32_t message_type) {
    try {
        ::phx::SampleDumpInfo log_info;
        log_info.mutable_dumptime()->assign(get_current_time());
        log_info.mutable_service()->assign(ServerConfig::_monitor_service_name);
        log_info.set_scenetype(req->callbackslotinfo().scenetype());
        log_info.mutable_algotraceid()->assign(req->algotraceid());
        log_info.set_slotid(req->callbackslotinfo().slotid());
        log_info.mutable_reqid()->assign(req->reqid());
        log_info.mutable_oaid()->assign(req->oaid());
        log_info.set_route(req->callbackslotinfo().route());
        log_info.mutable_az()->assign(FLAGS_az_info);
        std::string sample_message_str = "";
        log_info.mutable_dumpdata()->assign(sample_message_str);
        log_info.set_costtime(context->get_predicttime());
        log_info.set_msgtype(message_type);

        std::string req_res_str = "";
        std::string request_str;
        if (req->SerializeToString(&request_str)) {                    
            req_res_str.append(request_str);
        }
        std::string response_str;
        if (res->code() == 200 || res->code() == ERROR_BIZ_PROTO_REQID_EMPTY || 
            res->code() == ERROR_BIZ_PROTO_ADITEMS_EMPTY || res->code() == ERROR_BIZ_REPEATED_MATERIALID)  {
            if (res->SerializeToString(&response_str)) {
                req_res_str.append(response_str);
            }
        }
        std::string encode_req_res_str = base64_encode(req_res_str);

        if (message_type == SAMPLE_DUMP_NORMAL_REQ_RES) {
            log_info.mutable_dumpdata()->assign(encode_req_res_str);                            
        }
        else if (message_type == SAMPLE_DUMP_FEATUREDUMP) {
            if (fe_dump.SerializeToString(&sample_message_str)) {
                std::string encode_str = base64_encode(sample_message_str);
                log_info.mutable_dumpdata()->assign(encode_str);
            }                
        }
        else if (message_type == SAMPLE_DUMP_EXCEPTION_REQ_RES) {
            log_info.mutable_dumpdata()->assign(encode_req_res_str);
        }

        hikafka::KafkaMessage* kafkaMessage = new hikafka::KafkaMessage();
        log_info.SerializePartialToString(&kafkaMessage->value);
        HILOG_APP(INFO) << "sample_dump size"<< kafkaMessage->value.size() << endl;
        if(hikafka::KafkaHelper::getInstance().sendMsg(_dump_log_kafka_name, kafkaMessage)==false){
            HILOG_APP(ERROR) << "kafka input queue fail "<< _dump_log_kafka_name;
            delete kafkaMessage;
        }

        if (req->debuglevel() == 111) {
            std::string file_name = "log_info_" + std::to_string(message_type) + ".json";
            debug::pb::SavePbToFile(file_name, log_info);
        }
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << "Something wrong in sample log dump,  " << e.what();
        return false;
    }

    return true;
}

int CallbackDumpService::dump_log(CallbackContextPtr context, const phx::FeRequest& fe_dump){
    const phx::CallbackRequest* req = context->get_callback_request();
    const phx::CallbackResponse* res = context->get_callback_response();
    const std::string& req_id = req->reqid();
    std::string result;

    if (!context->get_is_ex_req() && is_req_res_sample(req_id)) {
        if (!context->get_is_ex_req() && _dump_req_res_kafka == "true") {
            dump_kafka_sample(context, req, res, fe_dump, SAMPLE_DUMP_NORMAL_REQ_RES);
        }
        else {
            dump_log_sample(context, req, res, fe_dump, SAMPLE_DUMP_NORMAL_REQ_RES);
        }
    }

    if (context->get_is_ex_req() && is_ex_req_sample(req_id)) {
        if (_dump_ex_req_kafka == "true") {
            dump_kafka_sample(context, req, res, fe_dump, SAMPLE_DUMP_EXCEPTION_REQ_RES);
        }
        else {
            dump_log_sample(context, req, res, fe_dump, SAMPLE_DUMP_EXCEPTION_REQ_RES);
        }
    }  

    if (is_fe_dump_sample(req_id)) {
        if (_dump_fe_dump_kafka == "true") {
            dump_kafka_sample(context, req, res, fe_dump, SAMPLE_DUMP_FEATUREDUMP);
        } 
        else {
            dump_log_sample(context, req, res, fe_dump, SAMPLE_DUMP_FEATUREDUMP);
        }
    }

    return ERROR_SUCCESS;
}

std::string CallbackDumpService::get_current_time() {
    // 获取当前时间点
    auto now = std::chrono::system_clock::now();
    // 转换为time_t类型，以便使用std::put_time进行格式化
    auto now_c = std::chrono::system_clock::to_time_t(now);
    // 将time_t转换为tm结构体
    std::tm now_tm = *std::localtime(&now_c);

    // 使用stringstream进行格式化
    std::stringstream ss;
    ss << std::put_time(&now_tm, "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

}