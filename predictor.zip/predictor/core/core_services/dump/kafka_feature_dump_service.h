#pragma once

#include "core/core_context/core_context.h"
#include "core/core_services/dump/dump_feature_service.h"
#include <config_xml.h>
#include <string>
namespace Core {

class KafkaDumpFeatureService : public DumpFeatureService {
private:
    std::string _dump_kafka_name;
    std::string _dump_kafka_key;
    std::string _send_kafka;

public:
    KafkaDumpFeatureService() = default;
    virtual ~KafkaDumpFeatureService() = default;
    void initialize_xml(ConfigXmlPtr xml);

public:
    int dump_sink(CoreContextPtr context) override;
};

}