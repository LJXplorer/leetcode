#ifndef _CORE_SERVICES_DUMP_LOG_H
#define _CORE_SERVICES_DUMP_LOG_H
#include "hlframe/node.h"
#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"
#include <cstdint>

namespace Core {
    class DumpLogService : public ServiceBaseInfo{
    private:

        //日志采样上报
        int32_t _sample_req_res_ratio = 1; // request、response采样上报比例
        int32_t _sample_fe_dump_ratio = 1; // fedump采样上报比例
        int32_t _sample_ex_req_ratio = 1; // 异常请求采样上报比例
        int32_t _sample_predict_ratio = 1; // 推理请求响应上报比例
        std::string _dump_req_res_kafka = "false";
        std::string _dump_fe_dump_kafka = "false";
        std::string _dump_ex_req_kafka = "false";

        int32_t _sample_verify2_ratio = 0; //校验点2采样上报比例
        std::string _dump_old_verify = "false"; // 老链路上报

        //watchpoint上报
        int32_t _watch_point_ratio = 1; // watch point 采样上报比例
        std::string _watch_point_dump = "false"; // watch point是否上报
        std::string _watch_point_json = "false"; // watch point是否采用json上报
        
        int32_t _max_sample_ratio = 10000;
        int32_t _max_sample_qps = 10000;

        int32_t _verify_batch_sample_num = 2; // 精排校验点上报用于随机采样的分包数量

        //dump log 使用的kafka
        std::string _dump_log_kafka_name = "dump_log";
        std::string _dump_log_kafka_key = "dump_log";
        std::string _internal_watchpoint_kafka_name = "internal_watchpoint";
        std::string _internal_watchpoint_kafka_key = "internal_watchpoint";
        std::string _external_watchpoint_kafka_name = "external_watchpoint";
        std::string _external_watchpoint_kafka_key = "external_watchpoint";
        //大模型query未命中上报kafka
        std::string _dump_missed_query_kafka_name = "missed_query";
        std::string _dump_missed_query_kafka_key = "missed_query";
        //校验点上报kafka
        std::string _dump_verify_kafka_name = "sample_verify_dump";
        std::string _dump_verify_kafka_key = "sample_verify_dump";

        // hash
        int32_t _FE_SAMPLE_BASE = 10000;
        int32_t _SEED = 0x7f3a21eaL;        
        int32_t _ONE_HUNDRED = 10000; // 采样的基数，100为百分比
        int32_t _VERIFY2_SAMPLE_BASE = 10000;
   
    public:
        DumpLogService(){
        }

        virtual ~DumpLogService(){

        }

        virtual void initialize(ConfigXmlPtr xml);
        virtual void initialize_xml(ConfigXmlPtr xml);
        virtual void initialize(GraphContextPtr context);
        virtual int do_service(GraphContextPtr context);
    private:
        virtual  int process(CoreContextPtr context) override;

        std::string get_current_time();
        void dump_watchpoint(CoreContextPtr context);
        

    public:
        virtual int dump_log(CoreContextPtr context);//dump请求响应
        int dump_offline_log(CoreContextPtr context);
        int dump_offline_log_new(CoreContextPtr context);
        bool dump_missed_query(CoreContextPtr context);
        bool dump_log_sample(CoreContextPtr context, const phx::PredictorRequest* req, const phx::PredictorResponse* res,
                             const phx::FeRequest* fe_dump, int32_t message_type);
        bool dump_kafka_sample(CoreContextPtr context, const phx::PredictorRequest* req, const phx::PredictorResponse* res,
                             const phx::FeRequest* fe_dump, int32_t message_type);
        bool dump_watchpoint_sample(CoreContextPtr context, const phx::PredictorRequest* req,
                             const phx::FeRequest* fe_dump, int32_t watchpoint_type, 
                             const std::string& kafka_key, const std::string& kafka_name);
        bool dump_verify_sample(CoreContextPtr context, const phx::PredictorRequest* req, const phx::PredictorResponse* res,
                             const phx::FeRequest* fe_dump, int32_t message_type);

        int32_t get_hash(const std::string& salt_str) {
            uint32_t out;
            butil::MurmurHash3_x86_32(salt_str.c_str(), salt_str.length(), _SEED, &out);
            return  out % _ONE_HUNDRED;
        }

        int32_t get_fe_hash(const std::string& salt_str) {
            uint32_t out;
            butil::MurmurHash3_x86_32(salt_str.c_str(), salt_str.length(), _SEED, &out);
            return  out % _FE_SAMPLE_BASE;
        }

        bool is_req_res_sample(const std::string& req_id) {
            int32_t hash_res = get_hash(req_id);
            return hash_res < _sample_req_res_ratio;
        }

        bool is_fe_dump_sample(const std::string& req_id) {
            int32_t hash_res = get_fe_hash(req_id);
            return hash_res < _sample_fe_dump_ratio;
        }

        bool is_predict_sample(const std::string& req_id) {
            int32_t hash_res = get_hash(req_id);
            return hash_res < _sample_predict_ratio;
        }

        bool is_ex_req_sample(const std::string& req_id) {
            int32_t hash_res = get_hash(req_id);
            return hash_res < _sample_ex_req_ratio;
        }

        bool is_watchpoint_sample(const std::string& req_id) {
            int32_t hash_res = get_hash(req_id);
            return hash_res < _watch_point_ratio;
        }

        int32_t get_verify2_hash(const std::string& salt_str) {
            uint32_t out;
            butil::MurmurHash3_x86_32(salt_str.c_str(), salt_str.length(), _SEED, &out);
            return  out % _VERIFY2_SAMPLE_BASE;
        }

        bool is_verify2_sample(const CoreContextPtr &context) {
            int32_t hash_res = get_verify2_hash(context->get_req_id());
            if (_sample_verify2_ratio > 0) {
                return hash_res < _sample_verify2_ratio;
            }
            else {
                // max(prerank, ctr, cvr);
                const auto &tmp = std::max(context->_cvr_sample_ratio, context->_ctr_sample_ratio);
                const auto &max_sample_ratio = std::max(tmp, context->_prerank_sample_ratio);
                return hash_res < std::min(max_sample_ratio, _max_sample_ratio);
            }
        }

    };
    
}

#endif
