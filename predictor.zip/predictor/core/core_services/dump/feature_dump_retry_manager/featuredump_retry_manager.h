#ifndef _CORE_FEATUREDUMP_RETRY_MGR_H
#define _CORE_FEATUREDUMP_RETRY_MGR_H
#include "core/core_context/callback_context.h"
#include "core/core_context/core_context.h"
#include <boost/lockfree/queue.hpp>
#include <thread>
#include <thread_pool.h>
namespace Core{
    class FeatureDumpContextInfo {
    public:
        std::chrono::steady_clock::time_point time_stamp;
        std::shared_ptr<CallbackContext> context;
        FeatureDumpContextInfo()= default;
        FeatureDumpContextInfo(std::chrono::steady_clock::time_point time_stamp, CallbackContextPtr context):time_stamp(time_stamp),context(context){}
        ~FeatureDumpContextInfo(){}
    };

    class FeatureDumpRetryManager{
    public:
        std::shared_ptr<boost::lockfree::queue<FeatureDumpContextInfo*>> _featuredump_queue;
        std::vector<std::thread> _featuredump_retry_thread_ids;

        FeatureDumpRetryManager();
        ~FeatureDumpRetryManager();

        void init();

        static FeatureDumpRetryManager& instance() {
            static FeatureDumpRetryManager inst;
            return inst;
        }

        static void handle(FeatureDumpRetryManager* mgr);
        bool push_to_featuredump_queue(FeatureDumpContextInfo* dataInfo);
        static void retry(std::shared_ptr<CallbackContext> context);
    };

}//core
#endif
