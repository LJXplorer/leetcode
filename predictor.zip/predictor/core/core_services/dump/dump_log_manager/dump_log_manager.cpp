
#include "dump_log_manager.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/defs.h"
#include <atomic>
#include <log_helper.h>
#include <string>
namespace Core {
    DEFINE_int32(dump_log_thread_num, 5, "dump_log_thread_num");
    DumpLogManager::DumpLogManager(){
        _dump_thread_ids.resize(FLAGS_dump_log_thread_num);
    }
    
    bvar::Adder<int64_t> DumpLogManager::dump_log_counter{"oom", "dump_log_count"};
    bvar::Adder<uint64_t> DumpLogManager::fetch_failed_counter{"oom", "dump_log_fetch_failed_count"};
    bvar::Adder<uint64_t> DumpLogManager::try_fetch_counter{"oom", "dump_log_try_fetch_count"}; 
    bvar::Adder<uint64_t> DumpLogManager::fetch_success_counter{"oom", "dump_log_fetch_success_count"};

    DumpLogManager::~DumpLogManager(){
    }
    
    void DumpLogManager::init(){
        _dump_log_info_queue = std::make_shared<boost::lockfree::queue<DumpLogArgs*>>(500);
        for(int32_t i = 0;i < FLAGS_dump_log_thread_num;i++){
            _dump_thread_ids[i] = std::thread(DumpLogManager::handle_log, this);
            _dump_thread_ids[i].detach();
        }  
    }

    void DumpLogManager::handle_log(DumpLogManager* mgr){
        pthread_setname_np(pthread_self(), "dumplog");
        while(true) {
            DumpLogArgs* arg = nullptr;
            bool get = mgr->_dump_log_info_queue->pop(arg);
            if (ServerConfig::_dump_monitor_enable.load()) {
                DumpLogManager::try_fetch_counter << 1;
            }
            
            if (get && arg != nullptr) {
               if (ServerConfig::_dump_monitor_enable) {
                   DumpLogManager::fetch_success_counter << 1;
               }
               
               arg->_service->process(arg->_ctx);
               if (arg != nullptr) {
                    delete arg;
                    arg = nullptr;
                    if (ServerConfig::_dump_monitor_enable && dump_log_counter.get_value() > 0) {
                        dump_log_counter << -1;
                    } 
                }
            }else{
                if (ServerConfig::_dump_monitor_enable) {
                    DumpLogManager::fetch_failed_counter << 1;
                }
                
                usleep(10000);
                continue;
            }
        }  
    }

    void DumpLogManager::push_dump_log_to_queue(DumpLogArgs* arg){
        if(arg == nullptr){
            HILOG_APP(INFO)<<"arg,push_dump_to_queue null";
            return;
        }
        MonitorMgr::redis_report_common(
            "HONOR", 
            "dump_log_queue", 
            0, "push_num", 1, FsSource::REDIS, STRING_DEFAULT, STRING_TOTALUP);
        bool ret = _dump_log_info_queue->bounded_push(arg);
        if (!ret) {
            HILOG_APP(ERROR) << "push args to queue failed! release resource!";
            MonitorMgr::redis_report_common(
                                "HONOR", 
                                "dump_log_queue", 
                                0, "push_failed_num", 1, FsSource::REDIS, STRING_DEFAULT, STRING_TOTALUP);
            if (ServerConfig::_dump_monitor_enable && dump_log_counter.get_value() > 0) {
                dump_log_counter << -1;
            }
            
            delete arg;
        }
        HILOG_APP(INFO) <<arg->_dump_type <<",push_dump_to_queue ret:"<<ret;
    }

}
