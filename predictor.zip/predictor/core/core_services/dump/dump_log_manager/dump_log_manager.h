#ifndef _CORE_DUMP_LOG_MGR_H
#define _CORE_DUMP_LOG_MGR_H
#include "core/core_services/base_service/service_info.h"
#include <atomic>
#include <boost/lockfree/queue.hpp>
namespace Core {
    enum DumpLogType{
        DUMP_LOG_UNKNOWN = 0,
        DUMP_LOG_FS = 1,
        DUMP_LOG_FE = 2,
        DUMP_LOG_LOG = 3,
    };

    struct DumpLogArgs{
        DumpLogType _dump_type = DUMP_LOG_UNKNOWN;
        CoreContextPtr _ctx;
        ServiceBaseInfo* _service = nullptr;
    }; 
    
    class DumpLogManager {
    public:
        std::shared_ptr<boost::lockfree::queue<DumpLogArgs*>> _dump_log_info_queue;
        std::vector<std::thread> _dump_thread_ids;
        DumpLogManager();
        ~DumpLogManager();
    public:
        void init();

        static DumpLogManager& instance() {
            static DumpLogManager inst;
            return inst;
        }

        static void handle_log(DumpLogManager* mgr);
        void push_dump_log_to_queue(DumpLogArgs* arg);
        static bvar::Adder<int64_t> dump_log_counter;
        static bvar::Adder<uint64_t> try_fetch_counter;
        static bvar::Adder<uint64_t> fetch_failed_counter;
        static bvar::Adder<uint64_t> fetch_success_counter;
    };

}//core
#endif
