
#include "dump_manager.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/defs.h"
#include "core/utils/monitor_mgr.h"
#include <atomic>
#include <bvar/reducer.h>
#include <log_helper.h>
namespace Core {
    DEFINE_int32(dump_thread_num, 25, "dump_thread_num");
    DumpManager::DumpManager(){
        _dump_thread_ids.resize(FLAGS_dump_thread_num);
    }
    bvar::Adder<int64_t>  DumpManager::dump_counter {"oom", "dump_count"};
    bvar::Adder<uint64_t> DumpManager::fetch_failed_counter{"oom", "dump_fetch_failed_count"};
    bvar::Adder<uint64_t> DumpManager::try_fetch_counter{"oom", "dump_try_fetch_count"};    
    bvar::Adder<uint64_t> DumpManager::fetch_success_counter{"oom", "dump_fetch_success_count"};

    DumpManager::~DumpManager(){
    }
    
    void DumpManager::init(){
        _dump_info_queue = std::make_shared<boost::lockfree::queue<DumpArgs*>>(800);
        for(int32_t i = 0;i < FLAGS_dump_thread_num;i++){
            _dump_thread_ids[i] = std::thread(DumpManager::handle, this);
            _dump_thread_ids[i].detach();
        }  
    }

    void DumpManager::handle(DumpManager* mgr){
        pthread_setname_np(pthread_self(), "dump");
        while(true) {
            DumpArgs* arg = nullptr;
            bool get = mgr->_dump_info_queue->pop(arg);
            if (ServerConfig::_dump_monitor_enable) {
                DumpManager::try_fetch_counter << 1;
            }

            if (get && arg != nullptr) {
               arg->_service->process(arg->_ctx);
               if (ServerConfig::_dump_monitor_enable) {
                    DumpManager::fetch_success_counter << 1;
               }
               
               if (arg != nullptr) {
                    delete arg;
                    if (ServerConfig::_dump_monitor_enable && DumpManager::dump_counter.get_value() > 0) {
                        DumpManager::dump_counter << -1;
                    }
                     
                    arg = nullptr;
                }
            }else{
                usleep(1000);
                if (ServerConfig::_dump_monitor_enable) {
                    DumpManager::fetch_failed_counter << 1;
                }

                continue;
            }
        }  
    }

    void DumpManager::push_dump_to_queue(DumpArgs* arg){
        if(arg == nullptr){
            HILOG_APP(INFO)<<"arg,push_dump_to_queue null";
            return;
        }
        // TODO: dump queue monitor
        MonitorMgr::redis_report_common(
            "HONOR", 
            "dump_queue", 
            0, "push_num", 1, FsSource::REDIS, STRING_DEFAULT, STRING_TOTALUP);

        bool ret = _dump_info_queue->bounded_push(arg);        
        if (!ret) {
            HILOG_APP(ERROR) << "push args to queue failed! release resource";
            // TODO: dump queue monitor
            MonitorMgr::redis_report_common(
                                "HONOR", 
                                "dump_queue", 
                                0, "push_failed_num", 1, FsSource::REDIS, STRING_DEFAULT, STRING_TOTALUP);
            if (ServerConfig::_dump_monitor_enable && DumpManager::dump_counter.get_value() > 0) {
                DumpManager::dump_counter << -1;
            }


            delete arg;
        }
        HILOG_APP(INFO) <<arg->_dump_type <<",push_dump_to_queue ret:"<<ret;
    }

}
