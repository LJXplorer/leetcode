#ifndef _CORE_DUMP_MGR_H
#define _CORE_DUMP_MGR_H
#include "core/core_services/base_service/service_info.h"
#include <atomic>
#include <boost/lockfree/queue.hpp>
#include <bvar/reducer.h>
#include <cstdint>
namespace Core {
    enum DumpType{
        DUMP_UNKNOWN = 0,
        DUMP_FS = 1,
        DUMP_FE = 2,
        DUMP_LOG = 3,
    };

    struct DumpArgs{
        DumpType _dump_type = DUMP_UNKNOWN;
        CoreContextPtr _ctx;
        ServiceBaseInfo* _service = nullptr;
    }; 
    
    class DumpManager {
    public:
        std::shared_ptr<boost::lockfree::queue<DumpArgs*>> _dump_info_queue;
        std::vector<std::thread> _dump_thread_ids;
        DumpManager();
        ~DumpManager();
    public:
        void init();

        static DumpManager& instance() {
            static DumpManager inst;
            return inst;
        }

        static void handle(DumpManager* mgr);
        void push_dump_to_queue(DumpArgs* arg);
        static bvar::Adder<int64_t> dump_counter;
        static bvar::Adder<uint64_t> try_fetch_counter;
        static bvar::Adder<uint64_t> fetch_failed_counter;
        static bvar::Adder<uint64_t> fetch_success_counter;
    };

}//core
#endif
