#pragma once
#include "common/hidict/callback.h"
#include "common/hidict/dict.h"
#include "common/hidict/dict_logger.h"
#include "core/utils/monitor_mgr.h"
#include "core/core_services/dict/dict_push.h"
#include "phx-fe/ad_dict/jieba_dict.h"
#include <exception>
#include <string>
namespace Core {
    template<typename DictType>
    class AdDictCallback : public hidict::DictCallback {
    public:
        bool OnLoadFinished(time_t n, bool load_suc) override {
            hidict::DictInfo *dict_info = this->dict_info_;
            try {
                //上报加载耗时
                Core::MonitorMgr::percent_report_dict(dict_info->m_clazz_name, dict_info->m_path, dict_info->get_latest_version(),load_suc == true ? 0 : -1,
                                                    "dict_load_cost", time(NULL) - n);
                //上报词典解析失败数量
                Core::MonitorMgr::common_report_dict(dict_info->m_clazz_name, dict_info->m_path, dict_info->get_latest_version(),load_suc == true ? 0 : -1,
                                                    "dict_parse_failed_num", dict_info->parse_failed_num);
                //上报词典天版本
                Core::MonitorMgr::percent_report_dict(dict_info->m_clazz_name, dict_info->m_path, dict_info->get_latest_version(),load_suc == true ? 0 : -1,
                                                    "dict_day_version", dict_info->get_version(dict_info->m_day_version));
                //上报词典分钟版本
                Core::MonitorMgr::percent_report_dict(dict_info->m_clazz_name, dict_info->m_path, dict_info->get_latest_version(),load_suc == true ? 0 : -1,
                                                    "dict_minute_version", dict_info->get_version(dict_info->m_minute_version));
                //上报词典加载状态，
                Core::MonitorMgr::common_report_dict(
                        dict_info_->m_clazz_name, dict_info->m_path,dict_info->get_latest_version(),
                        (load_suc && dict_info->dictErrorManager.getErrorField() == 0 && dict_info->parse_failed_num <1) == true ? 0 : -1, "dict_load_status",
                        1);
                //上报词典加载数量
                Core::MonitorMgr::common_report_dict(
                        dict_info->m_clazz_name, dict_info->m_path,dict_info->get_latest_version(), load_suc == true ? 0 : -1, "dict_load_num",
                        dict_info->load_succ_num);
                
                //打印加载数量
                hidict::DictLogger::getLogger()->hiLogWriter("dict ["+ std::to_string(time(NULL)) + "] " 
                                                            + "class [" + dict_info->m_clazz_name + "] load succ size: " + std::to_string(dict_info->load_succ_num) + " parse failed size: " + std::to_string(dict_info->parse_failed_num));

                // 词典加载信息通过 http 逐条上报
                if (dictpush::DictPushConfig::dict_push_enable_.load(std::memory_order_relaxed)) {
                    dictpush::PodMeta meta = dictpush::GetPodMeta();
                    nlohmann::json payload;
                    payload["podName"] = meta.pod_name;
                    payload["podIP"] = meta.pod_ip;
                    payload["dictName"] = dict_info->m_clazz_name;
                    payload["dictVersion"] = dict_info->get_latest_version();
                    payload["status"] = (load_suc && dict_info->dictErrorManager.getErrorField() == 0 && dict_info->parse_failed_num < 1) == true ? 1 : 2;
                    payload["loadEndTime"] = dictpush::FormatTimeYmdHMS(time(NULL));
                    dictpush::DictPusher::Post(std::move(payload));
                }
    
            } catch(const std::exception& e) {
                std::cout <<"upload dict aiops failed! exception: "<< e.what() << std::endl;
            }
            
            
            return true;
        }
        void OnError() override {
            if (this->dict_info_->dictErrorManager.getErrorField() > 0) {
                if (this->dict_info_->dictErrorManager.hasError(hidict::DICT_DIR_EMPTY)) {
                    //上报词典目录是空状态
                    Core::MonitorMgr::common_report_dict(this->dict_info_->m_clazz_name, this->dict_info_->m_path,this->dict_info_->get_latest_version(), -1,
                                                         "dict_dir_empty", 1);
                }
                if (this->dict_info_->dictErrorManager.hasError(hidict::DICT_NO_SUCC_FILE)) {
                    //上报词典没有SUCCESS FILE状态
                    Core::MonitorMgr::common_report_dict(this->dict_info_->m_clazz_name, this->dict_info_->m_path, this->dict_info_->get_latest_version(),-1,
                                                         "dict_no_succ_file", 1);
                }
                if (this->dict_info_->dictErrorManager.hasError(hidict::DICT_NO_TASK_INFO)) {
                    //上报词典没有task info 字段
                    Core::MonitorMgr::common_report_dict(this->dict_info_->m_clazz_name, this->dict_info_->m_path, this->dict_info_->get_latest_version(),-1,
                                                         "dict_no_task_file", 1);
                }
            }
        }
    };
    template<>
    class AdDictCallback<AdDict::JieBaDict> : public hidict::DictCallback {
        bool OnLoadFinished(time_t n, bool load_suc) override {
            std::cout << "OnLoadFinished: dict class = [" << this->dict_info_->m_clazz_name << "]; dict_path = ["
                      << this->dict_info_->m_path << "]; dict_load_status = ["
                      << load_suc << "]\n";
            Core::MonitorMgr::common_report_dict("JieBaDict", this->dict_info_->m_path, "default",0,
                                                 "dict_load_status", 1);
            return true;
        }
        void OnError() override {
        }
    };

}// namespace Core