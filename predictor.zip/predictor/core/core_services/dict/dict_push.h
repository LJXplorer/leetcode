#pragma once
#include <atomic>
#include <mutex>
#include <string>
#include "nlohmann/json.hpp"
#include <brpc/channel.h>

namespace dictpush {

class DictPushConfig {
public:
    static std::atomic<bool> dict_push_enable_;
    static std::string push_url_;
    static std::string push_uri_;
    static void set(bool enable, const std::string& url, const std::string& uri);
};

class DictPusher {
public:
    static void Post(nlohmann::json&& payload_json); // 同步直推
private:
    static bool EnsureChannelInitialized();          // 推送资源初始化
    static bool ExecuteHttpPost(const std::string& json_body);  // 执行 HTTP POST

    // 初始化
    static std::atomic<bool> channel_initialized_;
    static std::mutex init_mutex_;
    static brpc::Channel channel_;
    static std::string current_channel_url_;
};

// 获取 pod 元信息
struct PodMeta {
    std::string pod_name;
    std::string pod_ip;
};
PodMeta GetPodMeta();   // 从环境变量/host 获取元信息
std::string FormatTimeYmdHMS(time_t t);

} // namespace dictpush