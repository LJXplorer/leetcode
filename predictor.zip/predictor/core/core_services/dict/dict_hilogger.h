#include "common/hidict/dict_logger.h"
#include <log_helper.h>
namespace Core {
    class DictHilogger: public hidict::DictLogger {
        void hiLogWriter(const std::string& message) override {
            HILOG_APP(ERROR) << message;
        }
    };
}