#pragma once
#include "common/config/base_config.h"
#include "common/config/service_config.h"
#include "common/config/base_config.h"
#include "common/hilog/log_helper.h"
#include "phx-fe/ad_dict/ad_dict_manager.h"

namespace Core {

class AdDictConfigMgr {
// using dict_map = std::unordered_map<std::string, std::string >;
public:
    static AdDictConfigMgr& instance() {
        static AdDictConfigMgr inst;
        return inst;
    }

    int init(const config::ConfigServiceCfg& cfg,
                    const std::string& group_id,
                    const std::string& data_id);
    int update(const std::string& content);

    bool is_first_load = true;

};

struct DicthNacosConfig : public config::ListenableConfig {
        std::string group_id;
        std::string data_id;
        DicthNacosConfig(const std::string& group_id, const std::string& data_id)
            : group_id(group_id), data_id(data_id) {}

        int OnConfigChanged(const std::string& new_config) override {
            HILOG_APP(INFO) << "new content: \n" << new_config << std::endl;
            return AdDictConfigMgr::instance().update(new_config);
        }

        config::ConfigSource GetConfigSource() override {
            return {
                .group_id = group_id,
                .data_id = data_id
            };
        }
    };

};  