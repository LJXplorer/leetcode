//
// Created by l00011609 on 2025/6/24.
//

#ifndef MLOPSSERVING_RAGGGED_TENSOR_UTIL_H
#define MLOPSSERVING_RAGGGED_TENSOR_UTIL_H

#include <google/protobuf/arena.h>
#include <google/protobuf/message.h>
#include <google/protobuf/repeated_field.h>

#include "tf/flow.pb.h"

#include <iostream>
#include <memory>
#include <variant>
#include <vector>

namespace _pb = google::protobuf;

namespace Core {

    struct TensorView {
        const ::proto::flow::TensorProto *tensor_;
        int32_t offset_;
        int32_t length_;

        TensorView() {
            tensor_ = nullptr;
            offset_ = 0;
            length_ = 0;
        }

        TensorView(const ::proto::flow::TensorProto *tensor, int32_t offset, int32_t length) {
            tensor_ = tensor;
            offset_ = offset;
            length_ = length;
        }

        void set(const ::proto::flow::TensorProto *tensor, int32_t offset, int32_t length) {
            tensor_ = tensor;
            offset_ = offset;
            length_ = length;
        }

        int32_t length() {
            return length_;
        }

        int64_t int64_val(int32_t index) const {
            return (tensor_->dtype() == ::proto::flow::DataType::DT_INT64) ? tensor_->int64_val(offset_ + index) : 0;
        }

        const int64_t *int64_val() const {
            return (tensor_->dtype() == ::proto::flow::DataType::DT_INT64) ? tensor_->int64_val().data() + offset_ : nullptr;
        }

        float float_val(int32_t index) const {
            return (tensor_->dtype() == ::proto::flow::DataType::DT_FLOAT) ? tensor_->float_val(offset_ + index) : 0.0f;
        }

        const float *float_val() const {
            return (tensor_->dtype() == ::proto::flow::DataType::DT_FLOAT) ? tensor_->float_val().data() + offset_ : nullptr;
        }

        std::string string_val(int32_t index) const {
            return (tensor_->dtype() == ::proto::flow::DataType::DT_STRING) ? tensor_->string_val(offset_ + index) : std::string();
        }

        const std::string *const *string_val() const {
            return (tensor_->dtype() == ::proto::flow::DataType::DT_STRING) ? tensor_->string_val().data() + offset_ : nullptr;
        }
    };

    class RaggedTensorUtil {
    public:
        template<typename T>
        static ::proto::flow::TensorProto *CreateTensor(const std::vector<T> &flat_values);

        template<typename T>
        static ::proto::flow::TensorProto *CreateTensor(const std::vector<std::vector<T>> &values, int32_t total_size = 0, google::protobuf::Arena* arena = nullptr);

        template<typename T>
        static ::proto::flow::TensorProto *CreateTensor(const std::vector<_pb::RepeatedField<T>> &values, int32_t total_size = 0);
        
        template<typename T>
        static ::proto::flow::TensorProto *CreateTensor(const std::vector<const _pb::RepeatedField<T>*> &values, int32_t total_size = 0, google::protobuf::Arena* arena = nullptr);
        
        template<typename T>
        static ::proto::flow::TensorProto *CreateTensor(const std::vector<const _pb::RepeatedPtrField<T>*> &values, int32_t total_size = 0, google::protobuf::Arena* arena = nullptr);

        template<typename T>
        static ::proto::flow::TensorProto *CreateTensor(const std::vector<const _pb::RepeatedField<T>*> &values,int32_t begin_index, int32_t end_index, int32_t total_size = 0, google::protobuf::Arena* arena = nullptr);

        template<typename T>
        static ::proto::flow::TensorProto *CreateTensor(const std::vector<const _pb::RepeatedPtrField<T>*> &values,int32_t begin_index, int32_t end_index, int32_t total_size = 0, google::protobuf::Arena* arena = nullptr);
        
        /*****************************************************************/

        // 从一个已经打平的1-D张量构建RaggedTensorProto
        template<typename T>
        static ::proto::flow::RaggedTensorProto *FromUniformRowLength(const std::vector<T> &flat_values, int32_t uniform_row_length);

        template<typename T>
        static ::proto::flow::RaggedTensorProto *FromRowSplits(const std::vector<T> &flat_values,
                                                const std::vector<int32_t> &row_splits);

        template<typename T>
        static ::proto::flow::RaggedTensorProto *FromNestedRowSplits(const std::vector<T> &flat_values,
                                                      const std::vector<std::vector<int32_t>> &nested_splits);

        /*****************************************************************/

        static ::proto::flow::RaggedTensorProto *FromUniformRowLength(::proto::flow::TensorProto *flat_values, int32_t uniform_row_length);

        static ::proto::flow::RaggedTensorProto *FromRowSplits(::proto::flow::TensorProto *flat_values, const std::vector<int32_t> &row_splits, google::protobuf::Arena* arena = nullptr);

        static ::proto::flow::RaggedTensorProto *FromNestedRowSplits(::proto::flow::TensorProto *flat_values,
                                                      const std::vector<std::vector<int32_t>> &nested_splits);

        /*****************************************************************/

        // 从多个不同的原始张量构建RaggedTensorProto
        template<typename T>
        static ::proto::flow::RaggedTensorProto *FromValues(const std::vector<std::vector<T>> &values, google::protobuf::Arena* arena = nullptr);

        template<typename T>
        static ::proto::flow::RaggedTensorProto *FromValues(const std::vector<_pb::RepeatedField<T>> &values);

        template<typename T>
        static ::proto::flow::RaggedTensorProto *FromValues(const std::vector<const _pb::RepeatedField<T>*> &values, google::protobuf::Arena* arena = nullptr);

        template<typename T>
        static ::proto::flow::RaggedTensorProto *FromValues(const std::vector<const _pb::RepeatedPtrField<T>*> &values, google::protobuf::Arena* arena = nullptr);

        template<typename T>
        static ::proto::flow::RaggedTensorProto *FromValues(const std::vector<const _pb::RepeatedField<T>*> &values,int32_t begin_index, int32_t end_index, google::protobuf::Arena* arena = nullptr);

        template<typename T>
        static ::proto::flow::RaggedTensorProto *FromValues(const std::vector<const _pb::RepeatedPtrField<T>*> &values,int32_t begin_index, int32_t end_index, google::protobuf::Arena* arena = nullptr);

        static ::proto::flow::RaggedTensorProto *FromValues(const std::vector<::proto::flow::RaggedTensorProto *> &values);

        /*****************************************************************/

        static int32_t GetBatchSize(const ::proto::flow::RaggedTensorProto *rt);

        static TensorView GetValues(const ::proto::flow::RaggedTensorProto *rt);

        static TensorView GetValuesByIndex(const ::proto::flow::RaggedTensorProto *rt, const std::vector<int32_t> &indices);

        /*****************************************************************/
        static void PrintRaggedTensor(::proto::flow::RaggedTensorProto *rt);

    private:
        static void concat(::proto::flow::RaggedTensorProto *rt1, ::proto::flow::RaggedTensorProto *rt2, int32_t axis = 0);
    };

}// namespace Core

#endif//MLOPSSERVING_RAGGGED_TENSOR_UTIL_H
