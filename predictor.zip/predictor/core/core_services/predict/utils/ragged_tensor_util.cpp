﻿//
// Created by l00011609 on 2025/6/24.
//

#include "ragged_tensor_util.h"
#include <google/protobuf/arena.h>
#include <sstream>

// inner function ------------------------------------------------------------------------
namespace Core {

    const int32_t MAX_PRINT = 100;

    template<typename T>
    std::string vector_2_String(const std::vector<T> &vec, int32_t max = MAX_PRINT) {
        std::ostringstream oss;
        oss << "[";
        for (int32_t i = 0; i < vec.size() && i < max; i++) {
            oss << vec[i];
            if (i != vec.size() - 1)
                oss << ", ";// 非末尾元素添加逗号
        }

        if (max < vec.size()) {
            oss << "......";
        }

        oss << "]";
        return oss.str();
    }

    template<typename T>
    std::string vector_2_String(const _pb::RepeatedField<T> &vec, int32_t max = MAX_PRINT) {
        std::ostringstream oss;
        oss << "[";
        for (int32_t i = 0; i < vec.size() && i < max; i++) {
            oss << vec.Get(i);
            if (i != vec.size() - 1)
                oss << ", ";// 非末尾元素添加逗号
        }

        if (max < vec.size()) {
            oss << "......";
        }

        oss << "]";
        return oss.str();
    }

    template<typename T>
    std::string vector_2_String(const _pb::RepeatedPtrField<T> &vec, int32_t max = MAX_PRINT) {
        std::ostringstream oss;
        oss << "[";
        for (int32_t i = 0; i < vec.size() && i < max; i++) {
            oss << vec.Get(i);
            if (i != vec.size() - 1)
                oss << ", ";// 非末尾元素添加逗号
        }

        if (max < vec.size()) {
            oss << "......";
        }

        oss << "]";
        return oss.str();
    }

    std::pair<int32_t, int32_t> get_values_range(const _pb::RepeatedPtrField<::proto::flow::RowPartitionProto> &row_partition,
                                                 const int32_t row_index, int32_t start, int32_t end,
                                                 const std::vector<int32_t> &indices) {
        const auto range = [&](const ::proto::flow::RowPartitionProto &row, const int32_t start, const int32_t end,
                               const int32_t index) -> std::pair<int32_t, int32_t> {
            if (index >= end - start) {
                std::cout << "Error: index = " << index << " is invalid, start = " << start << ", end = " << end
                          << std::endl;
                return {0, 0};
            }

            switch (row.partition_case()) {
                case ::proto::flow::RowPartitionProto::kRowSplits: {
                    auto row_splits = row.row_splits().int_val();
                    if (index == -1) {
                        return {row_splits[start], row_splits[end]};
                    } else {
                        return {row_splits[start + index], row_splits[start + index + 1]};
                    }
                }

                case ::proto::flow::RowPartitionProto::kUniformRowLength: {
                    auto len = row.uniform_row_length();
                    auto nrows = row.nrows();
                    if (index == -1) {
                        return {start * len, end * len};
                    } else {
                        return {(start + index) * len, (start + index + 1) * len};
                    }
                }

                default:
                    std::cout << "Error: unsupported partition type!" << std::endl;
                    return {0, 0};
            }
        };

        int32_t index = -1;
        if (row_index < indices.size()) {
            index = indices[row_index];
        }

        auto [start_i, end_i] = range(row_partition[row_index], start, end, index);
        if (start_i == end_i) {
            return {start_i, end_i};
        }

        if (row_index == row_partition.size() - 1) {
            return {start_i, end_i};
        }

        return get_values_range(row_partition, row_index + 1, start_i, end_i, indices);
    }

    void set_row_partition(::proto::flow::RaggedTensorProto *rt, const std::vector<std::vector<int32_t>> &nested_splits) {
        rt->set_ragged_rank(nested_splits.size());
        rt->add_dense_shape(nested_splits[0].size() - 1);

        for (int32_t i = 0; i < nested_splits.size(); i++) {
            auto row_splits = nested_splits[i];
            int32_t uniform_row_length = row_splits[1] - row_splits[0];

            ::proto::flow::TensorProto *row_splits_tensor = new ::proto::flow::TensorProto();
            row_splits_tensor->set_dtype(::proto::flow::DataType::DT_INT32);
            row_splits_tensor->add_shape(row_splits.size());
            row_splits_tensor->mutable_int_val()->Add(row_splits.begin(), row_splits.end());
            for (int32_t j = 0; j < row_splits.size(); j++) {
                if (uniform_row_length >= 0 && j > 0 && row_splits[j] - row_splits[j - 1] != uniform_row_length) {
                    uniform_row_length = -1;
                }
            }

            rt->add_dense_shape(uniform_row_length);
            auto *rt_row_partition = rt->add_row_partition();
            rt_row_partition->set_nrows(row_splits.size() - 1);
            if (uniform_row_length >= 0) {
                rt_row_partition->set_uniform_row_length(uniform_row_length);
                delete row_splits_tensor;
            } else {
                rt_row_partition->set_allocated_row_splits(row_splits_tensor);
            }
        }
    }

    // ---------------------------------------------------------------------------------------

    // RaggedTensorUtil implements -----------------------------------------------------------
    template<typename T>
    ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromValues(const std::vector<std::vector<T>> &values, google::protobuf::Arena* arena) {
        int32_t total_size = 0;
        std::vector<int32_t> row_splits(values.size() + 1, 0);
        for (int32_t i = 0; i < values.size(); i++) {
            total_size += values[i].size();
            row_splits[i + 1] = total_size;
        }

        return FromRowSplits(CreateTensor(values, total_size, arena), row_splits, arena);
    }

    template<typename T>
    ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromValues(const std::vector<_pb::RepeatedField<T>> &values) {
        int32_t total_size = 0;
        std::vector<int32_t> row_splits(values.size() + 1, 0);
        for (int32_t i = 0; i < values.size(); i++) {
            total_size += values[i].size();
            row_splits[i + 1] = total_size;
        }

        return FromRowSplits(CreateTensor(values, total_size), row_splits);
    }

    template<typename T>
    ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromValues(const std::vector<const _pb::RepeatedField<T>*> &values, google::protobuf::Arena* arena){
        int32_t total_size = 0;
        int32_t values_size = values.size();
        std::vector<int32_t> row_splits(values_size + 1, 0);
        
        for (int32_t i = 0; i < values_size; i++) {
            total_size += values[i]->size();
            row_splits[i + 1] = total_size;
        }

        return FromRowSplits(CreateTensor(values, total_size, arena), row_splits, arena);
    }
    
    template<typename T>
    ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromValues(const std::vector<const _pb::RepeatedPtrField<T>*> &values, google::protobuf::Arena* arena){
        int32_t total_size = 0;
        int32_t values_size = values.size();
        std::vector<int32_t> row_splits(values_size + 1, 0);
        
        for (int32_t i = 0; i < values_size; i++) {
            total_size += values[i]->size();
            row_splits[i + 1] = total_size;
        }

        return FromRowSplits(CreateTensor(values, total_size, arena), row_splits, arena);
    }
    template<typename T>
    ::proto::flow::RaggedTensorProto *FromValues(const std::vector<const _pb::RepeatedField<T>*> &values,int32_t begin_index, int32_t end_index, google::protobuf::Arena* arena ){
        if(begin_index >= end_index || values.size() < end_index) return nullptr;
        int32_t total_size = 0;
        int32_t values_size = end_index - begin_index;
        std::vector<int32_t> row_splits(values_size + 1, 0);
        
        for (int32_t i = 0; i < values_size; i++) {
            total_size += values[i]->size();
            row_splits[i + 1] = total_size;
        }

        return FromRowSplits(CreateTensor(values,begin_index,end_index, total_size,arena), row_splits);
    }

    template<typename T>
    ::proto::flow::RaggedTensorProto *FromValues(const std::vector<const _pb::RepeatedPtrField<T>*> &values,int32_t begin_index, int32_t end_index, google::protobuf::Arena* arena){
        if(begin_index >= end_index || values.size() < end_index) return nullptr;
        int32_t total_size = 0;
        int32_t values_size = end_index - begin_index;
        std::vector<int32_t> row_splits(values_size + 1, 0);

        for (int32_t i = 0; i < values_size; i++) {
            total_size += values[i]->size();
            row_splits[i + 1] = total_size;
        }

        return FromRowSplits(CreateTensor(values,begin_index,end_index, total_size,arena), row_splits);
    }

        

    ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromValues(const std::vector<::proto::flow::RaggedTensorProto *> &values) {
        std::cout << "welcome, FromValues, size: " << values.size() << std::endl;

        const auto start_time = std::chrono::high_resolution_clock::now();

        int32_t total_size = 0;
        ::proto::flow::DataType type = ::proto::flow::DataType::DT_INVALID;
        std::vector<std::vector<int32_t>> nested_splits;// to do
        for (int32_t i = 0; i < values.size(); i++) {
            total_size += values[i]->values().shape(0);

            if (i == 0) {
                type = values[i]->values().dtype();
            } else if (type != ::proto::flow::DataType::DT_INVALID && values[i]->values().dtype() != type) {
                type = ::proto::flow::DataType::DT_INVALID;
            }
        }

        ::proto::flow::TensorProto *flat_values_tensor = new ::proto::flow::TensorProto();
        flat_values_tensor->add_shape(total_size);
        flat_values_tensor->set_dtype(type);
        if (type == ::proto::flow::DataType::DT_INT64) {
            auto *int64_val = flat_values_tensor->mutable_int64_val();
            int64_val->Reserve(total_size);
            for (int32_t i = 0; i < values.size(); i++) {
                int64_val->Add(values[i]->values().int64_val().begin(), values[i]->values().int64_val().end());
            }
        } else if (type == ::proto::flow::DataType::DT_FLOAT) {
            auto *float_val = flat_values_tensor->mutable_float_val();
            float_val->Reserve(total_size);
            for (int32_t i = 0; i < values.size(); i++) {
                float_val->Add(values[i]->values().float_val().begin(), values[i]->values().float_val().end());
            }
        } else if (type == ::proto::flow::DataType::DT_STRING) {
            auto *string_val = flat_values_tensor->mutable_string_val();
            string_val->Reserve(total_size);
            for (int32_t i = 0; i < values.size(); i++) {
                string_val->Add(values[i]->values().string_val().begin(), values[i]->values().string_val().end());
            }
        } else {
            std::cout << "Unsupported data type: " << DataType_Name(type) << std::endl;
        }

        ::proto::flow::RaggedTensorProto *rt = new ::proto::flow::RaggedTensorProto();
        rt->set_allocated_values(flat_values_tensor);
        set_row_partition(rt, nested_splits);

        const auto end_time = std::chrono::high_resolution_clock::now();
        const auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        std::cout << "FromValues took " << duration.count() << " us." << std::endl;

        return rt;
    }

    int32_t RaggedTensorUtil::GetBatchSize(const ::proto::flow::RaggedTensorProto *rt) {
        if (rt == NULL) {
            return -1;
        }
        return rt->dense_shape(0);
    }

    TensorView RaggedTensorUtil::GetValues(const ::proto::flow::RaggedTensorProto *rt) {
        TensorView view;

        if (rt == nullptr) {
            return view;
        }

        view.set(&rt->values(), 0, rt->values().shape(0));
        return view;
    }

    TensorView RaggedTensorUtil::GetValuesByIndex(const ::proto::flow::RaggedTensorProto *rt, const std::vector<int32_t> &indices) {
        TensorView view;

        if (rt == nullptr) {
            return view;
        }

        if (indices.size() > rt->ragged_rank() || indices.size() == 0) {
            std::cout << "Error: indices is invalid!" << std::endl;
            return view;
        }

        auto [start, end] = get_values_range(rt->row_partition(), 0, 0, rt->dense_shape(0), indices);
        // std::cout << "start: " << start << " end: " << end << std::endl;
        view.set(&rt->values(), start, end - start);
        return view;
    }

    template<typename T>
    ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromUniformRowLength(const std::vector<T> &flat_values,
                                                              int32_t uniform_row_length) {
        return FromUniformRowLength(CreateTensor(flat_values), uniform_row_length);
    }

    template<typename T>
    ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromRowSplits(const std::vector<T> &flat_values,
                                                       const std::vector<int32_t> &row_splits) {
        return FromRowSplits(CreateTensor(flat_values), row_splits);
    }

    template<typename T>
    ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromNestedRowSplits(const std::vector<T> &flat_values,
                                                             const std::vector<std::vector<int32_t>> &nested_splits) {
        return FromNestedRowSplits(CreateTensor(flat_values), nested_splits);
    }

    ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromUniformRowLength(::proto::flow::TensorProto *flat_values, int32_t uniform_row_length) {
        // std::cout << "welcome, FromUniformRowLength, size: " << flat_values->shape(0) << " uniform_row_length: " << uniform_row_length << std::endl;

        const auto start_time = std::chrono::high_resolution_clock::now();

        ::proto::flow::RaggedTensorProto *rt = new ::proto::flow::RaggedTensorProto();
        rt->set_allocated_values(flat_values);

        int32_t nrows = flat_values->shape(0) / uniform_row_length;
        rt->set_ragged_rank(1);
        rt->add_dense_shape(nrows);
        rt->add_dense_shape(uniform_row_length);
        auto *rt_row_partition = rt->add_row_partition();
        rt_row_partition->set_nrows(nrows);
        rt_row_partition->set_uniform_row_length(uniform_row_length);

        const auto end_time = std::chrono::high_resolution_clock::now();
        const auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        // std::cout << "FromUniformRowLength took " << duration.count() << " us." << std::endl;

        return rt;
    }

    ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromRowSplits(::proto::flow::TensorProto *flat_values,
                                                       const std::vector<int32_t> &row_splits, google::protobuf::Arena* arena) {
        // std::cout << "welcome, FromRowSplits, size: " << flat_values->shape(0) << " row_splits: " << vector_2_String(row_splits) << std::endl;

        const auto start_time = std::chrono::high_resolution_clock::now();

        ::proto::flow::RaggedTensorProto *rt = google::protobuf::Arena::CreateMessage<::proto::flow::RaggedTensorProto>(arena);
        rt->set_allocated_values(flat_values);

        int32_t uniform_row_length = row_splits[1] - row_splits[0];
        ::proto::flow::TensorProto *row_splits_tensor = google::protobuf::Arena::CreateMessage<::proto::flow::TensorProto>(arena);
        row_splits_tensor->set_dtype(::proto::flow::DataType::DT_INT32);
        row_splits_tensor->add_shape(row_splits.size());
        row_splits_tensor->mutable_int_val()->Add(row_splits.begin(), row_splits.end());
        for (int32_t i = 0; i < row_splits.size(); i++) {
            if (uniform_row_length >= 0 && i > 0 && row_splits[i] - row_splits[i - 1] != uniform_row_length) {
                uniform_row_length = -1;
            }
        }

        rt->set_ragged_rank(1);
        rt->add_dense_shape(row_splits.size() - 1);
        rt->add_dense_shape(uniform_row_length);
        auto *rt_row_partition = rt->add_row_partition();
        rt_row_partition->set_nrows(row_splits.size() - 1);
        if (uniform_row_length >= 0) {
            rt_row_partition->set_uniform_row_length(uniform_row_length);
            // 如果没分配在arena上手动释放
            if (arena == nullptr) {
                delete row_splits_tensor;
            }
        } else {
            rt_row_partition->set_allocated_row_splits(row_splits_tensor);
        }

        const auto end_time = std::chrono::high_resolution_clock::now();
        const auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        // std::cout << "FromRowSplits took " << duration.count() << " us." << std::endl;

        return rt;
    }

    ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromNestedRowSplits(::proto::flow::TensorProto *flat_values,
                                                             const std::vector<std::vector<int32_t>> &nested_splits) {
        std::cout << "welcome, FromNestedRowSplits, size: " << flat_values->shape(0)
                  << " nested_splits: " << nested_splits.size() << std::endl;

        const auto start_time = std::chrono::high_resolution_clock::now();

        ::proto::flow::RaggedTensorProto *rt = new ::proto::flow::RaggedTensorProto();
        rt->set_allocated_values(flat_values);
        set_row_partition(rt, nested_splits);

        const auto end_time = std::chrono::high_resolution_clock::now();
        const auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        // std::cout << "FromNestedRowSplits took " << duration.count() << " us." << std::endl;

        return rt;
    }

    template<typename T>
    ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor(const std::vector<T> &flat_values) {
        const auto start_time = std::chrono::high_resolution_clock::now();

        ::proto::flow::TensorProto *flat_values_tensor = new ::proto::flow::TensorProto();
        flat_values_tensor->add_shape(flat_values.size());
        if constexpr (std::is_same_v<T, int64_t>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_INT64);
            auto *int64_val = flat_values_tensor->mutable_int64_val();
            int64_val->Reserve(flat_values.size());
            int64_val->Add(flat_values.begin(), flat_values.end());
        } else if constexpr (std::is_same_v<T, float>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_FLOAT);
            auto *float_val = flat_values_tensor->mutable_float_val();
            float_val->Reserve(flat_values.size());
            float_val->Add(flat_values.begin(), flat_values.end());
        } else if constexpr (std::is_same_v<T, std::string>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_STRING);
            auto *string_val = flat_values_tensor->mutable_string_val();
            string_val->Reserve(flat_values.size());
            string_val->Add(flat_values.begin(), flat_values.end());
        }

        const auto end_time = std::chrono::high_resolution_clock::now();
        const auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        // std::cout << "CreateTensor took " << duration.count() << " us." << std::endl;
        return flat_values_tensor;
    }

    template<typename T>
    ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor(const std::vector<std::vector<T>> &values, int32_t total_size, google::protobuf::Arena* arena) {
        const auto start_time = std::chrono::high_resolution_clock::now();

        if (total_size == 0) {
            for (int32_t i = 0; i < values.size(); i++) {
                total_size += values[i].size();
            }
        }

        ::proto::flow::TensorProto *flat_values_tensor = google::protobuf::Arena::CreateMessage<::proto::flow::TensorProto>(arena);
        flat_values_tensor->add_shape(total_size);
        if constexpr (std::is_same_v<T, int64_t>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_INT64);
            auto *int64_val = flat_values_tensor->mutable_int64_val();
            int64_val->Reserve(total_size);
            for (int32_t i = 0; i < values.size(); i++) {
                int64_val->Add(values[i].begin(), values[i].end());
            }
        } else if constexpr (std::is_same_v<T, float>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_FLOAT);
            auto *float_val = flat_values_tensor->mutable_float_val();
            float_val->Reserve(total_size);
            for (int32_t i = 0; i < values.size(); i++) {
                float_val->Add(values[i].begin(), values[i].end());
            }
        } else if constexpr (std::is_same_v<T, std::string>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_STRING);
            auto *string_val = flat_values_tensor->mutable_string_val();
            string_val->Reserve(total_size);
            for (int32_t i = 0; i < values.size(); i++) {
                string_val->Add(values[i].begin(), values[i].end());
            }
        }

        const auto end_time = std::chrono::high_resolution_clock::now();
        const auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        // std::cout << "CreateTensor took " << duration.count() << " us." << std::endl;
        return flat_values_tensor;
    }

    template<typename T>
    ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor(const std::vector<_pb::RepeatedField<T>> &values, int32_t total_size) {
        const auto start_time = std::chrono::high_resolution_clock::now();

        if (total_size == 0) {
            for (int32_t i = 0; i < values.size(); i++) {
                total_size += values[i].size();
            }
        }

        ::proto::flow::TensorProto *flat_values_tensor = new ::proto::flow::TensorProto();
        flat_values_tensor->add_shape(total_size);
        if constexpr (std::is_same_v<T, int64_t>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_INT64);
            auto *int64_val = flat_values_tensor->mutable_int64_val();
            int64_val->Reserve(total_size);
            for (int32_t i = 0; i < values.size(); i++) {
                int64_val->Add(values[i].begin(), values[i].end());
            }
        } else if constexpr (std::is_same_v<T, float>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_FLOAT);
            auto *float_val = flat_values_tensor->mutable_float_val();
            float_val->Reserve(total_size);
            for (int32_t i = 0; i < values.size(); i++) {
                float_val->Add(values[i].begin(), values[i].end());
            }
        } else if constexpr (std::is_same_v<T, std::string>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_STRING);
            auto *string_val = flat_values_tensor->mutable_string_val();
            string_val->Reserve(total_size);
            for (int32_t i = 0; i < values.size(); i++) {
                string_val->Add(values[i].begin(), values[i].end());
            }
        }

        const auto end_time = std::chrono::high_resolution_clock::now();
        const auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        // std::cout << "CreateTensor took " << duration.count() << " us." << std::endl;
        return flat_values_tensor;
    }

    template<typename T>
    ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor(const std::vector<const _pb::RepeatedField<T>*> &values, int32_t total_size,google::protobuf::Arena* arena){
        const auto start_time = std::chrono::high_resolution_clock::now();

        int32_t value_size =  values.size();
        if (total_size == 0) {
            for (int32_t i = 0; i < value_size; i++) {
                total_size += values[i]->size();
            }
        }

        ::proto::flow::TensorProto *flat_values_tensor = google::protobuf::Arena::CreateMessage<proto::flow::TensorProto>(arena);
        flat_values_tensor->add_shape(total_size);
        if constexpr (std::is_same_v<T, int64_t>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_INT64);
            auto *int64_val = flat_values_tensor->mutable_int64_val();
            int64_val->Reserve(total_size);
            for (int32_t i = 0; i < value_size; i++) {
                int64_val->Add(values[i]->begin(), values[i]->end());
            }
        } else if constexpr (std::is_same_v<T, float>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_FLOAT);
            auto *float_val = flat_values_tensor->mutable_float_val();
            float_val->Reserve(total_size);
            for (int32_t i = 0; i < value_size; i++) {
                float_val->Add(values[i]->begin(), values[i]->end());
            }
        } else if constexpr (std::is_same_v<T, std::string>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_STRING);
            auto *string_val = flat_values_tensor->mutable_string_val();
            string_val->Reserve(total_size);
            for (int32_t i = 0; i < value_size; i++) {
                string_val->Add(values[i]->begin(), values[i]->end());
            }
        }

        const auto end_time = std::chrono::high_resolution_clock::now();
        const auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        // std::cout << "CreateTensor took " << duration.count() << " us." << std::endl;
        return flat_values_tensor;
    }
    
    template<typename T>
    ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor(const std::vector<const _pb::RepeatedPtrField<T>*> &values, int32_t total_size, google::protobuf::Arena* arena){
        const auto start_time = std::chrono::high_resolution_clock::now();

        int32_t value_size =  values.size();
        if (total_size == 0) {
            for (int32_t i = 0; i < value_size; i++) {
                total_size += values[i]->size();
            }
        }
        ::proto::flow::TensorProto *flat_values_tensor = google::protobuf::Arena::CreateMessage<proto::flow::TensorProto>(arena);
        flat_values_tensor->add_shape(total_size);
        if constexpr (std::is_same_v<T, int64_t>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_INT64);
            auto *int64_val = flat_values_tensor->mutable_int64_val();
            int64_val->Reserve(total_size);
            for (int32_t i = 0; i < value_size; i++) {
                int64_val->Add(values[i]->begin(), values[i]->end());
            }
        } else if constexpr (std::is_same_v<T, float>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_FLOAT);
            auto *float_val = flat_values_tensor->mutable_float_val();
            float_val->Reserve(total_size);
            for (int32_t i = 0; i < value_size; i++) {
                float_val->Add(values[i]->begin(), values[i]->end());
            }
        } else if constexpr (std::is_same_v<T, std::string>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_STRING);
            auto *string_val = flat_values_tensor->mutable_string_val();
            string_val->Reserve(total_size);
            for (int32_t i = 0; i < value_size; i++) {
                string_val->Add(values[i]->begin(), values[i]->end());
            }
        }

        const auto end_time = std::chrono::high_resolution_clock::now();
        const auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        // std::cout << "CreateTensor took " << duration.count() << " us." << std::endl;
        return flat_values_tensor;
    }

    template<typename T>
    ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor(const std::vector<const _pb::RepeatedField<T>*> &values,int32_t begin_index, int32_t end_index, int32_t total_size, google::protobuf::Arena* arena ){
        const auto start_time = std::chrono::high_resolution_clock::now();
        if(begin_index >= end_index || values.size() < end_index) return nullptr;
        if (total_size == 0) {
            for (int32_t i = begin_index; i < end_index; i++) {
                total_size += values[i]->size();
            }
        }

        ::proto::flow::TensorProto *flat_values_tensor = google::protobuf::Arena::CreateMessage<proto::flow::TensorProto>(arena);
        flat_values_tensor->add_shape(total_size);
        if constexpr (std::is_same_v<T, int64_t>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_INT64);
            auto *int64_val = flat_values_tensor->mutable_int64_val();
            int64_val->Reserve(total_size);
            for (int32_t i = begin_index; i < end_index; i++) {
                int64_val->Add(values[i]->begin(), values[i]->end());
            }
        } else if constexpr (std::is_same_v<T, float>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_FLOAT);
            auto *float_val = flat_values_tensor->mutable_float_val();
            float_val->Reserve(total_size);
            for (int32_t i = begin_index; i < end_index; i++) {
                float_val->Add(values[i]->begin(), values[i]->end());
            }
        } else if constexpr (std::is_same_v<T, std::string>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_STRING);
            auto *string_val = flat_values_tensor->mutable_string_val();
            string_val->Reserve(total_size);
            for (int32_t i = begin_index; i < end_index; i++) {
                string_val->Add(values[i]->begin(), values[i]->end());
            }
        }

        const auto end_time = std::chrono::high_resolution_clock::now();
        const auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        std::cout<<__LINE__ << "CreateTensor took " << duration.count() << " us." << std::endl;
        return flat_values_tensor;
    }

    template<typename T>
    ::proto::flow::TensorProto *CreateTensor(const std::vector<const _pb::RepeatedPtrField<T>*> &values,int32_t begin_index, int32_t end_index, int32_t total_size, google::protobuf::Arena* arena){
        const auto start_time = std::chrono::high_resolution_clock::now();
        if(begin_index >= end_index || values.size() < end_index) return nullptr;
        if (total_size == 0) {
            for (int32_t i = begin_index; i < end_index; i++) {
                total_size += values[i]->size();
            }
        }

        ::proto::flow::TensorProto *flat_values_tensor = google::protobuf::Arena::CreateMessage<proto::flow::TensorProto>(arena);
        flat_values_tensor->add_shape(total_size);
        if constexpr (std::is_same_v<T, int64_t>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_INT64);
            auto *int64_val = flat_values_tensor->mutable_int64_val();
            int64_val->Reserve(total_size);
            for (int32_t i = begin_index; i < end_index; i++) {
                int64_val->Add(values[i]->begin(), values[i]->end());
            }
        } else if constexpr (std::is_same_v<T, float>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_FLOAT);
            auto *float_val = flat_values_tensor->mutable_float_val();
            float_val->Reserve(total_size);
            for (int32_t i = begin_index; i < end_index; i++) {
                float_val->Add(values[i]->begin(), values[i]->end());
            }
        } else if constexpr (std::is_same_v<T, std::string>) {
            flat_values_tensor->set_dtype(::proto::flow::DataType::DT_STRING);
            auto *string_val = flat_values_tensor->mutable_string_val();
            string_val->Reserve(total_size);
            for (int32_t i = begin_index; i < end_index; i++) {
                string_val->Add(values[i]->begin(), values[i]->end());
            }
        }

        const auto end_time = std::chrono::high_resolution_clock::now();
        const auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
        //std::cout<<__LINE__<< "CreateTensor took " << duration.count() << " us." << std::endl;
        return flat_values_tensor;
    }

    // void RaggedTensorUtil::PrintRaggedTensor(::proto::flow::RaggedTensorProto *rt) {
    //     LogInfo("**********::proto::flow::RaggedTensorProto Info**********");

    //     LogInfo("::proto::flow::RaggedTensorProto ragged_rank: {}", rt->ragged_rank());
    //     LogInfo("::proto::flow::RaggedTensorProto dense_shape: {}", vector_2_String(rt->dense_shape()));

    //     auto rt_values = rt->values();
    //     LogInfo("::proto::flow::RaggedTensorProto values:");
    //     LogInfo("shape: {}", vector_2_String(rt_values.shape()));
    //     LogInfo("dtype: {}", DataType_Name(rt_values.dtype()));
    //     if (rt_values.dtype() == ::proto::flow::DataType::DT_INT64) {
    //         LogInfo("data: {}", vector_2_String(rt_values.int64_val(), 10));
    //     } else if (rt_values.dtype() == ::proto::flow::DataType::DT_FLOAT) {
    //         LogInfo("data: {}", vector_2_String(rt_values.float_val(), 10));
    //     } else if (rt_values.dtype() == ::proto::flow::DataType::DT_STRING) {
    //         LogInfo("data: {}", vector_2_String(rt_values.string_val(), 10));
    //     }

    //     LogInfo("::proto::flow::RaggedTensorProto row_partition: ");
    //     for (int32_t i = 0; i < rt->row_partition().size(); i++) {
    //         LogInfo("row_partition[{}].nrows: {}", i, rt->row_partition(i).nrows());
    //         if (rt->row_partition(i).has_uniform_row_length()) {
    //             LogInfo("row_partition[{}].uniform_row_length: {}", i, rt->row_partition(i).uniform_row_length());
    //         } else {
    //             LogInfo("row_partition[{}].row_splits: {}", i,
    //                     vector_2_String(rt->row_partition(i).row_splits().int_val()));
    //         }
    //     }

    //     LogInfo("**********::proto::flow::RaggedTensorProto Info**********");
    // }

    // ---------------------------------------------------------------------------------------

    // template define -----------------------------------------------------------------------
    template ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor<int64_t>(const std::vector<int64_t> &);
    template ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor<float>(const std::vector<float> &);
    template ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor<int64_t>(const std::vector<std::vector<int64_t>> &, int32_t, google::protobuf::Arena*);
    template ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor<float>(const std::vector<std::vector<float>> &, int32_t, google::protobuf::Arena*);
    template ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor<int64_t>(const std::vector<_pb::RepeatedField<int64_t>> &,
                                                                  int32_t);
    template ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor<float>(const std::vector<_pb::RepeatedField<float>> &,
                                                                int32_t);

    template ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor(const std::vector<const _pb::RepeatedField<int64_t>*> &values, int32_t, google::protobuf::Arena*);
    template ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor(const std::vector<const _pb::RepeatedField<float>*> &values, int32_t, google::protobuf::Arena*);
    template ::proto::flow::TensorProto *RaggedTensorUtil::CreateTensor(const std::vector<const _pb::RepeatedPtrField<std::string>*> &values, int32_t, google::protobuf::Arena*);

    template ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromUniformRowLength<int64_t>(const std::vector<int64_t> &, int32_t);
    template ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromUniformRowLength<float>(const std::vector<float> &, int32_t);
    template ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromRowSplits<int64_t>(const std::vector<int64_t> &,
                                                                         const std::vector<int32_t> &);
    template ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromRowSplits<float>(const std::vector<float> &,
                                                                       const std::vector<int32_t> &);
    template ::proto::flow::RaggedTensorProto *
    RaggedTensorUtil::FromNestedRowSplits<int64_t>(const std::vector<int64_t> &,
                                                   const std::vector<std::vector<int32_t>> &);
    template ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromNestedRowSplits<float>(const std::vector<float> &,
                                                                             const std::vector<std::vector<int32_t>> &);
    template ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromValues<int64_t>(const std::vector<std::vector<int64_t>> &, google::protobuf::Arena*);
    template ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromValues<float>(const std::vector<std::vector<float>> &, google::protobuf::Arena*);
    template ::proto::flow::RaggedTensorProto *
    RaggedTensorUtil::FromValues<std::string>(const std::vector<std::vector<std::string>> &, google::protobuf::Arena*);
    template ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromValues<int64_t>(const std::vector<_pb::RepeatedField<int64_t>> &);
    template ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromValues<float>(const std::vector<_pb::RepeatedField<float>> &);
    template ::proto::flow::RaggedTensorProto *
    RaggedTensorUtil::FromValues<std::string>(const std::vector<_pb::RepeatedField<std::string>> &);

    template ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromValues<int64_t>(const std::vector<const _pb::RepeatedField<int64_t>*> &, google::protobuf::Arena* arena);
    template ::proto::flow::RaggedTensorProto *RaggedTensorUtil::FromValues<float>(const std::vector<const _pb::RepeatedField<float>*> &, google::protobuf::Arena* arena);
    template ::proto::flow::RaggedTensorProto *
    RaggedTensorUtil::FromValues<std::string>(const std::vector<const _pb::RepeatedPtrField<std::string>*> &, google::protobuf::Arena* arena);
    // ---------------------------------------------------------------------------------------
}// namespace Core
