#include "model_version.h"
#include "common/hilog/log_helper.h"
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "core/utils/monitor_mgr.h"
#include "hlframe/gtransport_manager.h"
#include "tf/flow.pb.h"
#include <algorithm>
#include <exception>
#include <glog/logging.h>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <string>
using namespace HLframe;


// 通过已有的 Channel 发出 brpc 请求并解析响应 获取版本信息
std::pair<int32_t, int32_t> ModelVersion::get_model_version_by_channel(brpc::Channel *channel, const std::string &model_name) {
    brpc::Controller cntl;

    ::proto::flow::GetModelVersionsRequest request;
    ::proto::flow::GetModelVersionsResponse response;
    ::proto::flow::PredicterService_Stub stub(channel);
    int32_t cur_version = -1;
    int32_t bak_version = -1;

    request.set_name(model_name);

    stub.GetModelVersions(&cntl, &request, &response, nullptr);
    if (cntl.Failed()) {
        HILOG_APP(ERROR) << " Get model meta data failed. " << cntl.ErrorCode() << "," << cntl.ErrorText();
        return std::make_pair(cur_version, bak_version);  // 返回 -1 表示失败
    }

    HILOG_APP(INFO) << "Get model meta data suc, ip addr: " << butil::endpoint2str(cntl.remote_side()) << ","
                    << cntl.ErrorText() << "; response = " << response.DebugString();
    if (response.versions().empty()) {
        return std::make_pair(cur_version, bak_version); // 返回 -1 表示没有版本信息
    }

    for (auto& version : response.versions()) {
        if (version > cur_version) {
            bak_version = cur_version;
            cur_version = version;
        } else if (version > bak_version && version != cur_version) {
            bak_version = version;
        }
    }
    return std::make_pair(cur_version, bak_version);
}

// 通过 brpc 获取 名称和版本号对应关系
std::unordered_map<std::string, std::pair<int32_t, int32_t>> ModelVersion::get_model_versions() {
    auto &model_info_manager = Core::Info::ModelInfoManager::instance();
    auto channel_map = model_info_manager.get_model_infos();
    std::unordered_map<std::string, std::pair<int32_t, int32_t>> model_version_map;

    for (const auto &channel_pair : channel_map) {
        const std::string &model_name = channel_pair.first;
        brpc::Channel *channel = channel_pair.second->get_channel();

        try {
            auto version_pair = get_model_version_by_channel(channel, model_name);
            if (version_pair.first != -1) {
                model_version_map[model_name] = version_pair;
            }
            HILOG_APP(INFO) << "get_model_versions: " << model_name << " cur_version: " << version_pair.first << " bak_version: " << version_pair.second;
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "Error getting version for model: " << model_name << ", Exception: " << e.what();
            return {};
        } catch (...) {
            HILOG_APP(ERROR) << "Unknown error getting version for model: " << model_name;
            return {};
        }
    }

    return model_version_map;
}

int ModelVersion::new_init() {
    auto model_version_map = get_model_versions();
    for (auto &[model_name, model_version] : model_version_map) {
        update_model_version(model_name, model_version);  // 更新模型版本
    }
    run();
    return 0;
}

void ModelVersion::run() {
    std::thread t([this]() {
        while (true) {
            std::this_thread::sleep_for(std::chrono::minutes(1));
            auto model_version_map = get_model_versions();
            for (auto &[model_name, model_version] : model_version_map) {
                update_model_version(model_name, model_version);  // 更新模型版本
            }
        }
    });
    t.detach();
}
