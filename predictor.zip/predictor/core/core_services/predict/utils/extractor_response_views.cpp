#include "extractor_response_views.h"
#include <cstdint>
namespace Core::util {

    int32_t ExtractorResponseSlotView::ViewBatchCount() const {
        return (full_item_cnt_ + view_batch_size_) / view_batch_size_;
    }
    ExtractorResponseBatchView::ExtractorResponseBatchView(
            const std::vector<ExtractorWrapper> *extractor_response_wrapper, int32_t slot_offset,
            int32_t flat_index_start, int32_t view_batch_size)
        : slot_offset_(slot_offset), flat_index_start_(flat_index_start), view_batch_size_(view_batch_size),
          extractor_response_wrapper_(extractor_response_wrapper) {
        this->real_batch_size_ = extractor_response_wrapper->at(0).extractor_response->item_cnt();
    }
    ExtractorResponseBatchView ExtractorResponseSlotView::BatchViewAt(int32_t batch_index) const {
        ExtractorResponseBatchView batch_view{extractor_response_wrapper_, slot_offset_,
                                              batch_index * this->view_batch_size_, view_batch_size_};

        return batch_view;
    }

    ExtractorResponseView::ExtractorResponseView(const std::vector<ExtractorWrapper> *extractor_response_wrapper)
        : extractor_response_wrapper_(extractor_response_wrapper) {};

    ExtractorResponseView::InitResult ExtractorResponseView::Init() {
        if (extractor_response_wrapper_->size() == 1) {
            this->real_batch_size_ = extractor_response_wrapper_->at(0).extractor_response->item_cnt();
            this->full_item_cnt_ = real_batch_size_;
            this->slot_num_ =
                    extractor_response_wrapper_->at(0).extractor_response->item_features_size() / real_batch_size_;
            return kSuccess;
        }
        int expected_real_batch_size = extractor_response_wrapper_->at(0).extractor_response->item_cnt();

        for (int i = 1; i < extractor_response_wrapper_->size() - 1; ++i) {
            if (extractor_response_wrapper_->at(i).extractor_response->item_cnt() != expected_real_batch_size) {
                return kFailedBatch;
            }
        }
        this->real_batch_size_ = expected_real_batch_size;
        this->full_item_cnt_ = (expected_real_batch_size * (extractor_response_wrapper_->size() - 1)) +
                               extractor_response_wrapper_->back().extractor_response->item_cnt();
        this->slot_num_ =
                extractor_response_wrapper_->at(0).extractor_response->item_features_size() / real_batch_size_;
        return kSuccess;
    }

    ExtractorResponseSlotView::ExtractorResponseSlotView(
            const std::vector<ExtractorWrapper> *extractor_response_wrapper, int32_t slot_index,
            int32_t real_batch_size) {
        this->extractor_response_wrapper_ = extractor_response_wrapper;
        this->slot_offset_ = slot_index * real_batch_size;
        this->slot_type_ = DetectDataType(slot_index);
    }

    google::protobuf::RepeatedField<int64_t> *ExtractorResponseBatchView::GetInt64List(int32_t item_index) {
        int32_t flat_index = flat_index_start_ + item_index;
        int32_t real_batch_index = flat_index / real_batch_size_;
        int32_t real_batch_offset = flat_index - real_batch_index * real_batch_size_;
        auto *feature_extractor_response = extractor_response_wrapper_->at(real_batch_index).extractor_response;
        return feature_extractor_response->mutable_item_features(real_batch_offset + slot_offset_)->mutable_signs();
    }
    ExtractorResponseSlotView ExtractorResponseView::SlotViewAt(int32_t slot_index) const {
        ExtractorResponseSlotView slot_view(this->extractor_response_wrapper_, slot_index, this->real_batch_size_);
        return slot_view;
    }
}// namespace Core::util