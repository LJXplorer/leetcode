#pragma once
#include "core/core_context/fe_context.h"
#include "core/core_services/predict/predict_service.h"
#include "fe_request.pb.h"
#include <cstdint>
#include <google/protobuf/repeated_ptr_field.h>
#include <vector>

/**
 * @namespace Core::util
 * @brief Contains utility classes for viewing and accessing extractor response data.
 * 
 * Provides hierarchical views for accessing extractor response data at different levels:
 * - ExtractorResponseView: Top-level view of the entire extractor response
 * - ExtractorResponseSlotView: View focused on a specific slot within the response
 * - ExtractorResponseBatchView: View focused on batch-level data within a slot
 * 
 * These views provide read-only access to the underlying extractor response data
 * with appropriate bounds checking and type safety.
 */
namespace Core::util {
    class ExtractorResponseBatchView {
    public:
        ExtractorResponseBatchView(const std::vector<ExtractorWrapper> *extractor_response_wrapper, int32_t slot_offset,
                                   int32_t flat_index_start_, int32_t view_batch_size);
        google::protobuf::RepeatedField<int64_t> *GetInt64List(int32_t item_index);
        int32_t Size() const;

    private:
        int32_t slot_offset_;
        int32_t flat_index_start_;
        int32_t view_batch_size_;
        const std::vector<ExtractorWrapper> *extractor_response_wrapper_;
        int32_t real_batch_size_;
    };
    class ExtractorResponseSlotView {
    public:
        explicit ExtractorResponseSlotView(const std::vector<ExtractorWrapper> *extractor_response_wrapper,
                                           int32_t slot_index, int32_t real_batch_size);
        int32_t ViewBatchCount() const;
        ExtractorResponseBatchView BatchViewAt(int32_t batch_index) const;
        void SetViewBatchVSize(int32_t batch_size);

    private:
        int32_t slot_offset_;
        SlotDataType slot_type_;
        int32_t view_batch_size_;
        int32_t full_item_cnt_;
        const std::vector<ExtractorWrapper> *extractor_response_wrapper_;
        SlotDataType DetectDataType(int32_t slot_index) const;
    };

    class ExtractorResponseView {
    public:
        enum InitResult : int32_t {
            kSuccess = 0,
            kFailedBatch = 1,
        };
        explicit ExtractorResponseView(const std::vector<ExtractorWrapper> *extractor_response_wrapper);
        InitResult Init();
        int32_t SlotSize() const {
            return slot_num_;
        };

        ExtractorResponseSlotView SlotViewAt(int32_t slot_index) const;

    private:
        const std::vector<ExtractorWrapper> *extractor_response_wrapper_;
        int32_t slot_num_;
        int32_t real_batch_size_;
        int32_t full_item_cnt_;
    };

}// namespace Core::util