#ifndef TF_MODEL_TOOL
#define TF_MODEL_TOOL

#include "brpc/callback.h"
#include "common/hilog/log_helper.h"
#include "hlframe/gtransport_manager.h"
#include "tf/flow.pb.h"
#include <brpc/channel.h>
#include <brpc/channel_base.h>
#include <chrono>
#include <map>
#include <shared_mutex>
#include <unordered_map>
#include <utility>

//调用 HLframe::GtransportManager 的 get_transports() 获取到 _model_channel_map unordered_map<string, brpc::Channel*> ，
//通过每个 brpc::Channel* 构造出的 stub GetModelMetadata() 获取版本信息 _model_version_map unordered_map<string,int32_t>，
//去 Core::FEConfigManager 的成员 _model_config 获取到 _model_config map<string,shared_ptr<FEConfig>>
//将_model_version 和 _model_config 根据服务名 string name一一对应 获得 FEConfig 和版本号的对应关系 map<shared_ptr<FEConfig>,int32_t>
//对每个 FEConfig 执行 FEConfig::check_version() ，如果返回 true 就什么也不做，如果返回 false ，执行 FEConfig::load() 并且 FEConfig::set_version()
struct ModelInfoStruct {
    std::string model_name;
    int32_t model_version;
    int32_t bak_model_version;
    std::string pair_model;
    std::chrono::system_clock::time_point model_update_time;
};

class ModelVersion {
public:
    static ModelVersion &instance() {
        static ModelVersion inst;
        return inst;
    }

    // 返回 最新模型版本
    int32_t get_model_version(const std::string &model_name) {
        std::shared_lock<std::shared_mutex> lock(model_version_mtx_);// 共享锁
        auto it = old_model_info_.find(model_name);
        if (it != old_model_info_.end()) {
            return it->second.model_version;
        }
        return -1;// 如果未找到模型，返回 -1
    }

    // 返回 当前可用版本，即最新和次新两个版本
    std::pair<int32_t, int32_t> get_available_model_versions(const std::string &model_name) {
        std::shared_lock<std::shared_mutex> lock(model_version_mtx_);// 共享锁
        auto it = old_model_info_.find(model_name);
        if (it != old_model_info_.end()) {
            return std::make_pair(it->second.model_version, it->second.bak_model_version);
        }
        return std::make_pair(-1, -1);// 如果未找到模型，返回 -1
    }

    int32_t get_max_common_version(const std::string &item_model_name, const std::string &user_model_name) {
        auto item_versions = get_available_model_versions(item_model_name);
        auto user_versions = get_available_model_versions(user_model_name);
        HILOG_APP(INFO) << "get_max_common_version:item model " << item_model_name
                        << " to cur_version: " << item_versions.first << " bak_version: " << item_versions.second
                        << " user model " << user_model_name << " to cur_version: " << user_versions.first
                        << " bak_version: " << user_versions.second;
        int max_common = -1;

        // 检查 item 最新版本
        if (item_versions.first >= 1 &&
            (item_versions.first == user_versions.first || item_versions.first == user_versions.second)) {
            max_common = item_versions.first;
        }

        // 检查 item 次新版本
        if (item_versions.second >= 1 &&
            (item_versions.second == user_versions.first || item_versions.second == user_versions.second)) {
            max_common = std::max(max_common, item_versions.second);
        }

        return max_common;
    }

    // 更新模型版本（写操作）
    void update_model_version(const std::string &model_name, std::pair<int32_t, int32_t> version_pair) {
        ModelInfoStruct model_info;
        model_info.model_name = model_name;
        model_info.model_version = version_pair.first;
        model_info.bak_model_version = version_pair.second;
        model_info.model_update_time = std::chrono::system_clock::now();
        std::unique_lock<std::shared_mutex> lock(model_version_mtx_);// 独占锁
        old_model_info_[model_name] = model_info;
        HILOG_APP(INFO) << "Updated model version for " << model_name << " to cur_version: " << version_pair.first
                        << " bak_version: " << version_pair.second;
    }
    ModelVersion(const ModelVersion &) = delete;
    ModelVersion &operator=(const ModelVersion &) = delete;
    int new_init();
    std::mutex _nacos_update_mtx;

private:
    ModelVersion() {
    }
    std::unordered_map<std::string, ModelInfoStruct> old_model_info_;
    std::pair<int32_t, int32_t> get_model_version_by_channel(brpc::Channel *channel, const std::string &model_name);
    std::unordered_map<std::string, std::pair<int32_t, int32_t>> get_model_versions();
    void run();
    std::shared_mutex model_version_mtx_;
};

#endif
