#include "predict_service.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/monitor_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/predict/simple_callback.h"
#include "hlframe/register.h"
#include "phx-fe/src/framework.h"
#include "tf/flow.pb.h"
#include "utils/ragged_tensor_util.h"
#include <brpc/controller.h>
#include <bthread/bthread.h>
#include <butil/time.h>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <debug_utils.h>
#include <glog/logging.h>
#include <google/protobuf/arena.h>
#include <google/protobuf/repeated_field.h>
#include <log_helper.h>
#include <memory>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>
#include <wrapper_time.h>

namespace Core {
    SERVICE_REGISTER(PredictService);

    bool PredictService::skip(GraphContextPtr context) {
        //TODO: 考虑是否会跳过 目前认为不会跳过
        return false;
    }

    int PredictService::do_service(GraphContextPtr context) {
        HILOG_APP(INFO) << "PredictService::do_service start";
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int32_t ret = 0;
        ret = process(ctx);
        HILOG_APP(INFO) << "PredictService::do_service end";
        return ret;
    }

    void PredictService::initialize(ConfigXmlPtr xml) {
        std::string predict_type;
        xml->attr<std::string>("predict", predict_type);
        if (!predict_type.empty()) {
            _predict_type = stringToExperimentModelType(predict_type);
        }
        xml->attr<int32_t>("batch_size", _batch_size);

        HILOG_APP(INFO) << get_name() << ",stage: " << _stage_type << ",predict_type: " << predict_type
                        << ", batch_size: " << std::to_string(_batch_size);
    }
    void PredictService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
        ctx->get_infer_context()->all_node(get_predict_type());
        ctx->_node_split_num_map[this] = std::make_shared<std::atomic<int>>(0);
        return;
    }

    void PredictService::get_item_slot_data_types(const std::string &model_name,
                                                  const std::vector<ExtractorWrapper> &extractor_responses,
                                                  size_t slot_num, std::vector<SlotDataType> &item_slot_data_types) {
        // 处理 item 特征
        for (int slot_index = 0; slot_index < slot_num; ++slot_index) {
            for (const auto &extractor_wrapper_response: extractor_responses) {
                auto extractor_response = extractor_wrapper_response.extractor_response;
                auto &item_features = extractor_response->item_features();
                int64_t item_num = extractor_response->item_cnt();

                for (int j = 0; j < item_num; ++j) {
                    auto &feature = item_features.at(j + item_num * slot_index);//(slot_i,item_j)处的Feature
                    if (feature.signs().size() > 0) {
                        // 这个特征是 int
                        item_slot_data_types[slot_index] = SlotDataType::INT_64;
                        break;
                    } else if (feature.weights().size() > 0) {
                        // 这个特征是 float
                        item_slot_data_types[slot_index] = SlotDataType::FLOAT;
                        break;
                    } else if (feature.bytes_list().size() > 0) {
                        // 这个特征是 string
                        item_slot_data_types[slot_index] = SlotDataType::STRING;
                        break;
                    } else {
                        // 这个特征为空 继续遍历下一个直到 j = item_num -1
                        continue;
                    }
                }
                // 如果遍历完了发现 item_slot_data_types->value[slot_index] 不是 UNKNOWN 了，就可以跳出循环，不再处理下一个 extractor_response
                if (item_slot_data_types[slot_index] != SlotDataType::UNKNOWN) {
                    break;
                }
            }
        }
        return;
    }

    void PredictService::get_user_slot_data_types(const std::string &model_name,
                                                  const std::vector<ExtractorWrapper> &extractor_responses,
                                                  size_t slot_num, std::vector<SlotDataType> &user_slot_data_types) {
        // 处理 user 特征
        const auto &extractor_wrapper_response = extractor_responses[0];
        auto extractor_response = extractor_wrapper_response.extractor_response;
        for (int slot_index = 0; slot_index < slot_num; ++slot_index) {
            auto &feature = extractor_response->user_features(slot_index);
            if (feature.signs().size() > 0) {
                // 这个特征是 int
                user_slot_data_types[slot_index] = SlotDataType::INT_64;
            } else if (feature.weights().size() > 0) {
                // 这个特征是 float
                user_slot_data_types[slot_index] = SlotDataType::FLOAT;
            } else if (feature.bytes_list().size() > 0) {
                // 这个特征是 string
                user_slot_data_types[slot_index] = SlotDataType::STRING;
            }
        }
    }

    int PredictService::process(CoreContextPtr context) {
        BizLatency *lat = get_node_stat(context)->get_lat();
        lat->_req_begin_tm = gettimeofday_us();
        auto &predict_type = get_predict_type();
        if (predict_type == ExperimentModelType::MODEL_INFO_UNKNOWN) {
            HILOG_APP(ERROR) << "unknown predict type";
            this->run_output_nodes_if_ready(context);
            return -1;
        }

        protobuf::Arena *arena = context->get_context_arena();

        std::unordered_map<ExperimentModelInfo *, std::vector<ExtractorWrapper>> *model_info_extractor_responses_map =
                nullptr;
        auto &fe_split_map = context->get_fe_context()->fe_split_;

        // HILOG_APP(INFO) << "fe_split_map: " << debug::printer::ToString(fe_split_map) << std::endl;
        HILOG_APP(INFO) << "fe_split_map:";
        for (const auto &[k, v]: fe_split_map) {
            HILOG_APP(INFO) << "k: " << experimentModelTypeToString(k);
        }

        auto it = fe_split_map.find(predict_type);
        if (it != fe_split_map.end()) {
            model_info_extractor_responses_map = &it->second;// 假设 it->second 是你需要的类型
        }

        //根据 model_info 来并行处理逻辑
        if (model_info_extractor_responses_map == nullptr) {
            HILOG_APP(WARNING) << "model_info_extractor_responses_map is nullptr";
            this->run_output_nodes_if_ready(context);
            return -1;
        }

        size_t total_node_split_num = 0;
        for (const auto &[model_info, extractor_responses]: *model_info_extractor_responses_map) {
            int64_t predict_service_check_extractor_responses = gettimeofday_us();
            total_node_split_num += reserve_model_split_num(context, model_info, extractor_responses);
            predict_service_check_extractor_responses = gettimeofday_us() - predict_service_check_extractor_responses;
            if (ServerConfig::_debug_bvar_monitor_enable) {
                debug::monitor::MonitorPercentile("check_extractor_rsp", predict_service_check_extractor_responses);
            }
        }
        // 总分包数为0，不会走到callback，直接结束
        if (total_node_split_num == 0) {
            lat->_req_end_tm = gettimeofday_us();
            if (ServerConfig::_debug_bvar_monitor_enable) {
                debug::monitor::MonitorPercentile("predict_service_cost", butil::gettimeofday_us() - lat->_req_begin_tm);
            }
            this->run_output_nodes_if_ready(context);
            return 0;
        }

        // 分配所有模型分包的计数器
        auto node_split_num_iter = context->_node_split_num_map.find(this);
        if(node_split_num_iter != context->_node_split_num_map.end()) {
            int old = node_split_num_iter->second->fetch_add(total_node_split_num);
            HILOG_APP(INFO) << get_name() << " old:" << old << " initial incr_batch_count to:" << node_split_num_iter->second->load();
        } else {
            HILOG_APP(ERROR) << get_name() << " initial incr_batch_count not find node";
            this->run_output_nodes_if_ready(context);
            return -1;
        }

        // 多线程处理每个模型，无需等待
        for (const auto &[model_info, extractor_responses]: *model_info_extractor_responses_map) {
            start_bthread(&PredictService::process_single_model, BThreadType::Normal, this, context,
                                          model_info, extractor_responses);
        }
        return 0;
    }

    std::string PredictService::extractor_responses_to_json(const std::vector<ExtractorWrapper> &extractor_responses) {
        std::ostringstream oss;
        oss << "[\n";
        for (size_t i = 0; i < extractor_responses.size(); ++i) {
            oss << extractor_responses[i].to_json();
            if (i != extractor_responses.size() - 1) {
                oss << ",\n";
            }
        }
        oss << "\n]";
        return oss.str();
    }

    int32_t PredictService::reserve_model_split_num(CoreContextPtr &context, ExperimentModelInfo *model_info,
                                              const std::vector<ExtractorWrapper> &extractor_responses) {
        //获取 slot_num
        //item_features 是 (slot,item.size()) 的二维矩阵 按列从上到下存储 在 最外面的repeated中，即一个vector
        //item_features.size()  = slot * item_cnt
        //slot = item_features.size() / item_cnt
        // 写 extractor_responses 到文件 predict_type + model_name + extractor_responses.txt
        if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
            debug::file::WriteToFile(experimentModelTypeToString(get_predict_type()) + "_" + model_info->_model_name +
                                             "_" + "extractor_responses.json",
                                     extractor_responses_to_json(extractor_responses));
        }

        if (extractor_responses.size() == 0) {
            HILOG_APP(ERROR) << "model name: " << model_info->_model_name << ", extractor_responses.size() < 1";
            return 0;
        }

        auto &item_features = extractor_responses.at(0).extractor_response->item_features();
        int64_t item_num = extractor_responses.at(0).extractor_response->item_cnt();
        if (item_features.size() == 0 || item_num == 0) {
            HILOG_APP(ERROR) << "item_features.size() || item_num is 0";
            return 0;
        }
        // 对extractor_responses进行检查
        bool run_error = false;
        auto infer_context = context->get_infer_context();
        auto &model_infer = infer_context->get_model_infer(get_predict_type(), model_info);
        auto &total_item = model_infer._total_item;
        if (extractor_responses[0].extractor_response->user_features_size() <= 0) {
            HILOG_APP(ERROR) << model_info->_model_name <<  " user_features_size() <= 0";
            run_error = true;
        }
        for (const auto &extractor_response_wrapper: extractor_responses) {
            auto extractor_response = extractor_response_wrapper.extractor_response;
            if (extractor_response->item_features().size() % extractor_response->item_cnt() != 0) {
                HILOG_APP(ERROR) << model_info->_model_name << "item_features size%item_cnt not 0 ";
                run_error = true;
                break;
            }
            total_item += extractor_response->item_cnt();
        }

        if (run_error) {
            HILOG_APP(ERROR) << " jump predict, model_name: " << model_info->_model_name;
            return 0;
        }

        size_t batch_num = (total_item + _batch_size - 1) / _batch_size;
        for (auto batch_index = 0; batch_index < batch_num; batch_index++) {
            model_infer._infer_pairs.insert({batch_index, {}}); // 预留
        }

        return batch_num;
    }

    bool PredictService::process_single_model(CoreContextPtr &context, ExperimentModelInfo *model_info,
                                              const std::vector<ExtractorWrapper> &extractor_responses) {
        auto infer_context = context->get_infer_context();
        auto &model_infer = infer_context->get_model_infer(get_predict_type(), model_info);
        if (model_infer._infer_pairs.empty()) return false; // 前置校验没通过，不会预留分包，直接跳过
        protobuf::Arena *arena = context->get_context_arena();
        int64_t item_num = extractor_responses.at(0).extractor_response->item_cnt();
        long detect_slot_type_cost = butil::gettimeofday_us();
        const size_t item_slot_num = extractor_responses.at(0).extractor_response->item_features().size() / item_num;
        const size_t user_slot_num = extractor_responses.at(0).extractor_response->user_features().size();

        std::vector<SlotDataType> user_slot_data_types(user_slot_num, SlotDataType::UNKNOWN);
        get_user_slot_data_types(model_info->_model_name, extractor_responses, user_slot_num, user_slot_data_types);

        std::vector<SlotDataType> item_slot_data_types(item_slot_num, SlotDataType::UNKNOWN);
        get_item_slot_data_types(model_info->_model_name, extractor_responses, item_slot_num, item_slot_data_types);
        detect_slot_type_cost = butil::gettimeofday_us() - detect_slot_type_cost;
        if (ServerConfig::_debug_bvar_monitor_enable) {
            debug::monitor::MonitorPercentile("detect_slot_type", detect_slot_type_cost);
        }
        long prepare_user_feature = butil::gettimeofday_us();
        std::vector<SlotInfo> user_slot_list(user_slot_num);//存储单个user特征
        //处理 user 特征 不用合并
        auto &user_features = extractor_responses.at(0).extractor_response->user_features();
        for (int i = 0; i < user_slot_num; ++i) {
            auto &feature = user_features.at(i);//(slot_i,1)处的Feature
            SlotDataType &data_type = user_slot_data_types[i];
            user_slot_list[i].slot_id = feature.slot_id();
            switch (data_type) {
                case SlotDataType::INT_64: {
                    if (!user_slot_list[i].int_values_repeated) {
                        user_slot_list[i].int_values_repeated =
                                std::make_shared<std::vector<const google::protobuf::RepeatedField<int64_t> *>>();
                    }
                    user_slot_list[i].slot_data_type = SlotDataType::INT_64;
                    user_slot_list[i].slot_id = feature.slot_id();
                    auto &slot_features = *user_slot_list[i].int_values_repeated;
                    slot_features.push_back(&feature.signs());
                    break;
                }
                case SlotDataType::FLOAT: {
                    if (!user_slot_list[i].float_values_repeated) {
                        user_slot_list[i].float_values_repeated =
                                std::make_shared<std::vector<const google::protobuf::RepeatedField<float> *>>();
                    }
                    user_slot_list[i].slot_data_type = SlotDataType::FLOAT;
                    user_slot_list[i].slot_id = feature.slot_id();
                    auto &slot_features = *user_slot_list[i].float_values_repeated;
                    slot_features.push_back(&feature.weights());
                    break;
                }
                case SlotDataType::STRING: {
                    if (!user_slot_list[i].string_values_repeated) {
                        user_slot_list[i].string_values_repeated = std::make_shared<
                                std::vector<const google::protobuf::RepeatedPtrField<std::string> *>>();
                    }
                    user_slot_list[i].slot_data_type = SlotDataType::STRING;
                    user_slot_list[i].slot_id = feature.slot_id();
                    auto &slot_features = *user_slot_list[i].string_values_repeated;
                    slot_features.push_back(&feature.bytes_list());
                    break;
                }
                default: {
                    // HILOG_APP(INFO) << "user feature 具有未知的 data type";
                    user_slot_list[i].slot_data_type = SlotDataType::UNKNOWN;
                    break;
                }
            }
        }
        //user特征转换为ragged tensor,分配在context arena上
        std::vector<::proto::flow::ModelPredictRequest_PredictInputTensor *> user_ragged_tensor{};
        user_ragged_tensor.reserve(user_slot_num);

        size_t user_input_tensor_size = 0;

        for (const auto &user_slot_info: user_slot_list) {
            auto *user_input =
                    google::protobuf::Arena::CreateMessage<::proto::flow::ModelPredictRequest_PredictInputTensor>(
                            arena);
            user_input->set_name(user_slot_info.slot_id);
            user_input->set_type(0);// 0表示user 1表示item

            //填充 user 特征到 inputs
            switch (user_slot_info.get_data_type()) {
                case SlotDataType::INT_64: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(*user_slot_info.int_values_repeated, arena));
                    user_input->set_allocated_values(rt);
                    break;
                }
                case SlotDataType::FLOAT: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(*user_slot_info.float_values_repeated, arena));
                    user_input->set_allocated_values(rt);
                    break;
                }
                case SlotDataType::STRING: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(*user_slot_info.string_values_repeated, arena));
                    user_input->set_allocated_values(rt);
                    break;
                }
                default: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(std::vector<std::vector<int64_t>>(), arena));
                    user_input->set_allocated_values(rt);
                    break;
                }
            }
            user_input_tensor_size += user_input->ByteSizeLong();
            user_ragged_tensor.emplace_back(user_input);
        }

        int64_t signs_size = 0;
        int64_t weights_size = 0;
        int64_t byte_list_size = 0;

        if (context->get_rank_request()->debuglevel() == DebugLevel::kPrintModelRequestInfo ||
            ServerConfig::_turn_on_predict_service_model_info_monitor) {

            for (const auto &user_slot_info: user_slot_list) {
                switch (user_slot_info.get_data_type()) {
                    case SlotDataType::INT_64: {
                        if (user_slot_info.int_values_repeated) {
                            signs_size += user_slot_info.int_values_repeated->size();
                        }
                        break;
                    }
                    case SlotDataType::FLOAT: {
                        weights_size += user_slot_info.float_values_repeated->size();
                        break;
                    }
                    case SlotDataType::STRING: {
                        byte_list_size += user_slot_info.string_values_repeated->size();
                        break;
                    }
                    default: {
                        HILOG_APP(WARNING) << "unknown type";
                        break;
                    }
                }
            }

            HILOG_APP(ERROR) << "predict_type: " << experimentModelTypeToString(get_predict_type())
                             << ", model_name: " << model_info->_model_name
                             << " user_slot_num: " << user_slot_list.size() << ", signs_size: " << signs_size
                             << ", weights_size: " << weights_size << ", byte_list_size: " << byte_list_size
                             << ", user_input_tensor_size: " << user_input_tensor_size;
            // std::cout << "predict_type: " << experimentModelTypeToString(get_predict_type())
            //           << ", model_name: " << model_info->_model_name << " user_slot_num: " << user_slot_list.size()
            //           << ", signs_size: " << signs_size << ", weights_size: " << weights_size
            //           << ", byte_list_size: " << byte_list_size
            //           << ", user_input_tensor_size: " << user_input_tensor_size << std::endl;

            MonitorMgr::percent_report_model(model_info->_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "user_slot_num",
                                             user_slot_list.size());
            MonitorMgr::percent_report_model(model_info->_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "signs_size", signs_size);
            MonitorMgr::percent_report_model(model_info->_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "weights_size",
                                             weights_size);
            MonitorMgr::percent_report_model(model_info->_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "byte_list_size",
                                             byte_list_size);
            MonitorMgr::percent_report_model(model_info->_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "user_input_tensor_size",
                                             user_input_tensor_size);
        }

        prepare_user_feature = butil::gettimeofday_us() - prepare_user_feature;
        if (ServerConfig::_debug_bvar_monitor_enable) {
            debug::monitor::MonitorPercentile("prepare_user_feature", prepare_user_feature);
        }
        // 写 user_slot_list 到文件 predict_type + model_name + user_slot_list.txt
        if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
            debug::file::WriteToFile(experimentModelTypeToString(get_predict_type()) + "_" + model_info->_model_name +
                                             "_" + "user_slot_list.txt",
                                     debug::printer::ToString(user_slot_list));
        }

        //合并 item_features
        int64_t merge_item_slots = gettimeofday_us();

        HILOG_APP(INFO) << "start merging item";
        std::vector<SlotInfo> item_slot_list;
        int32_t &total_item = model_infer._total_item;
        merge_item_fe_response(extractor_responses, item_slot_data_types, item_slot_num, total_item, item_slot_list);
        HILOG_APP(INFO) << "end merging item";
        merge_item_slots = gettimeofday_us() - merge_item_slots;
        if (ServerConfig::_debug_bvar_monitor_enable) {
            debug::monitor::MonitorPercentile("merge_item_slots", merge_item_slots);
        }

        size_t batch_num = model_infer._infer_pairs.size();

        for (auto batch_index = 0; batch_index < batch_num; batch_index++) {
            start_bthread(&PredictService::batch_predict, BThreadType::Normal, this, context, item_slot_list,
                                model_info, user_ragged_tensor, total_item, _batch_size, batch_index);
        }
        return true;
    }

    void PredictService::batch_predict(
            CoreContextPtr &context, const std::vector<SlotInfo> &item_slot_list,
            Core::ExperimentModelInfo *const model_info,
            const std::vector<::proto::flow::ModelPredictRequest_PredictInputTensor *> &user_input_tensors,
            size_t total_item, size_t batch_size, size_t batch_index) {
        long make_infer_request = butil::gettimeofday_us();
        // step1.按照batch拆分item特征
        size_t flat_index_start = batch_size * batch_index;
        size_t flat_index_end = std::min(flat_index_start + batch_size, total_item);
        std::vector<std::shared_ptr<SlotInfo>> batch_slots(item_slot_list.size());
        for (size_t slot_idx = 0; slot_idx < item_slot_list.size(); ++slot_idx) {
            auto &slot_info = item_slot_list[slot_idx];
            batch_slots[slot_idx] = slot_info.sub_slot_info(flat_index_start, (flat_index_end - flat_index_start));
        }

        //step2.构造推理请求
        auto *arena = context->get_context_arena();
        auto *predict_request = google::protobuf::Arena::CreateMessage<::proto::flow::PredictRequest>(arena);
        ::proto::flow::ModelPredictRequest *model_request = predict_request->add_model_requests();
        model_request->set_model_name(model_info->_model_name);

        int64_t signs_size = 0;
        int64_t weights_size = 0;
        int64_t byte_list_size = 0;
        if (context->get_rank_request()->debuglevel() == DebugLevel::kPrintModelRequestInfo ||
            ServerConfig::_turn_on_predict_service_model_info_monitor) {

            for (const auto &item_slot_info_ptr: batch_slots) {
                auto &item_slot_info = *item_slot_info_ptr;
                switch (item_slot_info.get_data_type()) {
                    case SlotDataType::INT_64: {
                        if (item_slot_info.int_values_repeated) {
                            signs_size += item_slot_info.int_values_repeated->size();
                        }
                        break;
                    }
                    case SlotDataType::FLOAT: {
                        weights_size += item_slot_info.float_values_repeated->size();
                        break;
                    }
                    case SlotDataType::STRING: {
                        byte_list_size += item_slot_info.string_values_repeated->size();
                        break;
                    }
                    default: {
                        HILOG_APP(WARNING) << "unknown type";
                        break;
                    }
                }
            }
        }

        // step2.1 将item特征处理为ragged tensor

        size_t item_input_tensor_size = 0;
        for (const auto &item_slot_info_ptr: batch_slots) {
            auto &item_slot_info = *item_slot_info_ptr;
            auto *item_input = model_request->add_inputs();
            item_input->set_name(item_slot_info.slot_id);
            item_input->set_type(1);// 0表示user 1表示item

            //填充 item 特征到 inputs
            switch (item_slot_info.get_data_type()) {
                case SlotDataType::INT_64: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(*item_slot_info.int_values_repeated, arena));
                    item_input->set_allocated_values(rt);
                    break;
                }
                case SlotDataType::FLOAT: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(*item_slot_info.float_values_repeated, arena));
                    item_input->set_allocated_values(rt);
                    break;
                }
                case SlotDataType::STRING: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(*item_slot_info.string_values_repeated, arena));
                    item_input->set_allocated_values(rt);
                    break;
                }
                default: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(std::vector<std::vector<int64_t>>(), arena));
                    item_input->set_allocated_values(rt);
                    break;
                }
            }

            item_input_tensor_size += item_input->ByteSizeLong();
        }

        //step3.将已经处理好的user ragged tensor直接填充,注意这里必须要将user ragged tensor 分配到同一个arena上,否则会有资源多次释放问题!
        for (auto user_input_tensor: user_input_tensors) {
            model_request->mutable_inputs()->AddAllocated(user_input_tensor);
        }
        if (ServerConfig::_debug_bvar_monitor_enable) {
            debug::monitor::MonitorPercentile("make_infer_request", butil::gettimeofday_us() - make_infer_request);
        }
        // 写 PredictRequest 到文件 predict_type + model_name + i + predictRequest.txt
        if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
            debug::pb::SavePbToFile(experimentModelTypeToString(get_predict_type()) + "_" + model_info->_model_name +
                                            "_" + std::to_string(batch_index) + "_" + "PredictRequest.json",
                                    *predict_request);
        }

        if (context->get_rank_request()->debuglevel() == DebugLevel::kPrintModelRequestInfo ||
            ServerConfig::_turn_on_predict_service_model_info_monitor) {

            HILOG_APP(ERROR) << "predict_type: " << experimentModelTypeToString(get_predict_type())
                             << ", model_name: " << model_info->_model_name << ", batch index: " << batch_index
                             << ", item_slot_num: " << item_slot_list.size() << ", signs_size: " << signs_size
                             << ", weights_size: " << weights_size << ", byte_list_size: " << byte_list_size
                             << ", model_request->ByteSizeLong(): " << model_request->ByteSizeLong()
                             << ", item_input_tensor_size: " << item_input_tensor_size;
            // std::cout << "predict_type: " << experimentModelTypeToString(get_predict_type())
            //           << ", model_name: " << model_info->_model_name << ", batch index: " << batch_index
            //           << ", item_slot_num: " << item_slot_list.size() << ", signs_size: " << signs_size
            //           << ", weights_size: " << weights_size << ", byte_list_size: " << byte_list_size
            //           << ", model_request->ByteSizeLong(): " << model_request->ByteSizeLong()
            //           << ", item_input_tensor_size: " << item_input_tensor_size << std::endl;

            MonitorMgr::percent_report_model(model_info->_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "item_slot_num",
                                             item_slot_list.size());
            MonitorMgr::percent_report_model(model_info->_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "signs_size", signs_size);
            MonitorMgr::percent_report_model(model_info->_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "weights_size",
                                             weights_size);
            MonitorMgr::percent_report_model(model_info->_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "byte_list_size",
                                             byte_list_size);
            MonitorMgr::percent_report_model(model_info->_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "item_input_tensor_size",
                                             item_input_tensor_size);

            MonitorMgr::percent_report_model(model_info->_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "model_request_byte_size",
                                             model_request->ByteSizeLong());
        }

        //step4.发起rpc请求
        brpc::Channel *channel = model_info->_model_info->get_channel();
        ::proto::flow::PredictResponse *response =
                google::protobuf::Arena::CreateMessage<::proto::flow::PredictResponse>(arena);
        // process_prediction
        int64_t infer_io_start = butil::gettimeofday_us();
        ::proto::flow::PredicterService_Stub stub(channel);
        auto *simple_callback = new SimpleCallBack(context, this, predict_request, response, model_info, _predict_type,
                                                   batch_index, _batch_size, make_infer_request, infer_io_start);
        stub.Predict(&simple_callback->cntl, simple_callback->request, simple_callback->response, simple_callback);
    }

    std::vector<std::vector<SlotInfo>>
    PredictService::parse_item_list(const std::vector<ExtractorWrapper> &extractor_responses,
                                    const size_t &item_slot_num, const std::vector<SlotDataType> &item_slot_data_types,
                                    int32_t &total_item, CoreContextPtr &context, const std::string &model_name) {

        int64_t predict_service_merge_item = gettimeofday_us();
        std::vector<SlotInfo> item_slot_list(item_slot_num);//存储合包后的所有item特征
        HILOG_APP(INFO) << "start merging item";
        for (const auto &extractor_wrapper_response: extractor_responses) {
            //合并 item_cnt
            auto extractor_response = extractor_wrapper_response.extractor_response;
            total_item += extractor_response->item_cnt();

            auto &item_features = extractor_response->item_features();

            int64_t item_num = extractor_response->item_cnt();
            for (int i = 0; i < item_slot_num; ++i) {
                for (int j = 0; j < item_num; ++j) {
                    //遍历所有item的同一slot的特征
                    auto &feature = item_features.at(j + item_num * i);//(slot_i,item_j)处的Feature
                    SlotDataType data_type = item_slot_data_types[i];
                    switch (data_type) {
                        case SlotDataType::INT_64: {
                            if (!item_slot_list[i].int_values) {
                                item_slot_list[i].int_values = std::make_shared<std::vector<std::vector<int64_t>>>();
                            }
                            item_slot_list[i].slot_data_type = SlotDataType::INT_64;
                            std::vector<std::vector<int64_t>> &slot_features = *item_slot_list[i].int_values;
                            const auto &data = feature.signs();
                            item_slot_list[i].slot_id = feature.slot_id();
                            std::vector<int64_t> feature_data(data.size());
                            //把feature.signs()转换成 vector<int>
                            for (int k = 0; k < data.size(); ++k) {
                                feature_data[k] = data[k];
                            }
                            slot_features.push_back(feature_data);
                            break;
                        }
                        case SlotDataType::FLOAT: {
                            if (!item_slot_list[i].float_values) {
                                item_slot_list[i].float_values = std::make_shared<std::vector<std::vector<float>>>();
                            }
                            item_slot_list[i].slot_data_type = SlotDataType::FLOAT;
                            std::vector<std::vector<float>> &slot_features = *item_slot_list[i].float_values;
                            const auto &data = feature.weights();
                            item_slot_list[i].slot_id = feature.slot_id();
                            std::vector<float> feature_data(data.size());
                            //把feature.signs()转换成 vector<float>
                            for (int k = 0; k < data.size(); ++k) {
                                feature_data[k] = data[k];
                            }
                            slot_features.push_back(feature_data);
                            break;
                        }
                        case SlotDataType::STRING: {
                            if (!item_slot_list[i].string_values) {
                                item_slot_list[i].string_values =
                                        std::make_shared<std::vector<std::vector<std::string>>>();
                            }
                            item_slot_list[i].slot_data_type = SlotDataType::STRING;
                            std::vector<std::vector<std::string>> &slot_features = *item_slot_list[i].string_values;
                            const auto &data = feature.bytes_list();
                            item_slot_list[i].slot_id = feature.slot_id();
                            std::vector<std::string> feature_data(data.size());
                            //把feature.signs()转换成 vector<string>
                            for (int k = 0; k < data.size(); ++k) {
                                feature_data[k] = data[k];
                            }
                            slot_features.push_back(feature_data);
                            break;
                        }
                        default: {
                            // HILOG_APP(INFO) << "feature 具有未知的 data type";
                            item_slot_list[i].slot_data_type = SlotDataType::UNKNOWN;
                            item_slot_list[i].slot_id = feature.slot_id();
                            break;
                        }
                    }
                }
            }//对于同一个slot，应该可以异步
        }//这里同步
        HILOG_APP(INFO) << "end merging item";

        MonitorMgr::percent_report_model(model_name, context->GetUploadSlotName(),
                                         std::to_string(context->get_algo_scene_id()), 0, "ranking_merge_time",
                                         gettimeofday_us() - predict_service_merge_item);

        // 写 item_slot_list 到文件 predict_type + model_name + item_slot_list.txt
        if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
            debug::file::WriteToFile(experimentModelTypeToString(get_predict_type()) + "_" + model_name + "_" +
                                             "item_slot_list.txt",
                                     debug::printer::ToString(item_slot_list));
        }
        //根据 配置（每N个item分成一个包） 再分 std::vector<SlotInfo> （已经合包的 Fe 结果，只有一个包）
        //分成 std::vector<std::vector<SlotInfo>>
        //      第i个包     该包的第j个Slot

        //SlotInfo中有且仅会有一个vector非空
        //如果是一个包N个item，那么 一个 SlotInfo 就会分出 vector<SlotInfo>，第i个slotinfo  是原本的[i,i*N)的那部分
        //直观看就是把一个SlotInfo斩断成几节，每一节的vector数量为N，如果原SlotInfo中元素数量不能被N整除，最后一节会不满N个
        HILOG_APP(INFO) << "start split item";
        int64_t predict_service_split_item = gettimeofday_us();
        std::vector<std::vector<SlotInfo>> item_splited_batches =
                split_into_batches(item_slot_list, _batch_size, total_item);
        MonitorMgr::percent_report_model(model_name, context->GetUploadSlotName(),
                                         std::to_string(context->get_algo_scene_id()), 0, "ranking_split_time",
                                         gettimeofday_us() - predict_service_split_item);
        HILOG_APP(INFO) << "end split item";
        return item_splited_batches;
    }

    int PredictService::parse_item_list(const std::vector<ExtractorWrapper> &extractor_responses,
                                        const size_t &item_slot_num,
                                        const std::vector<SlotDataType> &item_slot_data_types, int32_t &total_item,
                                        CoreContextPtr &context, const std::string &model_name,
                                        std::vector<std::vector<std::shared_ptr<SlotInfo>>> &ret) {
        std::vector<SlotInfo> item_slot_list(item_slot_num);//存储合包后的所有item特征
        HILOG_APP(INFO) << "start merging item";
        for (const auto &extractor_wrapper_response: extractor_responses) {
            //合并 item_cnt
            auto extractor_response = extractor_wrapper_response.extractor_response;
            total_item += extractor_response->item_cnt();

            auto &item_features = extractor_response->item_features();

            int64_t item_num = extractor_response->item_cnt();
            for (int i = 0; i < item_slot_num; ++i) {
                for (int j = 0; j < item_num; ++j) {
                    //遍历所有item的同一slot的特征
                    auto &feature = item_features.at(j + item_num * i);//(slot_i,item_j)处的Feature
                    SlotDataType data_type = item_slot_data_types[i];
                    switch (data_type) {
                        case SlotDataType::INT_64: {
                            if (!item_slot_list[i].int_values_repeated) {
                                item_slot_list[i].int_values_repeated = std::make_shared<
                                        std::vector<const google::protobuf::RepeatedField<int64_t> *>>();
                            }
                            item_slot_list[i].slot_data_type = SlotDataType::INT_64;
                            auto &slot_features = *item_slot_list[i].int_values_repeated;
                            slot_features.push_back(&feature.signs());
                            break;
                        }
                        case SlotDataType::FLOAT: {
                            if (!item_slot_list[i].float_values_repeated) {
                                item_slot_list[i].float_values_repeated =
                                        std::make_shared<std::vector<const google::protobuf::RepeatedField<float> *>>();
                            }
                            item_slot_list[i].slot_data_type = SlotDataType::FLOAT;
                            auto &slot_features = *item_slot_list[i].float_values_repeated;
                            slot_features.push_back(&feature.weights());
                            break;
                        }
                        case SlotDataType::STRING: {
                            if (!item_slot_list[i].string_values_repeated) {
                                item_slot_list[i].string_values_repeated = std::make_shared<
                                        std::vector<const google::protobuf::RepeatedPtrField<std::string> *>>();
                            }
                            item_slot_list[i].slot_data_type = SlotDataType::STRING;
                            auto &slot_features = *item_slot_list[i].string_values_repeated;
                            slot_features.push_back(&feature.bytes_list());
                            break;
                        }
                        default: {
                            // HILOG_APP(INFO) << "feature 具有未知的 data type";
                            item_slot_list[i].slot_data_type = SlotDataType::UNKNOWN;
                            item_slot_list[i].slot_id = feature.slot_id();
                            break;
                        }
                    }
                }
            }//对于同一个slot，应该可以异步
        }//这里同步
        HILOG_APP(INFO) << "end merging item";

        // 写 item_slot_list 到文件 predict_type + model_name + item_slot_list.txt
        if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
            debug::file::WriteToFile(experimentModelTypeToString(get_predict_type()) + "_" + model_name + "_" +
                                             "item_slot_list.txt",
                                     debug::printer::ToString(item_slot_list));
        }
        //根据 配置（每N个item分成一个包） 再分 std::vector<SlotInfo> （已经合包的 Fe 结果，只有一个包）
        //分成 std::vector<std::vector<SlotInfo>>
        //      第i个包     该包的第j个Slot

        //SlotInfo中有且仅会有一个vector非空
        //如果是一个包N个item，那么 一个 SlotInfo 就会分出 vector<SlotInfo>，第i个slotinfo  是原本的[i,i*N)的那部分
        //直观看就是把一个SlotInfo斩断成几节，每一节的vector数量为N，如果原SlotInfo中元素数量不能被N整除，最后一节会不满N个
        HILOG_APP(INFO) << "start split item";
        HILOG_APP(INFO) << "end split item";
        return split_into_batches(item_slot_list, _batch_size, total_item, ret);
    }

    int PredictService::merge_item_fe_response(const std::vector<ExtractorWrapper> &extractor_responses,
                                               const std::vector<SlotDataType> &item_slot_data_types,
                                               size_t item_slot_num, int32_t &total_item,
                                               std::vector<SlotInfo> &item_slot_list) {
        //存储合包后的所有item特征
        item_slot_list.resize(item_slot_num);
        int32_t extrator_index = 0;
        for (const auto &extractor_wrapper_response: extractor_responses) {
            //合并 item_cnt
            auto extractor_response = extractor_wrapper_response.extractor_response;
            auto &item_features = extractor_response->item_features();
            int32_t item_fea_length = item_features.size();
            int32_t item_num = extractor_response->item_cnt();
            int32_t i = 0;
            for (int32_t index = 0; index < item_fea_length; ++index) {
                i = index / item_num;
                int32_t item_index = index % item_num;
                auto &feature = item_features.at(index);//(slot_i,item_j)处的Feature
                SlotDataType data_type = item_slot_data_types[i];
                switch (data_type) {
                    case SlotDataType::INT_64: {
                        if (!item_slot_list[i].int_values_repeated) {
                            item_slot_list[i].int_values_repeated =
                                    std::make_shared<std::vector<const google::protobuf::RepeatedField<int64_t> *>>(
                                            total_item);
                            item_slot_list[i].slot_data_type = SlotDataType::INT_64;
                            item_slot_list[i].slot_id = feature.slot_id();
                        }
                        item_slot_list[i].int_values_repeated->operator[](extrator_index + item_index) =
                                &feature.signs();
                        break;
                    }
                    case SlotDataType::FLOAT: {
                        if (!item_slot_list[i].float_values_repeated) {
                            item_slot_list[i].float_values_repeated =
                                    std::make_shared<std::vector<const google::protobuf::RepeatedField<float> *>>(
                                            total_item);
                            item_slot_list[i].slot_data_type = SlotDataType::FLOAT;
                            item_slot_list[i].slot_id = feature.slot_id();
                        }
                        item_slot_list[i].float_values_repeated->operator[](extrator_index + item_index) =
                                &feature.weights();
                        break;
                    }
                    case SlotDataType::STRING: {
                        if (!item_slot_list[i].string_values_repeated) {
                            item_slot_list[i].string_values_repeated = std::make_shared<
                                    std::vector<const google::protobuf::RepeatedPtrField<std::string> *>>(total_item);
                            item_slot_list[i].slot_data_type = SlotDataType::STRING;
                            item_slot_list[i].slot_id = feature.slot_id();
                        }
                        item_slot_list[i].string_values_repeated->operator[](extrator_index + item_index) =
                                &feature.bytes_list();
                        break;
                    }
                    default: {
                        item_slot_list[i].slot_data_type = SlotDataType::UNKNOWN;
                        item_slot_list[i].slot_id = feature.slot_id();
                        break;
                    }
                }

            }//item_feature

            //下一个分包位置
            extrator_index += item_num;
        }
        return 0;
    }

    void PredictService::update_score_status(const size_t &index, const size_t &batch_size,
                                             const std::vector<ItemWrapper> &item_wrappers,
                                             std::shared_ptr<CoreContext> &context,
                                             const PredictScoreStatus &ctr_status,
                                             const PredictScoreStatus &cvr_status,
                                             const PredictScoreStatus &ltv_status) {
        for (int i = index * batch_size; i < (index + 1) * batch_size && i < item_wrappers.size(); i++) {
            const phx::PredictorItemInfo *item_info = item_wrappers[i].item;
            for (auto &prerank_dump: *context->_bak_response_dump->mutable_responsedumpdata()) {
                if (item_info->creativeid() == prerank_dump.creativeid()) {
                    if (ctr_status != PREDICT_SCORE_UNKOWN) {
                        prerank_dump.set_ctrstatus(ctr_status);
                    }
                    if (cvr_status != PREDICT_SCORE_UNKOWN) {
                        prerank_dump.set_cvrstatus(cvr_status);
                    }
                    if (ltv_status!= PREDICT_SCORE_UNKOWN) {
                        prerank_dump.set_ltvstatus(ltv_status);
                    }
                    break;
                }
            }
        }
    }

    //外层的vector是batch （行拆分）
    //内层的vector是全部的slot （列拆分）
    std::vector<std::vector<SlotInfo>> PredictService::split_into_batches(const std::vector<SlotInfo> &item_slot_list,
                                                                          size_t batch_size, size_t total_item) {
        size_t slot_num = item_slot_list.size();
        if (slot_num < 1) {
            HILOG_APP(ERROR) << "slot_num = 0";
            return {};
        }

        HILOG_APP(INFO) << "item_slot_list: " << debug::printer::ToString(item_slot_list);

        size_t batch_num = (total_item + batch_size - 1) / batch_size;

        HILOG_APP(INFO) << "split_into_batches start, batch_size:" << batch_size << ", total_item: " << total_item
                        << ", batch_num: " << batch_num;
        std::vector<std::vector<SlotInfo>> batches(batch_num,
                                                   std::vector<SlotInfo>(slot_num));// i:请求包 j是 SlotInfo

        for (int col = 0; col < slot_num; ++col) {
            std::vector<SlotInfo> split_slot_infos;
            if (item_slot_list[col].get_data_type() == SlotDataType::UNKNOWN) {
                //特殊处理
                split_slot_infos = std::vector<SlotInfo>(batch_num);
                for (auto &info: split_slot_infos) {
                    info.slot_id = item_slot_list[col].slot_id;
                    info.slot_data_type = SlotDataType::UNKNOWN;
                }
            } else {
                split_slot_infos = item_slot_list[col].split(batch_size);//拆散的列
            }

            for (int row = 0; row < batch_num; ++row) {
                batches[row][col] = split_slot_infos[row];
            }
        }
        HILOG_APP(INFO) << "split_into_batches end";
        return batches;
    }

    int PredictService::split_into_batches(const std::vector<SlotInfo> &item_slot_list, size_t batch_size,
                                           size_t total_item,
                                           std::vector<std::vector<std::shared_ptr<SlotInfo>>> &result) {
        size_t slot_num = item_slot_list.size();
        if (slot_num < 1) {
            HILOG_APP(ERROR) << "slot_num = 0";
            return -1;
        }

        HILOG_APP(INFO) << "item_slot_list: " << debug::printer::ToString(item_slot_list);

        size_t batch_num = (total_item + batch_size - 1) / batch_size;

        HILOG_APP(INFO) << "split_into_batches start, batch_size:" << batch_size << ", total_item: " << total_item
                        << ", batch_num: " << batch_num;
        result.assign(batch_num, std::vector<std::shared_ptr<SlotInfo>>(slot_num));// i:请求包 j是 SlotInfo

        for (int col = 0; col < slot_num; ++col) {
            std::vector<std::shared_ptr<SlotInfo>> split_slot_infos(batch_num);
            if (item_slot_list[col].get_data_type() == SlotDataType::UNKNOWN) {
                //特殊处理
                for (auto &info: split_slot_infos) {
                    info = std::make_shared<SlotInfo>();
                    info->slot_id = item_slot_list[col].slot_id;
                    info->slot_data_type = SlotDataType::UNKNOWN;
                }
            } else {
                item_slot_list[col].split(batch_num, batch_size, split_slot_infos);//拆散的列
            }

            for (int row = 0; row < batch_num; ++row) {
                result[row][col] = split_slot_infos[row];
            }
        }
        HILOG_APP(INFO) << "split_into_batches end";
        return 0;
    }

}// namespace Core