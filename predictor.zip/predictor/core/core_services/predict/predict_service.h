#pragma once

#include "common/comm/concurrent_map.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"
#include "fe_request.pb.h"
#include "hlframe/node.h"
#include "phx-fe/util/util.h"
#include "tf/flow.pb.h"
#include <algorithm>
#include <brpc/controller.h>
#include <bthread/bthread.h>
#include <bthread/types.h>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <glog/logging.h>
#include <log_helper.h>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
namespace Core {
    enum class BThreadType {
        Normal,
        Urgent,
    };

    static void *bthread_bridge(void *raw) {
        auto f = static_cast<std::function<void()> *>(raw);
        (*f)();
        delete f;
        return nullptr;
    }

    template<typename F, typename... Args>
    bthread_t start_bthread(F &&func, BThreadType type = BThreadType::Normal, Args &&...args) {
        auto task_ptr = new std::function<void()>(std::bind(std::forward<F>(func), std::forward<Args>(args)...));
        bthread_t bth;
        if (type == BThreadType::Urgent) {
            bthread_start_urgent(&bth, nullptr, bthread_bridge, task_ptr);
        } else {
            bthread_start_background(&bth, nullptr, bthread_bridge, task_ptr);
        }

        return bth;
    }

    class PredictService : public ServiceBaseInfo {
    private:
        int32_t _batch_size = 40;//每个包中的item数量

        void get_item_slot_data_types(const std::string &model_name,
                                      const std::vector<ExtractorWrapper> &extractor_responses, size_t slot_num,
                                      std::vector<SlotDataType> &slot_data);
        void get_user_slot_data_types(const std::string &model_name,
                                      const std::vector<ExtractorWrapper> &extractor_responses, size_t slot_num,
                                      std::vector<SlotDataType> &slot_data);

        //将合包后的完整的包，根据配置项 batch_size（每个分包中item个数）拆出多个分包
        std::vector<std::vector<SlotInfo>> split_into_batches(const std::vector<SlotInfo> &slot_list, size_t batch_size,
                                                              size_t total_item);
        int split_into_batches(const std::vector<SlotInfo> &slot_list, size_t batch_size, size_t total_item,
                               std::vector<std::vector<std::shared_ptr<SlotInfo>>> &result);
        ExperimentModelType _predict_type = ExperimentModelType::MODEL_INFO_UNKNOWN;

    public:
        PredictService() = default;
        ~PredictService() {

        };

        void initialize(ConfigXmlPtr xml) override;
        void initialize(GraphContextPtr context) override;
        int do_service(GraphContextPtr context) override;
        bool skip(GraphContextPtr context) override;
        const Node_Type type() override {
            return HLframe::NODE_TYPE_IO;
        }

        static void update_score_status(const size_t &index, const size_t &batch_size, const std::vector<ItemWrapper>& item_wrappers, 
                                std::shared_ptr<CoreContext> &context, const PredictScoreStatus &ctr_status,
                                const PredictScoreStatus &cvr_status, const PredictScoreStatus &ltv_status);

        // 预先计算模型分包数，并预留分包索引
        int32_t reserve_model_split_num(CoreContextPtr &context, ExperimentModelInfo *model_info,
                                              const std::vector<ExtractorWrapper> &extractor_responses);

        bool process_single_model(CoreContextPtr &context, ExperimentModelInfo *model_info,
                                  const std::vector<ExtractorWrapper> &extractor_responses);

        // 按照batch 维度拆包 + 生产预估请求 + 调用推理服务
        void
        batch_predict(CoreContextPtr &context, const std::vector<SlotInfo> &item_slot_list,
                      Core::ExperimentModelInfo *const model_info,
                      const std::vector<::proto::flow::ModelPredictRequest_PredictInputTensor *> &user_input_tensors,
                      size_t total_item, size_t batch_size, size_t batch_index);
        int merge_item_fe_response(const std::vector<ExtractorWrapper> &extractor_responses,
                                   const std::vector<SlotDataType> &item_slot_data_types, size_t item_slot_num,
                                   int32_t &total_item, std::vector<SlotInfo> &item_slot_info);

        static std::vector<ItemWrapper> *get_item_wrappers(CoreContextPtr &context,
                                                           Core::ExperimentModelInfo *model_info,
                                                           ExperimentModelType predict_type) {
            std::vector<ItemWrapper> *item_vec = nullptr;
            switch (predict_type) {
                case ExperimentModelType::CPC_CTR: {
                    auto it = context->_model_predict_cpc_ctr_map.find(model_info);
                    if (it != context->_model_predict_cpc_ctr_map.end()) {
                        item_vec = &it->second;
                    } else {
                        // key不存在的处理逻辑
                    }
                    break;
                }
                case ExperimentModelType::CPD_CTR: {
                    auto it = context->_model_predict_cpd_ctr_map.find(model_info);
                    if (it != context->_model_predict_cpd_ctr_map.end()) {
                        item_vec = &it->second;
                    }
                    break;
                }
                case ExperimentModelType::CPC_CVR: {
                    auto it = context->_model_predict_cpc_cvr_map.find(model_info);
                    if (it != context->_model_predict_cpd_ctr_map.end()) {
                        item_vec = &it->second;
                    }
                    break;
                }
                case ExperimentModelType::CPD_CVR: {
                    auto it = context->_model_predict_cpd_cvr_map.find(model_info);
                    if (it != context->_model_predict_cpd_ctr_map.end()) {
                        item_vec = &it->second;
                    }
                    break;
                }
                case ExperimentModelType::LTV: {
                    auto it = context->_model_predict_ltv_map.find(model_info);
                    if(it != context->_model_predict_ltv_map.end()) {
                        item_vec = &it->second;
                    }
                    break;
                }
                default: {
                    HILOG_APP(ERROR) << "unknown predict type";
                    break;
                }
            }
            return item_vec;
        }

        static void mock_predict_response(::proto::flow::PredictResponse *response,
                                          Core::ExperimentModelInfo *experiment_model_info) {
            ::proto::flow::ModelPredictResponse *model_response = response->add_responses();
            model_response->set_model_name("rec-model-test");
            model_response->set_model_version(1);
            model_response->set_error_code(10000);
            model_response->set_error_message("");
            model_response->set_cost(100);
            model_response->set_inference_cost(80);

            ::proto::flow::ModelPredictResponse_PredictOutputTensor *output = model_response->add_outputs();
            output->set_name("0");
            output->mutable_values()->set_dtype(::proto::flow::DataType::DT_FLOAT);
            output->mutable_values()->add_shape(5);
            output->mutable_values()->add_shape(1);

            // 在函数外或合适的位置定义随机数生成器和分布
            std::random_device rd;                                // 随机数种子
            std::mt19937 gen(rd());                               // 伪随机数生成器
            std::uniform_real_distribution<float> dis(0.0f, 1.0f);// 生成0到1之间的浮点数

            // 生成随机数并添加到output
            int item_num = 5;
            for (int i = 0; i < item_num; i++) {
                float random_score = dis(gen);// 生成0到1之间的随机浮点数
                output->mutable_values()->add_float_val(random_score);
            }
        }

        static std::string extractor_responses_to_json(const std::vector<ExtractorWrapper> &extractor_responses);

        static bool safe_string_to_int(const std::string &str, int &out_value) {
            std::istringstream iss(str);
            iss >> out_value;
            return !iss.fail() && iss.eof();
        }

        virtual std::vector<std::vector<SlotInfo>>
        parse_item_list(const std::vector<ExtractorWrapper> &extractor_responses, const size_t &item_slot_num,
                        const std::vector<SlotDataType> &item_slot_data_types, int32_t &total_item,
                        CoreContextPtr &context, const std::string &model_name);

        virtual int parse_item_list(const std::vector<ExtractorWrapper> &extractor_responses,
                                    const size_t &item_slot_num, const std::vector<SlotDataType> &item_slot_data_types,
                                    int32_t &total_item, CoreContextPtr &context, const std::string &model_name,
                                    std::vector<std::vector<std::shared_ptr<SlotInfo>>> &batch);

    protected:
        int process(CoreContextPtr context) override;
        inline const ExperimentModelType &get_predict_type() const {
            return _predict_type;
        }
    };

}// namespace Core