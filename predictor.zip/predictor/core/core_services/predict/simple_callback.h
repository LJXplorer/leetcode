#pragma once
#include "core/core_context/core_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/base_service/c_adapter.h"
#include "core/core_services/predict/predict_service.h"
#include "core/utils/defs.h"
#include <brpc/options.pb.h>
#include <log_helper.h>
#include <utility>
#include <wrapper_time.h>
namespace Core {
    struct SimpleCallBack : public google::protobuf::Closure {
        SimpleCallBack(CoreContextPtr ctx, Node *node, const ::proto::flow::PredictRequest *req, ::proto::flow::PredictResponse *res,
                       Core::ExperimentModelInfo *experiment_model_info, ExperimentModelType predict_type, const size_t index, 
                       const int32_t &batch_size, const int64_t make_infer_request_start, const int64_t infer_io_start)
            : request(req), response(res), node(node), cntl(), context(std::move(ctx)), 
            experiment_model_info(experiment_model_info), predict_type(predict_type), 
            index(index), batch_size(batch_size), make_infer_request_start(make_infer_request_start),
            infer_io_start(infer_io_start) {
                cntl.set_request_compress_type(experiment_model_info->_model_info->_request_compress_type);
        }
        const ::proto::flow::PredictRequest *request;
        ::proto::flow::PredictResponse *response;
        Node *node;
        brpc::Controller cntl;
        CoreContextPtr context;
        Core::ExperimentModelInfo *experiment_model_info;
        ExperimentModelType predict_type;
        size_t index;
        int32_t batch_size;
        int64_t make_infer_request_start;
        int64_t infer_io_start;

        int32_t code = 0;
        int64_t lat = 0;
        void Run() override {
            auto *base_service_ptr = dynamic_cast<ServiceBaseInfo *>(node);
            if (base_service_ptr != nullptr) {
                BizLatency *lat = base_service_ptr->get_node_stat(context)->get_lat();
                // 最晚的infer_io_start作为请求阶段结束
                lat->_req_end_tm =  max(lat->_req_end_tm, infer_io_start);
                // 最早的收到回包开始计算返回阶段耗时
                if (lat->_rsp_begin_tm == 0) {
                    lat->_rsp_begin_tm = gettimeofday_us();
                }
            }
            lat = cntl.latency_us();
            code = cntl.ErrorCode();
            if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
                debug::pb::SavePbToFile(experimentModelTypeToString(predict_type) + "_" +
                                                experiment_model_info->_model_name + "_" + std::to_string(index) + "_" +
                                                "PredictResponse.json",
                                        *response);
            }
            if (ServerConfig::_debug_bvar_monitor_enable) {
                debug::monitor::MonitorPercentile("infer_io", butil::gettimeofday_us() - infer_io_start);
                debug::monitor::MonitorPercentile(experiment_model_info->_model_name + "_request_size",
                                                request->ByteSizeLong());
            }

            std::vector<ItemWrapper> *item_wrappers =
                PredictService::get_item_wrappers(context, experiment_model_info, predict_type);
            if (item_wrappers == nullptr) {
                HILOG_APP(ERROR) << "cannot find item_wrappers, model_name: "
                                    << experiment_model_info->_model_name
                                    << ", predict type: " << experimentModelTypeToString(predict_type);
            }

            auto infer_context = context->get_infer_context();
            auto &model_infer_pair = infer_context->get_model_infer(predict_type, experiment_model_info);
            auto &infer_pair = model_infer_pair._infer_pairs[index];
            infer_pair._start_index = index * batch_size;
            infer_pair._end_index = min((index + 1) * batch_size, (*item_wrappers).size());
            infer_pair._ret = cntl.ErrorCode();
            infer_pair._predict_request = request;
            //在stage监控里面上报推理相关时间
            std::string policy = "default";
            switch (experiment_model_info->_model_type) {
                case ExperimentModelType::CPC_CTR:
                case ExperimentModelType::CPD_CTR:
                    policy = context->_ctr_policy;
                    break;
                case ExperimentModelType::CPC_CVR:
                case ExperimentModelType::CPD_CVR:
                    policy = context->_cvr_policy;
                    break;
                case ExperimentModelType::LTV:
                    policy = context->_ltv_policy;
                    break;
                default:
                    break;
            }
            
            if (cntl.Failed()) {
                HILOG_APP(ERROR) << "model:" << experiment_model_info->_model_info->_model_name
                             << " Predict failed: " << cntl.ErrorText() << ",lat: " << cntl.latency_us();
                PredictService::update_score_status(index, batch_size, *item_wrappers, context, 
                                PREDICT_SCORE_FAIL, PREDICT_SCORE_FAIL, PREDICT_SCORE_FAIL);
                MonitorMgr::percent_report_model(experiment_model_info->_model_info->_model_name,
                                             context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()),
                                             cntl.ErrorCode(), "predict_time", cntl.latency_us());
                MonitorMgr::percent_report_stage(std::to_string(context->get_route()),
                                                std::to_string(context->get_algo_scene_id()), policy, node->get_name(),
                                                context->GetUploadSlotName(), cntl.ErrorCode(), "stage_predict_time",
                                                cntl.latency_us());
            } else {
                // debug::monitor::MonitorPercentile("serialize_request_time_us", cntl->_serialize_request_time_us);
                // debug::monitor::MonitorPercentile("network_time_us", cntl->_network_time_us);
                int64_t prcoess_infer_rsp = butil::gettimeofday_us();
                HILOG_APP(INFO) << "model:" << experiment_model_info->_model_info->_model_name
                                << " Predict success, lat: " << cntl.latency_us();

                MonitorMgr::percent_report_model(experiment_model_info->_model_info->_model_name,
                                             context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()),
                                             0, "predict_time", cntl.latency_us());

                MonitorMgr::percent_report_stage(std::to_string(context->get_route()),
                                                std::to_string(context->get_algo_scene_id()), policy, node->get_name(),
                                                context->GetUploadSlotName(), 0, "stage_predict_time", cntl.latency_us());

                auto &model_predict_responses = response->responses();//所有model_name所在的list
                for (const auto &model_predict_response: model_predict_responses) {
                    if (ServerConfig::_debug_bvar_monitor_enable) {
                        debug::monitor::MonitorPercentile("infer_cost", model_predict_response.cost());
                    }
                    if (model_predict_response.model_name() == experiment_model_info->_model_name) {
                        infer_pair._predict_response = response;
                        unordered_map<int32_t, ::proto::flow::ModelPredictResponse_PredictOutputTensor>
                            output_name_output_tensor_map;//output_name->output_tensor

                        const int32_t &error_code = model_predict_response.error_code();
                        const std::string &error_message = model_predict_response.error_message();

                        if (error_code != 10000) {
                            //模型返回 存在问题
                            HILOG_APP(ERROR) << "model: " << experiment_model_info->_model_info->_model_name
                                            << ", response error_code: " << error_code
                                            << ", error_message: " << error_message;
                            infer_pair._ret = -2;
                            PredictService::update_score_status(index, batch_size, *item_wrappers, context, 
                                PREDICT_SCORE_FAIL, PREDICT_SCORE_FAIL, PREDICT_SCORE_FAIL);
                            break;
                        }

                        for (const auto &predict_output_tensor: model_predict_response.outputs()) {

                            int output_name = -1;
                            if (!PredictService::safe_string_to_int(predict_output_tensor.name(), output_name)) {
                                HILOG_APP(ERROR) << "failed to convert output_name_str to int type, output_name_str: "
                                                << predict_output_tensor.name();
                            }
                            output_name_output_tensor_map[output_name] = predict_output_tensor;
                        }

                        // std::vector<ItemWrapper> *item_wrappers =
                        //         get_item_wrappers(context, experiment_model_info, get_predict_type());
                        // if (item_wrappers == nullptr) {
                        //     HILOG_APP(ERROR) << "cannot find item_wrappers, model_name: "
                        //                      << experiment_model_info->_model_name
                        //                      << ", predict type: " << experimentModelTypeToString(_predict_type);
                        // }

                        int64_t pctr_in_pos_num = context->get_pctr_in_pos_num();
                        int64_t model_pos_num =
                                experiment_model_info->_model_info->get_adunit_pos_info(context->get_slot_id());

                        auto get_score = [&](int pos_index, int score_index) -> float {
                            auto it = output_name_output_tensor_map.find(pos_index);
                            if (it != output_name_output_tensor_map.end()) {
                                const auto &scores = it->second.values().float_val();
                                if (scores.size() > score_index) {
                                    PredictService::update_score_status(index, batch_size, *item_wrappers, context, PREDICT_SCORE_UNKOWN,
                                                        PREDICT_SCORE_UNKOWN, PREDICT_SCORE_UNKOWN);
                                    return scores.at(score_index);
                                } else {
                                    HILOG_APP(WARNING)
                                            << "score_index: " << score_index << ">= scores.size(): " << scores.size();
                                }
                            } else {
                                HILOG_APP(WARNING) << pos_index << " not found in p.outputs";
                            }
                            return 0.0f;
                        };

                        //这里是要遍历 predict包中 item实际的位置
                        int score_index = 0;

                        for (int i = index * batch_size; i < (index + 1) * batch_size && i < (*item_wrappers).size();
                            i++) {
                            const phx::PredictorItemInfo *item_info = (*item_wrappers)[i].item;
                            int32_t conv_type = item_info->convtype();
                            int32_t deep_conv_type = item_info->deepconvtype();
                            int32_t enhance_conv_type = item_info->enhanceconvtype();

                            //修改下面的逻辑，从遍历判断改为直接查找output_name_output_tensor_map中是否有 conv_type 、 deep_conv_type 和 enhance_conv_type
                            if (predict_type == ExperimentModelType::CPC_CTR ||
                                predict_type == ExperimentModelType::CPD_CTR) {
                                if (experiment_model_info->_model_info->_multi_pos_flag) {
                                    // 多位置预估分数填充逻辑
                                    if (-1 == model_pos_num) {//广告位不在模型配置里面，用vec[0]填充pctr，多位置数据不填充
                                        float pctr = get_score(0, score_index);
                                        (*item_wrappers)[i].item_data->set_pctr(pctr);
                                        infer_pair._pctr_scores += pctr;
                                    } else {                       //广告位在模型配置里面
                                        if (0 == pctr_in_pos_num) {//商推传值为0, 用vec[0]填充pctr，多位置数据不填充
                                            float pctr = get_score(0, score_index);
                                            (*item_wrappers)[i].item_data->set_pctr(pctr);
                                            infer_pair._pctr_scores += pctr;
                                        } else if (pctr_in_pos_num > 0 && pctr_in_pos_num < model_pos_num) {
                                            //商推传值为在区间(0, model_pos_num)内, 用vec[-1]填充pctr，多位置数据不填充
                                            int max_pos = output_name_output_tensor_map.size() - 1;
                                            float pctr = get_score(max_pos, score_index);
                                            (*item_wrappers)[i].item_data->set_pctr(pctr);
                                            infer_pair._pctr_scores += pctr;
                                        } else if (pctr_in_pos_num >= model_pos_num) {
                                            //商推传值为在区间[model_pos_num,+OO)内, 用vec[-1]填充pctr，多位置数据填充
                                            int max_pos = output_name_output_tensor_map.size() - 1;
                                            float pctr = get_score(max_pos, score_index);
                                            (*item_wrappers)[i].item_data->set_pctr(pctr);
                                            infer_pair._pctr_scores += pctr;
                                            if (model_pos_num <= output_name_output_tensor_map.size() - 2) {
                                                infer_pair._pos_score.resize(model_pos_num, 0.0f);
                                                for (int pos_index = 1; pos_index <= model_pos_num; ++pos_index) {
                                                    float s = get_score(pos_index, score_index);
                                                    (*item_wrappers)[i].item_data->mutable_pctrinpos()->Add(s);
                                                    infer_pair._pos_score[pos_index - 1] += s;
                                                }
                                            } else {
                                                HILOG_APP(ERROR)
                                                        << "ERROR: adunit config pos num: " << model_pos_num
                                                        << " > output num: " << output_name_output_tensor_map.size();
                                            }
                                        }
                                    }
                                } else {
                                    //填ctr分
                                    auto it = output_name_output_tensor_map.find(0);
                                    if (it != output_name_output_tensor_map.end()) {
                                        const auto &scores = it->second.values().float_val();
                                        if (scores.size() > score_index) {
                                            (*item_wrappers)[i].item_data->set_pctr(scores.at(score_index));
                                            if (scores.at(score_index) <= epsilon) {
                                                infer_pair._zero_ctr++;
                                            }
                                            infer_pair._pctr_scores += scores.at(score_index);
                                            infer_pair._predict_ctr_success_cnt++;
                                            PredictService::update_score_status(index, batch_size, *item_wrappers, context, PREDICT_SCORE_SCUCESS,
                                                                PREDICT_SCORE_UNKOWN, PREDICT_SCORE_UNKOWN);
                                        }
                                        infer_pair._predict_ctr_cnt++;

                                    } else {
                                        infer_pair._model_no_optput++;
                                    }
                                }

                            } else if (predict_type == ExperimentModelType::CPC_CVR ||
                                    predict_type == ExperimentModelType::CPD_CVR) {
                                //填转化分
                                if (!experiment_model_info->_model_info->_multi_pos_flag) {// 防止cvr配置多位置预估
                                    bool cvr_success_score = false;
                                    if (conv_type != 0) {
                                        auto it = output_name_output_tensor_map.find(conv_type);
                                        if (it != output_name_output_tensor_map.end()) {
                                            const auto &scores = it->second.values().float_val();
                                            if (scores.size() > score_index) {
                                                (*item_wrappers)[i].item_data->set_pcvr(scores.at(score_index));
                                                if (scores.at(score_index) <= epsilon) {
                                                    infer_pair._zero_cvr++;
                                                }
                                                infer_pair._pcvr_scores += scores.at(score_index);
                                                infer_pair._predict_cvr_success_cnt++;
                                                cvr_success_score = true;
                                            }
                                            infer_pair._predict_cvr_cnt++;
                                        } else {
                                            infer_pair._model_no_optput++;
                                        }
                                    }

                                    if (deep_conv_type != 0) {
                                        auto it = output_name_output_tensor_map.find(deep_conv_type);
                                        if (it != output_name_output_tensor_map.end()) {
                                            const auto &scores = it->second.values().float_val();
                                            if (scores.size() > score_index) {
                                                (*item_wrappers)[i].item_data->set_pdcvr(scores.at(score_index));
                                                if (scores.at(score_index) <= epsilon) {
                                                    infer_pair._zero_dcvr++;
                                                }
                                                infer_pair._pdcvr_scores += scores.at(score_index);
                                                infer_pair._predict_deep_cvr_success_cnt++;
                                                cvr_success_score = true;
                                            }
                                            infer_pair._predict_deep_cvr_cnt++;
                                        } else {
                                            infer_pair._model_no_optput++;
                                        }
                                    }

                                    if (enhance_conv_type != 0) {
                                        auto it = output_name_output_tensor_map.find(enhance_conv_type);
                                        if (it != output_name_output_tensor_map.end()) {
                                            const auto &scores = it->second.values().float_val();
                                            if (scores.size() > score_index) {
                                                (*item_wrappers)[i].item_data->set_pecvr(scores.at(score_index));
                                                if (scores.at(score_index) <= epsilon) {
                                                    infer_pair._zero_ecvr++;
                                                }
                                                infer_pair._pecvr_scores += scores.at(score_index);
                                                infer_pair._predict_enhance_cvr_success_cnt++;
                                                cvr_success_score = true;
                                            }
                                            infer_pair._predict_enhance_cvr_cnt++;
                                        } else {
                                            infer_pair._model_no_optput++;
                                        }
                                    }

                                    int32_t cvr1_target = item_info->cvr1target();
                                    if(cvr1_target != 0) {
                                        auto it = output_name_output_tensor_map.find(cvr1_target);
                                        if (it != output_name_output_tensor_map.end()) {
                                            const auto &scores = it->second.values().float_val();
                                            if (scores.size() > score_index) {
                                                (*item_wrappers)[i].item_data->set_pcvr1(scores.at(score_index));
                                                if (scores.at(score_index) <= epsilon) {
                                                    infer_pair._zero_pcvr1++;
                                                }
                                                infer_pair._pcvr1_scores += scores.at(score_index);
                                                infer_pair._predict_pcvr1_success_cnt++;
                                                cvr_success_score = true;
                                            }
                                            infer_pair._predict_pcvr1_cnt++;
                                        } else {
                                            infer_pair._model_no_optput++;
                                        }

                                    }

                                    int32_t cvr2_target = item_info->cvr2target();
                                    if(cvr2_target != 0) {
                                        auto it = output_name_output_tensor_map.find(cvr2_target);
                                        if (it != output_name_output_tensor_map.end()) {
                                            const auto &scores = it->second.values().float_val();
                                            if (scores.size() > score_index) {
                                                (*item_wrappers)[i].item_data->set_pcvr2(scores.at(score_index));
                                                if (scores.at(score_index) <= epsilon) {
                                                    infer_pair._zero_pcvr2++;
                                                }
                                                infer_pair._pcvr2_scores += scores.at(score_index);
                                                infer_pair._predict_pcvr2_success_cnt++;
                                                cvr_success_score = true;
                                            }
                                            infer_pair._predict_pcvr2_cnt++;
                                        } else {
                                            infer_pair._model_no_optput++;
                                        }
                                    }

                                    if (cvr_success_score) {
                                        PredictService::update_score_status(index, batch_size, *item_wrappers, context, PREDICT_SCORE_UNKOWN,
                                                            PREDICT_SCORE_SCUCESS, PREDICT_SCORE_UNKOWN);
                                    }
                                }
                            } else if (predict_type == ExperimentModelType::LTV) {
                                 bool ltv_success_score = false;

                                int32_t ltv1_target = item_info->ltv1target();
                                if(ltv1_target != 0) {
                                    auto it = output_name_output_tensor_map.find(ltv1_target);
                                    if (it != output_name_output_tensor_map.end()) {
                                        const auto &scores = it->second.values().float_val();
                                        if (scores.size() > score_index) {
                                            (*item_wrappers)[i].item_data->set_pltv1(scores.at(score_index));
                                            if (scores.at(score_index) <= epsilon) {
                                                infer_pair._zero_ltv1++;
                                            }
                                            infer_pair._ltv1_scores += scores.at(score_index);
                                            infer_pair._predict_ltv1_success_cnt++;
                                            ltv_success_score = true;
                                
                                        }
                                        infer_pair._predict_ltv1_cnt++;
                                    } else {
                                        infer_pair._model_no_optput++;
                                    }
                                }


                                int32_t ltv2_target = item_info->ltv2target();
                                if(ltv2_target != 0) {
                                    auto it = output_name_output_tensor_map.find(ltv2_target);
                                    if (it != output_name_output_tensor_map.end()) {
                                        const auto &scores = it->second.values().float_val();
                                        if (scores.size() > score_index) {
                                            (*item_wrappers)[i].item_data->set_pltv2(scores.at(score_index));
                                            if (scores.at(score_index) <= epsilon) {
                                                infer_pair._zero_ltv2++;
                                            }
                                            infer_pair._ltv2_scores += scores.at(score_index);
                                            infer_pair._predict_ltv2_success_cnt++;
                                            ltv_success_score = true;
                                
                                        }
                                        infer_pair._predict_ltv2_cnt++;
                                    } else {
                                        infer_pair._model_no_optput++;
                                    }
                                }

                                if (ltv_success_score) {
                                        PredictService::update_score_status(index, batch_size, *item_wrappers, context, PREDICT_SCORE_UNKOWN,
                                                            PREDICT_SCORE_UNKOWN, PREDICT_SCORE_SCUCESS);
                                }

                            }

                            score_index++;
                        }
                        MonitorMgr::percent_report_model(experiment_model_info->_model_info->_model_name,
                                                        context->GetUploadSlotName(),
                                                        std::to_string(context->get_algo_scene_id()), 0, "predict_io",
                                                        cntl.latency_us() - (model_predict_response.cost() * 1000));
                        MonitorMgr::percent_report_model(experiment_model_info->_model_info->_model_name,
                                                        context->GetUploadSlotName(),
                                                        std::to_string(context->get_algo_scene_id()), 0, "model_time",
                                                        (model_predict_response.cost() * 1000));
                        //在stage上单独上报耗时
                        MonitorMgr::percent_report_stage(std::to_string(context->get_route()),
                                                        std::to_string(context->get_algo_scene_id()), policy, node->get_name(),
                                                        context->GetUploadSlotName(), 0, "stage_predict_io",
                                                        cntl.latency_us() - (model_predict_response.cost() * 1000));
                        MonitorMgr::percent_report_stage(std::to_string(context->get_route()),
                                                        std::to_string(context->get_algo_scene_id()), policy, node->get_name(),
                                                        context->GetUploadSlotName(), 0, "stage_model_time",
                                                        (model_predict_response.cost() * 1000));
                        break;
                    }
                }
                if (ServerConfig::_debug_bvar_monitor_enable) {
                    debug::monitor::MonitorPercentile("prcoess_infer_rsp", butil::gettimeofday_us() - prcoess_infer_rsp);
                }
            }

            if (c_adapter::is_split_finish(node, context)) {
                HILOG_APP(INFO) << "model: " << experiment_model_info->_model_info->_model_name << "request end.";
                if (base_service_ptr != nullptr) {
                    BizLatency *lat = base_service_ptr->get_node_stat(context)->get_lat();
                    lat->_rsp_end_tm = gettimeofday_us();
                    if (ServerConfig::_debug_bvar_monitor_enable) {
                        debug::monitor::MonitorPercentile("predict_service_cost", butil::gettimeofday_us() - lat->_req_begin_tm);
                    }
                }
                node->run_output_nodes_if_ready(context);
            }
            delete this;
        }
        void report() {
            if (ServerConfig::_debug_bvar_monitor_enable) {
                debug::monitor::MonitorPercentile("batch_infer", butil::gettimeofday_us() - make_infer_request_start);
            }
        }
        virtual ~SimpleCallBack() {
            report();
        }
    };

}// namespace Core