// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.


#include <brpc/server_id.h>
#include <butil/macros.h>
#include <butil/fast_rand.h>
#include <brpc/socket.h>
#include <butil/strings/string_piece.h>
#include <memory>
#include <random>
#include <string>
#include <unordered_map>
#include <vector>
#include "customize_loadbalancer.h"


namespace Core {
    DECLARE_string(az_info);
}

namespace brpc {
namespace policy {

const uint32_t prime_offset[] = {
#include "offset_inl.list"
};

inline uint32_t GenRandomStride() {
    return prime_offset[butil::fast_rand_less_than(ARRAY_SIZE(prime_offset))];
}

bool CustomizeLoadBalancer::Add(Servers& bg, const ServerId& id) {
    if (bg.server_list.capacity() < 128) {
        bg.server_list.reserve(128);
    }
    std::map<ServerId, size_t>::iterator it = bg.server_map.find(id);
    if (it != bg.server_map.end()) {
        return false;
    }
    bg.server_map[id] = bg.server_list.size();
    bg.server_list.push_back(id);
    return true;
}

bool CustomizeLoadBalancer::Remove(Servers& bg, const ServerId& id) {
    std::map<ServerId, size_t>::iterator it = bg.server_map.find(id);
    if (it != bg.server_map.end()) {
        const size_t index = it->second;
        bg.server_list[index] = bg.server_list.back();
        bg.server_map[bg.server_list[index]] = index;
        bg.server_list.pop_back();
        bg.server_map.erase(it);
        return true;
    }
    return false;
}

size_t CustomizeLoadBalancer::BatchAdd(
    Servers& bg, const std::vector<ServerId>& servers) {
    size_t count = 0;
    for (size_t i = 0; i < servers.size(); ++i) {
        count += !!Add(bg, servers[i]);
    }
    return count;
}

size_t CustomizeLoadBalancer::BatchRemove(
    Servers& bg, const std::vector<ServerId>& servers) {
    size_t count = 0;
    for (size_t i = 0; i < servers.size(); ++i) {
        count += !!Remove(bg, servers[i]);
    }
    return count;
}

bool CustomizeLoadBalancer::AddServer(const ServerId& id) {
    auto iter = _az_db_servers.find(id.tag);
    if(iter != _az_db_servers.end()) {
        bool res =  iter->second.Modify(Add, id);
        //if not same az ,set to others 
        if(id.tag != Core::FLAGS_az_info) {
            res &= _az_db_servers[OTHERS_STR].Modify(Add,id);
        }
        return res;
    } else {
        return _az_db_servers[OTHERS_STR].Modify(Add,id);
    }
    
}

bool CustomizeLoadBalancer::RemoveServer(const ServerId& id) {
    auto iter = _az_db_servers.find(id.tag);
    if(iter != _az_db_servers.end()) {
        bool res =  iter->second.Modify(Remove, id);
        if (id.tag != Core::FLAGS_az_info) {
            res &= _az_db_servers[OTHERS_STR].Modify(Remove,id);
        }
        return res;
    } else {
        return _az_db_servers[OTHERS_STR].Modify(Remove,id);
    }
}

size_t CustomizeLoadBalancer::AddServersInBatch(
    const std::vector<ServerId>& servers) {
    std::unordered_map<std::string, std::vector<ServerId>> servers_map;
    for(auto server: servers) {
        if(server.tag != Core::FLAGS_az_info) {
            servers_map[OTHERS_STR].push_back(server);
        } 
        servers_map[server.tag].push_back(server);
        
    }
    size_t n = 0;
    size_t other = 0;
    for(auto server: servers_map){
        size_t res =_az_db_servers[server.first].Modify(BatchAdd, server.second);
        n += res;
        if(server.first == OTHERS_STR) {
            other = res;
        }
    }

    LOG_IF(ERROR, n-other != servers.size())
        << "Fail to AddServersInBatch, expected " << servers.size()
        << " actually " << n-other;
    return n-other;
}

size_t CustomizeLoadBalancer::RemoveServersInBatch(
    const std::vector<ServerId>& servers) {
    
    std::unordered_map<std::string, std::vector<ServerId>> servers_map;
    for(auto server: servers) {
        if(server.tag != Core::FLAGS_az_info) {
            servers_map[OTHERS_STR].push_back(server);
        } 
        servers_map[server.tag].push_back(server);
    }
    size_t n = 0;
    size_t other = 0;
    for(auto server: servers_map){

        size_t res = _az_db_servers[server.first].Modify(BatchRemove, server.second);
        n += res;
        if(server.first == OTHERS_STR) {
            other = res;
        }
    }
    
    //condition should be adjusted
    LOG_IF(ERROR,  n-other != servers.size())
        << "Fail to RemoveServersInBatch, expected " << servers.size()
        << " actually " << (n-other);
    return n-other;
}

int CustomizeLoadBalancer::SelectServer(const SelectIn& in, SelectOut* out) {
    if(!_is_step_az) { //access node from same az 
        if(SelectServerFromAssignAZ(Core::FLAGS_az_info, in,out) != 0) {
            return SelectServerFromAssignAZ(OTHERS_STR, in, out);
        }
        return 0;
    } else { //access node with ratio from assigned az 
        static std::random_device rd;
        static std::mt19937 gen(rd());
        static std::uniform_real_distribution<> dis(0.0, 100);

        double rand_val = dis(gen);
        double acc = 0.0; 

        for(const auto &ratio: _az_ratio) {
            acc += ratio.second;
            if(rand_val < acc) {
                return SelectServerFromAssignAZ(ratio.first, in, out);
            }
        }

    }
    
    return 0;
}

int CustomizeLoadBalancer::SelectServerFromAssignAZ(const std::string az_str, const SelectIn& in, SelectOut* out) {

    auto iter = _az_db_servers.find(az_str);
    if(iter == _az_db_servers.end()) {
        return ENODATA;
    }

    butil::DoublyBufferedData<Servers, TLS>::ScopedPtr s;
    if (iter->second.Read(&s) != 0) {
        return ENOMEM;
    }
    const size_t n = s->server_list.size();
    if (n == 0) {
        return ENODATA;
    }
    if (_cluster_recover_policy && _cluster_recover_policy->StopRecoverIfNecessary()) {
        if (_cluster_recover_policy->DoReject(s->server_list)) {
            return EREJECT;
        }
    }
    TLS tls = s.tls();
    if (tls.stride == 0) {
        tls.stride = GenRandomStride();
        // use random at first time, for the case of
        // use rr lb every time in new thread
        tls.offset = butil::fast_rand_less_than(n);
    }

    for (size_t i = 0; i < n; ++i) {
        tls.offset = (tls.offset + tls.stride) % n;
        const SocketId id = s->server_list[tls.offset].id;
        if (((i + 1) == n  // always take last chance
             || !ExcludedServers::IsExcluded(in.excluded, id))
            && Socket::Address(id, out->ptr) == 0
            && (*out->ptr)->IsAvailable()) {
            s.tls() = tls;
            return 0;
        }
    }
    if (_cluster_recover_policy) {
        _cluster_recover_policy->StartRecover();
    }
    s.tls() = tls;
    return EHOSTDOWN;

}

CustomizeLoadBalancer* CustomizeLoadBalancer::New(
    const butil::StringPiece& params) const {
    CustomizeLoadBalancer* lb = new (std::nothrow) CustomizeLoadBalancer;
    if (lb && !lb->SetParameters(params)) {
        delete lb;
        lb = NULL;
    }
    
    lb->parseStepParams(params);
    return lb;
}

void CustomizeLoadBalancer::Destroy() {
    delete this;
}

void CustomizeLoadBalancer::Describe(
    std::ostream &os, const DescribeOptions& options) {
    if (!options.verbose) {
        os << "cb";
        return;
    }
    os << "CustomizeLoadbalancer{";
    butil::DoublyBufferedData<Servers, TLS>::ScopedPtr s;
    //todo: not understand
    if (_az_db_servers[Core::FLAGS_az_info].Read(&s) != 0) {
        os << "fail to read _db_servers";
    } else {
        os << "n=" << s->server_list.size() << ':';
        for (size_t i = 0; i < s->server_list.size(); ++i) {
            os << ' ' << s->server_list[i];
        }
    }
    os << '}';
}

bool CustomizeLoadBalancer::SetParameters(const butil::StringPiece& params) {
    //set not working
    const butil::StringPiece empty = "";
    return GetRecoverPolicyByParams(empty, &_cluster_recover_policy);
}

void CustomizeLoadBalancer::parseStepParams(const butil::StringPiece& params) {
     //init same az nodes db and others nodes db
    _az_db_servers.emplace(
        std::piecewise_construct,
        std::forward_as_tuple(Core::FLAGS_az_info),
        std::forward_as_tuple());
    _az_db_servers.emplace(
        std::piecewise_construct,
        std::forward_as_tuple(OTHERS_STR),
        std::forward_as_tuple());

    if(params.empty()) {
        return;
    }
    std::vector<butil::StringPiece> results;
    SplitByDelimiter(params, ',',  results);
    int32_t total_other_az_ratio = 0;
    for(auto part: results){
        std::vector<butil::StringPiece> single;
        SplitByDelimiter(part, ':', single);
        if(single.size() < 3) {
            continue;
        }
        if( Core::FLAGS_az_info != single[0]) {
            continue;
        }
        // init once to one az, like: az6:az7:50,az6:az7:60
        // _az_db_servers.emplace(single[1].as_string(), butil::DoublyBufferedData<Servers, TLS>());
        _az_db_servers.emplace(
            std::piecewise_construct,
            std::forward_as_tuple(single[1].as_string()),
            std::forward_as_tuple());

        int32_t ratio = 0;
        try {
            ratio = std::stoi(single[2].as_string());
        }catch (...){
            std::cout<< "step az ratio not string number" << std::endl;
        }
        total_other_az_ratio+=ratio;
        _az_ratio.emplace(single[1].as_string(), ratio);
    }

    if(total_other_az_ratio > 100 ) {
        _az_ratio.emplace(Core::FLAGS_az_info, 0);
    } else {
        _az_ratio.emplace(Core::FLAGS_az_info, 100 - total_other_az_ratio);
    }
    
    //if step params parse successfull \ ratio size > 1 \ total_other_az_ratio<=100 , then step_az is on
    if(_az_db_servers.size() > 2 && _az_ratio.size() > 1 && total_other_az_ratio <= 100) {
        _is_step_az = true;
    }
}

void CustomizeLoadBalancer::SplitByDelimiter(const butil::StringPiece& input, char delim,std::vector<butil::StringPiece>& result) {
    size_t start = 0;
    while (start < input.size()) {
        size_t pos = input.find(delim, start);
        if (pos == butil::StringPiece::npos) {
            result.emplace_back(input.data() + start, input.size() - start);
            break;
        }
        result.emplace_back(input.data() + start, pos - start);
        start = pos + 1;
    }
}

}  // namespace policy
} // namespace brpc
