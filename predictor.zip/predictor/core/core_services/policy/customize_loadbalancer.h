// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.


#ifndef BRPC_POLICY_CUSTOMIZE_LOAD_BALANCER_H
#define BRPC_POLICY_CUSTOMIZE_LOAD_BALANCER_H

#include <brpc/policy/round_robin_load_balancer.h>
#include <cstdint>
#include <unordered_map>
#include <vector>                                      // std::vector
#include <map>                                         // std::map
#include <butil/containers/doubly_buffered_data.h>
#include <brpc/load_balancer.h>
#include <brpc/cluster_recover_policy.h>

namespace brpc {
namespace policy {

/**
 *
 * @brief Contains a LoadBalancer selects server with same az evenly as default, Otherwise select other az pod evenly
 * . Selected numbers of servers(added at the same time) are very close.
 * if loadbalancer config assgin ratio to access assgined az, then select nodes from assigned az evenly
 * 
 */
class CustomizeLoadBalancer : public LoadBalancer {
public:
    bool AddServer(const ServerId& id);
    bool RemoveServer(const ServerId& id);
    size_t AddServersInBatch(const std::vector<ServerId>& servers);
    size_t RemoveServersInBatch(const std::vector<ServerId>& servers);
    int SelectServer(const SelectIn& in, SelectOut* out);
    CustomizeLoadBalancer* New(const butil::StringPiece&) const;
    void Destroy();
    void Describe(std::ostream&, const DescribeOptions& options);

private:
    struct Servers {
        std::vector<ServerId> server_list;
        std::map<ServerId, size_t> server_map;
    };
    struct TLS {
        TLS() : stride(0), offset(0) { }
        uint32_t stride;
        uint32_t offset;
    };
    const std::string OTHERS_STR = "others";
    bool SetParameters(const butil::StringPiece& params);
    static bool Add(Servers& bg, const ServerId& id);
    static bool Remove(Servers& bg, const ServerId& id);
    static size_t BatchAdd(Servers& bg, const std::vector<ServerId>& servers);
    static size_t BatchRemove(Servers& bg, const std::vector<ServerId>& servers);
    int SelectServerFromAssignAZ(const std::string az_str, const SelectIn& in, SelectOut* out);   //select nodes from assign az

    std::unordered_map<std::string, butil::DoublyBufferedData<Servers, TLS>> _az_db_servers; //key->value: az->nodes
    std::unordered_map<std::string, int32_t> _az_ratio;   //key->value: az->分流比例
    std::shared_ptr<ClusterRecoverPolicy> _cluster_recover_policy;
    void parseStepParams(const butil::StringPiece& params);
    void SplitByDelimiter(const butil::StringPiece& input, char delim,std::vector<butil::StringPiece>& result);
    bool _is_step_az = false;
};

}  // namespace policy
} // namespace brpc


#endif  // BRPC_POLICY_ROUND_ROBIN_LOAD_BALANCER_H
