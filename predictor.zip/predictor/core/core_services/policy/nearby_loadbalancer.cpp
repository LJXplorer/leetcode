// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.


#include <brpc/server_id.h>
#include <butil/macros.h>
#include <butil/fast_rand.h>
#include <brpc/socket.h>
#include <vector>
#include "nearby_loadbalancer.h"


namespace Core {
    DECLARE_string(az_info);
}

namespace brpc {
namespace policy {

const uint32_t prime_offset[] = {
#include "offset_inl.list"
};

inline uint32_t GenRandomStride() {
    return prime_offset[butil::fast_rand_less_than(ARRAY_SIZE(prime_offset))];
}

bool NearbyLoadBalancer::Add(Servers& bg, const ServerId& id) {
    if (bg.server_list.capacity() < 128) {
        bg.server_list.reserve(128);
    }
    std::map<ServerId, size_t>::iterator it = bg.server_map.find(id);
    if (it != bg.server_map.end()) {
        return false;
    }
    bg.server_map[id] = bg.server_list.size();
    bg.server_list.push_back(id);
    return true;
}

bool NearbyLoadBalancer::Remove(Servers& bg, const ServerId& id) {
    std::map<ServerId, size_t>::iterator it = bg.server_map.find(id);
    if (it != bg.server_map.end()) {
        const size_t index = it->second;
        bg.server_list[index] = bg.server_list.back();
        bg.server_map[bg.server_list[index]] = index;
        bg.server_list.pop_back();
        bg.server_map.erase(it);
        return true;
    }
    return false;
}

size_t NearbyLoadBalancer::BatchAdd(
    Servers& bg, const std::vector<ServerId>& servers) {
    size_t count = 0;
    for (size_t i = 0; i < servers.size(); ++i) {
        count += !!Add(bg, servers[i]);
    }
    return count;
}

size_t NearbyLoadBalancer::BatchRemove(
    Servers& bg, const std::vector<ServerId>& servers) {
    size_t count = 0;
    for (size_t i = 0; i < servers.size(); ++i) {
        count += !!Remove(bg, servers[i]);
    }
    return count;
}

bool NearbyLoadBalancer::AddServer(const ServerId& id) {
    // std::cout<< "[ NearbyLoadBalancer ] add server to nb ,pod ip: "<< id.id << "campus: " << id.tag << "local az: "<< Core::FLAGS_az_info <<std::endl;
    if (id.tag == Core::FLAGS_az_info) {
        // std::cout<<"[ NearbyLoadBalancer ] add to nearby"<<std::endl;
        return _db_servers_nearby.Modify(Add, id);
    } else {
        // std::cout<<"[ NearbyLoadBalancer ] add to others"<<std::endl;
        return _db_servers_others.Modify(Add, id);
    }
    
}

bool NearbyLoadBalancer::RemoveServer(const ServerId& id) {
    // std::cout<< "[ NearbyLoadBalancer ] remove server to nb ,pod ip: "<< id.id << "campus: " << id.tag << "local az: "<< Core::FLAGS_az_info <<std::endl;
    if (id.tag == Core::FLAGS_az_info) {
        // std::cout<<"[ NearbyLoadBalancer ] remove to nearby"<<std::endl;
        return _db_servers_nearby.Modify(Remove, id);
    } else {
        // std::cout<<"[ NearbyLoadBalancer ] remove to others"<<std::endl;
        return _db_servers_others.Modify(Remove, id);
    }
}

size_t NearbyLoadBalancer::AddServersInBatch(
    const std::vector<ServerId>& servers) {

    // std::cout<< "[ NearbyLoadBalancer ] add server batch to nb ,server size: "<< servers.size() 
    //             <<" az: " << Core::FLAGS_az_info<<std::endl;
   
    std::vector<ServerId> nearby_servers;
    std::vector<ServerId> others_servers;
    for(auto server: servers) {
        if(server.tag == Core::FLAGS_az_info) {
            // std::cout<< "[ NearbyLoadBalancer ] push to nearby_servers, addr: "<< server.id <<
            // " tag: "<< server.tag <<std::endl;
            nearby_servers.push_back(server);
        } else {
            // std::cout<< "[ NearbyLoadBalancer ] push to others_servers, addr: "<< server.id <<std::endl;
            others_servers.push_back(server);
        }
    }
    const size_t n = _db_servers_nearby.Modify(BatchAdd, nearby_servers);
    const size_t others_n = _db_servers_others.Modify(BatchAdd, others_servers);
    LOG_IF(ERROR, (n+others_n) != servers.size())
        << "Fail to AddServersInBatch, expected " << servers.size()
        << " actually " << (n+others_n);
    return n+others_n;
}

size_t NearbyLoadBalancer::RemoveServersInBatch(
    const std::vector<ServerId>& servers) {
    
    // std::cout<< "[ NearbyLoadBalancer ] remove server batch to nb ,server size: "<< servers.size() <<std::endl;
   
    std::vector<ServerId> nearby_servers;
    std::vector<ServerId> others_servers;
    for(auto server: servers) {
        if(server.tag == Core::FLAGS_az_info) {
            // std::cout<< "[ NearbyLoadBalancer ] push to nearby_servers, addr: "<< server.id <<std::endl;
            nearby_servers.push_back(server);
        } else {
            // std::cout<< "[ NearbyLoadBalancer ] push to others_servers, addr: "<< server.id <<std::endl;
            others_servers.push_back(server);
        }
    }
    const size_t n = _db_servers_nearby.Modify(BatchRemove, nearby_servers);
    
    const size_t others_n = _db_servers_others.Modify(BatchRemove, others_servers);
    //condition should be adjusted
    LOG_IF(ERROR,  (n+others_n) != servers.size())
        << "Fail to RemoveServersInBatch, expected " << servers.size()
        << " actually " << (n+others_n);
    return n+others_n;
}

int NearbyLoadBalancer::SelectServer(const SelectIn& in, SelectOut* out) {
    
    if(SelectServerFromNearBy(in,out) != 0) {
        // std::cout << "SelectServerFromNearBy" << std::endl;
        return SelectServerFromOthers(in, out);
    }
    return 0;
}

int NearbyLoadBalancer::SelectServerFromNearBy(const SelectIn& in, SelectOut* out) {
    butil::DoublyBufferedData<Servers, TLS>::ScopedPtr s;
    if (_db_servers_nearby.Read(&s) != 0) {
        return ENOMEM;
    }
    const size_t n = s->server_list.size();
    if (n == 0) {
        return ENODATA;
    }
    if (_cluster_recover_policy && _cluster_recover_policy->StopRecoverIfNecessary()) {
        if (_cluster_recover_policy->DoReject(s->server_list)) {
            return EREJECT;
        }
    }
    TLS tls = s.tls();
    if (tls.stride == 0) {
        tls.stride = GenRandomStride();
        // use random at first time, for the case of
        // use rr lb every time in new thread
        tls.offset = butil::fast_rand_less_than(n);
    }

    for (size_t i = 0; i < n; ++i) {
        tls.offset = (tls.offset + tls.stride) % n;
        const SocketId id = s->server_list[tls.offset].id;
        if (((i + 1) == n  // always take last chance
             || !ExcludedServers::IsExcluded(in.excluded, id))
            && Socket::Address(id, out->ptr) == 0
            && (*out->ptr)->IsAvailable()) {
            s.tls() = tls;
            return 0;
        }
    }
    if (_cluster_recover_policy) {
        _cluster_recover_policy->StartRecover();
    }
    s.tls() = tls;
    return EHOSTDOWN;
}

int NearbyLoadBalancer::SelectServerFromOthers(const SelectIn& in, SelectOut* out) {
    butil::DoublyBufferedData<Servers, TLS>::ScopedPtr s;
    // std::cout << "SelectServerFromOthers" << std::endl;
    if (_db_servers_others.Read(&s) != 0) {
        // std::cout << "SelectServerFromOthers ENOMEM" << std::endl;
        return ENOMEM;
    }
    const size_t n = s->server_list.size();
    if (n == 0) {
        return ENODATA;
    }
    if (_cluster_recover_policy && _cluster_recover_policy->StopRecoverIfNecessary()) {
        if (_cluster_recover_policy->DoReject(s->server_list)) {
            return EREJECT;
        }
    }
    TLS tls = s.tls();
    if (tls.stride == 0) {
        tls.stride = GenRandomStride();
        // use random at first time, for the case of
        // use rr lb every time in new thread
        tls.offset = butil::fast_rand_less_than(n);
    }

    for (size_t i = 0; i < n; ++i) {
        tls.offset = (tls.offset + tls.stride) % n;
        const SocketId id = s->server_list[tls.offset].id;
        if (((i + 1) == n  // always take last chance
             || !ExcludedServers::IsExcluded(in.excluded, id))
            && Socket::Address(id, out->ptr) == 0
            && (*out->ptr)->IsAvailable()) {
            s.tls() = tls;
            return 0;
        }
    }
    if (_cluster_recover_policy) {
        _cluster_recover_policy->StartRecover();
    }
    s.tls() = tls;
    return EHOSTDOWN;
}

NearbyLoadBalancer* NearbyLoadBalancer::New(
    const butil::StringPiece& params) const {
    NearbyLoadBalancer* lb = new (std::nothrow) NearbyLoadBalancer;
    if (lb && !lb->SetParameters(params)) {
        delete lb;
        lb = NULL;
    }
    return lb;
}

void NearbyLoadBalancer::Destroy() {
    delete this;
}

void NearbyLoadBalancer::Describe(
    std::ostream &os, const DescribeOptions& options) {
    if (!options.verbose) {
        os << "nb";
        return;
    }
    os << "NearbyLoadbalancer{";
    butil::DoublyBufferedData<Servers, TLS>::ScopedPtr s;
    if (_db_servers_nearby.Read(&s) != 0) {
        os << "fail to read _db_servers";
    } else {
        os << "n=" << s->server_list.size() << ':';
        for (size_t i = 0; i < s->server_list.size(); ++i) {
            os << ' ' << s->server_list[i];
        }
    }
    os << '}';
}

bool NearbyLoadBalancer::SetParameters(const butil::StringPiece& params) {
    return GetRecoverPolicyByParams(params, &_cluster_recover_policy);
}

}  // namespace policy
} // namespace brpc
