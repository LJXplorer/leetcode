#include "offline_item_emb_dict_loader.h"
#include "prerank/prerank_embedding.pb.h"
#include "core/core_services/prerank/embedding_cache/feature_cache.h"
#include "core/core_server/server_config/server_config.h"
#include "common/comm/file_scanner.h"
#include <dirent.h>
#include <fcntl.h>
#include <log_helper.h>
#include <nlohmann/json.hpp>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fstream>
#include <sstream>

namespace Core {
namespace prerank {

namespace {
    // 解析 _TASK_INFO 第二行，取 version 字段
    static int32_t ReadTaskInfoVersion(const std::string &dir_path, std::string &model_name_out, int32_t &version_out, int32_t &item_count_out) {
        std::string file_path = dir_path + "/_TASK_INFO";
        int fd = open(file_path.c_str(), O_RDONLY);
        if (fd == -1) {
            HILOG_APP(WARNING) << "_TASK_INFO not found: " << file_path;
            return -1;
        }
        struct stat sb{};
        if (fstat(fd, &sb) == -1) {
            close(fd);
            return -1;
        }
        int32_t length = static_cast<int32_t>(sb.st_size);
        const char *p_buf = static_cast<const char *>(mmap(NULL, length, PROT_READ, MAP_PRIVATE, fd, 0));
        if (p_buf == nullptr || p_buf == MAP_FAILED) {
            close(fd);
            return -1;
        }
        const char *start = p_buf;
        const char *end = p_buf + length;
        int line_count = 0;
        const char *line_start = nullptr;
        const char *line_end = nullptr;
        for (const char *it = start; it < end; ++it) {
            if (*it == '\n') {
                ++line_count;
                if (line_count == 1) {
                    line_start = it + 1;
                } else if (line_count == 2) {
                    line_end = it;
                    break;
                }
            }
        }
        std::string second_line;
        if (line_start && line_end && line_start < line_end) {
            second_line.assign(line_start, line_end);
        }
        munmap((void *) p_buf, length);
        close(fd);
        if (second_line.empty()) return -1;
        // 格式: {model_name},{model_version},{item_count}
        std::istringstream iss(second_line);
        std::string tok;
        std::vector<std::string> parts;
        while (std::getline(iss, tok, ',')) parts.emplace_back(tok);
        if (parts.size() < 3) return -1;
        model_name_out = parts[0];
        try {
            version_out = std::stoi(parts[1]);
            item_count_out = std::stoi(parts[2]);
        } catch (...) {
            return -1;
        }
        return 0;
    }

    // 读取 itemEmb.txt 每行的 protobuf 二进制，填充到 FeatureCache 的备份缓冲
    static int LoadItemEmbFile(const std::string &dir_path, const std::string &model_name, int32_t model_version) {
        std::string path = dir_path + "/itemEmb.txt";
        std::ifstream in(path, std::ios::in);
        if (!in.is_open()) {
            HILOG_APP(ERROR) << "Failed to open itemEmb.txt: " << path;
            return -1;
        }
        // 预分配写入对象
        Core::prerank::FeatureCache::get_instance().pre_allocate(model_name, model_version, false);

        std::string line;
        std::vector<int64_t> creative_ids;
        std::vector<float> vec_buffer;
        const int kBatch = 4096;
        int parsed = 0;

        while (std::getline(in, line)) {
            if (line.empty()) continue;
            phx::ItemEmbeddingInfo item;
            if (!item.ParseFromString(line)) {
                HILOG_APP(WARNING) << "ParseFromString failed for one embedding row";
                continue;
            }
            creative_ids.push_back(item.cid());
            for (int i = 0; i < item.float_val_size(); ++i) {
                vec_buffer.push_back(item.float_val(i));
            }
            if (static_cast<int>(creative_ids.size()) >= kBatch) {
                int32_t dim = item.float_val_size();
                Core::prerank::FeatureCache::get_instance().batch_insert_feature(
                        model_name, model_version, creative_ids, vec_buffer.data(), creative_ids.size(), dim, true);
                creative_ids.clear();
                vec_buffer.clear();
            }
            ++parsed;
        }
        if (!creative_ids.empty()) {
            int32_t dim = vec_buffer.empty() ? 0 : static_cast<int32_t>(vec_buffer.size() / creative_ids.size());
            if (dim > 0) {
                Core::prerank::FeatureCache::get_instance().batch_insert_feature(
                        model_name, model_version, creative_ids, vec_buffer.data(), creative_ids.size(), dim, true);
            }
        }
        HILOG_APP(INFO) << "Loaded itemEmb.txt rows: " << parsed << ", dir: " << dir_path;
        return 0;
    }
}

int LoadLatestEmbeddingFromGoose(const std::string &model_name_cfg, int32_t model_version_cfg) {
    HILOG_APP(ERROR) << "古娜拉黑暗之神：扫描SUCCESS并加载词典文件LoadLatestEmbeddingFromGoose";
    const auto &model_infos = Core::Info::ModelInfoManager::instance().get_model_infos();
    auto it = model_infos.find(model_name_cfg);
    if (it == model_infos.end() || !it->second) {
        HILOG_APP(ERROR) << "Model not found for embedding dict load: " << model_name_cfg;
        return -1;
    }
    const std::string &dict_root = it->second->_dict_name; // 如 /ad/ad_phx_predictor_dict/adinfo
    if (dict_root.empty()) {
        HILOG_APP(ERROR) << "Empty dict_root for model: " << model_name_cfg;
        return -1;
    }

    // 扫描 yyyyMMdd
    long dummy_version = -1;
    std::string latest_day;
    {
        common::FileScanner day_scanner(dict_root);
        if (!day_scanner.SafeScan(&dummy_version, &latest_day, -1)) {
            HILOG_APP(INFO) << "No day directory with SUCCESS under: " << dict_root;
            return -2;
        }
    }
    // 扫描 HHmm
    long minute_ver = -1;
    std::string latest_minute;
    {
        common::FileScanner minute_scanner(latest_day);
        if (!minute_scanner.SafeScan(&minute_ver, &latest_minute, -1)) {
            HILOG_APP(INFO) << "No minute directory with SUCCESS under: " << latest_day;
            return -2;
        }
    }
    // 在分钟目录下扫描，SUCCESS 作为完成信号
    long model_ver_found = -1;
    std::string model_ver_dir_abs;
    {
        common::FileScanner ver_scanner(latest_minute, "SUCCESS");
        if (!ver_scanner.SafeScan(&model_ver_found, &model_ver_dir_abs, -1)) {
            HILOG_APP(INFO) << "No model_version directory with SUCCESS under: " << latest_minute;
            return -2;
        }
    }

    // 读取 _TASK_INFO 校验 model_name 与 version
    std::string task_model_name;
    int32_t task_version = 0;
    int32_t task_item_cnt = 0;
    if (ReadTaskInfoVersion(model_ver_dir_abs, task_model_name, task_version, task_item_cnt) != 0) {
        HILOG_APP(WARNING) << "_TASK_INFO parse failed under: " << model_ver_dir_abs;
    }

    const std::string &model_name = !task_model_name.empty() ? task_model_name : model_name_cfg;
    int32_t model_version = task_version > 0 ? task_version : model_version_cfg;

    // 加载 itemEmb.txt
    if (LoadItemEmbFile(model_ver_dir_abs, model_name, model_version) != 0) {
        return -1;
    }

    // 切换buffer
    Core::prerank::FeatureCache::get_instance().commit_buffer(model_name, model_version, true, false);
    HILOG_APP(INFO) << "Committed FeatureCache for model: " << model_name << ", version: " << model_version
                    << ", path: " << model_ver_dir_abs;
    return 0;
}

} // namespace prerank
} // namespace Core