#include "offline_emb_done_service.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/predict/utils/model_version.h"
#include "offline_dict_warmup_notifier.h"
#include "core/utils/error.h"
#include "model_semaphore_manager.h"
#include <log_helper.h>

namespace Core {
    SERVICE_REGISTER(OfflineItemEmbeddingDoneService);
    int OfflineItemEmbeddingDoneService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int offline_success_split_num = ctx->get_prerank_context()->GetItemEmbSplitSuccessCount();
        size_t split_size = 0;
        // for (const auto &[_, fe_split]: ctx->get_prerank_context()->get_split_list()) {
        //     split_size = fe_split.size();
        // }

        // HILOG_APP(ERROR) << "offline item embedding end, dict_name = [" << ctx->get_prerank_context()->item_dict_name_
        //                  << "], item emb model name = [" << ctx->_offline_item_emb_model << "], version = ["
        //                  << ctx->_offline_item_emb_version << "]; split num = [" << split_size
        //                  << "]; split success num = [" << offline_success_split_num << "]; task reason = [" << ctx->get_prerank_context()->offline_item_emb_reason_ << "]";

        if (ServerConfig::_first_load_offline_item_emb) {
            ServerConfig::_offline_item_emb_cnt.fetch_sub(1);
        }

        auto sema = ModelSemaphoreManager::GetSemaphore();
        if (!sema) {
            HILOG_APP(ERROR) << "Failed to get semaphore in OfflineItemEmbeddingDoneService";
            return -1;
        }

        int available_before = sema->available();
        int running_tasks_before = ServerConfig::_max_models - available_before;

        HILOG_APP(ERROR) << "Before release: max_count=" << ServerConfig::_max_models
                        << ", available=" << available_before << ", running_tasks=" << running_tasks_before;

        sema->release();

        int available_after = sema->available();
        int running_tasks_after = ServerConfig::_max_models - available_after;

        HILOG_APP(ERROR) << "After release: max_count=" << ServerConfig::_max_models << ", available=" << available_after
                        << ", running_tasks=" << running_tasks_after;

        HILOG_APP(ERROR) << "offline item embedding done";

        HILOG_APP(ERROR) << "古娜拉黑暗之神：马上要触发词典预热了";
        
        // 触发词典预热
        if (ctx) {
            const std::string model_name = ctx->_offline_item_emb_model;
            const int32_t model_version = ctx->_offline_item_emb_version;
            (void)Core::prerank::NotifyDictWarmup(model_name, model_version);
        }
        return ERROR_SUCCESS;
    };

}// namespace Core