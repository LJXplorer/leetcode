#include "offline_item_embedding_service.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/core_context.h"
#include "core/core_context/monitor_context.h"
#include "core/core_services/base_service/service_info.h"
#include "core/core_services/predict/utils/model_version.h"
#include "core/core_services/predict/utils/ragged_tensor_util.h"
#include "core/core_services/prerank/embedding_cache/feature_cache.h"
#include "core/core_services/prerank/embedding_cache/feature_cache_writer.h"
#include "core/utils/error.h"
#include "hlframe/register.h"
#include "prerank/prerank_embedding.pb.h"
#include <brpc/controller.h>
#include <cstddef>
#include <debug_utils.h>
#include <fstream>
#include <glog/logging.h>
#include <log_helper.h>
#include <string>
#include <thread_pool.h>

namespace Core {
    SERVICE_REGISTER(OfflineItemEmbeddingService);

    void OfflineItemEmbeddingService::initialize_xml(ConfigXmlPtr xml) {
        xml->attr<std::string>("dest", dest_);
    }

    bool OfflineItemEmbeddingService::skip(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        auto fe_ctx = ctx->get_fe_context();
        if (ctx == nullptr || ctx->_prerank_context_ptr == nullptr ||
            ctx->_prerank_context_ptr->_offline_item_model_info == nullptr) {
            HILOG_APP(ERROR) << "OfflineItemEmbeddingService skip!!! ";
            return true;
        }
        HILOG_APP(INFO) << "get_predict_type: " << static_cast<int>(get_predict_type())
                        << " exist: " << fe_ctx->exist(get_predict_type());
        // return (get_predict_type() != ExperimentModelType::ITEM_EMBEDDING)
        //     || (fe_ctx->exist(get_predict_type()) == false)

        return false;
    }

    bool OfflineItemEmbeddingService::CheckIsEmbeddingShape(const ::proto::flow::TensorProto &shape) {
        return shape.shape().size() == 2;
    }

    void OfflineItemEmbeddingService::process_prediction(std::shared_ptr<CoreContext> &context, brpc::Channel *channel,
                                                         const ::proto::flow::PredictRequest *request,
                                                         ::proto::flow::PredictResponse *response,
                                                         std::shared_ptr<Info::ModelInfo> experiment_model_info,
                                                         int32_t index) {
        ::proto::flow::PredicterService_Stub stub(channel);
        brpc::Controller cntl;
        stub.Predict(&cntl, request, response, nullptr);
        if (cntl.Failed()) {
            HILOG_APP(ERROR) << "model:" << experiment_model_info->_model_name
                             << " Predict failed: " << cntl.ErrorText() << ",lat: " << cntl.latency_us();
            MonitorMgr::percent_report_model(experiment_model_info->_model_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), cntl.ErrorCode(),
                                             "predict_time", cntl.latency_us());

        } else {
            HILOG_APP(INFO) << "model:" << experiment_model_info->_model_name
                            << " Predict success, lat: " << cntl.latency_us();

            int32_t version = context->_offline_item_emb_version;

            auto &model_predict_responses = response->responses();

            if (model_predict_responses.empty()) {
                HILOG_APP(INFO) << "empty response: " << std::endl;
            }
            HILOG_APP(INFO) << "model_predict_responses size: " << model_predict_responses.size();
            for (const auto &model_predict_response: model_predict_responses) {
                HILOG_APP(INFO) << "tfserving model name: " << model_predict_response.model_name()
                                << "expri model name: " << experiment_model_info->_model_name << std::endl;
                // std::cout << "model_predict_response1: " << model_predict_response.DebugString()<< std::endl;
                if (model_predict_response.model_name() == experiment_model_info->_model_name) {

                    //HILOG_APP(INFO) << "model_predict_response: " << model_predict_response.DebugString();
                    //找到了使用的模型
                    auto &predict_output_tensors = model_predict_response.outputs();//(name,values)
                    //HILOG_APP(INFO) << "predict_output_tensors size: "<< predict_output_tensors.size();
                    for (const auto &output_tensor: predict_output_tensors) {
                        HILOG_APP(INFO) << "output_tensor.name(): " << output_tensor.name();
                        //拿到name的int值 循环模型信息的item 列表 （core_ctx里）
                        //遍历item列表 拿到item的convtype deepconvtype enhancedconvtype

                        //看name对应值在convtype deepconvtype enhancedconvtype中的哪一个
                        //如果是convtype，赋值cvr；deepconvtype赋值dcvr enhancedconvtype赋值ecvr
                        if (output_tensor.name() == "item_vec") {
                            std::vector<int64_t> creative_ids;
                            // for(auto& iter: context->get_prerank_context()->_offline_item_embedding_map) {
                            const std::vector<ItemWrapper> &item_vec =
                                    context->get_prerank_context()->_offline_item_embedding_map.at(index);
                            for (int i = 0; i < item_vec.size(); i++) {
                                creative_ids.push_back(item_vec[i].item->creativeid());
                            }
                            // }
                            HILOG_APP(INFO) << "item_vector";
                            auto &batch_item_vecs = output_tensor.values();
                            const float *vecs = batch_item_vecs.float_val().data();
                            const int batch_size = batch_item_vecs.shape(0);
                            const int single_vector_size = batch_item_vecs.shape(1);

                            if (creative_ids.size() == 0 || creative_ids.size() != batch_size) {
                                HILOG_APP(INFO)
                                        << "batch size not equal, request size = [" << creative_ids.size() << "]"
                                        << "batch size = [" << batch_size << "]; ";
                                return;
                            }

                            HILOG_APP(INFO) << "process_embeddings";
                            process_embeddings(context, experiment_model_info->_model_name, version, creative_ids, vecs,
                                               batch_size, single_vector_size);
                            MonitorMgr::percent_report_model(
                                    experiment_model_info->_model_name, context->GetUploadSlotName(),
                                    std::to_string(context->get_algo_scene_id()), 0, "predict_time", cntl.latency_us());
                            MonitorMgr::percent_report_model(
                                    experiment_model_info->_model_name, context->GetUploadSlotName(),
                                    std::to_string(context->get_algo_scene_id()), 0, "predict_io",
                                    cntl.latency_us() - (model_predict_response.cost() * 1000));
                            MonitorMgr::percent_report_model(experiment_model_info->_model_name,
                                                             context->GetUploadSlotName(),
                                                             std::to_string(context->get_algo_scene_id()), 0,
                                                             "model_time", (model_predict_response.cost() * 1000));
                            MonitorMgr::common_report_model(
                                    experiment_model_info->_model_name, context->GetUploadSlotName(),
                                    std::to_string(context->get_algo_scene_id()), "default", 0, "req_num", 1);

                            break;
                        }
                    }
                    break;
                }
            }
        }
    }
    int OfflineItemEmbeddingService::process_embeddings(std::shared_ptr<CoreContext> context,
                                                        const std::string &model_url, int64_t model_version,
                                                        const std::vector<int64_t> &creative_ids,
                                                        const float *embedding_result, int32_t batch_size,
                                                        int32_t single_vector_size) {
        HILOG_APP(INFO) << "dest_ = [" << dest_ << "]";
        HILOG_APP(INFO) << "process_embeddings model url: " << model_url;
        HILOG_APP(INFO) << "process_embeddings embedding_result: " << *embedding_result;
        HILOG_APP(INFO) << "process_embeddings batch_size: " << batch_size;
        HILOG_APP(INFO) << "process_embeddings single_vector_size: " << single_vector_size;

        // 构造ItemEmbeddingInfo列表
        std::vector<phx::ItemEmbeddingInfo> embedding_items;
        for (int i = 0; i < batch_size; i++) {
            phx::ItemEmbeddingInfo item;
            item.set_cid(creative_ids[i]);
            for (int j = 0; j < single_vector_size; j++) {
                item.add_float_val(embedding_result[i * single_vector_size + j]);
            }
            embedding_items.push_back(std::move(item));
        }

        EmbeddingBatch batch;
        batch.model_url = model_url;
        batch.model_version = model_version;
        batch.embedding_info = std::move(embedding_items);

        // 异步入队写入
        g_feature_cache_writer.enqueue_batch(batch);

        return 0;
    }
    void OfflineItemEmbeddingService::get_item_slot_data_types(const phx::ExtractorResponse *extractor_responses,
                                                               const size_t &slot_num,
                                                               std::vector<SlotDataType> &slot_data_type) {
        // 处理 item 特征
        for (int slot_index = 0; slot_index < slot_data_type.size(); ++slot_index) {
            // for (const auto &extractor_response: extractor_responses) {
            auto &item_features = extractor_responses->item_features();
            int64_t item_num = extractor_responses->item_cnt();

            for (int j = 0; j < item_num; ++j) {
                auto feature = item_features.at(j + item_num * slot_index);//(slot_i,item_j)处的Feature
                if (feature.signs().size() > 0) {
                    // 这个特征是 int
                    slot_data_type[slot_index] = SlotDataType::INT_64;
                    break;
                } else if (feature.weights().size() > 0) {
                    // 这个特征是 float
                    slot_data_type[slot_index] = SlotDataType::FLOAT;
                    break;
                } else if (feature.bytes_list().size() > 0) {
                    // 这个特征是 string
                    slot_data_type[slot_index] = SlotDataType::STRING;
                    break;
                } else {
                    // 这个特征为空 继续遍历下一个直到 j = item_num -1
                    continue;
                }
            }
            // 如果遍历完了发现 item_slot_data_types->value[slot_index] 不是 UNKNOWN 了，就可以跳出循环，不再处理下一个 extractor_response
            // if (slot_data_type[slot_index] != SlotDataType::UNKNOWN) {
            //     break;
            // }
            // }
            // 获取下一个 slot_index 的 DATA_TYPE
        }
    }

    int OfflineItemEmbeddingService::process(CoreContextPtr context) {
        BizLatency *lat = get_node_stat(context)->get_lat();
        auto prerank_context = context->get_prerank_context();

        // extractor_responses.push_back(fe_response.second);
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);
            protobuf::Arena arena;
            // std::cout<< "fe result size: " << extractor_responses.size() <<std::endl;

            if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
                // debug::file::WriteToFile(debug::printer::ToString(extractor_responses),
                //                          experimentModelTypeToString(predict_type) + "_" + model_info->_model_name +
                //                                  "_" + "extractor_responses.txt");
            }

            if (prerank_context->_offline_item_model_info == nullptr) {
                HILOG_APP(ERROR) << "_offline_item_model_info is nullptr";
                return false;
            }
            std::string model_name = prerank_context->_offline_item_model_info->_model_name;

            if (prerank_context->_offline_item_embedding_fe_response_map.size() < 1) {
                HILOG_APP(ERROR) << "model name: " << prerank_context->_offline_item_model_info->_model_name
                                 << ", extractor_responses.size() < 1";
                return false;
            }
            if (prerank_context->_offline_item_embedding_fe_response_map.at(0) == nullptr ||
                prerank_context->_offline_item_embedding_fe_response_map.at(0)->item_features().size() == 0 ||
                prerank_context->_offline_item_embedding_fe_response_map.at(0)->item_cnt() == 0) {
                HILOG_APP(ERROR) << "item_features.size() || item_num is 0";
                return false;
            }
            // 对extractor_responses进行检查
            bool run_error = false;
            for (const auto &extractor_response: prerank_context->_offline_item_embedding_fe_response_map) {
                if (extractor_response.second->item_features().size() % extractor_response.second->item_cnt() != 0) {
                    HILOG_APP(ERROR) << "something went wrong in FE";
                    run_error = true;
                    break;
                }
            }
            if (run_error) {
                HILOG_APP(ERROR) << "jump predict, model_name: " << model_name;
            }

            HILOG_APP(INFO) << "model_name: " << model_name << "item_embedding_fe_response_map size: "
                            << prerank_context->_offline_item_embedding_fe_response_map.size();

            int32_t version = context->_offline_item_emb_version;

            prerank::FeatureCache::get_instance().clear_double_buffer(model_name, version, context->_is_version_update);

            for (int index = 0; index < prerank_context->_offline_item_embedding_fe_response_map.size(); index++) {
                auto extractor_responses = prerank_context->_offline_item_embedding_fe_response_map.at(index);
                const size_t item_slot_num =
                        extractor_responses->item_features().size() / extractor_responses->item_cnt();

                std::vector<SlotDataType> item_slot_data_types(item_slot_num, SlotDataType::UNKNOWN);
                get_item_slot_data_types(extractor_responses, item_slot_num, item_slot_data_types);
                HILOG_APP(INFO) << "update_item_slot_data_types end, slot_data_types: " << item_slot_data_types.size()
                                << "\n"
                                << "slot type: " << debug::printer::ToString(item_slot_data_types);

                HILOG_APP(INFO) << "start merging item";
                std::vector<SlotInfo> item_splited_batches;
                parse_item_list_item_embedding(extractor_responses, item_slot_num, item_slot_data_types, context,
                                               model_name, item_splited_batches);
                HILOG_APP(INFO) << "end merging item, item_splited_batches size: " << item_splited_batches.size()
                                << "\n"
                                << "slot type: " << debug::printer::ToString(item_splited_batches);

                if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
                    debug::file::WriteToFile(debug::printer::ToString(item_splited_batches),
                                             "_" + model_name + "_" + "item_splited_batches.txt");
                }

                //构造分包的Predict Request
                auto predict_request = google::protobuf::Arena::CreateMessage<::proto::flow::PredictRequest>(&arena);
                ::proto::flow::ModelPredictRequest *model_request = predict_request->add_model_requests();

                model_request->set_model_name(prerank_context->_offline_item_model_info->_model_name);
                model_request->set_model_version(version);

                //处理 item特征
                // 对于每个分包请求 遍历其中的 item的slot_info
                for (const auto &item_slot_info: item_splited_batches) {
                    auto *item_input = model_request->add_inputs();
                    item_input->set_name(item_slot_info.slot_id);
                    item_input->set_type(1);// 0表示user 1表示item

                    //填充 item 特征到 inputs
                    switch (item_slot_info.get_data_type()) {
                        case SlotDataType::INT_64: {
                            ::proto::flow::RaggedTensorProto *rt(
                                    RaggedTensorUtil::FromValues(*item_slot_info.int_values_repeated));
                            item_input->set_allocated_values(rt);
                            break;
                        }
                        case SlotDataType::FLOAT: {
                            ::proto::flow::RaggedTensorProto *rt(
                                    RaggedTensorUtil::FromValues(*item_slot_info.float_values_repeated));
                            item_input->set_allocated_values(rt);
                            break;
                        }
                        case SlotDataType::STRING: {
                            ::proto::flow::RaggedTensorProto *rt(
                                    RaggedTensorUtil::FromValues(*item_slot_info.string_values_repeated));
                            item_input->set_allocated_values(rt);
                            break;
                        }
                        default: {
                            ::proto::flow::RaggedTensorProto *rt(
                                    RaggedTensorUtil::FromValues(std::vector<std::vector<int64_t>>()));
                            item_input->set_allocated_values(rt);
                            break;
                        }
                    }
                }

                //这里可以用分包同步或异步请求了
                brpc::Channel *channel = prerank_context->_offline_item_model_info->get_channel();

                // 写 PredictRequest 到文件 predict_type + model_name + i + predictRequest.txt
                if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
                    debug::pb::SavePbToFile(prerank_context->_offline_item_model_info->_model_name + "_" + "_" +
                                                    "PredictRequest.json",
                                            *predict_request);
                }

                ::proto::flow::PredicterService_Stub stub(channel);
                ::proto::flow::PredictResponse *predict_response =
                        google::protobuf::Arena::CreateMessage<::proto::flow::PredictResponse>(&arena);

                process_prediction(context, prerank_context->_offline_item_model_info->get_channel(), predict_request,
                                   predict_response, prerank_context->_offline_item_model_info, index);

                HILOG_APP(INFO) << "model: " << prerank_context->_offline_item_model_info->_model_name
                                << "request end.";

                HILOG_APP(INFO) << prerank_context->_offline_item_model_info->_model_name + "_" + "_PredictRequest: \n"
                                << debug::printer::ToString(*predict_request) << "_PredictResponse: \n"
                                << debug::printer::ToString(*predict_response);
                if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
                    debug::pb::SavePbToFile(prerank_context->_offline_item_model_info->_model_name + "_" + "_" +
                                                    "PredictResponse.json",
                                            *predict_response);
                }
            }

            prerank::FeatureCache::get_instance().commit_buffer(model_name, version, context->_is_version_update,
                                                                context->_is_first_rotate);

            MonitorMgr::common_report_model(
                    model_name, context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()),
                    "default", 0, "item_emb_num",
                    prerank::FeatureCache::get_instance().get_feature_vectors_size(model_name, version));
        }

        BizLatencyGaurd lat_guard(lat, LAT_STAGE_DESTROY);
        return 0;
    }

    void OfflineItemEmbeddingService::parse_item_list_item_embedding(
            const phx::ExtractorResponse *extractor_response, const size_t &item_slot_num,
            const std::vector<SlotDataType> &item_slot_data_types, CoreContextPtr &context,
            const std::string &model_name, std::vector<SlotInfo> &item_slot_list) {
        item_slot_list.resize(item_slot_num);//存储合包后的所有item特征
        // for (const auto &extractor_response: extractor_responses) {

        auto &item_features = extractor_response->item_features();
        int32_t item_fea_length = item_features.size();
        int32_t item_num = extractor_response->item_cnt();
        HILOG_APP(INFO) << "start parse item list , feature length: " << item_fea_length << "item_num: " << item_num;
        int32_t i = 0;
        for (int32_t index = 0; index < item_fea_length; ++index) {
            i = index / item_num;
            int32_t item_index = index % item_num;
            auto &feature = item_features.at(index);//(slot_i,item_j)处的Feature
            SlotDataType data_type = item_slot_data_types[i];
            switch (data_type) {
                case SlotDataType::INT_64: {
                    if (!item_slot_list[i].int_values_repeated) {
                        item_slot_list[i].int_values_repeated =
                                std::make_shared<std::vector<const google::protobuf::RepeatedField<int64_t> *>>(
                                        extractor_response->item_cnt());
                        item_slot_list[i].slot_data_type = SlotDataType::INT_64;
                        item_slot_list[i].slot_id = feature.slot_id();
                    }
                    item_slot_list[i].int_values_repeated->operator[](item_index) = &feature.signs();
                    break;
                }
                case SlotDataType::FLOAT: {
                    if (!item_slot_list[i].float_values_repeated) {
                        item_slot_list[i].float_values_repeated =
                                std::make_shared<std::vector<const google::protobuf::RepeatedField<float> *>>(
                                        extractor_response->item_cnt());
                        item_slot_list[i].slot_data_type = SlotDataType::FLOAT;
                        item_slot_list[i].slot_id = feature.slot_id();
                    }
                    item_slot_list[i].float_values_repeated->operator[](item_index) = &feature.weights();
                    break;
                }
                case SlotDataType::STRING: {
                    if (!item_slot_list[i].string_values_repeated) {
                        item_slot_list[i].string_values_repeated =
                                std::make_shared<std::vector<const google::protobuf::RepeatedPtrField<std::string> *>>(
                                        extractor_response->item_cnt());
                        item_slot_list[i].slot_data_type = SlotDataType::STRING;
                        item_slot_list[i].slot_id = feature.slot_id();
                    }
                    item_slot_list[i].string_values_repeated->operator[](item_index) = &feature.bytes_list();
                    break;
                }
                default: {
                    item_slot_list[i].slot_data_type = SlotDataType::UNKNOWN;
                    item_slot_list[i].slot_id = feature.slot_id();
                    break;
                }
            }
        }
        //对于同一个slot，应该可以异步
        // }//这里同步
        HILOG_APP(INFO) << "end merging item";

        // 写 item_slot_list 到文件 predict_type + model_name + item_slot_list.txt
        if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
            debug::file::WriteToFile(debug::printer::ToString(item_slot_list),
                                     experimentModelTypeToString(get_predict_type()) + "_" + model_name + "_" +
                                             "item_slot_list.txt");
        }
    }

    int OfflineItemEmbeddingService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int32_t ret = 0;
        try {
            ctx->gen_log_head();
            ret = process(ctx);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << "do service fail: " << ret << "," << e.what();
        }
        return ret;
    }

}// namespace Core
