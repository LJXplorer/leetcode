#include "offline_dict_warmup_notifier.h"
#include "core/core_server/server_config/server_config.h"
#include "common/comm/wrapper_time.h"
#include "common/hilog/log_helper.h"
#include <nlohmann/json.hpp>
#include <brpc/channel.h>
#include <brpc/controller.h>

namespace Core {
namespace prerank {
static std::string BuildCosPath(const std::string& model_name, int32_t model_version) {
    std::string date_str = get_current_date_yyyymmdd();
    std::string interval_str = get_current_30min_interval();
    std::string suffix = "/ai-modeldict-prod-1311258067/ad/ad_phx_predictor_dict/" +
        model_name + "/" + std::to_string(model_version) + "/" + date_str + "/" + interval_str + "/";
    return suffix;
}

int NotifyDictWarmup(const std::string& model_name, int32_t model_version) {
    if (ServerConfig::_dict_warmup_url.empty() || ServerConfig::_dict_warmup_uri.empty()) {
        HILOG_APP(WARNING) << "Dict warmup url/uri empty, skip notify";
        return 0;
    }

    HILOG_APP(ERROR) << "古娜拉黑暗之神：url: " << ServerConfig::_dict_warmup_url << ", uri: " << ServerConfig::_dict_warmup_uri;
    HILOG_APP(ERROR) << "古娜拉黑暗之神：model_name: " << model_name << ", model_version: " << model_version;

    // HTTP POST
    nlohmann::json body;
    body["cosPath"] = BuildCosPath(model_name, model_version);
    body["serviceCode"] = "ad-phx-predictor";

    try {
        brpc::Channel channel;
        brpc::ChannelOptions options;
        options.protocol = "http";
        options.connection_type = "pooled";
        if (channel.Init(ServerConfig::_dict_warmup_url.c_str(), &options) != 0) {
            HILOG_APP(ERROR) << "Warmup notify: init channel failed";
            return -1;
        }

        std::string json_body = body.dump();
        brpc::Controller cntl;
        cntl.http_request().uri() = ServerConfig::_dict_warmup_uri;
        cntl.http_request().set_method(brpc::HTTP_METHOD_POST);
        cntl.http_request().set_content_type("application/json; charset=utf-8");
        cntl.set_timeout_ms(2000);
        cntl.request_attachment().append(json_body);
        channel.CallMethod(NULL, &cntl, NULL, NULL, NULL);
        if (cntl.Failed()) {
            HILOG_APP(ERROR) << "Warmup notify failed, brpc error: " << cntl.ErrorText();
            return -1;
        }
        long status = cntl.http_response().status_code();
        if (status < 200 || status >= 300) {
            HILOG_APP(ERROR) << "Warmup notify failed, response code: " << status
                             << ", error: " << cntl.response_attachment().to_string();
            return -1;
        }
        HILOG_APP(INFO) << "Warmup notify success, cosPath=" << body["cosPath"].get<std::string>();
        return 0;
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << "Warmup notify exception: " << e.what();
        return -1;
    } catch (...) {
        HILOG_APP(ERROR) << "Warmup notify unknown exception";
        return -1;
    }
}

} // namespace prerank
} // namespace Core