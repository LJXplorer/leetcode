#pragma once
#include <string>

namespace Core {
namespace prerank {
int NotifyDictWarmup(const std::string& model_name, int32_t model_version); // 上报至词典模块

} // namespace prerank
} // namespace Core