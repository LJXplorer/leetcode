#ifndef FEATURE_CACHE_WRITER_H
#define FEATURE_CACHE_WRITER_H
#include "prerank/prerank_embedding.pb.h"
#include <atomic>
#include <condition_variable>
#include <fstream>
#include <mutex>
#include <queue>
#include <string>
#include <thread>
#include <vector>

struct EmbeddingBatch {
    std::string model_url;
    int64_t model_version;
    std::vector<int64_t> creative_ids;
    std::vector<phx::ItemEmbeddingInfo> embedding_info;
    bool is_version_update;
};

class FeatureCacheWriter {
public:
    explicit FeatureCacheWriter(int wait_timeout_ms = 30000);// 默认30秒    
    ~FeatureCacheWriter();

    void enqueue_batch(const EmbeddingBatch &batch);

public:
    void write_loop();
    int write_embedding(const std::string &dir,const std::vector<phx::ItemEmbeddingInfo> &embedding_items);

private:
    std::thread writer_thread_;
    std::mutex mutex_;
    std::condition_variable cond_var_;
    std::queue<EmbeddingBatch> batch_queue_;
    std::atomic<bool> stop_flag_;
    int wait_timeout_ms_=30000;  // 等待超时时间，单位毫秒
};

extern FeatureCacheWriter g_feature_cache_writer;

#endif// FEATURE_CACHE_WRITER_H