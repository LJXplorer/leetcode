#include "feature_cache_writer.h"
#include "prerank/prerank_embedding.pb.h"
#include <iostream>
#include <log_helper.h>
#include <sys/stat.h>
#include <wrapper_time.h>

static bool checkDirectories(const std::string &dir) {
    struct stat info;
    if (stat(dir.c_str(), &info) != 0) {
        // 目录不存在，尝试创建
        if (mkdir(dir.c_str(), 0755) != 0) {
            HILOG_APP(ERROR) << "Failed to create directory: " << dir << std::endl;
            return false;
        }
    } else if (!(info.st_mode & S_IFDIR)) {
        HILOG_APP(ERROR) << "Path exists but is not a directory: " << dir << std::endl;
        return false;
    }
    return true;
}
static const std::string adEmbeddingFile = "itemEmb.txt";

FeatureCacheWriter g_feature_cache_writer;

FeatureCacheWriter::FeatureCacheWriter(int wait_timeout_ms) : stop_flag_(false), wait_timeout_ms_(wait_timeout_ms) {
}

FeatureCacheWriter::~FeatureCacheWriter() {
    {
        std::unique_lock<std::mutex> lock(mutex_);
        stop_flag_ = true;
        cond_var_.notify_all();
    }
    if (writer_thread_.joinable()) {
        writer_thread_.join();
    }
}

void FeatureCacheWriter::enqueue_batch(const EmbeddingBatch &batch) {
    {
        std::unique_lock<std::mutex> lock(mutex_);
        batch_queue_.push(batch);
        HILOG_APP(ERROR) << "enqueue_batch!!! queue size: " << batch_queue_.size()
                         << ", current batch embedding_info size: " << batch.embedding_info.size();

        // 如果线程未启动，启动线程
        if (!writer_thread_.joinable()) {
            writer_thread_ = std::thread(&FeatureCacheWriter::write_loop, this);
        }
    }
    cond_var_.notify_one();
}

int FeatureCacheWriter::write_embedding(const std::string &dir,
                                        const std::vector<phx::ItemEmbeddingInfo> &embedding_items) {
    if (!checkDirectories(dir)) {
        return -1;
    }
    std::string path = dir + adEmbeddingFile;
    std::ofstream output_file(path, std::ios::app);
    if (!output_file.is_open()) {
        HILOG_APP(ERROR) << "Failed to open file: " << path << std::endl;
        return -1;
    }

    for (const auto &item: embedding_items) {
        std::string serialized_str;
        if (!item.SerializeToString(&serialized_str)) {
            HILOG_APP(ERROR) << "Failed to serialize ItemEmbeddingInfo to string: " << path << std::endl;
            return -1;
        }
        output_file << serialized_str << std::endl;
    }
    output_file.flush();// 强制刷新

    HILOG_APP(ERROR) << "Successfully wrote " << embedding_items.size() << " ItemEmbeddingInfo lines to: " << path
                     << std::endl;
    return 0;
}

void FeatureCacheWriter::write_loop() {
    while (true) {
        EmbeddingBatch batch;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            // 等待队列非空或超时
            bool has_data = cond_var_.wait_for(lock, std::chrono::seconds(wait_timeout_ms_ / 1000),
                                               [this] { return !batch_queue_.empty() || stop_flag_; });

            if (!has_data && batch_queue_.empty()) {
                // 超时且队列为空，退出线程
                HILOG_APP(ERROR) << "Wait timeout and queue empty, exiting write thread.";
                break;
            }

            if (stop_flag_ && batch_queue_.empty()) {
                break;
            }

            if (!batch_queue_.empty()) {
                batch = batch_queue_.front();
                batch_queue_.pop();
            } else {
                // 队列空，继续等待
                continue;
            }
        }

        // 写文件操作
        std::string date_str = get_current_date_yyyymmdd();
        std::string interval_str = get_current_30min_interval();
        std::string base_dir = batch.model_url + "/" + date_str + "/" + interval_str + "/" + std::to_string(batch.model_version) +"/";
        int ret = write_embedding(base_dir, batch.embedding_info);
        if (ret != 0) {
            HILOG_APP(ERROR) << "Write embedding failed for model_url: " << batch.model_url << std::endl;
        }
        HILOG_APP(ERROR) << "write_loop end!!!" << std::endl;
    }
}