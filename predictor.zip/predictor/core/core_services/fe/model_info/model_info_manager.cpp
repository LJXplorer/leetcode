#include "model_info_manager.h"
#include "butil/third_party/rapidjson/document.h"
#include "common/comm/config_xml.h"
#include "common/config/config_manager.h"
#include "common/config/error_code.h"
#include "common/hidict/dict_manager.h"
#include "phx-fe/config_mgr/xml_config_mgr.h"
#include "phx-fe/decode/decode.h"
#include "phx-fe/src/service.h"
#include <boost/algorithm/hex.hpp>
#include <boost/uuid/detail/md5.hpp>
#include <brpc/options.pb.h>
#include <crypt.h>
#include <cstdint>
#include <debug_utils.h>
#include <fcntl.h>
#include <glog/logging.h>
#include <log_helper.h>
#include <memory>
#include <openssl/aes.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <string>
#include <string_view>
#include <sys/mman.h>
#include <sys/stat.h>
namespace Core::Info {
    int ModelInfo::init() {
        HILOG_APP(INFO) << "ModelInfo init start";

        try {
            _options.connection_type = _connection_type;
            _options.protocol = _protocol_type.c_str();

            HILOG_APP(INFO) << "initialize polaris channel" << " _model_url: " << _model_url;
            if (!_model_url.empty()) {
                if (_channel.Init(_model_url.c_str(), _lb.c_str(), &_options) != 0) {
                    HILOG_APP(ERROR) << _model_name << " initialize polaris channel fail";
                    return -1;
                } else {
                    HILOG_APP(INFO) << _model_name << " initialize polaris channel success";
                }
            }
        } catch (const std::exception &exp) {
            HILOG_APP(ERROR) << _model_name << " initialize polaris channel fail";
            return -1;
        }

        if (load_fe_config()) {
            HILOG_APP(INFO) << "load_fe_config success";
        }

        if (load_model_input_config()) {
            HILOG_APP(INFO) << "load_model_input_config success";
        }

        if (load_multi_pos_config()) {
            HILOG_APP(INFO) << "load multi_pos_config success";
        }

        boost::uuids::detail::md5 boost_md5;
        boost_md5.process_bytes(_fe_config_content.c_str(), _fe_config_content.length());
        boost::uuids::detail::md5::digest_type digest;
        boost_md5.get_digest(digest);
        const auto char_digest = reinterpret_cast<const char *>(&digest);
        boost::algorithm::hex(char_digest, char_digest + sizeof(boost::uuids::detail::md5::digest_type),
                              std::back_inserter(_fe_config_content_md5));

        try {

            if (_use_encrypted_fe_config) {
                HILOG_APP(INFO) << "decrypt fe config...";
                _fe_config_content = Decode::decode_string(_fe_config_content);
            }

            HILOG_APP(INFO) << "_fe_config_content: " << _fe_config_content << "," << _fe_config_content_md5
                            << std::endl;
            std::vector<DictConfigPlainText> dict_configs =
                    XmlConfigMgr::get_dict_configs_from_string(_fe_config_content, "");
            HILOG_APP(INFO) << "get_dict_configs_from_string success " << std::endl;
            //预处理
            std::vector<hidict::DictConfig> hidict_configs;
            std::string archived_dict_path;
            for (const auto &dict_config: dict_configs) {
                hidict::DictConfig hidict_config;
                hidict_config.m_name = dict_config.name;
                hidict_config.m_path = dict_config.path;
                hidict_config.m_clazz = dict_config.class_name;
                hidict_configs.push_back(hidict_config);
            }
            //call 词典模块 返回一个addict collector 指针
            _model_dict_collector = new AdDict::AdDictCollector();
            long handle = reinterpret_cast<long>(_model_dict_collector);
            _model_dict_collector->init(std::to_string(handle), hidict_configs, false);

            HILOG_APP(INFO) << "init_xml_online_by_decypt_content_new_sample start" << std::endl;
            // config_info的指针，写到ModelInfo里

            HILOG_APP(INFO) << "_model_input_config_content: " << _model_input_config_content << std::endl;
            _config_info = init_xml_online_by_decypt_content_new_sample(_fe_config_content, _model_input_config_content,
                                                                        _model_dict_collector);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "Error from model:" << _model_name << ",reason: " << e.what();
            return -1;
        } catch (...) {
            HILOG_APP(ERROR) << "An unexpected error occurred, model name: " << _model_name << ".";
            return -1;
        }

        HILOG_APP(INFO) << "ModelInfo init end " << std::endl;

        return 0;
    }

    bool ModelInfo::load_fe_config() {
        //根据 _model_config_path + _fe_config_file_name 得到 fe config文件的路径
        //读取加密的文件内容到 _fe_config_content
        //解密 _fe_config_content 内容
        bool success = false;
        try {
            std::string config_path = _model_config_path;
            if (config_path.back() != '/') {
                config_path += "/";
            }
            success = read_file(config_path + _fe_config_file_name, _fe_config_content);
            HILOG_APP(INFO) << "read_fe_config:" << success << std::endl;
            std::cout << "read_fe_config:" << success << std::endl;
        } catch (...) {
            success = false;
            HILOG_APP(ERROR) << _model_name << "," << model_type_to_string(_model_type) << ",fe: " << _model_config_path
                             << ", load_fe_config fail!";
            std::cout << _model_name << "," << model_type_to_string(_model_type) << ",fe: " << _model_config_path
                      << ", load_fe_config fail!";
        }
        return success;
    }
    bool ModelInfo::load_model_input_config() {
        // 根据 _model_config_path + _model_input_config_file_name 得到 model_input_config文件的路径
        //读取文件内容到 _model_input_config_content
        bool success = false;
        try {
            std::string config_path = _model_config_path;
            if (config_path.back() != '/') {
                config_path += "/";
            }
            success = read_file(config_path + _model_input_config_file_name, _model_input_config_content);
            HILOG_APP(INFO) << "read_model_config:" << success << std::endl;
            std::cout << "read_model_config:" << success << std::endl;
        } catch (...) {
            success = false;
            HILOG_APP(ERROR) << _model_name << "," << model_type_to_string(_model_type) << ",fe: " << _model_config_path
                             << ", load_model_input_config fail!";
            std::cout << _model_name << "," << model_type_to_string(_model_type) << ",fe: " << _model_config_path
                      << ", load_model_input_config fail!";
        }
        return success;
    }

    bool ModelInfo::load_multi_pos_config() {
        if (_multi_pos_config_file.empty()) {
            _multi_pos_flag = false;
            return true;
        }

        _multi_pos_flag = true;
        bool success = false;
        try {
            std::string config_path = _model_config_path;
            if (config_path.back() != '/') {
                config_path += "/";
            }

            std::string config_content;
            success = read_file(config_path + _multi_pos_config_file, config_content);
            // parse content to _adunit_pos_info
            try {
                nlohmann::json pos_config = nlohmann::json::parse(config_content);
                if (!pos_config.contains("position_predict") || !pos_config["position_predict"].is_object()) {
                    throw std::runtime_error("Missing or invalid 'position_predict' field");
                }
                for (const auto &[k, v]: pos_config["position_predict"].items()) {
                    if (!v.contains("adunit_id") || !v.contains("num")) {
                        HILOG_APP(ERROR) << "Warning: missing 'adunit_id' or 'num' in entry " << k;
                        continue;
                    }

                    if (!v["adunit_id"].is_string() || !v["num"].is_number_integer()) {
                        HILOG_APP(ERROR) << "Warning: invalid type for 'adunit_id' or 'num' in entry " << k;
                        continue;
                    }

                    int64_t adunit_id = 0;
                    try {
                        adunit_id = std::stoll(v["adunit_id"].get<std::string>());
                    } catch (const std::exception &e) {
                        HILOG_APP(ERROR) << "Warning: failed to convert adunit_id to int64_t in entry " << k << ": "
                                         << e.what();
                        continue;
                    }

                    int64_t num = v["num"].get<int64_t>();
                    _adunit_pos_info[adunit_id] = num;
                }
            } catch (const std::exception &e) {
                success = false;
                _multi_pos_flag = false;
                HILOG_APP(ERROR) << "Exception: " << e.what();
            }
        } catch (...) {
            success = false;
            _multi_pos_flag = false;
            HILOG_APP(ERROR) << _model_name << "," << model_type_to_string(_model_type) << ",fe: " << _model_config_path
                             << ", load_multi_pos_config fail!";
            std::cout << _model_name << "," << model_type_to_string(_model_type) << ",fe: " << _model_config_path
                      << ", load_multi_pos_config fail!";
        }
        return success;
    }

    int64_t ModelInfo::get_adunit_pos_info(int64_t adunit_id) {
        const auto iter = _adunit_pos_info.find(adunit_id);
        if (iter != _adunit_pos_info.end()) {
            return iter->second;
        }
        return -1;
    }

    brpc::Channel *ModelInfo::get_channel() {
        return &_channel;
    }

    ModelInfoManager &ModelInfoManager::instance() {
        static ModelInfoManager inst;
        return inst;
    }

    int ModelInfoManager::update(const std::string &content) noexcept {
        HILOG_APP(INFO) << "ModelInfoManager::update start";
        ConfigXml xml_conf;
        if (!xml_conf.parse(content)) {
            HILOG_APP(ERROR) << "model info xml parse error!";
            return -1;
        }

        ConfigXml main;
        if (!xml_conf.find("main", main)) {
            HILOG_APP(ERROR) << "main not found in model_info.xml on Nacos";
            return -2;
        }

        // 解析 common 节点
        std::string common_model_path;
        ConfigXml common;
        std::string common_step_az_config;
        if (main.child("common", common)) {
            common.attr<std::string>("model_path", common_model_path, "");
            if (common_model_path.empty()) {
                HILOG_APP(ERROR) << "common model_path is empty";
            } else if (common_model_path.back() == '/') {
                common_model_path.pop_back();
            }
            HILOG_APP(INFO) << "Model path: " << common_model_path;

            common.attr<std::string>("step_az", common_step_az_config, "");
        } else {
            HILOG_APP(ERROR) << "common not found in model_info.xml on Nacos";
            return -3;
        }

        ConfigXml model_info_xml;
        if (!main.child("model", model_info_xml)) {
            HILOG_APP(ERROR) << "model not exist in channel_config in model_info.xml on Nacos";
            return -4;
        }
        bool has_next = false;
        auto new_backup_map = std::make_shared<std::unordered_map<std::string, std::shared_ptr<ModelInfo>>>();
        auto new_emb_name_backup_map = std::make_shared<emb_model_name_map>();
        // auto backup_map = _model_info_maps.get_bak_obj();
        // backup_map->clear();//清空旧缓存
        do {
            auto model_info = std::make_shared<ModelInfo>();
            model_info_xml.attr<std::string>("name", model_info->_model_name);
            if (model_info->_model_name.empty()) {
                HILOG_APP(ERROR) << "model_name is empty";
            }
            model_info_xml.attr<int64_t>("id", model_info->_model_id);
            if (model_info->_model_id == -1) {
                // 没有模型id就不会加载这个模型
                HILOG_APP(ERROR) << "model_name: " << model_info->_model_name << ", model id is null";
                has_next = model_info_xml.next("model", model_info_xml);
                continue;
            }
            model_info_xml.attr<std::string>("model_url", model_info->_model_url);
            if (model_info->_model_url.empty()) {
                HILOG_APP(ERROR) << "model_name: " << model_info->_model_name << ", url is empty";
            }

            model_info_xml.attr<std::string>("protocol_type", model_info->_protocol_type);
            if (model_info->_protocol_type.empty()) {
                model_info->_protocol_type = "baidu_std";
            }

            std::string connection_type_str;
            model_info_xml.attr<std::string>("connection_type", connection_type_str);
            if (connection_type_str == "pooled") {
                model_info->_connection_type = brpc::CONNECTION_TYPE_POOLED;
            } else if (connection_type_str == "short") {
                model_info->_connection_type = brpc::CONNECTION_TYPE_SHORT;
            } else {
                model_info->_connection_type = brpc::CONNECTION_TYPE_SINGLE;
            }

            if (!safe_read_int_attr(model_info_xml, "timeout_ms", model_info->_options.timeout_ms)) {
                return -5;
            }

            if (!safe_read_int_attr(model_info_xml, "backup_timeout_ms", model_info->_options.backup_request_ms)) {
                return -6;
            }

            if (!safe_read_int_attr(model_info_xml, "max_retry", model_info->_options.max_retry)) {
                return -7;
            }

            model_info_xml.attr<std::string>("path", model_info->_model_config_path);
            if (model_info->_model_config_path.empty()) {
                model_info->_model_config_path = common_model_path + "/" + model_info->_model_name;
            }

            model_info_xml.attr<std::string>("fe_config", model_info->_fe_config_file_name);
            if (model_info->_fe_config_file_name.empty()) {
                model_info->_fe_config_file_name = "fe_config.xml";
            }
            model_info_xml.attr<std::string>("model_input_config", model_info->_model_input_config_file_name);
            if (model_info->_model_input_config_file_name.empty()) {
                model_info->_model_input_config_file_name = "model_input_config.yaml";
            }

            model_info_xml.attr<std::string>("multi_pos_config", model_info->_multi_pos_config_file, "");

            std::string model_type_str;
            model_info_xml.attr<std::string>("model_type", model_type_str);

            if (model_type_str == "item_embedding") {
                model_info->_model_type = ModelType::ITEM_EMBEDDING;
            } else if (model_type_str == "user_embedding") {
                model_info->_model_type = ModelType::USER_EMBEDDING;
            } else {
                model_info->_model_type = ModelType::UNKNOWN;
            }

            model_info_xml.attr<std::string>("pair_model", model_info->_pair_model);
            model_info_xml.attr<std::string>("dict_name", model_info->_dict_name);
            model_info_xml.attr<std::string>("emb_name", model_info->_emb_name);
            std::string is_ltr_str;
            model_info_xml.attr<std::string>("is_ltr", is_ltr_str);
            if (is_ltr_str == "true") {
                model_info->_is_ltr = true;
            }
            std::string request_compress_type;
            model_info_xml.attr<std::string>("request_compress_type", request_compress_type);
            if (request_compress_type == "gzip") {
                model_info->_request_compress_type = brpc::COMPRESS_TYPE_GZIP;
            } else if (request_compress_type == "lz4") {
                model_info->_request_compress_type = brpc::COMPRESS_TYPE_LZ4;
            } else if (request_compress_type == "snappy") {
                model_info->_request_compress_type = brpc::COMPRESS_TYPE_SNAPPY;
            } else if (request_compress_type == "zlib") {
                model_info->_request_compress_type = brpc::COMPRESS_TYPE_ZLIB;
            } else {
                model_info->_request_compress_type = brpc::COMPRESS_TYPE_NONE;
            }

            model_info_xml.attr<std::string>("connection_group", model_info->_options.connection_group);
            std::string lb_str = "cb";
            model_info_xml.attr<std::string>("lb", lb_str);
            if (_load_balancers.find(lb_str) == _load_balancers.end()) {
                lb_str = "rr";
            }

            if(lb_str == "cb") {  // step az config only work in custom balancer
                std::string single_step_az;
                model_info_xml.attr<std::string>("step_az", single_step_az,"");
                if(!common_step_az_config.empty()) {
                    lb_str.append(":").append(common_step_az_config);
                } else if (!single_step_az.empty()) {
                    lb_str.append(":").append(single_step_az);
                }
            }
            model_info->_lb = lb_str;
            if (model_info->init() != 0) {
                HILOG_APP(ERROR) << "Fail to initialize " << model_info->_model_name << " polaris channel";
            } else {
                new_backup_map->insert_or_assign(model_info->_model_name, model_info);
                if (!model_info->_emb_name.empty()) {
                    new_emb_name_backup_map->insert_or_assign(model_info->_emb_name + model_type_to_string(model_info->_model_type), model_info->_model_name);
                }
            }

            has_next = model_info_xml.next("model", model_info_xml);
            HILOG_APP(INFO) << "type:" << model_type_to_string(model_info->_model_type)
                            << " name:" << model_info->_model_name
                            << " model_fe_config_path:" << model_info->_model_config_path
                            << " model_fe_config_file:" << model_info->_fe_config_file_name
                            << " model_fe_input_config_file:" << model_info->_model_input_config_file_name;
        } while (has_next);

        //all param parse success
        _common_model_path = common_model_path;
        auto backup_map = _model_info_maps.get_bak_obj();
        backup_map->clear();
        *backup_map = *new_backup_map;

        auto emb_name_backup_map = _emb_model_name_maps.get_bak_obj();
        emb_name_backup_map->clear();
        *emb_name_backup_map = *new_emb_name_backup_map;

        _model_info_maps.change();
        _emb_model_name_maps.change();

        HILOG_APP(INFO) << "model_info_map_to_string: "
                        << model_info_map_to_string(*_model_info_maps.get_current_obj());

        HILOG_APP(ERROR) << "new model_info map size: " << backup_map->size() << ", emb_name_backup_map size: " << emb_name_backup_map->size();
        std::cout << "new model_info map size: " << backup_map->size() << ", emb_name_backup_map size: " << emb_name_backup_map->size() << std::endl;
        HILOG_APP(INFO) << "ModelInfoManager::update end";
        return 0;
    }

    std::unordered_map<std::string, std::shared_ptr<ModelInfo>> &ModelInfoManager::get_model_infos() {
        auto current_model_info_map = _model_info_maps.get_current_obj();
        return *(current_model_info_map.get());
    }

    brpc::Channel *ModelInfoManager::get_channel(const std::string &model_name) {
        auto current_model_info_map = _model_info_maps.get_current_obj();
        auto it = current_model_info_map->find(model_name);

        if (it == current_model_info_map->end()) {
            HILOG_APP(ERROR) << "channel not found, model_name: " << model_name;
            return nullptr;
        }
        return it->second->get_channel();
    }

    std::shared_ptr<ModelInfo> ModelInfoManager::get_model_info(const std::string &model_name) {
        auto current_model_info_map = _model_info_maps.get_current_obj();
        auto it = current_model_info_map->find(model_name);

        if (it == current_model_info_map->end()) {
            HILOG_APP(ERROR) << "model_info not found, model_name: " << model_name;
            return nullptr;
        }
        return it->second;
    }

    void ModelInfoManager::get_emb_model_name(const std::string &emb_name, const ModelType &model_type, std::string &model_name) {
        auto current_emb_model_name_map = _emb_model_name_maps.get_current_obj();
        auto it = current_emb_model_name_map->find(emb_name + model_type_to_string(model_type));

        if (it == current_emb_model_name_map->end()) {
            HILOG_APP(ERROR) << "model name not found, emb_name: " << emb_name;
            return;
        }
        model_name = it->second;
    }

    const std::string &ModelInfoManager::get_model_path(const std::string &name) {
        auto current_model_info_map = _model_info_maps.get_current_obj();
        auto m = current_model_info_map->find(name);
        if (m != current_model_info_map->end()) {
            return m->second->get_model_path();
        }
        return STRING_DEFAULT;
    }

    int ModelInfoManager::init(const config::ConfigServiceCfg &cfg, const std::string &group_id,
                               const std::string &data_id) {
        auto ptr = std::make_shared<ModelInfoNacosConfig>(group_id, data_id);
        config::RegisterResponse regist_ret = config::ConfigManager::getInstance().RegisterConfig(cfg, ptr);
        if (regist_ret != config::RegisterResponse::kSuccess) {
            std::cerr << "register model_info nacos failed" << std::endl;
            HILOG_APP(ERROR) << "register model_info nacos failed";
            return -1;
        }
        return 0;
    }

    std::vector<unsigned char> ModelInfo::getKey(const std::string &key) {
        std::string truncatedKey = key.substr(0, 16);
        std::vector<unsigned char> result(16, 0);
        try {
            for (size_t i = 0; i < truncatedKey.length(); ++i) {
                result[i] = static_cast<unsigned char>(truncatedKey[i]);
            }
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "getKey failed!" << e.what();
        }
        return result;
    }

    std::vector<unsigned char> ModelInfo::base64Decode(const std::string &encoded) {
        BIO *bio, *b64;
        try {
            char *buffer = (char *) malloc(encoded.size());
            if (buffer == nullptr) {
                throw std::runtime_error("Failed to allocate memory");
            }

            bio = BIO_new_mem_buf(encoded.data(), encoded.size());
            if (bio == nullptr) {
                free(buffer);
                throw std::runtime_error("Failed to create BIO");
            }

            b64 = BIO_new(BIO_f_base64());
            if (b64 == nullptr) {
                BIO_free(bio);
                free(buffer);
                throw std::runtime_error("Failed to create BIO for base64");
            }

            bio = BIO_push(b64, bio);
            BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL);

            int decoded_length = BIO_read(bio, buffer, encoded.size());
            if (decoded_length < 0) {
                BIO_free_all(bio);
                free(buffer);
                throw std::runtime_error("Failed to decode base64");
            }

            std::string decoded(buffer, decoded_length);
            std::vector<unsigned char> vec(decoded.begin(), decoded.end());

            BIO_free_all(bio);
            free(buffer);

            return vec;
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "base64Decode failed!" << e.what();
        }

        return std::vector<unsigned char>();
    }

    std::string ModelInfo::decrypt(const std::string &base64Str, const std::string &keyStr, const std::string &ivStr) {
        try {
            std::vector<unsigned char> secretKey = getKey(keyStr);
            std::vector<unsigned char> iv = getKey(ivStr);
            std::vector<unsigned char> encrypted = base64Decode(base64Str);
            std::vector<unsigned char> original(encrypted.size() + AES_BLOCK_SIZE);
            int outlen;

            EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
            EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, secretKey.data(), iv.data());
            EVP_DecryptUpdate(ctx, original.data(), &outlen, encrypted.data(), encrypted.size());
            int finalLen;
            EVP_DecryptFinal_ex(ctx, original.data() + outlen, &finalLen);
            EVP_CIPHER_CTX_free(ctx);

            original.resize(outlen + finalLen);

            return std::string(original.begin(), original.end());
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "decrypt failed!" << e.what();
        }
        return "";
    }

    //TODO: 需要异常处理 读不到文件会crash
    bool ModelInfo::read_file(const std::string &file_path, std::string &file_content) {
        // open file
        int fd = open(file_path.c_str(), O_RDONLY);
        if (-1 == fd) {
            HILOG_APP(ERROR) << "open file failed, file path: " << file_path;
            return false;
        }
        // stat file
        struct stat sb;
        if (fstat(fd, &sb) == -1) {
            HILOG_APP(ERROR) << "fstat failed, file path: " << file_path;
            return false;
        }

        // mmap
        int32_t length = sb.st_size;
        const char *p_buf = static_cast<const char *>(mmap(NULL, length, PROT_READ, MAP_PRIVATE, fd, 0));
        if (p_buf == nullptr || p_buf == MAP_FAILED) {
            HILOG_APP(ERROR) << "mmap failed, file_path: " << file_path;
            return false;
        }
        file_content.assign(p_buf, length);
        // unmmap
        munmap((void *) p_buf, length);
        // close
        close(fd);
        return true;
    }

    std::vector<std::shared_ptr<Config>> &ModelInfo::get_fe_config() {
        return _config_info->configs_;
    }

    // std::shared_ptr<Info::ModelInfo> ModelInfoManager::get_model_info_for_test(const std::string &model_name) {
    //     static std::string kFeConfigContent = debug::ReadFile("../test/test_model/fe_config.xml", std::ios::in);
    //     static std::string kModelInputConfig =
    //             debug::ReadFile("../test/test_model/model_input_config.yaml", std::ios::in);

    //     auto model_info_ptr = std::make_shared<Info::ModelInfo>();
    //     auto &model_info = *model_info_ptr;
    //     model_info._model_name = model_name;
    //     model_info._model_url = "model_for_test";
    //     model_info._model_config_path = "";
    //     model_info._fe_config_content = kFeConfigContent;
    //     model_info._model_input_config_content = kModelInputConfig;

    //     // 调用  拿到词典信息
    //     //第一个解码的fe_config内容，第二个空字符串
    //     std::vector<DictConfigPlainText> dict_configs =
    //             XmlConfigMgr::get_dict_configs_from_string(kFeConfigContent, "");

    //     //预处理
    //     std::vector<hidict::DictConfig> hidict_configs;
    //     std::string archived_dict_path;
    //     for (const auto &dict_config: dict_configs) {
    //         hidict::DictConfig hidict_config;
    //         hidict_config.m_name = dict_config.name;
    //         hidict_config.m_path = dict_config.path;
    //         hidict_config.m_clazz = dict_config.class_name;
    //         hidict_configs.push_back(hidict_config);
    //     }
    //     //call 词典模块 返回一个addict collector 指针
    //     AdDict::AdDictCollector *dict_collector = new AdDict::AdDictCollector();
    //     long handle = reinterpret_cast<long>(dict_collector);
    //     dict_collector->init(std::to_string(handle), hidict_configs, false);
    //     // config_info的指针，写到ModelInfo里
    //     auto config_info =
    //             init_xml_online_by_decypt_content_new_sample(kFeConfigContent, kModelInputConfig, dict_collector);

    //     model_info.set_config_info(*config_info);

    //     return model_info_ptr;
    // }

}// namespace Core::Info