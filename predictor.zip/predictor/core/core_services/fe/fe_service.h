#pragma once

#include "core/core_context/context_defs.h"
#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"
#include "fe_request.pb.h"
#include "phx-fe/src/session.h"
#include "user_action.pb.h"
#include <bthread/types.h>
#include <bvar/latency_recorder.h>
namespace Core {

    class FeService : public ServiceBaseInfo {
    public:
        enum class ExtractType {
            kAll,
            kUser,
            kItem,
        };

    private:
        static constexpr int32_t kDefaultFeSplitSize = 40;
        int32_t split_size_ = kDefaultFeSplitSize;
        ExperimentModelType model_type_;
        ExtractType extract_type_ = FeService::ExtractType::kAll;
        bvar::LatencyRecorder *single_fe_cost_;
        bvar::LatencyRecorder *node_cost_;

    public:
        FeService() = default;

        ~FeService() {
            if (single_fe_cost_ != nullptr) {
                delete single_fe_cost_;
            }
            if (node_cost_ != nullptr) {
                delete node_cost_;
            }
        }

        void initialize(ConfigXmlPtr xml) override;
        void initialize(GraphContextPtr context) override;
        int do_service(GraphContextPtr context) override;
        bool skip(GraphContextPtr context) override;
        void set_model_type(ExperimentModelType model_type) {
            model_type_ = model_type;
        }

        const ExperimentModelType &get_model_type() {
            return model_type_;
        }

    public:
        struct BatchFeArgs {
            phx_fe::Options option;
            phx_fe::Session* session;
            phx::FeRequest *fe_request;
            phx::UserAction *user_action;
            phx::ExtractorResponse *split_extractor_response;
            ExtractorWrapper *extrator_wrapper;
            const ExperimentModelInfo *exp_model_info;
            FeService *fe_service;
            bthread_t bid;
            long start = 0;
            long end = 0;
        };
        int SplitExtract(CoreContextPtr context, phx_fe::ConfigsGetter config_getter, phx_fe::ModelSlotsGetter model_slots_getter);
        const std::unordered_map<ExperimentModelInfo *, std::vector<ItemWrapper>> *
        GetItemListsOfThisNode(CoreContextPtr core_context);
        void StartBackgroundExtraction(BatchFeArgs &args);

        /**
         * @brief 构造一个分片的FeRequest
         * 
         * @param arena 返回的FeRequest分配在这个arena上
         * @param full_fe_request 全量fe_request
         * @param total_items 全量item
         * @param item_start_index item起始索引
         * @param item_end_index item结束索引
         * @return phx::FeRequest* 
         */
        phx::FeRequest *BuildSplitFeRequest(CoreContextPtr core_context, phx::FeRequest *full_fe_request,
                                            const std::vector<ItemWrapper> &total_items, size_t item_start_index,
                                            size_t item_end_index, ExtractorWrapper &ext_wrapper);
        static void *SplitExtractCStyle(void *args_v);
        int UserFeatureExtract(CoreContextPtr core_context);
        int ItemFeatureExtract(CoreContextPtr core_context);
        void ShallowCopyUserFeature(phx::FeRequest *from, phx::FeRequest *to);
    };

}// namespace Core