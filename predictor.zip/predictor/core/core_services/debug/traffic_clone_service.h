#pragma once
#include "core/core_services/base_service/service_info.h"
#include "ranking_client.h"
#include <functional>
#include <memory>
#include <shared_mutex>
#include <unordered_map>

namespace Core {
    class TrafficCloneService : public ServiceBaseInfo {
    public:
        TrafficCloneService() = default;
        int do_service(GraphContextPtr context) override;

    protected:
        virtual void SendRequest(const std::string &addr, const ::phx::PredictorRequest *request_ptr);

    private:
        std::shared_ptr<debug::RankingClient> GetOrCreateClient(const std::string &addr);

    private:
        std::unordered_map<std::string, std::shared_ptr<debug::RankingClient>> client_map_;
        std::shared_mutex mtx_;
        std::hash<std::string> hasher;
    };
}// namespace Core
