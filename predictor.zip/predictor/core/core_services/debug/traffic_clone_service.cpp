#include "traffic_clone_service.h"
#include "core/utils/debug_param_manager.h"
#include "core/utils/error.h"
#include <log_helper.h>
#include <memory>
#include <mutex>
#include <nlohmann/json_fwd.hpp>
#include <unistd.h>
namespace Core {
    SERVICE_REGISTER(TrafficCloneService);

    int TrafficCloneService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        if (ctx == nullptr) {
            HILOG_APP(ERROR) << "context is not CoreContext";
            return -1;
        }
        int traffic_sample_rate = 0;
        std::string traffic_clone_addr{};
        nlohmann::json debug_param = debug::DebugParamManager::GetInstance().Get("TrafficCloneService");
        if (debug_param.empty() || !debug_param.is_object()) {
            return ERROR_SUCCESS;
        }
        try {
            if (debug_param.contains("traffic_sample_rate")) {
                traffic_sample_rate = debug_param["traffic_sample_rate"].get<int>();
            }
            if (debug_param.contains("traffic_clone_addr")) {
                traffic_clone_addr = debug_param["traffic_clone_addr"].get<std::string>();
            }
        } catch (nlohmann::json::exception &e) {
            HILOG_APP(ERROR) << "parse TrafficCloneService param failed: " << e.what();
        }
        if (traffic_sample_rate <= 0 || traffic_clone_addr.empty()) {
            return ERROR_SUCCESS;
        }
        auto hash_val = hasher(ctx->_bak_request.reqid());
        auto random_val = static_cast<int>(hash_val % 100) + 1;
        if (random_val <= traffic_sample_rate) {
            SendRequest(traffic_clone_addr, &ctx->_bak_request);
        }
        return ERROR_SUCCESS;
    }
    std::shared_ptr<debug::RankingClient> TrafficCloneService::GetOrCreateClient(const std::string &addr) {
        {
            std::shared_lock read_lock(mtx_);
            auto iter = client_map_.find(addr);
            if (iter != client_map_.end()) {
                return iter->second;
            }
        }
        {
            std::unique_lock write_lock(mtx_);
            client_map_[addr] = std::make_shared<debug::RankingClient>(addr);
            return client_map_[addr];
        }
    }

    void TrafficCloneService::SendRequest(const std::string &addr, const ::phx::PredictorRequest *request_ptr) {
        auto client = GetOrCreateClient(addr);
        client->SendRequest(request_ptr);
    }

}// namespace Core