#ifndef _CORE_SERVICES_DONE_H
#define _CORE_SERVICES_DONE_H
#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"
namespace Core {

    class DoneService : public ServiceBaseInfo {
    private:
        std::string _proto_type;
        std::set<std::string> _valid_route;

        void fill_scores_in_response(CoreContextPtr& context, phx::PredictorResponse *response);

    public:
        DoneService() {
        }

        ~DoneService() {
        }

        virtual void initialize(ConfigXmlPtr xml);
        virtual void initialize_xml(ConfigXmlPtr xml);
        virtual void initialize(GraphContextPtr context);
        virtual int do_service(GraphContextPtr context);

    public:
        virtual int assembly_response(CoreContextPtr context);
    };

}// namespace Core

#endif
