#pragma once
#include "core/core_services/base_service/service_info.h"
#include "core/core_context/callback_context.h"
namespace Core {
 
    class CallbackDoneService : public ServiceBaseInfo {
  
    public:
        CallbackDoneService(){
        }

        ~CallbackDoneService(){

        }

        virtual void initialize(ConfigXmlPtr xml);
        virtual void initialize_xml(ConfigXmlPtr xml);
        virtual void initialize(GraphContextPtr context);
        virtual int do_service(GraphContextPtr context) ;

    public:
        virtual int assembly_response(CallbackContextPtr context);
    };
    
}

