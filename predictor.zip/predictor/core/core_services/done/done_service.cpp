#include "core/core_services/done/done_service.h"
#include "common/hilog/log_helper.h"
#include "common/monitor/monitor_manager.h"
#include "core/core_context/core_context.h"
#include "core/utils/defs.h"
#include "core/utils/error.h"
#include "json2pb/pb_to_json.h"
#include <boost/algorithm/string.hpp>
#include <debug_utils.h>
#include <glog/logging.h>
#include <string>
#include <type_traits>
#include <unordered_set>
#include <utils.h>
namespace Core {

    SERVICE_REGISTER(DoneService);

    void DoneService::initialize(ConfigXmlPtr xml) {
        initialize_xml(xml);
    }

    void DoneService::initialize_xml(ConfigXmlPtr xml) {
    }

    void DoneService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
    }

    int DoneService::do_service(GraphContextPtr context) {
        HILOG_APP(INFO) << "DoneService::do_service(GraphContextPtr context) start";
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int32_t ret = 0;
        BizLatency *lat = get_node_stat(ctx)->get_lat();
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);
            try {
                ret = assembly_response(ctx);
            } catch (const std::exception &e) {
                HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << "do service fail: " << ret << "," << e.what();
            }
        }
        HILOG_APP(INFO) << LOG_HEAD(ctx) << get_name() << " do_service ret:" << ret;
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_DESTROY);
            ctx->_end_ts = gettimeofday_ms();
            ctx->get_raw_response()->set_predictortime(ctx->_end_ts - ctx->_begin_ts);
            ctx->set_predicttime(ctx->_end_ts - ctx->_begin_ts);
            ctx->get_request_context()->done();
            monitor::MonitorManager::getInstance().InterfaceSvrSuccess(
                    ctx->_begin_ts, "/predictService", ctx->get_req_id(), "200", "", "", 0, "",
                    std::to_string(ctx->get_slot_id()) + "," +
                            std::to_string(ctx->_bak_request.predictorslotinfo().predictoriteminfos_size()));
        }
        HILOG_APP(INFO) << "DoneService::do_service(GraphContextPtr context) end";
        return ret;
    }

    int DoneService::assembly_response(CoreContextPtr context) {
        auto response = context->get_rank_response();
        HILOG_APP(INFO) << "response: " << debug::printer::ToString(response);
        response->set_reqid(context->get_req_id());
        response->set_code(context->_response_code);
        response->set_predictortime(context->_end_ts - context->_begin_ts);
        //填精排分到返回体
        fill_scores_in_response(context, response);
        HILOG_APP(INFO) << "predictor response: \n" <<  debug::printer::ToString(response);
        if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
            debug::pb::SavePbToFile("predictor_response.json", *response);
        }
        context->get_raw_response()->CopyFrom(*response);
        return ERROR_SUCCESS;
    }

    void DoneService::fill_scores_in_response(CoreContextPtr &context, phx::PredictorResponse *response) {
        for (const auto &[creative_id, item_data]: context->_creative_id_item_score_map) {
            ::phx::PredictorItemData *item_data_proto = response->mutable_predictslotdata()->add_predictoritemdatas();
            
            // 将 item_data 拷贝给 item_data_proto
            item_data_proto->CopyFrom(item_data);
        }
    }

}// namespace Core
