#include "core/core_services/fs/redis_service.h"
#include "common/hilog/log_helper.h"
#include <boost/algorithm/string.hpp>
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
#include "core/core_context/monitor_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/error.h"
#include "fetch/fetch_manager.h"
#include "redis_client/redis_client_manager.h"
#include "core/utils/monitor_mgr.h"
#include "core/core_services/fs/cache/fs_cache.h"
#include "common/comm/charsets.h"
#include "brpc/policy/gzip_compress.h"
#include "util/base64.h"
#include "common/hikafka/kafka_helper.h"

namespace Core {

        void RedisService::initialize(ConfigXmlPtr xml){
            initialize_xml(xml);
        }

        void RedisService::initialize_xml(ConfigXmlPtr xml){

        }


        void RedisService::initialize(GraphContextPtr context){
            auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
            ctx->get_monitor_context()->alloc_node(get_name());           
        }

        int RedisService::do_service(GraphContextPtr context) {
            auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
            HILOG_APP(INFO)<<LOG_HEAD(ctx) <<get_name() ;
            int32_t ret = 0;
            BizLatency* lat = get_node_stat(ctx)->get_lat();
            try{
                BizLatencyGaurd lat_guard(lat,LAT_STAGE_CREATE);
                ret = process(ctx);
                
            }catch(const std::exception& e){
                HILOG_APP(ERROR)<<LOG_HEAD(ctx) <<get_name() << "do service fail: " << ret << ","<<e.what();
            }
            return ret;
        }

        int RedisService::process(CoreContextPtr context){
            std::vector<std::shared_ptr<const FetchInfo> > get_fetch_vec;
            std::unordered_map<std::string, std::vector<std::shared_ptr<const FetchInfo> >> hash_fetch_map;
            get_fetch(context,get_fetch_vec, hash_fetch_map);
	    
	        if(get_fetch_vec.size() == 0 && hash_fetch_map.empty()){
                HILOG_APP(WARNING) << get_name() << " get_fetch_vec.size() == 0 and hash_fetch_map is empty";
                BizLatency* lat = get_node_stat(context)->get_lat();
                {
                     BizLatencyGaurd lat_guard_dst(lat,LAT_STAGE_DESTROY);
                }
                run_output_nodes_if_ready(context);       
                return ERROR_SUCCESS;
            }
            
            auto get_fetch_over = std::make_shared<std::atomic<bool>>(false);//get特征都拉取完成
            auto hash_fetch_over = std::make_shared<std::atomic<bool>>(false);//hashget特征都拉取完成

            if (get_fetch_vec.size() != 0) {
                auto get_cond = std::make_shared<std::atomic<int>>(get_fetch_vec.size());
                for (size_t fetch_index = 0; fetch_index < get_fetch_vec.size(); fetch_index++) {
                    auto fetch_info = get_fetch_vec[fetch_index];

                    std::shared_ptr<RedisClient> redis_client;
                    redis_client = RedisClientManager::instance().get_client(fetch_info->_redis_client_id);

                    if (redis_client == nullptr) {
                        // todo 告警
                        HILOG_APP(ERROR) << "redis_client_id: " << fetch_info->_redis_client_id << " redis client not found";
                        int old = get_cond->fetch_sub(1);
                        if (old == 1) {
                            get_fetch_over->store(true);
                            if (get_fetch_over->load() && hash_fetch_over->load()) {
                                run_output_nodes_if_ready(context);
                            }
                            
                        }
                        continue;
                    }

                    std::string key;                    
                    make_fetch_key(context,fetch_info,key);
                    if(fetch_info->_expired_time){
                        std::shared_ptr< std::string> result = nullptr;
                        auto succ = get_string_feature_from_cache(fetch_info->_up_name,key,result);
                        if(succ){
                            std::string response = "";   
                            std::string final_feat_str = "";                                                   
                            FetchManager::instance().parse_redis_response(key,  fetch_info, response, *result,context->get_fs_context(),0, final_feat_str);
                            int old = get_cond->fetch_sub(1);
                            if (old == 1) {
                               get_fetch_over->store(true);
                                if (get_fetch_over->load() && hash_fetch_over->load()) {
                                    run_output_nodes_if_ready(context);
                                }
                            }
                            continue;
                        }
                    }

                    HILOG_APP(INFO) << "cluster_id: " << fetch_info->_cluster_id << " key:"<<key;                   
                    
                    auto &cluster_id = fetch_info->_cluster_id;
                    auto &up_id = fetch_info->_up_id;                 
                    auto callback = [this, key, get_cond, get_fetch_over, hash_fetch_over, cluster_id, up_id, context, fetch_info]
                        (std::shared_ptr<brpc::RedisResponse> response, std::shared_ptr<brpc::Controller> cntl_ptr){
                        int error_code = 0;
                        std::string response_str;
                        if (response == nullptr) {
                            response_str = "";
                            HILOG_APP(WARNING) << "response is nullptr; send redis failed or timeout, up_id:" << up_id
                            << " cluster_id: " << cluster_id;
                            error_code = -1;
                        } else if (response->reply_size() < 0) {
                            response_str = "";
                            response.reset();
                            HILOG_APP(WARNING) << key << " reply_size: " << response->reply_size()
                            << ", up_id:" << up_id  << " cluster_id: " << cluster_id;
                            error_code = -6;
                        } else if (response->reply(0).is_nil()) {
                            response_str = "";
                            response.reset();
                            error_code = -2;
                            HILOG_APP(WARNING) << key << " reply is nil;" << " up_id:" << up_id  << " cluster_id: " << cluster_id;
                        } else if (!response->reply(0).is_string()) {
                            response_str = "";
                            response.reset();
                            error_code = -6;
                            HILOG_APP(WARNING) << key << " reply is not a string;" << " up_id:" << up_id  << " cluster_id: " << cluster_id;
                        } else {
                            response_str.assign(response->reply(0).data().data(), 
                                                        response->reply(0).size()+1);
                            HILOG_APP(WARNING) << key << " redis data size: " << response->reply(0).data().size()<< ", up_id:" << up_id  << " cluster_id: " << cluster_id;
                            error_code = 0;
                        }
                        auto item_stat_ptr = get_node_stat(context);
                        std::string final_feat_str = "";
                        if (response) { 
                            std::string value = "";                                                        
                            FetchManager::instance().parse_redis_response(key,fetch_info, response_str, value,context->get_fs_context(),error_code, final_feat_str);
                            item_stat_ptr->report_redis_rpc(fetch_info->_cluster_id,error_code,cntl_ptr->latency_us(),1,response->ByteSize());
                            // 测试环境特征上报
                            if (error_code == 0 && ServerConfig::_feature_report_enable.load() && ServerConfig::_feature_report_running.load() && random_sampling_per_thousand(ServerConfig::_feature_report_user_end_policy.load())) {
                            // if (error_code == 0 && random_sampling_per_thousand(ServerConfig::_feature_report_user_end_policy.load())) {
                                do_feature_report(fetch_info->_feature_type, key, response_str);
                            }
                        }
                        else {
                            item_stat_ptr->report_redis_rpc(fetch_info->_cluster_id,error_code,cntl_ptr->latency_us(),0,0);
                        }
                        item_stat_ptr->report_up_rpc(fetch_info->_up_id, cluster_id, error_code, final_feat_str.size(), response_str.size());                       

                        int old = get_cond->fetch_sub(1);
                        HILOG_APP(WARNING) << " cluster: " << cluster_id << ", up: " << up_id << ", old: " << old << ", cost:"<<cntl_ptr->latency_us();
                        if (old == 1) {
                            BizLatency* lat = get_node_stat(context)->get_lat();
                            get_fetch_over->store(true);
                            if (get_fetch_over->load() && hash_fetch_over->load()) {
                                {
                                    BizLatencyGaurd lat_guard_dst(lat,LAT_STAGE_DESTROY);
                                } 
                                run_output_nodes_if_ready(context);
                            }
                        }
                    };
                    
                    redis_client->get_simple(key, callback, fetch_info->_time_out);
                    
                }
            }
            else {
                get_fetch_over->store(true);
            }

            if (!hash_fetch_map.empty()) {
                auto hash_cond = std::make_shared<std::atomic<int>>(hash_fetch_map.size());
                for (auto& cluster_feats : hash_fetch_map) {
                    

                    auto fetch_vec = cluster_feats.second;
                    std::vector<std::string> fields;
                    std::string key;
                    uint64_t time_out = 0;
                    std::string client_id;
                    for (size_t fetch_index = 0; fetch_index < fetch_vec.size(); fetch_index++) {
                        auto fetch_info = fetch_vec[fetch_index]; 
                        if (key.empty()) {
                            make_fetch_key(context,fetch_info,key);
                        }  
                        if (time_out == 0) {
                            time_out = fetch_info->_time_out;
                        } 
                        if (client_id.empty()) {
                            client_id = fetch_info->_redis_client_id;
                        }              
                        if(fetch_info->_expired_time){
                            std::shared_ptr< std::string> result = nullptr;
                            auto succ = get_string_feature_from_cache(fetch_info->_up_name,key,result);
                            if(succ){
                                std::string response = "";  
                                std::string final_feat_str = "";                         
                                FetchManager::instance().parse_redis_response(key,  fetch_info, response, *result,context->get_fs_context(),0, final_feat_str);
                                if (fetch_index == (fetch_vec.size()-1) && fields.size() == 0) {
                                    int old = hash_cond->fetch_sub(1);
                                    if (old == 1) {
                                        hash_fetch_over->store(true);
                                        if (get_fetch_over->load() && hash_fetch_over->load()) {
                                            run_output_nodes_if_ready(context);
                                        }
                                    }                                    
                                }
                                continue;                                
                            }
                        } 
                        fields.push_back(fetch_info->_prefix + fetch_info->_up_id);                    
                    }
                    auto field_ptr = std::make_shared<std::vector<std::string>>(fields);
                    auto fetch_vec_ptr = std::make_shared<std::vector<std::shared_ptr<const FetchInfo>>>(fetch_vec);

                    auto &cluster_id = cluster_feats.first;
                    
                    std::shared_ptr<RedisClient> redis_client;
                    redis_client = RedisClientManager::instance().get_client(client_id);
                    if (redis_client == nullptr) {
                        // todo 告警
                        HILOG_APP(ERROR) << "redis_client_id: " << client_id << " redis client not found";
                        int old = hash_cond->fetch_sub(1);
                        if (old == 1) {
                            hash_fetch_over->store(true);
                            if (get_fetch_over->load() && hash_fetch_over->load()) {
                                run_output_nodes_if_ready(context);
                            }
                            
                        }
                        continue;
                    }
                    
                    auto callback = [this, key, cluster_id, hash_cond, get_fetch_over, hash_fetch_over, context, field_ptr, fetch_vec_ptr]
                        (std::shared_ptr<brpc::RedisResponse> response, std::shared_ptr<brpc::Controller> cntl_ptr){  
                        int up_size = 0;                    
                        int error_code = 0;
                        auto scene_id = std::to_string(context->get_algo_scene_id());                                       
                        if (response == nullptr) {
                            HILOG_APP(WARNING) << "response is nullptr; send redis failed or timeout key:" << key
                            << " cluster_id: " << cluster_id;
                            error_code = -1;
                        } else if (response->reply_size() < 0) {
                            response.reset();
                            HILOG_APP(WARNING) << key << " reply_size: " << response->reply_size()
                            << " key:" << key  << " cluster_id: " << cluster_id;
                            error_code = -6;
                        } else if (response->reply(0).size() < 0) {
                            response.reset();
                            HILOG_APP(WARNING) << key << " reply_array_size: " << response->reply(0).size()
                            << " key:" << key  << " cluster_id: " << cluster_id;
                            error_code = -6;
                        } 
                        auto item_stat_ptr = get_node_stat(context);
                        if (response) {
                            for (size_t fetch_index = 0; fetch_index < fetch_vec_ptr->size(); fetch_index++) {
                                int final_error_code = error_code;
                                std::string response_str;
                                const auto fetch_info_ptr = (*fetch_vec_ptr)[fetch_index];
                                if (response->reply(0)[fetch_index].is_nil()) {
                                    response_str = "";
                                    final_error_code = -2;
                                    HILOG_APP(WARNING) << key << " reply is nil;" << " key:" << key << 
                                        " up_id: " << fetch_info_ptr->_up_id << " cluster_id: " << cluster_id;
                                } else if (!response->reply(0)[fetch_index].is_string()) {
                                    response_str = "";
                                    response.reset();
                                    final_error_code = -6;
                                    HILOG_APP(WARNING) << key << " reply is not a string; key:" << key << 
                                        " up_id: " << fetch_info_ptr->_up_id << " cluster_id: " << cluster_id;
                                } else {
                                    response_str.assign(response->reply(0)[fetch_index].data().data(), 
                                                        response->reply(0)[fetch_index].size()+1);                                    
                                    HILOG_APP(WARNING) << key << " redis data size: " << response->reply(0)[fetch_index].size() <<
                                         " up_id: " << fetch_info_ptr->_up_id << " cluster_id: " << cluster_id;
                                    final_error_code = 0;
                                    up_size += 1;
                                }
                                std::string value = "";
                                std::string final_feat_str = "";
                                int64_t start_parse_time = gettimeofday_ms();
                                FetchManager::instance().parse_redis_response(key,fetch_info_ptr, response_str, value,context->get_fs_context(),final_error_code, final_feat_str);
                                int64_t parse_time = gettimeofday_ms() - start_parse_time;
                                MonitorMgr::redis_report_percent(STRING_DEFAULT, cluster_id, final_error_code, "parse_total_cost",
                                                         parse_time, FsSource::REDIS, scene_id, fetch_info_ptr->_up_id);
                                
                                // MonitorMgr::redis_report_percent(STRING_DEFAULT, context->get_rank_request()->, final_error_code, "parse_total_cost",
                                //                          parse_time, FsSource::REDIS, std::to_string(context->get_algo_scene_id()), fetch_info_ptr->_up_id);
                                item_stat_ptr->report_up_rpc(fetch_info_ptr->_up_id, cluster_id, final_error_code, final_feat_str.size(), response_str.size());
                                if (fetch_info_ptr->_dump_missed_feat == "true" && final_error_code != 0) {
                                    context->set_has_missed_query(true);
                                }

                                // 测试环境特征上报
                                if (final_error_code == 0 && ServerConfig::_feature_report_enable.load() && ServerConfig::_feature_report_running.load() && random_sampling_per_thousand(ServerConfig::_feature_report_user_end_policy.load())) {
                                // if (final_error_code == 0 && random_sampling_per_thousand(ServerConfig::_feature_report_user_end_policy.load())) {
                                    do_hash_feature_report(fetch_info_ptr->_feature_type, key, fetch_info_ptr->_prefix + fetch_info_ptr->_up_id, response_str);
                                }
                            }
                        }
                        if (response) {
                            item_stat_ptr->report_redis_rpc(cluster_id, 0, cntl_ptr->latency_us(), up_size, response->ByteSize());
                        }
                        else {
                            item_stat_ptr->report_redis_rpc(cluster_id, error_code, cntl_ptr->latency_us(), 0, 0);
                        }
                        

                        int old = hash_cond->fetch_sub(1);
                        HILOG_APP(WARNING) << " cluster: " << cluster_id << ", old: " << old << ", cost:" <<cntl_ptr->latency_us();
                        if (old == 1) {
                            BizLatency* lat = get_node_stat(context)->get_lat();
                            
                            hash_fetch_over->store(true);
                            if (get_fetch_over->load() && hash_fetch_over->load()) {
                                {
                                    BizLatencyGaurd lat_guard_dst(lat,LAT_STAGE_DESTROY);
                                } 
                                run_output_nodes_if_ready(context);
                            }
                        }
                    };
                    
                    redis_client->hmget_multiple_fields(key, *field_ptr, callback, time_out);
                }
                
            }   
            else {
                hash_fetch_over->store(true);
            }
       
            return ERROR_SUCCESS;
        }

        bool  RedisService::get_fetch(CoreContextPtr context, std::vector<std::shared_ptr<const FetchInfo> >& fetch_vec, std::unordered_map<std::string, std::vector<std::shared_ptr<const FetchInfo> >>& hash_fetch_map){
             return false;
        }

        bool RedisService::make_fetch_key(CoreContextPtr context,std::shared_ptr<const FetchInfo> fetch,std::string&key){
            return false;
        }


        bool RedisService::random_sampling_per_thousand(int32_t end_policy) {
            static std::random_device rd;
            static std::mt19937 gen(rd());
            static std::uniform_int_distribution<> dis = std::uniform_int_distribution<>(1, 1000);
            int randomValue = dis(gen);
            return randomValue <= end_policy;
        }

        void RedisService::do_feature_report(const std::string& fea_type, const std::string& key, const std::string& response) {
            std::string report_msg;
            report_msg.reserve(fea_type.size() + key.size() + 2 + 4 * ((response.size() + 2) / 3));
            report_msg.append(fea_type).append(" ").append(key).append(" ").append(base64_encode(response));
            HILOG_APP(INFO) << "[feature report] key-value:" << report_msg;
            if (!ServerConfig::_feature_report_kafka_name.empty()) {
                hikafka::KafkaMessage* kafkaMessage = new hikafka::KafkaMessage();
                kafkaMessage->key = ServerConfig::_feature_report_kafka_key;
                kafkaMessage->value.assign(report_msg.begin(),report_msg.end());
                hikafka::KafkaHelper::getInstance().sendMsg(ServerConfig::_feature_report_kafka_name, kafkaMessage);
            }
        }

        void RedisService::do_hash_feature_report(const std::string& fea_type, const std::string& key, const std::string& field, const std::string& response) {
            std::string report_msg;
            report_msg.reserve(fea_type.size() + key.size() + field.size() + 3 + 4 * ((response.size() + 2) / 3));
            report_msg.append(fea_type).append(" ").append(key).append(" ").append(field).append(" ").append(base64_encode(response));
            HILOG_APP(INFO) << "[feature report] key-field-value:" << report_msg;
            if (!ServerConfig::_feature_report_kafka_name.empty()) {
                hikafka::KafkaMessage* kafkaMessage = new hikafka::KafkaMessage();
                kafkaMessage->key = ServerConfig::_feature_report_kafka_key;
                kafkaMessage->value.assign(report_msg.begin(),report_msg.end());
                hikafka::KafkaHelper::getInstance().sendMsg(ServerConfig::_feature_report_kafka_name, kafkaMessage);
            }
        }
}
