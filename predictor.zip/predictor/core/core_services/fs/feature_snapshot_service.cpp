#include "core/core_services/fs/feature_snapshot_service.h"
#include "core/core_context/core_context.h"
#include "core/core_context/monitor_context.h"
#include "core/core_services/fs/redis_client/redis_client.h"
#include "core/core_services/fs/redis_client/redis_client_manager.h"
#include "hlframe/context.h"
#include "hlframe/graph_context.h"
#include "hlframe/register.h"
#include <brpc/controller.h>
#include <brpc/redis.h>
#include <charsets.h>
#include <config_xml.h>
#include <cstdint>
#include <exception>
#include <log_helper.h>
#include <memory>
#include <zstd.h> 
#include <boost/algorithm/string.hpp>
namespace Core {
SERVICE_REGISTER(FeatureSnapshotService);

void FeatureSnapshotService::initialize(ConfigXmlPtr xml) {
    xml->attr<std::string>("redis_client", _snapshot_redis_id, "");
    xml->attr<int32_t>("redis_timeout", _snapshot_timeout_ms, 100);
    xml->attr<int32_t>("redis_max_retry", _snapshot_max_retry, 0);
    xml->attr<std::string>("add_algosceneid", _add_algosceneid, "false");
    std::string no_snapshot_slots_sets;
    xml->attr<std::string>("no_snapshot_slots", no_snapshot_slots_sets); 
    if (!no_snapshot_slots_sets.empty()) {
        std::unordered_set<std::string> slots; 
        boost::split(slots, no_snapshot_slots_sets, boost::is_any_of(",")); 
        for (const std::string& s : slots) {
            int64_t slot = std::stoll(s);
            _no_snapshot_slots.insert(slot);
        }
    }
    initialize_xml(xml);
}

void FeatureSnapshotService::initialize_xml(ConfigXmlPtr xml) { }

void FeatureSnapshotService::initialize(GraphContextPtr context) {
    auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
    ctx->get_monitor_context()->alloc_node(get_name());
}

int FeatureSnapshotService::do_service(GraphContextPtr context) {
    auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
    int32_t ret = 0;
    BizLatency* lat = get_node_stat(ctx)->get_lat();
    try {
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);
            ret = process(ctx);
        }
        {
            BizLatencyGaurd lat_guard(lat,LAT_STAGE_DESTROY);
        }
    } catch(const std::exception& e) {
        HILOG_APP(ERROR)<<LOG_HEAD(ctx) <<get_name() << "do service fail: " << ret << ","<<e.what();
        ret = -1;
    }
    return ret;
}

int FeatureSnapshotService::process(CoreContextPtr context) {
    auto item_stat_ptr = get_node_stat(context);
    std::string snapshot_key;
    make_redis_key(context, snapshot_key);
    std::shared_ptr<RedisClient> redis_client = RedisClientManager::instance().get_client(_snapshot_redis_id);
    if(redis_client == nullptr) {
        HILOG_APP(ERROR) << LOG_HEAD(context) << "snapshot redis cliend: " << _snapshot_redis_id << " not found";
        run_output_nodes_if_ready(context);
        return -1;
    }

    if(!redis_client->_running) {
        HILOG_APP(ERROR) << LOG_HEAD(context) << "snapshot redis cliend: " << _snapshot_redis_id << " not running";
        run_output_nodes_if_ready(context);
        return -2;
    }

    StatRpc sr;
    sr._source=FsSource::REDIS;
    item_stat_ptr->_redis_extra_map.insert({"get_feature_snapshot",sr});

    auto callback = [this, snapshot_key, context](
        std::shared_ptr<brpc::RedisResponse> response,
        std::shared_ptr<brpc::Controller> cntl
    ){
        int error_code = 0;
        if (response == nullptr) {
            HILOG_APP(WARNING) << "response is nullptr; send redis failed or timeout key:" << snapshot_key
            << " redis_id: " << this->_snapshot_redis_id;
            error_code = -1;
        } else if (response->reply_size() < 0) {
            response.reset();
            HILOG_APP(WARNING) << snapshot_key << " reply_size: " << response->reply_size()
                << " key:" << snapshot_key  << " redis_id: " << this->_snapshot_redis_id;
            error_code = -6;
        } else if (response->reply(0).is_nil()) {
            response.reset();
            error_code = -2;
            HILOG_APP(WARNING) << snapshot_key << ": reply is nil;" 
                << " redis_id: " << this->_snapshot_redis_id;
        } else if (!response->reply(0).is_string()) {
            response.reset();
            error_code = -6;
            HILOG_APP(WARNING) << snapshot_key << ": reply is not a string;" 
                << " redis_id: " << this->_snapshot_redis_id;
        } else {
            HILOG_APP(WARNING) << snapshot_key << " redis data size: " 
                << response->reply(0).data().size()<< " redis_id: " << this->_snapshot_redis_id;
            error_code = 0;
        }

        auto stat_ptr = this->get_node_stat(context);
        std::string cluster;
        if (std::find(_no_snapshot_slots.begin(), _no_snapshot_slots.end(), context->get_slot_id()) != _no_snapshot_slots.end()) {
            cluster = "no_snapshot_get_feature";
        }
        else {
            cluster = "get_feature_snapshot";
        }

        if (response) {
            stat_ptr->report_redis_rpc(cluster,error_code,cntl->latency_us(), 1, response->ByteSize());
        }
        else {
            stat_ptr->report_redis_rpc(cluster,error_code,cntl->latency_us(), 0, 0);
        }
        std::string value = "";
        this->prase_snapshot_feature(
            snapshot_key, response, value, context->get_fs_context(), error_code
        );

        if(error_code == 0) {
            // TODO: monitor
        }

        BizLatency* lat = get_node_stat(context)->get_lat();
        BizLatencyGaurd lat_guard_dst(lat,LAT_STAGE_DESTROY);
        run_output_nodes_if_ready(context);
    };

    redis_client->get_simple(
        snapshot_key, 
        callback, 
        _snapshot_timeout_ms, 
        _snapshot_max_retry
    );
    return 0;
}

void FeatureSnapshotService::make_redis_key(CoreContextPtr context, std::string& key) {
    if (_add_algosceneid == "true") {
        // redis_key: phx_{$reqid}_{$slotid}_{$algosceneid}
        key.append("phx_");
        key.append(context->get_req_id());
        key.append("_").append(std::to_string(context->get_slot_id()));
        key.append("_").append(std::to_string(context->get_algo_scene_id()));
    }
    else {
        // redis_key: phx_{$reqid}_{$slotid}
        key.append("phx_");
        key.append(context->get_req_id());
        key.append("_").append(std::to_string(context->get_slot_id()));
    }
    
}

void FeatureSnapshotService::prase_snapshot_feature(
    const std::string& key,
    std::shared_ptr<brpc::RedisResponse> response,
    const std::string& value,
    FSContextPtr fs_context,
    int32_t error_code
) {
    try{
        if(response) {
            bool suc = false;
            std::string uncompress_data_str = "";

            bool ok = zstd_decompress(
                uncompress_data_str,
                response->reply(0).data().data(), 
                response->reply(0).data().size()
            );

            if(ok) {
                auto feature_snapshot = std::make_shared<::phx::FeRequest>();
                suc = feature_snapshot->ParseFromArray(uncompress_data_str.c_str(), uncompress_data_str.size());
                if(!suc) {
                    HILOG_APP(INFO) << "ParseFromArray error: " << " key:"<<key;
                }
                fs_context->_snapshot_feature = feature_snapshot;
            } else {
                HILOG_APP(ERROR) << "snapshot key: " << key << " zstd uncompress failed";
            }
        } else {
            HILOG_APP(WARNING) << "feature snapshot key: " << key << " redis resp is null, error_code: " << error_code;
        }
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << "prase_snapshot_feature failed! key: " << key << ": " << e.what();
    }
}

bool FeatureSnapshotService::zstd_decompress(
    std::string &uncompressed, 
    const void *src, 
    size_t srcSize
) {
    if(src == nullptr) {
        return false;
    }

    unsigned long long const decompressedSize = ZSTD_getFrameContentSize(src, srcSize);
    if (decompressedSize == ZSTD_CONTENTSIZE_ERROR) {
        return false;
    }
    if (decompressedSize == ZSTD_CONTENTSIZE_UNKNOWN) {
        return false;
    }

    uncompressed.resize(decompressedSize);

    size_t const dSize = ZSTD_decompress(&uncompressed[0], decompressedSize, src, srcSize);
    if (ZSTD_isError(dSize)) {
        return false;
    }

    return true;
}

bool FeatureSnapshotService::skip(GraphContextPtr context) {
    return false;
}

}