#ifndef _FS_CONCURRENT_MAP_H
#define _FS_CONCURRENT_MAP_H
#include "common/comm/concurrent_map.h"
#include <google/protobuf/message.h>
#include <map>
#include "common/comm/cachevalue_map.h"
#include "common/comm/double_buffer.h"
const int32_t INTERACT_CACHCE_COUNT = 1500*10000;

extern std::unordered_map<std::string,ConcurrentMap<std::string , std::shared_ptr<std::string> > > g_string_caches;
extern std::unordered_map<std::string,ConcurrentMap<std::string , std::shared_ptr<google::protobuf::Message> > > g_interact_message_caches;
extern std::unordered_map<std::string,ConcurrentMap<std::string , std::shared_ptr<google::protobuf::Message> > > g_item_nearline_message_caches;
extern std::unordered_map<std::string,ConcurrentMap<std::string , std::shared_ptr<google::protobuf::Message> > > g_black_message_caches;
extern std::unordered_map<std::string,DBuffer< common::CacheValueMap<std::string , std::shared_ptr<google::protobuf::Message> > > > g_double_message_caches;
extern std::unordered_map<std::string,ConcurrentMap<std::string , std::shared_ptr<google::protobuf::Message> > > g_default_message_caches;

void add_string_cache(const std::string&fg);
std::shared_ptr<std::unordered_map<std::string,std::shared_ptr< std::string> > > 
    get_string_feature_from_cache(const std::string&fg,const std::vector<std::string> & items,std::vector<std::string>& timeout_vec);
bool get_string_feature_from_cache(const std::string&fg,const std::string&key,std::shared_ptr< std::string> ret);
bool put_string_feature_into_cache(const std::string&fg,const std::string&key,const std::shared_ptr< std::string>& ret,int32_t expire = 0);
void put_string_feature_into_cache(const std::string&fg,const std::unordered_map<std::string, std::shared_ptr< CacheValue<std::shared_ptr< std::string> >  >  >& map);

void add_message_cache(const std::string&fg);
int32_t get_message_cache_size(const std::string&fg);
void get_message_keys(const std::string&fg,std::map<size_t ,std::vector<std::string>>&valide_keys,std::map<size_t ,std::vector<std::string>>&expire_keys);
void get_expire_message_key(const std::string&fg,std::map<size_t ,std::vector<std::string>>&expire_keys);
void expire_message_key(const std::string&fg,const std::map<size_t ,std::vector<std::string>>&expire_keys);
std::shared_ptr<google::protobuf::Message> get_message_feature_from_cache(const std::string&fg,const std::string&key);
std::shared_ptr<std::unordered_map<std::string,std::shared_ptr<google::protobuf::Message> > > 
    get_message_feature_from_cache(const std::string&fg,const std::vector<std::string> & items,std::vector<std::string>& timeout_vec);
bool put_message_feature_into_cache(const std::string&fg,const std::string&key,const std::shared_ptr<google::protobuf::Message>& ret,int32_t expire = 0);
void put_message_feature_into_cache(const std::string&fg,const std::unordered_map<std::string,  std::shared_ptr< CacheValue<std::shared_ptr<google::protobuf::Message> >  > >& map);

void add_black_message_cache(const std::string&fg);
int32_t get_black_message_cache_size(const std::string&fg);
void get_black_expire_message_key(const std::string&fg,std::map<size_t ,std::vector<std::string>>&expire_keys);
void black_expire_message_key(const std::string&fg,const std::map<size_t ,std::vector<std::string>>&expire_keys);
std::shared_ptr<google::protobuf::Message> get_black_message_feature_from_cache(const std::string&fg,const std::string&key);
bool put_black_message_feature_into_cache(const std::string&fg,const std::string&key,const std::shared_ptr<google::protobuf::Message>& ret,int32_t expire);


void add_dbuffer_message_cache(const std::string&fg);
int32_t get_dbuffer_message_cache_size(const std::string&fg);
void get_dbuffer_message_keys(const std::string&fg,std::map<size_t ,std::vector<std::string>>&valide_keys,std::map<size_t ,std::vector<std::string>>&expire_keys);
std::shared_ptr<google::protobuf::Message> get_curr_dbuffer_message_feature_from_cache(const std::string&fg,const std::string&key);
std::shared_ptr<std::unordered_map<std::string,std::shared_ptr<google::protobuf::Message> > > 
    get_curr_dbuffer_message_feature_from_cache(const std::string&fg,const std::vector<std::string> & items,std::vector<std::string>& timeout_vec);
bool put_bak_dbuffer_message_feature_into_cache(const std::string&fg,const std::string&key,const std::shared_ptr<google::protobuf::Message>& ret,int32_t expire = 0);
void put_bak_dbuffer_message_feature_into_cache(const std::string&fg,const std::unordered_map<std::string,  std::shared_ptr< CacheValue<std::shared_ptr<google::protobuf::Message> >  > >& map);
bool put_curr_dbuffer_message_feature_into_cache(const std::string&fg,const std::string&key,const std::shared_ptr<google::protobuf::Message>& ret,int32_t expire = 0);
void put_curr_dbuffer_message_feature_into_cache(const std::string&fg,const std::unordered_map<std::string,  std::shared_ptr< CacheValue<std::shared_ptr<google::protobuf::Message> >  > >& map);
void exchange_dbuffer_message_cache(const std::string&fg);



void add_item_nearline_message_cache(const std::string&fg);
int32_t get_item_nearline_message_cache_size(const std::string&fg);
void get_item_nearline_message_keys(const std::string&fg,std::map<size_t ,std::vector<std::string>>&valide_keys,std::map<size_t ,std::vector<std::string>>&expire_keys);
void get_item_nearline_expire_message_key(const std::string&fg,std::map<size_t ,std::vector<std::string>>&expire_keys);
void expire_item_nearline_message_key(const std::string&fg,const std::map<size_t ,std::vector<std::string>>&expire_keys);
std::shared_ptr<google::protobuf::Message> get_item_nearline_message_feature_from_cache(const std::string&fg,const std::string&key);
std::shared_ptr<std::unordered_map<std::string,std::shared_ptr<google::protobuf::Message> > > 
    get_item_nearline_message_feature_from_cache(const std::string&fg,const std::vector<std::string> & items,std::vector<std::string>& timeout_vec);
bool put_item_nearline_message_feature_into_cache(const std::string&fg,const std::string&key,const std::shared_ptr<google::protobuf::Message>& ret,int32_t expire = 0);
void put_item_nearline_message_feature_into_cache(const std::string&fg,const std::unordered_map<std::string,  std::shared_ptr< CacheValue<std::shared_ptr<google::protobuf::Message> >  > >& map);


#endif
