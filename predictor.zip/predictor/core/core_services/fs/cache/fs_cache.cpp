#include "fs_cache.h"
#include "common/hilog/log_helper.h"

std::unordered_map<std::string,ConcurrentMap<std::string , std::shared_ptr<std::string> > > g_string_caches = {};
std::unordered_map<std::string,ConcurrentMap<std::string , std::shared_ptr<google::protobuf::Message> > > g_interact_message_caches = {};
std::unordered_map<std::string,ConcurrentMap<std::string , std::shared_ptr<google::protobuf::Message> > > g_item_nearline_message_caches = {};
std::unordered_map<std::string,ConcurrentMap<std::string , std::shared_ptr<google::protobuf::Message> > > g_black_message_caches = {};
std::unordered_map<std::string,DBuffer< common::CacheValueMap<std::string , std::shared_ptr<google::protobuf::Message> > > > g_double_message_caches = {};

void add_string_cache(const std::string&fg){
    g_string_caches.insert({fg, ConcurrentMap<std::string,std::shared_ptr<std::string> >(1471)});
}

bool get_string_feature_from_cache(const std::string&fg,const std::string&key,std::shared_ptr< std::string> ret){
    auto it = g_string_caches.find(fg);
    if(it != g_string_caches.end()){
        auto msg_ptr = it->second.get(key);
        if(msg_ptr == nullptr) return  false; 
        ret = msg_ptr->get_val();
    }
    return true;
}


std::shared_ptr<std::unordered_map<std::string,std::shared_ptr< std::string> > > 
    get_string_feature_from_cache(const std::string&fg,const std::vector<std::string> & items,std::vector<std::string>& timeout_vec){
    auto result = std::make_shared<std::unordered_map<std::string,std::shared_ptr< std::string> > >();
    auto it = g_string_caches.find(fg);
    if(it != g_string_caches.end()){
        return it->second.get(items,timeout_vec);
    }
    return result;
}

bool put_string_feature_into_cache(const std::string&fg,const std::string& key,const std::shared_ptr<std::string>& ret,int32_t expire){
    auto it = g_string_caches.find(fg);
    if(it != g_string_caches.end()){
        auto cache_v = std::make_shared< CacheValue< std::shared_ptr<std::string> > >(ret,expire);
        it->second.put(key,cache_v);
        return true;
    }
    return false;
}

void put_string_feature_into_cache(const std::string&fg,const std::unordered_map<std::string, std::shared_ptr< CacheValue<std::shared_ptr< std::string> >  >  >& map){
    auto it = g_string_caches.find(fg);
    if(it != g_string_caches.end()){
        return it->second.put(map);
    }
    return ;
}


void add_message_cache(const std::string&fg){
     g_interact_message_caches.insert({fg, ConcurrentMap<std::string,std::shared_ptr<google::protobuf::Message> >(1471)});
     auto&msg_cache = g_double_message_caches[fg];
    //  msg_cache.get_current_obj()->init(1471);
    //  msg_cache.get_bak_obj()->init(1471);
}

int32_t get_message_cache_size(const std::string&fg){
    auto it = g_interact_message_caches.find(fg);
    if(it != g_interact_message_caches.end()){
        return it->second.size();
    }
    return 0;
}

void get_expire_message_key(const std::string&fg,std::map<size_t ,std::vector<std::string>>&expire_keys){
    auto it = g_interact_message_caches.find(fg);
    if(it != g_interact_message_caches.end()){
        return it->second.expire_keys(expire_keys);
    }
}

void get_message_keys(const std::string&fg,std::map<size_t ,std::vector<std::string>>&valide_keys,std::map<size_t ,std::vector<std::string>>&expire_keys){
    auto it = g_interact_message_caches.find(fg);
    if(it != g_interact_message_caches.end()){
        return it->second.keys(valide_keys,expire_keys);
    }
}

void expire_message_key(const std::string&fg,const std::map<size_t ,std::vector<std::string>>&expire_keys){
    auto it = g_interact_message_caches.find(fg);
    if(it != g_interact_message_caches.end()){
        return it->second.expire(expire_keys);
    }
}

std::shared_ptr<google::protobuf::Message> get_message_feature_from_cache(const std::string&fg,const std::string&key){
    auto it = g_interact_message_caches.find(fg);
    if(it != g_interact_message_caches.end()){
        auto msg_ptr = it->second.get(key);
        if(msg_ptr == nullptr) return  nullptr; 
        return msg_ptr->get_val();
    }

    return nullptr;
}

std::shared_ptr<std::unordered_map<std::string,std::shared_ptr<google::protobuf::Message> > > 
    get_message_feature_from_cache(const std::string&fg,const std::vector<std::string> & items,std::vector<std::string>& timeout_vec){
    auto result = std::make_shared<std::unordered_map<std::string,std::shared_ptr< google::protobuf::Message> > >();
    auto it = g_interact_message_caches.find(fg);
    if(it != g_interact_message_caches.end()){
        return it->second.get(items,timeout_vec);
    }
    return result;
}

bool put_message_feature_into_cache(const std::string&fg,const std::string&key,const std::shared_ptr<google::protobuf::Message>& ret,int32_t expire){
    auto it = g_interact_message_caches.find(fg);
    if(it != g_interact_message_caches.end()){
        auto cache_v = std::make_shared< CacheValue< std::shared_ptr<google::protobuf::Message> > >(ret,expire);
        it->second.put(key,cache_v);
        return true;
    }
    return false;
}

void put_message_feature_into_cache(const std::string&fg,const std::unordered_map<std::string,  std::shared_ptr< CacheValue<std::shared_ptr<google::protobuf::Message> >  > >& map){
    auto it = g_interact_message_caches.find(fg);
    if(it != g_interact_message_caches.end()){
        return it->second.put(map);
    }
    return ;
}

void add_black_message_cache(const std::string&fg){
     g_black_message_caches.insert({fg, ConcurrentMap<std::string,std::shared_ptr<google::protobuf::Message> >(1471)});
}

int32_t get_black_message_cache_size(const std::string&fg){
    auto it = g_black_message_caches.find(fg);
    if(it != g_black_message_caches.end()){
        return it->second.size();
    }
    return 0;
}

void get_black_expire_message_key(const std::string&fg,std::map<size_t ,std::vector<std::string>>&expire_keys){
    auto it = g_black_message_caches.find(fg);
    if(it != g_black_message_caches.end()){
        return it->second.expire_keys(expire_keys);
    }
}

void black_expire_message_key(const std::string&fg,const std::map<size_t ,std::vector<std::string>>&expire_keys){
    auto it = g_black_message_caches.find(fg);
    if(it != g_black_message_caches.end()){
        return it->second.expire(expire_keys);
    }
}

std::shared_ptr<google::protobuf::Message> get_black_message_feature_from_cache(const std::string&fg,const std::string&key){
    auto it = g_black_message_caches.find(fg);
    if(it != g_black_message_caches.end()){
        auto msg_ptr = it->second.get(key);
        if(msg_ptr == nullptr) return  nullptr;
        return msg_ptr->get_val();
    }
    return nullptr;
}

bool put_black_message_feature_into_cache(const std::string&fg,const std::string&key,const std::shared_ptr<google::protobuf::Message>& ret,int32_t expire){
    auto it = g_black_message_caches.find(fg);
    if(it != g_black_message_caches.end()){
        auto cache_v = std::make_shared< CacheValue< std::shared_ptr<google::protobuf::Message> > >(ret,expire);
        it->second.put(key,cache_v);
        return true;
    }
    return false;
}

void add_dbuffer_message_cache(const std::string&fg){
     auto&msg_cache = g_double_message_caches[fg];
    //  msg_cache.get_current_obj()->init(1471);
    //  msg_cache.get_bak_obj()->init(1471);
}

int32_t get_dbuffer_message_cache_size(const std::string&fg){
    auto it = g_double_message_caches.find(fg);
    if(it != g_double_message_caches.end()){
        return it->second.get_current_obj()->size();
    }
    return 0;
}


void get_dbuffer_message_keys(const std::string&fg, std::vector<std::string>&valide_keys, std::vector<std::string>&expire_keys){
    auto it = g_double_message_caches.find(fg);
    if(it != g_double_message_caches.end()){
        return it->second.get_current_obj()->keys(valide_keys,expire_keys);
    }
}



std::shared_ptr<google::protobuf::Message> get_curr_dbuffer_message_feature_from_cache(const std::string&fg,const std::string&key){
    auto it = g_double_message_caches.find(fg);
    if(it != g_double_message_caches.end()){
        auto cach_val_ptr = it->second.get_current_obj()->get(key);
        if(cach_val_ptr == nullptr) return nullptr;
        return cach_val_ptr->get_val();
    }
    return nullptr;
}

std::shared_ptr<std::unordered_map<std::string,std::shared_ptr<google::protobuf::Message> > > 
    get_curr_dbuffer_message_feature_from_cache(const std::string&fg,const std::vector<std::string> & items,
        std::vector<std::string>& timeout_vec){
    auto result = std::make_shared<std::unordered_map<std::string,std::shared_ptr< google::protobuf::Message> > >();
    auto it = g_double_message_caches.find(fg);
    if(it != g_double_message_caches.end()){
        return it->second.get_current_obj()->get(items,timeout_vec);
    }
    return result;
}

bool put_bak_dbuffer_message_feature_into_cache(const std::string&fg,const std::string&key,
    const std::shared_ptr<google::protobuf::Message>& ret,int32_t expire){
    auto it = g_double_message_caches.find(fg);
    if(it != g_double_message_caches.end()){
        auto cache_v = std::make_shared< CacheValue< std::shared_ptr<google::protobuf::Message> > >(ret,expire);
        it->second.get_bak_obj()->put(key,cache_v);
        return true;
    }
    return false;
}

void put_bak_dbuffer_message_feature_into_cache(const std::string&fg,
const std::unordered_map<std::string,  std::shared_ptr< CacheValue<std::shared_ptr<google::protobuf::Message> >  > >& map){
    auto it = g_double_message_caches.find(fg);
    if(it != g_double_message_caches.end()){
        return it->second.get_bak_obj()->put(map);
    }
    return ;
}

void exchange_dbuffer_message_cache(const std::string&fg){
    auto it = g_double_message_caches.find(fg);
    if(it != g_double_message_caches.end()){
        return it->second.change();
    }
    return ;
}

bool put_curr_dbuffer_message_feature_into_cache(const std::string&fg,const std::string&key,
        const std::shared_ptr<google::protobuf::Message>& ret,int32_t expire ){
    auto it = g_double_message_caches.find(fg);
    if(it != g_double_message_caches.end()){
        auto cache_v = std::make_shared< CacheValue< std::shared_ptr<google::protobuf::Message> > >(ret,expire);
        it->second.get_current_obj()->put(key,cache_v);
        return true;
    }
    return false;
}

void put_curr_dbuffer_message_feature_into_cache(const std::string&fg,
    const std::unordered_map<std::string,  std::shared_ptr< CacheValue<std::shared_ptr<google::protobuf::Message> >  > >& map){
    auto it = g_double_message_caches.find(fg);
    if(it != g_double_message_caches.end()){
        return it->second.get_current_obj()->put(map);
    }
    return ;
}


//item_nearline
void add_item_nearline_message_cache(const std::string&fg){
     g_item_nearline_message_caches.insert({fg, ConcurrentMap<std::string,std::shared_ptr<google::protobuf::Message> >(1471)});
     auto&msg_cache = g_double_message_caches[fg];
    //  msg_cache.get_current_obj()->init(1471);
    //  msg_cache.get_bak_obj()->init(1471);
}

int32_t get_item_nearline_message_cache_size(const std::string&fg){
    auto it = g_item_nearline_message_caches.find(fg);
    if(it != g_item_nearline_message_caches.end()){
        return it->second.size();
    }
    return 0;
}

void get_item_nearline_expire_message_key(const std::string&fg,std::map<size_t ,std::vector<std::string>>&expire_keys){
    auto it = g_item_nearline_message_caches.find(fg);
    if(it != g_item_nearline_message_caches.end()){
        return it->second.expire_keys(expire_keys);
    }
}

void get_item_nearline_message_keys(const std::string&fg,std::map<size_t ,std::vector<std::string>>&valide_keys,std::map<size_t ,std::vector<std::string>>&expire_keys){
    auto it = g_item_nearline_message_caches.find(fg);
    if(it != g_item_nearline_message_caches.end()){
        return it->second.keys(valide_keys,expire_keys);
    }
}

void expire_item_nearline_message_key(const std::string&fg,const std::map<size_t ,std::vector<std::string>>&expire_keys){
    auto it = g_item_nearline_message_caches.find(fg);
    if(it != g_item_nearline_message_caches.end()){
        return it->second.expire(expire_keys);
    }
}

std::shared_ptr<google::protobuf::Message> get_item_nearline_message_feature_from_cache(const std::string&fg,const std::string&key){
    auto it = g_item_nearline_message_caches.find(fg);
    if(it != g_item_nearline_message_caches.end()){
        auto msg_ptr = it->second.get(key);
        if(msg_ptr == nullptr) return  nullptr; 
        return msg_ptr->get_val();
    }

    return nullptr;
}

std::shared_ptr<std::unordered_map<std::string,std::shared_ptr<google::protobuf::Message> > > 
    get_item_nearline_message_feature_from_cache(const std::string&fg,const std::vector<std::string> & items,std::vector<std::string>& timeout_vec){
    auto result = std::make_shared<std::unordered_map<std::string,std::shared_ptr< google::protobuf::Message> > >();
    auto it = g_item_nearline_message_caches.find(fg);
    if(it != g_item_nearline_message_caches.end()){
        return it->second.get(items,timeout_vec);
    }
    return result;
}

bool put_item_nearline_message_feature_into_cache(const std::string&fg,const std::string&key,const std::shared_ptr<google::protobuf::Message>& ret,int32_t expire){
    auto it = g_item_nearline_message_caches.find(fg);
    if(it != g_item_nearline_message_caches.end()){
        auto cache_v = std::make_shared< CacheValue< std::shared_ptr<google::protobuf::Message> > >(ret,expire);
        it->second.put(key,cache_v);
        return true;
    }
    return false;
}

void put_item_nearline_message_feature_into_cache(const std::string&fg,const std::unordered_map<std::string,  std::shared_ptr< CacheValue<std::shared_ptr<google::protobuf::Message> >  > >& map){
    auto it = g_item_nearline_message_caches.find(fg);
    if(it != g_item_nearline_message_caches.end()){
        return it->second.put(map);
    }
    return ;
}

