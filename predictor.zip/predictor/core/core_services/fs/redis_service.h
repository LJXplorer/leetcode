#ifndef _CORE_REDIS_SERVICES_FS_H
#define _CORE_REDIS_SERVICES_FS_H
#include "core/core_services/base_service/service_info.h"
#include "core/core_context/core_context.h"
#include "core/core_services/fs/fetch/fetch_manager.h"
#include "google/protobuf/message.h"
namespace Core {
    class RedisService : public ServiceBaseInfo{
    public:
        RedisService() {
        }

        ~RedisService(){

        }

        virtual void initialize(ConfigXmlPtr xml);
        virtual void initialize_xml(ConfigXmlPtr xml);
        virtual void initialize(GraphContextPtr context);
        virtual int do_service(GraphContextPtr context);
        virtual const Node_Type type() {
                return NODE_TYPE_IO ;
        }
    private:
        virtual int process(CoreContextPtr context);
        virtual bool get_fetch(CoreContextPtr context, std::vector<std::shared_ptr<const FetchInfo> >& fetch_vec, std::unordered_map<std::string, std::vector<std::shared_ptr<const FetchInfo> >>& hash_fetch_map);
        virtual bool make_fetch_key(CoreContextPtr context,std::shared_ptr<const FetchInfo> fetch,std::string&key);
        bool random_sampling_per_thousand(int32_t end_policy);
        void do_feature_report(const std::string& fea_type, const std::string& key, const std::string& response);
        void do_hash_feature_report(const std::string& fea_type, const std::string& key, const std::string& field, const std::string& response);
    };

    

}

#endif
