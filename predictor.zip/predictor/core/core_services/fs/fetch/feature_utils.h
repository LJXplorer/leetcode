#pragma once
#include "common/comm/str_utils.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/fs/cache/fs_cache.h"
#include <cstdint>
#include <debug_utils.h>
#include <google/protobuf/descriptor.h>
#include <log_helper.h>
#include <memory>
#include <string>
#include "core/core_services/fs/fetch/fetch_manager.h"
#include "core/core_context/core_context.h"
namespace ai_feature {

inline const std::string kGlobalStringDefaultValue = "默认值";
inline const int32_t _SEED = 0x7f3a21eaL;
inline const int32_t _ONE_HUNDRED = 100;

inline bool ContainsAllowScene(const std::shared_ptr<const Core::FetchInfo>& f, const Core::CoreContextPtr context) {
  if (!f->_allow_scene.empty() && context->get_rank_request()->predictorslotinfo().algosceneid() != 0) {
    return std::find(f->_allow_scene.begin(), f->_allow_scene.end(), context->get_rank_request()->predictorslotinfo().algosceneid()) != f->_allow_scene.end();
  }
  return true;
}

inline bool selectFeature(const std::shared_ptr<const Core::FetchInfo>& f, const Core::CoreContextPtr context) {
  return ContainsAllowScene(f, context);
}

} // namespace ai_feature