#include "fetch_manager.h"
#include "common/comm/config_xml.h"
#include "common/hilog/log_helper.h"
#include "butil/third_party/snappy/snappy.h"
#include "core/utils/defs.h"
// #include "feature_utils.h"
#include "core/core_services/fs/cache/fs_cache.h"
#include "common/comm/charsets.h"
#include "brpc/policy/gzip_compress.h"
#include <boost/algorithm/string.hpp>
#include "common/config/error_code.h"
#include "common/config/config_manager.h"
#include <memory>
#include <string>
#include <utility>
#include <zstd.h> 

using namespace hilog;
namespace Core {

    int FetchManager::init(const std::string& path){
        _fetch_conf_path = path;
        ConfigXml xml_conf;
        xml_conf.init(_fetch_conf_path);

        ConfigXml main;
        if (!xml_conf.find("main", main)) {
            HILOG_APP(WARNING) << "main not found in file: " << _fetch_conf_path;
            return -1;
        }

        auto fetch_meta = _fetch_meta.get_bak_obj();
        fetch_meta -> clear();

        //用户特征新配置
        bool has_user_next = true;
        ConfigXml user_xml;
        if (!main.child("cluster", user_xml)) {
            HILOG_APP(WARNING) << "user_feature not found in file: " << _fetch_conf_path;
            has_user_next = false;
        }
        while (has_user_next) {
            
            std::string cluster_id;
            std::string cmd;
            std::string feature_type;
            std::string sep;
            std::string redis_client_id;
            int time_out = 0;
            user_xml.attr<std::string>("id", cluster_id);
            user_xml.attr<std::string>("cmd", cmd);
            user_xml.attr<std::string>("redis_client_id", redis_client_id);
            user_xml.attr<std::string>("fea_type", feature_type);
            user_xml.attr<std::string>("sep", sep);
            user_xml.attr<int>("time_out", time_out);
            ConfigXml up_info;
            user_xml.child("up", up_info);
            bool has_next = false;
            do {
                auto  fetch_info = std::make_shared< FetchInfo>();
                fetch_info->_cluster_id = cluster_id;
                fetch_info->_cmd = cmd;
                fetch_info->_redis_client_id = redis_client_id;
                fetch_info->_feature_type = feature_type;
                fetch_info->_sep = sep;
                fetch_info->_time_out = time_out;
                up_info.attr<std::string>("id", fetch_info->_up_id);
                up_info.attr<std::string>("path", fetch_info->_path);
                std::string allow_scene_keys;
                up_info.attr<std::string>("allow", allow_scene_keys); 
                // allow_scene_keys不为空
                if (!allow_scene_keys.empty()) {
                    std::unordered_set<std::string> allow_scene_strings; 
                    boost::split(allow_scene_strings, allow_scene_keys, boost::is_any_of(",")); 
                    for (const std::string& scene_str : allow_scene_strings) {
                        // 将字符串转换为 int32_t
                        std::int32_t scene = std::stoi(scene_str); // 使用 std::stoi 进行转换
                        fetch_info->_allow_scene.insert(scene);
                    }
                }
                up_info.attr<std::string>("prefix", fetch_info->_prefix);
                up_info.attr<std::string>("compress", fetch_info->_compress);
                up_info.attr<std::string>("use_decode", fetch_info->_use_decode, "true");
                up_info.attr<std::string>("dump_missed_feat", fetch_info->_dump_missed_feat, "false");
                (fetch_meta->_fetch_info_vec).emplace_back(fetch_info);
                has_next = up_info.next("up", up_info);
            }while(has_next);
            has_user_next = user_xml.next("cluster", user_xml);
        }

        _fetch_meta.change();

        HILOG_APP(WARNING) << "fetcher _fetch_info_vec size: " << _fetch_meta.get_current_obj()->_fetch_info_vec.size()
        << ",fetcher fetch_item_info_vec size: " << _fetch_meta.get_current_obj()->_fetch_item_info_vec.size();

        return 0;
    }

    std::vector<std::shared_ptr<const FetchInfo>>& FetchManager::get_fetchs(){
        return (_fetch_meta.get_current_obj())->_fetch_info_vec;
    }

    std::vector<std::shared_ptr<const FetchInfo>>& FetchManager::get_item_fetchs(){
        return (_fetch_meta.get_current_obj())->_fetch_item_info_vec;
    }

    FetchMeta& FetchManager::get_cur_fetch_meta() {
        return *(_fetch_meta.get_current_obj());
    }
    
    void FetchManager::parse_redis_response(const std::string& key, std::shared_ptr<const FetchInfo> fetch,
                              const std::string& response, const std::string &value,
                              FSContextPtr context,int32_t error_code, std::string& final_feat_str){
        try {
            if (!response.empty()) {
                bool suc = false;
                std::shared_ptr<std::string> cacha_ret = nullptr;
                std::string conv_data;
                std::string uncompress_data_str = "";
                if (fetch->_use_decode == "true") {
                    int ret = charsets::to_88591(response.c_str(),response.size(),conv_data);
                }
                else {
                    conv_data.assign(response.c_str(), response.size()+1);
                }
                

                if (!fetch->_compress.empty()) {
                    auto ok = true;
                    if( fetch->_compress== "snappy"){
                        uncompress_data_str.reserve(conv_data.size() * 6); // snappy compress ratio is 22%, so mutilpy by 6
                        ok = butil::snappy::Uncompress(conv_data.c_str(), conv_data.size(),&uncompress_data_str);
                    }else if(fetch->_compress== "gzip"){
                        butil::IOBuf input,output;
                        input.append(conv_data);
                        ok = brpc::policy::GzipDecompress(input,&output);
                        output.copy_to(&uncompress_data_str);
                    } else if (fetch->_compress== "zstd") {
                        ok = zstd_decompress(uncompress_data_str, 
                            response.c_str(),response.size());
                    } else if (fetch->_compress== "none") {
                        uncompress_data_str = response.c_str();
                    }
                    
                    if(ok) {
                        if(!uncompress_data_str.empty()){
                            suc = fill_user_fea(fetch->_up_id, fetch->_path, key, context,uncompress_data_str.c_str(), uncompress_data_str.size(), final_feat_str);
                        } else {
                            suc = fill_user_fea(fetch->_up_id, fetch->_path, key, context, conv_data.c_str(), conv_data.size(), final_feat_str);
                        }
                    } else {
                        suc = fill_user_fea(fetch->_up_id, fetch->_path, key, context, conv_data.c_str(), conv_data.size(), final_feat_str);
                    }
                    if (!suc) {
                        //report;
                    }else if(fetch->_expired_time > 0){
                        if(ok){
                            cacha_ret = std::make_shared<std::string>(uncompress_data_str);
                        } else {
                            cacha_ret = std::make_shared<std::string>(response.c_str());
                        }                       
                    }
                    HILOG_APP(WARNING) << key << " parse redis response to message ; up: [" <<fetch->_up_id << "] uncompress ok: " << ok
                        <<",suc:"<<suc;
                } 
                else {
                    suc = fill_user_fea(fetch->_up_id, fetch->_path, key, context, conv_data.c_str(), conv_data.size(), final_feat_str);
                    if (!suc) {
                        //report;
                    }else if(fetch->_expired_time > 0){
                        cacha_ret = std::make_shared<std::string>(response.c_str());
                    } 
                    HILOG_APP(WARNING) << key << " parse redis response to message; up: [" << fetch->_up_id << "]"<<", suc:"<<suc;
                }
                //set cache
                if(fetch->_expired_time > 0){
                    put_string_feature_into_cache(fetch->_up_id,key,cacha_ret,fetch->_expired_time);
                }
            } else if (!value.empty()) {
                /*if (fetch->_compress == "snappy") {//已经解压
                    std::string uncompress_data_str = "";
                    butil::snappy::Uncompress(value.c_str(), value.size(), &uncompress_data_str);
                    bool suc = parse_func(key,uncompress_data_str.c_str(), uncompress_data_str.size(), context);
                    HILOG_APP(WARNING) <<key<< " parse redis prefix:" << fetch->_feature_name << " suc:"<<suc;
                } else */
                {
                    // bool suc = parse_func(key,value.c_str(), value.size(), context);
                    bool suc = fill_user_fea(fetch->_up_id, fetch->_path, key, context, value.c_str(), value.size(),final_feat_str);
                    HILOG_APP(WARNING) << key << " parse up_id:" << fetch->_up_id << " suc:"<<suc;
                }
            } else {
                bool suc = false/*parse_func(key,"", 0, context)*/;
                HILOG_APP(WARNING) << key << " empty parse up:" << fetch->_up_id << " suc:"<< response.empty()
                << " error_code:" << error_code;
            }
        } catch (...) {
            HILOG_APP(WARNING) << " parse response failed, up: " <<  fetch->_up_id << "key: " << key;
        }
    }

    bool FetchManager::zstd_decompress(std::string& uncompressed, const void *src, size_t srcSize) {
        if(src == nullptr) {
            return false;
        }
    
        unsigned long long const decompressedSize = ZSTD_getFrameContentSize(src, srcSize);
        if (decompressedSize == ZSTD_CONTENTSIZE_ERROR) {
            return false;
        }
        if (decompressedSize == ZSTD_CONTENTSIZE_UNKNOWN) {
            return false;
        }
    
        uncompressed.resize(decompressedSize);
    
        size_t const dSize = ZSTD_decompress(&uncompressed[0], decompressedSize, src, srcSize);
        if (ZSTD_isError(dSize)) {
            return false;
        }
    
        return true;
    }

    bool FetchManager::fill_user_fea(const std::string& up_id, const std::string& path, const std::string& key, 
                                        Core::FSContextPtr fs_ctx, const char* data, size_t len, std::string& final_feat_str) {
        final_feat_str = data;
        if (len == 0) {
            return false;
        }
        auto* feature_dump = fs_ctx->get_feature_dump();
        const google::protobuf::Reflection* reflection = feature_dump->GetReflection();
        const google::protobuf::Descriptor* descriptor = feature_dump->GetDescriptor();
        const google::protobuf::FieldDescriptor* field = descriptor->FindFieldByName(path);
        if (field == nullptr) {
            HILOG_APP(WARNING) << key << ", up_id: [" << up_id << "] parse fail, cause " << path << " doesn't exist in FeRequest";
            return false;
        }
        if (field->type() == google::protobuf::FieldDescriptor::TYPE_MESSAGE) {
            std::unique_ptr<google::protobuf::Message> temp_message(feature_dump->GetReflection()->GetMessageFactory()->GetPrototype(field->message_type())->New());
            if (!temp_message->ParseFromArray(data, static_cast<int>(len))) {
                HILOG_APP(WARNING) << key << ", up_id: [" << up_id << "] failed to parse message into " << path << " in FeRequest";
                return false;
            }
            
            // 解析成功后再填充到 feature_dump 中
            google::protobuf::Message* up_message = reflection->MutableMessage(feature_dump, field);
            up_message->CopyFrom(*temp_message);
        } else {
            HILOG_APP(WARNING) << key << ", up_id: [" << up_id << "] failed to parse, cause " << path << " 's type is not message";
            return false;
        }
        return true;
    }
}
