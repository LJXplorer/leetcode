#include "core/core_context/fs_context.h"
#include "fetch_manager.h"
#include "common/hilog/log_helper.h"
#include <string>
#include "core/utils/monitor_mgr.h"
using namespace hilog;
namespace Core{

void fill_group_meta(FSContextPtr ctx,const std::string&fg,const std::string&key,
    const std::string&version){
    auto meta_it = ctx->_user_group_meta.find(fg);
    if(meta_it != ctx->_user_group_meta.end() ){
        meta_it->second->set_featuregroup(fg);
        std::string rowkey;
        rowkey = key.substr(fg.size()+1);
        if (rowkey == STRING_DEFAULT) {
            MonitorMgr::redis_report_common(STRING_DEFAULT, fg, 0, "default_count", 1,FsSource::LOCAL_CACHE, STRING_DEFAULT, STRING_TOTALUP);
        }
        meta_it->second->set_rowkey(rowkey);
        meta_it->second->set_version(version);
    }
    ctx->_hit_user_group[fg] = true;
}

int FetchManager::init_register(FetchMeta& meta){
    //处理sequenceExample类型的特征
    auto user_special_seq_prefix = meta._user_special_seq_prefix;
    for (int i=0; i< user_special_seq_prefix.size(); ++i) {
        const std::string prefix = user_special_seq_prefix[i];
        register_parse_func(prefix, meta,
            [prefix](const std::string& key, const char* data, size_t len, FSContextPtr fs_ctx) {
                auto& seq = fs_ctx->_user_seq[prefix];
                auto suc = seq->ParseFromArray(data, static_cast<int>(len));
                fill_group_meta(fs_ctx,prefix,key,seq->version());
                return suc;
            });
    }

    // 处理游戏的自定义用户和query特征
    register_parse_func("appmarket_uf_game_user_offline_feature", meta,
        [](const std::string& key, const char* data, size_t len, FSContextPtr fs_ctx) -> bool {
            if(!fs_ctx->get_user_feature()->mutable_game_user_offline_feature()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx, "appmarket_uf_game_user_offline_feature", key, fs_ctx->get_user_feature()->mutable_game_user_offline_feature()->version());
            return true;
        }
    );

    register_parse_func("appmarket_qf_game_query_offline_feature", meta,
        [](const std::string& key, const char* data, size_t len, FSContextPtr fs_ctx) -> bool {
            if(!fs_ctx->get_user_feature()->mutable_game_query_offline_feature()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx, "appmarket_qf_game_query_offline_feature", key, fs_ctx->get_user_feature()->mutable_game_query_offline_feature()->version());
            return true;
        }    
    );

    register_parse_func("game_uf_behavior_realline_v1", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_game_user_online_feature()->mutable_game_user_behavior_seq_feature()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"game_uf_behavior_realline_v1",key,fs_ctx->get_user_feature()->mutable_game_user_online_feature()->mutable_game_user_behavior_seq_feature()->version());
        return true;
        
    });

    // // //处理体验的自定义pb
    register_parse_func("appmarket_uf_dmp_fe_akv", meta,
        [](const std::string& key, const char* data, size_t len, FSContextPtr fs_ctx) -> bool {
            if(!fs_ctx->get_user_feature()->mutable_common_udid_feature()->mutable_experience_user_dmp_feature_group()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx, "appmarket_uf_dmp_fe_akv", key, fs_ctx->get_user_feature()->mutable_common_udid_feature()->mutable_experience_user_dmp_feature_group()->version());
            return true;
        }
    );
    
    //dmp 
    // register_parse_func("dmp_v1_uf_ex_akv", meta,
    //     [](const std::string& key, const char* data, size_t len, FSContextPtr fs_ctx) -> bool {
    //         if(!fs_ctx->get_user_feature()->mutable_am_user_feature_group()->mutable_am_user_demographics_dmp_feature()->ParseFromArray(data, static_cast<int>(len))) {
    //             return false;
    //         }
    //         fill_group_meta(fs_ctx, "dmp_v1_uf_ex_akv", key, fs_ctx->get_user_feature()->mutable_am_user_feature_group()->mutable_am_user_demographics_dmp_feature()->version());
    //         return true;
    //     }
    // );

    
    //处理UserSequenceEntity类型的特征
    // register_parse_func("g_first_open_nl", meta,
    //     [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

    //          if (!fs_ctx->get_user_feature()->mutable_g_first_open_nl()->ParseFromArray(data, static_cast<int>(len))) {
    //             return false;
    //         }
    //         fill_group_meta(fs_ctx,"g_first_open_nl",key,fs_ctx->get_user_feature()->mutable_g_first_open_nl()->version());
    //         return true;
            
    //     });

    // register_parse_func("g_open_nl", meta,
    //     [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
    //         if (!fs_ctx->get_user_feature()->mutable_g_open_nl()->ParseFromArray(data, static_cast<int>(len))) {
    //             return false;
    //         }
    //         fill_group_meta(fs_ctx,"g_open_nl",key,fs_ctx->get_user_feature()->mutable_g_open_nl()->version());
    //         return true;
    //     });

    // register_parse_func("g_ins_nl", meta,
    // [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
    //     if (!fs_ctx->get_user_feature()->mutable_g_ins_nl()->ParseFromArray(data, static_cast<int>(len))) {
    //         return false;
    //     }
    //     fill_group_meta(fs_ctx,"g_ins_nl",key,fs_ctx->get_user_feature()->mutable_g_ins_nl()->version());

    //     return true;
    // });

    // register_parse_func("g_cur_ins_nl", meta,
    // [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
    //     if (!fs_ctx->get_user_feature()->mutable_g_cur_ins_nl()->ParseFromArray(data, static_cast<int>(len))) {
    //         return false;
    //     }
    //     fill_group_meta(fs_ctx,"g_cur_ins_nl",key,fs_ctx->get_user_feature()->mutable_g_cur_ins_nl()->version());


    //     return true;
    // });

    // register_parse_func("g_unins_nl", meta,
    // [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
    //     if (!fs_ctx->get_user_feature()->mutable_g_unins_nl()->ParseFromArray(data, static_cast<int>(len))) {
    //         return false;
    //     }
    //     fill_group_meta(fs_ctx,"g_unins_nl",key,fs_ctx->get_user_feature()->mutable_g_unins_nl()->version());

    //     return true;
    // });

    // register_parse_func("g_update_nl", meta,
    //     [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
    //         if (!fs_ctx->get_user_feature()->mutable_g_update_nl()->ParseFromArray(data, static_cast<int>(len))) {
    //             return false;
    //         }
    //         fill_group_meta(fs_ctx,"g_update_nl",key,fs_ctx->get_user_feature()->mutable_g_update_nl()->version());

    //         return true;
    //     });

    register_parse_func("honor_ad_uf_app_click_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_am_gm_clk_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_app_click_offline",key,fs_ctx->get_user_feature()->mutable_am_gm_clk_off()->version());

            return true;
        });
    
    register_parse_func("honor_ad_uf_app_install_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_am_gm_ins_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }

            fill_group_meta(fs_ctx,"honor_ad_uf_app_install_offline",key,fs_ctx->get_user_feature()->mutable_am_gm_ins_off()->version());

            return true;
        });

    register_parse_func("honor_ad_uf_app_first_use_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_g_first_use_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_app_first_use_offline",key,fs_ctx->get_user_feature()->mutable_g_first_use_off()->version());

            return true;
        });

    register_parse_func("honor_ad_uf_app_last_use_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_g_last_use_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_app_last_use_offline",key,fs_ctx->get_user_feature()->mutable_g_last_use_off()->version());

            return true;
        });

    register_parse_func("honor_ad_uf_app_use_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_g_use_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_app_use_offline",key,fs_ctx->get_user_feature()->mutable_g_use_off()->version());

            return true;
        });

    register_parse_func("honor_ad_uf_yoyo_expo_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_yoyo_imp_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_yoyo_expo_offline",key,fs_ctx->get_user_feature()->mutable_yoyo_imp_off()->version());

            return true;
        });

    register_parse_func("honor_ad_uf_yoyo_click_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_yoyo_clk_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_yoyo_click_offline",key,fs_ctx->get_user_feature()->mutable_yoyo_clk_off()->version());

            return true;
        });

    register_parse_func("honor_ad_uf_am_gm_user_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_am_gm_user_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_am_gm_user_offline",key,fs_ctx->get_user_feature()->mutable_am_gm_user_off()->version());

            return true;
        });

    register_parse_func("honor_ad_uf_honorsearch_user_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_hs_user_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_honorsearch_user_offline",key,fs_ctx->get_user_feature()->mutable_hs_user_off()->version());

            return true;
        });

    register_parse_func("honor_ad_uf_feed_user_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_feed_user_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_feed_user_offline",key,fs_ctx->get_user_feature()->mutable_feed_user_off()->version());

            return true;
        });

    register_parse_func("honor_ad_uf_onboard_user_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_onboard_user_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_onboard_user_offline",key,fs_ctx->get_user_feature()->mutable_onboard_user_off()->version());

            return true;
        });

    // register_parse_func("honor_ad_uf_v2_dmp", meta,
    //     [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
    //         if (!fs_ctx->get_user_feature()->mutable_dmp_stat()->ParseFromArray(data, static_cast<int>(len))) {
    //             return false;
    //         }
    //         fill_group_meta(fs_ctx,"honor_ad_uf_v2_dmp",key,fs_ctx->get_user_feature()->mutable_dmp_stat()->version());

    //         return true;
    //     });
    // register_parse_func("ad_conversion_nl", meta,
    //     [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
    //         if (!fs_ctx->get_user_feature()->mutable_ad_conversion_nl()->ParseFromArray(data, static_cast<int>(len))) {
    //             return false;
    //         }
    //         fill_group_meta(fs_ctx,"ad_conversion_nl",key,fs_ctx->get_user_feature()->mutable_ad_conversion_nl()->version());

    //         return true;
    //     });
    register_parse_func("honor_ad_qf_query_feature", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_query_feature()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_qf_query_feature",key,fs_ctx->get_user_feature()->mutable_query_feature()->version());

            return true;
        });

    //处理UserSequenceEntity类型的特征
    register_parse_func("honor_ad_uf_app_download_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

             if (!fs_ctx->get_user_feature()->mutable_am_gm_dld_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_app_download_offline",key,fs_ctx->get_user_feature()->mutable_am_gm_dld_off()->version());
            return true;
            
        });

    register_parse_func("honor_ad_uf_app_open_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

             if (!fs_ctx->get_user_feature()->mutable_am_gm_open_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_app_open_offline",key,fs_ctx->get_user_feature()->mutable_am_gm_open_off()->version());
            return true;
            
        });
    
    register_parse_func("honor_ad_uf_oaid_example_feature", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

             if (!fs_ctx->get_user_feature()->mutable_oaid_example_feature()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_oaid_example_feature",key,"");
            return true;
            
        });

    register_parse_func("honor_ad_uf_quick_service_sequence_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

             if (!fs_ctx->get_user_feature()->mutable_quick_servicre_seq_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_quick_service_sequence_offline",key,fs_ctx->get_user_feature()->mutable_quick_servicre_seq_off()->version());
            return true;
            
        });
    
    register_parse_func("honor_ad_uf_app_use_offline_all", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

             if (!fs_ctx->get_user_feature()->mutable_global_user_off_all()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_app_use_offline_all",key,fs_ctx->get_user_feature()->mutable_global_user_off_all()->version());
            return true;
            
        });

    register_parse_func("honor_ad_uf_app_conversion_offline", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

             if (!fs_ctx->get_user_feature()->mutable_app_conv_off()->ParseFromArray(data, static_cast<int>(len))) {
                return false;
            }
            fill_group_meta(fs_ctx,"honor_ad_uf_app_conversion_offline",key,fs_ctx->get_user_feature()->mutable_app_conv_off()->version());
            return true;
            
        });

    register_parse_func("honor_ad_mf_mediaid_feature", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_mediaid_feature()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        auto meta_it = fs_ctx->_user_group_meta.find("honor_ad_mf_mediaid_feature");
        if(meta_it != fs_ctx->_user_group_meta.end() ){
            meta_it->second->set_featuregroup("mediaid_feature");
            std::string rowkey;
            rowkey = key.substr(28);
            meta_it->second->set_rowkey(rowkey);
            meta_it->second->set_version(fs_ctx->get_user_feature()->mutable_mediaid_feature()->version());
        }
        fs_ctx->_hit_user_group["honor_ad_mf_mediaid_feature"] = true;
        return true;

    });

    register_parse_func("honor_ad_uf_user_desktop_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_user_desktop_offline_feature()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_user_desktop_offline",key,fs_ctx->get_user_feature()->mutable_user_desktop_offline_feature()->version());
        return true;
        
    });

    register_parse_func("honor_ad_uf_yoyo_seq_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_user_yoyo_offline_seq_feature()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_yoyo_seq_offline",key,fs_ctx->get_user_feature()->mutable_user_yoyo_offline_seq_feature()->version());
        return true;
        
    });

    register_parse_func("honor_ad_af_attr_most", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_adunit_attribute_feature()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_af_attr_most",key,fs_ctx->get_user_feature()->mutable_adunit_attribute_feature()->version());
        return true;
        
    });

    fetch_ad_user_feature(meta);

    fetch_adunit_info(meta);

    return 0;
}

void FetchManager::fetch_ad_user_feature(FetchMeta& meta){
    // af_ad_seq_off_fg
    register_parse_func("honor_ad_uf_af_ad_action_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_af_ad_seq_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_af_ad_action_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_af_ad_seq_off_fg()->version());
        return true;
        
    });

    // am_ad_seq_off_fg
    register_parse_func("honor_ad_uf_am_ad_action_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_ad_seq_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_am_ad_action_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_ad_seq_off_fg()->version());
        return true;
        
    });

    // feed_ad_seq_off_fg
    register_parse_func("honor_ad_uf_feed_ad_action_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_feed_ad_seq_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_feed_ad_action_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_feed_ad_seq_off_fg()->version());
        return true;
        
    });

    // yoyo_ad_seq_off_fg
    register_parse_func("honor_ad_uf_yoyo_ad_action_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_yoyo_ad_seq_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_yoyo_ad_action_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_yoyo_ad_seq_off_fg()->version());
        return true;
        
    });

    // af_ad_seq_nl_fg
    register_parse_func("honor_ad_uf_af_ad_action_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_af_ad_seq_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_af_ad_action_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_af_ad_seq_nl_fg()->version());
        return true;
        
    });

    // am_ad_seq_nl_fg
    register_parse_func("honor_ad_uf_am_ad_action_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_ad_seq_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_am_ad_action_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_ad_seq_nl_fg()->version());
        return true;
        
    });

    // feed_ad_seq_nl_fg
    register_parse_func("honor_ad_uf_feed_ad_action_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_feed_ad_seq_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_feed_ad_action_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_feed_ad_seq_nl_fg()->version());
        return true;
        
    });

    // yoyo_ad_seq_nl_fg
    register_parse_func("honor_ad_uf_yoyo_ad_action_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_yoyo_ad_seq_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_yoyo_ad_action_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_yoyo_ad_seq_nl_fg()->version());
        return true;
        
    });

    // feed_non_ad_seq_off_fg
    register_parse_func("honor_ad_uf_feed_user_seq_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_feed_non_ad_seq_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_feed_user_seq_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_feed_non_ad_seq_off_fg()->version());
        return true;
        
    });

    // // gl_ad_conversion_nl_fg
    // register_parse_func("honor_ad_uf_app_conversion_online", meta,
    // [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

    //         if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
    //         return false;
    //     }
    //     fill_group_meta(fs_ctx,"honor_ad_uf_app_conversion_online",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->version());
    //     return true;
        
    // });

    // am_query_seq_nl_fg
    register_parse_func("honor_ad_uf_am_query_list_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_query_seq_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_am_query_list_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_query_seq_nl_fg()->version());
        return true;
        
    });

    // am_clk_nl_fg
    register_parse_func("honor_ad_uf_app_click_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_clk_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_app_click_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_clk_nl_fg()->version());
        return true;
        
    });

    // am_dld_nl_fg
    register_parse_func("honor_ad_uf_app_download_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_dld_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_app_download_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_dld_nl_fg()->version());
        return true;
        
    });

    // am_ins_nl_fg
    register_parse_func("honor_ad_uf_app_install_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_ins_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_app_install_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_ins_nl_fg()->version());
        return true;
        
    });


    // am_open_nl_fg
    register_parse_func("honor_ad_uf_app_open_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_open_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_app_open_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_open_nl_fg()->version());
        return true;
        
    });

    // am_user_nl_fg
    register_parse_func("honor_ad_uf_am_gm_user_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_user_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_am_gm_user_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_am_user_nl_fg()->version());
        return true;
        
    });

    // user_open_seq_nl_fg
    register_parse_func("honor_ad_g_open_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_g_open_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->version());
        return true;
        
    });

    // user_first_open_seq_nl_fg
    register_parse_func("honor_ad_g_first_open_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_first_open_seq_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_g_first_open_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_first_open_seq_nl_fg()->version());
        return true;
        
    });

    // user_install_seq_nl_fg
    register_parse_func("honor_ad_g_ins_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_install_seq_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_g_ins_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_install_seq_nl_fg()->version());
        return true;
        
    });

    // user_uninstall_seq_nl_fg
    register_parse_func("honor_ad_g_unins_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_uninstall_seq_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_g_unins_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_uninstall_seq_nl_fg()->version());
        return true;
        
    });

    // user_update_seq_nl_fg
    register_parse_func("honor_ad_g_update_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_update_seq_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_g_update_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_update_seq_nl_fg()->version());
        return true;
        
    });

    // user_install_list_seq_nl_fg
    register_parse_func("honor_ad_g_cur_ins_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_install_list_seq_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_g_cur_ins_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_install_list_seq_nl_fg()->version());
        return true;
        
    });

    // user_create_type_stats_feature_group 
    register_parse_func("honor_ad_uf_createtype_stats", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_create_type_stats_feature_group()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_createtype_stats",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_create_type_stats_feature_group()->version());
        return true;
        
    });

    // user_click_seq_fg
    register_parse_func("honor_ad_uf_ad_click_sequence_new", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_click_seq_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_ad_click_sequence_new",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_click_seq_fg()->version());
        return true;
        
    });

    // app_behav_fg
    register_parse_func("honor_ad_uf_app_behav", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_app_behav_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_app_behav",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_app_behav_fg()->version());
        return true;
        
    });

    // user_key_behavior_conv_fg
    register_parse_func("honor_ad_uf_key_behav_seq_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_key_behavior_conv_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_key_behav_seq_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_key_behavior_conv_fg()->version());
        return true;
        
    });

    // hs_ad_seq_off_fg
    register_parse_func("honor_ad_uf_hoborsearch_seq_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_hs_ad_seq_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_hoborsearch_seq_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_hs_ad_seq_off_fg()->version());
        return true;
        
    });

    // // user_open_seq_off_fg
    // register_parse_func("honor_ad_uf_open_seq_v2_offline", meta,
    // [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

    //         if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
    //         return false;
    //     }
    //     fill_group_meta(fs_ctx,"honor_ad_uf_open_seq_v2_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->version());
    //     return true;
        
    // });

    // // user_first_open_seq_off_fg
    // register_parse_func("honor_ad_uf_first_open_seq_v2_offline", meta,
    // [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

    //         if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_first_open_seq_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
    //         return false;
    //     }
    //     fill_group_meta(fs_ctx,"honor_ad_uf_first_open_seq_v2_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_first_open_seq_off_fg()->version());
    //     return true;
        
    // });

    // user_update_seq_off_fg
    register_parse_func("honor_ad_uf_update_seq_v2_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_update_seq_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_update_seq_v2_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_update_seq_off_fg()->version());
        return true;
        
    });

    // user_install_seq_off_fg
    register_parse_func("honor_ad_uf_install_seq_v2_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_install_seq_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_install_seq_v2_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_install_seq_off_fg()->version());
        return true;
        
    });

    // user_uninstall_seq_off_fg
    register_parse_func("honor_ad_uf_uninstall_seq_v2_offline", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_uninstall_seq_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_uninstall_seq_v2_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_uninstall_seq_off_fg()->version());
        return true;
        
    });

    // query_pkg_rank_feature_group
    register_parse_func("honor_ad_qf_inter_query_pkg", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_ad_query_feature()->mutable_query_pkg_rank_feature_group()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_qf_inter_query_pkg",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_ad_query_feature()->mutable_query_pkg_rank_feature_group()->version());
        return true;
        
    });

    // query_intent_rank_feature_group
    register_parse_func("honor_ad_qf_inter_query_intent", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_ad_query_feature()->mutable_query_intent_rank_feature_group()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_qf_inter_query_intent",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_ad_query_feature()->mutable_query_intent_rank_feature_group()->version());
        return true;
        
    });

    // app_basic_attr_fg
    register_parse_func("honor_ad_uf_app_basic_attr", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_app_basic_attr_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_app_basic_attr",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_app_basic_attr_fg()->version());
        return true;
        
    });

    // user_basic_attr_fg
    register_parse_func("honor_ad_uf_user_basic_attr", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_basic_attr_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_user_basic_attr",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_basic_attr_fg()->version());
        return true;
        
    });

    // app_last_use_nl_fg
    register_parse_func("honor_ad_uf_last_three_time_use_app", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_app_last_use_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_last_three_time_use_app",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_app_last_use_nl_fg()->version());
        return true;
        
    });

    // app_first_use_nl_fg
    register_parse_func("honor_ad_uf_app_first_use_offline_v2", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_app_first_use_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_app_first_use_offline_v2",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_app_first_use_nl_fg()->version());
        return true;
        
    });

    // gl_ad_conversion_nl_fg
    register_parse_func("honor_ad_uf_app_conv_nl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_app_conv_nl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->version());
        return true;
        
    });

    // user_search_query_seq
    register_parse_func("honor_ad_uf_user_query_down_fg", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_search_query_seq()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_user_query_down_fg",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_search_query_seq()->version());
        return true;
        
    });

    // query_associate_seq
    register_parse_func("honor_ad_qf_query_associate_words_fg", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_query_associate_seq()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_qf_query_associate_words_fg",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_query_associate_seq()->version());
        return true;
        
    });

    // // user_tag_cross_stats_fg
    // register_parse_func("honor_ad_uf_60d_clk_dl_offline", meta,
    // [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

    //         if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_tag_cross_stats_fg()->ParseFromArray(data, static_cast<int>(len))) {
    //         return false;
    //     }
    //     fill_group_meta(fs_ctx,"honor_ad_uf_60d_clk_dl_offline",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_tag_cross_stats_fg()->version());
    //     return true;
        
    // });

    // gl_ad_conversion_off_fg
    register_parse_func("honor_ad_uf_app_conversion_offline_v2", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_gl_ad_conversion_off_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_uf_app_conversion_offline_v2",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_gl_ad_conversion_off_fg()->version());
        return true;
        
    });

    // user_first_party_action_seq
    register_parse_func("ad_uf_1st_pty_act", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_first_party_action_seq()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"ad_uf_1st_pty_act",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_user_first_party_action_seq()->version());
        return true;
        
    });

    // appsuggest_user_tag_cross_stats_fg
    register_parse_func("ad_uf_asg_clk_dl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_appsuggest_user_tag_cross_stats_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"ad_uf_asg_clk_dl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_appsuggest_user_tag_cross_stats_fg()->version());
        return true;
        
    });

    // affiliate_user_tag_cross_stats_fg
    register_parse_func("ad_uf_aff_clk_dl", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_affiliate_user_tag_cross_stats_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"ad_uf_aff_clk_dl",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_affiliate_user_tag_cross_stats_fg()->version());
        return true;
        
    });

    // user feature
    register_parse_func("feature_dump_service", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            std::shared_ptr<::qinglong::FeatureDump> feature_dump_entity = std::make_shared<::qinglong::FeatureDump>();
            HILOG_APP(INFO) << "_redis_client_id11: " << " key:"<<key;
            if (!feature_dump_entity->ParseFromArray(data, static_cast<int>(len))) {
                HILOG_APP(INFO) << "_redis_client_id error: " << " key:"<<key;
                return false;
            }
            
            std::string index = key.substr(key.length() - 1, 1);
            HILOG_APP(INFO) << "index: " << index <<" key:"<<key;
            if(index.empty()){
                return false;
            }
            int index_i = 0;
            try {
                index_i = stoi(index);
            } catch(...) {
                return false;
            }
            fs_ctx ->_fe_requests[index_i]->Swap(feature_dump_entity->mutable_fe_request());
            
            //fill_group_meta(fs_ctx,"honor_ad_uf_app_first_use_offline_v2",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_app_first_use_nl_fg()->version());
            return true;
            
        });

    register_parse_func("feature_dump_service_index", meta,
        [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            int size = 0 ;
            try {
                size = std::stoi(data);
            }catch(...) {}
            
            if(size == 0) {
                return false;
            }
                        
            fs_ctx->_index_size = size;

            fs_ctx->init_fe_request(size);

            //fill_group_meta(fs_ctx,"honor_ad_uf_app_first_use_offline_v2",key,fs_ctx->get_user_feature()->mutable_af_user_feature()->mutable_app_first_use_nl_fg()->version());
            return true;
            
        });

}
void FetchManager::fetch_adunit_info(FetchMeta& meta){
    // adunit_create_type_stats_feature_group
    register_parse_func("honor_ad_af_createtype_stats", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_ad_adunit_id_feature()->mutable_adunit_create_type_stats_feature_group()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_af_createtype_stats",key,fs_ctx->get_user_feature()->mutable_ad_adunit_id_feature()->mutable_adunit_create_type_stats_feature_group()->version());
        return true;
        
    });

    // im_adunit_pkg_rank_feature_group
    register_parse_func("honor_ad_af_im_adunit_pkg_rank", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){

            if (!fs_ctx->get_user_feature()->mutable_ad_adunit_id_feature()->mutable_im_adunit_pkg_rank_feature_group()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"honor_ad_af_im_adunit_pkg_rank",key,fs_ctx->get_user_feature()->mutable_ad_adunit_id_feature()->mutable_im_adunit_pkg_rank_feature_group()->version());
        return true;
        
    });
    // adunit_intent_stat_fg
    register_parse_func("ad_af_adt_intent", meta,
    [](const std::string& key,const char* data, size_t len, FSContextPtr fs_ctx){
            if (!fs_ctx->get_user_feature()->mutable_ad_adunit_id_feature()->mutable_adunit_intent_stat_fg()->ParseFromArray(data, static_cast<int>(len))) {
            return false;
        }
        fill_group_meta(fs_ctx,"ad_af_adt_intent",key,fs_ctx->get_user_feature()->mutable_ad_adunit_id_feature()->mutable_adunit_intent_stat_fg()->version());
        return true;
        
    });
}




}//end core
