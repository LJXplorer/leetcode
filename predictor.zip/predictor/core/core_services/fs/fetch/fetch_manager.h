#ifndef _REDIS_FETCH_MANAGER_H
#define _REDIS_FETCH_MANAGER_H

#include <cstdint>
#include <google/protobuf/message.h>
#include <memory>
#include <functional>
#include <map>
#include <string>
#include "core/core_context/fs_context.h"
#include "brpc/redis.h"
#include "core/utils/defs.h"
#include "common/config/base_config.h"
#include "common/config/service_config.h"
#include "common/comm/double_buffer.h"
#include "log_helper.h"
namespace Core {
    struct FetchInfo {
        std::string _prefix;
        std::string _compress;
        std::string _feature_type;//item/user|query/cross
        long _expired_time = 0;
        long _interval = 0;
        std::string _feature_name;
        std::unordered_set<std::int32_t> _allow_scene;
        int _time_out = 0;
        std::string _cluster_id;
        std::string _cmd;
        std::string _redis_client_id;
        std::string _sep;
        std::string _up_id;
        std::string _path;
        std::string _up_name;
        std::string _use_decode = "true";
        std::string _dump_missed_feat = "false";

    };


    struct FetchMeta {
        std::vector<std::shared_ptr<const FetchInfo>> _fetch_item_info_vec;
        std::vector<std::shared_ptr<const FetchInfo>> _fetch_info_vec;

        void clear() {
            _fetch_item_info_vec.clear();
            _fetch_info_vec.clear();
        }
    };


    class FetchManager {
    public:
        std::string _fetch_conf_path;
        DBuffer<FetchMeta> _fetch_meta;
    private:
        FetchManager(){}
    public:
        int init(const std::string& path);
        std::vector<std::shared_ptr<const FetchInfo>>& get_fetchs();
        std::vector<std::shared_ptr<const FetchInfo>>& get_item_fetchs();
        FetchMeta& get_cur_fetch_meta();
        static bool zstd_decompress(std::string& uncompressed, const void *src, size_t srcSize);
        static FetchManager& instance() {
            static FetchManager inst;
            return inst;
        }
        
        void parse_redis_response(const std::string& key, std::shared_ptr<const FetchInfo> fetch,
                              const std::string& response, const std::string &value,
                              FSContextPtr context,int32_t error_code, std::string& final_feat_str);
        bool fill_user_fea(const std::string& up_name, const std::string& path, const std::string& key, 
                            Core::FSContextPtr fs_ctx, const char* data, size_t len, std::string& final_feat_str);
    };
} // end of namespace

#endif
