#ifndef _CORE_SERVICES_USER_FS_H
#define _CORE_SERVICES_USER_FS_H
#include "core/core_services/fs/redis_service.h"
#include "core/core_context/core_context.h"

namespace Core {
    class UserFsService : public RedisService {
    public:
        UserFsService() {
        }

        ~UserFsService(){
        }
        virtual void initialize(GraphContextPtr context);
        virtual void initialize(ConfigXmlPtr xml) override;
        virtual void initialize_xml(ConfigXmlPtr xml);
        std::string _handle_query_enable = "true"; 
    public:
        virtual bool get_fetch(CoreContextPtr context, std::vector<std::shared_ptr<const FetchInfo> >& fetch_vec, std::unordered_map<std::string, std::vector<std::shared_ptr<const FetchInfo> >>& hash_fetch_map);
        virtual bool make_fetch_key(CoreContextPtr context,std::shared_ptr<const FetchInfo> fetch,std::string&key);
    };
    
}

#endif
