
#include "common/hilog/log_helper.h"
#include "common/comm/wrapper_time.h"
#include <boost/algorithm/string.hpp>
#include "core/core_services/fs/fetch/fetch_manager.h"
#include "core/core_services/fs/redis_client/redis_client_manager.h"
#include "core/core_services/fs/async_item/async_item_cache.h"
#include "core/core_services/fs/async_item/data_fetcher.h"
#include "core/utils/defs.h"
#include "core/utils/monitor_mgr.h"

DEFINE_int32(offline_backet_refresh_us, 200*1000, "offline_item_refresh_us");
DEFINE_int32(offline_backet_refresh_batch_size, 1, "offline_item_refresh_batch_size");
DEFINE_int32(item_random_base_ms, 500, "item_random_base_ms");
DEFINE_int32(INTERACT_EXPIRED_CHECK_INTERVAL, 60*60, "INTERACT_EXPIRED_CHECK_INTERVAL");
DEFINE_int32(INTERACT_GROUP_UPDATE_CHECK_INTERVAL, 60, "INTERACT_GROUP_UPDATE_CHECK_INTERVAL");
DEFINE_int32(INTERACT_BLACK_EXPIRED_CHECK_INTERVAL, 60*10, "INTERACT_BLACK_EXPIRED_CHECK_INTERVAL");
DEFINE_int32(item_cache_thread_num, 5, "item_cache_thread_num");
std::atomic<int32_t>  *g_interact_total = new std::atomic<int>(0);
std::atomic<int32_t>  *new_g_interact_total = new std::atomic<int>(0);
namespace Core {

    AsyncContext::AsyncContext(){
        _slplit_finish = std::make_shared<std::atomic<int32_t>>(MAX_SLICE_NUM);
        for(int32_t i =0;i<MAX_SLICE_NUM;i++){
            _slice_arr_vec.emplace_back(std::make_shared<SliceContext>());
            _slice_arr_vec[i]->_ctx_slplit_finish = _slplit_finish;
        }
        _item_finish_cnt = std::make_shared<std::atomic<int32_t>>(0);
        
    }

    bool AsyncItemUpdate::init(const std::string& fetch_name,int interval,int backet_num){
        _backet_num = backet_num;
        _initialized = initialize(fetch_name);
        _refresh_interval_s = interval + (rand() % FLAGS_item_random_base_ms);
        _fetch_name = fetch_name;
        _online_queue = std::make_shared<boost::lockfree::queue<OnlineQuery*>>(1000);

        HILOG_APP(WARNING) <<_fetch_name << " interval_ms: " << _refresh_interval_s<<",initialized:"<<_initialized;
        return _initialized;
    }

    bool AsyncItemUpdate::initialize(const std::string& fetch_name){ 
        return false;
    }

    void AsyncItemUpdate::refresh_default(){

    }

    void push_online_item_to_queue(const std::string&fea_name,const std::string&id){
        auto* online_item = new OnlineQuery();
        online_item->_feature_name.assign(fea_name);
        online_item->_query_ids.emplace_back(id);
        AsyncItemCacheManager::instance().push_online_id_update(online_item);
    }


    void AsyncItemUpdate::run() {
        if(_initialized == false){
           HILOG_APP(ERROR) <<_fetch_name << " interval_ms: " << _refresh_interval_s<<",initialized:"<<_initialized;
           return;
        }
        std::thread t([this](){
            while(_initialized) {
                int64_t t = gettimeofday_ms();
                if(t - _last_refresh_ms > _refresh_interval_s * 1000){
                    AsyncContextPtr ctx = std::make_shared<AsyncContext>();
                    for(int32_t i = 0; i < _backet_num;i++){
                        refresh(ctx,i);
                        if(i%FLAGS_offline_backet_refresh_batch_size == 0){
                            usleep(FLAGS_offline_backet_refresh_us);
                        }
                    }
                    refresh_default();
                    _last_refresh_ms = t;
                    HILOG_APP(ERROR)<<_fetch_name<<" update :" << _last_refresh_ms;
                }
                if(_default_refresh == false){
                     refresh_default();
                     _default_refresh = true;
                }
                //online queue
                int online_size = 0;
                {
                    std::set<std::string>  duplicates;
                    while(true) {
                        OnlineQuery* online_query = nullptr;
                        bool get = _online_queue->pop(online_query);
                        if (get && online_query != nullptr) {
                            for(auto&k : online_query->_query_ids){
                                duplicates.insert(k);
                                online_size++;
                            }
                            if (online_query != nullptr) {
                                delete online_query;
                                online_query = nullptr;
                            }
                            
                        }else{
                            break;
                        }
                    }
                    if(duplicates.size()){
                        RedisQueryInfo* redis_query = new RedisQueryInfo();
                        redis_query->_fetch_info = _fetch_info;
                        redis_query->_cache_item_update = this;
                        redis_query->_is_online = true;
                        for(const auto&d : duplicates){
                            if(check_black(d) ){
                                HILOG_APP(WARNING)<<_fetch_name<<" exist black :"<<d;
                                continue;
                            }
                            redis_query->_redis_key_msg.insert({make_item_key(d),gen_message()});
                            if(redis_query->_redis_key_msg.size() >= 100)break;//超过100截断
                            
                        }
                        push_query_info_to_queue(redis_query);
                    }
                }
                HILOG_APP(WARNING)<<_fetch_name<<","<<get_message_cache_size(_fetch_name);
                //过期处理
                //expire( );
                HILOG_APP(WARNING)<<_fetch_name<<" update online_size:" << online_size;
                std::this_thread::sleep_for(std::chrono::milliseconds(_interval*1000));
                //sleep(3600*12);

            }
        });
        t.detach();
    }

    void AsyncItemUpdate::expire( ){
        std::map<size_t ,std::vector<std::string>> expire_keys;
        get_expire_message_key(_fetch_name,expire_keys);
        expire_message_key(_fetch_name,expire_keys);
        HILOG_APP(WARNING)<<_fetch_name<<","<<expire_keys.size();
    }

    void AsyncItemUpdate::refresh(AsyncContextPtr ctx,int32_t index){
        
        HILOG_APP(INFO) <<_fetch_name <<",refresh index:"<<index;
    }

    void push_query_info_to_queue(RedisQueryInfo*info) {
        AsyncItemCacheManager::instance().push_query_info(info);
    }

    void push_query_info_to_interact_queue(RedisQueryInfo *info) {
        AsyncItemCacheManager::instance().push_interact_query_info(info);
    }

    int AsyncItemCacheManager::init(){
        _query_info_queue = std::make_shared<boost::lockfree::queue<RedisQueryInfo*>>(100000);
        for(int32_t i = 0;i < FLAGS_item_cache_thread_num;i++){
            std::thread td = std::thread(AsyncItemCacheManager::handle, this);
            td.detach();
        }

        _query_info_interact_queue = std::make_shared<boost::lockfree::queue<RedisQueryInfo*>>(100000);
        for (int32_t i = 0; i < FLAGS_item_cache_thread_num; i++) {
            /* code */
            std::thread td = std::thread(AsyncItemCacheManager::handle_interact, this);
            td.detach();
        }
        

        //interact
        std::vector<std::shared_ptr<const FetchInfo>> cross = FetchManager::instance().get_cross_fetchs();
        for(auto &f : cross){
            add_message_cache(f->_feature_name);
            add_black_message_cache(f->_feature_name);
        }
        
        update_interact_default_data();
        HILOG_APP(INFO)<<"AsyncItemCacheManager _item_cache_map:"<<_item_cache_map.size();
       
        //cross_refresh过期处理
        std::thread cross_refresh([this](){
            while(true) {
                std::this_thread::sleep_for(std::chrono::milliseconds(FLAGS_INTERACT_EXPIRED_CHECK_INTERVAL*1000));
                
                //cross
                std::vector<std::shared_ptr<const FetchInfo>>& cross_fetch = FetchManager::instance().get_cross_fetchs();
                for(auto &cf : cross_fetch){
                    const bool is_new_interact_feat = (cf->_new_interact_feat == "true");
                    auto valide_keys = std::make_shared<std::map<size_t ,std::vector<std::string>>>();
                    auto expire_keys = std::make_shared<std::map<size_t ,std::vector<std::string>>>();
                    get_message_keys(cf->_feature_name,*valide_keys,*expire_keys);
                    //refresh
                    HILOG_APP(ERROR)<<"cross_refresh:"<<cf->_feature_name<<",valide_keys:"
                    <<valide_keys->size()<<",expire_keys:"<<expire_keys->size()<<",INTERVAL:"<<FLAGS_INTERACT_EXPIRED_CHECK_INTERVAL;
                    refresh_interact_data(cf,valide_keys);
                    expire_message_key(cf->_feature_name,*expire_keys);
                    for(const auto& expire_slice : *expire_keys){
                        if (is_new_interact_feat) {
                            new_g_interact_total->fetch_sub(expire_slice.second.size());
                        }
                        else {
                            g_interact_total->fetch_sub(expire_slice.second.size());
                        }
                        
                    }
                    //std::this_thread::sleep_for(std::chrono::milliseconds(FLAGS_INTERACT_GROUP_UPDATE_CHECK_INTERVAL*1000));
                }    
            }
        });
        cross_refresh.detach();
        //black_cross_refresh 过期处理
        std::thread black_cross_refresh([this](){
            while(true) {
                std::this_thread::sleep_for(std::chrono::milliseconds(FLAGS_INTERACT_BLACK_EXPIRED_CHECK_INTERVAL*1000));
                
                //cross
                std::vector<std::shared_ptr<const FetchInfo>>& cross_fetch = FetchManager::instance().get_cross_fetchs();
                for(auto &cf : cross_fetch){
                    std::map<size_t ,std::vector<std::string>> black_expire_keys;
                    get_black_expire_message_key(cf->_feature_name,black_expire_keys);
                    black_expire_message_key(cf->_feature_name,black_expire_keys);
                }
        
            }
        });
        black_cross_refresh.detach();
        register_cache();
        start_update();
        
        return 0;   
    }

    void AsyncItemCacheManager::register_cache(){
        // 注册SequenceExample类型
        const auto& item_fetch_info= FetchManager::instance().get_item_fetchs(); 
        const auto& item_special_seq_prefix = FetchManager::instance().get_item_special_seq_prefix();
        for(const auto& fetch_info : item_fetch_info){ // SequenceExample
            auto iter = item_special_seq_prefix.find(fetch_info->_feature_name);
            if(iter != item_special_seq_prefix.end()){
                _item_cache_map.insert({fetch_info->_feature_name, createAsyncItemCache<tensorflow::SequenceExample>(fetch_info->_feature_name, fetch_info->_interval, fetch_info->_bucket_num)});
            }else{ // self def pb
                if(fetch_info->_feature_name == group_game_item_offline_feature){
                    _item_cache_map.insert({group_game_item_offline_feature, createAsyncItemCache<qinglong::GameItemOfflineFeatureGroup>(group_game_item_offline_feature, fetch_info->_interval, fetch_info->_bucket_num)});
                }
                if(fetch_info->_feature_name == group_media_feature){
                    _item_cache_map.insert( {group_media_feature,createAsyncItemCache<qinglong::SequenceExampleMediaId>(group_media_feature, fetch_info->_interval,fetch_info->_bucket_num)} );
                }
                if(fetch_info->_feature_name == group_item_ad_stats_offline){
                    _item_cache_map.insert( {group_item_ad_stats_offline,
                                        createAsyncItemCache<qinglong::CreativeFeatureGroup>(group_item_ad_stats_offline, fetch_info->_interval,fetch_info->_bucket_num)} );
                }
                //体验item自定义特征
                if(fetch_info->_feature_name == group_appmarket_if_apprecom_tag_akv){
                    _item_cache_map.insert({group_appmarket_if_apprecom_tag_akv, createAsyncItemCache<qinglong::AmAppExtraInfoFeatureGroup>(group_appmarket_if_apprecom_tag_akv, fetch_info->_interval, fetch_info->_bucket_num)});
                }
                if(fetch_info->_feature_name == group_appmarket_if_appsearch_info_d){
                    _item_cache_map.insert({group_appmarket_if_appsearch_info_d, createAsyncItemCache<qinglong::AmAppExtraInfoDailyFeatureGroup>(group_appmarket_if_appsearch_info_d, fetch_info->_interval, fetch_info->_bucket_num)});
                }
               
                if (fetch_info->_feature_name == group_ad_pkg_nl) {
                    _item_cache_map.insert({group_ad_pkg_nl, createAsyncItemCache<qinglong::PackageNameNearLineStat>(group_ad_pkg_nl, fetch_info->_interval, fetch_info->_bucket_num)});
                }
            }
        }
        //_item_cache_map.insert( {group_item_ad_stats,createAsyncItemCache<qinglong::DescInfo>(group_item_stats_hour,43200,fetch_info->_bucket_num)} );
    }

    void AsyncItemCacheManager::refresh_interact_data(std::shared_ptr<const FetchInfo> fetch_info,std::shared_ptr< std::map<size_t ,std::vector<std::string> > > keys){
        
        HILOG_APP(WARNING)<<fetch_info->_feature_name<<",refresh_interact_data :"<<keys->size();
        for(const auto& v_k : *keys){
            if(v_k.second.size() == 0) {
                HILOG_APP(WARNING)<<fetch_info->_feature_name<<",refresh_interact_data bucket:"<<v_k.first<<","<<v_k.second.size();
                continue;
            }
            auto data_map = std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> >();

            if (fetch_info->_interval <= 0) {
                continue;
            }

            for(const auto& k: v_k.second){
                std::string redis_key;
                
                if(k != STRING_DEFAULT) {
                    redis_key.append(fetch_info->_prefix);
                } else {
                    redis_key.append(fetch_info->_group_prefix);
                }          
                redis_key.append(k);
                auto insertData = [&](const std::string& redis_key, auto feature) {
                    data_map.insert({redis_key, std::make_shared<decltype(feature)>()});
                };
                if (fetch_info->_feature_name == group_ad_pkg_adt) {
                    insertData(redis_key, qinglong::AdunitPkgStatFeatureGroup{});
                }
                else if (fetch_info->_feature_name == group_ad_pkg_adt_nl) {
                    insertData(redis_key, qinglong::PackageNameNearLineStat{});
                }
                else if (fetch_info->_feature_name == group_appmarket_search_cross_stats) {
                    insertData(redis_key, qinglong::AmQueryAppCrossStatsFeatureGroup{});
                }
                else if (fetch_info->_feature_name == group_ad_pkg_intent) {
                    insertData(redis_key, qinglong::AppPackageNameFeatureGroup{});
                } 
                else if (fetch_info->_feature_name == group_ad_pkg_cty) {
                    insertData(redis_key, qinglong::UserCityGenderStatFeatureGroup{});
                } 
                else if (fetch_info->_feature_name == group_ad_pkg_prov) {
                    insertData(redis_key, qinglong::UserBaseDmpStatFeatureGroup{});
                } 
                else {
                    insertData(redis_key, tensorflow::SequenceExample{});
                }
                HILOG_APP(INFO)<<fetch_info->_feature_name<<",refresh_interact_data redis_key :"<<redis_key<<","<<k;
            }

            std::size_t bucket_size = data_map.size();
            HILOG_APP(INFO) << fetch_info->_feature_name << ",bucketid:" << v_k.first << ",bucket size:" << bucket_size;
            if(bucket_size) {
                RedisQueryInfo* redis_query = new RedisQueryInfo();
                redis_query->_fetch_info = fetch_info;
                redis_query->_redis_key_msg = data_map;
                push_query_info_to_interact_queue(redis_query);

            }

        }  
    }
    
    void AsyncItemCacheManager::update_interact_default_data(){
        std::vector<std::shared_ptr<const FetchInfo> > fetch_vec  = FetchManager::instance().get_cross_fetchs(); 
            auto set_interact_default_data_to_cache =[&](std::shared_ptr<const FetchInfo> fetch,
            std::shared_ptr<std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> > > data_map,
            std::shared_ptr<std::unordered_map<std::string, int> >  data_map_status,
            int batch_size, std::shared_ptr<std::atomic<int>> time_out_num, 
            std::shared_ptr<std::atomic<int>> kv_not_exist_num){
            for (auto & r : *data_map) {
                auto it = data_map_status->find(r.first);
                std::string cache_key = r.first.find(STRING_DEFAULT) != std::string::npos?r.first.substr(fetch->_group_prefix.size()) : r.first.substr(fetch->_prefix.size());
                HILOG_APP(INFO) <<fetch->_feature_name<<",status:"<<r.first<<","<<it->second<<",cache_key:"<<cache_key;
                if(it->second == 0){
                    //默认数据不设置过期时间，只更新
                    put_message_feature_into_cache(fetch->_feature_name,cache_key,r.second,0/*fetch->_expired_time*/);
                    if (fetch->_new_interact_feat == "true") {
                        auto old = new_g_interact_total->fetch_add(1);
                        if(old >= INTERACT_CACHCE_COUNT){
                            HILOG_APP(ERROR)<<fetch->_feature_name <<" interact count more:"<<INTERACT_CACHCE_COUNT;
                            break;
                        }
                    }
                    else {
                        auto old = g_interact_total->fetch_add(1);
                        if(old >= INTERACT_CACHCE_COUNT){
                            HILOG_APP(ERROR)<<fetch->_feature_name <<" interact count more:"<<INTERACT_CACHCE_COUNT;
                            break;
                        }
                    }
                    
                    if (fetch->_feature_name != group_ad_pkg_adt && fetch->_feature_name != group_ad_pkg_adt_nl && fetch->_feature_name != group_appmarket_search_cross_stats
                            && fetch->_feature_name != group_ad_pkg_intent && fetch->_feature_name != group_ad_pkg_cty && fetch->_feature_name != group_ad_pkg_prov) {
                        auto seq_ptr = std::dynamic_pointer_cast<tensorflow::SequenceExample>(r.second);
                        for(auto&f : seq_ptr->context().feature()){
                            auto group = std::make_shared< CacheValue<std::string> >(fetch->_feature_name);
                            _item_feature_2_group.put(f.first,group);
                        }
                    }
                    
                }
            }
        };

        for(auto&f : fetch_vec){
            auto data_map = std::make_shared<std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> > >();
            auto data_map_status = std::make_shared<std::unordered_map<std::string, int>  >();
            std::vector<std::string> group_keys;
            std::string d_key = f->_group_prefix + STRING_DEFAULT;
            group_keys.push_back(d_key);
            if (f->_feature_name == group_ad_pkg_adt) {
                data_map->insert({d_key, std::make_shared<qinglong::AdunitPkgStatFeatureGroup>()});
            }
            else if (f->_feature_name == group_ad_pkg_adt_nl) {
                data_map->insert({d_key, std::make_shared<qinglong::PackageNameNearLineStat>()});
            }
            else if (f->_feature_name == group_appmarket_search_cross_stats) {
                data_map->insert({d_key, std::make_shared<qinglong::AmQueryAppCrossStatsFeatureGroup>()});
            }
            else if (f->_feature_name == group_ad_pkg_intent) {
                data_map->insert({d_key, std::make_shared<qinglong::AppPackageNameFeatureGroup>()});
            }
            else if (f->_feature_name == group_ad_pkg_cty) {
                data_map->insert({d_key, std::make_shared<qinglong::UserCityGenderStatFeatureGroup>()});
            }
            else if (f->_feature_name == group_ad_pkg_prov) {
                data_map->insert({d_key, std::make_shared<qinglong::UserBaseDmpStatFeatureGroup>()});
            }
            else {
                data_map->insert({d_key, std::make_shared<tensorflow::SequenceExample>()});
            }            
            data_map_status->insert({d_key, 0});
            HILOG_APP(WARNING)<<d_key<<",AsyncItemCacheManager :"<<_item_cache_map.size()
            <<",data_map size:"<<data_map->size()<<",data_map_status size:"<<data_map_status->size();
            DataFetcher::instance()->get_item_async(nullptr,group_keys, 0, group_keys.size(),
                    std::bind(set_interact_default_data_to_cache,f , std::placeholders::_1, std::placeholders::_2, group_keys.size(),std::placeholders::_3,std::placeholders::_4), 
                        f, data_map,data_map_status);
        }        
    }

    const std::string& AsyncItemCacheManager::get_item_group_name(const std::string&k){
        auto g = _item_feature_2_group.get(k);
        if(g == nullptr) return STRING_DEFAULT;
        return g->get_val();
    }

    void AsyncItemCacheManager::start_update(){
        for(auto&c: _item_cache_map){
            c.second->run();
        }
    }

    void AsyncItemCacheManager::handle(AsyncItemCacheManager* mgr){
        
        while(true) {
            RedisQueryInfo* query = nullptr;
            bool get = mgr->_query_info_queue->pop(query);
            if (get && query != nullptr) {
                query_and_store(query);
                if (query != nullptr) {
                    delete query;
                    query = nullptr;
                }
                
            }else{
                usleep(10000);
                continue;
            }
        }  
    }

    void AsyncItemCacheManager::handle_interact(AsyncItemCacheManager* mgr) {
        while(true) {
            RedisQueryInfo* query = nullptr;
            bool get_ret = mgr->_query_info_interact_queue->pop(query);
            if (get_ret && query != nullptr) {
                query_and_store_interact(query);
                if (query != nullptr) {
                    delete query;
                    query = nullptr;
                }
            } else {
                usleep(10000);
                continue;
            }
        }
    }

    void AsyncItemCacheManager::push_query_info( RedisQueryInfo* info){
        if(info == nullptr){
            HILOG_APP(INFO)<<",push_query_info null";
            return;
        }
        bool ret = _query_info_queue->push(info);
        HILOG_APP(INFO) <<info->_fetch_info->_feature_name <<",push_query_info ret:"<<ret;

    }

    void AsyncItemCacheManager::push_interact_query_info(RedisQueryInfo* info) {
        if (info == nullptr) {
            HILOG_APP(INFO)<<",push_interact_query_info null";
            return;
        }
        bool ret = _query_info_interact_queue->push(info);
        HILOG_APP(INFO) <<info->_fetch_info->_feature_name <<",push_interact_query_info ret:"<<ret;
    }

    void AsyncItemCacheManager::query_and_store(const RedisQueryInfo*info){
        if(info == nullptr) return;
        auto fetch_info = info->_fetch_info;
        //该函数只会去使用redis不会使用akv
        auto client = RedisClientManager::instance().get_client(fetch_info->_redis_client_id);
        if(client == nullptr){
            HILOG_APP(WARNING) <<fetch_info->_feature_name
                <<" redis client is nullptr, redis_client_id: " << fetch_info->_redis_client_id;
            return;
        }
        
        std::shared_ptr<std::unordered_map<std::string, int> > data_map_status = std::make_shared<std::unordered_map<std::string, int>>();
        std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> > store_data_map;
        
        for(auto&q : info->_redis_key_msg){
            auto response_ptr = std::make_shared<brpc::RedisResponse>();
            auto cntl_ptr = std::make_shared<brpc::Controller>();
            int ret = client->get_simple(q.first,cntl_ptr,response_ptr);
            HILOG_APP(INFO)<<fetch_info->_feature_name<<",key:"<<q.first;
            if(ret != 0){
                HILOG_APP(INFO)<<fetch_info->_feature_name<<",key:"<<q.first <<ret;
               data_map_status->insert({q.first,ret});
               continue;
            }
            
            ret = DataFetcher::instance()->check_redis_response(fetch_info,q.first,cntl_ptr,response_ptr);
            HILOG_APP(INFO)<<fetch_info->_feature_name<<",check_redis_response key:"<<q.first;
            if(ret != 0){
                data_map_status->insert({q.first,ret});
                continue;
            }
            ret = DataFetcher::instance()->process_redis_response(fetch_info,q.first,cntl_ptr,response_ptr,q.second);
            MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch_info->_feature_name,ret,"feature_value_size",q.second->ByteSize(),FsSource::REDIS,STRING_DEFAULT, STRING_TOTALUP);
            MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch_info->_feature_name,ret,"redis_response_size",response_ptr->ByteSize(),FsSource::REDIS,STRING_DEFAULT, STRING_TOTALUP);
            data_map_status->insert({q.first,ret});
            if(ret != 0){
                continue;
            }
            store_data_map.insert({q.first,q.second});
        }
        HILOG_APP(INFO)<<fetch_info->_feature_name<<",store_data_map:"<<store_data_map.size()<<","<<info->_is_online;
        info->_cache_item_update->set_message_cache(store_data_map,data_map_status,info->_is_online);

        //离线需要双Buff切换
        if(info->_is_online == false){
            int old = info->_ctx->_item_finish_cnt->fetch_sub(info->_redis_key_msg.size());
            int old_group = info->_ctx->_slplit_finish->load();
            int last_item = info->_ctx->_item_finish_cnt->load();
            if(last_item < 1 && old_group < 1){
                exchange_dbuffer_message_cache(fetch_info->_feature_name);
                HILOG_APP(WARNING) <<fetch_info->_feature_name
                    <<" exchange _dbuffer_message_cache " << fetch_info->_redis_client_id;
            }
            HILOG_APP(WARNING)<<fetch_info->_feature_name<<",old:"<<old<<",old_group:"<<old_group<<",last_item:"<<last_item;
        }
        
    }

    void AsyncItemCacheManager::query_and_store_interact(const RedisQueryInfo* info) {

        if(info == nullptr) return;
        auto fetch_info = info->_fetch_info;
        auto expire_time = fetch_info->_expired_time;


        //该函数只会去使用redis不会使用akv
        auto client = RedisClientManager::instance().get_client(fetch_info->_redis_client_id);
        if(client == nullptr){
            HILOG_APP(WARNING) <<fetch_info->_feature_name
                <<" redis client is nullptr, redis_client_id: " << fetch_info->_redis_client_id;
            return;
        }
        

        std::unordered_map<std::string,  std::shared_ptr<CacheValue<std::shared_ptr<google::protobuf::Message>>>> cache_map;
        for(auto&q : info->_redis_key_msg){
            auto response_ptr = std::make_shared<brpc::RedisResponse>();
            auto cntl_ptr = std::make_shared<brpc::Controller>();
            int ret = client->get_simple(q.first,cntl_ptr,response_ptr);
            HILOG_APP(INFO)<<fetch_info->_feature_name<<",key:"<<q.first;
            if(ret != 0){
                HILOG_APP(INFO)<<fetch_info->_feature_name<<",key:"<<q.first <<ret;
                continue;
            }
            
            ret = DataFetcher::instance()->check_redis_response(fetch_info,q.first,cntl_ptr,response_ptr);
            HILOG_APP(INFO)<<fetch_info->_feature_name<<",check_redis_response key:"<<q.first;
            if(ret != 0){
                continue;
            }


            ret = DataFetcher::instance()->process_redis_response(fetch_info,q.first,cntl_ptr,response_ptr,q.second);


            MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch_info->_feature_name,ret,"feature_value_size",q.second->ByteSize(),FsSource::REDIS,STRING_DEFAULT, STRING_TOTALUP);
            MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch_info->_feature_name,ret,"redis_response_size",response_ptr->ByteSize(),FsSource::REDIS,STRING_DEFAULT, STRING_TOTALUP);
            if(ret != 0){
                continue;
            }
            // status = 0
            std::string cache_key = q.first.find(STRING_DEFAULT) != std::string::npos?q.first.substr(fetch_info->_group_prefix.size()) : q.first.substr(fetch_info->_prefix.size());
            cache_map.insert({cache_key,std::make_shared< CacheValue< std::shared_ptr<google::protobuf::Message> > >(q.second, expire_time)});
        }
        HILOG_APP(INFO)<<fetch_info->_feature_name<<",store_data_map:"<< cache_map.size()<<","<<info->_is_online;
        put_message_feature_into_cache(fetch_info->_feature_name, cache_map);
    }
    void AsyncItemCacheManager::push_online_id_update(OnlineQuery* online){
        if(online == nullptr) return;
        auto it = _item_cache_map.find(online->_feature_name);
        if(it != _item_cache_map.end()){
            it->second->_online_queue->push(online);
        }
    }
}
