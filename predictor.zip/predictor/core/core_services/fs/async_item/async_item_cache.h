#ifndef _CORE_SERVICES_ITEM_CACHE_FS_H
#define _CORE_SERVICES_ITEM_CACHE_FS_H
#include <vector>
#include <string>
#include <atomic>
#include <memory>
#include <mutex>
#include "google/protobuf/message.h"
#include "core/core_services/fs/fetch/fetch_manager.h"
#include "core/core_services/fs/async_item/data_fetcher.h"
#include "core/core_services/fs/cache/fs_cache.h"
#include "itemfeature/ad_group_info.pb.h"
#include "json2pb/pb_to_json.h"
#include "common/comm/concurrent_map.h"
#include <boost/lockfree/queue.hpp>
const int32_t MAX_SLICE_NUM = 500;
const int32_t SLICE_BATCH_SIZE = 100;
const int32_t EXPIRE_TS = 172800;

namespace Core {
    struct SliceContext{
        std::vector<std::string> _item_ids;
        std::vector<std::string> _redis_key_ids;
        std::shared_ptr<std::atomic<int>> _batch_cnt;

        uint64_t _start_time = 0;
        uint64_t _end_time = 0;
        std::shared_ptr< std::atomic<int32_t> > _ctx_slplit_finish;
    };

    struct AsyncContext{
        AsyncContext();
        std::vector<std::shared_ptr<SliceContext>> _slice_arr_vec;
        std::shared_ptr< std::atomic<int32_t>> _slplit_finish;
        std::shared_ptr< std::atomic<int32_t>> _item_finish_cnt;
    };

    struct OnlineQuery{
        std::string _feature_name;
        std::vector<std::string> _query_ids;
    };

    using AsyncContextPtr = std::shared_ptr<AsyncContext>;

    class AsyncItemUpdate{
    public:
        int32_t _backet_num = MAX_SLICE_NUM;
        int32_t _refresh_interval_s = 30000;
        int64_t _last_refresh_ms = 0;
        int32_t _interval = 30;
        bool _initialized = false;
        bool _default_refresh = false;
        std::string _fetch_name;
        std::vector<std::string>  _backet_keys;
        std::shared_ptr<const FetchInfo> _fetch_info;
        std::shared_ptr<boost::lockfree::queue<OnlineQuery*>> _online_queue;
    public:
        AsyncItemUpdate(){

        }

        ~AsyncItemUpdate(){

        }

        bool init(const std::string& fetch_name,int interval,int backet_num = MAX_SLICE_NUM );
        virtual bool initialize(const std::string& fetch_name);
        virtual void run();
        virtual void refresh(AsyncContextPtr ctx,int32_t index);
        virtual void refresh_default();
        virtual void expire();
        virtual std::string make_item_key(const std::string& id){
            return "";
        }
        virtual bool check_black(const std::string& id){
            return false;
        }

        virtual void set_message_cache(
            const std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> >&result
            ,std::shared_ptr<std::unordered_map<std::string, int> > data_status,bool current = false){

        }

        virtual std::shared_ptr<google::protobuf::Message> gen_message(){
            return std::make_shared<tensorflow::SequenceExample>();
        };

    };

    void push_online_item_to_queue(const std::string&fea_name,const std::string&id);

    struct RedisQueryInfo{
        AsyncContextPtr _ctx;
        AsyncItemUpdate* _cache_item_update = nullptr;
        std::shared_ptr<const FetchInfo> _fetch_info;
        std::unordered_map<std::string,std::shared_ptr<google::protobuf::Message> > _redis_key_msg;
        bool _is_online = false;
    }; 
    void push_query_info_to_queue(RedisQueryInfo*info);
    void push_query_info_to_interact_queue(RedisQueryInfo* info);

    template<typename MESSAGE>
    class AsyncItemCache : public AsyncItemUpdate{
    private:
        std::string _redis_client_id;
       
    public:
        AsyncItemCache() {
        }

        ~AsyncItemCache(){

        }

        virtual void refresh(AsyncContextPtr ctx,int32_t index){
            auto slice_ctx = ctx->_slice_arr_vec[index];
            auto bucket_result_vec = std::make_shared<std::vector<std::string > >();
            DataFetcher::instance()->get_group_async( _backet_keys[index],index,_fetch_info,
                std::bind(&AsyncItemCache::slice_bucket, this,ctx,slice_ctx, index,std::placeholders::_1,std::placeholders::_2,std::placeholders::_3),
                bucket_result_vec
            );
            HILOG_APP(INFO) <<_fetch_name <<",refresh index:"<<index;
        }
    public:
        virtual bool initialize(const std::string& fetch_name){
            std::vector<std::shared_ptr<const FetchInfo>> fetch_list = FetchManager::instance().get_item_fetchs();
            for(auto&f : fetch_list){
                if(f->_feature_name == fetch_name){
                    _fetch_info = f;
                    for(int32_t b = 0;b<_backet_num;b++){
                        _backet_keys.emplace_back(make_bucket_key(b));
                    }
                    return true;
                }
            }
            return false;
        }
        virtual std::shared_ptr<google::protobuf::Message> gen_message(){
            return std::make_shared<MESSAGE>();
        }

        void all_item_done(std::shared_ptr<SliceContext> ctx,
            std::shared_ptr<std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> > >data_map,
            std::shared_ptr<std::unordered_map<std::string, int> >  data_map_status){
            std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> > store_data_map;
            int item_fail = 0;
            for (auto & item_feature_map : *data_map) {
                auto it = data_map_status->find(item_feature_map.first);
                if(it->second == 0){
                    store_data_map.insert({item_feature_map.first,item_feature_map.second});
                }else{
                    HILOG_APP(INFO) <<_fetch_name<<",status:"<<item_feature_map.first<<","<<it->second;
                    item_fail++;

                }
               
            }
            if(item_fail)
            HILOG_APP(ERROR) <<_fetch_name<<",all_item_done item_fail:"<<item_fail;
            if(store_data_map.size())set_message_cache(store_data_map,data_map_status);
        }

        void sync_item_slice(AsyncContextPtr aysnc_ctx,std::shared_ptr<SliceContext> ctx){
            int32_t split_size = 100,id_size = ctx->_item_ids.size();
            for(int i=0;i< id_size;){
                RedisQueryInfo* query_info = new RedisQueryInfo();
                query_info->_ctx = aysnc_ctx;
                query_info->_cache_item_update = this;
                query_info->_fetch_info = _fetch_info;
                int index = 0;
                do{
                    std::string redis_key = make_item_key(ctx->_item_ids[i]);
                    query_info->_redis_key_msg.insert({redis_key, gen_message()});
                    index++;
                    i++;
                    HILOG_APP(INFO)<<_fetch_info->_feature_name<<","<<redis_key;
                }while(index < split_size && i<id_size);
               
                push_query_info_to_queue(query_info);
            }
        }

        void items_slice(AsyncContextPtr aysnc_ctx,std::shared_ptr<SliceContext> ctx){
            if(ctx->_item_ids.size() <= 0){
                int32_t old = ctx->_ctx_slplit_finish->fetch_sub(1);
                if(old <= 1){
                    exchange_dbuffer_message_cache(_fetch_name);
                    HILOG_APP(ERROR)<<_fetch_name <<" exchange,item size:"<<ctx->_item_ids.size() <<",old:"<< old;
                }
            
                return;
            }
            int batch_size = ctx->_item_ids.size() + SLICE_BATCH_SIZE / ctx->_item_ids.size();
            HILOG_APP(INFO) <<_fetch_name <<",batch_size:"<<batch_size<<",item size:"<<ctx->_item_ids.size();
            std::shared_ptr<std::atomic<int>> count_cnd = std::make_shared<std::atomic<int>>(1);
            ctx->_batch_cnt.reset(new std::atomic<int>(batch_size));
            auto emb_result_vec = std::make_shared<std::vector<std::unordered_map<std::string,  std::shared_ptr<google::protobuf::Message> > > >();
            emb_result_vec->resize(batch_size);
            auto data_map = std::make_shared<std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> > >();
            auto data_map_status = std::make_shared<std::unordered_map<std::string, int>  >();
            
            for(auto&key : ctx->_item_ids){
                std::string redis_key = make_item_key(key);
                ctx->_redis_key_ids.push_back(redis_key);
                data_map->insert({redis_key, std::make_shared<MESSAGE>()});
                data_map_status->insert({redis_key, 0});
            }
            HILOG_APP(INFO) <<_fetch_name <<",batch_size:"<<batch_size<<",item size:"<<ctx->_item_ids.size()<<",redis key:"<< ctx->_redis_key_ids.size();
            DataFetcher::instance()->get_item_async(nullptr,ctx->_redis_key_ids, 0, ctx->_item_ids.size(),
                        std::bind(&AsyncItemCache::slice_one_batch, this,aysnc_ctx, std::placeholders::_1, count_cnd, std::placeholders::_2, ctx,  ctx->_item_ids.size(),std::placeholders::_3,std::placeholders::_4), 
                        _fetch_info, data_map,data_map_status);
        }


        void slice_one_batch(AsyncContextPtr aysnc_ctx,std::shared_ptr<std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> > > data_map,
            std::shared_ptr<std::atomic<int>> count_cnd,
            std::shared_ptr<std::unordered_map<std::string, int> >  data_map_status,
            std::shared_ptr<SliceContext> ctx, int batch_size, std::shared_ptr<std::atomic<int>> time_out_num, 
            std::shared_ptr<std::atomic<int>> kv_not_exist_num){
            HILOG_APP(INFO) <<_fetch_name<<",emb_result_vec.size:"<<data_map_status->size() <<",count_cnd:"<<count_cnd->load()
                <<",kv_not_exist_num:"<<kv_not_exist_num->load()<<",time_out_num:"<< time_out_num->load();\


            int old_count = count_cnd->fetch_sub(1);
            if (old_count != 1) {
                return;
            }

            all_item_done(ctx,data_map,data_map_status);
            int32_t old = ctx->_ctx_slplit_finish->fetch_sub(1);
            if(old <= 1){
                exchange_dbuffer_message_cache(_fetch_name);
                HILOG_APP(ERROR)<<_fetch_name <<"exchange,item size:"<<ctx->_item_ids.size() <<",old:"<< old;
            }

        }

        std::string make_item_key(const std::string& id){
            std::string key(_fetch_info->_prefix);
            key.append(id).append(_fetch_info->_postfix);
            return key;
        }

        std::string make_bucket_key(int32_t index){
            std::string key(_fetch_info->_group_prefix);
            key.append(std::to_string(index));
            return key;
        }

        virtual void set_message_cache(const std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> >&result,
                std::shared_ptr<std::unordered_map<std::string, int> > data_status,bool current = false){
            HILOG_APP(WARNING) <<_fetch_name<<",result.size:"<<result.size();
            std::unordered_map<std::string,  std::shared_ptr< CacheValue<std::shared_ptr<google::protobuf::Message> >  > > cache_map;
            for(const auto&r :result){
                std::string data,err;
                std::string cache_key = r.first.substr(_fetch_info->_prefix.size());
                //json2pb::ProtoMessageToJson(*(r.second.get()),&data,&err);
                //bool p = put_message_feature_into_cache(_fetch_info->_feature_name,cache_key,r.second,EXPIRE_TS);
                cache_map.insert({cache_key, std::make_shared< CacheValue< std::shared_ptr<google::protobuf::Message> > >(r.second,EXPIRE_TS)});
                HILOG_APP(INFO) <<_fetch_name<<" set cache:"<<r.first<<","<<data<<"cache_key:"<<cache_key<<","<<EXPIRE_TS;
            }
            //put_message_feature_into_cache(_fetch_info->_feature_name,cache_map);
            if(current == false){
                put_bak_dbuffer_message_feature_into_cache(_fetch_info->_feature_name,cache_map);
            }else{
                put_curr_dbuffer_message_feature_into_cache(_fetch_info->_feature_name,cache_map);
            }

            HILOG_APP(WARNING) <<_fetch_name<<" set cache:"<<_fetch_info->_feature_name<<",cache_map size:"<<cache_map.size()<<","<<EXPIRE_TS;
            // for(const auto&r :result){
            //     auto msg = put_bak_dbuffer_message_feature_into_cache(_fetch_info->_feature_name,r.first);
            //     std::string data,err;
            //     if(msg != nullptr)
            //     json2pb::ProtoMessageToJson(*(msg.get()),&data,&err);
            //     HILOG_APP(INFO) <<_fetch_name<<",get cache:"<<r.first<<","<<data;
            // }
        }

        void slice_bucket(AsyncContextPtr aysnc_ctx,std::shared_ptr<SliceContext> ctx,int32_t index,std::shared_ptr<std::vector<std::string > > result,int32_t size,int32_t code){
        
            std::set<std::string> key_set;
            for(auto&k : *result){
                if(key_set.find(k) == key_set.end()){
                    key_set.insert(k);
                    ctx->_item_ids.emplace_back(k);
                }
            }
            //默认最后一个分桶增加默认
            if(index == MAX_SLICE_NUM -1 && key_set.find(STRING_DEFAULT) == key_set.end()){
                ctx->_item_ids.emplace_back(STRING_DEFAULT);
                key_set.insert(STRING_DEFAULT);
            }

            aysnc_ctx->_item_finish_cnt->fetch_add(key_set.size());
            int32_t old = ctx->_ctx_slplit_finish->fetch_sub(1);
            if(old <= 1){
                HILOG_APP(ERROR)<<_fetch_name <<" exchange,item size:"<<ctx->_item_ids.size() <<",old:"<< old;
            }
            HILOG_APP(WARNING) <<_fetch_name <<",slice_bucket index:"<<index<<",code:"<<code<<",size:"<<size<<",_item_ids size:"<<ctx->_item_ids.size();
            //items_slice(aysnc_ctx,ctx);
            sync_item_slice(aysnc_ctx,ctx);
        }

    };

    template<typename MESSAGE>
    class AsyncNearlineItemCache : public AsyncItemUpdate{
    private:
        std::string _redis_client_id;
       
    public:
        AsyncNearlineItemCache() {
        }

        ~AsyncNearlineItemCache(){

        }

   
    public:
        virtual bool initialize(const std::string& fetch_name){
            std::vector<std::shared_ptr<const FetchInfo>> fetch_list = FetchManager::instance().get_item_fetchs();
            for(auto&f : fetch_list){
                if(f->_feature_name == fetch_name){
                    _fetch_info = f;
                    return true;
                }
            }
            return false;
        }

        virtual void refresh_default(){
            auto* online_item_default = new OnlineQuery();
            online_item_default->_feature_name.assign(_fetch_info->_prefix);
            online_item_default->_query_ids.emplace_back(STRING_DEFAULT);
            _online_queue->push(online_item_default);
       }

        virtual std::shared_ptr<google::protobuf::Message> gen_message(){
            return std::make_shared<MESSAGE>();
        }

        virtual bool check_black(const std::string& id){
            auto black_msg =  get_black_message_feature_from_cache(_fetch_name,id);
            return black_msg != nullptr;
        }
        
        std::string make_item_key(const std::string& id){
            std::string key(_fetch_info->_prefix);
            key.append(id).append(_fetch_info->_postfix);
            return key;
        }


        virtual void set_message_cache(const std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> >&result,
                std::shared_ptr<std::unordered_map<std::string, int> > data_status,bool current = false){
            HILOG_APP(WARNING) <<_fetch_name<<",result.size:"<<result.size();
            if(result.size() == 0) return;
            std::unordered_map<std::string,  std::shared_ptr< CacheValue<std::shared_ptr<google::protobuf::Message> >  > > cache_map;
            for(const auto&r :result){
                std::string data,err;
                std::string cache_key = r.first.substr(_fetch_info->_prefix.size());
                cache_map.insert({cache_key, std::make_shared< CacheValue< std::shared_ptr<google::protobuf::Message> > >(r.second,_fetch_info->_expired_time)});
                HILOG_APP(INFO) <<_fetch_name<<" set cache:"<<r.first<<","<<data<<"cache_key:"<<cache_key<<","<<_fetch_info->_expired_time;
            }
            put_item_nearline_message_feature_into_cache(_fetch_info->_feature_name,cache_map);
            for(const auto&s :*data_status){//无值需要存黑名单
                if(s.second == -2){
                    std::string cache_key = s.first.substr(_fetch_info->_prefix.size());
                    bool black_ret = put_black_message_feature_into_cache(_fetch_info->_feature_name,cache_key,gen_message(),_fetch_info->_expired_time);
                    HILOG_APP(WARNING)<<_fetch_info->_feature_name <<" nearline :"<<cache_key <<" store black :"<<black_ret;
                }
            }

            HILOG_APP(WARNING) <<_fetch_name<<" set cache:"<<_fetch_info->_feature_name<<",cache_map size:"<<cache_map.size()<<","<<_fetch_info->_expired_time;
 
        }

    };

    class AsyncItemCacheManager {
    public:
        std::shared_ptr<boost::lockfree::queue<RedisQueryInfo*>> _query_info_queue;
        std::shared_ptr<boost::lockfree::queue<RedisQueryInfo*>> _query_info_interact_queue;
        std::map<std::string, std::shared_ptr<AsyncItemUpdate> >  _item_cache_map;
        std::vector<std::thread > _tids;
        ConcurrentMap<std::string , std::string > _item_feature_2_group;
    private:
        AsyncItemCacheManager(){

        }
    public:
        int init();
        void register_cache();

        static AsyncItemCacheManager& instance() {
            static AsyncItemCacheManager inst;
            return inst;
        }
        template<typename M>
        std::shared_ptr<AsyncItemUpdate> createAsyncItemCache(const std::string& fetch_name,int interval,int backet_num){
            std::shared_ptr<AsyncItemUpdate>cache_ptr = nullptr;
            if(backet_num > 0){
                cache_ptr = std::make_shared< AsyncItemCache<M> >();
            }else{
                cache_ptr = std::make_shared< AsyncNearlineItemCache<M> >();
            }
            HILOG_APP(WARNING) <<fetch_name<< ",interval:"<<interval<<",backet_num:"<<backet_num<<" init ";
            if(cache_ptr->init(fetch_name,interval,backet_num)){
                //add_message_cache(fetch_name);
                if(backet_num > 0){//item
                    add_dbuffer_message_cache(fetch_name);
                }
                else{ //nearline
                    add_item_nearline_message_cache(fetch_name);
                    add_black_message_cache(fetch_name);
                }
            }else{
                HILOG_APP(WARNING) <<fetch_name<< ",interval:"<<interval<<",backet_num:"<<backet_num<<" init fail";
            }
            return cache_ptr;
        }
        void start_update();
        //query
        static void handle(AsyncItemCacheManager* mgr);
        static void handle_interact(AsyncItemCacheManager* mgr);
        static void query_and_store(const RedisQueryInfo*info);
        static void query_and_store_interact(const RedisQueryInfo* info);
        void push_query_info(RedisQueryInfo*info);
        void push_interact_query_info(RedisQueryInfo* info);
        //update query
        void push_online_id_update(OnlineQuery* online);
        void update_interact_default_data();
        void refresh_interact_data(std::shared_ptr<const FetchInfo> fetch_info,std::shared_ptr< std::map<size_t ,std::vector<std::string>>> keys );
        const std::string& get_item_group_name(const std::string&k);
    };

}//core
#endif
