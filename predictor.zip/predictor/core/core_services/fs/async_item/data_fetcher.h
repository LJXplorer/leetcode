#ifndef _CORE_SERVICES_DATA_FETCH_H
#define _CORE_SERVICES_DATA_FETCH_H

#include "core/core_services/fs/redis_client/redis_client.h"
#include "core/core_context/core_context.h"
#include "core/core_services/fs/fetch/fetch_manager.h"
#include "google/protobuf/message.h"
#include <memory>
#include <map>

namespace Core{
    using CoreContextPtr = std::shared_ptr<CoreContext>;
    
class DataFetcher {
private:
    DataFetcher() {
    }
public:
    using ParseFunc = std::function<void(void)> ;
    static DataFetcher* instance() {
        static DataFetcher inst;
        return &inst;
    }

    void get_item_async(CoreContextPtr context,const std::vector<std::string>& keys, int start, int end,
        std::function<void( std::shared_ptr<std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> >>, 
        std::shared_ptr<std::unordered_map<std::string, int> >,
        std::shared_ptr<std::atomic<int>> time_out_num,std::shared_ptr<std::atomic<int>> kv_not_exist_num ) > call_back,
        std::shared_ptr<const FetchInfo> fetch, 
        std::shared_ptr<std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> >> data_map,
        std::shared_ptr<std::unordered_map<std::string, int> > data_map_status );
    
    void get_group_async(const std::string& key, int32_t index,std::shared_ptr<const FetchInfo> fetch,
            std::function<void( std::shared_ptr< std::vector<std::string > >,int32_t item_size,int32_t error_code)> call_back,
            std::shared_ptr<std::vector<std::string > > vec_result);

    int process_redis_response(std::shared_ptr<const FetchInfo> fetch,const std::string& key, 
        std::shared_ptr<brpc::Controller> cntl_ptr,std::shared_ptr<brpc::RedisResponse> response,
        std::shared_ptr<google::protobuf::Message> msg_ptr);
    int check_redis_response(std::shared_ptr<const FetchInfo> fetch,const std::string& key,
        std::shared_ptr<brpc::Controller> cntl_ptr,std::shared_ptr<brpc::RedisResponse> response);
};

}

#endif