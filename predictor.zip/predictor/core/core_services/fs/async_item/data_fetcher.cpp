#include "core/core_services/fs/async_item/data_fetcher.h"
#include "common/hilog/log_helper.h"
#include "core/core_services/fs/redis_client/redis_client.h"
#include "core/core_services/fs/redis_client/redis_client_manager.h"
#include "core/utils/defs.h"
#include "gflags/gflags.h"
#include <boost/algorithm/string.hpp>
#include "json2pb/pb_to_json.h"
#include <boost/locale.hpp>
#include <debug_utils.h>
#include "common/comm/charsets.h"
#include "brpc/policy/gzip_compress.h"

#include <memory>
#include <wrapper_time.h>
#include "core/utils/monitor_mgr.h"
namespace Core{
DEFINE_int32(offline_item_refresh_us, 15*1000, "offline_item_refresh_us");
DEFINE_int32(offline_item_refresh_batch_size, 50, "offline_item_refresh_batch_size");
DEFINE_int32(offline_item_refresh_batch_split_size, 200, "offline_item_refresh_batch_split_size");
void DataFetcher::get_item_async(CoreContextPtr context,const std::vector<std::string>& keys, int start, int end,
    std::function< void(std::shared_ptr<std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> > >, 
    std::shared_ptr<std::unordered_map<std::string, int> >,
    std::shared_ptr<std::atomic<int>> time_out_num, 
    std::shared_ptr<std::atomic<int>> kv_not_exist_num )  > call_back,
    std::shared_ptr<const FetchInfo> fetch, std::shared_ptr<std::unordered_map<std::string, std::shared_ptr<google::protobuf::Message> > >  data_map,
    std::shared_ptr<std::unordered_map<std::string, int> > data_map_status) {

    std::shared_ptr<std::unordered_map<std::string, bool>> feature_use_akv_map;
    std::shared_ptr<RedisClient> client = nullptr;
    FsSource fs_source = FsSource::REDIS;

    if (!context) {
        client = RedisClientManager::instance().get_client(fetch->_redis_client_id);
    } else if (context->_feature_use_akv_map) {
        feature_use_akv_map = context->_feature_use_akv_map;
        auto it = feature_use_akv_map->find(fetch->_feature_name);
        if (it != feature_use_akv_map->end()) {
            if (it->second) {
                client = RedisClientManager::instance().get_client(fetch->_akv_client_id);
                fs_source = FsSource::AKV;
            } else {
                client = RedisClientManager::instance().get_client(fetch->_redis_client_id);
            }
        } else {
            client = RedisClientManager::instance().get_client(fetch->_redis_client_id);
        }
    } else {
        client = RedisClientManager::instance().get_client(fetch->_redis_client_id);
    }

    auto time_out_cnd = std::make_shared<std::atomic<int>>(0);
    auto kv_not_exist_cnd = std::make_shared<std::atomic<int>>(0);
    if (client) {
        auto count_cnd = std::make_shared<std::atomic<int>>(end - start);
        for (int i = start; i < end; i++) {
            // HILOG_APP(INFO) <<fetch->_feature_name <<",keys_size:"<<keys.size()<<"start:"<<start<<",end:"<<end<<",key:"<<keys[i];
            if (i >= keys.size()) {
                HILOG_APP(ERROR)<<fetch->_feature_name << " i: " << i << " keys size: " << keys.size() << " i is greater than size, code error";
                break;
            }
            auto& key = keys[i];
            auto redis_back = [this,data_map,data_map_status,fetch, key, count_cnd, call_back,time_out_cnd,kv_not_exist_cnd,fs_source]
                (std::shared_ptr<brpc::RedisResponse> response, std::shared_ptr<brpc::Controller> cntl_ptr) {
                auto msg_satus_it = data_map_status->find(key);
                msg_satus_it->second = check_redis_response(fetch,key,cntl_ptr,response);
                if(msg_satus_it->second == 0){
                    auto msg_it = data_map->find(key);
                    if( msg_it != data_map->end()){
                        int ret = process_redis_response(fetch,key,cntl_ptr,response,msg_it->second);
                        MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch->_feature_name,ret,"feature_value_size",msg_it->second->ByteSize(),fs_source, STRING_DEFAULT, STRING_TOTALUP);
                        MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch->_feature_name,msg_satus_it->second,"redis_response_size",response->ByteSize(),fs_source,STRING_DEFAULT, STRING_TOTALUP);
                    }
                } else if(msg_satus_it->second == -1){
                    time_out_cnd->fetch_add(1);
                }else if(msg_satus_it->second == -6){
                    kv_not_exist_cnd->fetch_add(1);
                }
                MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch->_feature_name,msg_satus_it->second,"redis_total_cost",cntl_ptr->latency_us(),fs_source,STRING_DEFAULT, STRING_TOTALUP);
                MonitorMgr::redis_report_common(STRING_DEFAULT, fetch->_feature_name, msg_satus_it->second,"fetch_num",1,fs_source, STRING_DEFAULT, STRING_TOTALUP);
                auto old_count = count_cnd->fetch_sub(1);
                if (old_count == 1) {
                    call_back(data_map,data_map_status, time_out_cnd, kv_not_exist_cnd);
                }
            };

            client->get_simple(key, redis_back); 

            if ( FLAGS_offline_item_refresh_us > 0 && keys.size() >= FLAGS_offline_item_refresh_batch_split_size && i % FLAGS_offline_item_refresh_batch_size == 0) {
                usleep(FLAGS_offline_item_refresh_us);
            }
        }

    } else {
        HILOG_APP(WARNING) << "redis client is nullptr, redis_client_id: " << fetch->_redis_client_id;
        call_back(data_map,data_map_status, time_out_cnd, kv_not_exist_cnd);
    }
}

void DataFetcher::get_group_async(const std::string& key, int32_t index,std::shared_ptr<const FetchInfo> fetch,
            std::function< void(std::shared_ptr<std::vector<std::string > >,int32_t,int32_t )> call_back,
            std::shared_ptr<std::vector<std::string > > vec_result){
    auto client = RedisClientManager::instance().get_client(fetch->_redis_client_id);

    if (client) {
        HILOG_APP(WARNING)<<fetch->_redis_client_id<< " get_group_async request, key: " << key<<",name:"<<fetch->_feature_name;
        auto redis_back = [key, fetch, vec_result, call_back](std::shared_ptr<brpc::RedisResponse> response,
                                                              std::shared_ptr<brpc::Controller> cntl_ptr) {
            //该函数不会去使用akv，只会去使用redis
            int32_t error_code = 0;
            int32_t item_size = 0;
            if (cntl_ptr->Failed()) {
                HILOG_APP(WARNING) << "get_group_async response redis key failed, key: " << key<<","<<cntl_ptr->ErrorText();
                error_code = -1;
                MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch->_feature_name,error_code,"redis_total_cost",cntl_ptr->latency_us(),FsSource::REDIS,STRING_DEFAULT, STRING_TOTALUP);
                MonitorMgr::redis_report_common(STRING_DEFAULT, fetch->_feature_name, error_code,"fetch_num",1,FsSource::REDIS,STRING_DEFAULT, STRING_TOTALUP);
                call_back(vec_result, item_size, error_code);
                return;
            }

            if (response == nullptr || response->reply_size() <= 0 || response->reply(0).is_nil() ||
                !response->reply(0).is_string() || response->reply(0).data().size() == 0) {
                error_code = -2;
                MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch->_feature_name,error_code,"redis_total_cost",cntl_ptr->latency_us(),FsSource::REDIS, STRING_DEFAULT, STRING_TOTALUP);
                MonitorMgr::redis_report_common(STRING_DEFAULT, fetch->_feature_name, error_code,"fetch_num",1,FsSource::REDIS,STRING_DEFAULT, STRING_TOTALUP);
                HILOG_APP(WARNING) << "get_group_async get invalide response, key: " << key<<",error_code:"<<error_code<<",name:"<<fetch->_feature_name;
                call_back(vec_result, item_size, error_code);
                return;
            }
            unsigned int data_size = response->reply(0).data().size();
            try {
                std::string data_str(response->reply(0).data().data(), data_size);
                int ret = 0;
                if(fetch->_compress == "gzip"){
                    std::string conv_str;
                    ret = charsets::to_88591(data_str.c_str(), data_str.size(), conv_str);
                    if(ret == 0){
                        butil::IOBuf input, output;
                        input.append(conv_str);
                        if (brpc::policy::GzipDecompress(input,&output)) {
                            if(!output.empty()){
                                data_str.clear();
                                output.copy_to(&data_str);
                            }
                        } else {
                            HILOG_APP(ERROR)<<"group key: "<<key << " One redis bucket key uncompress failed, redis_client: " << fetch->_feature_name
                            <<",data_size: "<<data_size<<" ,conv_data size: "<< conv_str.size();
                            ret = -10;
                        }
                    }
                }
                if(ret == 0 || ret == -10){
                    boost::split(*(vec_result.get()), data_str, boost::is_any_of(",,"),boost::token_compress_on);
                }
                MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch->_feature_name,ret,"feature_value_size",data_str.size(),FsSource::REDIS,STRING_DEFAULT, STRING_TOTALUP);
                MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch->_feature_name,error_code,"redis_response_size",response->ByteSize(),FsSource::REDIS,STRING_DEFAULT, STRING_TOTALUP);
                HILOG_APP(INFO)<< "key: " << key<< " get_group_async response redis_client:"<<fetch->_redis_client_id<<",reply i:"<<vec_result->size()<<",name:"<<fetch->_feature_name
                    <<","<<data_str.size() << ", ret: " << ret;

                auto isnt_DSP_Data = [](const std::string& str) -> bool {
                    if (str.length() != 11) {
                        return false;
                    }
                    for (char ch : str) {
                        if (!std::isdigit(ch)) {
                            return false;
                        }
                    }
                    return true;
                };
                
                if(fetch->_is_callback == "false" && vec_result) {
                    std::vector<std::string > no_DSP_vec_result;
                    for(const auto& str : *vec_result){
                        if(isnt_DSP_Data(str)){
                            no_DSP_vec_result.push_back(str);
                        }                    
                    }
                    no_DSP_vec_result.swap(*vec_result);
                }                
            } catch (const std::exception& e) {
                HILOG_APP(WARNING)<<"response redis_client: " << fetch->_redis_client_id<< " key: " << key << " insert to vec_result has exception: " << e.what()<<",name:"<<fetch->_feature_name;
            }
            MonitorMgr::redis_report_percent(STRING_DEFAULT, fetch->_feature_name,error_code,"redis_total_cost",cntl_ptr->latency_us(),FsSource::REDIS,STRING_DEFAULT, STRING_TOTALUP);
            MonitorMgr::redis_report_common(STRING_DEFAULT,fetch->_feature_name, error_code,"fetch_num",1,FsSource::REDIS,STRING_DEFAULT, STRING_TOTALUP);
            call_back(vec_result, vec_result->size(), error_code);
        };
        client->get_simple(key, redis_back, 1000); // timeout: 100ms

    } else {
        HILOG_APP(WARNING) << "request redis client is nullptr, redis_client_id: " << fetch->_redis_client_id<<",name:"<<fetch->_feature_name;
        call_back(vec_result, 0, -1);
    }
}

    int DataFetcher::process_redis_response(std::shared_ptr<const FetchInfo> fetch,const std::string& key, 
        std::shared_ptr<brpc::Controller> cntl_ptr,std::shared_ptr<brpc::RedisResponse> response,
        std::shared_ptr<google::protobuf::Message> msg_ptr){

        unsigned int data_size = response->reply(0).data().size();
        int ret = 0;
        try {
            std::string conv_data ;
            ret = charsets::to_88591(response->reply(0).data().data(),data_size,conv_data);
            if (ret == 0) {
                if(fetch->_compress == "gzip"){
                    butil::IOBuf input,output;
                    input.append(conv_data);
                    if (brpc::policy::GzipDecompress(input,&output)) {
                        if(!output.empty()){
                            output.copy_to(&conv_data);
                        }
                    } else {
                        HILOG_APP(WARNING)<<"key:"<<key << "One ad_id's feature uncompress failed,  redis_client: " << fetch->_feature_name
                        <<",data_size:"<<data_size<<",conv_data size:"<<conv_data.size();
                        // ret = -5;
                    }
                }
                if (msg_ptr->ParseFromArray(conv_data.c_str(),conv_data.size())) {
                    // HILOG_APP(INFO)<< "key: " << key<< " ParseFromArray succ redis_client:"<<fetch->_redis_client_id<<",data_size:"<<data_size<<",conv_data size:"<<conv_data.size();
                } else {
                    HILOG_APP(WARNING)<<"key:"<<key << "One ad_id's feature parse failed,  redis_client: " << fetch->_feature_name
                        <<",data_size:"<<data_size<<",conv_data size:"<<conv_data.size();
                    ret = -2;
                }
                
                // std::string data,err;
                // json2pb::ProtoMessageToJson(*(msg_it->second.get()),&data,&err);

                // HILOG_APP(INFO)<< "key: " << key<< "json data:"<<fetch->_redis_client_id<<",data_size:"<<data_size<<","
                // <<",conv_data size:"<<conv_data.size();
            } else {
                HILOG_APP(ERROR) << "key: " << key << " do not reserved in data_map, code error redis_client: " << fetch->_feature_name
                <<",ret:"<<ret;
                ret = -4;
            }
        } catch (const std::exception& e) {
            ret = -3;
            HILOG_APP(WARNING)<<"redis_client: " << fetch->_redis_client_id<< " key: " << key << " insert to datamap has exception: " << e.what();
        }
        return ret;
    }

    int DataFetcher::check_redis_response(std::shared_ptr<const FetchInfo> fetch,const std::string& key,
            std::shared_ptr<brpc::Controller> cntl_ptr,std::shared_ptr<brpc::RedisResponse> response){
        if (cntl_ptr->Failed()) {
            HILOG_APP(WARNING)<< fetch->_feature_name<< " response redis key failed, key: " << key<<","<<cntl_ptr->ErrorText();
            return  -1;
        }
        int error_code = 0;
        if (response == nullptr) {
            error_code = -1;
        } else if (response->reply_size() < 0) {
            error_code = -6;
        } else if (response->reply(0).is_nil()) {
            error_code = -2;
        } else if (!response->reply(0).is_string()) {
            error_code = -6;
        }
        if(error_code)
        HILOG_APP(WARNING) << "check_redis_response response, key: " 
                << key<<",error_code:"<<error_code<<",name:"<<fetch->_feature_name;

        return error_code;
    }
}//core