
#include "common/hilog/log_helper.h"
#include <boost/algorithm/string.hpp>
#include <string>
#include "core/core_context/monitor_context.h"
#include "core/utils/monitor_mgr.h"
#include "fetch/fetch_manager.h"
#include "redis_client/redis_client_manager.h"
#include "core/core_services/fs/user_fs_service.h"
#include "core/core_services/fs/fetch/feature_utils.h"
namespace Core {
        SERVICE_REGISTER(UserFsService);
        void UserFsService::initialize(GraphContextPtr context){
            auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
            ctx->get_monitor_context()->alloc_node(get_name());           
        }

        void UserFsService::initialize(ConfigXmlPtr xml) {
            xml->attr<std::string>("handle_query_enable", _handle_query_enable, "true");
            initialize_xml(xml);
    }

        void UserFsService::initialize_xml(ConfigXmlPtr xml) { }

        
        bool UserFsService::get_fetch(CoreContextPtr context, std::vector<std::shared_ptr<const FetchInfo> >& fetch_vec, std::unordered_map<std::string, std::vector<std::shared_ptr<const FetchInfo> >>& hash_fetch_map){
            const auto & all_fetchs = FetchManager::instance().get_fetchs();
            auto item_stat_ptr = get_node_stat(context);
            for(const auto&f : all_fetchs){
                //如果不包含AllowScene
                if (!ai_feature::selectFeature(f, context)) {
                    continue;
                }
                // 空query不查询redis
                if (f->_feature_type == "query") {
                    if (_handle_query_enable=="true" && context->get_handled_query().empty()) {
                        continue;
                    }
                    else if (context->get_query().empty()){
                        continue;
                    }
                }
                if (f->_cmd == "get") {
                    fetch_vec.emplace_back(f);
                }
                else {                    
                    hash_fetch_map[f->_cluster_id].emplace_back(f);
                }
                StatRpc sr;
                UpRpc ur;
                sr._source=FsSource::REDIS;
                ur._source = FsSource::REDIS;
                item_stat_ptr->_redis_extra_map.insert({f->_cluster_id,sr});
                item_stat_ptr->_up_extra_map.insert({f->_up_id,ur});
            }
            
            return true;
        }

        bool UserFsService::make_fetch_key(CoreContextPtr context,std::shared_ptr<const FetchInfo> fetch,std::string& key){
            if (fetch->_cmd == "get") {
                if(fetch->_feature_type == "oaid"){
                    key.append(context->get_oaid());
                }else if(fetch->_feature_type == "query"){
                    if (_handle_query_enable=="true") {
                        key.append(context->get_handled_query());
                    }else{
                        key.append(context->get_query());
                    }
                }else if(fetch->_feature_type == "user_mediaId"){
                    key.append(std::to_string(context->get_media_id()));
                }else if(fetch->_feature_type == "user_adunitId"){
                    key.append(std::to_string(context->get_slot_id()));
                }
                key.append(fetch->_sep);
                key.append(fetch->_up_id);

            }
            else {
                if(fetch->_feature_type == "oaid"){
                    key.append(context->get_oaid());
                }else if(fetch->_feature_type == "query"){
                    if (_handle_query_enable=="true") {
                        key.append(context->get_handled_query());
                    }else{
                        key.append(context->get_query());
                    }
                }else if(fetch->_feature_type == "user_mediaId"){
                    key.append(std::to_string(context->get_media_id()));
                }else if(fetch->_feature_type == "user_adunitId"){
                    key.append(std::to_string(context->get_slot_id()));
                }
                key.append(fetch->_sep);
                key.append(fetch->_cluster_id);
            }
            
            return true;
        }
}
