#ifndef _CORE_SERVICES_FS_REDIS_MANEGER_H
#define _CORE_SERVICES_FS_REDIS_MANEGER_H

#include "redis_client.h"
#include <unordered_map>
namespace Core {

class RedisClientManager {
private:
    RedisClientManager(){}
    public:
    std::unordered_map<std::string, std::shared_ptr<RedisClient>> _client_map;
public:
    bool init(const std::string& path);
    std::shared_ptr<RedisClient> get_client(const std::string& id);
    static RedisClientManager& instance() {
        static RedisClientManager inst;
        return inst;
    }
};



} // end of namespace client

#endif
