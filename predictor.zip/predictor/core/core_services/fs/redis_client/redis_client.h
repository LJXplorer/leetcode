#ifndef _CORE_SERVICES_FS_REDIS_H
#define _CORE_SERVICES_FS_REDIS_H

#include <brpc/redis.h>
#include <brpc/channel.h>
#include <memory>
#include "channel_pool.h"
#include <thread>
#include <vector>

namespace Core{
struct NodeInfo {
    public:
        bool ParseNodeString(const std::string &nodeString);
        void ParseSlotString(const std::string &SlotString);
    public:
        std::string _strinfo;
        // The node ID, a 40 characters random string generated when a node is created and never changed again (unless CLUSTER RESET HARD is used)
        std::string _id;        
        // The node IP     
        std::string _ip;    
        // The node port
        uint16_t _port;   
        // A list of comma separated flags: myself, master, slave, fail?, fail, handshake, noaddr, noflags
        std::string _flags;  
        bool _is_fail; 
        // true if node is master, false if node is salve
        bool _is_master;     
        bool _is_slave;
        // The replication master
        std::string _master_id; 
        int32_t _ping_sent;    
        // Milliseconds unix time the last pong was received
        int32_t _pong_recv;      
        // The configuration epoch (or version) of the current node (or of the current master if the node is a slave).
        // Each time there is a failover, a new, unique, monotonically increasing configuration epoch is created.
        // If multiple nodes claim to serve the same hash slots, the one with higher configuration epoch wins
        int32_t _epoch;         
        // The state of the link used for the node-to-node cluster bus   
        bool _connected;     
        // A hash slot number or range
        std::vector<std::pair<uint32_t, uint32_t> > _mSlots;
};

class RedisClient {
public:
    std::string _url;
    std::string _pass;
    uint64_t _time_out;
    int _update_interval;
    uint32_t _pool_size;
    int _max_retry;
    bool _running;
    bool _is_akv;
    
    std::shared_ptr<std::thread> _thread_ptr;
    std::vector<std::shared_ptr<ChannelPool>> _channel_pool_vec;
    std::atomic<int> _pool_index;
public:
    RedisClient(const std::string& url, const std::string& pass,
                uint64_t time_out, int update_interval, uint32_t pool_size,bool is_akv = false,int max_retry = 0) noexcept;
    virtual ~RedisClient() {
    }
public:
    bool init();
    int set(const std::string& key, const char* value, size_t value_size,
            std::function<void(std::shared_ptr<brpc::RedisResponse>, std::shared_ptr<brpc::Controller> cntl_ptr)> call_back,
            int64_t timeout_ms = -1, int max_retry = -1,
            int expire_time = 0);
    int get_simple(const std::string& key,
                   std::function<void(std::shared_ptr<brpc::RedisResponse>, std::shared_ptr<brpc::Controller> cntl_ptr)> call_back,
                   int64_t timeout_ms = -1, int max_retry = -1);
    int get_simple(const std::string& key,std::shared_ptr<brpc::Controller> cntl_ptr,std::shared_ptr<brpc::RedisResponse>&rsp,
            int64_t timeout_ms = -1, int max_retry = -1);
    int hget_simple(const std::string& key, const std::string& field,
                    std::function<void(std::shared_ptr<brpc::RedisResponse>, std::shared_ptr<brpc::Controller> cntl_ptr)> call_back,
                    int64_t timeout_ms = -1, int max_retry = -1);
    int mget_simple(const std::vector<std::string>& keys,
                    std::function<void(std::shared_ptr<brpc::RedisResponse>, std::shared_ptr<brpc::Controller> cntl_ptr)> call_back,
                    int64_t timeout_ms = -1, int max_retry = -1);
    int hmget_multiple_fields(const std::string& key, const std::vector<std::string>& fields,
                    std::function<void(std::shared_ptr<brpc::RedisResponse>, std::shared_ptr<brpc::Controller> cntl_ptr)> call_back,
                    int64_t timeout_ms = -1, int max_retry = -1);

    void set_response_handler(std::shared_ptr<brpc::Controller> cntl_ptr,
        std::shared_ptr<brpc::RedisResponse> response_ptr,
        std::function<void(std::shared_ptr<brpc::RedisResponse>, std::shared_ptr<brpc::Controller> cntl_ptr)> call_back);
    // auto latency = -a start;
    void update_channel_pool();


    bool is_channel_pool_changed();

    bool init_channel_pool(std::shared_ptr<ChannelPool> channel_pool);

    bool init_akv_channel_pool(std::shared_ptr<ChannelPool> channel_pool);

    void init_slot_node_map(std::vector<int>& slot_ipport_index_vec, const std::vector<NodeInfo>& nodes);
    bool init_channel(int32_t idx, const std::string &host, 
                        uint32_t port, uint32_t poolsize, int64_t timeout_ms, const std::string& lb,
                        std::vector<std::shared_ptr<ConnectPool<brpc::Channel>>>& m_channel_list);

    bool init_channel(int32_t idx, const std::string &host, 
                        uint32_t port, uint32_t poolsize, int64_t time_out, const std::string& load_balancer,
                        std::vector<std::shared_ptr<brpc::Channel>>& m_channel_list);

};

using redis_client_ptr = std::shared_ptr<RedisClient>;
} // end of namespace client

#endif
