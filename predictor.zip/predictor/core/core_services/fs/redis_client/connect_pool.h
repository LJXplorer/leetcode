#ifndef _CORE_SERVICES_FS_REDIS_CONNECT_POOL_H
#define _CORE_SERVICES_FS_REDIS_CONNECT_POOL_H
#include <memory>
#include <list>
#include <string>
#include <functional>
#include "common/hilog/log_helper.h"
#include <butil/fast_rand.h>

namespace Core {

using namespace hilog;
/*
一个大小为pool_size的连接池，连接资源紧张时会自动扩张到max_size，但最大不能超过max_size，
资源紧张情况消失时连接池又会恢复到pool_size
*/
template <typename Conn>
class ConnectPool {
public:
    using BuildFunc = std::function<std::shared_ptr<Conn>(void)> ;
    BuildFunc _build_connection;
    uint32_t _pool_size = 0;
    uint32_t _max_size = 0;
    uint32_t _borrow_size = 0;
    uint32_t _busy = 0;
    std::vector<std::shared_ptr<Conn>> _conn_list;
    std::mutex mut;
public:
    ConnectPool(uint32_t pool_size, uint32_t max_size, BuildFunc build_connection) noexcept :
    _pool_size(pool_size), _max_size(max_size), _build_connection(build_connection) {
        if (_pool_size > max_size) {
            throw std::runtime_error("pool_size should not be greater than max_size, pool_size: " + std::to_string(_pool_size)
            + " max_size: " + std::to_string(_max_size));
        }
        for (size_t i = 0; i < _pool_size; i++){
            auto conn = build_connection();
            if (conn == nullptr) {
                HILOG_APP(WARNING) << "build_connection return nullptr, error!";
            } else {
                _conn_list.push_back(conn);
            }
        }
    }

    std::shared_ptr<Conn> borrow(int* borrow_size = nullptr) {
        size_t index = butil::fast_rand() % _conn_list.size();
        return _conn_list[index];
    }

    bool release(std::shared_ptr<Conn> conn) {
	return true;
    }
};
} // end of namespace

#endif
