#include "redis_client.h"
#include <vector>
#include <memory>
#include "brpc/callback.h"
#include <boost/algorithm/string.hpp>
#include <chrono>
#include <boost/algorithm/string.hpp>
#include "common/hilog/log_helper.h"
#include <gflags/gflags.h>
#include "common/comm/debug_utils.h"


DEFINE_int32(init_redis_max_retry, 10, "init redis max retry");
using namespace hilog;

namespace Core {

//   rr                           # round robin, choose next server
//   random                       # randomly choose a server
//   la                           # locality aware
//   c_murmurhash/c_md5           # consistent hashing with murmurhash3/md5
//   "" or NULL  
RedisClient::RedisClient(const std::string& url, const std::string& pass, uint64_t time_out, 
                           int update_interval, uint32_t pool_size, bool is_akv,int max_retry ) noexcept :
                           _url(url), _pass(pass), _time_out(time_out), _update_interval(update_interval),
                           _pool_size(pool_size) ,_is_akv(is_akv), _max_retry(max_retry) {
}


bool RedisClient::init() {
    _channel_pool_vec.resize(2);
    _channel_pool_vec[0] = std::make_shared<ChannelPool>();
    _channel_pool_vec[1] = std::make_shared<ChannelPool>();
    _pool_index.store(0, std::memory_order_release);
    int pool_index_t = _pool_index.load(std::memory_order_acquire);
    auto channel_pool = _channel_pool_vec[_pool_index];
    bool init_channel_pool_suc = false;
    int retry_times = 0;
    while (retry_times < FLAGS_init_redis_max_retry) {
        if(_is_akv){
            init_channel_pool_suc = init_akv_channel_pool(channel_pool);
        }else{
            init_channel_pool_suc = init_channel_pool(channel_pool);
        }
        
        if (init_channel_pool_suc) {
            break;
        } else {
            retry_times++;
            sleep(1);
        }
    }
    if (!init_channel_pool_suc) {
        HILOG_APP(ERROR) << "redis channel pool init failed: " << _url;
        return false;
    }
    
    this->_running = true;
    _thread_ptr = std::make_shared<std::thread>(&RedisClient::update_channel_pool, this);
    _thread_ptr->detach();
    return true;
}

void RedisClient::update_channel_pool() {
    while(1) {
        std::this_thread::sleep_for(std::chrono::seconds(_update_interval));
        try {
            auto bak_pool_index = 1 - _pool_index.load(std::memory_order_acquire);
            auto channel_pool = _channel_pool_vec[bak_pool_index];
            bool rpc_suc = true;
            bool init_channel_pool_suc = true;
            try {
                if(_is_akv){
                    init_channel_pool_suc = init_akv_channel_pool(channel_pool);
                } else {
                    init_channel_pool_suc = init_channel_pool(channel_pool);
                }
                
            } catch (const std::exception & e) {
                HILOG_APP(WARNING) << "exception: " << e.what();
                rpc_suc = false;
            }
            if (!rpc_suc) return;
            if (!init_channel_pool_suc) continue;
            if (is_channel_pool_changed()) {
                _pool_index.store(bak_pool_index, std::memory_order_release);
                auto cur_index = _pool_index.load(std::memory_order_acquire);
                HILOG_APP(WARNING) << "switch channel_pool cur_idex: " << cur_index;
                // channel_pool_vec[cur_index] = std::make_shared<ChannelPool>();
            } else {
                HILOG_APP(WARNING) << "channel pool not changed";
            }
        } catch (const std::exception & e) {
            HILOG_APP(WARNING) << "exception : " << e.what();
        }
    }
}

bool RedisClient::is_channel_pool_changed() {
    auto channel_pool0 = _channel_pool_vec[0];
    auto channel_pool1 = _channel_pool_vec[1];
    if (channel_pool0->_valid_lines.size() != channel_pool1->_valid_lines.size()) {
        HILOG_APP(WARNING) << "valid_lines size changed;  valid_lines 0 size: " << channel_pool0->_valid_lines.size();
        HILOG_APP(WARNING) << "valid_lines size changed;  valid_lines 1 size: " << channel_pool1->_valid_lines.size();
        return true;
    }
    return false;
}

bool RedisClient::init_channel_pool(std::shared_ptr<ChannelPool> channel_pool) {

    brpc::ChannelOptions options;
    options.max_retry = _max_retry; // 0 means no retry
    options.timeout_ms = _time_out * 10;
    options.protocol = brpc::PROTOCOL_REDIS;
    brpc::Channel redis_channel;
    if (redis_channel.Init(_url.c_str(), &options) != 0) {  // 6379 is the default port for redis-server
        HILOG_APP(WARNING) << "Fail to init channel to redis-server: " << _url.c_str()
                      << " pass: " << _pass.c_str();
       throw "Fail to init channel to redis-server";
    }
    HILOG_APP(WARNING) << "url: " << _url.c_str() << " start,pass:"<<_pass;
    if(!_pass.empty()){
        brpc::RedisRequest p_request;
        brpc::RedisResponse p_response;
        brpc::Controller p_cntl;
        butil::StringPiece parts[2];
        parts[0].set("AUTH");
        parts[1].set(_pass.c_str(),_pass.size());
        p_request.AddCommandByComponents(&parts[0], 2);
        redis_channel.CallMethod(NULL, &p_cntl, &p_request, &p_response, NULL/*done*/);
        if (p_cntl.Failed()) {
            std::cout << "Fail to access redis-server[AUTH], remote_ip:" << p_cntl.remote_side()
                        << " cost_us:" << p_cntl.latency_us() 
                        << " error:"<< p_cntl.ErrorText();
            HILOG_APP(WARNING) << "Fail to access redis-server[cAUTH], remote_ip:" << p_cntl.remote_side()
                        << " cost_us:" << p_cntl.latency_us() 
                        << " error:"<< p_cntl.ErrorText();
            return false;
        }
        // HILOG_APP(WARNING) << "reply_size: " << response.reply_size();
        if (p_response.reply(0).is_error()) {
            HILOG_APP(WARNING) << "auth Fail to set response:"<<p_response.reply(0).error_message();
            return false;
        } 
    }

    brpc::RedisRequest set_request;
    brpc::RedisResponse response;
    brpc::Controller cntl;
    set_request.AddCommand("cluster nodes");
    redis_channel.CallMethod(NULL, &cntl, &set_request, &response, NULL/*done*/);
    if (cntl.Failed()) {
        std::cout << "Fail to access redis-server[cluster nodes], remote_ip:" << cntl.remote_side()
                     << " cost_us:" << cntl.latency_us() 
                     << " error:"<< cntl.ErrorText();
        HILOG_APP(WARNING) << "Fail to access redis-server[cluster nodes], remote_ip:" << cntl.remote_side()
                     << " cost_us:" << cntl.latency_us() 
                     << " error:"<< cntl.ErrorText();
        return false;
    }
    // HILOG_APP(WARNING) << "reply_size: " << response.reply_size();
    if (response.reply(0).is_error()) {
        HILOG_APP(WARNING) << "cluster nodes Fail to set response:"<<response.reply(0).error_message();
        return false;
    } 
    
    std::vector<std::string> vlines;
    // do clear
    channel_pool->_valid_lines.clear();
    std::string s = std::string(response.reply(0).data().data(), response.reply(0).data().size());
    ////std::cout << "response size: " << response.reply(0).size();
    boost::split(vlines, s, boost::is_any_of("\n"), boost::token_compress_on);
    std::vector<NodeInfo> vNodes;
    for (size_t i= 0; i < vlines.size(); ++i) {
        NodeInfo node;
        node._strinfo = vlines[i];

        std::vector<std::string> nodeinfo;
        boost::split(nodeinfo, node._strinfo, boost::is_any_of(" "), boost::token_compress_on);
        if (nodeinfo.size() < 8) {
            continue;
        }
        if (NULL != strstr(nodeinfo[7].c_str(), "disconnected")){
            continue;
        }
        if (NULL == strstr(nodeinfo[2].c_str(), "master")) {
            continue;
        }
        channel_pool->_valid_lines.push_back(vlines[i]);
        node._id = nodeinfo[0];
        node.ParseNodeString(nodeinfo[1]);
        // HILOG_APP(WARNING) << "ip: " << node.ip << " port:" << node.port;
        for (size_t j = 8; j < nodeinfo.size(); j++) {
            // HILOG_APP(WARNING) << "nodeinfo 8: " << nodeinfo[j];
            node.ParseSlotString(nodeinfo[j]);
        }
        vNodes.push_back(node);
    }
    if (!is_channel_pool_changed()) {
        HILOG_APP(WARNING) << " is_channel_pool_changed not changed, return without build redis client pool";
        return true;
    }
    HILOG_APP(WARNING) << "url: " << _url.c_str() << " end";
    init_slot_node_map(channel_pool->_slot_ipport_index_vec, vNodes);

    uint32_t cnt = vNodes.size();

    if(channel_pool->m_channel_list.size() != cnt)channel_pool->m_channel_list.resize(cnt);

    for (uint32_t i = 0; i < cnt; ++i) {
        init_channel(i, vNodes[i]._ip, vNodes[i]._port, _pool_size, _time_out, "", channel_pool->m_channel_list);
    }
    return true;
}

bool RedisClient::init_akv_channel_pool(std::shared_ptr<ChannelPool> channel_pool) {
    brpc::ChannelOptions options;
    options.max_retry = _max_retry; // 0 means no retry
    options.timeout_ms = _time_out * 10;
    options.protocol = brpc::PROTOCOL_REDIS;
    // brpc::Channel redis_channel;
    const std::string list_prefix = "list://";

    std::vector<std::string> nodes;
    boost::split(nodes, _url.substr(list_prefix.length()), boost::is_any_of(","), boost::token_compress_on);

    std::vector<std::shared_ptr<brpc::Channel>> valid_channels;
    for (const auto &node: nodes) {
        auto probe_channel = std::make_shared<brpc::Channel>();
        if (probe_channel->Init(node.c_str(), &options) != 0) {
            HILOG_APP(WARNING) << "Failed to init probe channel: " << node;
            continue;
        }
        valid_channels.push_back(probe_channel);
    }

    HILOG_APP(WARNING) << "url: " << _url.c_str() << " start,pass:"<<_pass;

    HILOG_APP(INFO) << "开始鉴权";

    if(!_pass.empty()){

        HILOG_APP(INFO) << "valid_channels.size(): " << valid_channels.size();
        for (auto &channel: valid_channels) {
            brpc::RedisRequest p_request;
            brpc::RedisResponse p_response;
            brpc::Controller p_cntl;
            butil::StringPiece parts[2];
            parts[0].set("AUTH");
            parts[1].set(_pass.c_str(), _pass.size());
            p_request.AddCommandByComponents(&parts[0], 2);
            channel->CallMethod(nullptr, &p_cntl, &p_request, &p_response, nullptr);
            if (p_cntl.Failed()) {
                HILOG_APP(WARNING) << "Fail to access redis-server[cAUTH], remote_ip:" << p_cntl.remote_side()
                                   << " cost_us:" << p_cntl.latency_us() << " error:" << p_cntl.ErrorText();
                continue;
            }
            if (p_response.reply(0).is_error()) {
                HILOG_APP(WARNING) << "auth Fail to set response:" << p_response.reply(0).error_message();
                continue;
            }
        }
    }
    
    HILOG_APP(INFO) << "获取cluster信息";
    std::string cluster_info;
    bool cluster_info_obtained = false;
    for (const auto &channel: valid_channels) {
        brpc::RedisRequest set_request;
        brpc::RedisResponse response;
        brpc::Controller cntl;
        set_request.AddCommand("cluster nodes");

        channel->CallMethod(NULL, &cntl, &set_request, &response, NULL /*done*/);

        const brpc::RedisReply &cluster_reply = response.reply(0);
        if (cntl.Failed()) {
            HILOG_APP(WARNING) << "Fail to access redis-server[cluster nodes], remote_ip:" << cntl.remote_side()
                               << " cost_us:" << cntl.latency_us() << " error:" << cntl.ErrorText();
            continue;
        }
        // HILOG_APP(WARNING) << "reply_size: " << response.reply_size();
        if (cluster_reply.is_error()) {
            HILOG_APP(WARNING) << "cluster nodes Fail to set response:" << response.reply(0).error_message();
            continue;
        }

        if (cluster_reply.is_nil()) {
            HILOG_APP(WARNING) << "Cluster nodes returned nil (no nodes available)";
            continue;
        }
        if (!cluster_reply.is_string()) {
            HILOG_APP(WARNING) << "Unexpected reply type for 'cluster nodes': "
                               << static_cast<int>(cluster_reply.type());
            continue;
        }
        cluster_info.assign(cluster_reply.data().data(), cluster_reply.data().size());
        cluster_info_obtained = true;
        HILOG_APP(INFO)<<"Successfully obtained cluster info via channel";
        break;
    }

    if (!cluster_info_obtained) {
        HILOG_APP(ERROR) << "All channels failed to get cluster nodes info";
        return false;
    }

    std::vector<std::string> vlines;
    // do clear
    channel_pool->_valid_lines.clear();

    boost::split(vlines, cluster_info, boost::is_any_of("\n"), boost::token_compress_on);

    std::vector<NodeInfo> vNodes;
    for (size_t i= 0; i < vlines.size(); ++i) {
        NodeInfo node;
        node._strinfo = vlines[i];

        std::vector<std::string> nodeinfo;
        boost::split(nodeinfo, node._strinfo, boost::is_any_of(" "), boost::token_compress_on);
        if (nodeinfo.size() < 8) {
            continue;
        }
        if (NULL != strstr(nodeinfo[7].c_str(), "disconnected")){
            continue;
        }
        if (NULL == strstr(nodeinfo[2].c_str(), "master")) {
            continue;
        }
        channel_pool->_valid_lines.push_back(vlines[i]);
        node._id = nodeinfo[0];
        node.ParseNodeString(nodeinfo[1]);
        // HILOG_APP(WARNING) << "ip: " << node.ip << " port:" << node.port;
        for (size_t j = 8; j < nodeinfo.size(); j++) {
            // HILOG_APP(WARNING) << "nodeinfo 8: " << nodeinfo[j];
            node.ParseSlotString(nodeinfo[j]);
        }
        vNodes.push_back(node);
    }
    if (!is_channel_pool_changed()) {
        HILOG_APP(WARNING) << " is_channel_pool_changed not changed, return without build redis client pool";
        return true;
    }
    HILOG_APP(WARNING) << "url: " << _url.c_str() << " end";
    init_slot_node_map(channel_pool->_slot_ipport_index_vec, vNodes);

    uint32_t cnt = vNodes.size();

    if(channel_pool->m_akv_channel_list.size() != cnt)channel_pool->m_akv_channel_list.resize(cnt);
    
    for (uint32_t i = 0; i < cnt; ++i) {
        int ret = init_channel(i, vNodes[i]._ip, vNodes[i]._port, _pool_size, _time_out, "", channel_pool->m_akv_channel_list);
    }
    HILOG_APP(INFO)<< "使用list初始化没有问题 init_channel";
    return true;
}

bool RedisClient::init_channel(int32_t idx, const std::string &host, 
                        uint32_t port, uint32_t poolsize, int64_t time_out, const std::string& load_balancer,
                        std::vector<std::shared_ptr<ConnectPool<brpc::Channel>>>& m_channel_list) {
    if (host.empty()) {
        HILOG_APP(WARNING) << "Error Host" << host;
        return false;
    }

    std::string ip_port = host + ":" + std::to_string(port);

    brpc::ChannelOptions options;
    options.protocol = brpc::PROTOCOL_REDIS;
    options.connection_type = "";
    options.timeout_ms = time_out;
    options.max_retry = 1;
    options.backup_request_ms = -1;
    auto build_connection = [](std::string ip_port, std::string load_balancer, brpc::ChannelOptions options){
        auto channel = std::make_shared<brpc::Channel>();
        if (channel->Init(ip_port.c_str(), load_balancer.c_str(), &options) != 0) {
            HILOG_APP(WARNING) << "Fail to initialize channel";
            return std::shared_ptr<brpc::Channel>();
        }
        return channel;
    };
    // HILOG_APP(WARNING) << "poolsize: " << poolsize;
    auto conn_pool_ptr = new ConnectPool<brpc::Channel>(poolsize, 100, std::bind(build_connection, ip_port, load_balancer, options));
    std::shared_ptr<ConnectPool<brpc::Channel>> conn_pool;
    conn_pool.reset(conn_pool_ptr);
    m_channel_list[idx] = conn_pool;
    return true;
}

bool RedisClient::init_channel(int32_t idx, const std::string &host, 
                        uint32_t port, uint32_t poolsize, int64_t time_out, const std::string& load_balancer,
                        std::vector<std::shared_ptr<brpc::Channel>>& m_channel_list) {
    if (host.empty()) {
        HILOG_APP(WARNING) << "Error Host" << host;
        return false;
    }

    std::string ip_port = host + ":" + std::to_string(port);

    brpc::ChannelOptions options;
    options.protocol = brpc::PROTOCOL_REDIS;
    options.connection_type = "";
    options.timeout_ms = time_out;
    options.max_retry = 1;
    options.backup_request_ms = -1;
    
    auto channel = std::make_shared<brpc::Channel>();
    if (channel->Init(ip_port.c_str(), load_balancer.c_str(), &options) != 0) {
        HILOG_APP(WARNING) << "Fail to initialize channel" << ip_port.c_str();
        m_channel_list[idx] = std::shared_ptr<brpc::Channel>();
        return false;
    }

    brpc::RedisRequest p_request;
    brpc::RedisResponse p_response;
    brpc::Controller p_cntl;
    butil::StringPiece parts[2];
    parts[0].set("AUTH");
    parts[1].set(_pass.c_str(), _pass.size());
    p_request.AddCommandByComponents(&parts[0], 2);
    channel->CallMethod(nullptr, &p_cntl, &p_request, &p_response, nullptr);
    if (p_cntl.Failed()) {
        HILOG_APP(WARNING) << "Fail to access redis-server[cAUTH], remote_ip:" << p_cntl.remote_side()
                           << " cost_us:" << p_cntl.latency_us() << " error:" << p_cntl.ErrorText();
        m_channel_list[idx] = std::shared_ptr<brpc::Channel>();
        return false;
    }
    if (p_response.reply(0).is_error()) {
        HILOG_APP(WARNING) << "auth Fail to set response:" << p_response.reply(0).error_message();
        m_channel_list[idx] = std::shared_ptr<brpc::Channel>();
        return false;
    }

    m_channel_list[idx] = channel;

    return true;
}

void RedisClient::init_slot_node_map(std::vector<int>& slot_ipport_index_vec, const std::vector<NodeInfo>& nodes) {
    slot_ipport_index_vec.resize(16384, -1); // redis slot数为16384, 预分配好，-1 代表slot不存在
    for (size_t i = 0; i < nodes.size(); ++i) {
        const NodeInfo& node = nodes.at(i);
        for (auto iter = node._mSlots.begin(); 
                iter != node._mSlots.end(); ++iter) {
            uint32_t start_slot = iter->first;
            uint32_t end_slot = iter->second;
            for (uint32_t start = start_slot; start <= end_slot; ++start) {
                if (start < slot_ipport_index_vec.size()) {
                    slot_ipport_index_vec[start] = i;
                } else {
                    HILOG_APP(WARNING) << "start is greater than 16384, start:" << start;
                    slot_ipport_index_vec.resize(start + 1, -1);
                    slot_ipport_index_vec[start] = i;
                }
            }
        }
    }
}

int RedisClient::set(const std::string& key,
                    const char* value,
                    size_t value_size,
                    std::function<void(std::shared_ptr<brpc::RedisResponse>,
                    std::shared_ptr<brpc::Controller> cntl_ptr)> call_back,
                    int64_t timeout_ms, int max_retry,
                    int expire_time) {
    brpc::RedisRequest set_request;
    auto response = std::make_shared<brpc::RedisResponse>();
    std::shared_ptr<brpc::Controller> cntl_ptr = std::make_shared<brpc::Controller>();
    if (timeout_ms > 0) {
        cntl_ptr->set_timeout_ms(timeout_ms);
    }
    if (max_retry > 0) {
        cntl_ptr->set_max_retry(max_retry);
    }
    if (expire_time > 0) {
        std::string expire_str = std::to_string(expire_time);
        butil::StringPiece parts[4];
        parts[0].set("SETEX");
        parts[1].set(key.c_str(), key.size());
        parts[2].set(expire_str.c_str(), expire_str.size());
        parts[3].set(value, value_size);
        set_request.AddCommandByComponents(&parts[0], 4);
    } else {
        butil::StringPiece parts[3];
        parts[0].set("SET");
        parts[1].set(key.c_str(), key.size());
        parts[2].set(value, value_size);
        set_request.AddCommandByComponents(&parts[0], 3);
    }
    auto pool_index_t = _pool_index.load(std::memory_order_acquire);
    auto channel_pool_ptr = _channel_pool_vec[pool_index_t];
    uint32_t index = channel_pool_ptr->get_key_node_index(key.c_str(), key.size());
    auto redis_call_back = brpc::NewCallback(this, &RedisClient::set_response_handler, cntl_ptr, response, call_back);
    
    std::shared_ptr<brpc::Channel> channel;
    if(_is_akv){
        channel = channel_pool_ptr->get_akv_connection(index);
    }else{
        channel = channel_pool_ptr->get_connection(index);
    }
    if (!channel) {
        HILOG_APP(WARNING) << "get redis channel is nullpr";
        return -1;
    }

   // HILOG_APP(WARNING) << "channel empty :" << (channel == nullptr);
    channel->CallMethod(NULL, cntl_ptr.get(), &set_request, response.get(), redis_call_back);
	channel_pool_ptr->free_connection(channel, index);
    return 0;
}
int RedisClient::get_simple(const std::string& key,
        std::function<void(std::shared_ptr<brpc::RedisResponse>, std::shared_ptr<brpc::Controller> cntl_ptr)> call_back,
        int64_t timeout_ms, int max_retry) {
    std::shared_ptr<brpc::RedisRequest> request = std::make_shared<brpc::RedisRequest>();
    auto response_ptr = std::make_shared<brpc::RedisResponse>();
    auto cntl_ptr = std::make_shared<brpc::Controller>();
    if (timeout_ms > 0) {
        cntl_ptr->set_timeout_ms(timeout_ms);
    } else {
        cntl_ptr->set_timeout_ms(_time_out);
    }
    if (max_retry > 0) {
        cntl_ptr->set_max_retry(max_retry);
    }
    butil::StringPiece parts[2];
    parts[0].set("GET");
    parts[1].set(key.c_str(), key.size());

    request->AddCommandByComponents(&parts[0], 2);
    auto pool_index_t = _pool_index.load(std::memory_order_acquire);
    auto channel_pool_ptr = _channel_pool_vec[pool_index_t];

    uint32_t index = channel_pool_ptr->get_key_node_index(key.c_str(), key.size());

    std::shared_ptr<brpc::Channel> channel;
    if(_is_akv){
        HILOG_APP(INFO) << "use akv: " << _url << ",key: " << key; 
        channel = channel_pool_ptr->get_akv_connection(index);
    }else{
        HILOG_APP(INFO) << "use redis: " << _url << ",key: " << key; 
        channel = channel_pool_ptr->get_connection(index);
    }
    
    if (channel) {
        auto redis_call_back = brpc::NewCallback(this, &RedisClient::set_response_handler,cntl_ptr, response_ptr, call_back);
        channel->CallMethod(nullptr, cntl_ptr.get(), request.get(), response_ptr.get(), redis_call_back);
	    channel_pool_ptr->free_connection(channel, index);
        return 0;
    } else {
        HILOG_APP(WARNING) << "get redis channel is nullpr";
    }
    return -1;
}

int RedisClient::get_simple(const std::string& key,std::shared_ptr<brpc::Controller> cntl_ptr,
        std::shared_ptr<brpc::RedisResponse>&response_ptr,
            int64_t timeout_ms , int max_retry ){
    std::shared_ptr<brpc::RedisRequest> request = std::make_shared<brpc::RedisRequest>();
    if (timeout_ms > 0) {
        cntl_ptr->set_timeout_ms(timeout_ms);
    } else {
        cntl_ptr->set_timeout_ms(_time_out);
    }
    if (max_retry > 0) {
        cntl_ptr->set_max_retry(max_retry);
    }
    butil::StringPiece parts[2];
    parts[0].set("GET");
    parts[1].set(key.c_str(), key.size());

    request->AddCommandByComponents(&parts[0], 2);
    auto pool_index_t = _pool_index.load(std::memory_order_acquire);
    auto channel_pool_ptr = _channel_pool_vec[pool_index_t];
    uint32_t index = channel_pool_ptr->get_key_node_index(key.c_str(), key.size());
    std::shared_ptr<brpc::Channel> channel;
    if(_is_akv){
        HILOG_APP(INFO) << "use akv: " << _url << ",key: " << key; 
        channel = channel_pool_ptr->get_akv_connection(index);
    }else{
        HILOG_APP(INFO) << "use redis: " << _url << ",key: " << key; 
        channel = channel_pool_ptr->get_connection(index);
    }

    if (channel) {
        channel->CallMethod(nullptr, cntl_ptr.get(), request.get(), response_ptr.get(), nullptr);
	    channel_pool_ptr->free_connection(channel, index);
        return 0;
    } else {
        HILOG_APP(WARNING) << "get redis channel is nullpr";
    }
    return -1;
}


int RedisClient::hget_simple(const std::string& key, const std::string& field,
        std::function<void(std::shared_ptr<brpc::RedisResponse>, std::shared_ptr<brpc::Controller> cntl_ptr)> call_back,
        int64_t timeout_ms, int max_retry) {
    std::shared_ptr<brpc::RedisRequest> request = std::make_shared<brpc::RedisRequest>();
    auto response_ptr = std::make_shared<brpc::RedisResponse>();
    auto cntl_ptr = std::make_shared<brpc::Controller>();
    if (timeout_ms > 0) {
        cntl_ptr->set_timeout_ms(timeout_ms);
    } else {
        cntl_ptr->set_timeout_ms(_time_out);
    }
    if (max_retry > 0) {
        cntl_ptr->set_max_retry(max_retry);
    }
    butil::StringPiece parts[3];
    parts[0].set("HGET");
    parts[1].set(key.c_str(), key.size());
    parts[2].set(field.c_str(), field.size());

    request->AddCommandByComponents(&parts[0], 3);
    auto pool_index_t = _pool_index.load(std::memory_order_acquire);
    auto& channel_pool_ptr = _channel_pool_vec[pool_index_t];
    uint32_t index = channel_pool_ptr->get_key_node_index(key.c_str(), key.size());
    std::shared_ptr<brpc::Channel> channel;
    if(_is_akv){
        HILOG_APP(INFO) << "use akv: " << _url << ",key: " << key; 
        channel = channel_pool_ptr->get_akv_connection(index);
    }else{
        HILOG_APP(INFO) << "use redis: " << _url << ",key: " << key; 
        channel = channel_pool_ptr->get_connection(index);
    }
    
    if (channel) {
        auto redis_call_back = brpc::NewCallback(this, &RedisClient::set_response_handler,cntl_ptr, response_ptr, call_back);
        channel->CallMethod(nullptr, cntl_ptr.get(), request.get(), response_ptr.get(), redis_call_back);
        channel_pool_ptr->free_connection(channel, index);
        return 0;
    } else {
        HILOG_APP(ERROR) << "get redis channel is nullpr";
    }
    return -1;
}

int RedisClient::mget_simple(const std::vector<std::string>& keys,
    std::function<void(std::shared_ptr<brpc::RedisResponse>, std::shared_ptr<brpc::Controller> cntl_ptr)> call_back,
    int64_t timeout_ms, int max_retry) {
    std::shared_ptr<brpc::RedisRequest> request = std::make_shared<brpc::RedisRequest>();
    auto response_ptr = std::make_shared<brpc::RedisResponse>();
    auto cntl_ptr = std::make_shared<brpc::Controller>();
    if (timeout_ms > 0) {
        cntl_ptr->set_timeout_ms(timeout_ms);
    } else {
        cntl_ptr->set_timeout_ms(_time_out);
    }
    if (max_retry > 0) {
        cntl_ptr->set_max_retry(max_retry);
    }

    // 设置命令为 MGET
    butil::StringPiece parts[keys.size() + 1];
    parts[0].set("MGET");
    for (size_t i = 0; i < keys.size(); ++i) {
        parts[i + 1].set(keys[i].c_str(), keys[i].size());
    }

    request->AddCommandByComponents(&parts[0], keys.size() + 1);
    auto pool_index_t = _pool_index.load(std::memory_order_acquire);
    auto& channel_pool_ptr = _channel_pool_vec[pool_index_t];
    uint32_t index = channel_pool_ptr->get_key_node_index(keys[0].c_str(), keys[0].size());
    std::shared_ptr<brpc::Channel> channel;
    if(_is_akv){
        // HILOG_APP(INFO) << "use akv: " << _url << ",keys: " << keys; 
        channel = channel_pool_ptr->get_akv_connection(index);
    }else{
        // HILOG_APP(INFO) << "use redis: " << _url << ",keys: " << keys; 
        channel = channel_pool_ptr->get_connection(index);
    }
    
    if (channel) {
        auto redis_call_back = brpc::NewCallback(this, &RedisClient::set_response_handler,cntl_ptr, response_ptr, call_back);
        channel->CallMethod(nullptr, cntl_ptr.get(), request.get(), response_ptr.get(), redis_call_back);
        channel_pool_ptr->free_connection(channel, index);
        return 0;
    } else {
        HILOG_APP(ERROR) << "get redis channel is null";
    }
    return -1;
}

int RedisClient::hmget_multiple_fields(const std::string& key, const std::vector<std::string>& fields,
        std::function<void(std::shared_ptr<brpc::RedisResponse>, std::shared_ptr<brpc::Controller> cntl_ptr)> call_back,
        int64_t timeout_ms, int max_retry) {
    std::shared_ptr<brpc::RedisRequest> request = std::make_shared<brpc::RedisRequest>();
    auto response_ptr = std::make_shared<brpc::RedisResponse>();
    auto cntl_ptr = std::make_shared<brpc::Controller>();
    if (timeout_ms > 0) {
        cntl_ptr->set_timeout_ms(timeout_ms);
    } else {
        cntl_ptr->set_timeout_ms(_time_out);
    }
    if (max_retry > 0) {
        cntl_ptr->set_max_retry(max_retry);
    }
    
    // 设置命令为 HMGET
    butil::StringPiece parts[fields.size() + 1];
    parts[0].set("HMGET");
    parts[1].set(key.c_str(), key.size());
    for (size_t i = 0; i < fields.size(); ++i) {
        parts[i + 2].set(fields[i].c_str(), fields[i].size());
    }

    request->AddCommandByComponents(&parts[0], fields.size() + 2);
    auto pool_index_t = _pool_index.load(std::memory_order_acquire);
    auto& channel_pool_ptr = _channel_pool_vec[pool_index_t];
    uint32_t index = channel_pool_ptr->get_key_node_index(key.c_str(), key.size());
    std::shared_ptr<brpc::Channel> channel;
    if(_is_akv){
        HILOG_APP(INFO) << "use akv: " << _url << ",key: " << key; 
        channel = channel_pool_ptr->get_akv_connection(index);
    }else{
        HILOG_APP(INFO) << "use redis: " << _url << ",key: " << key; 
        channel = channel_pool_ptr->get_connection(index);
    }    
    if (channel && call_back) {
        // HILOG_APP(ERROR) << "callback address: " << &call_back;
        auto redis_call_back = brpc::NewCallback(this, &RedisClient::set_response_handler,cntl_ptr, response_ptr, call_back);  
        channel->CallMethod(nullptr, cntl_ptr.get(), request.get(), response_ptr.get(), redis_call_back);
        channel_pool_ptr->free_connection(channel, index);
        return 0;
    } else {
        HILOG_APP(ERROR) << "get redis channel is null";
    }
    return -1;
}


void RedisClient::set_response_handler(std::shared_ptr<brpc::Controller> cntl_ptr,
  std::shared_ptr<brpc::RedisResponse> response_ptr, std::function<void(std::shared_ptr<brpc::RedisResponse>, std::shared_ptr<brpc::Controller> cntl_ptr)> call_back) {
    // auto latency = -a start;
    // HILOG_APP(ERROR) << "enter handler";
    if (cntl_ptr->Failed()) {
        HILOG_APP(ERROR) << "cntl failed, remote_ip:" << cntl_ptr->remote_side()
                     << " cost_us:" << cntl_ptr->latency_us() 
                     << " error:"<< cntl_ptr->ErrorText() ;
        response_ptr.reset();
    }

    call_back(response_ptr, cntl_ptr);
}

inline bool NodeInfo::ParseNodeString(const std::string& nodeString) {
    std::string::size_type ColonPos = nodeString.find(':');
    if (ColonPos == std::string::npos) {
        return false;
    } else {
        const std::string port_str = nodeString.substr(ColonPos + 1);
        _port = atoi(port_str.c_str());
        _ip = nodeString.substr(0, ColonPos);
        return true;
    }
}

inline void NodeInfo::ParseSlotString(const std::string& SlotString) {
    uint32_t StartSlot = 0;
    uint32_t EndSlot = 0;
    std::string::size_type BarPos = SlotString.find('-');
    if (BarPos == std::string::npos) {
        StartSlot = atoi(SlotString.c_str());
        EndSlot = StartSlot;
    } else {
        const std::string EndSlotStr = SlotString.substr(BarPos + 1);
        EndSlot = atoi(EndSlotStr.c_str());
        StartSlot = atoi(SlotString.substr(0, BarPos).c_str());
    }
    if (StartSlot > 16384 || EndSlot > 16384) {
        HILOG_APP(WARNING) << "error, wrong SlotString:" << SlotString.c_str();
    }
    _mSlots.push_back(std::make_pair(StartSlot, EndSlot));
}

} // end of namesapce client
