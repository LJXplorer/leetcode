#include "redis_client_manager.h"
#include "common/comm/config_xml.h"
#include <string>

namespace Core {
using namespace hilog;
bool RedisClientManager::init(const std::string& path) {
    ConfigXml xml_conf;
    xml_conf.init(path);

    ConfigXml main;
    if (!xml_conf.find("main", main)) {
        HILOG_APP(WARNING) << "main not found in file: " << path;
        return false;
    }

    ConfigXml client_conf;
    if (!main.child("client", client_conf)) {
        HILOG_APP(WARNING) << "client not found in " << path;
        return false;
    }

    bool has_next = false;
    do {
        std::string id;
        client_conf.attr<std::string>("id", id);
        std::string url;
        client_conf.attr<std::string>("url", url);
        std::string pass;
        client_conf.attr<std::string>("pass", pass);
        uint32_t pool_size;
        client_conf.attr<uint32_t>("pool_size", pool_size);
        int timeout = 10;
        client_conf.attr<int>("timeout", timeout);
        int update_interval = 60;
        client_conf.attr<int>("update_interval", update_interval);

        std::string is_akv_str;
        client_conf.attr<string>("is_akv", is_akv_str);
        bool is_akv = (is_akv_str == "true");

        HILOG_APP(INFO) << "init redis id: " << id << " url: " << url << std::endl;
        HILOG_APP(WARNING) << "init redis id: " << id << " url: " << url << " update_interval: " << update_interval<<",pass:"<<pass;
        std::shared_ptr<RedisClient> client_ptr = std::make_shared<RedisClient>(url, pass, timeout, update_interval, pool_size,is_akv, 0);
        
        if (!client_ptr->init()) {
            return false;
        }


        _client_map.insert({id, client_ptr});
        has_next = client_conf.next("client", client_conf);
    } while(has_next);

    HILOG_APP(WARNING) << "_client_map size: " << _client_map.size();
    HILOG_APP(INFO) << "_client_map size: " << _client_map.size() << std::endl;

    return true;
}

std::shared_ptr<RedisClient> RedisClientManager::get_client(const std::string& id) {

    auto it = _client_map.find(id);
    if(it != _client_map.end()) {
        return it->second;
    }
    // todo print error message
    HILOG_APP(WARNING) << "can't find client: " << id << endl;
    return nullptr;
}
} // end of namespace
