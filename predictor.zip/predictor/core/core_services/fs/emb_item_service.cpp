#include "core/core_services/fs/emb_item_service.h"
#include "core/core_services/predict/utils/model_version.h"
#include "common/hilog/log_helper.h"
#include "ranking/predict_service.pb.h"
#include <boost/algorithm/string.hpp>
#include <cctype>
#include <cmath>
#include <locale>
#include <memory>
#include <string>
#include <string_view>
namespace Core {
SERVICE_REGISTER(EmbItemFsService);
void EmbItemFsService::initialize(ConfigXmlPtr xml) {
  std::string fs_type;
  xml->attr<std::string>("type", fs_type);
  if (fs_type == "user") {
    _fs_type = FEA_TYPE_USER;
  } else if (fs_type == "item") {
    _fs_type = FEA_TYPE_ITEM;
  }
  xml->attr<std::string>("fetch_path", _fetch_path);
  xml->attr<std::string>("redis_path", _redis_path);
  xml->attr<int>("batch_size", _batch_size);
  std::string is_truncation;
  xml->attr<std::string>("is_truncation", is_truncation, "false");
  if (is_truncation == "true") {
    _is_truncation = true;
  } else {
    _is_truncation = false;
  }
  
  initialize_xml(xml);
}

void EmbItemFsService::initialize_xml(ConfigXmlPtr xml) {}

void EmbItemFsService::initialize(GraphContextPtr context) {
  auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
  ctx->get_monitor_context()->alloc_node(get_name());
}

int EmbItemFsService::do_service(GraphContextPtr context) {
  auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
  HILOG_APP(INFO) << LOG_HEAD(ctx) << get_name()
                  << " do_service _fetch_path:" << _fetch_path
                  << " _redis_path:" << _redis_path;
  int32_t ret = 0;
  
  try {
   
    ret = process(ctx);
  } catch (const std::exception &e) {
    HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name()
                     << "do service fail: " << ret << "," << e.what();
  }
 
  return ret;
}

int EmbItemFsService::process(CoreContextPtr context) {
    int item_size = context->get_rank_request()->predictorslotinfo().predictoriteminfos_size();
    int slice_cnt = (item_size + _batch_size) / _batch_size;
    
    std::vector<BatchFetchArgs> batch_args(slice_cnt);
    BizLatency* lat = get_node_stat(context)->get_lat();
    {
      BizLatencyGaurd lat_guard_create(lat,LAT_STAGE_CREATE);
      for(int s = 0; s <slice_cnt;s++){
        batch_args[s].start = s*_batch_size;
        batch_args[s].end = std::min(s*_batch_size + _batch_size,item_size);
        batch_args[s].context = context;
        batch_args[s].start_fetch_status = bthread_start_background(&batch_args[s].tid, &BTHREAD_ATTR_NORMAL,
                                        &EmbItemFsService::get_item_feature,
                                        static_cast<void *>(&batch_args[s]));
      }
    }
    {
      BizLatencyGaurd lat_guard_dst(lat,LAT_STAGE_DESTROY);
      for (auto& arg : batch_args) {
          bthread_join(arg.tid, NULL);
      }    
      //dsp上下文
      if (context->get_fs_context()->_zero_creativeid_items.size() != 0) {
        get_dsp_item_feature(context);
      }         
    }  
  HILOG_APP(INFO) << "EmbItemFsService end!" <<std::endl;
  return ERROR_SUCCESS;
}

void* EmbItemFsService::get_dsp_item_feature(CoreContextPtr context) {
  FSContextPtr fs_context = context->get_fs_context();
  const auto& zero_creativeid_items = fs_context->_zero_creativeid_items;
  for(auto& item : zero_creativeid_items) {
    auto *item_feature = context->get_fs_context()->alloc_zero_creativeid_item_fea();
    if(item_feature == nullptr) {
      continue;
    }
    if (item_feature) {
      item_feature->mutable_item_info()->set_creative_id(item->creativeid());
      item_feature->mutable_item_info()->set_conv_type(item->convtype());
      item_feature->mutable_item_info()->set_billing_mode(item->billingmode());
      item_feature->mutable_item_info()->set_conv_goal(item->convgoal());
      item_feature->mutable_item_info()->set_enhanced_conv_type(item->enhanceconvtype());
      item_feature->mutable_item_info()->set_deep_conv_type(item->deepconvtype());
      item_feature->mutable_item_info()->mutable_rta_id()->assign(item->rtaid());
      item_feature->mutable_item_info()->set_rta_url_id(item->rtaurlid());
      item_feature->mutable_item_info()->set_bid(item->bid());
      item_feature->mutable_item_info()->set_ocpx_sbp(item->ocpxsbp());
      item_feature->mutable_item_info()->set_data_source(item->datasource());
      item_feature->mutable_item_info()->set_advertiser_id(item->advertiserid());
      item_feature->mutable_item_info()->set_recall_type(item->recalltype());
      if (item->admask() & (1ULL << 2)) {
        item_feature->mutable_item_info()->set_is_derivative(1);     
      }
      else {
        item_feature->mutable_item_info()->set_is_derivative(0);
      }
      item_feature->mutable_item_info()->set_appid(item->appid());
      double final_ecpm = std::floor(item->finalecpm());
      if(final_ecpm < 0) {
        final_ecpm = 0.0;
      }
      item_feature->mutable_item_info()->set_final_ecpm(static_cast<int64_t>(final_ecpm));
    }
    
  }
  return nullptr;
}

void* EmbItemFsService::get_item_feature(void* arg) {
  BatchFetchArgs *args = static_cast<BatchFetchArgs *>(arg);

  FSContextPtr fs_context = args->context->get_fs_context();
  const auto &items = args->context->get_rank_request()->predictorslotinfo().predictoriteminfos();
  HILOG_APP(WARNING)<<"get_item_feature:"<<args->tid<<",["<<args->start<<","<<args->end<<"] item size:"
      <<items.size()<<","<<fs_context->_item_fea.size();

  for (int b = args->start;b < args->end;b++) {
    // step1:分配item_feature、sq、item_context
    const phx::PredictorItemInfo* item = nullptr;
    item = &items[b];
    if (item == nullptr) {
      HILOG_APP(ERROR) << LOG_HEAD(args->context) << " get item ptr failed, idx:" << b;
      args->context->set_ex_req(true);
      continue;
    }
    auto *item_feature = args->context->get_fs_context()->alloc_item_fea(item->creativeid(),false);
    auto *app_feature = args->context->get_fs_context()->alloc_app_fea(item->appid(),false);

    if(item_feature == nullptr && app_feature == nullptr){
      continue;
    }

    //上下文特征
    if (app_feature) {
      app_feature->mutable_ad_info()->set_app_id(item->appid());
    }
    
    if (item_feature) {
      item_feature->mutable_item_info()->set_creative_id(item->creativeid());
      item_feature->mutable_item_info()->set_conv_type(item->convtype());
      item_feature->mutable_item_info()->set_billing_mode(item->billingmode());
      item_feature->mutable_item_info()->set_conv_goal(item->convgoal());
      item_feature->mutable_item_info()->set_enhanced_conv_type(item->enhanceconvtype());
      item_feature->mutable_item_info()->set_deep_conv_type(item->deepconvtype());
      item_feature->mutable_item_info()->mutable_rta_id()->assign(item->rtaid());
      item_feature->mutable_item_info()->set_rta_url_id(item->rtaurlid());
      item_feature->mutable_item_info()->set_bid(item->bid());
      item_feature->mutable_item_info()->set_ocpx_sbp(item->ocpxsbp());
      item_feature->mutable_item_info()->set_data_source(1);
      item_feature->mutable_item_info()->set_recall_type(item->recalltype());
      if (item->admask() & (1ULL << 2)) {
        item_feature->mutable_item_info()->set_is_derivative(1);     
      }
      else {
        item_feature->mutable_item_info()->set_is_derivative(0);
      }
      item_feature->mutable_item_info()->set_appid(item->appid());
      double final_ecpm = std::floor(item->finalecpm());
      if(final_ecpm < 0) {
        final_ecpm = 0.0;
      }
      item_feature->mutable_item_info()->set_final_ecpm(static_cast<int64_t>(final_ecpm));
      
      //端到端校验模型信息
      if (args->context->_task_type != PredictTaskType::kFeatureDump && !args->context->get_rank_request()->algoexperiments().empty()) {
        BillingMode billing_mode = args->context->to_billing_mode(item->billingmode());
        std::vector<int32_t> conv_types;
        if (item->convtype() > 0) {
            conv_types.push_back(item->convtype());
        }
        if (item->deepconvtype() > 0) {
            conv_types.push_back(item->deepconvtype());
        }
        if (item->enhanceconvtype() > 0) {
            conv_types.push_back(item->enhanceconvtype());
        }
        bool is_cpc = billing_mode <= 4;
        auto &model_map = is_cpc ? args->context->_cpc_cvr_model_map : args->context->_cpd_cvr_model_map;
        auto &ctr_model_map = is_cpc ? args->context->_cpc_ctr_model_map : args->context->_cpd_ctr_model_map;
        std::unordered_set<std::string> model_names_set;
        //cvr
        for (int conv_type: conv_types) {
            if (auto it = model_map.find(conv_type); it != model_map.end()) {
              ExperimentModelInfo *model = it->second;
              const std::string &name = model->_model_name;
              if (model_names_set.insert(name).second) {
                ::phx::ItemModelInfo* cvr = item_feature->mutable_item_info()->mutable_cvr()->Add();
                cvr->set_model_id(model->_model_info->_model_id);
                int32_t model_vesion =
                    ModelVersion::instance().get_model_version(model->_model_info->get_name());
                cvr->set_model_version(model_vesion);
              }
                
            }
        }
        //ctr
        if (auto it = ctr_model_map.find(0); it != ctr_model_map.end()) {
            ExperimentModelInfo *model = it->second;
            ::phx::ItemModelInfo* ctr = item_feature->mutable_item_info()->mutable_ctr()->Add();
            ctr->set_model_id(model->_model_info->_model_id);
            int32_t model_vesion =
                    ModelVersion::instance().get_model_version(model->_model_info->get_name());
            ctr->set_model_version(model_vesion);
        }
        //prerank
        if (args->context->get_prerank_context()->GetUsePrerank()) {
          //item
          ::phx::ItemModelInfo* item_prerank = item_feature->mutable_item_info()->mutable_prerank()->Add();
          auto item_model_info = Info::ModelInfoManager::instance().get_model_info(args->context->get_prerank_context()->item_emb_model_name_);
          if (item_model_info) {
            item_prerank->set_model_id(item_model_info->_model_id);
            item_prerank->set_model_version(args->context->get_prerank_context()->max_common_version_);
          }
          else {
            HILOG_APP(ERROR) << LOG_HEAD(args->context) << "Model info not found for name: "
                   << args->context->get_prerank_context()->item_emb_model_name_;
          }
          
          //user
          ::phx::ItemModelInfo* user_prerank = item_feature->mutable_item_info()->mutable_prerank()->Add();
          auto user_model_info = Info::ModelInfoManager::instance().get_model_info(args->context->get_prerank_context()->user_emb_model_name_);
          if (user_model_info) {
            user_prerank->set_model_id(user_model_info->_model_id);
            user_prerank->set_model_version(args->context->get_prerank_context()->max_common_version_);
          }
          else {
            HILOG_APP(ERROR) << LOG_HEAD(args->context) << "Model info not found for name: "
                   << args->context->get_prerank_context()->user_emb_model_name_;
          }          
        }
      }     
      
    }    
    
  }
  return nullptr;
}
} // namespace Core
