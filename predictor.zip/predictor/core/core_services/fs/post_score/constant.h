#pragma once
#include <string>
namespace Core {
    namespace postscore{
       inline const std::string kCtrKeySpace = "recommend_aids_base_score";
       inline const std::string kCvrKeySpace = "ad:cvr:";
       inline const std::string kDeepCvrKeyspace = "ad:deepcvr:";
    }

}