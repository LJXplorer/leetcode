#pragma once

#include "core/core_context/core_context.h"
#include "core/core_context/fs_context.h"
#include "core/core_services/base_service/service_info.h"
#include <brpc/redis.h>
#include <memory>
#include <cstdint>
namespace Core {

class FeatureSnapshotService : public ServiceBaseInfo {
private:
    int32_t _snapshot_timeout_ms;
    int32_t _snapshot_max_retry;
    std::string _snapshot_redis_id;
    std::string _add_algosceneid;
    std::unordered_set<int64_t> _no_snapshot_slots;

public:
    FeatureSnapshotService() = default;
    ~FeatureSnapshotService() = default;

    virtual void initialize(ConfigXmlPtr xml) override;
    virtual void initialize_xml(ConfigXmlPtr xml);
    virtual void initialize(GraphContextPtr context) override;
    virtual bool skip(GraphContextPtr context) override;
    virtual int do_service(GraphContextPtr context) override;
    virtual int process(CoreContextPtr context) override;

    virtual const Node_Type type() override{
            return NODE_TYPE_IO ;
    }
    static bool zstd_decompress(
        std::string& uncompressed, 
        const void *src, 
        size_t srcSize
    );
private:
    void make_redis_key(CoreContextPtr context, std::string& key);
protected:
    void prase_snapshot_feature(
        const std::string& key,
        std::shared_ptr<brpc::RedisResponse> response,
        const std::string& value,
        FSContextPtr fs_context,
        int32_t error_code
    );


};

}