#ifndef _CORE_SERVICES_FS_H
#define _CORE_SERVICES_FS_H
#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"
#include "ranking/predict_service.pb.h"
#include <memory>
#include <string_view>

namespace Core {

class EmbItemFsService : public ServiceBaseInfo {
  static constexpr int kDefaultItemFsBatchSize = 40;
private:
  inline const static std::string kItemDefaultFeatureKey{"default"}; 
  FeaType _fs_type = FEA_TYPE_BOTH;
  std::string _fetch_path;
  std::string _redis_path;
  bool _is_truncation = false; // 是否在粗排截断后拉取特征
protected:
  int _batch_size = kDefaultItemFsBatchSize;

public:
  EmbItemFsService() {}

  ~EmbItemFsService() {}

  virtual void initialize(ConfigXmlPtr xml);
  virtual void initialize_xml(ConfigXmlPtr xml);
  virtual void initialize(GraphContextPtr context);
  virtual int do_service(GraphContextPtr context);

private:
  int process(CoreContextPtr context) override;
  

public:
  static void* get_item_feature(void* arg);
  static void* get_dsp_item_feature(CoreContextPtr context);
};

} // namespace Core

#endif
