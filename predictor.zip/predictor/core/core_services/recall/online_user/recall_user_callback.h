#pragma once
#include "core/core_context/context_defs.h"
#include "core/core_context/user_embedding_context.h"
#include "core/core_services/predict/predict_service.h"
#include "core/core_services/base_service/service_info.h"
#include "core/utils/error.h"
#include <brpc/options.pb.h>
#include <debug_utils.h>
#include <log_helper.h>
#include <utility>
namespace Core {
    struct RecallUserCallBack : public google::protobuf::Closure {
        RecallUserCallBack(::proto::flow::PredictRequest *req, ::proto::flow::PredictResponse *res,
                       Node *node, UserEmbeddingContextPtr ctx, std::string channel_name, brpc::CompressType request_compress_type)
            : request(req), response(res), node(node), cntl(), context(std::move(ctx)), channel_name(std::move(channel_name)) {
            cntl.set_request_compress_type(request_compress_type);
        }
        ::proto::flow::PredictRequest *request;
        ::proto::flow::PredictResponse *response;
        Node *node;
        brpc::Controller cntl;
        UserEmbeddingContextPtr context;
        std::string channel_name;

        int32_t code = 0;
        int64_t lat = 0;
        void Run() override {
            HILOG_APP(INFO) << "RecallUserCallBack::Run start";
            lat = cntl.latency_us();
            code = cntl.ErrorCode();
            if (cntl.Failed()) {
                HILOG_APP(ERROR) << node->get_name() << ",_channel_name:" << channel_name << ":"
                                 << cntl.ErrorText() << ",lat:" << lat;
            }

            if (context->get_rank_request()->debuglevel() == DebugLevel::kRecallDumpEmb) {
                debug::pb::SavePbToFile("recall_user_" + channel_name + "_predict_response.json", *response);
            }

            if (response->responses_size() > 0) {
                const auto &tf_rsp = response->responses(0);
                //HILOG_APP(INFO) << "model_type: " << experimentModelTypeToString(model_type) << ", tf_response: " << debug::printer::ToString(tf_rsp);
                const int32_t &error_code = tf_rsp.error_code();
                const std::string &error_message = tf_rsp.error_message();
                if (error_code != 10000) {
                    //模型返回 存在问题
                    HILOG_APP(ERROR) << "model: " << channel_name << ", response error_code: " << error_code << ", error_message: " << error_message;
                } else {
                    const auto &tf_rsp_outputs = tf_rsp.outputs();
                    for (const auto& output: tf_rsp_outputs) {
                        if (output.name() == "user_vec") {
                            const auto &user_embedding_output = output.values();
                            int embedding_size = user_embedding_output.float_val_size();
                            HILOG_APP(INFO) << LOG_HEAD(context) << "user embedding size: " << embedding_size;
                            // MonitorMgr::percent_report_model(context->_user_emb_model_info->_emb_name, context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()), 0, "model_embedding_size", embedding_size);
                            const float* user_embedding_vec = user_embedding_output.float_val().data();
                            auto *user_embedding_response = context->MutableUserEmbeddingResponse()->mutable_userembedding();
                            for (int i = 0; i < embedding_size; i++) {
                                user_embedding_response->Add(*(user_embedding_vec + i));
                            }
                            MonitorMgr::percent_report_model(context->_user_emb_model_info->_emb_name,
                                                     context->GetUploadSlotName(),
                                                     std::to_string(context->get_algo_scene_id()), 0, "predict_io",
                                                     lat - (tf_rsp.cost() * 1000));
                            MonitorMgr::percent_report_model(context->_user_emb_model_info->_emb_name,
                                                            context->GetUploadSlotName(),
                                                            std::to_string(context->get_algo_scene_id()), 0, "model_time",
                                                            (tf_rsp.cost()*1000));
                            float abs_sum = std::accumulate(context->GetUserEmbeddingResponse().userembedding().begin(),
                                                            context->GetUserEmbeddingResponse().userembedding().end(), 0.0f,
                                                            [](float acc, float val) { return acc + std::fabs(val); });
                            float user_emb_abs_avg = embedding_size == 0 ? 0.0 :  abs_sum / embedding_size;
                            MonitorMgr::common_report_model(context->_user_emb_model_info->_emb_name, context->GetUploadSlotName(),
                                                            std::to_string(context->get_algo_scene_id()), "default", 0, "user_emb_abs_avg",
                                                            user_emb_abs_avg);
                            MonitorMgr::common_report_model(context->_user_emb_model_info->_emb_name, context->GetUploadSlotName(),
                                                            std::to_string(context->get_algo_scene_id()), "default", 0, "user_emb_size",
                                                            embedding_size);
                            MonitorMgr::common_report_model(context->_user_emb_model_info->_emb_name, context->GetUploadSlotName(),
                                                            std::to_string(context->get_algo_scene_id()), "default", 0, "user_emb_req_num",
                                                            1);
                            break;
                        }
                    }
                }
            } else {
                HILOG_APP(ERROR) << "user embedding has no response: model_type: " << experimentModelTypeToString(ExperimentModelType::USER_EMBEDDING) << ", predict_response: " << debug::printer::ToString(response);
            }
            
            auto *base_service_ptr = dynamic_cast<ServiceBaseInfo *>(node);
            if (base_service_ptr != nullptr) {
                BizLatency *lat = base_service_ptr->get_node_stat(context)->get_lat();
                lat->_rsp_end_tm = get_cur_time_us();
            }
            node->run_output_nodes_if_ready(context);

            HILOG_APP(INFO) << "RecallUserCallBack::Run end";
            delete this;
        }

        void report() {
            MonitorMgr::common_report_model(context->_user_emb_model_info->_emb_name, context->GetUploadSlotName(),
                                                            std::to_string(context->get_algo_scene_id()), "default", 0, "model_req_num", 1);
            MonitorMgr::percent_report_model(context->_user_emb_model_info->_emb_name,
                                             context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()),
                                             0, "predict_time", lat);
        }
        virtual ~RecallUserCallBack() {
            report();
        }
    };

}// namespace Core