#include "recall_user_emb_inference_service.h"
#include "core/core_context/context_defs.h"
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "core/core_services/predict/utils/ragged_tensor_util.h"
#include "core/core_services/recall/online_user/recall_user_callback.h"
#include "core/utils/error.h"
#include "phx-fe/src/framework.h"
#include <butil/time.h>
#include <debug_utils.h>
#include <json2pb/pb_to_json.h>
#include <log_helper.h>

namespace Core {
    SERVICE_REGISTER(RecallUserEmbInferenceService);

    void RecallUserEmbInferenceService::initialize(ConfigXmlPtr xml) {
    }

    void RecallUserEmbInferenceService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<UserEmbeddingContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
    }

    bool RecallUserEmbInferenceService::skip(GraphContextPtr context) {
        auto embedding_context = dynamic_pointer_cast<UserEmbeddingContext>(context);
        return (embedding_context->_response_code != 200);
    }

    int RecallUserEmbInferenceService::do_service(GraphContextPtr context) {
        auto embedding_context = std::dynamic_pointer_cast<UserEmbeddingContext>(context);
        BizLatency *lat = get_node_stat(embedding_context)->get_lat();
        lat->_req_begin_tm = get_cur_time_us();
        if (ERROR_SUCCESS != Extract(embedding_context)) {
            this->run_output_nodes_if_ready(context);
            return ERROR_EMBEDDING_USER_PRERNAK_EMPTY;
        }
        return ERROR_SUCCESS;
    }

    phx::FeRequest *RecallUserEmbInferenceService::build_user_embedding_fe_request(UserEmbeddingContextPtr core_context) {
        phx::FeRequest *full_fe_request = core_context->get_fs_context()->feature_dump;
        auto user_embedding_fe_request =
                google::protobuf::Arena::CreateMessage<phx::FeRequest>(core_context->get_context_arena());
        const google::protobuf::Reflection *reflection = phx::FeRequest::GetReflection();
        const google::protobuf::Descriptor *descriptor = phx::FeRequest::GetDescriptor();
        for (int32_t i = 0; i < descriptor->field_count(); i++) {
            const google::protobuf::FieldDescriptor *field = descriptor->field(i);
            if (field->is_repeated()) {
                if (reflection->FieldSize(*full_fe_request, field) == 0) {
                    continue;
                }
            } else {
                if (!reflection->HasField(*full_fe_request, field)) {
                    continue;
                }
            }
            if (!field->is_repeated()) {
                switch (field->cpp_type()) {
                    case (protobuf::FieldDescriptor::CPPTYPE_MESSAGE): {
                        reflection->SetAllocatedMessage(user_embedding_fe_request,
                                                        reflection->MutableMessage(full_fe_request, field), field);
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_INT32): {
                        reflection->SetInt32(user_embedding_fe_request, field,
                                             reflection->GetInt32(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_INT64): {
                        reflection->SetInt64(user_embedding_fe_request, field,
                                             reflection->GetInt64(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_FLOAT): {
                        reflection->SetFloat(user_embedding_fe_request, field,
                                             reflection->GetFloat(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_DOUBLE): {
                        reflection->SetDouble(user_embedding_fe_request, field,
                                              reflection->GetDouble(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_STRING): {
                        reflection->SetString(user_embedding_fe_request, field,
                                              reflection->GetString(*full_fe_request, field));
                        break;
                    }
                    default:
                        break;
                }
            }
        }
        // mock一个item
        user_embedding_fe_request->add_prerank_item_fea();
        user_embedding_fe_request->add_item_fea();
        return user_embedding_fe_request;
    }

    void RecallUserEmbInferenceService::get_user_slot_data_types(const phx::ExtractorResponse *extractor_response,
                                                               std::vector<SlotDataType> &user_slot_data_types) {
        // 处理 user 特征
        for (int slot_index = 0; slot_index < user_slot_data_types.size(); ++slot_index) {
            auto &user_features = extractor_response->user_features();
            auto &feature = user_features.at(slot_index);//(slot_i,1)处的Feature
            if (feature.signs().size() > 0) {
                // 这个特征是 int
                user_slot_data_types[slot_index] = SlotDataType::INT_64;
            } else if (feature.weights().size() > 0) {
                // 这个特征是 float
                user_slot_data_types[slot_index] = SlotDataType::FLOAT;
            } else if (feature.bytes_list().size() > 0) {
                // 这个特征是 string
                user_slot_data_types[slot_index] = SlotDataType::STRING;
            }
            // 获取下一个 slot_index 的 DATA_TYPE
        }
    }

    int RecallUserEmbInferenceService::Extract(UserEmbeddingContextPtr context) {
        int ret = ERROR_SUCCESS;
        const std::string &user_model_name = context->GetRealUserModelName();
        std::shared_ptr<Info::ModelInfo> model_info = context->_user_emb_model_info;
        if (model_info == nullptr) {
            HILOG_APP(ERROR) << " not found config :" << user_model_name;
            return ERROR_EMBEDDING_USER_MODEL_CONFIG_NULL;
        }
        long fe_start = butil::gettimeofday_us();
        auto user_embedding_fe_request = build_user_embedding_fe_request(context);
        if (context->get_rank_request()->debuglevel() == DebugLevel::kRecallDumpEmb) {
            debug::pb::SavePbToFile("recall_user_" + model_info->_model_name + "_fe_request.json", *user_embedding_fe_request);
        }
        context->_user_extractor_response =
                google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(context->get_context_arena());
        auto *empty_user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(context->get_context_arena());

        toExtractorResponse(context->get_context_arena(), *user_embedding_fe_request, *empty_user_action,
                            model_info->get_config_info(), *context->_user_extractor_response, model_info->_is_ltr);

        BizLatency *lat = get_node_stat(context)->get_lat();
        long fe_end = butil::gettimeofday_us();
        MonitorMgr::percent_report_model(model_info->_emb_name, context->GetUploadSlotName() , std::to_string(context->GetAlgoSceneId()),0, "single_fe_cost",  (fe_end - fe_start));
        MonitorMgr::percent_report_model(model_info->_emb_name, context->GetUploadSlotName() , std::to_string(context->GetAlgoSceneId()),0, "model_total_fe_cost",  (fe_end - fe_start));
        int64_t now = butil::gettimeofday_us();
        lat->_req_end_tm = now;
        lat->_rsp_begin_tm = now;
        ret = Predict(context, model_info, context->_user_extractor_response);
        if (ERROR_SUCCESS != ret) {
            HILOG_APP(ERROR) << " RecallUserEmbInferenceService inference ERROR";
        }
        return ret;
    }

    int RecallUserEmbInferenceService::Predict(UserEmbeddingContextPtr context, std::shared_ptr<Info::ModelInfo> model_info,
                                               phx::ExtractorResponse *extractor_response) {
        if (extractor_response == nullptr) {
            HILOG_APP(ERROR) << "model name: " << model_info->_model_name << ", extractor_responses is nullptr";
            return ERROR_EMBEDDING_USER_PRERNAK_EMPTY;
        }
        auto &user_features = extractor_response->user_features();
        const size_t user_slot_num = user_features.size();
        auto user_slot_data_types = std::vector<SlotDataType>(user_slot_num, SlotDataType::UNKNOWN);
        get_user_slot_data_types(extractor_response, user_slot_data_types);
        HILOG_APP(INFO) << "get_user_slot_data_types end";

        std::vector<SlotInfo> user_slot_list(user_slot_num);

        //处理 user 特征
        for (int i = 0; i < user_slot_num; ++i) {
            auto& feature = user_features.at(i);//(slot_i,1)处的Feature
            SlotDataType data_type = user_slot_data_types[i];
            switch (data_type) {
                case SlotDataType::INT_64: {
                    if (!user_slot_list[i].int_values) {
                        user_slot_list[i].int_values = std::make_shared<std::vector<std::vector<int64_t>>>();
                    }
                    user_slot_list[i].slot_data_type = SlotDataType::INT_64;
                    std::vector<std::vector<int64_t>> &slot_features = *user_slot_list[i].int_values;
                    const auto &data = feature.signs();
                    user_slot_list[i].slot_id = feature.slot_id();
                    std::vector<int64_t> feature_data(data.size());
                    //把feature.signs()转换成 vector<int>
                    for (int k = 0; k < data.size(); ++k) {
                        feature_data[k] = data[k];
                    }
                    slot_features.push_back(feature_data);
                    break;
                }
                case SlotDataType::FLOAT: {
                    if (!user_slot_list[i].float_values) {
                        user_slot_list[i].float_values = std::make_shared<std::vector<std::vector<float>>>();
                    }
                    user_slot_list[i].slot_data_type = SlotDataType::FLOAT;
                    std::vector<std::vector<float>> &slot_features = *user_slot_list[i].float_values;
                    const auto &data = feature.weights();
                    user_slot_list[i].slot_id = feature.slot_id();
                    std::vector<float> feature_data(data.size());
                    //把feature.signs()转换成 vector<float>
                    for (int k = 0; k < data.size(); ++k) {
                        feature_data[k] = data[k];
                    }
                    slot_features.push_back(feature_data);
                    break;
                }
                case SlotDataType::STRING: {
                    if (!user_slot_list[i].string_values) {
                        user_slot_list[i].string_values = std::make_shared<std::vector<std::vector<std::string>>>();
                    }
                    user_slot_list[i].slot_data_type = SlotDataType::STRING;
                    std::vector<std::vector<std::string>> &slot_features = *user_slot_list[i].string_values;
                    const auto &data = feature.bytes_list();
                    user_slot_list[i].slot_id = feature.slot_id();
                    std::vector<std::string> feature_data(data.size());
                    //把feature.signs()转换成 vector<string>
                    for (int k = 0; k < data.size(); ++k) {
                        feature_data[k] = data[k];
                    }
                    slot_features.push_back(feature_data);
                    break;
                }
                default: {
                    // HILOG_APP(INFO) << "user feature 具有未知的 data type";
                    user_slot_list[i].slot_data_type = SlotDataType::UNKNOWN;
                    user_slot_list[i].slot_id = feature.slot_id();
                    break;
                }
            }
        }

        // 写 user_slot_list 到文件 predict_type + model_name + user_slot_list.txt
        if (context->get_rank_request()->debuglevel() == DebugLevel::kRecallDumpEmb) {
            debug::file::WriteToFile("recall_user_" + context->GetRealUserModelName() + "_user_slot_list.txt", debug::printer::ToString(user_slot_list));
        }

        // user embedding 不用item分包
        // std::vector<std::vector<SlotInfo>> item_splited_batches(1, std::vector<SlotInfo>(item_slot_num));

        auto predict_request =
                google::protobuf::Arena::CreateMessage<::proto::flow::PredictRequest>(context->get_context_arena());
        ::proto::flow::ModelPredictRequest *model_request = predict_request->add_model_requests();
        model_request->set_model_name(model_info->_model_name);
        model_request->set_model_version(context->GetUserEmbeddingVersion());

        //处理 user特征
        for (const auto &user_slot_info: user_slot_list) {
            auto *user_input = model_request->add_inputs();
            user_input->set_name(user_slot_info.slot_id);
            user_input->set_type(0);// 0表示user 1表示item

            //填充 user 特征到 inputs
            switch (user_slot_info.get_data_type()) {
                case SlotDataType::INT_64: {
                    ::proto::flow::RaggedTensorProto *rt(RaggedTensorUtil::FromValues(*user_slot_info.int_values));
                    user_input->set_allocated_values(rt);
                    break;
                }
                case SlotDataType::FLOAT: {
                    ::proto::flow::RaggedTensorProto *rt(RaggedTensorUtil::FromValues(*user_slot_info.float_values));
                    user_input->set_allocated_values(rt);
                    break;
                }
                case SlotDataType::STRING: {
                    ::proto::flow::RaggedTensorProto *rt(RaggedTensorUtil::FromValues(*user_slot_info.string_values));
                    user_input->set_allocated_values(rt);
                    break;
                }
                default: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(std::vector<std::vector<int64_t>>()));
                    user_input->set_allocated_values(rt);
                    break;
                }
            }
        }

        if (context->get_rank_request()->debuglevel() == DebugLevel::kRecallDumpEmb) {
            debug::pb::SavePbToFile("recall_user_fe_snapshot.json", *context->get_fs_context()->get_feature_dump());
        }

        // 调tfserving
        brpc::Channel *channel = model_info->get_channel();
        ::proto::flow::PredicterService_Stub stub(channel);
        auto predict_response =
                google::protobuf::Arena::CreateMessage<::proto::flow::PredictResponse>(context->get_context_arena());
        if (context->get_rank_request()->debuglevel() == DebugLevel::kRecallDumpEmb) {
            debug::pb::SavePbToFile("recall_user_" + model_info->_model_name + "_predict_request.json", *predict_request);
        }
        auto *recall_user_callback =
                new RecallUserCallBack(predict_request, predict_response, this, context, model_info->_model_name,
                                        model_info->_request_compress_type);
        stub.Predict(&recall_user_callback->cntl, recall_user_callback->request, recall_user_callback->response,
                     recall_user_callback);
        return ERROR_SUCCESS;
    }

}// namespace Core