#pragma once
#include "core/core_context/user_embedding_context.h"
#include "core/core_context/item_embedding_context.h"
#include "core/core_services/base_service/service_info.h"
#include <butil/third_party/rapidjson/document.h>
namespace Core {
    class RecallUserEmbStartService : public ServiceBaseInfo {
    private:
        std::string _dict_name;
    public:
        virtual void initialize(GraphContextPtr context);
        virtual void initialize(ConfigXmlPtr xml);
        int do_service(GraphContextPtr context) override;
        // static ItemEmbeddingAdPair* user_embedding_mocked_ad_pair;

        template <typename T>
        static bool safe_string_to_num(const std::string &str, T &out_value) {
            std::istringstream iss(str);
            iss >> out_value;
            return !iss.fail() && iss.eof();
        }
    private:
        int32_t process(UserEmbeddingContextPtr context);
        int32_t CheckRequest(UserEmbeddingContextPtr context);
        int32_t convert2RankRequest(UserEmbeddingContextPtr context);
        void genContextFeat(UserEmbeddingContextPtr context, FSContextPtr fs_ctx, const phx::PredictorRequest *req);
        void addTrackExtFeat(const butil::rapidjson::Document &doc, phx::FeRequest *feature_dump, const std::string &rtFeatureName);
    };

};// namespace Core