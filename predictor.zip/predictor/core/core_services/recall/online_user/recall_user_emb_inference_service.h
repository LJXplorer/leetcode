#pragma once

#include "core/core_services/base_service/service_info.h"
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "core/core_context/user_embedding_context.h"
#include "core/core_services/predict/predict_service.h"
#include <memory>
namespace Core {
class RecallUserEmbInferenceService : public ServiceBaseInfo {

public:
  RecallUserEmbInferenceService() = default;
  ~RecallUserEmbInferenceService() {}
  void initialize(ConfigXmlPtr xml) override;
  virtual void initialize(GraphContextPtr context);
  virtual int do_service(GraphContextPtr context) override;
  bool skip(GraphContextPtr context) override;
  const Node_Type type() override{
      return HLframe::NODE_TYPE_IO ;
  }

public:
  // int process(UserEmbeddingContextPtr context) override;
  int Extract(UserEmbeddingContextPtr context);
  int Predict(UserEmbeddingContextPtr context, std::shared_ptr<Info::ModelInfo> model_info, phx::ExtractorResponse* extractor_response);
  phx::FeRequest *build_user_embedding_fe_request(UserEmbeddingContextPtr core_context);
  void get_user_slot_data_types(const phx::ExtractorResponse *extractor_response, std::vector<SlotDataType> &slot_data_types);
  void process_predict_response(UserEmbeddingContextPtr context, const ::proto::flow::PredictResponse& predict_response);

  
};
} // namespace Core