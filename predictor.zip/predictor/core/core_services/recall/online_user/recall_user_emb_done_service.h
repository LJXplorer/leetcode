#pragma once
#include "core/core_context/user_embedding_context.h"
#include "core/core_services/base_service/service_info.h"

namespace Core {
    class RecallUserEmbDoneService : public ServiceBaseInfo {
    public:
        RecallUserEmbDoneService() = default;
        virtual ~RecallUserEmbDoneService() {};
        virtual void initialize(GraphContextPtr context);
        int do_service(GraphContextPtr context) override;
        int assembly_response(UserEmbeddingContextPtr context);
    };

}// namespace Core