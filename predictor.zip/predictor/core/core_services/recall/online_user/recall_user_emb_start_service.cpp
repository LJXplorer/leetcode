#include "recall_user_emb_start_service.h"
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "core/core_services/predict/utils/model_version.h"
#include "core/utils/error.h"
#include "core/utils/prehandle_query.h"
#include "hlframe/context.h"
#include <cstdint>
#include <exception>
#include <log_helper.h>
#include <memory>
#include <string>
namespace Core {
    SERVICE_REGISTER(RecallUserEmbStartService);
    // ItemEmbeddingAdPair* RecallUserEmbStartService::user_embedding_mocked_ad_pair = []() {
    //     auto* embedding_ad_pair_mocked = new ItemEmbeddingAdPair();
    //     auto* ad_info_mocked = new qinglongv2::EmbeddingAdInfo();
    //     ad_info_mocked->mutable_crid()->assign("0");
    //     embedding_ad_pair_mocked->ad_info = ad_info_mocked;
    //     auto* ad_embedding_mocked = new qinglongv2::ItemEmbedding();
    //     ad_embedding_mocked->mutable_crid()->assign("0");
    //     embedding_ad_pair_mocked->ad_embedding = ad_embedding_mocked;
    //     return embedding_ad_pair_mocked;
    // }();

    void RecallUserEmbStartService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<UserEmbeddingContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
    }

    void RecallUserEmbStartService::initialize(ConfigXmlPtr xml) {
        xml->attr<std::string>("dict_name", _dict_name);
    }

    int RecallUserEmbStartService::do_service(GraphContextPtr context) {
        HILOG_APP(INFO) << "=====================phx RecallUserEmbStartService::do_service  start====================================";
        auto ctx = std::dynamic_pointer_cast<UserEmbeddingContext>(context);
        int32_t ret = 0;
        try {
            ctx->gen_log_head();
            ret = process(ctx);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << "phx do service fail: " << ret << "," << e.what();
        }
        HILOG_APP(INFO) << "=====================phx RecallUserEmbStartService::do_service  end====================================";
        return ret;
    }


    int32_t RecallUserEmbStartService::process(UserEmbeddingContextPtr context) {
        auto embedding_context = dynamic_pointer_cast<UserEmbeddingContext>(context);
        BizLatency *lat = get_node_stat(embedding_context)->get_lat();
        const std::string &real_model_name = embedding_context->GetRealUserModelName();
        int32_t ret = 0;
        {
            BizLatencyGaurd lat_guard(lat,LAT_STAGE_CREATE);
            ret = CheckRequest(embedding_context);
            if (ret != ERROR_SUCCESS) {
                HILOG_APP(ERROR) << LOG_HEAD(embedding_context) << get_name() << "CheckRequest failed, code:" << ret;
                return ret;
            }
            embedding_context->_user_emb_model_info = Info::ModelInfoManager::instance().get_model_info(real_model_name);
            if (embedding_context->_user_emb_model_info == nullptr) {
                HILOG_APP(ERROR) << LOG_HEAD(embedding_context) << "user model info null ";
                embedding_context->_response_code = ERROR_EMBEDDING_USER_MODEL_CONFIG_NULL;
                MonitorMgr::common_report_model(embedding_context->GetUserEmbeddingModelName(), "0",
                                                    std::to_string(embedding_context->GetAlgoSceneId()), "default", -1,
                                                    "model_not_found", 1);
                return ERROR_EMBEDDING_USER_MODEL_CONFIG_NULL;
            }
            auto [cur_version, bak_version] = ModelVersion::instance().get_available_model_versions(real_model_name);

            const int32_t requested_version = embedding_context->GetUserEmbeddingVersion();
            
            if (cur_version > 0) {
                embedding_context->MutableUserEmbeddingResponse()->mutable_supporteduserembeddingversion()->Add(cur_version);
            }
            if (bak_version > 0) {
                embedding_context->MutableUserEmbeddingResponse()->mutable_supporteduserembeddingversion()->Add(bak_version);
            }
            if (requested_version != cur_version && requested_version != bak_version) {
                HILOG_APP(ERROR) << LOG_HEAD(embedding_context) << get_name() << " not available: [" << real_model_name
                                << "], mode_type:user embedding; reqeusted version = [" << requested_version
                                << "]; cur version = [" << cur_version << "]; bak_version = [" << bak_version << "]";
                embedding_context->_response_code = ERROR_EMBEDDING_USER_MODEL_CONFIG_NULL;
                MonitorMgr::common_report_model(embedding_context->GetUserEmbeddingModelName(), "0",
                                                    std::to_string(embedding_context->GetAlgoSceneId()), "default", -1,
                                                    "version_not_found", 1);
                return ERROR_EMBEDDING_USER_MODEL_CONFIG_NULL;
            }
            embedding_context->MutableUserEmbeddingResponse()->set_useduserembeddingversion(requested_version);
        }

        {
            BizLatencyGaurd lat_guard(lat,LAT_STAGE_DESTROY);
            convert2RankRequest(embedding_context);
            const auto fs_ctx_req = context->get_rank_request();
            if (fs_ctx_req->debuglevel() == DebugLevel::kRecallDumpProto) {
                debug::pb::SavePbToFile(fs_ctx_req->reqid() + "_user_convert2rank_request.json", *fs_ctx_req);
            }
            auto fs_ctx = context->get_fs_context();
            // 填充req_id
            fs_ctx->get_feature_dump()->mutable_req_id()->assign(context->get_req_id());
            //填上下文特征
            genContextFeat(context, fs_ctx, fs_ctx_req);
        }
        return ERROR_SUCCESS;
    }

    void RecallUserEmbStartService::genContextFeat(UserEmbeddingContextPtr context, FSContextPtr fs_ctx, const phx::PredictorRequest *req) {
        auto feature_dump = fs_ctx->get_feature_dump();

        feature_dump->set_req_time(context->get_begin_time());

        feature_dump->mutable_context()->set_adunit_id(req->predictorslotinfo().slotid());

        feature_dump->mutable_context()->set_media_id(req->mediaid());

        feature_dump->mutable_context()->mutable_launch_type()->assign(req->rtrequestfeature().launchtype());

        feature_dump->mutable_context()->set_user_installed_appid(req->hostappid());

        feature_dump->mutable_context()->set_screen_width(req->deviceinfo().screenwidth());

        feature_dump->mutable_context()->set_screen_height(req->deviceinfo().screenheight());

        feature_dump->mutable_context()->set_ppi(req->deviceinfo().ppi());

        feature_dump->mutable_context()->set_connection_type(req->deviceinfo().connectiontype());

        feature_dump->mutable_context()->mutable_query()->assign(req->query());

        Utf8Processing::Utf8Handler handler;
        const std::string &result = handler.pre_handled_query(req->query());
        context->set_handled_query(result);
        feature_dump->mutable_handled_query()->assign(result);

        feature_dump->mutable_context()->set_trigger_scene(req->triggerscene());

        // switch (req->predictorslotinfo().route()) {
        //     case 1: {
        //         feature_dump->mutable_context()->mutable_traffic_id()->assign("cloud");
        //         break;
        //     }
        //     case 2: {
        //         feature_dump->mutable_context()->mutable_traffic_id()->assign("byte");
        //         break;
        //     }
        //     case 3: {
        //         feature_dump->mutable_context()->mutable_traffic_id()->assign("it");
        //         break;
        //     }
        //     case 4: {
        //         feature_dump->mutable_context()->mutable_traffic_id()->assign("s1");
        //         break;
        //     }
        //     default: {
        //         feature_dump->mutable_context()->mutable_traffic_id()->assign("默认值");
        //         break;
        //     }
        // }

        feature_dump->mutable_context()->mutable_oaid()->assign(req->oaid());

        feature_dump->mutable_context()->set_media_type(req->mediatype());

        if (!req->rtrequestfeature().trackext().empty()) {
            butil::rapidjson::Document doc;
            doc.Parse(req->rtrequestfeature().trackext().c_str());
            if (!doc.HasParseError() && doc.IsObject()) {
                try {
                    addTrackExtFeat(doc, feature_dump, "sessionId");
                    addTrackExtFeat(doc, feature_dump, "detailType");
                    addTrackExtFeat(doc, feature_dump, "visitSource");
                    addTrackExtFeat(doc, feature_dump, "sourcePackageName");
                } catch (const std::exception &e) {
                    HILOG_APP(ERROR) << "add track_ext feat has exception " << e.what();
                }
            }
        }
    }

    int32_t RecallUserEmbStartService::CheckRequest(UserEmbeddingContextPtr context) {
        const auto& user_emb_req = context->GetUserEmbeddingRequest();
        if (user_emb_req.userembeddingmodelname().empty()) {
            context->_response_code = ERROR_EMBEDDING_URL_EMPTY;
            return ERROR_EMBEDDING_URL_EMPTY;
        }
        if (user_emb_req.userembeddingversion() <= 0) {
            context->_response_code = ERROR_EMBEDDING_USER_MODEL_CONFIG_NULL;
            return ERROR_EMBEDDING_USER_MODEL_CONFIG_NULL;
        }
        return ERROR_SUCCESS;
    }

    int32_t RecallUserEmbStartService::convert2RankRequest(UserEmbeddingContextPtr context) {
        const auto &user_emb_req = context->GetUserEmbeddingRequest();
        const auto &user_emb_rt_features = user_emb_req.userembeddingrtfeatures();
        auto *mutable_rank_req = context->get_mutable_rank_request();
        mutable_rank_req->set_reqid(user_emb_req.reqid());
        mutable_rank_req->set_oaid(user_emb_req.oaid());
        mutable_rank_req->set_debuglevel(user_emb_req.debuglevel());
        auto *mutable_predictorslotinfo = mutable_rank_req->mutable_predictorslotinfo();
        mutable_predictorslotinfo->set_predicttimestamp(context->get_begin_time());
        mutable_predictorslotinfo->set_algosceneid(static_cast<int32_t>(Info::ModelType::USER_EMBEDDING));

        int64_t slotid = 0L;
        if (!user_emb_rt_features.adunitid().empty() && !safe_string_to_num(user_emb_rt_features.adunitid(), slotid)) {
            HILOG_APP(ERROR) << LOG_HEAD(context) << "failed to convert user_emb_rt_features.adunitid() to int64 type, user_emb_rt_features.adunitid(): " << user_emb_rt_features.adunitid();
        } else {
            mutable_predictorslotinfo->set_slotid(slotid);
        }

        int64_t mediaid = 0L;
        if (!user_emb_rt_features.mediaid().empty() && !safe_string_to_num(user_emb_rt_features.mediaid(), mediaid)) {
            HILOG_APP(ERROR) << LOG_HEAD(context) << "failed to convert user_emb_rt_features.mediaid() to int64 type, user_emb_rt_features.mediaid(): " << user_emb_rt_features.mediaid();
        } else {
            mutable_rank_req->set_mediaid(mediaid);
        }

        auto *mutable_rtrequestfeature = mutable_rank_req->mutable_rtrequestfeature();
        mutable_rtrequestfeature->set_launchtype(user_emb_rt_features.launchtype());

        mutable_predictorslotinfo->mutable_rtadunitfeature()->mutable_industryids()->CopyFrom(user_emb_rt_features.industryids());

        mutable_rtrequestfeature->set_userinstalledpkgname(user_emb_rt_features.userinstalledpkgname());

        if (!user_emb_rt_features.userinstalledpkgname().empty()) {
            auto dict_iter = AdDict::AdDictCollectorInstance::instance().get_dict(_dict_name);
            if (dict_iter != nullptr) {
                auto pkg2appid_map = dict_iter->get_data<AdDict::package_name_2_app_id_type>();
                if (pkg2appid_map != nullptr) {
                    auto appid_iter = pkg2appid_map->find(user_emb_rt_features.userinstalledpkgname());
                    if (appid_iter != pkg2appid_map->end()) {
                        mutable_rank_req->set_hostappid(appid_iter->second->app_id());
                    } else {
                        // todo report
                        HILOG_APP(WARNING) << LOG_HEAD(context) << "Cannot find hostappid from userinstalledpkgname, package name: " << user_emb_rt_features.userinstalledpkgname();
                    }
                } else {
                    HILOG_APP(ERROR) << LOG_HEAD(context) << "Failed to get pkg2appid_map from dict, dict:" << _dict_name;
                }
            } else {
                HILOG_APP(ERROR) << LOG_HEAD(context) << "Failed to get PackageName2AppIdInfoDict dictInfo, dict:" << _dict_name;
            }
        }

        auto *mutable_deviceinfo = mutable_rank_req->mutable_deviceinfo();
        mutable_deviceinfo->set_screenwidth(user_emb_rt_features.screenwidth());
        mutable_deviceinfo->set_screenheight(user_emb_rt_features.screenheight());
        mutable_deviceinfo->set_ppi(user_emb_rt_features.ppi());

        const google::protobuf::EnumDescriptor* enum_descriptor = ::adcommon::ConnectionType_descriptor();
        const google::protobuf::EnumValueDescriptor* value_descriptor = enum_descriptor->FindValueByName(user_emb_rt_features.connectiontype());
        if (value_descriptor == nullptr) {
            mutable_deviceinfo->set_connectiontype(::adcommon::ConnectionType::UNKNOWN_TYPE);
        } else {
            mutable_deviceinfo->set_connectiontype(static_cast<::adcommon::ConnectionType>(value_descriptor->number()));
        }

        mutable_rank_req->set_query(user_emb_rt_features.query());
        mutable_rank_req->set_triggerscene(user_emb_rt_features.triggerscene());

        mutable_rtrequestfeature->set_trackext(user_emb_rt_features.trackext());

        mutable_rank_req->set_mediatype(user_emb_rt_features.mediatype());

        // mock一个item
        // auto *add_rank_item = mutable_rank_req->mutable_predictorslotinfo()->add_predictoriteminfos();
        // add_rank_item->set_creativeid(0);
        // add_rank_item->set_appid(0);
        // context->_emb_ads_map.insert({add_rank_item->creativeid(), *user_embedding_mocked_ad_pair});
        // context->get_fs_context()->alloc_item_fea(add_rank_item->creativeid());
        // context->get_fs_context()->alloc_app_fea(add_rank_item->appid());
        return ERROR_SUCCESS;
    }

    void RecallUserEmbStartService::addTrackExtFeat(const butil::rapidjson::Document &doc, phx::FeRequest *feature_dump,
                                       const std::string &rtFeatureName) {
        if (doc.HasMember(rtFeatureName.c_str())) {
            const butil::rapidjson::Value &value = doc[rtFeatureName.c_str()];
            if (rtFeatureName == "sessionId") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0)
                    feature_dump->mutable_context()->mutable_session_id()->assign(value.GetString());
            } else if (rtFeatureName == "detailType") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0) {
                    try {
                        feature_dump->mutable_context()->set_detail_type(std::stoi(value.GetString()));
                    } catch (const std::exception &e) {
                        HILOG_APP(WARNING) << get_name() << "detailType string parse to int has exception " << e.what();
                    }
                }
            } else if (rtFeatureName == "visitSource") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0)
                    feature_dump->mutable_context()->mutable_visit_source()->assign(value.GetString());
            } else if (rtFeatureName == "sourcePackageName") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0)
                    feature_dump->mutable_context()->mutable_source_package_name()->assign(value.GetString());
            }
        }
    }
}// namespace Core