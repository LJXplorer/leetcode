#pragma once
#include <fstream>
#include <log_helper.h>
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "ranking/embedding_info.pb.h"

namespace Core {
    class EmbInfoDictManager {
    
    private:
        // 私有构造函数
        EmbInfoDictManager() = default;

    public:
        // 禁用拷贝构造和赋值运算符
        EmbInfoDictManager(const EmbInfoDictManager &) = delete;
        EmbInfoDictManager &operator=(const EmbInfoDictManager &) = delete;

        const static std::string versionFile;
        const static std::string adEmbeddingFile;
        const static std::string adInfoFile;
        static std::atomic<int32_t> taskRunning;

    public:
        // 使用magic static获取单例（C++11起线程安全）
        static EmbInfoDictManager &GetInstance() {
            static EmbInfoDictManager instance;// 线程安全的初始化
            return instance;
        }

        // 从商推词典读取广告信息
        int readDict(const std::string& dir, honor::retrieval::annindex::EmbeddingInfoData* dict);
        
        // 将广告向量结果写回给商推
        int writeEmbedding(const std::string& dir, const honor::retrieval::annindex::EmbeddingInfoData& embedding);

        // 更新最新版本号
        int updateVersion(const std::string& dir, const std::string& version);

        // 获取最新版本号
        static int getLatestVersion(const std::string& path);

        static void offlineItemEmbRun(const std::string& dir, const std::shared_ptr<Info::ModelInfo> &model_info, const honor::retrieval::annindex::EmbeddingInfoData& embedding_info_data);
    
    private:
        bool checkDirectories(const std::string& dir);

    };
}