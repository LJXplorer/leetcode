#include "emb_info_dict_manager.h"
#include "core/core_context/item_embedding_context.h"
#include "core/core_services/predict/utils/model_version.h"
#include "hlframe/graph_manager.h"
#include "core/core_server/server_config/server_config.h"
#include <filesystem>
namespace Core {
    namespace fs = std::filesystem;
    const std::string EmbInfoDictManager::versionFile {"latest_version.txt"};
    const std::string EmbInfoDictManager::adEmbeddingFile {"ad_embedding.pb"};
    const std::string EmbInfoDictManager::adInfoFile {"ad_info.pb"};
    std::atomic<int32_t> EmbInfoDictManager::taskRunning{0};

    int EmbInfoDictManager::readDict(const std::string& dir, honor::retrieval::annindex::EmbeddingInfoData* dict) {
        if (dict == nullptr) {
            HILOG_APP(ERROR) << "Embedding info dict is nullptr";
            return -1;
        }
        std::string path = dir + adInfoFile;
        std::ifstream input_file(path, std::ios::binary);
        if (!input_file) {
            HILOG_APP(ERROR) << "Failed to open file: " << path;
            return -1;
        }

        if (!dict->ParseFromIstream(&input_file)) {
            HILOG_APP(ERROR) << "Failed to parse item info dict from file: " << path;
            return -1;
        }

        HILOG_APP(ERROR) << "Successfully parsed item info dict from file: " << path;
        return 0;
    }

    int EmbInfoDictManager::writeEmbedding(const std::string& dir, const honor::retrieval::annindex::EmbeddingInfoData& embedding) {
        if (!checkDirectories(dir)) return -1;
        std::string path = dir + adEmbeddingFile;
        std::ofstream output_file(path, std::ios::binary);
        if (!embedding.SerializeToOstream(&output_file)) {
            HILOG_APP(ERROR) << "Failed to write embedding info data to: " << path;
            return -1;
        }
        HILOG_APP(ERROR) << "Successfully write embedding info data to: " << path;
        return 0;
    }

    int EmbInfoDictManager::updateVersion(const std::string& dir, const std::string& version) {
        if (!checkDirectories(dir)) return -1;
        std::string path = dir + versionFile;
        std::ofstream output_file(path, std::ios::trunc);
        if (!output_file) {
            HILOG_APP(ERROR) << "Failed to open version file: " << path;
            return -1;
        }
        output_file << version;
        output_file.close();

        HILOG_APP(ERROR) << "Successfully write embedding info data to: " << path;
        return 0;
    }

    int EmbInfoDictManager::getLatestVersion(const std::string& path) {
        int latest_version = -1;
        if (!fs::exists(path)) return latest_version;
        std::ifstream input_file(path);
        if (!input_file) {
            HILOG_APP(ERROR) << "Failed to open latest version file: " << path;
            return latest_version;
        }
        // 读取input_file中的数字，赋值给latest_version
        input_file >> latest_version;
        if (input_file.fail() || input_file.bad()) {
            HILOG_APP(ERROR) << "Failed to parse version number from file: " << path;
            latest_version = -1;
        }
        input_file.close();

        return latest_version;
    }

    bool EmbInfoDictManager::checkDirectories(const std::string& dir) {
        if (fs::exists(dir)) return true;
        try {
            if (!fs::create_directories(dir)) {
                HILOG_APP(ERROR) << "create directories failed: " << dir;
                return false;
            }
        } catch (const fs::filesystem_error& e) {
            HILOG_APP(ERROR) << "create directories filesystem error: " << e.what();
            return false;
        } catch (const std::exception& e) {
            HILOG_APP(ERROR) << "create directories unknown error: " << e.what();
            return false;
        }
        return true;
    }

    void EmbInfoDictManager::offlineItemEmbRun(const std::string& dir, const std::shared_ptr<Info::ModelInfo> &model_info, const honor::retrieval::annindex::EmbeddingInfoData& embedding_info_data) {
        auto graph = HLframe::GraphManager::instance().get_graph(ServerConfig::_recall_offline_embedding_graph_name);
        if (graph == nullptr) {
            HILOG_APP(ERROR) << "vector recall item offline embedding service graph not found! graph name =["
                    << ServerConfig::_recall_offline_embedding_graph_name
                    << "]";
            return;
        }
        if (dir.empty()) {
            HILOG_APP(ERROR) << "vector recall item offline embedding ad_embedding_info_path is empty";
            return;
        }

        if (model_info->_emb_name.empty()) {
            HILOG_APP(ERROR) << "offline item model emb name empty! model_name = [" << model_info->_model_name << "];";
            return;
        }


        int model_version = ModelVersion::instance().get_model_version(model_info->_model_name);
        if (model_version < 0) {
            HILOG_APP(ERROR) << "offline item model version invalid! version = [" << model_version << "];";
            return;
        }

        HILOG_APP(ERROR) << "vector_recall_offline_graph_run" << ", model_name: " << model_info->_model_name << ", emb_name: " << model_info->_emb_name
                << ", model version: " << model_version << std::endl;
        
        // 需要等user模型版本更新完后，再更新向量
        if (model_info->_pair_model.empty()) {
            HILOG_APP(ERROR) << "offline item model pair name empty! model_name = [" << model_info->_model_name << "];";
            return;
        }
        int pair_model_version = ModelVersion::instance().get_model_version(model_info->_pair_model);
        if (pair_model_version != model_version) {
            HILOG_APP(ERROR) << "offline item model and user model version not consistant! model_name = [" << model_info->_model_name << "], item version = [" << model_version << "], user version = [" << pair_model_version << "]";
            return;
        }

        // 如果版本没有变化，则不更新向量
        int latest_version = getLatestVersion(dir + model_info->_emb_name + "/" + versionFile);
        if (latest_version == model_version) {
            HILOG_APP(ERROR) << "offline item model version not updated, " << model_info->_model_name << ":  version = [" << model_version << "]";
            return;
        }

        ItemEmbeddingContextPtr embedding_context = std::make_shared<ItemEmbeddingContext>();
        embedding_context->MutableEmbeddingInfoData()->CopyFrom(embedding_info_data);

        auto *fake_embedding_request = new qinglongv2::ItemEmbeddingRequest();
        auto *fake_embedding_response = new qinglongv2::ItemEmbeddingResponse();
        for (auto& emb_info : *embedding_context->MutableEmbeddingInfoData()->mutable_embeddinginfos()) {
            auto adinfo = fake_embedding_request->add_adinfos();
            std::string materialid = std::to_string(emb_info.crid());
            embedding_context->_offline_item_emb_info_map.insert({materialid, &emb_info});
            adinfo->set_crid(materialid);
            adinfo->set_adgroupid(std::to_string(emb_info.adgroupid()));
            adinfo->set_billingmode(std::to_string(emb_info.billingmode()));
            adinfo->set_convtype(emb_info.convtype());
            adinfo->set_deepconvtype(emb_info.deepconvtype());
            adinfo->set_enhanceconvtype(emb_info.enhanceconvtype());
            adinfo->set_convgoal(std::to_string(emb_info.convgoal()));
            adinfo->set_bid(emb_info.bid());
            adinfo->set_ocpxsbp(emb_info.ocpxsbp());
            adinfo->set_isinner(emb_info.isinner());
            // adinfo->set_datasource(emb_info.datasource()); // 召回都是直投
            adinfo->mutable_itemfeature()->set_industryl1code(std::to_string(emb_info.industryl1code()));
            adinfo->mutable_itemfeature()->set_industryl2code(std::to_string(emb_info.industryl2code()));
            adinfo->mutable_itemfeature()->set_adcreativepkgname(emb_info.adcreativepkgname());
            adinfo->mutable_itemfeature()->set_rtaid(emb_info.rtaid());
            adinfo->mutable_itemfeature()->set_rtaurlid(emb_info.rtaurlid());
            // kwType、keyword
        }
        fake_embedding_request->set_reqid("offline_default_reqid");
        fake_embedding_request->set_oaid("offline_default_oaid");
        fake_embedding_request->set_embeddingtype(::qinglongv2::EmbeddingType::ITEM_EMBEDDING);
        fake_embedding_request->set_itemembeddingmodelname(model_info->_emb_name);
        fake_embedding_request->set_itemembeddingversion(model_version);

        // todo 上线前删除
        // debug::pb::SavePbToFile("recall_offline_item_emb_request.json", *fake_embedding_request);

        embedding_context->make_request_context(nullptr, fake_embedding_request, fake_embedding_response, nullptr);
        embedding_context->_is_offline_emb_task = true;
        embedding_context->_offline_ad_embedding_info_path = dir;
        embedding_context->init();
        taskRunning.fetch_add(1);
        graph->run(embedding_context, nullptr, fake_embedding_request, fake_embedding_response, nullptr);
    }
}