#include "recall_offline_item_emb_inference_service.h"

namespace Core {
    SERVICE_REGISTER(RecallOfflineItemEmbInferenceService);

    common::lockfree_threadpool::Executor RecallOfflineItemEmbInferenceService::offline_item_embedding_fe_executor{common_thread_pool_size, common_thread_pool_size * 5, "recall_offline_item_emb_fe_executor"};

    void RecallOfflineItemEmbInferenceService::parallel_extract_execute(std::vector<EmbExtractorArgs> &args_vec) {
        if (args_vec.empty()) {
            HILOG_APP(ERROR) << "item embedding parallel_extract_execute has empty args_vec!";
            return;
        }
        if constexpr (!use_bthread_pool) {
            auto *latch = args_vec[0].latch;
            for (auto &args: args_vec) {
                common::lockfree_threadpool::TaskWrapper task_wrapper{};
                task_wrapper.args = (void *) (&args);
                task_wrapper.t = RecallItemEmbInferenceService::Extract;
                RecallOfflineItemEmbInferenceService::offline_item_embedding_fe_executor.enqueue(task_wrapper);
            }
            latch->Wait();
        } else {
            for (auto &args: args_vec) {
                bthread_start_background(&args.tid, &BTHREAD_ATTR_SMALL, RecallItemEmbInferenceService::Extract, &args);
            }

            for (auto &args: args_vec) {
                bthread_join(args.tid, nullptr);
            }
        }
    }
}// namespace Core
