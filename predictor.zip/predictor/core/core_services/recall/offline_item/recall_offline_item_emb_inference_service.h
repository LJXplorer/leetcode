#pragma once
#include "core/core_services/recall/online_item/recall_item_emb_inference_service.h"
namespace Core {
    class RecallOfflineItemEmbInferenceService : public RecallItemEmbInferenceService {
    private:
    public:
        RecallOfflineItemEmbInferenceService() = default;

        ~RecallOfflineItemEmbInferenceService() {
        }
        void parallel_extract_execute(std::vector<EmbExtractorArgs> &args_vec) override;

    public:
        static common::lockfree_threadpool::Executor offline_item_embedding_fe_executor;
        static constexpr bool use_bthread_pool = false;
        static constexpr size_t common_thread_pool_size = use_bthread_pool ? 0 : 1;
    };

}// namespace Core
