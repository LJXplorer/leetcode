#pragma once
#include "core/core_services/base_service/service_info.h"

namespace Core {
    class RecallOfflineItemEmbDoneService : public ServiceBaseInfo {
    public:
        RecallOfflineItemEmbDoneService() = default;
        virtual void initialize(GraphContextPtr context);
        virtual ~RecallOfflineItemEmbDoneService() {};
        int do_service(GraphContextPtr context) override;
    };

}// namespace Core