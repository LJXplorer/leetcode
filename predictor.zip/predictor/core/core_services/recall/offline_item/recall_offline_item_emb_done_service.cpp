#include "recall_offline_item_emb_done_service.h"
#include "core/core_context/item_embedding_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/recall/dict/emb_info_dict_manager.h"
#include "core/utils/defs.h"
#include "core/utils/error.h"
#include <boost/algorithm/string.hpp>
#include <json2pb/pb_to_json.h>
#include <log_helper.h>
#include <string>
namespace Core {
    SERVICE_REGISTER(RecallOfflineItemEmbDoneService);
    void RecallOfflineItemEmbDoneService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<ItemEmbeddingContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
    }

    int RecallOfflineItemEmbDoneService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<ItemEmbeddingContext>(context);
        BizLatency *lat = get_node_stat(ctx)->get_lat();

        auto& model_name = ctx->GetRealItemModelName();
        auto model_version = ctx->getItemEmbeddingVersion();
        {
            BizLatencyGaurd lat_guard(lat,LAT_STAGE_CREATE);
            MonitorMgr::common_report_model(ctx->GetItemEmbeddingModelName(), ctx->GetUploadSlotName(), std::to_string(ctx->GetAlgoSceneId()), STRING_DEFAULT, 0, "offline_emb_req_num", 1);
            if (ctx->_embedding_size == 0) {
                HILOG_APP(ERROR) << LOG_HEAD(ctx) << "offline_item_emb embedding size is [0], dict not updated";
                EmbInfoDictManager::taskRunning.fetch_sub(1);
                return ERROR_EMBEDDING_SHAPE;
            }
            if (ctx->_response_code != 200) {
                EmbInfoDictManager::taskRunning.fetch_sub(1);
                HILOG_APP(ERROR) << LOG_HEAD(ctx) << "offline_item_emb response code not 200, skip done";
                return ctx->_response_code;
            }
            const auto& emb_resp = ctx->GetItemEmbeddingResponse();
            auto& item_emb_info_map = ctx->_offline_item_emb_info_map;

            for (const auto& item_emb_res : emb_resp.itemembeddings()) {
                auto it = item_emb_info_map.find(item_emb_res.crid());
                if (it != item_emb_info_map.end()) {
                    it->second->mutable_embedding()->CopyFrom(item_emb_res.embedding());
                }
            }

            ctx->MutableEmbeddingInfoData()->set_dim(ctx->_embedding_size);
        }
        {
            BizLatencyGaurd lat_guard(lat,LAT_STAGE_DESTROY);
            std::string output_model_path = ctx->_offline_ad_embedding_info_path + ctx->GetItemEmbeddingModelName() + "/";
            
            // 更新embedding
            int ret1 = EmbInfoDictManager::GetInstance().writeEmbedding(output_model_path + std::to_string(model_version) + "/", ctx->GetEmbeddingInfoData());

            // 更新version
            int ret2 = EmbInfoDictManager::GetInstance().updateVersion(output_model_path, std::to_string(model_version));

            if (!ret1 && !ret2) {
                // HILOG_APP(ERROR) << "offline embedding success: " << fe_config->_model_name;
                MonitorMgr::common_report_model(ctx->GetItemEmbeddingModelName(), ctx->GetUploadSlotName(), std::to_string(ctx->GetAlgoSceneId()), STRING_DEFAULT,  0, "offline_emb_success_num", 1);
            }

            // todo 上线前删除
            // debug::file::WriteToFile(ctx->GetItemEmbeddingModelName() + "_" + model_name +
            //                                     "_" + "offline_embedding_info_data.json",
            //                             debug::printer::ToJsonObject(ctx->GetEmbeddingInfoData()).dump());

            HILOG_APP(INFO) << "vector_recall_offline_item_emb_run end ";
            EmbInfoDictManager::taskRunning.fetch_sub(1);
        }
        return ERROR_SUCCESS;
    }
}// namespace Core