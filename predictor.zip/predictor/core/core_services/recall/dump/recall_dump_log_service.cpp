#include "recall_dump_log_service.h"
#include "butil/third_party/rapidjson/document.h"
#include "butil/third_party/rapidjson/stringbuffer.h"
#include "butil/third_party/rapidjson/writer.h"
#include "common/hikafka/kafka_helper.h"
#include "common/hilog/log_helper.h"
#include "common/monitor/monitor_logger.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/item_embedding_context.h"
#include "core/core_context/monitor_context.h"
#include "core/core_context/user_embedding_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/dump/dump_log_manager/dump_log_manager.h"
#include "core/core_services/dump/dump_manager/dump_manager.h"
#include "core/core_services/predict/utils/model_version.h"
#include "core/core_services/predict/predict_service.h"
#include "core/utils/monitor_mgr.h"
#include "third_party/protobuf/include/google/protobuf/util/json_util.h"
#include "util/base64.h"
#include "util/str.h"
#include <boost/algorithm/hex.hpp>
#include <boost/algorithm/string.hpp>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <thread_pool.h>
#include <vector>

namespace Core {
    DECLARE_string(az_info);
    SERVICE_REGISTER(RecallDumpLogService);
    bvar::LatencyRecorder g_recall_dump_verify_qps{"recall_dump_log", "verify_qps"};
    void RecallDumpLogService::initialize(ConfigXmlPtr xml) {
        xml->attr<int>("sample_req_res_ratio", _sample_req_res_ratio);
        xml->attr<std::string>("dump_req_res_kafka", _dump_req_res_kafka, "false");
        xml->attr<int>("sample_ex_req_ratio", _sample_ex_req_ratio);
        xml->attr<std::string>("dump_ex_req_kafka", _dump_ex_req_kafka, "false");
        xml->attr<std::string>("dump_verify_kafka_name", _dump_verify_kafka_name);
        xml->attr<std::string>("dump_verify_kafka_key", _dump_verify_kafka_key);
        xml->attr<int>("sample_verify_ratio", _sample_verify_ratio, 0);
        xml->attr("max_sample_qps", _max_sample_qps, 0);
        initialize_xml(xml);
    }

    void RecallDumpLogService::initialize_xml(ConfigXmlPtr xml) {
    }

    void RecallDumpLogService::initialize(GraphContextPtr context) {
        // auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        // ctx->get_monitor_context()->alloc_node(get_name(),get_predict_type());
        // ctx->get_monitor_context()->alloc_node(get_name());
    }

    int RecallDumpLogService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int32_t ret = 0;
        try {
            DumpLogArgs *dump_arg = new DumpLogArgs();
            dump_arg->_dump_type = DUMP_LOG_LOG;
            dump_arg->_ctx = ctx;
            dump_arg->_service = this;
            if (ServerConfig::_dump_monitor_enable) {
                DumpLogManager::dump_log_counter << 1;
            }

            DumpLogManager::instance().push_dump_log_to_queue(dump_arg);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << "dump log task submit to exector fail: " << ret << ","
                             << e.what();
        }
        return ret;
    }

    int RecallDumpLogService::process(CoreContextPtr context) {
        try {
            dump_log(context);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << "do recall dump log service fail: " << e.what();
        }

        return ERROR_SUCCESS;
    }

    std::string RecallDumpLogService::get_current_time() {
        // 获取当前时间点
        auto now = std::chrono::system_clock::now();
        // 转换为time_t类型，以便使用std::put_time进行格式化
        auto now_c = std::chrono::system_clock::to_time_t(now);
        // 将time_t转换为tm结构体
        std::tm now_tm = *std::localtime(&now_c);

        // 使用stringstream进行格式化
        std::stringstream ss;
        ss << std::put_time(&now_tm, "%Y-%m-%d %H:%M:%S");
        return ss.str();
    }

    bool RecallDumpLogService::dump_user_log_sample(UserEmbeddingContextPtr context, int32_t message_type) {
        std::string result;
        const auto &user_req = context->GetUserEmbeddingRequest();
        const auto &user_res = context->GetUserEmbeddingResponse();
        const auto *rank_req = context->get_rank_request();
        const auto *fe_dump = context->get_fs_context()->feature_dump;
        static const std::string sep = "|";

        result.append(get_current_time());
        result.append(sep);
        result.append(ServerConfig::_monitor_service_name);
        result.append(sep);
        result.append("user");
        result.append(sep);
        result.append(user_req.reqid());
        result.append(sep);
        result.append(FLAGS_az_info);
        result.append(sep);
        result.append(std::to_string(message_type));
        result.append(sep);
        if (message_type == SAMPLE_DUMP_NORMAL_REQ_RES || message_type == SAMPLE_DUMP_EXCEPTION_REQ_RES) {
            std::string embRequestString;
            google::protobuf::util::MessageToJsonString(user_req, &embRequestString);
            result.append(embRequestString);
            result.append(sep);
            std::string rankRequestString;
            google::protobuf::util::MessageToJsonString(*rank_req, &rankRequestString);
            result.append(rankRequestString);
            result.append(sep);
            std::string responseString;
            google::protobuf::util::MessageToJsonString(user_res, &responseString);
            result.append(responseString);
            result.append(sep);
        } else if (message_type == SAMPLE_DUMP_FEATUREDUMP) {
            std::string feature_dump_string;
            google::protobuf::util::MessageToJsonString(*fe_dump, &feature_dump_string);
            result.append(feature_dump_string);
            result.append(sep);
        } else {
            result.append(sep);
        }
        result.append(std::to_string(context->get_predicttime()));
        result.append(sep);
        result.append(std::to_string(context->get_begin_time()));
        Util::Str::replace_all(result, "\r\n", "");

        if (user_req.debuglevel() == DebugLevel::kRecallDumpProto) {
            std::string file_name = "user_log_sample_" + std::to_string(message_type) + ".json";
            std::ofstream outFile(file_name);
            if (outFile.is_open()) {
                outFile << result;
                outFile.close();
            } else {
                std::cerr << "DEBUGLEVEL 30001 Failed to open file for writing log_sample.txt" << std::endl;
            }
        }

        monitor::details::MonitorLogger::getInstance().WriteToBigdataLogger(result);

        return true;
    }

    bool RecallDumpLogService::dump_item_log_sample(ItemEmbeddingContextPtr context, int32_t message_type) {
        std::string result;
        const auto &item_req = context->GetItemEmbeddingRequest();
        const auto &item_res = context->GetItemEmbeddingResponse();
        const auto *rank_req = context->get_rank_request();
        const auto *fe_dump = context->get_fs_context()->feature_dump;
        static const std::string sep = "|";

        result.append(get_current_time());
        result.append(sep);
        result.append(ServerConfig::_monitor_service_name);
        result.append(sep);
        result.append("item");
        result.append(sep);
        result.append(item_req.reqid());
        result.append(sep);
        result.append(FLAGS_az_info);
        result.append(sep);
        result.append(std::to_string(message_type));
        result.append(sep);
        if (message_type == SAMPLE_DUMP_NORMAL_REQ_RES || message_type == SAMPLE_DUMP_EXCEPTION_REQ_RES) {
            std::string embRequestString;
            google::protobuf::util::MessageToJsonString(item_req, &embRequestString);
            result.append(embRequestString);
            result.append(sep);
            std::string rankRequestString;
            google::protobuf::util::MessageToJsonString(*rank_req, &rankRequestString);
            result.append(rankRequestString);
            result.append(sep);
            std::string responseString;
            google::protobuf::util::MessageToJsonString(item_res, &responseString);
            result.append(responseString);
            result.append(sep);
        } else if (message_type == SAMPLE_DUMP_FEATUREDUMP) {
            std::string feature_dump_string;
            google::protobuf::util::MessageToJsonString(*fe_dump, &feature_dump_string);
            result.append(feature_dump_string);
            result.append(sep);
        } else {
            result.append(sep);
        }
        result.append(std::to_string(context->get_predicttime()));
        result.append(sep);
        result.append(std::to_string(context->get_begin_time()));
        Util::Str::replace_all(result, "\r\n", "");

        if (item_req.debuglevel() == DebugLevel::kRecallDumpProto) {
            std::string file_name = "item_log_sample_" + std::to_string(message_type) + ".json";
            std::ofstream outFile(file_name);
            if (outFile.is_open()) {
                outFile << result;
                outFile.close();
            } else {
                std::cerr << "DEBUGLEVEL 30001 Failed to open file for writing item_log_sample.txt" << std::endl;
            }
        }

        monitor::details::MonitorLogger::getInstance().WriteToBigdataLogger(result);

        return true;
    }

    int RecallDumpLogService::dump_log(CoreContextPtr context) {
        if (get_predict_type() == ExperimentModelType::ITEM_EMBEDDING) {
            auto ctx = std::dynamic_pointer_cast<ItemEmbeddingContext>(context);
            const auto &emb_req = ctx->GetItemEmbeddingRequest();
            bool is_ex_req = (ctx->_response_code != 200);
            // item校验点 全量上报
            dump_item_log_verify(ctx);
            if (!is_ex_req && is_req_res_sample(emb_req.reqid())) {
                dump_item_log_sample(ctx, SAMPLE_DUMP_NORMAL_REQ_RES);
            }
            if (is_ex_req && is_ex_req_sample(emb_req.reqid())) {
                dump_item_log_sample(ctx, SAMPLE_DUMP_EXCEPTION_REQ_RES);
            }
        } else if (get_predict_type() == ExperimentModelType::USER_EMBEDDING) {
            auto ctx = std::dynamic_pointer_cast<UserEmbeddingContext>(context);
            const auto &emb_req = ctx->GetUserEmbeddingRequest();
            bool is_ex_req = (ctx->_response_code != 200);
            // user校验点 采样上报
            if (is_verify_sample(context)) {
                g_recall_dump_verify_qps << 1;
                if (g_recall_dump_verify_qps.qps() < _max_sample_qps) {
                    dump_user_log_verify(ctx);
                }
            }
            if (!is_ex_req && is_req_res_sample(emb_req.reqid())) {
                dump_user_log_sample(ctx, SAMPLE_DUMP_NORMAL_REQ_RES);
            }
            if (is_ex_req && is_ex_req_sample(emb_req.reqid())) {
                dump_user_log_sample(ctx, SAMPLE_DUMP_EXCEPTION_REQ_RES);
            }
        }
        return ERROR_SUCCESS;
    }

    bool RecallDumpLogService::dump_item_log_verify(ItemEmbeddingContextPtr context) {
        try {
            const phx::PredictorRequest *rank_req = context->get_rank_request(); 
            const phx::FeRequest *fe_dump = context->get_fs_context()->get_feature_dump();
            // ::phx::SampleDumpInfo log_info;
            // log_info.mutable_dumptime()->assign(get_current_time());
            // log_info.mutable_service()->assign(ServerConfig::_monitor_service_name);
            // log_info.set_scenetype(rank_req->predictorslotinfo().scenetype());
            // log_info.mutable_algotraceid()->assign("recall_item");
            // log_info.set_slotid(rank_req->predictorslotinfo().slotid());
            // log_info.mutable_reqid()->assign(rank_req->reqid());
            // log_info.mutable_oaid()->assign(rank_req->oaid());
            // log_info.set_route(rank_req->predictorslotinfo().route());
            // log_info.mutable_az()->assign(FLAGS_az_info);
            // std::string sample_message_str = "";
            // log_info.mutable_dumpdata()->assign(sample_message_str);
            // log_info.set_costtime(context->get_end_time() - context->get_begin_time());
            // log_info.set_msgtype(SAMPLE_DUMP_VERIFY);

            const std::string &model_name = context->GetRealItemModelName();
            // log_info.mutable_reqid()->assign(model_name);
            auto model_info = Info::ModelInfoManager::instance().get_model_info(model_name);                    
            if (model_info != nullptr && model_info->_model_dict_collector != nullptr) {
                for (const auto &[index, items]: context->_item_embedding_map) {
                    auto &exctractor_response = context->_item_embedding_fe_response_map[index];
                    ::phx::VerifyInfoSample verify_info;
                    verify_info.mutable_fe_request()->CopyFrom(*fe_dump);
                    verify_info.mutable_fe_request()->clear_item_fea();
                    for(const auto& item : items) {
                        auto item_fea = context->get_fs_context()->alloc_item_fea(item.item->creativeid(), false);
                        phx::ItemFeature *verify_item = verify_info.mutable_fe_request()->add_item_fea();
                        if (item_fea != nullptr) {
                            verify_item->CopyFrom(*item_fea);
                        }
                        ::phx::ScoreInfo* score_info = verify_info.mutable_score()->Add();
                        score_info->mutable_item_embedding()->CopyFrom(item.ad_embedding->embedding());
                    }
                    // todo 后续可以删除
                    verify_info.mutable_item_ids()->CopyFrom(verify_info.fe_request().item_fea());
                    //dict
                    for (const auto &[name, path]: model_info->_model_dict_collector->_dict_name2path_map) {
                        auto dict = verify_info.add_dicts();
                        dict->set_name(name);
                        dict->set_path(path);
                        auto dict_info = model_info->_model_dict_collector->get_dict(name);
                        dict->set_version(dict_info->m_task_info.version);
                    }
                    //model
                    verify_info.mutable_models()->mutable_model_name()->assign(model_name);                    
                    verify_info.mutable_models()->mutable_fe_config_path()->assign(model_info->_model_config_path);
                    verify_info.mutable_models()->mutable_fe_config_md5()->assign(model_info->_fe_config_content_md5);
                    verify_info.mutable_models()->mutable_model_version()->assign(std::to_string(context->getItemEmbeddingVersion()));
                    //extractor
                    verify_info.mutable_extractor_result()->CopyFrom(*exctractor_response);                       
                    
                    if (rank_req->debuglevel() == DebugLevel::kRecallDumpProto || (ServerConfig::_app_log_level < 2 && context->_is_offline_emb_task)) {
                        std::string file_name = "verify_info_" + std::to_string(SAMPLE_DUMP_VERIFY) + "_item_emb_" + std::to_string(gettimeofday_us()) + ".json";
                        debug::pb::SavePbToFile(file_name, verify_info);
                    }
                    hikafka::KafkaMessage *kafkaMessage = new hikafka::KafkaMessage();
                    verify_info.SerializeToString(&kafkaMessage->value);
                    HILOG_APP(INFO) << "item verify_info dump size" << kafkaMessage->value.size() << endl;
                    if (hikafka::KafkaHelper::getInstance().sendMsg(_dump_verify_kafka_name, kafkaMessage) == false) {
                        HILOG_APP(ERROR) << "kafka input queue fail " << _dump_verify_kafka_name;
                        delete kafkaMessage;
                    }
                }
            }                
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "Something wrong in verify item embedding log dump,  " << e.what();
            return false;
        }

        return true;
    }

    bool RecallDumpLogService::dump_user_log_verify(UserEmbeddingContextPtr context) {
        try {
            const phx::PredictorRequest *rank_req = context->get_rank_request(); 
            const phx::FeRequest *fe_dump = context->get_fs_context()->get_feature_dump();
            // ::phx::SampleDumpInfo log_info;
            // log_info.mutable_dumptime()->assign(get_current_time());
            // log_info.mutable_service()->assign(ServerConfig::_monitor_service_name);
            // log_info.set_scenetype(rank_req->predictorslotinfo().scenetype());
            // log_info.mutable_algotraceid()->assign("recall_user");
            // log_info.set_slotid(rank_req->predictorslotinfo().slotid());
            // log_info.mutable_reqid()->assign(rank_req->reqid());
            // log_info.mutable_oaid()->assign(rank_req->oaid());
            // log_info.set_route(rank_req->predictorslotinfo().route());
            // log_info.mutable_az()->assign(FLAGS_az_info);
            // std::string sample_message_str = "";
            // log_info.mutable_dumpdata()->assign(sample_message_str);
            // log_info.set_costtime(context->get_end_time() - context->get_begin_time());
            // log_info.set_msgtype(SAMPLE_DUMP_VERIFY);

            // std::vector<std::string> dump_data;
            ::phx::VerifyInfoSample verify_info;
            std::string model_name = context->GetRealUserModelName();
            auto model_info = Info::ModelInfoManager::instance().get_model_info(model_name);
            if (model_info != nullptr && model_info->_model_dict_collector != nullptr) {
                //dict
                for (const auto &[name, path]: model_info->_model_dict_collector->_dict_name2path_map) {
                    auto dict = verify_info.add_dicts();
                    dict->set_name(name);
                    dict->set_path(path);
                    auto dict_info = model_info->_model_dict_collector->get_dict(name);
                    dict->set_version(dict_info->m_task_info.version);
                }
                //model
                verify_info.mutable_models()->mutable_model_name()->assign(model_name);                    
                verify_info.mutable_models()->mutable_fe_config_path()->assign(model_info->_model_config_path);
                verify_info.mutable_models()->mutable_fe_config_md5()->assign(model_info->_fe_config_content_md5);
                verify_info.mutable_models()->mutable_model_version()->assign(std::to_string(context->GetUserEmbeddingVersion()));
                
                //fe_request
                verify_info.mutable_fe_request()->CopyFrom(*fe_dump);
                verify_info.mutable_item_ids()->CopyFrom(fe_dump->item_fea());
                
                //extractor response
                auto user_extractor_response = context->_user_extractor_response;
                if (user_extractor_response != nullptr) {
                    verify_info.mutable_extractor_result()->CopyFrom(*user_extractor_response);
                }
                
                //user_embedding
                verify_info.mutable_user_embedding()->CopyFrom(context->GetUserEmbeddingResponse().userembedding());
                                
                if (rank_req->debuglevel() == DebugLevel::kRecallDumpProto) {
                    std::string file_name = "verify_info_" + std::to_string(SAMPLE_DUMP_VERIFY) + "_user_emb_" + std::to_string(gettimeofday_us()) + ".json";
                    debug::pb::SavePbToFile(file_name, verify_info);
                }
                hikafka::KafkaMessage *kafkaMessage = new hikafka::KafkaMessage();
                verify_info.SerializeToString(&kafkaMessage->value);
                HILOG_APP(INFO) << "user verify_info size" << kafkaMessage->value.size() << endl;
                if (hikafka::KafkaHelper::getInstance().sendMsg(_dump_verify_kafka_name, kafkaMessage) == false) {
                    HILOG_APP(ERROR) << "kafka input queue fail " << _dump_verify_kafka_name;
                    delete kafkaMessage;
                }
            }             
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "Something wrong in verify user embedding log dump,  " << e.what();
            return false;
        }

        return true;
    }
}// namespace Core
