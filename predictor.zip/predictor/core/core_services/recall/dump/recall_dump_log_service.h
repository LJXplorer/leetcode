#pragma once
#include "core/core_context/user_embedding_context.h"
#include "hlframe/node.h"
#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"
#include <cstdint>

namespace Core {
    class RecallDumpLogService : public ServiceBaseInfo {
    private:

        //日志采样上报
        int32_t _sample_req_res_ratio = 1; // request、response采样上报比例
        int32_t _sample_ex_req_ratio = 1; // 异常请求采样上报比例
        int32_t _sample_verify_ratio = 0; //校验点采样上报比例
        std::string _dump_req_res_kafka = "false";
        std::string _dump_ex_req_kafka = "false";
        std::string _dump_verify_kafka_name = "sample_verify_dump";
        std::string _dump_verify_kafka_key = "sample_verify_dump";
        int32_t _max_sample_qps = 10000;

        // hash
        int32_t _RECALL_SAMPLE_BASE = 1000;
        int32_t _SEED = 0x7f3a21eaL;        
        int32_t _ONE_HUNDRED = 100; // 采样的基数，100为百分比
        int32_t _VERIFY_SAMPLE_BASE = 10000;
   
    public:
        RecallDumpLogService(){
        }

        ~RecallDumpLogService(){

        }

        virtual void initialize(ConfigXmlPtr xml);
        virtual void initialize_xml(ConfigXmlPtr xml);
        virtual void initialize(GraphContextPtr context);
        virtual int do_service(GraphContextPtr context);
    private:
        virtual  int process(CoreContextPtr context) override;
        std::string get_current_time();

    public:
        virtual int dump_log(CoreContextPtr context);
        bool dump_user_log_sample(UserEmbeddingContextPtr context, int32_t message_type);
        bool dump_item_log_sample(ItemEmbeddingContextPtr context, int32_t message_type);

        // 校验点上报
        bool dump_item_log_verify(ItemEmbeddingContextPtr context);
        bool dump_user_log_verify(UserEmbeddingContextPtr context);

        int32_t get_hash(const std::string& salt_str) {
            uint32_t out;
            butil::MurmurHash3_x86_32(salt_str.c_str(), salt_str.length(), _SEED, &out);
            return  out % _ONE_HUNDRED;
        }

        bool is_req_res_sample(const std::string& req_id) {
            int32_t hash_res = get_hash(req_id);
            return hash_res < _sample_req_res_ratio;
        }

        bool is_ex_req_sample(const std::string& req_id) {
            int32_t hash_res = get_hash(req_id);
            return hash_res < _sample_ex_req_ratio;
        }

        int32_t get_verify_hash(const std::string& salt_str) {
            uint32_t out;
            butil::MurmurHash3_x86_32(salt_str.c_str(), salt_str.length(), _SEED, &out);
            return  out % _VERIFY_SAMPLE_BASE;
        }

        bool is_verify_sample(const CoreContextPtr &context) {
            int32_t hash_res = get_verify_hash(context->get_req_id());
            return hash_res < _sample_verify_ratio;
        }

    };
    
}
