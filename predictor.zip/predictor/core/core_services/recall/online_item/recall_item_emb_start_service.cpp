#include "recall_item_emb_start_service.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/item_embedding_context.h"
#include "core/core_services/predict/utils/model_version.h"
#include "core/utils/error.h"
#include "hlframe/context.h"
#include "phx-fe/ad_dict/ad_dict_manager.h"
#include "phx-fe/ad_dict/packagename2appid_dict.h"
#include <cstdint>
#include <exception>
#include <log_helper.h>
#include <memory>
#include <string>
namespace Core {
    SERVICE_REGISTER(RecallItemEmbStartService);

    void RecallItemEmbStartService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<ItemEmbeddingContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
    }

    void RecallItemEmbStartService::initialize(ConfigXmlPtr xml) {
        xml->attr<std::string>("dict_name", _dict_name);
        xml->attr<int32_t>("split_size", _split_size);
    }

    int RecallItemEmbStartService::do_service(GraphContextPtr context) {
        HILOG_APP(INFO) << "=====================phx RecallItemEmbStartService::do_service  start====================================";
        auto ctx = std::dynamic_pointer_cast<ItemEmbeddingContext>(context);
        int32_t ret = 0;
        try {
            ctx->gen_log_head();
            ret = process(ctx);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << "phx do service fail: " << ret << "," << e.what();
        }
        HILOG_APP(INFO) << "=====================phx RecallItemEmbStartService::do_service  end====================================";
        return ret;
    }

    int32_t RecallItemEmbStartService::process(ItemEmbeddingContextPtr context) {
        BizLatency *lat = get_node_stat(context)->get_lat();
        const std::string &real_model_name = context->GetRealItemModelName();
        {
            BizLatencyGaurd lat_guard(lat,LAT_STAGE_CREATE);
            context->_item_emb_model_info = Info::ModelInfoManager::instance().get_model_info(real_model_name);
            if (context->_item_emb_model_info == nullptr) {
                HILOG_APP(ERROR) << LOG_HEAD(context) << "item model info null ";
                MonitorMgr::common_report_model(context->GetItemEmbeddingModelName(), "0",
                                                    std::to_string(context->GetAlgoSceneId()), "default", -1,
                                                    "model_not_found", 1);
                context->_response_code = ERROR_EMBEDDING_ITEM_MODEL_CONFIG_NULL;
                return ERROR_EMBEDDING_ITEM_MODEL_CONFIG_NULL;
            }
            auto [cur_version, bak_version] = ModelVersion::instance().get_available_model_versions(real_model_name);

            const int32_t requested_version = context->getItemEmbeddingVersion();
            
            if (cur_version > 0) {
                context->MutableItemEmbeddingResponse()->mutable_supporteditemembeddingversion()->Add(cur_version);
            }
            if (bak_version > 0) {
                context->MutableItemEmbeddingResponse()->mutable_supporteditemembeddingversion()->Add(bak_version);
            }
            if (requested_version != cur_version && requested_version != bak_version) {
                HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << " not available: [" << real_model_name
                                << "], mode_type:item embedding; reqeusted version = [" << requested_version
                                << "]; cur version = [" << cur_version << "]; bak_version = [" << bak_version << "]";
                MonitorMgr::common_report_model(context->GetItemEmbeddingModelName(), "0",
                                                    std::to_string(context->GetAlgoSceneId()), "default", -1,
                                                    "version_not_found", 1);
                context->_response_code = ERROR_EMBEDDING_ITEM_MODEL_CONFIG_NULL;
                return ERROR_EMBEDDING_ITEM_MODEL_CONFIG_NULL;
            }
            context->MutableItemEmbeddingResponse()->set_useditemembeddingversion(requested_version);
        }

        {
            BizLatencyGaurd lat_guard(lat,LAT_STAGE_DESTROY);
            const auto &embedding_request = context->GetItemEmbeddingRequest();
            const auto &ad_infos = embedding_request.adinfos();
            const auto &ad_infos_size = ad_infos.size();
            if (ad_infos_size == 0) {
                if (embedding_request.embeddingtype() == qinglongv2::ITEM_EMBEDDING) {
                    HILOG_APP(ERROR) << "ad_info is empty, can not do item embedding service! req id = "
                                    << embedding_request.reqid();
                    context->_response_code = ERROR_BIZ_PROTO_ADS_EMPTY;
                    return ERROR_BIZ_PROTO_ADS_EMPTY;
                }
                return ERROR_SUCCESS;
            }

            int32_t convert_ret = convert2RankRequest(context);
            if (convert_ret != ERROR_SUCCESS) {
                return convert_ret;
            }

            auto rank_req = context->get_rank_request();
            if (rank_req->predictorslotinfo().predictoriteminfos_size() == 0) {
                context->_response_code = ERROR_BIZ_PROTO_ADS_EMPTY;
                HILOG_APP(ERROR) << LOG_HEAD(context) << "predictoriteminfo is empty after convert2RankRequest, can not do item embedding service!";
                return ERROR_BIZ_PROTO_ADS_EMPTY;
            }
            report(context, "req_item",rank_req->predictorslotinfo().predictoriteminfos_size());

            if (rank_req->debuglevel() == DebugLevel::kRecallDumpProto) {
                debug::pb::SavePbToFile(rank_req->reqid() + "_item_convert2rank_request.json", *rank_req);
            }

            auto fs_ctx = context->get_fs_context();
            // 填充req_id
            fs_ctx->get_feature_dump()->mutable_req_id()->assign(context->get_req_id());
            fs_ctx->get_feature_dump()->set_req_time(context->get_begin_time());
            //填上下文特征
            auto feature_dump = fs_ctx->get_feature_dump();
            feature_dump->mutable_req_id()->assign(context->get_req_id());
            feature_dump->set_req_time(context->get_begin_time());
            feature_dump->mutable_context()->mutable_oaid()->assign(context->get_oaid());
        }
        return ERROR_SUCCESS;
    }


    int32_t RecallItemEmbStartService::convert2RankRequest(ItemEmbeddingContextPtr context) {
        auto dict_iter = AdDict::AdDictCollectorInstance::instance().get_dict(_dict_name);
        if (dict_iter == nullptr) {
             HILOG_APP(ERROR) << "Failed to get PackageName2AppIdInfoDict dictInfo, dict:" << _dict_name;
             context->_response_code = ERROR_EMBEDDING_DICT_NOT_FIND;
             return ERROR_EMBEDDING_DICT_NOT_FIND;
        }
        auto pkg2appid_map = dict_iter->get_data<AdDict::package_name_2_app_id_type>();
        if (pkg2appid_map == nullptr) {
            HILOG_APP(ERROR) << "Failed to get pkg2appid_map from dict, dict:" << _dict_name;
            context->_response_code = ERROR_EMBEDDING_DICT_NOT_FIND;
            return ERROR_EMBEDDING_DICT_NOT_FIND;
        }
        const auto &item_emb_req = context->GetItemEmbeddingRequest();
        auto mutable_rank_req = context->get_mutable_rank_request();
        mutable_rank_req->set_reqid(item_emb_req.reqid());
        mutable_rank_req->set_oaid(item_emb_req.oaid());
        mutable_rank_req->set_debuglevel(item_emb_req.debuglevel());
        mutable_rank_req->mutable_predictorslotinfo()->set_predicttimestamp(context->get_begin_time());
        mutable_rank_req->mutable_predictorslotinfo()->set_algosceneid(static_cast<int32_t>(Info::ModelType::ITEM_EMBEDDING));
        int32_t item_crid_cnt = 0;
        int32_t app_not_found_cnt = 0;
        std::unordered_set<int64_t> check_set;
        int32_t chunk_index = 0;
        std::vector<EmbItemWrapper> chunk;
        // std::unordered_set<std::string> pkg_total_set;
        // std::unordered_set<std::string> pkg_not_find_set;
        auto *item_embeddings = context->MutableItemEmbeddingResponse()->mutable_itemembeddings();
        for (const auto &ad_info : item_emb_req.adinfos()) {
            int64_t creativeid = 0L;
            if (!safe_string_to_num(ad_info.crid(), creativeid)) {
                HILOG_APP(ERROR) << LOG_HEAD(context) << "failed to convert ad_info.crid() to int64 type, ad_info.crid(): " << ad_info.crid();
                continue;
            }
            int64_t adgroupid = 0L;
            if (!ad_info.adgroupid().empty() && !safe_string_to_num(ad_info.adgroupid(), adgroupid)) {
                HILOG_APP(ERROR) << LOG_HEAD(context) << "failed to convert ad_info.adgroupid() to int64 type, ad_info.adgroupid(): " << ad_info.adgroupid();
                continue;
            }
            int32_t convgoal = 0;
            if (!ad_info.convgoal().empty() && !safe_string_to_num(ad_info.convgoal(), convgoal)) {
                HILOG_APP(ERROR) << LOG_HEAD(context) << "failed to convert ad_info.convgoal() to int32 type, ad_info.convgoal(): " << ad_info.convgoal();
                continue;
            }
            int32_t rtaurlid = 0;
            if (!ad_info.itemfeature().rtaurlid().empty() && !safe_string_to_num(ad_info.itemfeature().rtaurlid(), rtaurlid)) {
                HILOG_APP(ERROR) << LOG_HEAD(context) << "failed to convert ad_info.itemfeature().rtaurlid() to int32 type, ad_info.itemfeature().rtaurlid(): " << ad_info.itemfeature().rtaurlid();
                continue;
            }

            auto result = check_set.insert(creativeid);
            if(!result.second) {
                HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << " repeated materialID in request!";
                continue;
            }

            item_crid_cnt++;
            // pkg_total_set.insert(ad_info.itemfeature().adcreativepkgname());
            auto *add_item =  mutable_rank_req->mutable_predictorslotinfo()->add_predictoriteminfos();
            add_item->set_creativeid(creativeid);
            add_item->set_adgroupid(adgroupid);
            // 填充其他需要字段
            add_item->set_convgoal(convgoal);
            BillingMode billingmode = stringToBillingMode(ad_info.billingmode());
            if (billingmode != BillingMode::UNKNOWN) {
                add_item->set_billingmode(billingmode);
            }
            add_item->set_convtype(ad_info.convtype());
            add_item->set_deepconvtype(ad_info.deepconvtype());
            add_item->set_enhanceconvtype(ad_info.enhanceconvtype());
            add_item->set_bid(ad_info.bid());
            add_item->set_ocpxsbp(ad_info.ocpxsbp());
            add_item->set_rtaid(ad_info.itemfeature().rtaid());
            add_item->set_rtaurlid(rtaurlid);
            
            auto appid_iter = pkg2appid_map->find(ad_info.itemfeature().adcreativepkgname());
            if (appid_iter != pkg2appid_map->end()) {
                 add_item->set_appid(appid_iter->second->app_id());
            } else if (!ad_info.itemfeature().adcreativepkgname().empty()) {
                // todo report
                HILOG_APP(WARNING) << "Cannot find appid from package name, package name: " << ad_info.itemfeature().adcreativepkgname();
                // pkg_not_find_set.insert(ad_info.itemfeature().adcreativepkgname());
                app_not_found_cnt++;
            }
            
            context->get_fs_context()->alloc_item_fea(add_item->creativeid());
            context->get_fs_context()->alloc_app_fea(add_item->appid());
            auto *item_embedding = item_embeddings->Add();
            item_embedding->mutable_crid()->assign(ad_info.crid());
            EmbItemWrapper emb_item_wrapper(add_item, &ad_info, item_embedding);
            chunk.push_back(emb_item_wrapper);
            if (chunk.size() == static_cast<size_t>(_split_size)) {
                context->_item_embedding_map[chunk_index] = std::move(chunk);
                chunk_index++;// 增加分片索引
                chunk.clear();// 清空当前分包
            }
        }
        if (!chunk.empty()) {
            context->_item_embedding_map[chunk_index] = std::move(chunk);
        }
        if (item_crid_cnt != 0) {
            HILOG_APP(INFO) << "pkg not find appid rate: " << app_not_found_cnt << "/" << item_crid_cnt << "=" << 1.0 * app_not_found_cnt / item_crid_cnt;
        }
        // if (!pkg_total_set.empty()) {
        //     HILOG_APP(ERROR) << "[pkg dim] not find appid rate: " << 1.0 * pkg_not_find_set.size() / pkg_total_set.size();
        // }
        return ERROR_SUCCESS;
    }
}// namespace Core