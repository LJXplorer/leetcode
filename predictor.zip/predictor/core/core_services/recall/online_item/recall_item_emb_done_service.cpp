#include "recall_item_emb_done_service.h"
#include "core/utils/error.h"
#include <log_helper.h>
#include <wrapper_time.h>
namespace Core {
    SERVICE_REGISTER(RecallItemEmbDoneService);
    void RecallItemEmbDoneService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<ItemEmbeddingContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
    }

    int RecallItemEmbDoneService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<ItemEmbeddingContext>(context);
        int32_t ret = 0;
        BizLatency* lat = get_node_stat(ctx)->get_lat();
        {
            BizLatencyGaurd lat_guard(lat,LAT_STAGE_CREATE);
            try {
                ret = assembly_response(ctx);
            } catch (const std::exception &e) {
                HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name()
                    << "do service assembly_response fail: " << ret << "," << e.what();
            }
        }
        {
            BizLatencyGaurd lat_guard(lat,LAT_STAGE_DESTROY);
            ctx->_end_ts = gettimeofday_ms();
            monitor::MonitorManager::getInstance().InterfaceSvrSuccess(ctx->get_begin_time(), "/itemEmbeddingService", ctx->get_req_id(),
            std::to_string(ctx->_response_code),
            "", "", 0, "",
            std::to_string(ctx->GetItemEmbeddingRequest().adinfos_size()));
            ctx->get_request_context()->done();
        }
        return ERROR_SUCCESS;
    }

    int RecallItemEmbDoneService::assembly_response(ItemEmbeddingContextPtr context) {
        auto& emb_resp = *context->MutableItemEmbeddingResponse();
        emb_resp.set_code(context->_response_code);
        emb_resp.set_reqid(context->GetItemEmbeddingRequest().reqid());
        context->GetRawResponse()->CopyFrom(emb_resp);
        return ERROR_SUCCESS;
    }
}// namespace Core