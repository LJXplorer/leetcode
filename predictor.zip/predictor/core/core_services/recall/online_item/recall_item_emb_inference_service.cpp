#include "recall_item_emb_inference_service.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/item_embedding_context.h"
#include "core/core_services/predict/utils/ragged_tensor_util.h"
#include "core/utils/defs.h"
#include "core/utils/error.h"
#include "hlframe/context.h"
#include "phx-fe/src/framework.h"
#include <bthread/bthread.h>
#include <debug_utils.h>
#include <exception>
#include <google/protobuf/arena.h>
#include <latch.h>
#include <lockfree_threadpool.h>
#include <log_helper.h>
#include <memory>

namespace Core {
    SERVICE_REGISTER(RecallItemEmbInferenceService);
    common::lockfree_threadpool::Executor RecallItemEmbInferenceService::item_embedding_fe_executor =
            common::lockfree_threadpool::Executor(common_thread_pool_size, common_thread_pool_size * 2048, "recall_item_emb_fe_executor", 1000 * 100);
    phx::UserAction RecallItemEmbInferenceService::s_empty_user_action = {};

    bool RecallItemEmbInferenceService::skip(GraphContextPtr context) {
        auto embedding_context = dynamic_pointer_cast<ItemEmbeddingContext>(context);
        return (embedding_context->_response_code != 200);
    }

    void RecallItemEmbInferenceService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<ItemEmbeddingContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
    }
    int RecallItemEmbInferenceService::do_service(GraphContextPtr context) {
        auto embedding_context = dynamic_pointer_cast<ItemEmbeddingContext>(context);
        int64_t split_size = static_cast<int64_t>(embedding_context->_item_embedding_map.size());
        common::SimpleLatch latch{split_size};
        std::vector<EmbExtractorArgs> args_vec;
        args_vec.resize(split_size);
        size_t idx = 0;
        BizLatency *lat = get_node_stat(embedding_context)->get_lat();
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);
            for (const auto &[index, items]: embedding_context->_item_embedding_map) {
                HILOG_APP(INFO) << "femap size: " << items.size();
                auto *extractor_response =
                        google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(embedding_context->get_context_arena());

                embedding_context->_item_embedding_fe_response_map.insert({index, extractor_response});
                EmbExtractorArgs &arg = args_vec[idx];
                arg.extractor_result = embedding_context->_item_embedding_fe_response_map[index];
                arg.arena = embedding_context->get_context_arena();
                arg.context = embedding_context;
                arg.split_index = index;
                arg.fe_request = BuildFeRequest(embedding_context, items);
                arg.item_emb_model_info = embedding_context->_item_emb_model_info;
                arg.latch = &latch;
                idx++;
            }
        }
        {
            BizLatencyGaurd lat_guard_dst(lat, LAT_STAGE_DESTROY);
            parallel_extract_execute(args_vec);
            if (embedding_context->get_rank_request()->debuglevel() == DebugLevel::kRecallDumpEmb) {
                debug::pb::SavePbToFile("recall_item_fe_snapshot.json", *embedding_context->get_fs_context()->get_feature_dump());
            }
        }
        
        HILOG_APP(INFO)<< "fe result size: " << embedding_context->_item_embedding_fe_response_map.size() ;
        return ERROR_SUCCESS;
    }
    phx::FeRequest *RecallItemEmbInferenceService::BuildFeRequest(ItemEmbeddingContextPtr context,
                                                                     const std::vector<EmbItemWrapper> &items) {
        auto *fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(context->get_context_arena());
        auto fs_context = context->get_fs_context();
        for (const auto &item: items) {
            auto item_feature = fs_context->alloc_item_fea(item.item->creativeid(), false);
            if (unlikely(item_feature == nullptr)) {
                HILOG_APP(ERROR) << LOG_HEAD(context) << "item feature is null! creative_id = ["
                                 << item.item->creativeid() << "]";
                return nullptr;
            }
            fe_request->mutable_item_fea()->AddAllocated(item_feature);

            auto prerank_item_fea = fe_request->add_prerank_item_fea();
            prerank_item_fea->mutable_prerank_item_info()->set_appid(item.item->appid());
            prerank_item_fea->mutable_prerank_item_info()->set_creative_id(item.item->creativeid());
            prerank_item_fea->mutable_prerank_item_info()->set_billing_mode(item.item->billingmode());
            prerank_item_fea->mutable_prerank_item_info()->set_bid(item.item->bid());
            prerank_item_fea->mutable_prerank_item_info()->set_ocpx_sbp(item.item->ocpxsbp());
        }
        return fe_request;
    }

    void RecallItemEmbInferenceService::parallel_extract_execute(std::vector<EmbExtractorArgs> &args_vec) {
        if (args_vec.empty()) {
            HILOG_APP(ERROR) << "item embedding parallel_extract_execute has empty args_vec!";
            return;
        }
        if constexpr (!use_bthread_pool) {
            auto *latch = args_vec[0].latch;
            for (auto &args: args_vec) {
                common::lockfree_threadpool::TaskWrapper task_wrapper{};
                task_wrapper.args = (void *) (&args);
                task_wrapper.t = RecallItemEmbInferenceService::Extract;
                RecallItemEmbInferenceService::item_embedding_fe_executor.enqueue(task_wrapper);
            }
            latch->Wait();
        } else {
            for (auto &args: args_vec) {
                bthread_start_background(&args.tid, &BTHREAD_ATTR_SMALL, RecallItemEmbInferenceService::Extract, &args);
            }

            for (auto &args: args_vec) {
                bthread_join(args.tid, nullptr);
            }
        }
        // report
        long fe_start = std::numeric_limits<long>::max();
        long fe_end = 0L;

        for (auto &args: args_vec) {
            fe_start = std::min(fe_start, args.start);
            fe_end = std::max(fe_end, args.end);
        }

        auto &emb_name = args_vec[0].item_emb_model_info->_emb_name;
        auto &ctx = args_vec[0].context;
        MonitorMgr::percent_report_model(emb_name, ctx->GetUploadSlotName() ,std::to_string(ctx->get_algo_scene_id()),0, "model_total_fe_cost",  (fe_end - fe_start));
    }

    void *RecallItemEmbInferenceService::Extract(void *arg) {
        EmbExtractorArgs *fe_arg = (EmbExtractorArgs *) (arg);
        fe_arg->start = butil::gettimeofday_us();
        try {
            toExtractorResponse(fe_arg->arena, *(fe_arg->fe_request), s_empty_user_action,
                                fe_arg->item_emb_model_info->get_config_info(), *fe_arg->extractor_result, fe_arg->item_emb_model_info->_is_ltr);
            Predict(arg);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "fe extract failed! msg = " << e.what();
        } catch (...) {
            HILOG_APP(ERROR) << "fe extract failed! unknown exception";
        }
        fe_arg->end = butil::gettimeofday_us();
        MonitorMgr::percent_report_model(fe_arg->item_emb_model_info->_emb_name, fe_arg->context->GetUploadSlotName() , std::to_string(fe_arg->context->GetAlgoSceneId()),0, "single_fe_cost",  (fe_arg->end - fe_arg->start));
        fe_arg->latch->CountDown();
        return nullptr;
    }

    void *RecallItemEmbInferenceService::Predict(void *arg) {
        EmbExtractorArgs *fe_arg = (EmbExtractorArgs *) (arg);
        auto *arena = fe_arg->arena;
        auto *extractor_response = fe_arg->extractor_result;
        ItemEmbeddingContextPtr context = fe_arg->context;
        const std::string &model_name = context->GetRealItemModelName();
        if (extractor_response == nullptr ||
            extractor_response->item_features().size() == 0 ||
            extractor_response->item_cnt() == 0) {
            HILOG_APP(ERROR) << LOG_HEAD(context) << "Batch recall predict item_features.size() || item_num is 0";
            return nullptr;
        }
        if (extractor_response->item_features().size() % extractor_response->item_cnt() != 0) {
            HILOG_APP(ERROR) << LOG_HEAD(context) << "Batch recall predict something went wrong in FE, jump predict:" << model_name;
            return nullptr;
        }

        const size_t item_slot_num = extractor_response->item_features().size() / extractor_response->item_cnt();

        std::vector<SlotDataType> item_slot_data_types(item_slot_num, SlotDataType::UNKNOWN);
        get_item_slot_data_types(extractor_response, item_slot_num, item_slot_data_types);
        HILOG_APP(INFO) << "update_item_slot_data_types end";

        HILOG_APP(INFO) << "process user feature";
        //合并 item_features

        int32_t total_item = 0;
        HILOG_APP(INFO) << "start merging item";
        std::vector<SlotInfo> item_splited_batches = parse_item_list_item_embedding(
                extractor_response, item_slot_num, item_slot_data_types, total_item, context);
        HILOG_APP(INFO) << "end merging item";

        if (context->get_rank_request()->debuglevel() == DebugLevel::kRecallDumpEmb) {
            debug::file::WriteToFile("recall_item_" + model_name + "_" + std::to_string(fe_arg->split_index) + "_" + "item_splited_batches.txt", debug::printer::ToString(item_splited_batches));
        }

        //构造分包的Predict Request
        auto predict_request = google::protobuf::Arena::CreateMessage<::proto::flow::PredictRequest>(arena);
        ::proto::flow::ModelPredictRequest *model_request = predict_request->add_model_requests();
        model_request->set_model_name(model_name);
        model_request->set_model_version(context->getItemEmbeddingVersion());
        //处理 item特征
        // 对于每个分包请求 遍历其中的 item的slot_info
        for (const auto &item_slot_info: item_splited_batches) {
            auto *item_input = model_request->add_inputs();
            item_input->set_name(item_slot_info.slot_id);
            item_input->set_type(1);// 0表示user 1表示item

            //填充 item 特征到 inputs
            switch (item_slot_info.get_data_type()) {
                case SlotDataType::INT_64: {
                    ::proto::flow::RaggedTensorProto *rt(RaggedTensorUtil::FromValues(*item_slot_info.int_values));
                    item_input->set_allocated_values(rt);
                    break;
                }
                case SlotDataType::FLOAT: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(*item_slot_info.float_values));
                    item_input->set_allocated_values(rt);
                    break;
                }
                case SlotDataType::STRING: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(*item_slot_info.string_values));
                    item_input->set_allocated_values(rt);
                    break;
                }
                default: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(std::vector<std::vector<int64_t>>()));
                    item_input->set_allocated_values(rt);
                    break;
                }
            }
        }

        brpc::Channel *channel = context->_item_emb_model_info->get_channel();

        // 写 PredictRequest 到文件 predict_type + model_name + i + predictRequest.txt
        if (context->get_rank_request()->debuglevel() == DebugLevel::kRecallDumpEmb) {
            debug::pb::SavePbToFile("recall_item_" + model_name + "_" + std::to_string(fe_arg->split_index) + "_" + std::to_string(fe_arg->split_index) + "_predict_request.json", *predict_request);
        }

        ::proto::flow::PredicterService_Stub stub(channel);
        ::proto::flow::PredictResponse *predict_response =
                google::protobuf::Arena::CreateMessage<::proto::flow::PredictResponse>(arena);

        HILOG_APP(INFO) << "start_bthread ";

        process_prediction(context, channel, predict_request,
                        predict_response, context->_item_emb_model_info, fe_arg->split_index);

        HILOG_APP(INFO) << "model: " << model_name << "request end.";

        HILOG_APP(INFO) << model_name + "_" + "_PredictResponse: \n"
                        << debug::printer::ToString(*predict_response);
        if (context->get_rank_request()->debuglevel() == DebugLevel::kRecallDumpEmb) {
            debug::pb::SavePbToFile("recall_item_" + model_name + "_" + std::to_string(fe_arg->split_index) + "_predict_response.json", *predict_response);
        }

        return nullptr;
    }

    void RecallItemEmbInferenceService::get_item_slot_data_types(const phx::ExtractorResponse *extractor_responses, size_t slot_num, std::vector<SlotDataType> &item_slot_data_types) {
        // 处理 item 特征
        for (int slot_index = 0; slot_index < item_slot_data_types.size(); ++slot_index) {
            // for (const auto &extractor_response: extractor_responses) {
            auto& item_features = extractor_responses->item_features();
            int64_t item_num = extractor_responses->item_cnt();

            for (int j = 0; j < item_num; ++j) {
                auto feature = item_features.at(j + item_num * slot_index);//(slot_i,item_j)处的Feature
                if (feature.signs().size() > 0) {
                    // 这个特征是 int
                    item_slot_data_types[slot_index] = SlotDataType::INT_64;
                    break;
                } else if (feature.weights().size() > 0) {
                    // 这个特征是 float
                    item_slot_data_types[slot_index] = SlotDataType::FLOAT;
                    break;
                } else if (feature.bytes_list().size() > 0) {
                    // 这个特征是 string
                    item_slot_data_types[slot_index] = SlotDataType::STRING;
                    break;
                } else {
                    // 这个特征为空 继续遍历下一个直到 j = item_num -1
                    continue;
                }
            }
            // 获取下一个 slot_index 的 DATA_TYPE
        }
    }

    std::vector<SlotInfo> RecallItemEmbInferenceService::parse_item_list_item_embedding(
            const phx::ExtractorResponse *extractor_response, const size_t &item_slot_num,
            const std::vector<SlotDataType> &item_slot_data_types, int32_t &total_item, ItemEmbeddingContextPtr &context) {
        std::vector<SlotInfo> item_slot_list(item_slot_num);
        total_item += extractor_response->item_cnt();

        auto item_features = extractor_response->item_features();

        int64_t item_num = extractor_response->item_cnt();
        for (int i = 0; i < item_slot_num; ++i) {
            for (int j = 0; j < item_num; ++j) {
                //遍历所有item的同一slot的特征
                auto feature = item_features.at(j + item_num * i);//(slot_i,item_j)处的Feature
                SlotDataType data_type = item_slot_data_types[i];
                switch (data_type) {
                    case SlotDataType::INT_64: {
                        if (!item_slot_list[i].int_values) {
                            item_slot_list[i].int_values = std::make_shared<std::vector<std::vector<int64_t>>>();
                        }
                        item_slot_list[i].slot_data_type = SlotDataType::INT_64;
                        std::vector<std::vector<int64_t>> &slot_features = *item_slot_list[i].int_values;
                        const auto &data = feature.signs();
                        item_slot_list[i].slot_id = feature.slot_id();
                        std::vector<int64_t> feature_data(data.size());
                        //把feature.signs()转换成 vector<int>
                        for (int k = 0; k < data.size(); ++k) {
                            feature_data[k] = data[k];
                        }
                        slot_features.push_back(feature_data);
                        break;
                    }
                    case SlotDataType::FLOAT: {
                        if (!item_slot_list[i].float_values) {
                            item_slot_list[i].float_values = std::make_shared<std::vector<std::vector<float>>>();
                        }
                        item_slot_list[i].slot_data_type = SlotDataType::FLOAT;
                        std::vector<std::vector<float>> &slot_features = *item_slot_list[i].float_values;
                        const auto &data = feature.weights();
                        item_slot_list[i].slot_id = feature.slot_id();
                        std::vector<float> feature_data(data.size());
                        //把feature.signs()转换成 vector<float>
                        for (int k = 0; k < data.size(); ++k) {
                            feature_data[k] = data[k];
                        }
                        slot_features.push_back(feature_data);
                        break;
                    }
                    case SlotDataType::STRING: {
                        if (!item_slot_list[i].string_values) {
                            item_slot_list[i].string_values = std::make_shared<std::vector<std::vector<std::string>>>();
                        }
                        item_slot_list[i].slot_data_type = SlotDataType::STRING;
                        std::vector<std::vector<std::string>> &slot_features = *item_slot_list[i].string_values;
                        const auto &data = feature.bytes_list();
                        item_slot_list[i].slot_id = feature.slot_id();
                        std::vector<std::string> feature_data(data.size());
                        //把feature.signs()转换成 vector<string>
                        for (int k = 0; k < data.size(); ++k) {
                            feature_data[k] = data[k];
                        }
                        slot_features.push_back(feature_data);
                        break;
                    }
                    default: {
                        // HILOG_APP(INFO) << "feature 具有未知的 data type";
                        item_slot_list[i].slot_data_type = SlotDataType::UNKNOWN;
                        item_slot_list[i].slot_id = feature.slot_id();
                        break;
                    }
                }
            }
        }
        HILOG_APP(INFO) << "end merging item";

        // 写 item_slot_list 到文件 predict_type + model_name + item_slot_list.txt
        if (context->get_rank_request()->debuglevel() == DebugLevel::kRecallDumpEmb) {
            debug::file::WriteToFile("recall_item_" + context->GetRealItemModelName() + "_item_slot_list.txt", debug::printer::ToString(item_slot_list));
        }
        return item_slot_list;
    }

    void RecallItemEmbInferenceService::process_prediction(ItemEmbeddingContextPtr context, brpc::Channel *channel,
                                                         const ::proto::flow::PredictRequest *request,
                                                         ::proto::flow::PredictResponse *response,
                                                         std::shared_ptr<Info::ModelInfo> experiment_model_info,
                                                         int32_t index) {
        ::proto::flow::PredicterService_Stub stub(channel);
        brpc::Controller cntl;
        cntl.set_request_compress_type(experiment_model_info->_request_compress_type);
        stub.Predict(&cntl, request, response, nullptr);
        MonitorMgr::common_report_model(experiment_model_info->_emb_name, context->GetUploadSlotName(),
                                                            std::to_string(context->get_algo_scene_id()), "default", 0, "model_req_num", 1);
        if (cntl.Failed()) {
            HILOG_APP(ERROR) << "model:" << experiment_model_info->_model_name
                             << " Predict failed: " << cntl.ErrorText() << ",lat: " << cntl.latency_us();
        } else {
            HILOG_APP(INFO) << "model:" << experiment_model_info->_model_name
                            << " Predict success, lat: " << cntl.latency_us();

            MonitorMgr::percent_report_model(experiment_model_info->_emb_name,
                                             context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()),
                                             0, "predict_time", cntl.latency_us());

            auto &model_predict_responses = response->responses();

            if (model_predict_responses.empty()) {
                HILOG_APP(INFO) << "empty response: " << std::endl;
            }
            HILOG_APP(INFO) << "model_predict_responses size: " << model_predict_responses.size();
            for (const auto &model_predict_response: model_predict_responses) {
                HILOG_APP(INFO) << "tfserving model name: " << model_predict_response.model_name()
                                << "expri model name: " << experiment_model_info->_model_name << std::endl;
                // std::cout << "model_predict_response1: " << model_predict_response.DebugString()<< std::endl;
                if (model_predict_response.model_name() == experiment_model_info->_model_name) {

                    //找到了使用的模型
                    auto &predict_output_tensors = model_predict_response.outputs();//(name,values)
                    for (const auto &output_tensor: predict_output_tensors) {
                        HILOG_APP(INFO) << "output_tensor.name(): " << output_tensor.name();
                        if (output_tensor.name() == "item_vec") {
                            std::vector<EmbItemWrapper> &emb_item_vec = context->_item_embedding_map.at(index);
                            auto &batch_item_vecs = output_tensor.values();
                            const float *vecs = batch_item_vecs.float_val().data();
                            const int batch_size = batch_item_vecs.shape(0);
                            const int single_vector_size = batch_item_vecs.shape(1);

                            if (emb_item_vec.size() == 0 || emb_item_vec.size() != batch_size) {
                                HILOG_APP(INFO)
                                        << "batch size not equal, request size = [" << emb_item_vec.size() << "]"
                                        << "batch size = [" << batch_size << "]; ";
                                return;
                            }

                            if (context->_is_offline_emb_task && context->_embedding_size == 0) {
                                context->_embedding_size = single_vector_size;
                            }

                            // MonitorMgr::percent_report_model(experiment_model_info->_emb_name, context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()), 0, "model_embedding_size", single_vector_size);
                            HILOG_APP(INFO) << "process_embeddings";
                            float item_abs_avg = 0;
                            size_t item_size_sum = 0;
                            for (size_t i = 0; i < batch_size; i++) {
                                auto &item_embeddings_response = emb_item_vec[i];
                                for (int j = 0; j < single_vector_size; j++) {
                                    item_embeddings_response.ad_embedding->add_embedding(
                                            *(vecs + i * single_vector_size + j));
                                }
                                int embedding_size = item_embeddings_response.ad_embedding->embedding_size();
                                float abs_sum = std::accumulate(item_embeddings_response.ad_embedding->embedding().begin(), item_embeddings_response.ad_embedding->embedding().end(), 0.0f,
                                [](float acc, float val) { return acc + std::fabs(val); });
                                float abs_avg = embedding_size == 0 ? 0.0 : abs_sum / embedding_size;
                                item_abs_avg += abs_avg;
                                item_size_sum += embedding_size;
                            }
                            MonitorMgr::common_report_model(
                                    experiment_model_info->_emb_name, context->GetUploadSlotName(),
                                    std::to_string(context->GetAlgoSceneId()), "default", 0, "pdtr_number", batch_size);
                            MonitorMgr::common_report_model(
                                    experiment_model_info->_emb_name, context->GetUploadSlotName(),
                                    std::to_string(context->GetAlgoSceneId()), "default", 0, "item_emb_abs_avg", item_abs_avg);

                            MonitorMgr::common_report_model(
                                    experiment_model_info->_emb_name, context->GetUploadSlotName(),
                                    std::to_string(context->GetAlgoSceneId()), "default", 0, "item_emb_size", item_size_sum);

                            break;
                        }
                    }
                    MonitorMgr::percent_report_model(experiment_model_info->_emb_name,
                                                     context->GetUploadSlotName(),
                                                     std::to_string(context->get_algo_scene_id()), 0, "predict_io",
                                                     cntl.latency_us() - (model_predict_response.cost() * 1000));
                    MonitorMgr::percent_report_model(experiment_model_info->_emb_name,
                                                     context->GetUploadSlotName(),
                                                     std::to_string(context->get_algo_scene_id()), 0, "model_time",
                                                     (model_predict_response.cost()*1000));
                    break;
                }
            }
        }
    }
}// namespace Core