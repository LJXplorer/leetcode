#pragma once
#include "common/comm/lockfree_threadpool.h"
#include "core/core_services/base_service/service_info.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/item_embedding_context.h"
#include "core/core_server/server_config/server_config.h"
#include "fe_request.pb.h"
#include "user_action.pb.h"
#include "phx-fe/util/util.h"
#include <google/protobuf/arena.h>
#include <latch.h>
namespace Core {
    class RecallItemEmbInferenceService : public ServiceBaseInfo {
    public:
        struct EmbExtractorArgs {
            bthread_t tid;
            google::protobuf::Arena *arena;
            ItemEmbeddingContextPtr context;
            int32_t split_index;
            phx::ExtractorResponse *extractor_result;
            phx::FeRequest *fe_request;
            std::shared_ptr<Info::ModelInfo> item_emb_model_info;
            common::SimpleLatch *latch;
            long start = 0;
            long end = 0;
        };
        int do_service(GraphContextPtr context) override;
        virtual void initialize(GraphContextPtr context);
        phx::FeRequest *BuildFeRequest(ItemEmbeddingContextPtr context, const std::vector<EmbItemWrapper> &items);
        virtual void parallel_extract_execute(std::vector<EmbExtractorArgs> &args_vec);
        bool skip(GraphContextPtr context) override;
        
    protected:
        static common::lockfree_threadpool::Executor item_embedding_fe_executor;
        static void *Extract(void *arg);
        static void *Predict(void *arg);
        static phx::UserAction s_empty_user_action;
        static constexpr bool use_bthread_pool = true;
        static constexpr size_t common_thread_pool_size = use_bthread_pool ? 0 : 58;
        static void get_item_slot_data_types(const phx::ExtractorResponse *extractor_responses, size_t slot_num, std::vector<SlotDataType> &item_slot_data_types);
        static std::vector<SlotInfo> parse_item_list_item_embedding(
            const phx::ExtractorResponse *extractor_response, const size_t &item_slot_num,
            const std::vector<SlotDataType> &item_slot_data_types, int32_t &total_item, ItemEmbeddingContextPtr &context);
        static void process_prediction(ItemEmbeddingContextPtr context, brpc::Channel *channel,
                                        const ::proto::flow::PredictRequest *request,
                                        ::proto::flow::PredictResponse *response,
                                        std::shared_ptr<Info::ModelInfo> experiment_model_info,
                                        int32_t index);
    };
}// namespace Core