#pragma once
#include "core/core_services/base_service/service_info.h"
#include "core/core_context/item_embedding_context.h"

namespace Core {
    class RecallItemEmbDoneService : public ServiceBaseInfo {
    public:
        RecallItemEmbDoneService() = default;
        virtual ~RecallItemEmbDoneService() {};
        virtual void initialize(GraphContextPtr context);
        int do_service(GraphContextPtr context) override;
    private:
        int assembly_response(ItemEmbeddingContextPtr context);
    };

}// namespace Core