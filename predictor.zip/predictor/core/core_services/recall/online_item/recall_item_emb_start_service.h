#pragma once
#include "core/core_context/item_embedding_context.h"
#include "core/core_services/base_service/service_info.h"
namespace Core {
    class RecallItemEmbStartService : public ServiceBaseInfo {
    private:
        std::string _dict_name;
        int _split_size = 40;
    public:
        virtual void initialize(GraphContextPtr context);
        virtual void initialize(ConfigXmlPtr xml);
        int do_service(GraphContextPtr context) override;

        template <typename T>
        static bool safe_string_to_num(const std::string &str, T &out_value) {
            std::istringstream iss(str);
            iss >> out_value;
            return !iss.fail() && iss.eof();
        }

        const std::string &get_dict_name() {
            return _dict_name;
        }

    private:
        int32_t process(ItemEmbeddingContextPtr context);
        int32_t convert2RankRequest(ItemEmbeddingContextPtr context);
    };

};// namespace Core