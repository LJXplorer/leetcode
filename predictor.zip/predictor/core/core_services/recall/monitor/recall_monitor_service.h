#pragma once
#include "core/core_services/base_service/service_info.h"
#include "core/core_context/core_context.h"
#include "common/monitor/monitors.h"
namespace Core {
    class RecallMonitorService : public ServiceBaseInfo{
    public:
        RecallMonitorService() {  
        }

        ~RecallMonitorService(){

        }

        virtual void initialize(ConfigXmlPtr xml);
        virtual void initialize_xml(ConfigXmlPtr xml);
        virtual void initialize(GraphContextPtr context);
        virtual int do_service(GraphContextPtr context); 
    private:
        int process(CoreContextPtr context);
    public:
        virtual int report(CoreContextPtr context);

    };
    
}
