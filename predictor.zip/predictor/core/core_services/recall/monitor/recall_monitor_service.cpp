
#include "common/hilog/log_helper.h"
#include "core/core_context/context_defs.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/recall/monitor/recall_monitor_service.h"
#include "core/utils/defs.h"
#include "core/utils/monitor_mgr.h"
#include <algorithm>
#include <boost/algorithm/string.hpp>
#include <cstdint>
#include <nlohmann/json.hpp>
#include <string>
#include <unordered_map>

namespace Core {
    SERVICE_REGISTER(RecallMonitorService);

    void RecallMonitorService::initialize(ConfigXmlPtr xml) {
        initialize_xml(xml);
    }

    void RecallMonitorService::initialize_xml(ConfigXmlPtr xml) {
    }

    void RecallMonitorService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        return ctx->get_monitor_context()->alloc_node(get_name());
    }

    int RecallMonitorService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int32_t ret = 0;
        try {
            ret = process(ctx);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << "do service fail: " << ret << "," << e.what();
        }
        HILOG_APP(INFO) << LOG_HEAD(ctx) << get_name() << " do_service ret:" << ret;
        return ret;
    }

    int RecallMonitorService::process(CoreContextPtr ctx) {
        int ret = report(ctx);
        if (ret != ERROR_SUCCESS) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << " check_proto fail: " << ret;
            //report
            return ret;
        }
        return ERROR_SUCCESS;
    }

    int RecallMonitorService::report(CoreContextPtr ctx) {
        MonitorContextPtr _monitor_context_ptr = ctx->get_monitor_context();
        std::unordered_map<std::string, StatItemPtr> _stat_pair = _monitor_context_ptr->get_stat_pair();
        const std::string &upload_aggrated_slotid = STRING_DEFAULT;
        const std::string &route = std::to_string(ctx->get_route());
        const string algo_sceneId = std::to_string(ctx->get_algo_scene_id());

        //上报总体耗时
        auto total_cost = ctx->_end_ts - ctx->_begin_ts;
        MonitorMgr::percent_report_stage(route, algo_sceneId, STRING_DEFAULT, "flow", upload_aggrated_slotid,
                                             0, "flow_total_cost", total_cost);

        HILOG_APP(INFO) << LOG_HEAD(ctx) << "flow cost:" << total_cost;

        //上报阶段耗时
        for (auto &s: _stat_pair) {
            HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first << " cost:" << s.second->request_lat() << ":" << s.second->lat()
                            << "," << s.second->get_lat()->toString();
            const std::string &sceneId = std::to_string(ctx->get_algo_scene_id());
            MonitorMgr::percent_report_stage(route, sceneId, STRING_DEFAULT, s.first, upload_aggrated_slotid,
                                                0, "req_cost", s.second->request_lat());
            MonitorMgr::percent_report_stage(route, sceneId, STRING_DEFAULT, s.first, upload_aggrated_slotid,
                                                0, "rsp_cost", s.second->response_lat());
            MonitorMgr::percent_report_stage(route, sceneId, STRING_DEFAULT, s.first, upload_aggrated_slotid,
                                                0, "stage_total_cost", s.second->lat());

            if (!s.second->_l_extra_map.empty()) {
                for (auto &l_ex: s.second->_l_extra_map) {
                    MonitorMgr::common_report_stage(route, sceneId, STRING_DEFAULT, s.first,
                                                    upload_aggrated_slotid, 0, s.first + "_" + l_ex.first,
                                                    l_ex.second);
                    HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first << ":" << l_ex.first << ":" << l_ex.second;
                }
            }

            if (!s.second->_f_extra_map.empty()) {
                for (auto &f_ex: s.second->_f_extra_map) {
                    MonitorMgr::common_report_stage(route, sceneId, STRING_DEFAULT, s.first,
                                                    upload_aggrated_slotid, 0, s.first + "_" + f_ex.first,
                                                    f_ex.second);
                    HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first << ":" << f_ex.first << ":" << f_ex.second;
                }
            }

            if (!s.second->_redis_extra_map.empty()) {
                for (auto &r: s.second->_redis_extra_map) {
                    //硬编码，解决featuredump service上报的兼容问题
                    if (s.first == "dump_value") {
                        HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first;
                        MonitorMgr::redis_report_percent(route, "feature_dump_value", r.second._ret, "redis_total_cost",
                                                         r.second._lat, r.second._source, algo_sceneId, STRING_TOTALUP);
                        MonitorMgr::redis_report_common(route, "feature_dump_value", r.second._ret, "fetch_num", 1,
                                                        r.second._source, algo_sceneId, STRING_TOTALUP);
                        if (r.second._ret == 0) {
                            MonitorMgr::redis_report_common(route, "feature_dump_value", r.second._ret,
                                                            "fetch_success_num", 1, r.second._source, algo_sceneId,
                                                            STRING_TOTALUP);
                        } else if (r.second._ret == -2) {
                            MonitorMgr::redis_report_common(route, "feature_dump_value", r.second._ret,
                                                            "fetch_not_fount_num", 1, r.second._source, algo_sceneId,
                                                            STRING_TOTALUP);
                        }
                    } else {
                        MonitorMgr::redis_report_percent(route, r.first, r.second._ret, "redis_total_cost",
                                                         r.second._lat, r.second._source, algo_sceneId, STRING_TOTALUP);
                        MonitorMgr::redis_report_common(route, r.first, r.second._ret, "fetch_num", 1, r.second._source,
                                                        algo_sceneId, STRING_TOTALUP);
                        MonitorMgr::redis_report_percent(route, r.first, r.second._ret, "redis_response_size",
                                                         r.second._redis_response_size, r.second._source, algo_sceneId,
                                                         STRING_TOTALUP);
                        MonitorMgr::redis_report_percent(route, r.first, r.second._ret, "redis_up_num",
                                                         r.second._up_size, r.second._source, algo_sceneId,
                                                         STRING_TOTALUP);
                        if (r.second._ret == 0) {
                            MonitorMgr::redis_report_common(route, r.first, r.second._ret, "fetch_success_num", 1,
                                                            r.second._source, algo_sceneId, STRING_TOTALUP);
                        } else if (r.second._ret == -2) {
                            MonitorMgr::redis_report_common(route, r.first, r.second._ret, "fetch_not_fount_num", 1,
                                                            r.second._source, algo_sceneId, STRING_TOTALUP);
                        }
                    }
                    HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first << ":" << r.first << ":" << r.second._ret << ":"
                                    << r.second._lat;
                }
            }

            if (!s.second->_up_extra_map.empty()) {
                for (auto &r: s.second->_up_extra_map) {
                    MonitorMgr::redis_report_common(route, r.second._cluster_id, r.second._ret, "fetch_num", 1,
                                                    r.second._source, algo_sceneId, r.first);
                    MonitorMgr::redis_report_percent(route, r.second._cluster_id, r.second._ret,
                                                     "feature_response_size", r.second._response_size, r.second._source,
                                                     algo_sceneId, r.first);
                    MonitorMgr::redis_report_percent(route, r.second._cluster_id, r.second._ret, "feature_value_size",
                                                     r.second._feat_size, r.second._source, algo_sceneId, r.first);
                    if (r.second._ret == 0) {
                        MonitorMgr::redis_report_common(route, r.second._cluster_id, r.second._ret, "fetch_success_num",
                                                        1, r.second._source, algo_sceneId, r.first);
                    } else if (r.second._ret == -2) {
                        MonitorMgr::redis_report_common(route, r.second._cluster_id, r.second._ret,
                                                        "fetch_not_fount_num", 1, r.second._source, algo_sceneId,
                                                        r.first);
                    }
                }
            }
        }
        MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "request_cnt", 1);
        MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "req_item_size",
                                       ctx->_bak_request.predictorslotinfo().predictoriteminfos_size());

        return ERROR_SUCCESS;
    }

}// namespace Core
