#ifndef _CORE_SERVICES_START_H
#define _CORE_SERVICES_START_H
#include "butil/third_party/rapidjson/document.h"
#include "butil/third_party/rapidjson/stringbuffer.h"
#include "butil/third_party/rapidjson/writer.h"
#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"
namespace Core {

    class StartService : public ServiceBaseInfo {
    private:
        std::string _proto_type;
        std::set<std::string> _valid_route;
        std::set<PredictType> _predict_type_vec;
        int32_t _split_size = 40;
        int32_t _SEED = 0x7f3a21eaL;
        const int32_t _ONE_THOUSAND = 1000;
        const int32_t _TEN_THOUSAND = 10000;

    public:
        StartService() {
        }

        ~StartService() {
        }

        virtual void initialize(ConfigXmlPtr xml);
        virtual void initialize_xml(ConfigXmlPtr xml);
        virtual void initialize(GraphContextPtr context);
        virtual int do_service(GraphContextPtr context);

    private:
        int process(CoreContextPtr context);
        int init_prerank_context(CoreContextPtr context);
        void process_prerank(CoreContextPtr context, nlohmann::json &json_data);
        void init_prerank_items(CoreContextPtr context);
        void init_cvr_prerank_items(CoreContextPtr context);

    protected:
        int init_user_embedding_items(CoreContextPtr context, const std::string &user_embedding_url, int model_version);
        int init_embedding_context(CoreContextPtr context);
        void add_embedding_item(CoreContextPtr context, const std::string &user_emb_model_name,
                                const std::string &rule_name, const PredictType &predict_type);

    public:
        virtual int check_data(CoreContextPtr context);

        virtual int convert_proto(CoreContextPtr context);

        virtual int parse_ab_param(CoreContextPtr context);

        int get_split_size() {
            return _split_size;
        }

        static const std::string &get_model_name(CoreContextPtr context, int32_t m);

        void genContextFeat(CoreContextPtr context, FSContextPtr fs_ctx, const phx::PredictorRequest *req);
        void addTrackExtFeat(const butil::rapidjson::Document &doc, phx::FeRequest *feature_dump,
                             const std::string &rtFeatureName);
        void item_model_list(Core::CoreContextPtr context, const ::phx::PredictorItemInfo &item,
                             ::phx::PredictorItemData &item_data);

        int32_t get_hash(const std::string& salt_str, const int32_t base_num) {
            uint32_t out;
            butil::MurmurHash3_x86_32(salt_str.c_str(), salt_str.length(), _SEED, &out);
            return out % base_num;
        }
    };

}// namespace Core

#endif
