#include "core/core_services/start/callback_start_service.h"
#include "common/hilog/log_helper.h"
#include "core/core_context/callback_context.h"
#include "core/utils/defs.h"
#include "core/utils/error.h"
#include "core/utils/monitor_mgr.h"
#include <boost/algorithm/string.hpp>
#include <boost/beast/core/detail/base64.hpp>
#include <bvar/reducer.h>
#include <bvar/window.h>
#include <cstdint>
#include <google/protobuf/util/json_util.h>
#include <memory>
#include <string>
#include "third_party/protobuf/include/google/protobuf/util/json_util.h"
#include "json2pb/json_to_pb.h"
#include <nlohmann/json.hpp>
#include <google/protobuf/util/json_util.h>

namespace Core {

    SERVICE_REGISTER(CallbackStartService);

    void CallbackStartService::initialize(ConfigXmlPtr xml) {
        xml->attr<int>("retry_cnt", _retry_cnt);
        std::string skip_white_list_str;
        xml->attr<std::string>("skip_white_list", skip_white_list_str);
        get_skip_white_list(skip_white_list_str);
    }

    void CallbackStartService::initialize_xml(ConfigXmlPtr xml) {
    }

    void CallbackStartService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CallbackContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
    }

    int CallbackStartService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CallbackContext>(context);
        int32_t ret = 0;
        try {
            ctx->gen_log_head();
            ret = process(ctx);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << "do service fail: " << ret << ", " << e.what();
        }
        return ret;
    }

    void CallbackStartService::get_skip_white_list(std::string white_list_str) {
        std::set<std::string> result_set;
        if (!white_list_str.empty()) {
            std::istringstream ss(white_list_str);
            std::string item;
            while (std::getline(ss, item, ',')) {
                result_set.insert(item);
            }
        }

        skip_white_list = result_set;
        HILOG_APP(INFO) << "skip_white_list size: " << skip_white_list.size();
    }

    std::string getRouteStr(int route) {
        switch (route) {
            case 1:
                return "HONOR";
            case 2:
                return "BYTEDANCE";
            case 3:
                return "IT";
            case 4:
                return "BASELINE";
            default:
                return "";
        }
    }

    int CallbackStartService::process(CallbackContextPtr context) {
        int ret = 0;
        BizLatency *lat = get_node_stat(context)->get_lat();
        const auto *callback_req = context->get_callback_request();

        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);

            if (callback_req->callbackslotinfo().predicttimestamp() > 0) {
                const std::string &upload_aggreted_slotid = context->GetUploadSlotName();
                int64_t estimate_2_callback_cost =
                        gettimeofday_ms() - callback_req->callbackslotinfo().predicttimestamp();
                const std::string& algo_sceneId = std::to_string(context->get_algo_scene_id());
                MonitorMgr::percent_report_stage(getRouteStr(callback_req->callbackslotinfo().route()),algo_sceneId, "default", get_name(),
                                                 upload_aggreted_slotid, 0, "estimate_2_callback_cost",
                                                 estimate_2_callback_cost);
            }

            ret = check_data(context);
            if (ret != ERROR_SUCCESS) {
                HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << " check_proto fail: " << ret;
                context->set_ex_req(true);
                return ret;
            }

            context->set_retry_cnt(_retry_cnt);
            context->set_origin_retry_cnt(_retry_cnt);
        }

        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_DESTROY);
            ret = convert_proto(context);
            if (ret != ERROR_SUCCESS) {
                HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << " convert_proto fail: " << ret;
                context->set_ex_req(true);
                return ret;
            }
            const auto fs_ctx_req = context->get_rank_request();
            auto fs_ctx = context->get_fs_context();
            // 填充req_id
            fs_ctx->get_feature_dump()->mutable_req_id()->assign(context->get_req_id());
            //填上下文特征
            genContextFeat(fs_ctx, fs_ctx_req, callback_req);
        }

        return ERROR_SUCCESS;
    }

    int CallbackStartService::check_data(CallbackContextPtr context) {
        const auto *callback_req = context->get_callback_request();

        if (callback_req->reqid().empty()) {
            context->_response_code = ERROR_BIZ_PROTO_REQID_EMPTY;
            return ERROR_BIZ_PROTO_REQID_EMPTY;
        }

        if (callback_req->callbackslotinfo().callbackiteminfos_size() == 0) {
            context->_response_code = ERROR_BIZ_PROTO_ADITEMS_EMPTY;
            return ERROR_BIZ_PROTO_ADITEMS_EMPTY;
        }

        // std::unordered_set<int64_t> check_set;
        // for (int32_t i = 0; i < callback_req->callbackslotinfo().callbackiteminfos_size(); i++) {
        //     auto aditem = callback_req->callbackslotinfo().callbackiteminfos(i);
        //     auto result = check_set.insert(aditem.creativeid());
        //     if (!result.second) {
        //         HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << " repeated creativeid in request!!!";
        //         context->_response_code = ERROR_BIZ_REPEATED_MATERIALID;
        //         return ERROR_BIZ_REPEATED_MATERIALID;
        //     }
        // }
        return ERROR_SUCCESS;
    }

    int CallbackStartService::convert_proto(CallbackContextPtr context) {
        const phx::CallbackRequest &callback_req = *(context->get_callback_request());
        // 转化featuredump入参为ranking请求
        CreateRankingRequest(callback_req, context);
        auto rank_req = context->get_rank_request();
        int32_t item_size = rank_req->predictorslotinfo().predictoriteminfos_size();
        report(context, "req_item", item_size);

        if (skip_white_list.find(std::to_string(callback_req.callbackslotinfo().algosceneid())) !=
            skip_white_list.end()) {
            context->is_skip = true;
            HILOG_APP(INFO) << "is_skip is true, algosceneid is " << callback_req.callbackslotinfo().algosceneid();
        }
        if (item_size == 0) {
            return ERROR_BIZ_PROTO_ADS_EMPTY;
        }

        for (int32_t i = 0; i < item_size; i++) {
            auto& item = rank_req->predictorslotinfo().predictoriteminfos(i);
            if (item.creativeid() != 0) {
                context->get_fs_context()->alloc_item_fea(item.creativeid());
                context->get_fs_context()->alloc_app_fea(item.appid());
            }
            
        }

        return ERROR_SUCCESS;
    }

    // 调用函数
    void CallbackStartService::CreateRankingRequest(const phx::CallbackRequest &request, CallbackContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CallbackContext>(context);
        auto mutable_ranking_request = ctx->get_mutable_rank_request();

        mutable_ranking_request->set_debuglevel(request.debuglevel());
        mutable_ranking_request->set_reqid(request.reqid());
        mutable_ranking_request->set_mediaid(request.mediaid());
        mutable_ranking_request->mutable_predictorslotinfo()->set_slotid(request.callbackslotinfo().slotid());
        mutable_ranking_request->set_oaid(request.oaid());
        mutable_ranking_request->set_algotraceid(request.algotraceid());
        mutable_ranking_request->mutable_predictorslotinfo()->set_algosceneid(request.callbackslotinfo().algosceneid());
        mutable_ranking_request->set_triggerscene(request.triggerscene());
        mutable_ranking_request->mutable_predictorslotinfo()->set_route(request.callbackslotinfo().route());
        mutable_ranking_request->set_mediatype(request.mediatype());
        mutable_ranking_request->set_businesstype(request.businesstype());
        mutable_ranking_request->mutable_predictorslotinfo()->set_predicttimestamp(request.callbackslotinfo().predicttimestamp());
        mutable_ranking_request->mutable_predictorslotinfo()->mutable_rtadunitfeature()->CopyFrom(
                request.callbackslotinfo().rtadunitfeature());
        mutable_ranking_request->mutable_rtrequestfeature()->CopyFrom(request.rtrequestfeature());
        mutable_ranking_request->mutable_deviceinfo()->CopyFrom(request.deviceinfo());
        mutable_ranking_request->set_hostappid(request.hostappid());
        std::string query = extract_query(request.query());
        if (!query.empty()) {
            mutable_ranking_request->set_query(query);
        }
        int dsp_cnt = 0;
        int inner_cnt = 0;
        std::unordered_set<int64_t> check_set;
        for (const auto &item: request.callbackslotinfo().callbackiteminfos()) {
            // if (item.creativeid() == 0) {
            //     continue;
            // }
            auto *add_aditems = mutable_ranking_request->mutable_predictorslotinfo()->add_predictoriteminfos();
            if (add_aditems == nullptr) {
                continue;
            }
            if (item.creativeid() != 0) {
                auto result = check_set.insert(item.creativeid());
                if(!result.second) {
                    HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << " repeated creativeid in request!!!";
                    context->_response_code = ERROR_BIZ_REPEATED_MATERIALID;
                    return;
                }
            }
            else {
                context->get_fs_context()->_zero_creativeid_items.emplace_back(&item);
            }
            
            add_aditems->set_appid(item.appid());
            add_aditems->set_billingmode(item.billingmode());
            add_aditems->set_creativeid(item.creativeid());
            add_aditems->set_adgroupid(item.adgroupid());
            add_aditems->set_convtype(item.convtype());
            add_aditems->set_convgoal(item.convgoal());
            add_aditems->set_enhanceconvtype(item.enhanceconvtype());
            add_aditems->set_deepconvtype(item.deepconvtype());
            add_aditems->set_bid(item.bid());
            add_aditems->set_ocpxsbp(item.ocpxsbp());
            add_aditems->set_admask(item.admask());
            add_aditems->set_recalltype(item.recalltype());
            add_aditems->mutable_rtaid()->assign(item.rtaid());
            add_aditems->set_rtaurlid(item.rtaurlid());
            if (item.datasource() == 1 && item.isinner() != 1) {
                ctx->get_fs_context()->_item_direct_inv.insert(item.creativeid());
            }
            if (item.datasource() != 1) {
                dsp_cnt++;
            } else if (item.isinner() == 1) {
                inner_cnt++;
            }
            // add_aditems->set_rtaid(item.rtaid());
            // add_aditems->set_rtaurlid(item.rtaurlid());
            add_aditems->set_finalecpm(item.finalecpm());
        }

        const std::string &upload_aggreted_slotid = context->GetUploadSlotName();
        const std::string& algo_sceneId = std::to_string(context->get_algo_scene_id());
        // 统计callback请求的队列长度
        MonitorMgr::common_report_stage(getRouteStr(request.callbackslotinfo().route()),algo_sceneId, "defautl", get_name(),
                                        upload_aggreted_slotid, 0, "item_cnt",
                                        request.callbackslotinfo().callbackiteminfos_size());

        if (dsp_cnt == request.callbackslotinfo().callbackiteminfos_size()) {
            // 全是dsp
            context->_is_all_dsp = true;
            // 统计全dsp请求个数
            MonitorMgr::common_report_stage(getRouteStr(request.callbackslotinfo().route()), algo_sceneId, "defautl", get_name(),
                                            upload_aggreted_slotid, 0, "all_dsp_req_cnt", 1);

        } else if (inner_cnt == request.callbackslotinfo().callbackiteminfos_size()) {
            // 全是内投
            context->_is_all_inner = true;
            // 统计全内投请求个数
            MonitorMgr::common_report_stage(getRouteStr(request.callbackslotinfo().route()),algo_sceneId, "defautl", get_name(),
                                            upload_aggreted_slotid, 0, "all_inner_req_cnt", 1);
        } else {
            // 包含直投
            if (dsp_cnt == 0 && inner_cnt == 0) {
                // 统计全直投请求个数
                MonitorMgr::common_report_stage(getRouteStr(request.callbackslotinfo().route()),algo_sceneId, "defautl", get_name(),
                                                upload_aggreted_slotid, 0, "all_direct_req_cnt", 1);
            }
            // 统计直投item长度
            MonitorMgr::common_report_stage(getRouteStr(request.callbackslotinfo().route()), algo_sceneId,"defautl", get_name(),
                                            upload_aggreted_slotid, 0, "direct_item_cnt",
                                            ctx->get_fs_context()->_item_direct_inv.size());

            // 统计非直投item长度
            MonitorMgr::common_report_stage(getRouteStr(request.callbackslotinfo().route()), algo_sceneId,"defautl", get_name(),
                                            upload_aggreted_slotid, 0, "non_direct_item_cnt",
                                            request.callbackslotinfo().callbackiteminfos_size() -
                                                    ctx->get_fs_context()->_item_direct_inv.size());
        }

        MonitorMgr::redis_report_common(STRING_DEFAULT, "featuredump_direct_item", 0, "join_num",
                                        ctx->get_fs_context()->_item_direct_inv.size(), FsSource::REDIS,
                                        std::to_string(context->get_algo_scene_id()), STRING_TOTALUP);
    }

    std::string CallbackStartService::extract_query(const std::string &query) {
        try {
            std::string tmpQuery = query;
            boost::algorithm::replace_all(tmpQuery, "[", "");
            boost::algorithm::replace_all(tmpQuery, "]", "");

            if (!tmpQuery.empty()) {
                std::vector<std::string> arr;
                boost::split(arr, tmpQuery, boost::is_any_of(","));
                if (!arr.empty()) {
                    return arr[0];
                }
            }
        } catch (const std::exception &e) {
            HILOG_APP(INFO) << "extract query error, query: " << query << ", exception: " << e.what();
        }
        return "";
    }

    void CallbackStartService::genContextFeat( FSContextPtr fs_ctx, const phx::PredictorRequest * req, const phx::CallbackRequest* callback_request) {
        auto feature_dump = fs_ctx->get_feature_dump();

        feature_dump->set_req_time(req->predictorslotinfo().predicttimestamp());
        
        feature_dump->mutable_context()->set_adunit_id(req->predictorslotinfo().slotid());

        feature_dump->mutable_context()->set_media_id(req->mediaid());

        if (!req->rtrequestfeature().activationflag().empty()) {
            try {
                int64_t activationFlagInt = std::stoll(req->rtrequestfeature().activationflag());
                feature_dump->mutable_context()->set_activation_flag(activationFlagInt);
            } catch (const std::exception& e) {
                HILOG_APP(WARNING) << get_name() << "activationflag string parse to int has exception " << e.what();
            }   
        }

        feature_dump->mutable_context()->mutable_launch_type()->assign(req->rtrequestfeature().launchtype());

        if (!req->rtrequestfeature().requestsceneout().empty()) {
            try {
                int64_t requestSceneOutInt = std::stoll(req->rtrequestfeature().requestsceneout());
                feature_dump->mutable_context()->set_request_scene_out(requestSceneOutInt);
            } catch (const std::exception& e) {
                HILOG_APP(WARNING) << get_name() << "activationflag string parse to int has exception " << e.what();
            }
        }

        feature_dump->mutable_context()->set_is_preload(req->predictorslotinfo().rtadunitfeature().ispreload());

        feature_dump->mutable_context()->set_refresh_times(req->rtrequestfeature().refreshtimes());

        feature_dump->mutable_context()->set_shake_switch(req->rtrequestfeature().shakeswitch());

        feature_dump->mutable_context()->set_user_installed_appid(req->hostappid());

        feature_dump->mutable_context()->set_user_installed_pkg_size(req->rtrequestfeature().userinstalledpkgsize());

        feature_dump->mutable_context()->mutable_osv()->assign(req->deviceinfo().osv());

        feature_dump->mutable_context()->mutable_model()->assign(req->deviceinfo().model());

        feature_dump->mutable_context()->set_device_type(req->deviceinfo().devicetype());

        feature_dump->mutable_context()->set_screen_width(req->deviceinfo().screenwidth());

        feature_dump->mutable_context()->set_screen_height(req->deviceinfo().screenheight());

        feature_dump->mutable_context()->set_ppi(req->deviceinfo().ppi());

        feature_dump->mutable_context()->set_orientation(req->deviceinfo().orientation());

        feature_dump->mutable_context()->mutable_carrier()->assign(req->deviceinfo().carrier());

        feature_dump->mutable_context()->set_connection_type(req->deviceinfo().connectiontype());

        feature_dump->mutable_context()->mutable_ip()->assign(req->deviceinfo().ip());

        feature_dump->mutable_context()->mutable_query()->assign(req->query());

        if (!req->deviceinfo().geo().city().empty()) {
            try {
                int64_t cityInt = std::stoll(req->deviceinfo().geo().city());
                feature_dump->mutable_context()->set_city_code(cityInt);
            } catch (const std::exception& e) {
                HILOG_APP(WARNING) << get_name() << "activationflag string parse to int has exception " << e.what();
            }
        }
        
        feature_dump->mutable_context()->set_trigger_scene(req->triggerscene());

        switch (req->predictorslotinfo().route()) {
            case 1: {
                feature_dump->mutable_context()->mutable_traffic_id()->assign("cloud");
                break;
            }
            case 2: {
                feature_dump->mutable_context()->mutable_traffic_id()->assign("byte");
                break;
            }
            case 3: {
                feature_dump->mutable_context()->mutable_traffic_id()->assign("it");
                break;
            }
            case 4: {
                feature_dump->mutable_context()->mutable_traffic_id()->assign("s1");
                break;
            }
            default: {
                feature_dump->mutable_context()->mutable_traffic_id()->assign("默认值");
                break;
            }
            
        }

        std::string expIds_str;  
        for (auto& expId : callback_request->callbackslotinfo().algoexpids()) {
            expIds_str.append(expId);
            expIds_str.append(",");
        }
        if (!expIds_str.empty()) {
            expIds_str.pop_back();
        }
        feature_dump->mutable_context()->mutable_exp_ids()->assign(expIds_str);


        feature_dump->mutable_context()->mutable_oaid()->assign(req->oaid());

        feature_dump->mutable_context()->set_timestamp(req->deviceinfo().timestamp());

        feature_dump->mutable_context()->set_media_type(req->mediatype());

        feature_dump->mutable_context()->mutable_magicui_version()->assign(req->deviceinfo().magicuiversion());

        if (!req->rtrequestfeature().honorboardfeedlist().empty()) {
            try {
                std::string json_str = req->rtrequestfeature().honorboardfeedlist();
                google::protobuf::util::JsonParseOptions options;
                auto status = google::protobuf::util::JsonStringToMessage(json_str, feature_dump->mutable_context()->mutable_info_flow_context(), options);
                if (!status.ok()) {
                    HILOG_APP(ERROR) << "parse info_flow_context feat failed: "<<req->rtrequestfeature().honorboardfeedlist().c_str();
                }
                
            } catch (const std::exception& e) {
                HILOG_APP(ERROR) << "parse info_flow_context feat failed: "<<req->rtrequestfeature().honorboardfeedlist().c_str();
            }
        }

        if (!req->rtrequestfeature().trackext().empty()) {
            butil::rapidjson::Document doc;
            doc.Parse(req->rtrequestfeature().trackext().c_str());
            if (!doc.HasParseError() && doc.IsObject()) {
                try{
                    addTrackExtFeat(doc, feature_dump, "sessionId");
                    addTrackExtFeat(doc, feature_dump, "detailType");
                    addTrackExtFeat(doc, feature_dump, "visitSource");
                    addTrackExtFeat(doc, feature_dump, "sourcePackageName");        
                } catch (const std::exception& e) {
                    HILOG_APP(ERROR) << "add track_ext feat has exception "<< e.what();
                }
            }
        }
    

    }

    void CallbackStartService::addTrackExtFeat(const butil::rapidjson::Document& doc, phx::FeRequest* feature_dump, const std::string& rtFeatureName) {
        if (doc.HasMember(rtFeatureName.c_str())) {
            const butil::rapidjson::Value& value = doc[rtFeatureName.c_str()];
            if (rtFeatureName == "sessionId") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0) 
                    feature_dump->mutable_context()->mutable_session_id()->assign(value.GetString());
            }
            else if (rtFeatureName == "detailType") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0) {
                    try {
                        feature_dump->mutable_context()->set_detail_type(std::stoi(value.GetString()));
                    } catch (const std::exception& e) {
                        HILOG_APP(WARNING) << get_name() << "detailType string parse to int has exception " << e.what();
                    }
                }
            }
            else if (rtFeatureName == "visitSource") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0) 
                    feature_dump->mutable_context()->mutable_visit_source()->assign(value.GetString());
            }
            else if (rtFeatureName == "sourcePackageName") {
                if (!value.IsNull() && value.IsString() && value.GetStringLength() != 0) 
                    feature_dump->mutable_context()->mutable_source_package_name()->assign(value.GetString());
            }    
        }
    }


};// namespace Core
