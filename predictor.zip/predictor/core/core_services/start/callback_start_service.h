#pragma once
#include "core/core_context/callback_context.h"
#include "core/core_services/base_service/service_info.h"
#include "ranking/callback_service.pb.h"
#include <memory>
#include "butil/third_party/rapidjson/document.h"
#include "butil/third_party/rapidjson/writer.h"
#include "butil/third_party/rapidjson/stringbuffer.h"

namespace Core {

    class CallbackStartService : public ServiceBaseInfo {
    public:
        // 默认构造函数
        CallbackStartService() = default;
        virtual ~CallbackStartService() = default;
        void initialize(ConfigXmlPtr xml) override;
        virtual void initialize_xml(ConfigXmlPtr xml);
        void initialize(GraphContextPtr context) override;
        int do_service(GraphContextPtr context) override;
        int _retry_cnt = 1;
        std::set<std::string> skip_white_list;

    private:
        int process(CallbackContextPtr context);
        std::string extract_query(const std::string &query);
        const int REQUEST_TYPE_CALLBACK = 1;

    public:
        virtual int check_data(CallbackContextPtr context);

        void CreateRankingRequest(const phx::CallbackRequest &request, CallbackContextPtr context);

        virtual int convert_proto(CallbackContextPtr context);

        void concat_feat(const ::google::protobuf::RepeatedPtrField<std::string> &src, std::string &value);
        void trans_lower(const CallbackContextPtr ctx, std::string &device_info);
        void get_skip_white_list(std::string white_list_str);

        void genContextFeat( FSContextPtr fs_ctx, const phx::PredictorRequest * req, const phx::CallbackRequest* callback_request);
        void addTrackExtFeat(const butil::rapidjson::Document& doc, phx::FeRequest* feature_dump, const std::string& rtFeatureName);

    };

}// namespace Core
