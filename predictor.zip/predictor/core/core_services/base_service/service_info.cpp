#include "core/core_services/base_service/service_info.h"
#include "core/core_context/context_defs.h"
#include "core/utils/defs.h"
#include <boost/algorithm/string.hpp>
namespace Core {
    ServiceBaseInfo::ServiceBaseInfo() : HLframe::Node(STRING_EMPTY) {
    }

    ServiceBaseInfo::~ServiceBaseInfo() {
    }

    void ServiceBaseInfo::report(CoreContextPtr context, const std::string &k, int v) {
        get_node_stat(context)->report_int(k, v);
    }

    void ServiceBaseInfo::report(CoreContextPtr context, const std::string &k, float v) {
        get_node_stat(context)->report_float(k, v);
    }

    void ServiceBaseInfo::report(CoreContextPtr context, const std::string &k, const std::string &v) {
        get_node_stat(context)->report_string(k, v);
    }

    const std::string &ServiceBaseInfo::get_channel_name() {
        return _service_channel_name;
    }

    ServiceProtoType ServiceBaseInfo::get_service_proto_type() {
        return _sivice_proto_type;
    }

    ServiceStage ServiceBaseInfo::get_service_stage() {
        return _service_stage;
    }

    void ServiceBaseInfo::init(ConfigXmlPtr xml) {
        xml->attr<std::string>("stage", _stage_type);
        _service_stage = ServiceConvertor::string2Stage(_stage_type);
        std::string proto_type;
        xml->attr<std::string>("proto", proto_type);
        _sivice_proto_type = ServiceConvertor::string2proto(proto_type);
        std::string predict_type;
        xml->attr<std::string>("predict", predict_type);
        _predict_type = stringToExperimentModelType(predict_type);
        HILOG_APP(INFO)<<get_name()<<",stage:"<<_stage_type<<",predict:"<<predict_type;
        initialize(xml);
    }

    void ServiceBaseInfo::initialize(ConfigXmlPtr xml) {
    }

    ExperimentModelType ServiceBaseInfo::get_predict_type(){
        return _predict_type;
    }

    StatItemPtr ServiceBaseInfo::get_node_stat(CoreContextPtr context) {
        return context->get_monitor_context()->get_node_stat(get_name());
    }

    void ServiceBaseInfo::gen_split_key(const std::string &model_name, int index, std::string &out) {
        out.append(model_name).append(_delimiter);
        out.append("ITEM_EMBEDDING").append(_delimiter);
        out.append(std::to_string(index));
    }

}// namespace Core
