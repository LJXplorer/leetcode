#pragma once
#include "core/core_context/core_context.h"
#include "hlframe/node.h"
namespace HLframe::c_adapter {
    void incr_batch_count(Node *node, Core::CoreContextPtr context, size_t n);
    bool is_split_finish(Node *node, std::shared_ptr<Core::CoreContext> ctx);
    bool is_split_finish(Node *node, std::unordered_map<Node *, std::shared_ptr<std::atomic<int>>> *node_split_num_map);

    void incr_batch_count(Node *node, std::unordered_map<Node *, std::shared_ptr<std::atomic<int>>> *node_split_num_map,
                          size_t n);
}// namespace HLframe::c_adapter