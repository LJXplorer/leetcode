
#include "core/core_services/base_service/call_back/call_back.h"
namespace Core {
    CallBack::CallBack(){

    }

    CallBack::~CallBack(){
    }

    int32_t CallBack::error_code(){
        return _cntl.ErrorCode();
    }

    void CallBack::set_local_info(){
        _local_ip_port = butil::ip2str(_cntl.local_side().ip)._buf;
        _local_ip_port.append(":");
        _local_ip_port.append(std::to_string(_cntl.local_side().port));
    }

    const std::string& CallBack::get_local_info(){
        return _local_ip_port;
    }

    void CallBack::set_remote_info(){
        _remote_ip_port = butil::ip2str(_cntl.remote_side().ip)._buf;
        _remote_ip_port.append(":");
        _remote_ip_port.append(std::to_string(_cntl.remote_side().port));
    }

    const std::string& CallBack::get_remote_info(){
        return _remote_ip_port;
    }
    
    brpc::Controller* CallBack::get_controller(){
            return &_cntl;
    }
}
