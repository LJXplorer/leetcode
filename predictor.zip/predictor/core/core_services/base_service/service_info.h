#ifndef _CORE_SERVICE_INFO_H
#define _CORE_SERVICE_INFO_H
#include "core/core_context/core_context.h"
#include "core/utils/service_pair.h"
#include "core/utils/util.h"
#include "hlframe/node.h"
#include <map>
#include <unordered_map>
namespace Core {
    enum SplitField {
        SPLIT_FIELD_MODEL_NAME,
        SPLIT_FIELD_MODEL_RULE,
        SPLIT_FIELD_MODEL_TYPE,
        SPLIT_FIELD_PREDICT_TYPE,
        SPLIT_FIELD_INDEX,
    };
    class ServiceBaseInfo : public HLframe::Node {
    public:
        ServiceProtoType _sivice_proto_type = SERVICE_PROTO_TYPE_UNKNOWN;
        ServiceStage _service_stage = SERVICE_STAGE_UNKNOWN;
        ExperimentModelType _predict_type = ExperimentModelType::MODEL_INFO_UNKNOWN;
        std::string _service_channel_name;
        std::string _delimiter = "$";
        std::string _stage_type;

    public:
        ServiceBaseInfo();
        ~ServiceBaseInfo();
        virtual bool skip(GraphContextPtr context) {
            return false;
        }

    public:
        virtual const std::string &get_channel_name();
        ServiceProtoType get_service_proto_type();
        ServiceStage get_service_stage();
        ExperimentModelType get_predict_type();
        virtual void init(ConfigXmlPtr xml);
        virtual void initialize(ConfigXmlPtr xml);
        void initialize(GraphContextPtr context) override{};
        virtual int process(CoreContextPtr context) {
            return 0;
        };
        void report(CoreContextPtr context, const std::string &k, int v);
        void report(CoreContextPtr context, const std::string &k, float v);
        void report(CoreContextPtr context, const std::string &k, const std::string &v);
        StatItemPtr get_node_stat(CoreContextPtr context);
        void gen_split_key(const std::string &model_name, int index, std::string &out);
    };

}// namespace Core

#endif
