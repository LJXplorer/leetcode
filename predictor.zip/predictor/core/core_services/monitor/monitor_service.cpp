#include "core/core_services/monitor/monitor_service.h"
#include "common/hilog/log_helper.h"
#include "core/core_context/context_defs.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/defs.h"
#include "core/utils/monitor_mgr.h"
#include <algorithm>
#include <boost/algorithm/string.hpp>
#include <cstdint>
#include <nlohmann/json.hpp>
#include <string>
#include <unordered_map>
#include "common/hidict/dict.h"

namespace Core {
    SERVICE_REGISTER(MonitorService);

    void MonitorService::initialize(ConfigXmlPtr xml) {
        initialize_xml(xml);
        std::string _dict_report_list_str;
        xml->attr<std::string>("dict_report_list", _dict_report_list_str);
        std::vector<string> _dict_report_list_tmp; 
        if (!_dict_report_list_str.empty()) {
            boost::split(_dict_report_list_tmp, _dict_report_list_str, boost::is_any_of(","));
            _dict_report_list = _dict_report_list_tmp;
        }
    }

    void MonitorService::initialize_xml(ConfigXmlPtr xml) {
    }

    void MonitorService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        return ctx->get_monitor_context()->alloc_node(get_name());
    }

    int MonitorService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int32_t ret = 0;
        try {
            ret = process(ctx);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << "do service fail: " << ret << "," << e.what();
        }
        HILOG_APP(INFO) << LOG_HEAD(ctx) << get_name() << " do_service ret:" << ret;
        return ret;
    }

    int MonitorService::process(CoreContextPtr ctx) {
        int ret = report(ctx);
        if (ret != ERROR_SUCCESS) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << " check_proto fail: " << ret;
            //report
            return ret;
        }
        return ERROR_SUCCESS;
    }

    template <typename DictType>
    const DictType* get_dict_data(const std::string &dict_name) {
        auto iter = AdDict::AdDictCollectorInstance::instance().get_dict(dict_name);
        if (!iter) {
            HILOG_APP(WARNING) << "dict not found in monitor: " << dict_name;
            return nullptr;
        }
        auto dict_map = iter->get_data<DictType>();

        if (!dict_map) {
            HILOG_APP(WARNING) << "dict_map is null for dict_name in monitor: " << dict_name;
            return nullptr;
        }

        return dict_map;
    }

    int MonitorService::report(CoreContextPtr ctx) {
        MonitorContextPtr _monitor_context_ptr = ctx->get_monitor_context();
        std::unordered_map<std::string, StatItemPtr> _stat_pair = _monitor_context_ptr->get_stat_pair();
        const std::string &upload_aggrated_slotid = ctx->GetUploadSlotName();
        const std::string &route = std::to_string(ctx->get_route());
        const string algo_sceneId = std::to_string(ctx->get_algo_scene_id());

        //上报总体耗时
        if (ctx->get_rank_request()->algoexperiments().empty()) {
            MonitorMgr::percent_report_stage(route, algo_sceneId, "DEFAULT", "flow", upload_aggrated_slotid,
                                             0, "flow_total_cost", ctx->_end_ts - ctx->_begin_ts);
        }
        else {
            for (auto &exp: ctx->get_rank_request()->algoexperiments()) {
                MonitorMgr::percent_report_stage(route, algo_sceneId, exp.targetedpolicy(), "flow", upload_aggrated_slotid,
                                                0, "flow_total_cost", ctx->_end_ts - ctx->_begin_ts);
            }
        }

        HILOG_APP(INFO) << LOG_HEAD(ctx) << "flow cost:" << (ctx->_end_ts - ctx->_begin_ts);

        auto total_cost = ctx->_end_ts - ctx->_begin_ts;

        //黄金指标
        int64_t start_cost = 0;
        int64_t user_total_cost = 0;
        int64_t item_cost = 0;
        int64_t interact_cost = 0;
        int64_t fe_cost = 0;
        int64_t predict_cost = 0;
        std::unordered_map<std::string, int64_t> predict_cost_map;
        int64_t done_cost = 0;
        std::unordered_map<std::string, int64_t> model_cost_map;
        std::string model_cost;
        std::unordered_map<std::string, int64_t> model_type_predict_cost;
        std::unordered_set<std::string> model_types;
        std::unordered_map<std::string, int64_t> model_type_start_time;
        std::unordered_map<std::string, int64_t> model_type_end_time;

        //上报阶段耗时
        for (auto &s: _stat_pair) {
            HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first << " cost:" << s.second->request_lat() << ":" << s.second->lat()
                            << "," << s.second->get_lat()->toString();
            const std::string &sceneId = std::to_string(ctx->get_algo_scene_id());
            if (ctx->get_rank_request()->algoexperiments().empty()) {
                MonitorMgr::percent_report_stage(route, sceneId, "DEFAULT", s.first, upload_aggrated_slotid,
                                                 0, "req_cost", s.second->request_lat());
                MonitorMgr::percent_report_stage(route, sceneId, "DEFAULT", s.first, upload_aggrated_slotid,
                                                 0, "rsp_cost", s.second->response_lat());
                MonitorMgr::percent_report_stage(route, sceneId, "DEFAULT", s.first, upload_aggrated_slotid,
                                                 0, "stage_total_cost", s.second->lat());

                if (!s.second->_l_extra_map.empty()) {
                    for (auto &l_ex: s.second->_l_extra_map) {
                        MonitorMgr::common_report_stage(route, sceneId, "DEFAULT", s.first,
                                                        upload_aggrated_slotid, 0, s.first + "_" + l_ex.first,
                                                        l_ex.second);
                        HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first << ":" << l_ex.first << ":" << l_ex.second;
                    }
                }

                if (!s.second->_f_extra_map.empty()) {
                    for (auto &f_ex: s.second->_f_extra_map) {
                        MonitorMgr::common_report_stage(route, sceneId, "DEFAULT", s.first,
                                                        upload_aggrated_slotid, 0, s.first + "_" + f_ex.first,
                                                        f_ex.second);
                        HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first << ":" << f_ex.first << ":" << f_ex.second;
                    }
                }
            }
            else {
                for (auto &exp: ctx->get_rank_request()->algoexperiments()) {

                    MonitorMgr::percent_report_stage(route, sceneId, exp.targetedpolicy(), s.first, upload_aggrated_slotid,
                                                    0, "req_cost", s.second->request_lat());
                    MonitorMgr::percent_report_stage(route, sceneId, exp.targetedpolicy(), s.first, upload_aggrated_slotid,
                                                    0, "rsp_cost", s.second->response_lat());
                    MonitorMgr::percent_report_stage(route, sceneId, exp.targetedpolicy(), s.first, upload_aggrated_slotid,
                                                    0, "stage_total_cost", s.second->lat());

                    if (!s.second->_l_extra_map.empty()) {
                        for (auto &l_ex: s.second->_l_extra_map) {
                            MonitorMgr::common_report_stage(route, sceneId, exp.targetedpolicy(), s.first,
                                                            upload_aggrated_slotid, 0, s.first + "_" + l_ex.first,
                                                            l_ex.second);
                            HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first << ":" << l_ex.first << ":" << l_ex.second;
                        }
                    }

                    if (!s.second->_f_extra_map.empty()) {
                        for (auto &f_ex: s.second->_f_extra_map) {
                            MonitorMgr::common_report_stage(route, sceneId, exp.targetedpolicy(), s.first,
                                                            upload_aggrated_slotid, 0, s.first + "_" + f_ex.first,
                                                            f_ex.second);
                            HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first << ":" << f_ex.first << ":" << f_ex.second;
                        }
                    }
                }
            }

            if (!s.second->_redis_extra_map.empty()) {
                for (auto &r: s.second->_redis_extra_map) {
                    //硬编码，解决featuredump service上报的兼容问题
                    if (s.first == "dump_value") {
                        HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first;
                        MonitorMgr::redis_report_percent(route, "feature_dump_value", r.second._ret, "redis_total_cost",
                                                         r.second._lat, r.second._source, algo_sceneId, STRING_TOTALUP);
                        MonitorMgr::redis_report_common(route, "feature_dump_value", r.second._ret, "fetch_num", 1,
                                                        r.second._source, algo_sceneId, STRING_TOTALUP);
                        if (r.second._ret == 0) {
                            MonitorMgr::redis_report_common(route, "feature_dump_value", r.second._ret,
                                                            "fetch_success_num", 1, r.second._source, algo_sceneId,
                                                            STRING_TOTALUP);
                        } else if (r.second._ret == -2) {
                            MonitorMgr::redis_report_common(route, "feature_dump_value", r.second._ret,
                                                            "fetch_not_fount_num", 1, r.second._source, algo_sceneId,
                                                            STRING_TOTALUP);
                        }
                    } else {
                        MonitorMgr::redis_report_percent(route, r.first, r.second._ret, "redis_total_cost",
                                                         r.second._lat, r.second._source, algo_sceneId, STRING_TOTALUP);
                        MonitorMgr::redis_report_common(route, r.first, r.second._ret, "fetch_num", 1, r.second._source,
                                                        algo_sceneId, STRING_TOTALUP);
                        MonitorMgr::redis_report_percent(route, r.first, r.second._ret, "redis_response_size",
                                                         r.second._redis_response_size, r.second._source, algo_sceneId,
                                                         STRING_TOTALUP);
                        MonitorMgr::redis_report_percent(route, r.first, r.second._ret, "redis_up_num",
                                                         r.second._up_size, r.second._source, algo_sceneId,
                                                         STRING_TOTALUP);
                        if (r.second._ret == 0) {
                            MonitorMgr::redis_report_common(route, r.first, r.second._ret, "fetch_success_num", 1,
                                                            r.second._source, algo_sceneId, STRING_TOTALUP);
                        } else if (r.second._ret == -2) {
                            MonitorMgr::redis_report_common(route, r.first, r.second._ret, "fetch_not_fount_num", 1,
                                                            r.second._source, algo_sceneId, STRING_TOTALUP);
                        }
                    }
                    HILOG_APP(INFO) << LOG_HEAD(ctx) << s.first << ":" << r.first << ":" << r.second._ret << ":"
                                    << r.second._lat;
                }
            }

            if (!s.second->_up_extra_map.empty()) {
                for (auto &r: s.second->_up_extra_map) {
                    MonitorMgr::redis_report_common(route, r.second._cluster_id, r.second._ret, "fetch_num", 1,
                                                    r.second._source, algo_sceneId, r.first);
                    MonitorMgr::redis_report_percent(route, r.second._cluster_id, r.second._ret,
                                                     "feature_response_size", r.second._response_size, r.second._source,
                                                     algo_sceneId, r.first);
                    MonitorMgr::redis_report_percent(route, r.second._cluster_id, r.second._ret, "feature_value_size",
                                                     r.second._feat_size, r.second._source, algo_sceneId, r.first);
                    if (r.second._ret == 0) {
                        MonitorMgr::redis_report_common(route, r.second._cluster_id, r.second._ret, "fetch_success_num",
                                                        1, r.second._source, algo_sceneId, r.first);
                    } else if (r.second._ret == -2) {
                        MonitorMgr::redis_report_common(route, r.second._cluster_id, r.second._ret,
                                                        "fetch_not_fount_num", 1, r.second._source, algo_sceneId,
                                                        r.first);
                    }
                }
            }

            if (!s.second->_adjusted_extra_map.empty()) {
                for (auto &a: s.second->_adjusted_extra_map) {
                    MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "DEFAULT", a.first + "_adjusted_num",
                                                   a.second._adj_cnt);
                    MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "DEFAULT", a.first + "_total_num",
                                                   a.second._total_cnt);
                }
            }
        }
        MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "request_cnt", 1);
        MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "req_item_size",
                                       ctx->_bak_request.predictorslotinfo().predictoriteminfos_size());
        if (ctx->_prerank_context_ptr != nullptr && ctx->_prerank_context_ptr->GetUsePrerank()) {
            //以 广告位 上报 走粗排次数 +1
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "prerank_times", 1.0);
            //以 广告位 上报 进粗排的广告数
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "prerank_candidate_num",
                                           static_cast<double>(ctx->_ads_map.size()));

            //以 广告位 上报 截断服务 选中数量（即精排候选数） 和 丢弃数量
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "truncated_ads_num",
                                           static_cast<double>(ctx->_report_info->truncated_ads_num));
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "discarded_ads_num",
                                           static_cast<double>(ctx->_report_info->discarded_ads_num));

            //以 广告位 上报 截断模块保位
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "new_ads_added_num",
                                           static_cast<double>(ctx->_report_info->new_ads_added_num));
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "new_ads_not_added_num",
                                           static_cast<double>(ctx->_report_info->new_ads_not_added_num));
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "fallback_added_num",
                                           static_cast<double>(ctx->_report_info->fallback_added_num));
            //以 广告位 上报 截断模块各阶段选中和丢弃的广告个数
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "reserved_after_truncate_num",
                                           static_cast<double>(ctx->_report_info->reserved_after_truncate_num));
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "discarded_after_truncate_num",
                                           static_cast<double>(ctx->_report_info->discarded_after_truncate_num));
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "reserved_after_hold_num",
                                           static_cast<double>(ctx->_report_info->reserved_after_hold_num));
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "discarded_after_hold_num",
                                           static_cast<double>(ctx->_report_info->discarded_after_hold_num));
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "reserved_after_fallback_num",
                                           static_cast<double>(ctx->_report_info->reserved_after_fallback_num));
            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "discarded_after_fallback_num",
                                           static_cast<double>(ctx->_report_info->discarded_after_fallback_num));

            float abs_sum = std::accumulate(ctx->get_prerank_context()->UserEmbeddingVec().begin(),
                                            ctx->get_prerank_context()->UserEmbeddingVec().end(), 0.0f,
                                            [](float acc, float val) { return acc + std::fabs(val); });
            
            int user_emb_size=ctx->get_prerank_context()->UserEmbeddingVec().size();
            MonitorMgr::common_report_model(ctx->get_prerank_context()->user_emb_model_name_, upload_aggrated_slotid,
                                            std::to_string(ctx->get_algo_scene_id()), "default", 0, "user_emb_abs_avg",
                                            abs_sum/user_emb_size);
            MonitorMgr::common_report_model(ctx->get_prerank_context()->user_emb_model_name_, upload_aggrated_slotid,
                                            std::to_string(ctx->get_algo_scene_id()), "default", 0, "user_emb_size",
                                            user_emb_size);
            MonitorMgr::common_report_model(ctx->get_prerank_context()->user_emb_model_name_, upload_aggrated_slotid,
                                            std::to_string(ctx->get_algo_scene_id()), "default", 0, "user_emb_req_num",
                                            1);
        }
        // 按位预估监控

        size_t model_info_vec_size = ctx->_model_info_vec.size();
        for (int i = 0; i < model_info_vec_size; ++i) {
            auto model_info = ctx->_model_info_vec[i]->_model_info;
            if (!model_info->_multi_pos_flag && ctx->get_pctr_in_pos_num() != 0) {
                if (ctx->_model_info_vec[i]->_model_type == Core::ExperimentModelType::CPD_CTR) {
                    MonitorMgr::common_report_model(// 上推下发的pctrInPosNum
                            model_info->_model_name, upload_aggrated_slotid, algo_sceneId, "default", 0,
                            "pctr_in_pos_num", ctx->get_pctr_in_pos_num());
                    // 商推下发了广告位的位置数，但模型配置的是非多位置预估模型
                    MonitorMgr::common_report_model(model_info->_model_name, upload_aggrated_slotid, algo_sceneId,
                                                    "default", 0, "pos_req_not_pos_model", 1);
                    MonitorMgr::common_report_model(model_info->_model_name, upload_aggrated_slotid, algo_sceneId,
                                                    "default", 0, "pos_req_cnt", 1);
                }
            } else if (model_info->_multi_pos_flag) {
                MonitorMgr::common_report_model(model_info->_model_name, upload_aggrated_slotid, algo_sceneId,
                                                "default", 0, "pos_req_cnt", 1);

                int64_t pctr_in_pos_num = ctx->get_pctr_in_pos_num();
                int64_t model_pos_num = model_info->get_adunit_pos_info(ctx->get_slot_id());

                MonitorMgr::common_report_model(model_info->_model_name, upload_aggrated_slotid, algo_sceneId,
                                                "default", 0, "pctr_in_pos_num", pctr_in_pos_num);

                if (model_pos_num == -1) {
                    if (pctr_in_pos_num > 0) {//商推下发了广告位的位置数，但模型没有配置该广告位的位置数
                        MonitorMgr::common_report_model(model_info->_model_name, upload_aggrated_slotid, algo_sceneId,
                                                        "default", 0, "pos_req_but_adunit_not_in_model", 1);
                    }
                } else {
                    if (pctr_in_pos_num == 0) {//模型配置了该广告位的位置数，但商推下发的广告位位置数为0
                        MonitorMgr::common_report_model(model_info->_model_name, upload_aggrated_slotid, algo_sceneId,
                                                        "default", 0, "adunit_in_model_but_req_pos_zero", 1);
                    } else if (pctr_in_pos_num > 0 && pctr_in_pos_num < model_pos_num) {
                        // 商推下发了广告位的位置数，但下发的位置数<模型配置的位置数
                        MonitorMgr::common_report_model(model_info->_model_name, upload_aggrated_slotid, algo_sceneId,
                                                        "default", 0, "req_pos_zero_less_pos_in_model", 1);
                    }
                }
            }
        }

        auto infer_context = ctx->get_infer_context();
        if (infer_context != nullptr) {
            for (const auto &[predict_type, split_map]: infer_context->_split_map) {
                switch (predict_type) {
                    case Core::ExperimentModelType::CPC_CTR:
                    case Core::ExperimentModelType::CPD_CTR: {
                        for (const auto &[exp_model_info, model_infer]: split_map) {

                            for (const auto &[index, infer_pair]: model_infer._infer_pairs) {
                                int item_cnt = infer_pair._end_index - infer_pair._start_index + 1;
                                float pctr_sum = infer_pair._pctr_scores;

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_ctr_score", pctr_sum);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_ctr_success_count",
                                                               infer_pair._predict_ctr_success_cnt);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_ctr_count", infer_pair._predict_ctr_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "pctr_scores", pctr_sum);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "ctr_count",
                                                                infer_pair._predict_ctr_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "ctr_success_count",
                                                                infer_pair._predict_ctr_success_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "item_cnt", item_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", infer_pair._ret, "req_num", 1);

                                if (infer_pair._ret == 0) {
                                    MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                    algo_sceneId, "default", 0, "model_success", 1);
                                }

                                if (infer_pair._ret == 1008) {
                                    MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                    algo_sceneId, "default", 1008, "model_time_out", 1);
                                }

                                MonitorMgr::common_report_model(
                                        exp_model_info->_model_name, upload_aggrated_slotid, algo_sceneId, "default", 0,
                                        "model_convtype_no_find_num", infer_pair._model_no_optput);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "zero_ctr",
                                                                infer_pair._zero_ctr);

                                if (exp_model_info->_model_info->_multi_pos_flag && !infer_pair._pos_score.empty()) {
                                    int pos_vec_size = infer_pair._pos_score.size();
                                    for (int i = 1; i <= pos_vec_size; ++i) {
                                        float pos_scores = infer_pair._pos_score[i - 1];
                                        MonitorMgr::common_report_model(
                                                exp_model_info->_model_name, upload_aggrated_slotid, algo_sceneId,
                                                std::to_string(i), 0, "pctr_scores", pos_scores);
                                        MonitorMgr::common_report_model(exp_model_info->_model_name,
                                                                        upload_aggrated_slotid, algo_sceneId,
                                                                        std::to_string(i), 0, "item_cnt", item_cnt);
                                    }
                                }
                            }

                            MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                            algo_sceneId, "default", 0, "model_req_num", 1);

                            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "slot_ctr_req_num",
                                                           1);
                        }
                        break;
                    }
                    case Core::ExperimentModelType::CPC_CVR:
                    case Core::ExperimentModelType::CPD_CVR: {
                        for (const auto &[exp_model_info, model_infer]: split_map) {
                            for (const auto &[index, infer_pair]: model_infer._infer_pairs) {
                                float pcvr_sum = infer_pair._pcvr_scores;
                                float pdcvr_sum = infer_pair._pdcvr_scores;
                                float pecvr_sum = infer_pair._pecvr_scores;
                                float cvr_success_cnt = infer_pair._predict_cvr_success_cnt;
                                float dcvr_success_cnt = infer_pair._predict_deep_cvr_success_cnt;
                                float ecvr_success_cnt = infer_pair._predict_enhance_cvr_success_cnt;
                                float cvr_cnt = infer_pair._predict_cvr_cnt;
                                float dcvr_cnt = infer_pair._predict_deep_cvr_cnt;
                                float ecvr_cnt = infer_pair._predict_enhance_cvr_cnt;
                                int32_t item_cnt_pair = infer_pair._end_index - infer_pair._start_index + 1;

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_cvr_score", pcvr_sum);
                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_dcvr_score", pdcvr_sum);
                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_ecvr_score", pecvr_sum);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_cvr_success_count", cvr_success_cnt);
                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_deep_cvr_success_count", dcvr_success_cnt);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_enhance_cvr_success_count", ecvr_success_cnt);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_cvr_count", infer_pair._predict_cvr_cnt);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_deep_cvr_count", infer_pair._predict_deep_cvr_cnt);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_enhance_cvr_count",
                                                               infer_pair._predict_enhance_cvr_cnt);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_cvr1_score", infer_pair._pcvr1_scores);
                                
                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_cvr1_success_count", infer_pair._predict_pcvr1_success_cnt);
                                
                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_cvr1_count", infer_pair._predict_pcvr1_cnt);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_cvr2_score", infer_pair._pcvr2_scores);
                                
                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_cvr2_success_count", infer_pair._predict_pcvr2_success_cnt);
                                
                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_cvr2_count", infer_pair._predict_pcvr2_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "pcvr_scores", pcvr_sum);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "pdcvr_scores", pdcvr_sum);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "pecvr_scores", pecvr_sum);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "cvr_success_count",
                                                                cvr_success_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "deep_cvr_success_count",
                                                                dcvr_success_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "enhance_cvr_success_count",
                                                                ecvr_success_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "cvr_count", cvr_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "deep_cvr_count", dcvr_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "enhance_cvr_count",
                                                                ecvr_cnt);

                                MonitorMgr::common_report_model(
                                        exp_model_info->_model_name, upload_aggrated_slotid, algo_sceneId, "default", 0,
                                        "model_convtype_no_find_num", infer_pair._model_no_optput);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "zero_cvr",
                                                                infer_pair._zero_cvr);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "zero_dcvr",
                                                                infer_pair._zero_dcvr);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "zero_ecvr",
                                                                infer_pair._zero_ecvr);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "item_cnt", item_cnt_pair);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", infer_pair._ret, "req_num", 1);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid, algo_sceneId, "default", 0, 
                                                                "pcvr1_scores", infer_pair._pcvr1_scores);
                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid, algo_sceneId, "default", 0, 
                                                                "pcvr2_scores", infer_pair._pcvr2_scores);
                                
                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "cvr1_count", infer_pair._predict_pcvr1_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "cvr2_count", infer_pair._predict_pcvr2_cnt);
                                
                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "zero_cvr1",
                                                                infer_pair._zero_pcvr1);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "zero_cvr2",
                                                                infer_pair._zero_pcvr2);

                                if (infer_pair._ret == 0) {
                                    MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                    algo_sceneId, "default", 0, "model_success", 1);
                                }

                                if (infer_pair._ret == 1008) {
                                    MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                    algo_sceneId, "default", 1008, "model_time_out", 1);
                                }
                            }

                            MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                            algo_sceneId, "default", 0, "model_req_num", 1);

                            MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "slot_cvr_req_num",
                                                           1);
                        }

                        break;
                    }
                    case Core::ExperimentModelType::LTV: {
                        for(const auto& [exp_model_info, model_infer] : split_map) {
                            for(const auto& [index, infer_pair] : model_infer._infer_pairs) {
                                int32_t item_cnt_pair = infer_pair._end_index - infer_pair._start_index + 1;
                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid, algo_sceneId, "default", 0, "ltv1_scores", infer_pair._ltv1_scores);
                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid, algo_sceneId, "default", 0, "ltv2_scores", infer_pair._ltv2_scores);
                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid, algo_sceneId, "default", 0, "item_cnt", item_cnt_pair);
                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid, algo_sceneId, "default", 0, 
                                                                "zero_ltv1", infer_pair._zero_ltv1);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "zero_ltv2",
                                                                infer_pair._zero_ltv2);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "ltv1_count", infer_pair._predict_ltv1_cnt);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "ltv2_count", infer_pair._predict_ltv2_cnt);
                                
                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                            algo_sceneId, "default", 0, "model_req_num", 1);
                                
                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", infer_pair._ret, "req_num", 1);

                                MonitorMgr::common_report_model(
                                        exp_model_info->_model_name, upload_aggrated_slotid, algo_sceneId, "default", 0,
                                        "model_convtype_no_find_num", infer_pair._model_no_optput);
                                
                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "zero_ltv1",
                                                                infer_pair._zero_ltv1);

                                MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                algo_sceneId, "default", 0, "zero_ltv2",
                                                                infer_pair._zero_ltv2);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default", "slot_ltv_req_num",
                                                           1);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_ltv1_score", infer_pair._ltv1_scores);
                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_ltv2_score", infer_pair._ltv2_scores);

                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_ltv1_success_count", infer_pair._predict_ltv1_success_cnt);
                                
                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_ltv2_success_count", infer_pair._predict_ltv2_success_cnt);
                                
                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_ltv1_count", infer_pair._predict_ltv1_cnt);
                                
                                MonitorMgr::common_report_slot(route, upload_aggrated_slotid, "default",
                                                               "slot_ltv2_count", infer_pair._predict_ltv2_cnt);

                                if(infer_pair._ret == 1008) {
                                    MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                    algo_sceneId, "default", 1008, "model_time_out", 1);
                                } else if(infer_pair._ret == 0) {
                                    MonitorMgr::common_report_model(exp_model_info->_model_name, upload_aggrated_slotid,
                                                                    algo_sceneId, "default", 1008, "model_time_out", 1);
                                }
                            }
                        }
                    }

                    // todo ltv
                    default:
                        break;
                }
            }
        }
        

        report_req_dict_find_ratio(ctx);

        
        return ERROR_SUCCESS;
    }

    static std::unordered_map<std::string, std::function<const void*(const std::string&)>> type_map = {
        {"AppinfoDict", [](const std::string &path) -> const void* {
                return get_dict_data<AdDict::appinfo_dict_type>(path);
            }},
        {"AdinfoDict",  [](const std::string &path) -> const void* {
                return get_dict_data<AdDict::adinfo_dict_type>(path);
            }}
        // 后续有其他词典在这里加
    };

    void MonitorService::report_req_dict_find_ratio(CoreContextPtr ctx) {

        std::vector<DictStat> dict_stats;
        dict_stats.reserve(_dict_report_list.size());
        if(_dict_report_list.empty()) return;

        for (const auto& dict_path : _dict_report_list) {
            DictStat stat;
            stat.dict_info = AdDict::AdDictCollectorInstance::instance().get_dict(dict_path);
            if (stat.dict_info) {
                auto it = type_map.find(stat.dict_info->m_clazz_name);
                if (it != type_map.end()) {
                    stat.dict_map = it->second(stat.dict_info->m_path);
                }
            }
            dict_stats.push_back(std::move(stat));
        }

        for (auto& item : ctx->get_rank_request()->predictorslotinfo().predictoriteminfos()) {
            for (auto& stat : dict_stats) {
                if (!stat.dict_map) continue;

                if (stat.dict_info->m_clazz_name == "AppinfoDict") {
                    stat.total_set.insert(item.appid());
                    if (static_cast<const AdDict::appinfo_dict_type*>(stat.dict_map)->count(item.appid())) {
                        stat.finded_set.insert(item.appid());
                    }
                } else if (stat.dict_info->m_clazz_name == "AdinfoDict") {
                    stat.total_set.insert(item.creativeid());
                    if (static_cast<const AdDict::adinfo_dict_type*>(stat.dict_map)->count(item.creativeid())) {
                        stat.finded_set.insert(item.creativeid());
                    }
                }
            }
        }

        for (auto& stat : dict_stats) {
            if (!stat.dict_info) continue;
            MonitorMgr::common_report_dict(stat.dict_info->m_clazz_name, stat.dict_info->m_path,
                                        stat.dict_info->get_latest_version(), 0,
                                        "dict_req_find_num", stat.finded_set.size());
            MonitorMgr::common_report_dict(stat.dict_info->m_clazz_name, stat.dict_info->m_path,
                                        stat.dict_info->get_latest_version(), 0,
                                        "dict_req_total_num", stat.total_set.size());
            HILOG_APP(INFO) << "dict_name: " << stat.dict_info->m_clazz_name
                            << ", dict version: " << stat.dict_info->get_latest_version()
                            << ", find num: " << stat.finded_set.size()
                            << ", total num: " << stat.total_set.size();
        }

        return;
    }

}// namespace Core
