#ifndef _CORE_SERVICES_MONITOR_H
#define _CORE_SERVICES_MONITOR_H
#include "core/core_services/base_service/service_info.h"
#include "core/core_context/core_context.h"
#include "common/monitor/monitors.h"
#include "common/hidict/dict.h"
namespace Core {
    struct DictStat {
        hidict::DictInfo* dict_info = nullptr;
        const void* dict_map = nullptr;
        std::unordered_set<int64_t> total_set;
        std::unordered_set<int64_t> finded_set;
    };
    class MonitorService : public ServiceBaseInfo{
    public:
        MonitorService() {  
        }

        ~MonitorService(){

        }

        virtual void initialize(ConfigXmlPtr xml);
        virtual void initialize_xml(ConfigXmlPtr xml);
        virtual void initialize(GraphContextPtr context);
        virtual int do_service(GraphContextPtr context);
    private:
        int process(CoreContextPtr context);
        void report_req_dict_find_ratio(CoreContextPtr ctx);
        std::vector<std::string> _dict_report_list;
        // static std::string GetUploadSlotName(CoreContextPtr context);//转移到Context类中实现
    public:
        virtual int report(CoreContextPtr context);

    };
    
}

#endif
