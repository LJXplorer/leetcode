
#include "core/core_server/core_server.h"
#include "common/hikafka/kafka_helper.h"
#include "common/hilog/log_helper.h"
#include "common/hipolaris/polaris_naming_service.h"
#include "core/core_context/core_context.h"
#include "core/core_server/callback_imp.h"
#include "core/core_server/debug/debug_imp.h"
#include "core/core_server/predict_imp.h"
#include "core/core_server/embedding_imp.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/dict/dict_mgr.h"
#include "core/core_services/dump/dump_log_manager/dump_log_manager.h"
#include "core/core_services/dump/dump_manager/dump_manager.h"
#include "core/core_services/dump/dump_redis_manager/dump_redis_manager.h"
#include "core/core_services/dump/feature_dump_retry_manager/featuredump_retry_manager.h"
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "core/core_services/fs/fetch/fetch_manager.h"
#include "core/core_services/fs/redis_client/redis_client_manager.h"
#include "core/core_services/policy/customize_loadbalancer.h"
#include "core/utils/defs.h"
#include "core/utils/error.h"
#include "core/utils/monitor_mgr.h"
#include "core/utils/util.h"
#include "hlframe/graph_manager.h"
#include "hlframe/gtransport_manager.h"
#include "hlframe/node_manager.h"
#include "polaris_register.h"
#include <brpc/load_balancer.h>
#include <debug_utils.h>
#include <gflags/gflags.h>
#include <gflags/gflags_declare.h>
#include <iostream>
#include <memory>
#include <string>
#include <thread_pool.h>

// 全局状态管理
std::atomic_flag g_sig_lock = ATOMIC_FLAG_INIT;
// 异步安全的信号处理器
void signal_handler(int sig) {
    // 自旋锁防止重入
    if (g_sig_lock.test_and_set(std::memory_order_acquire))
        return;
    Core::PolarisRegister::instance().deregister_from_polaris();
    g_sig_lock.clear(std::memory_order_release);
}

// 初始化信号处理
void setup_signal_handlers() {
    struct sigaction sa {};
    sa.sa_handler = signal_handler;
    sa.sa_flags = SA_RESTART | SA_NODEFER;
    sigemptyset(&sa.sa_mask);

    const int signals[] = {SIGTERM, SIGQUIT};
    for (int sig: signals) {
        if (sigaction(sig, &sa, nullptr) == -1) {
            exit(EXIT_FAILURE);
        }
    }
}

namespace brpc {
    //配置channel为pooled连接时的最大连接数
    DECLARE_int32(max_connection_pool_size);
    DECLARE_int32(socket_send_buffer_size);
}// namespace brpc

namespace brpc::policy {

    DEFINE_string(polaris_cluster, "default", "Polaris cluster name");
    DEFINE_string(polaris_name_space, "default", "Polaris name_space");
    DEFINE_int32(polaris_timeout_ms, 3000, "Timeout for polaris requests");
    DEFINE_string(polaris_cache, "$HOME/polaris/backup", "polaris cache dir ");
    DEFINE_string(polaris_service_refresh_interval, "2s", "");
    DEFINE_string(polaris_service_expire_time, "24h", "");
    DEFINE_int32(polaris_refresh_ms, 1000, "brpc naming service thread refresh time");

}// namespace brpc::policy

namespace Core {

    DEFINE_string(env, "", "env");
    DEFINE_string(conf_path, "./conf/", "server conf");
    DEFINE_string(server_xml, "/server.xml", "server conf");
    DEFINE_string(server_version, "", "server version");
    DEFINE_string(nacos_xml, "nacos_config.xml", "nacos conf");
    //DEFINE_int32(minloglevel, 0, "glog level");
    DEFINE_string(debug_file_cos_conf_path, "./conf/debug_info_cos_config.json", "Path of the cos bucket conf");
    // DEFINE_string(debug_file_bucket_name, "mlops-test-bj-data-1311274267", "The name of the cos bucket where the debugging information is written");//测试用cos桶名
    DEFINE_string(debug_file_bucket_name, "cloud-predictor-debug-1311258067",
                  "The name of the cos bucket where the debugging information is written");//正式用cos桶名

    DEFINE_string(debug_file_bucket_path_prefix, "debug_info/", "debug file path prefix");
    DEFINE_uint64(debug_file_expire_days, 7, "Expiration time of debug information files (in days)");//1 for test

    DEFINE_string(az_info, "default", "zone of tencent cloud");
    // 提供 pod 元信息的 gflags
    DEFINE_string(pod_name, "", "pod name for dict push and monitor");
    DEFINE_string(pod_ip, "", "pod ip for dict push and monitor");

    CoreServer::CoreServer() {
    }

    CoreServer::~CoreServer() {
    }

    int CoreServer::init(int argc, char *argv[]) {
        google::ParseCommandLineFlags(&argc, &argv, true);
        if (FLAGS_conf_path.empty()) {
            std::cerr << "config path empty" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        }
        ServiceConvertor::registerStage();

        if (ServerConfig::init_nacos_config(FLAGS_conf_path + FLAGS_nacos_xml) != ERROR_SUCCESS) {
            std::cerr << FLAGS_conf_path << "," << FLAGS_server_xml << ",server xml parse fail" << std::endl;
            return ERROR_SYS_SERVER_PARSE_FAIL;
        }

        brpc::policy::FLAGS_polaris_cluster = ServerConfig::_polaris_cluster;
        brpc::policy::FLAGS_polaris_name_space = ServerConfig::_polaris_namespace_name;
        brpc::policy::FLAGS_polaris_cache = ServerConfig::_polaris_cache;
        brpc::policy::FLAGS_polaris_timeout_ms = ServerConfig::_polaris_connect_timeout_ms;
        brpc::policy::FLAGS_polaris_service_refresh_interval = ServerConfig::_polaris_service_refresh_interval;
        brpc::policy::FLAGS_polaris_service_expire_time = ServerConfig::_polaris_service_expire_time;
        brpc::policy::FLAGS_polaris_refresh_ms = ServerConfig::_brpc_naming_refresh_time;
        const char *campus = getenv(Core::campus.c_str());
        if (campus != nullptr) {
            FLAGS_az_info = campus;
        }

        auto polaris_naming_service = new brpc::policy::PolarisNamingService();
        brpc::NamingServiceExtension()->RegisterOrDie("polaris", polaris_naming_service);
        auto customizeLoadBalancer = new brpc::policy::CustomizeLoadBalancer();
        brpc::LoadBalancerExtension()->RegisterOrDie("cb", customizeLoadBalancer);
        
        config::ConfigServiceCfg cfg{.server_adder = ServerConfig::_server_adder,
                                     .auth_user_name = ServerConfig::_auth_user_name,
                                     .auth_passwd = ServerConfig::_auth_passwd,
                                     .name_space = ServerConfig::_name_space};

        if (ServerConfig::new_init(cfg, ServerConfig::_server_group_id, ServerConfig::_server_data_id) !=
            ERROR_SUCCESS) {
            std::cerr << "server nacos failed!" << std::endl;
            return ERROR_SYS_SERVER_PARSE_FAIL;
        }

        if (HLframe::NodeManager::instance().new_init(cfg, ServerConfig::_node_group_id, ServerConfig::_node_data_id) !=
            ERROR_SUCCESS) {
            std::cerr << "node xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        }

        if (HLframe::GraphManager::instance().new_init(cfg, ServerConfig::_graph_group_id,
                                                       ServerConfig::_graph_data_id) != ERROR_SUCCESS) {
            std::cerr << "graph xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        }

        std::cout << "event_dispatcher_num:" << ServerConfig::_event_dispatcher_num << std::endl;
        auto set_event_dispatcher_num_result = google::SetCommandLineOption(
                "event_dispatcher_num", std::to_string(ServerConfig::_event_dispatcher_num).c_str());
        if (set_event_dispatcher_num_result.empty()) {
            std::cout << "set event_dispatcher_num fquailed!";
        } else {
            std::cout << "set event_dispatcher_num success,ret = " << set_event_dispatcher_num_result << std::endl;
        }

        std::cout << "bvar_latency_p1" << gflags::SetCommandLineOption("bvar_latency_p1", "10") << endl;
        if (!ServerConfig::_monitor_sys_collect_id.empty() || !ServerConfig::_monitor_biz_collect_id.empty() ||
            !ServerConfig::_monitor_slot_collect_id.empty() || !ServerConfig::_monitor_redis_collect_id.empty()) {
            std::cout << ServerConfig::_monitor_sys_collect_id << "," << ServerConfig::_monitor_biz_collect_id << ","
                      << ServerConfig::_monitor_slot_collect_id << "," << ServerConfig::_monitor_redis_collect_id
                      << std::endl;
            if (!ServerConfig::_monitor_project_id.empty()) {
                monitor::MonitorManager::project_id = ServerConfig::_monitor_project_id;
            }
            if (!ServerConfig::_monitor_log_path.empty()) {
                monitor::details::MonitorLogger::monitor_log_path = ServerConfig::_monitor_log_path;
            }
            if (!ServerConfig::_bigdata_log_path.empty()) {
                monitor::details::MonitorLogger::bigdata_log_path = ServerConfig::_bigdata_log_path;
            }
            MonitorMgr::init(ServerConfig::_monitor_service_name, ServerConfig::_monitor_biz_collect_id,
                             ServerConfig::_monitor_slot_collect_id, ServerConfig::_monitor_sys_collect_id,
                             ServerConfig::_monitor_redis_collect_id,ServerConfig::_monitor_dict_collect_id);
            DumpLogManager::instance().init();
        }

        // if (Core::AdDictConfigMgr::instance().init(cfg, ServerConfig::_dict_group_id,
        //                                                ServerConfig::_dict_data_id) != ERROR_SUCCESS) {
        //     std::cerr << "dict xml parse fail" << std::endl;
        //     return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        // }

        // if (Core::Info::ModelInfoManager::instance().init(cfg, ServerConfig::_model_info_group_id,
        //                                                ServerConfig::_model_info_data_id) != ERROR_SUCCESS) {
        //     std::cerr << "model_info xml parse fail" << std::endl;
        //     return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        // }else{
        //     std::cerr << "ModelInfoManager init success" << std::endl;
        // }

        FetchManager::instance().init(ServerConfig::_fetch_path);
        RedisClientManager::instance().init(ServerConfig::_redis_path);
        // DumpRedisManager::instance().init();
        // DumpManager::instance().init();
        hikafka::KafkaHelper::getInstance().new_init(cfg, ServerConfig::_kafka_group_id, ServerConfig::_kafka_data_id);

        return initialize(argc, argv);
    }

    // 初始化特征拉取，KafKa等功能模块
    int CoreServer::initialize(int argc, char *argv[]) {
        return 0;
    }

    int CoreServer::start(int argc, char *argv[]) {

        int ret = init(argc, argv);

        std::cout << "core server init ret:" << ret << std::endl;

        if (ret != ERROR_SUCCESS) {
            std::cerr << "init fail:" << ret;
            return ret;
        }

        brpc::FLAGS_max_connection_pool_size = ServerConfig::_max_connection_pool_size;
        brpc::FLAGS_socket_send_buffer_size = ServerConfig::_socket_send_buffer_size;

        load_prerank();
        load_recall();
        std::cerr << "init ret:" << ret << std::endl;
        PredictImp predict_imp;
        if (_server.AddService(&predict_imp, brpc::SERVER_DOESNT_OWN_SERVICE) != ERROR_SUCCESS) {
            std::cerr << "AddService [PredictImp] fail, -1";
            return -1;
        }

        CallbackImp callback_imp;
        if (_server.AddService(&callback_imp, brpc::SERVER_DOESNT_OWN_SERVICE) != ERROR_SUCCESS) {
            std::cerr << "AddService [callback] fail, -1";
            return -1;
        }

        DebugServiceImp debug_imp;
        if (ServerConfig::_debug_enable) {
            if (_server.AddService(&debug_imp, brpc::SERVER_DOESNT_OWN_SERVICE) != ERROR_SUCCESS) {
                std::cerr << "AddService [DebugServiceImp] fail, -1";
                return -1;
            }
        }

        // 向量召回服务
        EmbeddingImp embedding_imp;
        if (_server.AddService(&embedding_imp, brpc::SERVER_DOESNT_OWN_SERVICE) != ERROR_SUCCESS) {
            std::cerr << "AddService [EmbeddingImp] fail, -1";
            return -1;
        }

        _server_options.num_threads = ServerConfig::_server_num_thread;
        if (_server.Start(ServerConfig::_server_port, &_server_options) != ERROR_SUCCESS) {
            std::cerr << "Start server failed! -2";
            return -2;
        }
        std::cerr << "server addir:" << ServerConfig::_server_ip_port << ",num_threads:" << _server_options.num_threads
                  << std::endl;

        _server.set_version(FLAGS_server_version);
        //服务注册
        PolarisRegister::instance().init();
        setup_signal_handlers();

        _server.Join();

        return 0;
    }
    int CoreServer::load_prerank() {
        std::cout << "----------> skip prerank module!!! <-----------" << std::endl;
        return 0;
    }

    int CoreServer::load_recall() {
        std::cout << "----------> skip recall module!!! <-----------" << std::endl;
        return 0;
    }

}// namespace Core
