#ifndef _CORE_SERVER_H
#define _CORE_SERVER_H
#include "brpc/server.h"
#include "common/comm/thread_pool.h"
#include "gflags/gflags.h"
#include <boost/asio/thread_pool.hpp>
#include <memory>
namespace Core {

    //static boost::asio::thread_pool g_dump_task_exector {8};

    class CoreServer {
    private:
        brpc::Server _server;
        brpc::ServerOptions _server_options;
        std::shared_ptr<common::PeriodicTask> _offline_embedding_task;

    public:
        CoreServer();
        ~CoreServer();
        virtual int init(int argc, char *argv[]);
        virtual int initialize(int argc, char *argv[]);
        virtual int load_prerank();
        virtual int load_recall();

    public:
        int start(int argc, char *argv[]);
    };

}// namespace Core

#endif
