#include "core/core_server/server_config/server_config.h"
#include "common/config/config_manager.h"
#include "common/config/error_code.h"
#include "common/hilog/log_helper.h"
#include "common/hidict/dict_counters_provider.h"
#include "core/core_services/dict/dict_push.h"
#include "core/utils/error.h"
#include "core/utils/util.h"
#include <boost/algorithm/string.hpp>
#include <cstdint>
#include <glog/logging.h>
#include <iostream>
#include <unordered_set>

namespace Core {

    std::string ServerConfig::_server_adder;
    std::string ServerConfig::_auth_user_name;
    std::string ServerConfig::_auth_passwd;
    std::string ServerConfig::_name_space;

    std::string ServerConfig::_server_group_id;
    std::string ServerConfig::_server_data_id;
    std::string ServerConfig::_graph_group_id;
    std::string ServerConfig::_graph_data_id;
    std::string ServerConfig::_node_group_id;
    std::string ServerConfig::_node_data_id;
    std::string ServerConfig::_redis_group_id;
    std::string ServerConfig::_redis_data_id;
    std::string ServerConfig::_fetch_group_id;
    std::string ServerConfig::_fetch_data_id;
    std::string ServerConfig::_kafka_group_id;
    std::string ServerConfig::_kafka_data_id;
    std::string ServerConfig::_model_info_group_id;
    std::string ServerConfig::_model_info_data_id;
    std::string ServerConfig::_model_rule_group_id;
    std::string ServerConfig::_model_rule_data_id;
    std::string ServerConfig::_dict_group_id;
    std::string ServerConfig::_dict_data_id;

    std::string ServerConfig::_app_name;
    std::string ServerConfig::_server_name;
    std::string ServerConfig::_server_ip;
    std::string ServerConfig::_server_ip_port;
    int32_t ServerConfig::_server_port = 3200;
    int32_t ServerConfig::_server_num_thread = 0;
    int32_t ServerConfig::_event_dispatcher_num = 1;

    std::string ServerConfig::_node_file;
    std::string ServerConfig::_graph_file;
    std::string ServerConfig::_transport_file;

    std::string ServerConfig::_log_name;
    std::string ServerConfig::_log_path = "./log/";
    int32_t ServerConfig::_app_log_level = 3;
    int32_t ServerConfig::_sys_log_level = 3;

    std::string ServerConfig::_redis_path;
    std::string ServerConfig::_fetch_path;
    std::string ServerConfig::_kafka_path;
    std::string ServerConfig::_model_info_path;
    std::string ServerConfig::_model_rule_path;
    std::string ServerConfig::_monitor_project_id = "ai_ad";
    std::string ServerConfig::_monitor_sys_collect_id;
    std::string ServerConfig::_monitor_biz_collect_id;
    std::string ServerConfig::_monitor_slot_collect_id;
    std::string ServerConfig::_monitor_redis_collect_id;
    std::string ServerConfig::_monitor_dict_collect_id;
    std::string ServerConfig::_monitor_log_path;
    std::string ServerConfig::_monitor_service_name;
    std::string ServerConfig::_bigdata_log_path;
    std::atomic<bool> ServerConfig::_dict_not_found_report = false;

    std::atomic<bool> ServerConfig::_dict_push_enable = false;  // 词典加载信息上报SLA开关
    std::string ServerConfig::_dict_sla_url = "";               // SLA上报地址
    std::string ServerConfig::_dict_sla_uri = "";               // SLA上报路径

    std::string ServerConfig::_dict_warmup_url = "";
    std::string ServerConfig::_dict_warmup_uri = "";

    std::string ServerConfig::_polaris_token;
    std::string ServerConfig::_polaris_service_name;
    std::string ServerConfig::_polaris_namespace_name;
    bool ServerConfig::_polaris_health_check_flag = true;
    int ServerConfig::_polaris_health_ttl = 5;
    int ServerConfig::_polaris_connect_timeout_ms = 5000;
    std::string ServerConfig::_polaris_cluster;
    std::string ServerConfig::_polaris_cache;
    std::string ServerConfig::_polaris_service_refresh_interval;
    std::string ServerConfig::_polaris_service_expire_time;
    int ServerConfig::_brpc_naming_refresh_time = 1000;
    std::atomic<int32_t> ServerConfig::_offline_item_emb_cnt = 0;
    bool ServerConfig::_first_load_offline_item_emb = true;

    bool ServerConfig::_debug_enable = false;
    std::atomic<bool> ServerConfig::_debug_bvar_monitor_enable = false;
    std::atomic<bool> ServerConfig::_turn_on_predict_service_model_info_monitor = false;
    int32_t ServerConfig::_featuredump_retry_time = 200;
    std::vector<int32_t> ServerConfig::_featuredump_retry_time_list = {200, 500, 1000};
    //新增启用dump 开关
    bool ServerConfig::_dump_enable = true;
    std::atomic<bool> ServerConfig::_dump_to_kafka_enable{false};
    std::atomic<int32_t> ServerConfig::_max_connection_pool_size{100};
    std::atomic<int32_t> ServerConfig::_socket_send_buffer_size{-1};
    // 新增 slots
    std::unordered_set<std::string> ServerConfig::_slots;
    std::string ServerConfig::_prerank_offline_embedding_graph_name;
    int32_t ServerConfig::_prerank_offline_embedding_interval=1;
    int32_t ServerConfig::_prerank_offline_embedding_scheduled=30;
    int32_t ServerConfig::_prerank_max_tuffer_size=10;

    // 粗排与获取item特征串行
    std::atomic<bool> ServerConfig::_prerank_fs_truncation_enabled{false};
    std::atomic<float> ServerConfig::_prerank_fs_truncation_threshold{0.0};
    // 打分一致性校验相关
    bool ServerConfig::_consist_enable = false;
    int32_t ServerConfig::_usleep_interval = 1000;

    // 包名维度预估相关
    bool ServerConfig::_pkg_dim_global_enable = false;
    std::unordered_set<std::string> ServerConfig::_pkg_dim_predict_types;
    std::unordered_set<std::string> ServerConfig::_pkg_dim_algo_scene_ids;

    //场景过滤采样比例
    std::atomic<int32_t> ServerConfig::_scene_filter_end_policy = 5;
    std::atomic<double> ServerConfig::_limit_qps = -1.0;
    common::RateLimiter ServerConfig::_rate_limit(10);
    std::atomic_bool ServerConfig::_dump_monitor_enable = false;

    // 测试环境特征上报
    std::atomic<bool> ServerConfig::_feature_report_enable = false;
    int32_t ServerConfig::_feature_report_start_h = 2;
    int32_t ServerConfig::_feature_report_period_h = 1;
    int32_t ServerConfig::_max_models = 3;
    std::string ServerConfig::_feature_report_kafka_name = "";
    std::string ServerConfig::_feature_report_kafka_key = "";
    std::atomic<bool> ServerConfig::_feature_report_running = false;
    std::atomic<int32_t> ServerConfig::_feature_report_user_end_policy = 1;

    //向量召回相关
    std::string ServerConfig::_recall_offline_embedding_graph_name;
    std::unordered_set<std::string> ServerConfig::_recall_ad_embedding_info_paths;


    int ServerConfig::init_nacos_config(const std::string &path) {
        ConfigXml xml;
        xml.init(path);
        std::cerr << "local nacos config path: " << path << std::endl;
        ConfigXml main_xml;
        if (!xml.find("main", main_xml)) {
            std::cerr << " main not found in " << path << std::endl;
            return ERROR_SYS_SERVER_CONFIG_INVALID;
        }

        // nacos
        {
            ConfigXml nacos_config;
            if (!main_xml.child("nacos", nacos_config)) {
                std::cerr << " nacos not found in " << path << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            nacos_config.attr<std::string>("server_adder", _server_adder);
            nacos_config.attr<std::string>("auth_user_name", _auth_user_name);
            nacos_config.attr<std::string>("name_space", _name_space);
            nacos_config.attr<std::string>("auth_passwd", _auth_passwd);
        }

        // naming service
        {
            ConfigXml naming_config;
            if (!main_xml.child("naming", naming_config)) {
                std::cerr << "naming_config not exist in file: " << std::endl;
            } else {
                naming_config.attr<std::string>("cluster", _polaris_cluster);
                naming_config.attr<std::string>("token", _polaris_token);
                naming_config.attr<std::string>("service_name", _polaris_service_name);
                naming_config.attr<std::string>("namespace_name", _polaris_namespace_name);
                naming_config.attr<std::string>("cache_dir", _polaris_cache);
                naming_config.attr<std::string>("service_refresh_interval", _polaris_service_refresh_interval, "2s");
                naming_config.attr<std::string>("service_expire_time", _polaris_service_expire_time, "24h");
                naming_config.attr<int>("naming_refresh_time", _brpc_naming_refresh_time, 1000);

                std::string health_enable;
                naming_config.attr<std::string>("health_check", health_enable, "false");
                if (health_enable == "true") {
                    _polaris_health_check_flag = true;
                }
                naming_config.attr<int>("health_ttl", _polaris_health_ttl, 5);
                naming_config.attr<int>("connect_timeout_ms", _polaris_connect_timeout_ms, 5000);
            }
        }
        // log 初始化
        {
            ConfigXml log_config;
            if (!main_xml.child("log", log_config)) {
                std::cerr << " log not found in server.xml" << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            log_config.attr<std::string>("path", _log_path);
            log_config.attr<std::string>("name", _log_name);

            try {
                hilog::global_helper().initialize(ServerConfig::_log_name, ServerConfig::_log_path);
                hilog::global_helper().setSysLogLevel(ServerConfig::_sys_log_level);
                hilog::global_helper().setAppLogLevel(ServerConfig::_app_log_level);
            } catch (const std::exception &e) {
                std::cout << " logn exception " << e.what() << std::endl;
            }
        }

        // server
        {
            ConfigXml server_config;
            if (!main_xml.child("server", server_config)) {
                std::cerr << " server not found in " << path << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            server_config.attr<std::string>("group_id", _server_group_id);
            server_config.attr<std::string>("data_id", _server_data_id);
        }
        //node
        {
            ConfigXml node_config;
            if (!main_xml.child("node", node_config)) {
                std::cerr << " node not found in " << path << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            node_config.attr<std::string>("group_id", _node_group_id);
            node_config.attr<std::string>("data_id", _node_data_id);
        }
        // graph
        {
            ConfigXml graph_config;
            if (!main_xml.child("graph", graph_config)) {
                std::cerr << " graph not found in " << path << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            graph_config.attr<std::string>("group_id", _graph_group_id);
            graph_config.attr<std::string>("data_id", _graph_data_id);
        }

        {
            ConfigXml redis_config;
            if (!main_xml.child("redis_client", redis_config)) {
                std::cerr << "fs_redis not found in " << path << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            // redis_config.attr<std::string>("group_id", _redis_group_id);
            // redis_config.attr<std::string>("data_id", _redis_data_id);
            redis_config.attr<std::string>("local_path", _redis_path);
        }

        //fetch
        {
            ConfigXml fetch_config;
            if (!main_xml.child("redis_fetch", fetch_config)) {
                std::cerr << "fs_fetch not found in " << path << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            // fetch_config.attr<std::string>("group_id", _fetch_group_id);
            // fetch_config.attr<std::string>("data_id", _fetch_data_id);
            fetch_config.attr<std::string>("local_path", _fetch_path);
        }

        //kafka
        {
            ConfigXml kafka_config;
            if (!main_xml.child("kafka", kafka_config)) {
                std::cerr << "fs_kafka not found in " << path << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            kafka_config.attr<std::string>("group_id", _kafka_group_id);
            kafka_config.attr<std::string>("data_id", _kafka_data_id);
        }

        //model_info
        {
            ConfigXml model_info;
            if (!main_xml.child("model_info", model_info)) {
                std::cerr << " model_info not found in " << path << std::endl;
                // return ERROR_SYS_SERVER_NODE_NO_EXIST;
            } else {
                model_info.attr<std::string>("group_id", _model_info_group_id);
                model_info.attr<std::string>("data_id", _model_info_data_id);
            }
        }

        //dict
        {
            ConfigXml dict_config;
            if (!main_xml.child("dict", dict_config)) {
                std::cerr << " dict not found in " << path << std::endl;
                // return ERROR_SYS_SERVER_NODE_NO_EXIST;
            } else {
                dict_config.attr<std::string>("group_id", _dict_group_id);
                dict_config.attr<std::string>("data_id", _dict_data_id);
            }
        }
        return ERROR_SUCCESS;
    }

    int ServerConfig::new_init(const config::ConfigServiceCfg &cfg, const std::string &group_id,
                               const std::string &data_id) {
        //  注册nacos
        auto ptr = std::make_shared<ServerNacosConfig>(group_id, data_id);
        config::RegisterResponse regist_ret = config::ConfigManager::getInstance().RegisterConfig(cfg, ptr);
        if (regist_ret != config::RegisterResponse::kSuccess) {
            std::cerr << "register server nacos failed, code:" << static_cast<long>(regist_ret) << std::endl;
            return ERROR_REGISTER_CONFIG_NULL;
        }
        // 初始化
        //添加监听器
        return ERROR_SUCCESS;
    }

    void string2IntList(std::string &str) {
        if (!str.empty()) {
            std::vector<int32_t> _featuredump_retry_time_list_tmp;
            std::string trimmedStr = str.substr(1, str.size() - 2);
            std::stringstream ss(trimmedStr);
            std::string token;
            while (std::getline(ss, token, ',')) {
                _featuredump_retry_time_list_tmp.push_back(std::stoi(token));
            }
            ServerConfig::_featuredump_retry_time_list = _featuredump_retry_time_list_tmp;
        }
    }

    int ServerConfig::update(const std::string &content) {
        ConfigXml content_xml;
        if (!content_xml.parse(content)) {
            std::cerr << "parse server.xml failed, content: " << content << std::endl;
            return ERROR_SYS_SERVER_CONFIG_INVALID;
        }
        ConfigXml main_xml;
        if (!content_xml.find("main", main_xml)) {
            std::cerr << "main not found in nacos server.xml" << std::endl;
            return ERROR_SYS_SERVER_CONFIG_INVALID;
        }

        // server
        {
            ConfigXml server_config;
            if (!main_xml.child("server", server_config)) {
                std::cerr << " server not found in nacos server.xml " << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            server_config.attr<std::string>("app", _app_name);
            server_config.attr<std::string>("server", _server_name);
            server_config.attr<int32_t>("port", _server_port);
            server_config.attr<int32_t>("num_thread", _server_num_thread);
            server_config.attr<int32_t>("event_dispatcher_num", _event_dispatcher_num);
        }

        // log
        {
            ConfigXml log_config;
            if (!main_xml.child("log", log_config)) {
                std::cerr << " log not found in server.xml" << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            log_config.attr<int32_t>("app_level", _app_log_level);
            log_config.attr<int32_t>("sys_level", _sys_log_level);

            //log，暂不支持动态更新

            hilog::global_helper().setSysLogLevel(ServerConfig::_sys_log_level);
            hilog::global_helper().setAppLogLevel(ServerConfig::_app_log_level);
        }

        //monitor
        {
            ConfigXml monitor_config;
            if (!main_xml.child("monitor", monitor_config)) {
                std::cerr << " monitor not found in nacos server.xml " << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            monitor_config.attr<std::string>("sys_collect_id", _monitor_sys_collect_id);
            monitor_config.attr<std::string>("biz_collect_id", _monitor_biz_collect_id);
            monitor_config.attr<std::string>("redis_collect_id", _monitor_redis_collect_id);
            monitor_config.attr<std::string>("slot_collect_id", _monitor_slot_collect_id);
            monitor_config.attr<std::string>("dict_collect_id", _monitor_dict_collect_id);

            monitor_config.attr<std::string>("path", _monitor_log_path);
            monitor_config.attr<std::string>("name", _monitor_service_name);
            monitor_config.attr<std::string>("bigdata_path", _bigdata_log_path);
            std::string dict_not_found_report;
            monitor_config.attr<std::string>("dict_not_found_report", dict_not_found_report);
            bool enable_dict_not_found_report = (dict_not_found_report == "true");
            _dict_not_found_report = enable_dict_not_found_report;
            hidict::g_real._dict_not_found_report = enable_dict_not_found_report;
            if (_dict_not_found_report) {
                HILOG_APP(ERROR) << "dict_not_found_report on";
            } else {
                HILOG_APP(ERROR) << "dict_not_found_report off";
            }
        }

        // dict_push_sla
        {
            ConfigXml dict_config;
            if (main_xml.child("dict_push_sla", dict_config)) {
                std::string push_enable_str;
                dict_config.attr<std::string>("dict_push_sla_enable", push_enable_str, "false");
                if (push_enable_str == "true" || push_enable_str == "1") {
                    _dict_push_enable = true;
                } else if (push_enable_str == "false" || push_enable_str == "0") {
                    _dict_push_enable = false;
                } else {
                    HILOG_APP(WARNING) << "Invalid push_enable value: " << push_enable_str
                                        << ", keep previous: " << (_dict_push_enable ? "true" : "false");
                }
                dict_config.attr<std::string>("dict_sla_url", _dict_sla_url);
                dict_config.attr<std::string>("dict_sla_uri", _dict_sla_uri);
                dictpush::DictPushConfig::set(_dict_push_enable, _dict_sla_url, _dict_sla_uri);
            }
        }

        //slots
        {
            ConfigXml slots_config;
            if (!main_xml.child("slots", slots_config)) {
                std::cerr << "slots not found in nacos server.xml " << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }

            std::string slots_value;
            slots_config.attr<std::string>("value", slots_value);// 获取 value 属性

            // 分割字符串并插入到 _slots 中
            // 存储分割结果
            std::vector<std::string> slot_vec;
            // 使用逗号分割
            boost::split(slot_vec, slots_value, boost::is_any_of(","));

            // 去除每个分割结果的前后空格并插入到 _slots 中
            for (auto &slot: slot_vec) {
                boost::algorithm::trim(slot);// 去除前后空格
                if (!slot.empty()) {
                    ServerConfig::_slots.insert(slot);// 插入到 set 中
                }
            }
        }

        // prerank
        {
            ConfigXml prerank_config;
            if (main_xml.child("prerank", prerank_config)) {
                prerank_config.attr<std::string>("offline_graph_name", _prerank_offline_embedding_graph_name);
                prerank_config.attr<int32_t>("offline_interval", _prerank_offline_embedding_interval);
                prerank_config.attr<int32_t>("offline_scheduled", _prerank_offline_embedding_scheduled);
                prerank_config.attr<int32_t>("max_tuffer_size", _prerank_max_tuffer_size);
                prerank_config.attr<int32_t>("max_models", _max_models);
                prerank_config.attr<std::string>("dict_warmup_url", _dict_warmup_url);
                prerank_config.attr<std::string>("dict_warmup_uri", _dict_warmup_uri);

                std::string fs_truncation_enabled;
                prerank_config.attr<std::string>("fs_truncation_enabled", fs_truncation_enabled, "false");
                if (fs_truncation_enabled == "true") {
                    _prerank_fs_truncation_enabled.store(true);
                } else {
                    _prerank_fs_truncation_enabled.store(false);
                }
                if (_prerank_fs_truncation_enabled.load()) {
                    HILOG_APP(ERROR) << "fs truncation is enabled";
                } else {
                    HILOG_APP(ERROR) << "fs truncation is disabled";
                }
                float fs_truncation_threshold = 0.0;
                prerank_config.attr<float>("fs_truncation_threshold", fs_truncation_threshold, 0.0);
                _prerank_fs_truncation_threshold.store(fs_truncation_threshold);
                HILOG_APP(INFO) << "fs truncation threshold: " << _prerank_fs_truncation_threshold.load();
            }
        }

        // dump enable
        {
            ConfigXml dump_enable_config;
            if (!main_xml.child("dump", dump_enable_config)) {
                std::cerr << "dump not found in nacos server.xml" << std::endl;
                return ERROR_SYS_SERVER_NODE_NO_EXIST;
            }
            std::string dump_enable;
            dump_enable_config.attr<std::string>("enable", dump_enable, "true");
            try {
                dump_enable_config.attr<int>("retry_time", _featuredump_retry_time);
                std::string _featuredump_retry_time_list_str;
                dump_enable_config.attr<std::string>("retry_time_list", _featuredump_retry_time_list_str);
                string2IntList(_featuredump_retry_time_list_str);
            } catch (const std::exception &e) {
                HILOG_APP(ERROR) << "deal retry info failed, exception: " << e.what();
            }
            if (!dump_enable.empty() && dump_enable == "false") {
                _dump_enable = false;
            } else {
                _dump_enable = true;
            }
        }

        //debug enable
        {
            ConfigXml debug_config;
            if (main_xml.child("debug", debug_config)) {
                std::string enable;
                debug_config.attr<std::string>("enable", enable, "false");
                if (enable == "true") {
                    _debug_enable = true;
                }
                std::string debug_bvar_monitor_enable;
                debug_config.attr<std::string>("bvar_monitor_enable", debug_bvar_monitor_enable, "false");
                if (debug_bvar_monitor_enable == "true") {
                    _debug_bvar_monitor_enable = true;
                } else if (debug_bvar_monitor_enable == "false") {
                    _debug_bvar_monitor_enable = false;
                } else {
                    HILOG_APP(ERROR) << "bvar_monitor_enable config error";
                }

                std::string turn_on_predict_service_model_info_monitor;
                debug_config.attr<std::string>("turn_on_predict_service_model_info_monitor",
                                               turn_on_predict_service_model_info_monitor, "false");
                if (turn_on_predict_service_model_info_monitor == "true") {
                    _turn_on_predict_service_model_info_monitor = true;
                } else {
                    _turn_on_predict_service_model_info_monitor = false;
                }
            }
            if (_debug_enable) {
                HILOG_APP(ERROR) << "debug services is enable";
            } else {
                HILOG_APP(ERROR) << "debug services is disable";
            }

            if (_debug_bvar_monitor_enable) {
                HILOG_APP(ERROR) << "bvar_monitor_enable is enable";
            } else {
                HILOG_APP(ERROR) << "bvar_monitor_enable is disable";
            }
        }

        // consist
        {
            ConfigXml consist_config;
            if (!main_xml.child("consist", consist_config)) {
                HILOG_APP(WARNING) << "consist not found in nacos server.xml";
            } else {
                std::string consist_enable;
                consist_config.attr<std::string>("enable", consist_enable, "false");
                if (!consist_enable.empty() && consist_enable == "true") {
                    _consist_enable = true;
                } else {
                    _consist_enable = false;
                }
                consist_config.attr<int32_t>("usleep_interval", _usleep_interval);
            }
        }

        // 包名维度预估 相关配置
        {
            ConfigXml pkg_dim_config;
            if (!main_xml.child("pkg-dim", pkg_dim_config)) {
                HILOG_APP(WARNING) << "pkg-dim not exist in nacos server.xml";
            } else {
                std::string global_enable;
                pkg_dim_config.attr<std::string>("global_enable", global_enable, "false");
                if (!global_enable.empty() && global_enable == "true") {
                    _pkg_dim_global_enable = true;
                    HILOG_APP(ERROR) << "pkg dim predict is enabled globally";
                } else {
                    _pkg_dim_global_enable = false;
                    HILOG_APP(ERROR) << "pkg dim predict is decided by AB experiments";
                }

                std::string predict_type_value;
                pkg_dim_config.attr<std::string>("predict_type", predict_type_value);

                std::vector<std::string> predict_type_vec;
                // 使用逗号分割
                boost::split(predict_type_vec, predict_type_value, boost::is_any_of(","));
                ServerConfig::_pkg_dim_predict_types.clear();
                // 去除每个分割结果的前后空格并插入到 _pkg_dim_predict_types 中
                for (auto &predict_type: predict_type_vec) {
                    boost::algorithm::trim(predict_type);// 去除前后空格
                    if (!predict_type.empty()) {
                        ServerConfig::_pkg_dim_predict_types.insert(predict_type);// 插入到 set 中
                    }
                }

                std::string algo_scene_id_value;
                pkg_dim_config.attr<std::string>("algo_scene_id", algo_scene_id_value);

                std::vector<std::string> algo_scene_id_vec;
                // 使用逗号分割
                boost::split(algo_scene_id_vec, algo_scene_id_value, boost::is_any_of(","));
                ServerConfig::_pkg_dim_algo_scene_ids.clear();
                // 去除每个分割结果的前后空格并插入到 _pkg_dim_algo_scene_ids 中
                for (auto &algo_scene_id: algo_scene_id_vec) {
                    boost::algorithm::trim(algo_scene_id);// 去除前后空格
                    if (!algo_scene_id.empty()) {
                        ServerConfig::_pkg_dim_algo_scene_ids.insert(algo_scene_id);// 插入到 set 中
                    }
                }
            }
        }
        //dump to kafka enable
        {
            ConfigXml dump_log_to_kafka_config;
            if (main_xml.child("dump_log_to_kafka", dump_log_to_kafka_config)) {
                bool enable = false;
                std::string dump_log_to_kafka_enable;
                dump_log_to_kafka_config.attr<std::string>("enable", dump_log_to_kafka_enable, "false");
                if (!dump_log_to_kafka_enable.empty() && dump_log_to_kafka_enable == "true") {
                    enable = true;
                } else {
                    enable = false;
                }
                _dump_to_kafka_enable.store(enable);
            }
            if (_dump_to_kafka_enable.load()) {
                HILOG_APP(ERROR) << "dump to kafka is enable";
            } else {
                HILOG_APP(ERROR) << "dump to kafka is disable";
            }
        }

        //scene filter
        {
            ConfigXml scene_filter;
            if (!main_xml.child("scenefilter", scene_filter)) {
                std::cerr << "scenefilter not found in nacos server.xml" << std::endl;
            } else {
                int32_t end_policy;
                scene_filter.attr<int32_t>("end_policy", end_policy, 5);
                _scene_filter_end_policy.store(end_policy);
            }
        }
        // qps
        {
            ConfigXml qps_limit_xml;
            if (!main_xml.child("limit_qps", qps_limit_xml)) {
                std::cerr << "limit_qps not found in nacos server.xml" << std::endl;
            } else {
                double limit_qps;
                qps_limit_xml.attr<double>("threshold", limit_qps, -1);
                _limit_qps.store(limit_qps);
                _rate_limit.update_rate(limit_qps);
            }
        }

        //Max number of pooled connections to a single endpoint
        {
            ConfigXml brpc_channel;
            if (!main_xml.child("brpc_channel", brpc_channel)) {
                std::cerr << "max_connection_pool_size not found in nacos server.xml" << std::endl;
            } else {
                int32_t max_connection_pool_size;
                brpc_channel.attr<int32_t>("max_connection_pool_size", max_connection_pool_size, 100);
                _max_connection_pool_size.store(max_connection_pool_size);

                int32_t socket_send_buffer_size;
                brpc_channel.attr<int32_t>("socket_send_buffer_size", socket_send_buffer_size, -1);
                _socket_send_buffer_size.store(socket_send_buffer_size);
            }
        }

        // feature report 测试环境特征上报
        {
            ConfigXml feature_report_config;
            if (main_xml.child("feature_report", feature_report_config)) {
                std::string enable;
                feature_report_config.attr<std::string>("enable", enable, "false");
                if (enable == "true") {
                    _feature_report_enable.store(true);
                } else {
                    _feature_report_enable.store(false);
                }
                feature_report_config.attr<int32_t>("start_h", _feature_report_start_h, 2);
                feature_report_config.attr<int32_t>("period_h", _feature_report_period_h, 1);
                feature_report_config.attr<std::string>("kafka_name", _feature_report_kafka_name, "");
                feature_report_config.attr<std::string>("kafka_key", _feature_report_kafka_key, "");
                int32_t user_end_policy;
                feature_report_config.attr<int32_t>("user_end_policy", user_end_policy, 0);
                _feature_report_user_end_policy.store(user_end_policy);
            }
            if (_feature_report_enable.load()) {
                HILOG_APP(ERROR) << "feature report is enable";
                std::cout << "feature report is enable\n";
            } else {
                HILOG_APP(ERROR) << "feature report is disable";
                std::cout << "feature report is disable\n";
            }
        }

        // 向量召回配置
        {
            ConfigXml recall_config;
            if (main_xml.child("recall", recall_config)) {
                recall_config.attr<std::string>("offline_graph_name", _recall_offline_embedding_graph_name);
                std::string ad_embedding_info_path_value;
                recall_config.attr<std::string>("ad_embedding_info_path", ad_embedding_info_path_value);
                // 存储分割结果
                std::vector<std::string> ad_embedding_info_path_vec; 
                // 使用逗号分割
                boost::split(ad_embedding_info_path_vec, ad_embedding_info_path_value, boost::is_any_of(",")); 
                for (auto& ad_embedding_info_path : ad_embedding_info_path_vec) {
                    boost::algorithm::trim(ad_embedding_info_path); // 去除前后空格
                    if (!ad_embedding_info_path.empty()) {
                        ServerConfig::_recall_ad_embedding_info_paths.insert(ad_embedding_info_path); // 插入到 set 中
                    }
                }
            }
        }

        return ERROR_SUCCESS;
    }

}// namespace Core
