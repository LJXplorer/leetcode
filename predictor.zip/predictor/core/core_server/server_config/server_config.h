#ifndef _CORE_SERVER_CONFIG_H
#define _CORE_SERVER_CONFIG_H
#include "common/comm/config_xml.h"
#include "common/config/service_config.h"
#include "common/config/base_config.h"
#include "iostream"
#include "log_helper.h"
#include <rate_limit.h>
#include <atomic>
#include <unordered_set>
namespace Core {

struct ServerConfig{
        // nacos service info
        static std::string _server_adder;
        static std::string _auth_user_name;
        static std::string _auth_passwd;
        static std::string _name_space;
        // nacos dataid
        // nacos: group_id & data_id
        static std::string _server_group_id;
        static std::string _server_data_id;

        static std::string _graph_group_id;
        static std::string _graph_data_id;

        static std::string _node_group_id;
        static std::string _node_data_id;

        static std::string _redis_group_id;
        static std::string _redis_data_id;

        static std::string _fetch_group_id;
        static std::string _fetch_data_id;

        static std::string _kafka_group_id;
        static std::string _kafka_data_id;

        static std::string _model_info_group_id;
        static std::string _model_info_data_id;

        static std::string _model_rule_group_id;
        static std::string _model_rule_data_id;

        static std::string _dict_group_id;
        static std::string _dict_data_id;
        /*******************************************/


        static std::string _app_name;
        static std::string _server_name;
        static std::string _server_ip;
        static std::string _server_ip_port;
        static int32_t _server_port;
        static int32_t _server_num_thread;
        static int32_t _event_dispatcher_num;

        static std::string _node_file;
        static std::string _graph_file;
        static std::string _transport_file;


        static std::string _log_path;
        static std::string _log_name;
        static int32_t _app_log_level;
        static int32_t _sys_log_level;

        //fs
        static std::string _redis_path;
        static std::string _fetch_path;
        static std::string _kafka_path;
        static std::string _model_info_path;
        static std::string _model_rule_path;

        static std::string _monitor_project_id;
        static std::string _monitor_biz_collect_id;
        static std::string _monitor_slot_collect_id;
        static std::string _monitor_sys_collect_id;
        static std::string _monitor_redis_collect_id;
        static std::string _monitor_dict_collect_id;
        static std::string _monitor_log_path;
        static std::string _monitor_service_name;
        static std::string _bigdata_log_path;
        static std::atomic<bool> _dict_not_found_report; //词典未找到率监控上报开关 默认为 false

        static std::atomic<bool> _dict_push_enable; // 词典加载信息上报SLA开关
        static std::string _dict_sla_url;           // SLA上报地址
        static std::string _dict_sla_uri;           // SLA上报路径
        static int32_t _max_models;

        static std::string _dict_warmup_url;
        static std::string _dict_warmup_uri;
        static std::string _prerank_offline_embedding_graph_name;
        static int32_t _prerank_offline_embedding_interval;
        static int32_t _prerank_offline_embedding_scheduled;
        static int32_t _prerank_max_tuffer_size;
        static std::atomic<bool> _prerank_fs_truncation_enabled; // 粗排与获取item特征串行开关
        static std::atomic<float> _prerank_fs_truncation_threshold; // 粗排与获取item特征串行功能阈值，精排保留数占总item数的比例

        //新增重点广告位配置
        static std::unordered_set<std::string> _slots; 
        static bool _dump_enable;
        static bool _debug_enable;
        static std::atomic<bool> _debug_bvar_monitor_enable; 
        static std::atomic<bool> _turn_on_predict_service_model_info_monitor;
        static std::atomic<bool> _dump_to_kafka_enable;//true则发送大数据日志到kafka，否则仍然写文件到本地
        static int32_t _featuredump_retry_time;
        static std::vector<int32_t>  _featuredump_retry_time_list;

        // 打分一致性校验配置
        static bool _consist_enable;
        static int32_t _usleep_interval;

        // 包名维度预估配置
        static bool _pkg_dim_global_enable;
        static std::unordered_set<std::string> _pkg_dim_predict_types;
        static std::unordered_set<std::string> _pkg_dim_algo_scene_ids;
        
        //命名服务配置
        static std::string _polaris_token;
        static std::string _polaris_service_name;
        static std::string _polaris_namespace_name;
        static bool _polaris_health_check_flag;
        static int _polaris_health_ttl;
        static int _polaris_connect_timeout_ms;
        static std::string _polaris_cluster;
        static std::string _polaris_cache;
        static std::string _polaris_service_refresh_interval;
        static std::string _polaris_service_expire_time;
        static int _brpc_naming_refresh_time;
        static std::atomic<int32_t> _offline_item_emb_cnt;
        static bool _first_load_offline_item_emb;

        //场景过滤采样比例
        static std::atomic<int32_t> _scene_filter_end_policy;

        static std::atomic<double> _limit_qps;
        static common::RateLimiter _rate_limit;

        // dump阶段队列监控开关
        static std::atomic_bool _dump_monitor_enable;

         // 测试环境特征上报
        static std::atomic<bool> _feature_report_enable;
        static int32_t _feature_report_start_h; // 开始采样时间，无热更新
        static int32_t _feature_report_period_h; // 采样时长，无热更新
        static std::string _feature_report_kafka_name;
        static std::string _feature_report_kafka_key;
        static std::atomic<bool> _feature_report_running;
        static std::atomic<int32_t> _feature_report_user_end_policy;

         //向量召回相关
        static std::string _recall_offline_embedding_graph_name;
        static std::unordered_set<std::string> _recall_ad_embedding_info_paths;

        //brpc  Max number of pooled connections to a single endpoint
        static std::atomic<int32_t> _max_connection_pool_size;

        static std::atomic<int32_t> _socket_send_buffer_size;

        //
        static int init_nacos_config(const std::string&path);

        static int new_init(const config::ConfigServiceCfg& cfg,
                            const std::string& group_id,
                            const std::string& data_id);

        static int update(const std::string& content);

    };


    struct ServerNacosConfig : public config::ListenableConfig {
        std::string group_id;
        std::string data_id;

        ServerNacosConfig(const std::string& group_id, const std::string& data_id)
            : group_id(group_id), data_id(data_id) {}

        int OnConfigChanged(const std::string& new_config) override {
            HILOG_APP(INFO) << "new content: \n" << new_config << std::endl;
            int ret = ServerConfig::update(new_config);
            if(ret != 0){
                std::cerr << "update failed when nacos changes \n";
            }
            return ret;
        }

        config::ConfigSource GetConfigSource() override {
            return {
                .group_id = group_id,
                .data_id = data_id
            };
        }
    };



}

#endif
