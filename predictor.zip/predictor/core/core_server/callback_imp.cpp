#include "core/core_server/callback_imp.h"
#include "core/core_context/callback_context.h"
#include "core/utils/defs.h"
#include "hlframe/graph_manager.h"
#include <fstream>
namespace Core {

    void CallbackImp::CallbackService(google::protobuf::RpcController *cntl_base, const ::phx::CallbackRequest *request,
                                      ::phx::CallbackResponse *response, google::protobuf::Closure *done) {

        brpc::ClosureGuard done_guard(done);
        brpc::Controller *cntl = static_cast<brpc::Controller *>(cntl_base);

        //1、创建通用上下文context
        auto ctx = create_context(cntl, request, response, done);
        //2、匹配业务对应图名
        auto graph_name = getGraphName(ctx);
        if (graph_name.empty()) {
            //report
            return;
        }

        //3、获取图
        auto graph = GraphManager::instance().get_graph(graph_name);
        if (graph == nullptr) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << graph_name << " no find ";
            //report
            return;
        }

        //执行调度
        try {
            graph->run(ctx, cntl, request, response, done);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << graph_name << " run exception " << e.what();
            //report
            return;
        }

        done_guard.release();
    }

    ContextPtr CallbackImp::create_context(brpc::Controller *cntl, const ::phx::CallbackRequest *request,
                                           ::phx::CallbackResponse *response, google::protobuf::Closure *done) {
        auto ctx = create_context();
        ctx->make_request_context<::phx::CallbackRequest, ::phx::CallbackResponse>(cntl, request, response, done);
        ctx->init();
        return ctx;
    }

    ContextPtr CallbackImp::create_context() {
        return std::make_shared<CallbackContext>();
    }

    std::string CallbackImp::getGraphName(ContextPtr context) {
        return GRAPH_CALLBACK;
    }
}// namespace Core
