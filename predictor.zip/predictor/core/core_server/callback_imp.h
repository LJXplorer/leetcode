#ifndef _FEATURE_DUMP_IMP_H
#define _FEATURE_DUMP_IMP_H
#include "brpc/server.h"
#include "core/core_server/imp.h"
#include "gflags/gflags.h"
#include "ranking/callback_service.pb.h"

namespace Core {

    class CallbackImp : public Imp, public ::phx::CallbackServer {
    public:
        CallbackImp() = default;
        ~CallbackImp() = default;
        void CallbackService(google::protobuf::RpcController *cntl_base, const ::phx::CallbackRequest *request,
                                ::phx::CallbackResponse *response, google::protobuf::Closure *done) override;

    public:
        virtual ContextPtr create_context(brpc::Controller *cntl, const ::phx::CallbackRequest *request,
                                          ::phx::CallbackResponse *response, google::protobuf::Closure *done);
        virtual ContextPtr create_context();
        virtual std::string getGraphName(ContextPtr context);
    };

}// namespace Core

#endif
