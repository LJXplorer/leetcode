#include "embedding_imp.h"
#include "core/core_context/context_defs.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/recall/dict/emb_info_dict_manager.h"
#include "core/utils/defs.h"
#include "hlframe/graph_manager.h"
#include <cstddef>
#include <memory>
namespace Core {
    ItemEmbeddingContextPtr EmbeddingImp::CreateItemContext(google::protobuf::RpcController *cntl_base,
                                                            const ::qinglongv2::ItemEmbeddingRequest *request,
                                                            ::qinglongv2::ItemEmbeddingResponse *response,
                                                            ::google::protobuf::Closure *done) {
        ItemEmbeddingContextPtr ctx = std::make_shared<ItemEmbeddingContext>();
        auto *cntl = dynamic_cast<brpc::Controller *>(cntl_base);
        ctx->make_request_context<::qinglongv2::ItemEmbeddingRequest, ::qinglongv2::ItemEmbeddingResponse>(
                cntl, request, response, done);
        ctx->init();
        return ctx;
    }

    UserEmbeddingContextPtr EmbeddingImp::CreateUserContext(google::protobuf::RpcController *cntl_base,
                                                    const ::qinglongv2::UserEmbeddingRequest *request,
                                                    ::qinglongv2::UserEmbeddingResponse *response,
                                                    ::google::protobuf::Closure *done) {
        UserEmbeddingContextPtr ctx = std::make_shared<UserEmbeddingContext>();
        auto *cntl = dynamic_cast<brpc::Controller *>(cntl_base);
        ctx->make_request_context<::qinglongv2::UserEmbeddingRequest, ::qinglongv2::UserEmbeddingResponse>(cntl, request,
                                                                                                   response, done);
        ctx->init();
        return ctx;
    }


    void EmbeddingImp::UserEmbeddingService(google::protobuf::RpcController *cntl_base,
                              const ::qinglongv2::UserEmbeddingRequest *request,
                              ::qinglongv2::UserEmbeddingResponse *response, ::google::protobuf::Closure *done)  {
        brpc::ClosureGuard done_guard(done);
        auto *cntl = dynamic_cast<brpc::Controller *>(cntl_base);

        //1、创建通用上下文context
        auto ctx = CreateUserContext(cntl, request, response, done);
        //2、匹配业务对应图名
        std::string graph_name = "recall_user_emb";
        if (graph_name.empty()) {
            //report
            return;
        }

        //3、获取图
        auto graph = GraphManager::instance().get_graph(graph_name);
        if (graph == nullptr) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << graph_name << " no find ";
            //report
            return;
        }

        //执行调度
        try {
            graph->run(ctx, cntl, request, response, done);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << graph_name << " run exception " << e.what();
            //report
            return;
        }

        done_guard.release();

    }

    void EmbeddingImp::ItemEmbeddingService(google::protobuf::RpcController *cntl_base,
                                            const ::qinglongv2::ItemEmbeddingRequest *request,
                                            ::qinglongv2::ItemEmbeddingResponse *response,
                                            ::google::protobuf::Closure *done) {

        brpc::ClosureGuard done_guard(done);
        auto *cntl = dynamic_cast<brpc::Controller *>(cntl_base);
        
        // 手动触发离线itemembedding
        if (!ServerConfig::_recall_offline_embedding_graph_name.empty() 
            && request->itemembeddingmodelname().empty() && request->debuglevel() == kRecallOfflineManually) {
            if (EmbInfoDictManager::taskRunning.load() > 0) {
                HILOG_APP(ERROR) << "Vector recall offline itme embedding is runnning, try it later";
                return;
            }

            auto &model_info_manager = Core::Info::ModelInfoManager::instance();
            auto &channel_map = model_info_manager.get_model_infos();

            for (auto& ad_embedding_info_path : ServerConfig::_recall_ad_embedding_info_paths) {
                int32_t max_retries = 5; // 读词典重试5次
                honor::retrieval::annindex::EmbeddingInfoData embedding_info_data;
                int ret = -1;
                while (max_retries-- > 0) {
                    ret = EmbInfoDictManager::GetInstance().readDict(ad_embedding_info_path, &embedding_info_data);
                    if (ret == 0) break;
                    embedding_info_data.Clear();
                    if (max_retries != 0) {
                        sleep(60);
                        HILOG_APP(ERROR) << "Retrying for reading ad_info_dict, " << max_retries << " times left";
                    }
                }
                if (ret != 0) {
                    HILOG_APP(ERROR) << "Read ad_info_dict failed, ret:" << ret;
                    continue;
                }

                for (const auto &channel_pair: channel_map) {
                    if (channel_pair.second->_model_type !=Core::Info::ModelType::ITEM_EMBEDDING) {
                        continue;
                    }
                    EmbInfoDictManager::offlineItemEmbRun(ad_embedding_info_path, channel_pair.second, embedding_info_data);
                    sleep(60);
                }
            }
            return;
        }

        // 正常item embedding逻辑

        //1、创建通用上下文context
        auto ctx = CreateItemContext(cntl, request, response, done);
        //2、匹配业务对应图名
        std::string graph_name = "recall_item_emb";
        if (graph_name.empty()) {
            //report
            return;
        }

        //3、获取图
        auto graph = GraphManager::instance().get_graph(graph_name);
        if (graph == nullptr) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << graph_name << " no find ";
            //report
            return;
        }

        //执行调度
        try {
            graph->run(ctx, cntl, request, response, done);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << graph_name << " run exception " << e.what();
            //report
            return;
        }

        done_guard.release();
    }
}// namespace Core