#include "core/core_context/user_embedding_context.h"
#include "core/core_context/item_embedding_context.h"
#include "core/core_server/imp.h"
#include "ranking/embedding_service.pb.h"
namespace Core {
    class EmbeddingImp : public qinglongv2::EmbeddingServer {
    public:
        void ItemEmbeddingService(google::protobuf::RpcController *cntl_base,
                                  const ::qinglongv2::ItemEmbeddingRequest *request,
                                  ::qinglongv2::ItemEmbeddingResponse *response,
                                  ::google::protobuf::Closure *done) override;
        void UserEmbeddingService(google::protobuf::RpcController *cntl_base,
                                  const ::qinglongv2::UserEmbeddingRequest *request,
                                  ::qinglongv2::UserEmbeddingResponse *response,
                                  ::google::protobuf::Closure *done) override;

    private:
        ItemEmbeddingContextPtr CreateItemContext(google::protobuf::RpcController *cntl_base,
                                                  const ::qinglongv2::ItemEmbeddingRequest *request,
                                                  ::qinglongv2::ItemEmbeddingResponse *response,
                                                  ::google::protobuf::Closure *done);
        
        UserEmbeddingContextPtr CreateUserContext(google::protobuf::RpcController *cntl_base,
                                                  const ::qinglongv2::UserEmbeddingRequest *request,
                                                  ::qinglongv2::UserEmbeddingResponse *response,
                                                  ::google::protobuf::Closure *done);
    };
}// namespace Core