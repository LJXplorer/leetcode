#ifndef _POLARIS_REGISTER_H
#define _POLARIS_REGISTER_H

#include <butil/logging.h>
#include <log_helper.h>
#include <memory>
#include <polaris/context.h>
#include <polaris/instance.h>
#include <polaris/provider.h>
#include <string>

//北极星注册和反注册
namespace Core {

    class PolarisRegister {
    private:
        std::string _instance_id;
        std::shared_ptr<polaris::ProviderApi> _provider;
        volatile bool _heart_beat_flag = true;

    public:
        PolarisRegister() = default;
        ~PolarisRegister() = default;

    public:
        static PolarisRegister &instance() {
            static PolarisRegister inst;
            return inst;
        }
        void init();
        bool register_to_polaris();
        bool deregister_from_polaris();
        static void heart_beat_2_polaris() noexcept;
        std::string get_intance_id() {
            return _instance_id;
        };
        std::shared_ptr<polaris::ProviderApi> get_provider() const {
            return _provider;
        }
    };

}// namespace Core

#endif