#include "core/core_server/predict_imp.h"
#include "core/core_context/core_context.h"
#include "core/core_server/server_config/server_config.h"
#include "hlframe/graph_manager.h"
#include "ranking/predict_service.pb.h"
#include <debug_utils.h>
#include <log_helper.h>
#include <system_error>

namespace Core {

    void PredictImp::PredictorService(google::protobuf::RpcController *cntl_base,
                                      const ::phx::PredictorRequest *request, ::phx::PredictorResponse *response,
                                      google::protobuf::Closure *done) {

        brpc::ClosureGuard done_guard(done);

        double limit_qps = ServerConfig::_limit_qps.load();
        if (limit_qps > 0 && !ServerConfig::_rate_limit.tryAcquire(1.0)) {
            // 开启了限流
             // 计数     
            response->set_code(429);
            MonitorMgr::redis_report_common("HONOR", "server_qps_limit", 0, "limit_num", 1, FsSource::REDIS,
                                            STRING_DEFAULT, STRING_TOTALUP);
            return;
        }

        // 计数
        _req_cnt << 1;

        brpc::Controller *cntl = static_cast<brpc::Controller *>(cntl_base);

        //1、创建通用上下文context
        auto ctx = create_context(cntl, request, response, done);
        //2、匹配业务对应图名
        auto graph_name = getGraphName(ctx);
        if (graph_name.empty()) {
            //report
            return;
        }

        //3、获取图
        auto graph = GraphManager::instance().get_graph(graph_name);
        if (graph == nullptr) {
            //report
            return;
        }

        //执行调度
        try {
            graph->run(ctx, cntl, request, response, done);
        } catch (const std::exception &e) {
            //report
            return;
        }

        done_guard.release();
    }

    ContextPtr PredictImp::create_context(brpc::Controller *cntl, const ::phx::PredictorRequest *request,
                                          ::phx::PredictorResponse *response, google::protobuf::Closure *done) {
        auto ctx = create_context();
        ctx->make_request_context<::phx::PredictorRequest, ::phx::PredictorResponse>(cntl, request, response, done);
        ctx->init();
        return ctx;
    }

    ContextPtr PredictImp::create_context() {
        return std::make_shared<CoreContext>();
    }

    std::string PredictImp::getGraphName(ContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        std::string graph_name;
        bool dumpEnabled = ServerConfig::_dump_enable;
        //通过mask第一个标识位来确定是否是纯dump请求
        if (ctx->get_rank_request()->reqmask() & (1ULL << 0)) {
            graph_name = dumpEnabled ? GRAPH_FEA : GRAPH_NO_FEA;
            ctx->_task_type = dumpEnabled ? PredictTaskType::kFeatureDump : ctx->_task_type;
        } else {
            graph_name = STRING_DEFAULT;
        }
        return graph_name;
    }
}// namespace Core
