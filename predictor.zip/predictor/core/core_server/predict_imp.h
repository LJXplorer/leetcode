#ifndef _CORE_SERVER_PREDICT_IMP_H
#define _CORE_SERVER_PREDICT_IMP_H
#include "brpc/server.h"
#include "gflags/gflags.h"
#include "core/core_server/imp.h"
#include "ranking/predict_service.pb.h"
#include <bvar/bvar.h>
#include <bvar/window.h>
#include "core/utils/defs.h"
namespace Core {

    class PredictImp : public Imp, public ::phx::PredictorServer{
    public:
        PredictImp() : _req_cnt(), _qps(limit_prefix, limit_metric, &_req_cnt, 1) {
            
        }
        ~PredictImp() = default;
        void PredictorService(google::protobuf::RpcController* cntl_base,const ::phx::PredictorRequest* request,
            ::phx::PredictorResponse* response, google::protobuf::Closure* done) override;
    public:
        virtual ContextPtr create_context(brpc::Controller* cntl,const ::phx::PredictorRequest* request,
                            ::phx::PredictorResponse* response, google::protobuf::Closure* done);
        virtual ContextPtr create_context();
        virtual std::string getGraphName(ContextPtr context);

    private:
        bvar::Adder<int> _req_cnt;
        bvar::Window<bvar::Adder<int>> _qps;
    };

    
}

#endif
