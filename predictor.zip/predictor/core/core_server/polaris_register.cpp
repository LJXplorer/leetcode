#include "polaris_register.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/defs.h"
#include <chrono>
#include <memory>
#include <polaris/defs.h>
#include <random>
#include <service_config.h>
#include <thread>

namespace  Core {
    
    //注册
    bool PolarisRegister::register_to_polaris(){
        const char* pod_ip = getenv(Core::pod_ip.c_str());
        HILOG_APP(INFO) << "pod ip: " << pod_ip;
        if(pod_ip == nullptr) {
            HILOG_APP(ERROR) << "Register instance failed: pod ip is null!";
            return false;
        }
        const char* zone = getenv(Core::zone.c_str());
        if (zone == nullptr) {
            HILOG_APP(ERROR) << "Register instance zone empty!";
            zone = "default";
        }
        HILOG_APP(INFO) << "zone: " << zone;
        const char* campus = getenv(Core::campus.c_str());
        if(campus == nullptr) {
            HILOG_APP(ERROR) << "Register instance zone empty!";
            campus = "default";
        }
        HILOG_APP(INFO) << "campus: " << campus;

        polaris::InstanceRegisterRequest req(ServerConfig::_polaris_namespace_name, ServerConfig::_polaris_service_name, 
            ServerConfig::_polaris_token,pod_ip, ServerConfig::_server_port);
        req.SetHealthCheckFlag(ServerConfig::_polaris_health_check_flag);
        req.SetTtl(ServerConfig::_polaris_health_ttl);

        req.SetLocation(zone, zone, campus);
        polaris::ReturnCode ret = _provider->Register(req, _instance_id);
        if (ret != polaris::kReturnOk) {
            HILOG_APP(ERROR) << "Register instance failed: " << polaris::ReturnCodeToMsg(ret);
            return false;
        }
        HILOG_APP(INFO) << "instance_id: "<< _instance_id <<std::endl;
        
        return true;
    }

    void PolarisRegister::init(){
        std::string config_str = 
            "global:\n"
            "  serverConnector:\n"
            "    addresses: [" + ServerConfig::_polaris_cluster + "]\n"
            "    connectTimeout: " + std::to_string(ServerConfig::_polaris_connect_timeout_ms) + "\n"
           
            ;
        std::string errorMsg;
        polaris::Config* config = polaris::Config::CreateFromString(config_str, errorMsg);

        polaris::Context* context = polaris::Context::Create(config);
        delete config;  // 创建完成后即可释放config对象

        if (!context) {
            HILOG_APP(FATAL) << "Config parse failed. Input config: " << config_str << ". Error message: " << errorMsg;
        }
        _provider.reset(polaris::ProviderApi::Create(context));
        if(!register_to_polaris()) {
            HILOG_APP(FATAL) << "register to polaris failed"; 
            return;
        }
        std::thread td = std::thread(PolarisRegister::heart_beat_2_polaris);
        td.detach();
        // 确保主线程有足够的生命周期
        std::this_thread::sleep_for(std::chrono::seconds(1));
        _heart_beat_flag = true;
    }

    //反注册
    bool PolarisRegister::deregister_from_polaris(){
        PolarisRegister::instance()._heart_beat_flag = false;
        if(PolarisRegister::instance().get_intance_id().empty() || ServerConfig::_polaris_token.empty()) {
            HILOG_APP(ERROR) << "deRegister instance failed: empty instance_id or token, instance_id: " 
                << PolarisRegister::instance().get_intance_id() << " token: "<< ServerConfig::_polaris_token;
            return false;
        }
        
        polaris::InstanceDeregisterRequest deregister_req(ServerConfig::_polaris_token, PolarisRegister::instance().get_intance_id());
        polaris::ReturnCode ret = PolarisRegister::_provider->Deregister(deregister_req);
        if (ret != polaris::kReturnOk) {
            HILOG_APP(ERROR) << "deRegister instance failed: " << polaris::ReturnCodeToMsg(ret);
            return false;
        }
        return true;
    }

    //上报心跳且异常情况下重新注册
    void PolarisRegister::heart_beat_2_polaris() noexcept {
        polaris::InstanceHeartbeatRequest heartbeat_req(ServerConfig::_polaris_token, PolarisRegister::instance().get_intance_id());
        int service_not_find_count = 0;
        std::random_device rd;  
        std::mt19937 gen(rd()); 
        std::uniform_int_distribution<> distrib(1, 5);

        while(PolarisRegister::instance()._heart_beat_flag) {
            std::shared_ptr<polaris::ProviderApi> provider = PolarisRegister::instance().get_provider();
            if (provider == nullptr) {
                HILOG_APP(ERROR) << "get provider failed! " ;
                std::this_thread::sleep_for(std::chrono::milliseconds(500)); 
                continue;
            }
            polaris::ReturnCode res = provider->Heartbeat(heartbeat_req);
            HILOG_APP(INFO) << "heart beat res: " << res ;
            HILOG_APP(INFO) << "_instance_id: " << PolarisRegister::instance().get_intance_id() ;
            if (res == polaris::kReturnOk) {
                std::this_thread::sleep_for(std::chrono::seconds(ServerConfig::_polaris_health_ttl - 1));
            } else if(res == polaris::kReturnServiceNotFound && ++service_not_find_count>1) {   //重新注册
                int rand_int = distrib(gen);
                HILOG_APP(INFO) << "sleep for: "<< rand_int;
                //随机sleep 1-5 s，然后重新注册
                std::this_thread::sleep_for(std::chrono::seconds(rand_int));
                if(PolarisRegister::instance().register_to_polaris()) {
                    polaris::InstanceHeartbeatRequest heartbeat_req(ServerConfig::_polaris_token, PolarisRegister::instance().get_intance_id());
                    service_not_find_count = 0;
                }
            } 
            // sleep 500ms 防止cpu busy   
            std::this_thread::sleep_for(std::chrono::milliseconds(500)); 
        }
    }

};




