#ifndef _CORE_SERVER_IMP_H
#define _CORE_SERVER_IMP_H
#include "brpc/server.h"
#include "gflags/gflags.h"
#include "hlframe/context.h"
using namespace HLframe;
namespace Core {

    class Imp{
    public:
        Imp() = default;
        ~Imp() = default;
    public:
        virtual ContextPtr create_context() = 0;
        virtual std::string getGraphName(ContextPtr context) = 0;
    };

    
}

#endif
