#include "debug_imp.h"
#include "ranking/predict_service.pb.h"
#include "ranking/rank_debug_service.pb.h"
#include "brpc/server.h"
#include "core/core_services/fs/cache/fs_cache.h"
#include "handler/dump_item_feature_handler.h"
#include "handler/debug_param_handler.h"
#include <json2pb/pb_to_json.h>
#include <nlohmann/json.hpp>
#include <nlohmann/json_fwd.hpp>



void DebugServiceImp::Debug(google::protobuf::RpcController *cntl_base, const phx::HttpRequest * /*request*/,
                            ::phx::HttpResponse * /*response*/, google::protobuf::Closure *done) {
    brpc::ClosureGuard done_guard(done);
    brpc::Controller *cntl = static_cast<brpc::Controller *>(cntl_base);
    nlohmann::json response_json;
    try {
        const auto request_json = nlohmann::json::parse(cntl->request_attachment().to_string());

        // 参数校验
        const std::string method = request_json.at("method").get<std::string>();

        // 工厂创建处理器
        auto handler = HandlerFactory::instance().create(method);
        if (!handler) {
            throw std::runtime_error("Unsupported method: " + method);
        }

        // 执行处理
        handler->handle(request_json, response_json);
        cntl->http_response().set_status_code(brpc::HTTP_STATUS_OK);

    } catch (const nlohmann::json::exception &e) {
        // 统一异常处理
        response_json = {{"error", "JSON error"}, {"detail", e.what()}};
        cntl->http_response().set_status_code(brpc::HTTP_STATUS_BAD_REQUEST);
    } catch (const std::exception &e) {
        response_json = {{"error", e.what()}};
        cntl->http_response().set_status_code(brpc::HTTP_STATUS_INTERNAL_SERVER_ERROR);
    }

    // 统一响应处理
    cntl->http_response().set_content_type("application/json");
    cntl->response_attachment().append(response_json.dump());
}