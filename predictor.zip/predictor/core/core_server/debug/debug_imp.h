#pragma once
#include "ranking/predict_service.pb.h"
#include "ranking/rank_debug_service.pb.h"

class DebugServiceImp : public ::phx::HttpService {
public:
    void Debug(google::protobuf::RpcController *cntl_base, const phx::HttpRequest * /*request*/,
                            ::phx::HttpResponse * /*response*/, google::protobuf::Closure *done) ;
};