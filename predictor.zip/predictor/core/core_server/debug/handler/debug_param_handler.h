#pragma once
#include "core/utils/debug_param_manager.h"
#include "handler_register_proxy.h"
#include <nlohmann/json_fwd.hpp>

class DebugParamHandler : public HandlerRegisterProxy<DebugParamHandler> {

public:
    DebugParamHandler();
    const static std::string &GetMethodName() {
        static const std::string kTrafficCloneParamMethodName{"debugParam"};
        return kTrafficCloneParamMethodName;
    }
    void handle(const nlohmann::json &req, nlohmann::json &resp) override;
};
