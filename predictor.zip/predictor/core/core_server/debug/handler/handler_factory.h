#pragma once
#include <functional>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <unordered_map>
#include "debug_handler.h"
class HandlerFactory {
    public:
        using HandlerCreator = std::function<std::unique_ptr<DebugHandler>()>;
        
        static HandlerFactory& instance() {
            static HandlerFactory factory;
            return factory;
        }
    
        void registerHandler(const std::string& method, HandlerCreator creator) {
            std::unique_lock lock(rd_mtx_);
            handlers_[method] = std::move(creator);
        }
    
        std::unique_ptr<DebugHandler> create(const std::string& method) {
            std::shared_lock lock(rd_mtx_);
            auto it = handlers_.find(method);
            return (it != handlers_.end()) ? it->second() : nullptr;
        }
    
    private:
        std::unordered_map<std::string, HandlerCreator> handlers_;
        std::shared_mutex rd_mtx_;
    };
    