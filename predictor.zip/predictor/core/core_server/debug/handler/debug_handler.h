#pragma once
#include <nlohmann/json.hpp>


class DebugHandler {
public:
    virtual ~DebugHandler() = default;
    virtual void handle(const nlohmann::json& req, nlohmann::json& resp) = 0;
};





