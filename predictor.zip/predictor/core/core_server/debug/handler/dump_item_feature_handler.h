#pragma once
#include "core/core_services/fs/cache/fs_cache.h"
#include "handler_register_proxy.h"
#include <json2pb/pb_to_json.h>

class DumpItemFeatureHandler : public HandlerRegisterProxy<DumpItemFeatureHandler> {
public:
    const static std::string &GetMethodName() {
        static const std::string kDumpItemFeatureHandlerMethodName = "dumpItemFeature";
        return kDumpItemFeatureHandlerMethodName;
    }
    using ItemCacheType = decltype(g_double_message_caches);
    explicit DumpItemFeatureHandler() : cache_(g_double_message_caches) {
    }

    void handle(const nlohmann::json &req, nlohmann::json &resp) override {
        // 参数校验
        if (!req.contains("featureGroup")) {
            throw std::runtime_error("featureGroup is required");
        }

        const std::string fg = req["featureGroup"];
        if (auto iter = cache_.find(fg); iter != cache_.end()) {
            if (req.contains("featureGroup")) {
                auto fg = req["featureGroup"].get<std::string>();
                if (auto iter = g_double_message_caches.find(fg); iter != g_double_message_caches.end()) {
                    const auto &value_map = iter->second.get_current_obj();
                    std::string key{"PREDICTOR_TEST_NULL_KEY"};
                    if (req.contains("key")) {
                        key = req["key"].get<std::string>();

                    } else {
                        std::vector<std::string> valid_keys{};
                        std::vector<std::string> expire_keys{};
                        value_map->keys(valid_keys, expire_keys);
                        if (!valid_keys.empty()) {
                            key = valid_keys[0];
                        }
                    }
                    auto msg_ptr = value_map->get(key);
                    if (msg_ptr == nullptr) {
                        resp[key] = "null";
                    } else {
                        std::string json_msg{};
                        json2pb::ProtoMessageToJson(*msg_ptr->get_val(), &json_msg);
                        auto msg_json_obj = nlohmann::json::parse(json_msg);
                        resp[key] = msg_json_obj;
                        resp["expiredTime"] = msg_ptr->expire();
                    }
                } else {
                    resp["error"] = "request featureGroup [" + fg + "] do not found";
                }
            } else {
                resp["error"] = "request featureGroup is null!";
            }
        } else {
            resp["error"] = "FeatureGroup not found: " + fg;
        }
    }

private:
    const ItemCacheType &cache_;
};