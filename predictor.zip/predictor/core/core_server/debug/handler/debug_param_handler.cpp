#include "debug_param_handler.h"
DebugParamHandler::DebugParamHandler()  = default;
void DebugParamHandler::handle(const nlohmann::json &req, nlohmann::json &resp) {
    if (req.contains("param_method")) {
        std::string param_method = req["param_method"];
        if (param_method == "update") {
            std::string param_key = req.at("param_key");
            const nlohmann::json &object = req.at("param_object");
            debug::DebugParamManager::GetInstance().Update(param_key, object);
            resp["result"] = "success update param";
        } else if (param_method == "set") {
            std::string param_key = req.at("param_key");
            const nlohmann::json &object = req.at("param_object");
            debug::DebugParamManager::GetInstance().Set(param_key, object);
            resp["result"] = "success set param";
        } else if (param_method == "remove") {
            std::string param_key = req.at("param_key");
            debug::DebugParamManager::GetInstance().Remove(param_key);
            resp["result"] = "success set param";
        } else if (param_method == "get") {
            std::string param_key = req.at("param_key");
            resp[param_key] = debug::DebugParamManager::GetInstance().Get(param_key);
        } else {
            resp["error"] = "not supported param method:[" + param_method + "]; supported param method = [update, set, remove, get]";
        }
    } else {
        resp["error"] = "json request do not contains key : [param_method]";
    }
}