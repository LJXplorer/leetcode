#pragma once
#include <cxxabi.h>
#include <iostream>
#include "core/core_server/debug/handler/debug_handler.h"
#include "core/core_server/debug/handler/handler_factory.h"

template<typename T>
bool RegisteCreator() {
    std::string name = T::GetMethodName();
    HandlerFactory::instance().registerHandler(name, []() { return std::make_unique<T>(); });
    return true;
};

template<typename T>
struct HandlerRegisterProxy : DebugHandler {
    friend T;

    static bool registered;
    static bool trigger() {
        return RegisteCreator<T>();
    };

    HandlerRegisterProxy() : DebugHandler() {
        std::cout << abi::__cxa_demangle(typeid(this).name(), nullptr, nullptr, nullptr) << " registered = ["
                  << registered << "]" << std::endl;
    }
};
template<typename T>
bool HandlerRegisterProxy<T>::registered = HandlerRegisterProxy<T>::trigger();