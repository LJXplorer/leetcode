#ifndef _AD_PACKAGE_NAME_2_APPID_DICT_H_
#define _AD_PACKAGE_NAME_2_APPID_DICT_H_
#include "common/hidict/dict_manager.h"
#include "dict/item_info_dict.pb.h"
#include "phx-fe/ad_dict/ad_dict_template.h"
#include "phx-fe/decode/base64.h"

namespace AdDict {
    using package_name_2_app_id_type = AdDict::AdDictTemplate<std::string, phx::PackageName2AppIdDict>::ContainerType;
    class PackageName2AppIdInfoDict : public AdDict::AdDictTemplate<std::string, phx::PackageName2AppIdDict> {
    public:
        bool fill_dict_data(const std::vector<std::string> &src, void *data) override;
    };
    DICT_REGISTER(PackageName2AppIdInfoDict);
}// namespace AdDict

#endif