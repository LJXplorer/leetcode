#ifndef _AD_INFO_DICT_H_
#define _AD_INFO_DICT_H_
#include "ad_dict_template.h"
#include "common/hidict/dict_manager.h"
#include "dict/item_info_dict.pb.h"
#include "phx-fe/decode/base64.h"
#include <cstdint>
namespace AdDict {
    using adinfo_dict_type = AdDictTemplate<int64_t, phx::AdInfoDict>::ContainerType;
    class AdinfoDict : public AdDictTemplate<int64_t, phx::AdInfoDict> {};
    DICT_REGISTER(AdinfoDict);
}// namespace AdDict

#endif