#if __cplusplus >= 201703L
#include "common/hidict/dict_counters_provider.h"
#include "phx-fe/ad_dict/ad_dict_manager.h"

namespace hidict {
    hidict::RealCounters g_real;

    void
    RealCounters::do_drain_all(std::function<void(const std::string &path, const std::string &clazz_name,
                                                  const std::string &dict_version, const uint64_t *buf, size_t METRICS)>
                                       sink) {
        uint64_t buf[METRICS];
        // 上报每个注册的词典
        for (size_t i = 0; i < cells_.size(); ++i) {
            //取出当前词典的所有指标信息到buf 并清零
            cells_[i]->drain_into(buf);

            // 取词典版本信息
            hidict::DictInfo *dict_info = nullptr;
            if (infos_[i].path != "default") {
                dict_info = AdDict::AdDictCollectorInstance::instance().get_dict(infos_[i].path);
            }
            
            if (dict_info == nullptr) {
                // 未找到词典，可能是default
                // std::ostringstream oss;
                // oss << "buf: ";
                // for (size_t j = 0; j < METRICS; ++j) {
                //     oss << kMetricNames[j] << "=" << buf[j];
                //     if (j + 1 < METRICS)
                //         oss << ", ";
                // }
                // oss << ", path: " << infos_[i].path;
                // std::cout << oss.str() << std::endl;
                // HILOG_APP(INFO) << oss.str();
                sink(infos_[i].path, infos_[i].clazz_name, "default", buf, METRICS);
                continue;
            }
            // std::ostringstream oss;
            // oss << "buf: ";
            // for (size_t j = 0; j < METRICS; ++j) {
            //     oss << kMetricNames[j] << "=" << buf[j];
            //     if (j + 1 < METRICS)
            //         oss << ", ";
            // }
            // oss << ", path: " << infos_[i].path << ", dict_info: " << dict_info
            //     << ", dict_version: " << dict_info->get_latest_version();
            // std::cout << oss.str() << std::endl;
            // HILOG_APP(INFO) << oss.str();

            sink(infos_[i].path, infos_[i].clazz_name, dict_info->get_latest_version(), buf, METRICS);
        }
    }

    DictCountersProvider *g_counters = &NoopCounters::instance();
}// namespace hidict
#else
#include "offline_dict_counters_provider.h"
namespace hidict {
    hidict::RealCounters g_real;
    DictCountersProvider *g_counters = &NoopCounters::instance();
}// namespace hidict
#endif