#ifndef _AD_JIEBA_DICT_H_
#define _AD_JIEBA_DICT_H_
#include "common/hidict/dict_manager.h"
#include "phx-fe/decode/base64.h"
#include "cppjieba/Jieba.hpp"
namespace AdDict {
    class JieBaDict : public hidict::Dict<cppjieba::MixSegment> {
    private:
        std::string m_jieba_dict_file = "jieba.dict.utf8";
        std::string m_hmm_model_file = "hmm_model.utf8";
        std::string m_user_dict_file = "user.dict.utf8";

    public:
        JieBaDict();
        virtual ~JieBaDict();
        virtual int init(const std::string &dict_name, const std::string &path);
        const void *get_value_reflection() const override;
        const void *get_value_descriptor() const override;
        bool fill_dict_data(const std::vector<std::string> &src, void *data);
        virtual bool load();
        virtual void gen_data_info();
    };
    DICT_REGISTER(JieBaDict);
}// namespace AdDict

#endif