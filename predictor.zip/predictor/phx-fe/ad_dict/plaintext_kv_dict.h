#pragma once
#include "ad_dict_template.h"
#include "tf/feature.pb.h"
namespace AdDict {
    class PlaintextKvDict : public AdDict::AdDictTemplate<std::string, tensorflow::Feature> {
    public:
        bool fill_dict_data(const std::vector<std::string> &src, void *data) override;
    };
    DICT_REGISTER(PlaintextKvDict);
}// namespace AdDict