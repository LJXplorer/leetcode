#ifndef _GAME_STATS_DICT_H_
#define _GAME_STATS_DICT_H_
#include "common/hidict/dict_manager.h"
#include "dict/item_stats_dict.pb.h"
#include "phx-fe/ad_dict/ad_dict_template.h"
#include "phx-fe/decode/base64.h"

namespace AdDict {
    using game_stats_dict_type = AdDictTemplate<std::string, phx::GameStatsDict>::ContainerType;
    class GameStatsDict : public AdDictTemplate<std::string, phx::GameStatsDict> {};
    DICT_REGISTER(GameStatsDict);
}// namespace AdDict

#endif// !_GAME_STATS_DICT_H_