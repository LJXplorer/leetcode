#ifndef _APP_INFO_DICT_H_
#define _APP_INFO_DICT_H_
#include "common/hidict/dict_manager.h"
#include "phx-fe/ad_dict/ad_dict_template.h"
#include "phx-fe/decode/base64.h"
#include "dict/item_info_dict.pb.h"
namespace AdDict {
    using appinfo_dict_type = AdDictTemplate<int64_t, phx::AppInfoDict>::ContainerType;
    class AppinfoDict : public AdDictTemplate<int64_t, phx::AppInfoDict> {};
    DICT_REGISTER(AppinfoDict);
}// namespace AdDict

#endif