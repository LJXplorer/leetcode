#ifndef _AD_UNIT_DICT_H_
#define _AD_UNIT_DICT_H_
#include "common/hidict/dict_manager.h"
#include "dict/item_info_dict.pb.h"
#include "phx-fe/ad_dict/ad_dict_template.h"
#include "phx-fe/decode/base64.h"
namespace AdDict {
    using adunit_dict_type = AdDictTemplate<int64_t, phx::AdunitInfoDict>::ContainerType;
    class AdunitDict : public AdDictTemplate<int64_t, phx::AdunitInfoDict> {};
    DICT_REGISTER(AdunitDict);
}// namespace AdDict

#endif