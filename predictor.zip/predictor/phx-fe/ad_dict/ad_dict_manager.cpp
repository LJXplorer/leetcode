
#include "ad_dict_manager.h"
#include "common/hidict/dict_manager.h"
#if __cplusplus >= 201703L
#include "common/hidict/dict_counters_provider.h"
#else
#include "offline_dict_counters_provider.h"
#endif
#include <vector>
namespace AdDict {

const phx::AppInfoDict* AdDictCollector::get_appinfo(const std::string &dict_name,int64_t id){
    if(id == 0) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_OR_KEY_EMPTY);
        return nullptr;
    }
    static std::atomic<uint64_t> empty_count{0};
    if (dict_name.empty()) {
        hidict::g_counters->inc("default", hidict::Metric::TOTAL);
        hidict::g_counters->inc("default", hidict::Metric::MAP_OR_KEY_EMPTY);
        uint64_t count = empty_count.fetch_add(1, std::memory_order_relaxed) + 1;
        if (count % 10 == 0) {
            std::cout << "AdDictCollector::get_appinfo dict_name empty" << std::endl;
        }
        return nullptr;
    }

    auto dict_ture_name = _dict_name2path_map.find(dict_name);
    if(dict_ture_name == _dict_name2path_map.end()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto appinfo_map = AdDictCollectorInstance::instance().get_data<appinfo_dict_type>(dict_ture_name->second);
    if(appinfo_map == nullptr) {
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto app = appinfo_map->find(id);
    if(app == appinfo_map->end()) {
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_NOT_FOUND);
        return nullptr;
    }
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_FOUND);
    return app->second.get();
}

const phx::AdInfoDict* AdDictCollector::get_adinfo(const std::string &dict_name,int64_t id){
    if(id == 0) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_OR_KEY_EMPTY);

        return nullptr;
    }
    static std::atomic<uint64_t> empty_count{0};
    if(dict_name.empty()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_OR_KEY_EMPTY);
        uint64_t count = empty_count.fetch_add(1, std::memory_order_relaxed) + 1;
        if (count % 10 == 0) {
            std::cout << "AdDictCollector::get_adinfo dict_name empty" << std::endl;
        }
        return nullptr;
    }
    auto dict_ture_name = _dict_name2path_map.find(dict_name);
    if(dict_ture_name == _dict_name2path_map.end()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto appinfo_map = AdDictCollectorInstance::instance().get_data<adinfo_dict_type>(dict_ture_name->second);
    if(appinfo_map == nullptr) {
        #ifdef DEBUG_DICT
            std::cout<< "error,dict AdInfoDict get map empty, key: " << id<< std::endl; 
        #endif
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto app = appinfo_map->find(id);
    if(app == appinfo_map->end()) {
        #ifdef DEBUG_DICT
            std::cout<< "error,dict AdInfoDict get value empty, key: " << id<< std::endl; 
        #endif
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_NOT_FOUND);
        return nullptr;
    }

    #ifdef DEBUG_DICT
        std::cout<< "dict AdInfoDict get value success, key: " << id<< std::endl; 
        std::cout<< "value: " << app->second.get()->DebugString()<< std::endl; 
    #endif
    phx::AdunitInfoDict xx;
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_FOUND);
    return app->second.get();
}

const phx::AdunitInfoDict* AdDictCollector::get_adunitinfo(const std::string &dict_name,int64_t id){
    if(id == 0) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_OR_KEY_EMPTY);
        return nullptr;
    }

    static std::atomic<uint64_t> empty_count{0};
    if(dict_name.empty()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_OR_KEY_EMPTY);
        uint64_t count = empty_count.fetch_add(1, std::memory_order_relaxed) + 1;
        if (count % 10 == 0) {
            std::cout << "AdDictCollector::get_adunitinfo dict_name empty" << std::endl;
        }
        return nullptr;
    }


    auto dict_ture_name = _dict_name2path_map.find(dict_name);
    if(dict_ture_name == _dict_name2path_map.end()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto appinfo_map = AdDictCollectorInstance::instance().get_data<adunit_dict_type>(dict_ture_name->second);
    if(appinfo_map == nullptr) {
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto app = appinfo_map->find(id);
    if(app == appinfo_map->end()) {
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_NOT_FOUND);
        return nullptr;
    }
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_FOUND);
    return app->second.get();
}

const phx::ItemStatsDict* AdDictCollector::get_adstatinfo(const std::string &dict_name,const std::string& id){
    if(id.empty()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_OR_KEY_EMPTY);
        return nullptr;
    }
    auto dict_ture_name = _dict_name2path_map.find(dict_name);
    if(dict_ture_name == _dict_name2path_map.end()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto appinfo_map = AdDictCollectorInstance::instance().get_data<adstat_dict_type>(dict_ture_name->second);
    if(appinfo_map == nullptr) {
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto app = appinfo_map->find(id);
    if(app == appinfo_map->end()) {
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_NOT_FOUND);
        return nullptr;
    }
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_FOUND);
    return app->second.get();
}

const cppjieba::MixSegment* AdDictCollector::get_segment_info(const std::string &dict_name){
    static std::atomic<uint64_t> empty_count{0};
    if(dict_name.empty()) {
        uint64_t count = empty_count.fetch_add(1, std::memory_order_relaxed) + 1;
        if (count % 10 == 0) {
            std::cout << "AdDictCollector::get_segment_info dict_name empty" << std::endl;
        }
        return nullptr;
    }
    auto dict_ture_name = _dict_name2path_map.find(dict_name);
    if(dict_ture_name == _dict_name2path_map.end()) {
        return nullptr;
    }
    return AdDictCollectorInstance::instance().get_data<cppjieba::MixSegment>(dict_ture_name->second);
}

bool AdDictCollector::seg_cut(const std::string &dict_name,const std::string&src,std::vector<std::string>&words){
    if(src.empty()) {
        return false;
    }
    auto dict_ture_name = _dict_name2path_map.find(dict_name);
    if(dict_ture_name == _dict_name2path_map.end()) {
        return false;
    }
    auto seg = get_segment_info(dict_ture_name->second);
    if(seg == nullptr) {
        return false;
    }
    seg->Cut(src, words);
    return true;
}

const phx::AdQueryStatsInfo* AdDictCollector::get_adquerystats_info(const std::string& dict_name, const std::string& query){
    if(query.empty()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_OR_KEY_EMPTY);
        return nullptr;
    }
    auto dict_ture_name = _dict_name2path_map.find(dict_name);
    if(dict_ture_name == _dict_name2path_map.end()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto adquerystatsinfo_map = AdDictCollectorInstance::instance().get_data<adquerystatinfo_dict_type>(dict_ture_name->second);
    if(adquerystatsinfo_map == nullptr) {
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto app = adquerystatsinfo_map->find(query);
    if(app == adquerystatsinfo_map->end()) {
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_NOT_FOUND);
        return nullptr;
    }
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_FOUND);
    return app->second.get();
}

const phx::AdQueryCrossAppDict *AdDictCollector::get_adquerycrossapp_info(const std::string &dict_name,
                                                                          const std::string &query) {
    if(query.empty()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_OR_KEY_EMPTY);
        return nullptr;
    }
    auto dict_ture_name = _dict_name2path_map.find(dict_name);
    if(dict_ture_name == _dict_name2path_map.end()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto adquerycrossapp_map = AdDictCollectorInstance::instance().get_data<ad_query_cross_app_dict_type>(dict_ture_name->second);
    if(adquerycrossapp_map == nullptr) {
        #ifdef DEBUG_DICT
            std::cout<< "error, dict AdQueryCrossAppDict get map empty, key: " << query<< std::endl; 
        #endif
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    } 
    auto app = adquerycrossapp_map->find(query);
    if(app == adquerycrossapp_map->end()) {
        #ifdef DEBUG_DICT
            std::cout<< "error, dict AdQueryCrossAppDict get value empty, key: " << query<< std::endl; 
        #endif
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_NOT_FOUND);
        return nullptr;
    }
    #ifdef DEBUG_DICT
            std::cout<< "dict AdQueryStatsInfo get value success, key: " << query<< std::endl; 
            std::cout<< "value: " << app->second.get()->DebugString()<< std::endl; 
    #endif
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_FOUND);
    return app->second.get();
}

const phx::PackageName2AppIdDict *AdDictCollector::get_packagename2appid_info(const std::string &dict_name,
                                                                              const std::string &query) {
    if(query.empty()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_OR_KEY_EMPTY);
        return nullptr;
    }
    auto dict_ture_name = _dict_name2path_map.find(dict_name);
    if(dict_ture_name == _dict_name2path_map.end()) {
        hidict::g_counters->inc("default",hidict::Metric::TOTAL);
        hidict::g_counters->inc("default",hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto package_name_2_app_id_type_map = AdDictCollectorInstance::instance().get_data<package_name_2_app_id_type>(dict_ture_name->second);
    if(package_name_2_app_id_type_map == nullptr) {
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::MAP_NOT_FOUND);
        return nullptr;
    }
    auto app = package_name_2_app_id_type_map->find(query);
    if(app == package_name_2_app_id_type_map->end()) {
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
        hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_NOT_FOUND);
        return nullptr;
    }
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::TOTAL);
    hidict::g_counters->inc(dict_ture_name->second,hidict::Metric::KEY_FOUND);
    return app->second.get();
}

bool AdDictCollector::init(const std::string&name,const std::vector<hidict::DictConfig>&cfg,bool off) {
    if (name.empty() || cfg.empty()) {
        return false;
    }
   
    std::vector<hidict::DictConfig> vector_dict_configs;
    for (const auto& config: cfg) {
        _dict_name2path_map.insert({config.m_name,config.m_path});
        // 在线不需要初始化，直接在predictor那边全局初始化
        if (!off) {
            continue;
        }
        hidict::DictConfig hidict_config{};
        hidict_config.m_name = config.m_path;
        hidict_config.m_path = config.m_path;
        hidict_config.m_clazz = config.m_clazz;
        vector_dict_configs.emplace_back(hidict_config);   
    }
    // 在线不需要初始化，直接在predictor那边全局初始化
    if(off) {
        return AdDictCollectorInstance::instance().init(name, vector_dict_configs, off);
    }
    return true;
}

}// hidict

