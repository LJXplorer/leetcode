#ifndef _AD_DICT_MANAGER_H_
#define _AD_DICT_MANAGER_H_
#include "common/hidict/dict_manager.h"
#include "adinfo_dict.h"
#include "appinfo_dict.h"
#include "adunit_dict.h"
#include "adstat_dict.h"
#include "jieba_dict.h"
#include "adquerystatsinfo_dict.h"
#include "adquerycrossapp_dict.h"
#include "packagename2appid_dict.h"
#include "plaintext_kv_dict.h"
#include "gamestatsdict.h"
#if __cplusplus >= 201703L
#include "common/hidict/dict_counters_provider.h"
#else
#include "offline_dict_counters_provider.h"
#endif

#include <cppjieba/MixSegment.hpp>
#include <unordered_map>
using namespace hidict;
namespace AdDict {

class AdDictCollectorInstance: public hidict::DictCollector {
 public:

    AdDictCollectorInstance()
    {}
    ~AdDictCollectorInstance() {
    }
    
    static AdDictCollectorInstance& instance() {
        static AdDictCollectorInstance inst;
        return inst;
    }

    template <class T>
    const T* get_data(const std::string &dict_name){
        auto info = get_dict(dict_name);
        if(info == nullptr){
            return nullptr;
        }
        return info->get_data<T>();
    }
};

class AdDictCollector {
 public:
    AdDictCollector()
    {}
    ~AdDictCollector() {
    }
    // 映射到dict_name到path的map，
    // 对于每个AdDictCollector对象，一个dict_name只会有一个path，
    // 底层刷新和存储按照path来刷新
    std::unordered_map<std::string, std::string> _dict_name2path_map;
    const hidict::DictInfo * get_dict(const std::string& dict_name) {
        if (dict_name.empty()) return nullptr;
        auto dict_ture_name = _dict_name2path_map.find(dict_name);
        if(dict_ture_name == _dict_name2path_map.end()) {
            return nullptr;
        }
        return AdDictCollectorInstance::instance().get_dict(dict_ture_name->second);
    }

    template <class T>
    const T* get_data(const std::string &dict_name){
        if (dict_name.empty()) return nullptr;
        auto dict_ture_name = _dict_name2path_map.find(dict_name);
        if(dict_ture_name == _dict_name2path_map.end()) {
            std::cout<< " not find dict [ " <<dict_name << " ]"<<std::endl;
            return nullptr;
        }
        return AdDictCollectorInstance::instance().get_data<T>(dict_ture_name->second);
    }
    bool init(const std::string&name,const std::vector<hidict::DictConfig>&cfg,bool off = true);

    const phx::AppInfoDict* get_appinfo(const std::string &dict_name,int64_t id);
    const phx::AdInfoDict* get_adinfo(const std::string &dict_name,int64_t id);
    const phx::AdunitInfoDict* get_adunitinfo(const std::string &dict_name,int64_t id);
    const phx::ItemStatsDict* get_adstatinfo(const std::string &dict_name,const std::string& id);
    const cppjieba::MixSegment* get_segment_info(const std::string &dict_name);
    bool seg_cut(const std::string &dict_name,const std::string&src,std::vector<std::string>&dest);
    const phx::AdQueryStatsInfo* get_adquerystats_info(const std::string& dict_name, const std::string& query);
    const phx::AdQueryCrossAppDict* get_adquerycrossapp_info(const std::string& dict_name, const std::string& query);
    const phx::PackageName2AppIdDict* get_packagename2appid_info(const std::string& dict_name, const std::string& query);
    template <typename AdDictType> 
    const typename AdDictType::ValueT* get_value(const std::string& dict_name, const typename AdDictType::KeyT& key) {
        if (dict_name.empty()) {
            return nullptr;
        }
        auto dict_ture_name = _dict_name2path_map.find(dict_name);
        if(dict_ture_name == _dict_name2path_map.end()) {
            return nullptr;
        }
        auto dict_entity = AdDictCollectorInstance::instance().get_data<typename AdDictType::ContainerType>(dict_ture_name->second);
        if (dict_entity == nullptr) {
            return nullptr;
        }
        auto ret = dict_entity->find(key);
        if (ret == dict_entity->end()) {
            return nullptr;
        }
        return ret->second.get();
    }
};


}  // AdDict
#endif