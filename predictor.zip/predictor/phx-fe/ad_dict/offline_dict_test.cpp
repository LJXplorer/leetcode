#include <gflags/gflags.h>
#include <gflags/gflags_declare.h>
#include <string>
#include <map>
#include <iostream>
#include <fstream>
// #include "adquerycrossapp_dict.h"
#include "adinfo_dict.h"
#include "adquerycrossapp_dict.h"
#include "adquerystatsinfo_dict.h"
#include "adunit_dict.h"
#include "ad_dict_manager.h"
#include "phx-fe/decode/base64.h"
#include <filesystem>
#include "phx-fe/third_party/cppjieba-5.0.3/include/cppjieba/MixSegment.hpp"
#include "dict/item_info_dict.pb.h"

using namespace std;
using namespace hidict;


using namespace AdDict;

// namespace Core {
//    DEFINE_string(az_info, "az1", "az");
// };

void init_adinfo(){
  std::vector<hidict::DictConfig> hidict_configs;
  //adinfo
  hidict::DictConfig hidict_config_adinfo{};
  hidict_config_adinfo.m_name = "adinfo";
  hidict_config_adinfo.m_path = "/ad/ad_phx_predictor_dict/adinfo/20250820/0000";
  // hidict_config_adinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
  hidict_config_adinfo.m_clazz = "AdinfoDict";
  hidict_configs.emplace_back(hidict_config_adinfo);  

  AdDict::AdDictCollector* dict_collector = new AdDict::AdDictCollector();
  dict_collector->init("xxxxxxx", hidict_configs);

  sleep(10);
  const phx::AdInfoDict* dd = dict_collector->get_adinfo("adinfo", 50029291201);
  std::cout<< "value: " << dd->DebugString()<< std::endl;
}

int main(int argc,char* argv[]) {
  init_adinfo();
  
}