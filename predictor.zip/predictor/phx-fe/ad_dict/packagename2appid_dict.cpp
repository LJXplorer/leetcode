#include "packagename2appid_dict.h"

namespace AdDict {
    bool PackageName2AppIdInfoDict::fill_dict_data(const std::vector<std::string> &src, void *data) {
        if (data == nullptr || src.empty()){
            log_error(hidict::DICT_DATA_NULL,"");
            return false;
        }     
        package_name_2_app_id_type *map_data = (package_name_2_app_id_type *) data;

        if (src.size() >= 2) {
            try {
                auto info = std::make_shared<phx::PackageName2AppIdDict>();
                info->set_package_name(src.at(0));
                info->set_app_id(std::stol(src.at(1)));
                // map_data->insert_or_assign(info->package_name(), info);
                auto it = map_data->find(info->package_name());
                if (it != map_data->end()) {
                    it->second = info;
                } else {
                    map_data->insert(std::make_pair(info->package_name(), info)); 
                }
            } catch (...) {
                log_error(hidict::DICT_PARSE_FAILED,src[0]);
                this->parse_failed_num++;
                return false;
            }
        } else {
            log_error(hidict::DICT_DATA_SIZE_LESS2,"");
            this->parse_failed_num++;
            return false;
        }
        this->load_succ_num++;
        return true;
    }

}// namespace AdDict