#pragma once
#include <string>
namespace AdDict {
    template<typename T>
    T ConvertKey(const std::string &input);

    template<>
    inline int64_t ConvertKey<int64_t>(const std::string &input) {
        return std::stol(input);
    }

    template<>
    inline std::string ConvertKey<std::string>(const std::string &input) {
        return input;
    }
}// namespace AdDict
