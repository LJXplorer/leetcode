#pragma once
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include <atomic>

// 指标清单
#define METRIC_LIST(X)                                                                                                 \
    X(TOTAL)                                                                                                           \
    X(KEY_FOUND)                                                                                                       \
    X(MAP_OR_KEY_EMPTY)                                                                                                \
    X(MAP_NOT_FOUND)                                                                                                   \
    X(KEY_NOT_FOUND)
namespace hidict {

    enum class Metric : uint8_t {
#define ENUM_ELEM(name) name,
        METRIC_LIST(ENUM_ELEM)
#undef ENUM_ELEM
                _COUNT
    };


    class DictCountersProvider {
    public:
        inline void inc(std::string path, Metric m, uint64_t x = 1) const noexcept {
            
        }

    };

    class NoopCounters final : public DictCountersProvider {
    public:
        static NoopCounters &instance() {
            static NoopCounters x;
            return x;
        }
        NoopCounters() = default;
    };

    class RealCounters final : public DictCountersProvider {
    public:
        RealCounters() {
        }
    };

    extern DictCountersProvider *g_counters;
}// namespace hidict