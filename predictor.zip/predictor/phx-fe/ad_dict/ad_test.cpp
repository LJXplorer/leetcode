#include <gflags/gflags.h>
#include <gflags/gflags_declare.h>
#include <string>
#include <map>
#include <iostream>
#include <fstream>
// #include "adquerycrossapp_dict.h"
#include "adinfo_dict.h"
#include "adquerycrossapp_dict.h"
#include "adquerystatsinfo_dict.h"
#include "adunit_dict.h"
#include "ad_dict_manager.h"
#include "phx-fe/decode/base64.h"
#include <filesystem>
#include "phx-fe/third_party/cppjieba-5.0.3/include/cppjieba/MixSegment.hpp"
#include "dict/item_info_dict.pb.h"

using namespace std;
using namespace hidict;


using namespace AdDict;

// namespace Core {
//    DEFINE_string(az_info, "az1", "az");
// };

void  write_appinfo(int count){
  mkdir("./test/appinfo/", 0755);
  std::ofstream outfile("./test/appinfo/appinfo.txt",ios_base::out);
  for(int i =0;i<count;i++){
    phx::AppInfoDict appinfo_dict;
    appinfo_dict.set_app_id(111*10+i);
    appinfo_dict.set_package_name("com.wx.mm");
    appinfo_dict.set_app_name("微信");
    appinfo_dict.set_first_class("即时通讯");
    appinfo_dict.set_second_class("聊天");
    // appinfo_dict.set_third_class("交互");
    appinfo_dict.set_first_class_id(1000);
    appinfo_dict.set_second_class_id(2000);
    // appinfo_dict.set_third_class_id(3000);
    appinfo_dict.set_appstore_first_class_id(11000);
    appinfo_dict.set_appstore_second_class_id(12000);
    appinfo_dict.set_appstore_third_class_id(12000);
    for(int t = 0;t<5;t++){
      appinfo_dict.add_app_tags()->assign("tag-"+ std::to_string(i));
    }
    appinfo_dict.set_dev_name("荣耀");
    appinfo_dict.set_develop_id(333);
    appinfo_dict.set_in_app_product(1333);
    appinfo_dict.set_has_app_checked(1);
    appinfo_dict.set_has_ad (1);
    appinfo_dict.set_version_time_day_elapsed(0.86);
    appinfo_dict.set_stars(4);
    appinfo_dict.set_distribution_shape_five_star("绝世好App");
    std::string data_str;
    appinfo_dict.SerializeToString(&data_str);
    data_str = base64_encode(data_str);
    outfile<<std::to_string(appinfo_dict.app_id())<<'\t'<<data_str<<std::endl;
  }
  outfile.flush();
  outfile.close();
  std::ofstream out_succss("./test/appinfo/SUCCESS");
}


void  write_adinfo(int count){
  mkdir("./test/adinfo/", 0755);
  std::ofstream outfile("./test/adinfo/adinfo.txt",ios_base::out);
  for(int i =0;i<count;i++){
    phx::AdInfoDict adinfo_dict;
    adinfo_dict.set_creative_id(11000+i);
    adinfo_dict.set_ad_delivery_item_id("1");
    adinfo_dict.set_advertiser_id(10);
    adinfo_dict.set_ad_group_id(10000);
    adinfo_dict.set_ad_placement_id(10001);
    adinfo_dict.set_promotion_purpose(10);
    adinfo_dict.set_industry_id_l1(12);
    adinfo_dict.set_industry_id(99);
    adinfo_dict.set_creative_update_date_time("20250619");
    adinfo_dict.set_creative_create_date_time("20250619");
    adinfo_dict.set_ad_specs_type(11);
    adinfo_dict.set_source_ad_group_id(44);
    adinfo_dict.set_ad_group_ad_bid (300);
    adinfo_dict.set_ad_group_ad_day_budget(200);
    adinfo_dict.set_ad_group_programmatic(100);
    adinfo_dict.set_app_id(2222);
    adinfo_dict.set_pkg_size(100.0);
    adinfo_dict.set_pkg_version("v2");
    adinfo_dict.set_ad_unit_type(2);
    adinfo_dict.add_placement_promotion_purpose("1");
    adinfo_dict.add_placement_promotion_purpose("2");
    adinfo_dict.set_advertiser_protocol_type(1);
    adinfo_dict.set_package_name("com.wx.mm");
    adinfo_dict.set_ad_creative_template_id(10);
    adinfo_dict.set_cost_type(4);
    adinfo_dict.set_ad_bid(4);
    adinfo_dict.set_ocpx_sbp(1);
    adinfo_dict.set_ocpx_deep_price(1);
    adinfo_dict.set_conv_type(1);
    adinfo_dict.set_deep_conv_type(1);
    std::string data_str;
    adinfo_dict.SerializeToString(&data_str);
    data_str = base64_encode(data_str);
    
    outfile<<std::to_string(adinfo_dict.creative_id())<<'\t'<<data_str<<std::endl;
  }
  outfile.flush();
  outfile.close();
  std::ofstream out_succss("./test/adinfo/SUCCESS");
}

void  write_adunitinfo(int count){
  mkdir("./test/adunitinfo/d1/d2", 0755);
  std::ofstream outfile("./test/adunitinfo/d1/d2/adunitinfo.txt",ios_base::out);
  for(int i =0;i<count;i++){
    phx::AdunitInfoDict adu_dict;
    adu_dict.set_ad_unit_id(122455+i);
    adu_dict.set_media_id(2223);
    adu_dict.set_media_type(1); 
    adu_dict.set_operation_platforms(1);
    adu_dict.set_type(2); 
    adu_dict.set_action_type(2);
    adu_dict.set_is_carousel(3);
    adu_dict.set_incentive_flag(1);
    adu_dict.set_detail_page_open_mode(6);
    adu_dict.set_render_mode(1);
    adu_dict.set_access_type(0);
    adu_dict.set_media_package("xxx1");
    adu_dict.set_industry_id_l1("ind-1");
    adu_dict.set_industry_id_l2("ind-2");
    std::string data_str;
    adu_dict.SerializeToString(&data_str);
    data_str = base64_encode(data_str);
    
    outfile<<std::to_string(adu_dict.ad_unit_id())<<'\t'<<data_str<<std::endl;
  }
  outfile.flush();
  outfile.close();
  std::ofstream out_succss("./test/adunitinfo/d1/d2/SUCCESS");
}

void  write_adunitinfo1(int count){
  mkdir("./test/adunitinfo/d1/d3", 0755);
  std::ofstream outfile("./test/adunitinfo/d1/d3/adunitinfo1.txt",ios_base::out);
  for(int i =0;i<count;i++){
    phx::AdunitInfoDict adu_dict;
    adu_dict.set_ad_unit_id(122455+i);
    adu_dict.set_media_id(2223);
    adu_dict.set_media_type(1); 
    adu_dict.set_operation_platforms(1);
    adu_dict.set_type(2); 
    adu_dict.set_action_type(2);
    adu_dict.set_is_carousel(3);
    adu_dict.set_incentive_flag(1);
    adu_dict.set_detail_page_open_mode(6);
    adu_dict.set_render_mode(1);
    adu_dict.set_access_type(0);
    adu_dict.set_media_package("xxx");
    adu_dict.set_industry_id_l1("ind-11");
    adu_dict.set_industry_id_l2("ind-22");
    std::string data_str;
    adu_dict.SerializeToString(&data_str);
    data_str = base64_encode(data_str);
    
    outfile<<std::to_string(adu_dict.ad_unit_id())<<'\t'<<data_str<<std::endl;
  }
  outfile.flush();
  outfile.close();
  std::ofstream out_succss("./test/adunitinfo/d1/d3/SUCCESS");
}


int test_single(int argc,char* argv[]) 
{
    // if(argc > 1){
    //   write_appinfo(10);
    //   write_adinfo(10);
    //   write_adunitinfo(10);
    // }
    std::cout<<"class size:"<<::hidict::DictRegisterMgr::instance()->m_global_dict_map.size()<<std::endl;
    for(auto&c : ::hidict::DictRegisterMgr::instance()->m_global_dict_map){
      std::cout<<c.first<<std::endl;
    }

    // std::string dict_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat/";
    // std::string dict_class = "AdQueryCrossApp";
    // std::vector<hidict::DictConfig> hidict_configs;
    // hidict::DictConfig hidict_config{};
    // hidict_config.m_name = dict_path;
    // hidict_config.m_path = dict_path;
    // hidict_config.m_clazz = dict_class;
    // hidict_configs.emplace_back(hidict_config); 
    // AdDict::AdDictCollectorInstance::instance().init("test", hidict_configs);


    // AdDictCollector coll_test;
    // coll_test.register_dict("adInfo","AdinfoDict","/data/goo/ad/ad_phx_predictor_dict/adinfo");
    // // coll_test.register_dict("query","AdQueryStatsInfoDict","/data/goo/ad/ad_phx_predictor_dict/adquerystat/20250713/0000");
    // //coll_test.register_dict("adunitinfo","AdunitDict","./test/adunitinfo");
  
    // // // coll_test.register_dict("jieba","JieBaDict","/jieba/");
    // coll_test.run(false);
    // AdDict::AdDictCollectorInstance::instance().run(false);
    // sleep(5);
    
    std::string dict_path1 = "/root/tmp_dir/20250818/0000/";
    std::string dict_class1 = "AdStatDict";
    std::vector<hidict::DictConfig> hidict_configs1;
    hidict::DictConfig hidict_config1{};
    hidict_config1.m_name = "test";
    hidict_config1.m_path = dict_path1;
    hidict_config1.m_clazz = dict_class1;
    hidict_configs1.emplace_back(hidict_config1); 
    AdDict::AdDictCollector *dict_collector = new AdDict::AdDictCollector();
    long handle = reinterpret_cast<long>(dict_collector);
    dict_collector->init(std::to_string(handle), hidict_configs1);
    
    while (1)
    {
      
        sleep(10);
        auto xxx = dict_collector->get_dict("test");
        std::cout<< "xxx: " << xxx->m_name << std::endl; 
        const auto map_data = dict_collector->get_data<adstat_dict_type>("test");
        // AdDict::AdDictCollectorInstance::instance().get_data<adinfo_dict_type>("test");
        if(map_data == nullptr) std::cout<<"map_data nullptr"<<std::endl;
        std::cout<<"adinfo_dict_type: main size "<<map_data->size()<<std::endl;

        auto val_it= map_data->find("h20764388a2391423");
        std::cout<< "key: "<<val_it->first <<std::endl;
        std::cout<< "value: "<<val_it->second->DebugString() <<std::endl;
        
    }
    
}
void init_online_dict(std::string& dict_collect_name) {
    std::vector<hidict::DictConfig> hidict_configs;
    //adinfo
    hidict::DictConfig hidict_config_adinfo{};
    hidict_config_adinfo.m_name = "/data/goo/ad/ad_phx_predictor_dict/adinfo";
    hidict_config_adinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    // hidict_config_adinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/adinfo";
    hidict_config_adinfo.m_clazz = "AdinfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo);  

    //adquerycross
    hidict::DictConfig hidict_config_adinfo_adquerycross{};
    hidict_config_adinfo_adquerycross.m_name = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    hidict_config_adinfo_adquerycross.m_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    hidict_config_adinfo_adquerycross.m_clazz = "AdQueryCrossAppInfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adquerycross);  

    //adquerystats
    hidict::DictConfig hidict_config_adinfo_adquerystats{};
    hidict_config_adinfo_adquerystats.m_name = "/data/goo/ad/ad_phx_predictor_dict/adquerystat";
    hidict_config_adinfo_adquerystats.m_path = "/data/goo/ad/ad_phx_predictor_dict/adquerystat";
    hidict_config_adinfo_adquerystats.m_clazz = "AdQueryStatsInfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adquerystats);  

    //adstats
    hidict::DictConfig hidict_config_adinfo_adstats{};
    hidict_config_adinfo_adstats.m_name = "/data/goo/ad/ad_phx_predictor_dict/aditemstat";
    hidict_config_adinfo_adstats.m_path = "/data/goo/ad/ad_phx_predictor_dict/aditemstat";
    hidict_config_adinfo_adstats.m_clazz = "AdStatDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adstats);  

    //adunit
    hidict::DictConfig hidict_config_adinfo_adunit{};
    hidict_config_adinfo_adunit.m_name = "/data/goo/ad/ad_phx_predictor_dict/adunitinfo";
    hidict_config_adinfo_adunit.m_path = "/data/goo/ad/ad_phx_predictor_dict/adunitinfo";
    hidict_config_adinfo_adunit.m_clazz = "AdunitDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adunit);  

    //appinfo
    hidict::DictConfig hidict_config_adinfo_appinfo{};
    hidict_config_adinfo_appinfo.m_name = "/data/goo/ad/ad_phx_predictor_dict/appinfo";
    hidict_config_adinfo_appinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/appinfo";
    hidict_config_adinfo_appinfo.m_clazz = "AppinfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_appinfo); 

    //jieba
    hidict::DictConfig hidict_config_adinfo_jieba{};
    hidict_config_adinfo_jieba.m_name = "/data/goo/ad/ad_phx_predictor_dict/jieba";
    hidict_config_adinfo_jieba.m_path = "/data/goo/ad/ad_phx_predictor_dict/jieba";
    hidict_config_adinfo_jieba.m_clazz = "JieBaDict";
    hidict_configs.emplace_back(hidict_config_adinfo_jieba); 

    long handle = reinterpret_cast<long>(&hidict_configs);
    AdDict::AdDictCollectorInstance::instance().init(std::to_string(handle), hidict_configs, false);
  
    //waiting for first time done of loading dict
    while (!AdDict::AdDictCollectorInstance::instance().get_first_load_done()) {
        std::cout << "wating for dict load done" << std::endl;
        sleep(1);
    }
    dict_collect_name = std::to_string(handle);
    std::cout << "all dict load done" << std::endl;

}

void get_data1(AdDict::AdDictCollector* dict_collector) {

  while (1) {
    std::cout<< " adinfo size: "<< dict_collector->get_dict("adinfo")->get_data<adinfo_dict_type>()->size() 
    << "parse failed size: " << dict_collector->get_dict("adinfo")->parse_failed_num
    <<std::endl;

    std::cout<< " adquerycross size: "<< dict_collector->get_dict("adquerycross")->get_data<ad_query_cross_app_dict_type>()->size() 
    << "parse failed size: " << dict_collector->get_dict("adquerycross")->parse_failed_num
    <<std::endl;

    std::cout<< " adstats size: "<< dict_collector->get_dict("adstats")->get_data<adstat_dict_type>()->size() 
    << "parse failed size: " << dict_collector->get_dict("adstats")->parse_failed_num
    <<std::endl;

    std::cout<< " adunit size: "<< dict_collector->get_dict("adunit")->get_data<adunit_dict_type>()->size()
    << "parse failed size: " << dict_collector->get_dict("adunit")->parse_failed_num
     <<std::endl;

    std::cout<< " appinfo size: "<< dict_collector->get_dict("appinfo")->get_data<appinfo_dict_type>()->size() 
    << "parse failed size: " << dict_collector->get_dict("appinfo")->parse_failed_num
    <<std::endl;

    std::cout<< " jieba size: "<< dict_collector->get_dict("jieba")->get_data<cppjieba::MixSegment>()->GetDictTrie()->WordWeightMax 
    << "parse failed size: " << dict_collector->get_dict("jieba")->parse_failed_num
    <<std::endl;

    sleep(10);
  }

  
}

void test_online() {
  std::string dict_collect_name = "";
  init_online_dict(dict_collect_name);

  std::cout<< "dict_collect_name: " << dict_collect_name <<std::endl;

  std::vector<hidict::DictConfig> hidict_configs;
    //adinfo
    hidict::DictConfig hidict_config_adinfo{};
    hidict_config_adinfo.m_name = "adinfo";
    hidict_config_adinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/adinfo";
    // hidict_config_adinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    hidict_config_adinfo.m_clazz = "AdinfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo);  

    //adquerycross
    hidict::DictConfig hidict_config_adinfo_adquerycross{};
    hidict_config_adinfo_adquerycross.m_name = "adquerycross";
    hidict_config_adinfo_adquerycross.m_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    hidict_config_adinfo_adquerycross.m_clazz = "AdQueryCrossAppInfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adquerycross);  

    //adquerystats
    hidict::DictConfig hidict_config_adinfo_adquerystats{};
    hidict_config_adinfo_adquerystats.m_name = "adquerystats";
    hidict_config_adinfo_adquerystats.m_path = "/data/goo/ad/ad_phx_predictor_dict/adquerystat";
    hidict_config_adinfo_adquerystats.m_clazz = "AdQueryStatsInfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adquerystats);  

    //adstats
    hidict::DictConfig hidict_config_adinfo_adstats{};
    hidict_config_adinfo_adstats.m_name = "adstats";
    hidict_config_adinfo_adstats.m_path = "/data/goo/ad/ad_phx_predictor_dict/aditemstat";
    hidict_config_adinfo_adstats.m_clazz = "AdStatDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adstats);  

    //adunit
    hidict::DictConfig hidict_config_adinfo_adunit{};
    hidict_config_adinfo_adunit.m_name = "adunit";
    hidict_config_adinfo_adunit.m_path = "/data/goo/ad/ad_phx_predictor_dict/adunitinfo";
    hidict_config_adinfo_adunit.m_clazz = "AdunitDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adunit);  

    //appinfo
    hidict::DictConfig hidict_config_adinfo_appinfo{};
    hidict_config_adinfo_appinfo.m_name = "appinfo";
    hidict_config_adinfo_appinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/appinfo";
    hidict_config_adinfo_appinfo.m_clazz = "AppinfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_appinfo); 

    //jieba
    hidict::DictConfig hidict_config_adinfo_jieba{};
    hidict_config_adinfo_jieba.m_name = "jieba";
    hidict_config_adinfo_jieba.m_path = "/data/goo/ad/ad_phx_predictor_dict/jieba";
    hidict_config_adinfo_jieba.m_clazz = "JieBaDict";
    hidict_configs.emplace_back(hidict_config_adinfo_jieba); 

    AdDict::AdDictCollector* dict_collector = new AdDict::AdDictCollector();
    dict_collector->init(dict_collect_name, hidict_configs,false);
  
    get_data1(dict_collector);

}



int main(int argc,char* argv[]) {
  // test_online();

  std::vector<hidict::DictConfig> hidict_configs;
    //adinfo
    hidict::DictConfig hidict_config_adinfo{};
    hidict_config_adinfo.m_name = "adinfo";
    hidict_config_adinfo.m_path = "/ad/ad_phx_predictor_dict/adinfo/20250821/0000";
    // hidict_config_adinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    hidict_config_adinfo.m_clazz = "AdinfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo);  

    /ad/ad_phx_predictor_dict/adunitinfo/20250821/0000
  //adinfo
    hidict::DictConfig hidict_config_adinfo{};
    hidict_config_adinfo.m_name = "adinfo";
    hidict_config_adinfo.m_path = "/ad/ad_phx_predictor_dict/adinfo/20250821/0000";
    // hidict_config_adinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    hidict_config_adinfo.m_clazz = "AdinfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo); 

    AdDict::AdDictCollector* dict_collector = new AdDict::AdDictCollector();
    dict_collector->init("xxxxxxx", hidict_configs);

    sleep(10);
    const phx::AdInfoDict* dd = dict_collector->get_adinfo("adinfo", 50029291201);
    std::cout<< "value: " << dd->DebugString()<< std::endl;
}