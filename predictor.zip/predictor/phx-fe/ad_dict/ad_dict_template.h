#pragma once
#include "common/hidict/dict.h"
#include "phx-fe/decode/base64.h"
#include <memory>
#include <unordered_map>
#include "key_convert.h"
namespace AdDict {

    template<typename KeyType, typename ValueType>
    class AdDictTemplate : public hidict::Dict<std::unordered_map<KeyType, std::shared_ptr<ValueType>>> {
    public:
        using ContainerType = std::unordered_map<KeyType, std::shared_ptr<ValueType>>;
        using KeyT = KeyType;
        using ValueT = ValueType;
        AdDictTemplate() = default;
        int init(const std::string &dict_name, const std::string &path) override {
            this->m_name = dict_name;
            this->m_path = path;
            return 0;
        }
        const void *get_value_reflection() const override {
            return ValueType::GetReflection();
        }
        const void *get_value_descriptor() const override {
            return ValueType::GetDescriptor();
        }

        bool fill_dict_data(const std::vector<std::string> &src, void *data) override {
            if (data == nullptr || src.empty()) {
                hidict::Dict<ContainerType>::log_error(hidict::DICT_DATA_NULL, "");
                return false;
            }
            auto *map_data = (ContainerType *) data;

            if (src.size() >= 2) {
                try {
                    std::string decode_base64 = base64_decode(src[1]);
                    if (decode_base64.empty()) {
                        hidict::Dict<ContainerType>::log_error(hidict::DICT_VALUE_EMPTY, src[0]);
                        this->parse_failed_num++;
                        return false;
                    }

                    auto info = std::make_shared<ValueType>();
                    auto succ = info->ParseFromString(decode_base64);
                    
                    if (succ) {
                        auto key = ConvertKey<KeyType>(src[0]);
                        auto it = map_data->find(key);
                        if (it != map_data->end()) {
                            it->second = info;
                        } else {
                            map_data->insert(std::make_pair(key, info));
                        }
                    } else {
                        hidict::Dict<ContainerType>::log_error(hidict::DICT_PARSE_FAILED, src[0]);
                        this->parse_failed_num++;
                        return false;
                    }

                } catch (...) {
                    hidict::Dict<ContainerType>::log_error(hidict::DICT_PARSE_FAILED, src[0]);
                    this->parse_failed_num++;
                    return false;
                }
            } else {
                hidict::Dict<ContainerType>::log_error(hidict::DICT_DATA_SIZE_LESS2, "");
                this->parse_failed_num++;
                return false;
            }
            this->load_succ_num++;
            return true;
        }

        void gen_data_info() override {
            this->m_dict[0] = std::make_shared<ContainerType>();
            this->m_dict[1] = std::make_shared<ContainerType>();
        }

        virtual void reset(int32_t idx) override {
            if (this->m_dict[idx]) {
                this->m_dict[idx]->clear();
                this->m_dict[idx] = std::make_shared<ContainerType>();
            }
            std::cout << "dict class name: " << "dict reset size: " << this->m_dict[idx]->size() << " idx: " << idx
                      << " current size: " << this->m_dict[1 - idx]->size() << std::endl;
        }
    };

}// namespace AdDict