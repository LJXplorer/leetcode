#include "jieba_dict.h"
#include <cstdlib>
namespace AdDict {

    JieBaDict::JieBaDict() {
    }

    JieBaDict::~JieBaDict() {
    }

    int JieBaDict::init(const std::string &dict_name, const std::string &path) {
        m_name = dict_name;
        m_path = path;
        is_no_version = true;
        if(is_directory(m_path) == false){
            std::cout <<"[" <<time(NULL) <<"] dict [" <<  dict_name << "] "<<"class [JieBaDict] "<<" path not dir, path ["<< m_path <<"]"<< std::endl;
            return -1;
        }

        if(is_file(m_path + "/" + m_jieba_dict_file) == false){
            std::cout <<"[" <<time(NULL) <<"] dict [" <<  dict_name << "] "<<"class [JieBaDict] "<<" m_jieba_dict_file is not file, path ["<< 
                    m_path + "/" + m_jieba_dict_file <<"]"<< std::endl;
            return -2;
        }

        if(is_file(m_path + "/" + m_hmm_model_file) == false){
            std::cout <<"[" <<time(NULL) <<"] dict [" <<  dict_name << "] "<<"class [JieBaDict] "<<" m_hmm_model_file is not file, path ["<< 
                    m_path + "/" + m_hmm_model_file <<"]"<< std::endl;
            return -3;
        }

        if(is_file(m_path + "/" + m_user_dict_file) == false){
            std::cout <<"[" <<time(NULL) <<"] dict [" <<  dict_name << "] "<<"class [JieBaDict] "<<" m_user_dict_file is not file, path ["<< 
                    m_path + "/" + m_user_dict_file <<"]"<< std::endl;
            return -4;
        }
        return 0;
    }

    bool JieBaDict::load(){
        return true;
    }

    void JieBaDict::gen_data_info(){
        try {
            this->m_dict[0] = std::make_shared<cppjieba::MixSegment>(m_path + "/" + m_jieba_dict_file,
                                             m_path + "/" + m_hmm_model_file,
                                             m_path + "/" + m_user_dict_file);
            this->m_dict[1] =  std::make_shared<cppjieba::MixSegment>(m_path + "/" + m_jieba_dict_file,
                                             m_path + "/" + m_hmm_model_file,
                                             m_path + "/" + m_user_dict_file);
        } catch(...) {
            std::cout <<"[" <<time(NULL) <<"] dict [" <<  m_name << "] "<<"class [JieBaDict] "<<"load failed, aborted..."<< std::endl;
            abort();
        }

        std::cout <<"[" <<time(NULL) <<"] dict [" <<  m_name << "] "<<"class [JieBaDict] "<<"load finished"<< std::endl;
        
    }

    bool JieBaDict::fill_dict_data(const std::vector<std::string> &src, void *data) {
        return true;
    }

    const void *JieBaDict::get_value_reflection() const {
        return nullptr;
    }

    const void *JieBaDict::get_value_descriptor() const {
        return nullptr;
    }
   
}// namespace AdDict