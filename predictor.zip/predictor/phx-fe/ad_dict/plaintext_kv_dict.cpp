#include "plaintext_kv_dict.h"
#include "common/hidict/dict.h"
#include "phx-fe/util/calc.h"
#include "phx-fe/util/util.h"
#include <memory>
#include <utility>
namespace AdDict {
    bool PlaintextKvDict::fill_dict_data(const std::vector<std::string> &src, void *data) {
        if (data == nullptr || src.empty()) {
            log_error(hidict::DICT_DATA_NULL, "");
            return false;
        }
        auto *map_data = (ContainerType *) data;

        if (src.size() >= 3) {
            try {
                const auto &key = src.at(0);
                const auto &value_type = src.at(1);
                const auto &values = src.at(2);
                if (unlikely(map_data->find(key) != map_data->end())) {
                    log_error(hidict::DICT_REPEATED_KEY, key);
                    this->parse_failed_num++;
                    return false;
                }
                auto feature_value = std::make_shared<tensorflow::Feature>();
                if (value_type == "string") {
                    auto value_splits = Calc::split_string(values, ",");
                    for (auto &value_split : value_splits) {
                        feature_value->mutable_bytes_list()->add_value(value_split);
                    }
                } else if (value_type == "int64") {
                    auto value_splits = Calc::split_string(values, ",");
                    for (auto &value_split : value_splits) {
                        feature_value->mutable_int64_list()->add_value(std::stol(value_split));
                    }
                } else {
                    log_error(hidict::DICT_VALUE_TYPE_UNKNOWN, value_type);
                    this->parse_failed_num++;
                    return false;
                }
                map_data->insert(std::make_pair(key, feature_value));

            } catch (...) {
                log_error(hidict::DICT_PARSE_FAILED, src[0]);
                this->parse_failed_num++;
                return false;
            }
        } else {
            log_error(hidict::DICT_DATA_SIZE_LESS2, "");
            this->parse_failed_num++;
            return false;
        }
        this->load_succ_num++;
        return true;
    }
}// namespace AdDict