#ifndef _AD_QUERY_CROSS_APP_DICT_H_
#define _AD_QUERY_CROSS_APP_DICT_H_
#include "common/hidict/dict_manager.h"
#include "phx-fe/ad_dict/ad_dict_template.h"
#include "phx-fe/decode/base64.h"
#include "dict/item_query_cross_dict.pb.h"

namespace AdDict {
    using ad_query_cross_app_dict_type = AdDictTemplate<std::string, phx::AdQueryCrossAppDict>::ContainerType;
    class AdQueryCrossAppInfoDict : public AdDictTemplate<std::string, phx::AdQueryCrossAppDict> {
    };
    DICT_REGISTER(AdQueryCrossAppInfoDict);
}// namespace AdDict

#endif