#ifndef _AD_QUERY_STATS_INFO_H
#define _AD_QUERY_STATS_INFO_H
#include "common/hidict/dict_manager.h"
#include "dict/item_query_cross_dict.pb.h"
#include "phx-fe/ad_dict/ad_dict_template.h"
#include "phx-fe/decode/base64.h"
namespace AdDict {
    using adquerystatinfo_dict_type = AdDictTemplate<std::string, phx::AdQueryStatsInfo>::ContainerType;
    class AdQueryStatsInfoDict : public AdDictTemplate<std::string, phx::AdQueryStatsInfo> {};
    DICT_REGISTER(AdQueryStatsInfoDict);
}// namespace AdDict

#endif