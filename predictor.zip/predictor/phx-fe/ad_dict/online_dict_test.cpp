#include <gflags/gflags.h>
#include <gflags/gflags_declare.h>
#include <string>
#include <map>
#include <iostream>
#include <fstream>
// #include "adquerycrossapp_dict.h"
#include "adinfo_dict.h"
#include "adquerycrossapp_dict.h"
#include "adquerystatsinfo_dict.h"
#include "adunit_dict.h"
#include "ad_dict_manager.h"
#include "phx-fe/decode/base64.h"
#include <filesystem>
#include "phx-fe/third_party/cppjieba-5.0.3/include/cppjieba/MixSegment.hpp"

using namespace std;
using namespace hidict;


using namespace AdDict;

template<typename DictType>
class AdDictCallback : public hidict::DictCallback {
public:
    bool OnLoadFinished(time_t n, bool load_suc) override {
        return true;
    }
    void OnError() override {
        
    }
};
   

// namespace Core {
//    DEFINE_string(az_info, "az1", "az");
// };

int test_single(int argc,char* argv[]) 
{
    // if(argc > 1){
    //   write_appinfo(10);
    //   write_adinfo(10);
    //   write_adunitinfo(10);
    // }
    std::cout<<"class size:"<<::hidict::DictRegisterMgr::instance()->m_global_dict_map.size()<<std::endl;
    for(auto&c : ::hidict::DictRegisterMgr::instance()->m_global_dict_map){
      std::cout<<c.first<<std::endl;
    }

    // std::string dict_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat/";
    // std::string dict_class = "AdQueryCrossApp";
    // std::vector<hidict::DictConfig> hidict_configs;
    // hidict::DictConfig hidict_config{};
    // hidict_config.m_name = dict_path;
    // hidict_config.m_path = dict_path;
    // hidict_config.m_clazz = dict_class;
    // hidict_configs.emplace_back(hidict_config); 
    // AdDict::AdDictCollectorInstance::instance().init("test", hidict_configs);


    // AdDictCollector coll_test;
    // coll_test.register_dict("adInfo","AdinfoDict","/data/goo/ad/ad_phx_predictor_dict/adinfo");
    // // coll_test.register_dict("query","AdQueryStatsInfoDict","/data/goo/ad/ad_phx_predictor_dict/adquerystat/20250713/0000");
    // //coll_test.register_dict("adunitinfo","AdunitDict","./test/adunitinfo");
  
    // // // coll_test.register_dict("jieba","JieBaDict","/jieba/");
    // coll_test.run(false);
    // AdDict::AdDictCollectorInstance::instance().run(false);
    // sleep(5);
    
    std::string dict_path1 = "/root/tmp_dir/20250818/0000/";
    std::string dict_class1 = "AdStatDict";
    std::vector<hidict::DictConfig> hidict_configs1;
    hidict::DictConfig hidict_config1{};
    hidict_config1.m_name = "test";
    hidict_config1.m_path = dict_path1;
    hidict_config1.m_clazz = dict_class1;
    hidict_configs1.emplace_back(hidict_config1); 
    AdDict::AdDictCollector *dict_collector = new AdDict::AdDictCollector();
    long handle = reinterpret_cast<long>(dict_collector);
    dict_collector->init(std::to_string(handle), hidict_configs1);
    
    while (1)
    {
      
        sleep(10);
        auto xxx = dict_collector->get_dict("test");
        std::cout<< "xxx: " << xxx->m_name << std::endl; 
        const auto map_data = dict_collector->get_data<adstat_dict_type>("test");
        // AdDict::AdDictCollectorInstance::instance().get_data<adinfo_dict_type>("test");
        if(map_data == nullptr) std::cout<<"map_data nullptr"<<std::endl;
        std::cout<<"adinfo_dict_type: main size "<<map_data->size()<<std::endl;

        auto val_it= map_data->find("h20764388a2391423");
        std::cout<< "key: "<<val_it->first <<std::endl;
        std::cout<< "value: "<<val_it->second->DebugString() <<std::endl;
        
    }
    
}
void init_online_dict(std::string& dict_collect_name) {
    std::vector<hidict::DictConfig> hidict_configs;
    //adinfo
    hidict::DictConfig hidict_config_adinfo{};
    hidict_config_adinfo.m_name = "/data/goo/ad/ad_phx_predictor_dict/adinfo";
    hidict_config_adinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    // hidict_config_adinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/adinfo";
    hidict_config_adinfo.m_clazz = "AdinfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo);  

    //adquerycross
    hidict::DictConfig hidict_config_adinfo_adquerycross{};
    hidict_config_adinfo_adquerycross.m_name = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    hidict_config_adinfo_adquerycross.m_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    hidict_config_adinfo_adquerycross.m_clazz = "AdQueryCrossAppInfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adquerycross);  

    //adquerystats
    hidict::DictConfig hidict_config_adinfo_adquerystats{};
    hidict_config_adinfo_adquerystats.m_name = "/data/goo/ad/ad_phx_predictor_dict/adquerystat";
    hidict_config_adinfo_adquerystats.m_path = "/data/goo/ad/ad_phx_predictor_dict/adquerystat";
    hidict_config_adinfo_adquerystats.m_clazz = "AdQueryStatsInfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adquerystats);  

    //adstats
    hidict::DictConfig hidict_config_adinfo_adstats{};
    hidict_config_adinfo_adstats.m_name = "/data/goo/ad/ad_phx_predictor_dict/aditemstat";
    hidict_config_adinfo_adstats.m_path = "/data/goo/ad/ad_phx_predictor_dict/aditemstat";
    hidict_config_adinfo_adstats.m_clazz = "AdStatDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adstats);  

    //adunit
    hidict::DictConfig hidict_config_adinfo_adunit{};
    hidict_config_adinfo_adunit.m_name = "/data/goo/ad/ad_phx_predictor_dict/adunitinfo";
    hidict_config_adinfo_adunit.m_path = "/data/goo/ad/ad_phx_predictor_dict/adunitinfo";
    hidict_config_adinfo_adunit.m_clazz = "AdunitDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adunit);  

    //appinfo
    hidict::DictConfig hidict_config_adinfo_appinfo{};
    hidict_config_adinfo_appinfo.m_name = "/data/goo/ad/ad_phx_predictor_dict/appinfo";
    hidict_config_adinfo_appinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/appinfo";
    hidict_config_adinfo_appinfo.m_clazz = "AppinfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_appinfo); 

    //jieba
    hidict::DictConfig hidict_config_adinfo_jieba{};
    hidict_config_adinfo_jieba.m_name = "/data/goo/ad/ad_phx_predictor_dict/jieba";
    hidict_config_adinfo_jieba.m_path = "/data/goo/ad/ad_phx_predictor_dict/jieba";
    hidict_config_adinfo_jieba.m_clazz = "JieBaDict";
    hidict_configs.emplace_back(hidict_config_adinfo_jieba); 

    long handle = reinterpret_cast<long>(&hidict_configs);
    AdDict::AdDictCollectorInstance::instance().init(std::to_string(handle), hidict_configs, false);
  
    //waiting for first time done of loading dict
    while (!AdDict::AdDictCollectorInstance::instance().get_first_load_done()) {
        std::cout << "wating for dict load done" << std::endl;
        sleep(1);
    }
    dict_collect_name = std::to_string(handle);
    std::cout << "all dict load done" << std::endl;

}

void get_data1(AdDict::AdDictCollector* dict_collector) {

  while (1) {
    std::cout<< " adinfo size: "<< dict_collector->get_dict("adinfo")->get_data<adinfo_dict_type>()->size() 
    << "parse failed size: " << dict_collector->get_dict("adinfo")->parse_failed_num
    <<std::endl;

    std::cout<< " adquerycross size: "<< dict_collector->get_dict("adquerycross")->get_data<ad_query_cross_app_dict_type>()->size() 
    << "parse failed size: " << dict_collector->get_dict("adquerycross")->parse_failed_num
    <<std::endl;

    std::cout<< " adstats size: "<< dict_collector->get_dict("adstats")->get_data<adstat_dict_type>()->size() 
    << "parse failed size: " << dict_collector->get_dict("adstats")->parse_failed_num
    <<std::endl;

    std::cout<< " adunit size: "<< dict_collector->get_dict("adunit")->get_data<adunit_dict_type>()->size()
    << "parse failed size: " << dict_collector->get_dict("adunit")->parse_failed_num
     <<std::endl;

    std::cout<< " appinfo size: "<< dict_collector->get_dict("appinfo")->get_data<appinfo_dict_type>()->size() 
    << "parse failed size: " << dict_collector->get_dict("appinfo")->parse_failed_num
    <<std::endl;

    std::cout<< " jieba size: "<< dict_collector->get_dict("jieba")->get_data<cppjieba::MixSegment>()->GetDictTrie()->WordWeightMax 
    << "parse failed size: " << dict_collector->get_dict("jieba")->parse_failed_num
    <<std::endl;

    sleep(10);
  }

  
}

void test_online() {
  std::string dict_collect_name = "";
  init_online_dict(dict_collect_name);

  std::cout<< "dict_collect_name: " << dict_collect_name <<std::endl;

  std::vector<hidict::DictConfig> hidict_configs;
    //adinfo
    hidict::DictConfig hidict_config_adinfo{};
    hidict_config_adinfo.m_name = "adinfo";
    hidict_config_adinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/adinfo";
    // hidict_config_adinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    hidict_config_adinfo.m_clazz = "AdinfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo);  

    //adquerycross
    hidict::DictConfig hidict_config_adinfo_adquerycross{};
    hidict_config_adinfo_adquerycross.m_name = "adquerycross";
    hidict_config_adinfo_adquerycross.m_path = "/data/goo/ad/ad_phx_predictor_dict/ad_query_app_cross_stat";
    hidict_config_adinfo_adquerycross.m_clazz = "AdQueryCrossAppInfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adquerycross);  

    //adquerystats
    hidict::DictConfig hidict_config_adinfo_adquerystats{};
    hidict_config_adinfo_adquerystats.m_name = "adquerystats";
    hidict_config_adinfo_adquerystats.m_path = "/data/goo/ad/ad_phx_predictor_dict/adquerystat";
    hidict_config_adinfo_adquerystats.m_clazz = "AdQueryStatsInfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adquerystats);  

    //adstats
    hidict::DictConfig hidict_config_adinfo_adstats{};
    hidict_config_adinfo_adstats.m_name = "adstats";
    hidict_config_adinfo_adstats.m_path = "/data/goo/ad/ad_phx_predictor_dict/aditemstat";
    hidict_config_adinfo_adstats.m_clazz = "AdStatDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adstats);  

    //adunit
    hidict::DictConfig hidict_config_adinfo_adunit{};
    hidict_config_adinfo_adunit.m_name = "adunit";
    hidict_config_adinfo_adunit.m_path = "/data/goo/ad/ad_phx_predictor_dict/adunitinfo";
    hidict_config_adinfo_adunit.m_clazz = "AdunitDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adunit);  

    //appinfo
    hidict::DictConfig hidict_config_adinfo_appinfo{};
    hidict_config_adinfo_appinfo.m_name = "appinfo";
    hidict_config_adinfo_appinfo.m_path = "/data/goo/ad/ad_phx_predictor_dict/appinfo";
    hidict_config_adinfo_appinfo.m_clazz = "AppinfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_appinfo); 

    //jieba
    hidict::DictConfig hidict_config_adinfo_jieba{};
    hidict_config_adinfo_jieba.m_name = "jieba";
    hidict_config_adinfo_jieba.m_path = "/data/goo/ad/ad_phx_predictor_dict/jieba";
    hidict_config_adinfo_jieba.m_clazz = "JieBaDict";
    hidict_configs.emplace_back(hidict_config_adinfo_jieba); 

    AdDict::AdDictCollector* dict_collector = new AdDict::AdDictCollector();
    dict_collector->init(dict_collect_name, hidict_configs,false);
  
    get_data1(dict_collector);

}

void init_online_query_stat() {


    auto register_dict_callback_factory = [](const std::string& dict_clazz_name)->hidict::DictCallback* {
             if (dict_clazz_name == "AdinfoDict") {
                    return new AdDictCallback<AdDict::AdinfoDict>();
                } else if (dict_clazz_name == "AdQueryCrossAppInfoDict") {
                    return new AdDictCallback<AdDict::AdQueryCrossAppInfoDict>();
                } else if (dict_clazz_name == "AdQueryStatsInfoDict") {
                    return new AdDictCallback<AdDict::AdQueryStatsInfoDict>();
                } else if (dict_clazz_name == "AdStatDict") {
                    return new AdDictCallback<AdDict::AdStatDict>();
                } else if (dict_clazz_name == "AdunitDict") {
                    return new AdDictCallback<AdDict::AdunitDict>();
                } else if (dict_clazz_name == "AppinfoDict") {
                    return new AdDictCallback<AdDict::AppinfoDict>();
                } else if (dict_clazz_name == "PackageName2AppIdInfoDict") {
                    return new AdDictCallback<AdDict::PackageName2AppIdInfoDict>();
                } else if (dict_clazz_name == "JieBaDict") {
                    return new AdDictCallback<AdDict::JieBaDict>();
                } 
                return nullptr;
        };
    std::vector<hidict::DictConfig> hidict_configs;
   
    //adquerystats
    hidict::DictConfig hidict_config_adinfo_adquerystats{};
    hidict_config_adinfo_adquerystats.m_name = "/ad/ad_phx_predictor_dict/adquerystat/";
    hidict_config_adinfo_adquerystats.m_path = "/ad/ad_phx_predictor_dict/adquerystat/";
    hidict_config_adinfo_adquerystats.m_clazz = "AdQueryStatsInfoDict";
    hidict_configs.emplace_back(hidict_config_adinfo_adquerystats);  

    long handle = reinterpret_cast<long>(&hidict_configs);
    
    AdDict::AdDictCollectorInstance::instance().init(std::to_string(handle), hidict_configs, false,register_dict_callback_factory);
  
    
   
    //waiting for first time done of loading dict
    while (!AdDict::AdDictCollectorInstance::instance().get_first_load_done()) {
        std::cout << "wating for dict load done" << std::endl;
        sleep(1);
    }
    std::string dict_collect_name = std::to_string(handle);
    std::cout << "all dict load done" << std::endl;

    AdDict::AdDictCollector* dict_collector = new AdDict::AdDictCollector();
    dict_collector->init(std::to_string(handle), hidict_configs, false);
    sleep(5);
    while(1) {
        auto dict_info = dict_collector->get_data<adquerystatinfo_dict_type>("/ad/ad_phx_predictor_dict/adquerystat/");
        if(dict_info == nullptr) {
            std::cout<< "empty data: " << std::endl;
            break;
        }
        for(auto dict_infos : *dict_info) {
            std::cout<< "key: " <<dict_infos.first << std::endl;
            std::cout<< "value: " << dict_infos.second->DebugString() << std::endl;

        }
        std::string sss = "q音乐\u0001a5386317";
        auto ss = dict_collector->get_adquerystats_info("/ad/ad_phx_predictor_dict/adquerystat/", sss);
        if(ss != nullptr) {
            std::cout<< "data size: "<< ss->DebugString() << std::endl;
        } else {
            std::cout<< "q音乐 empty: " << std::endl;
        }
        
        std::cout<< "version: " << dict_collector->get_dict("/ad/ad_phx_predictor_dict/adquerystat/")->m_task_info.version<<std::endl;
        sleep(3);
    }

}

int main(int argc,char* argv[]) {
  init_online_query_stat();


}