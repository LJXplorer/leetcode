#ifndef _AD_STAT_DICT_H_
#define _AD_STAT_DICT_H_
#include "common/hidict/dict_manager.h"
#include "dict/item_stats_dict.pb.h"
#include "phx-fe/ad_dict/ad_dict_template.h"
#include "phx-fe/decode/base64.h"
namespace AdDict {
    using adstat_dict_type = AdDictTemplate<std::string, phx::ItemStatsDict>::ContainerType;
    class AdStatDict : public AdDictTemplate<std::string, phx::ItemStatsDict> {};
    DICT_REGISTER(AdStatDict);
}// namespace AdDict

#endif