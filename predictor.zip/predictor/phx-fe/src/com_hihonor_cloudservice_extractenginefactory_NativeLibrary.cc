#include "com_hihonor_cloudservice_extractenginefactory_NativeLibrary.h"
#include "phx-fe/config_mgr/xml_config_mgr.h"
#include "service.h"
#include "phx-fe/util/timer.h"
#include "phx-fe/util/util.h"
#include <exception>

void throw_jni_exception(JNIEnv *env, const char *str) {
    jclass run_ex_cls = env->FindClass("java/lang/RuntimeException");

    if (run_ex_cls) {
        env->ThrowNew(run_ex_cls, str);
    }
}

JNIEXPORT jlong JNICALL
Java_com_hihonor_cloudservice_extractenginefactory_NativeLibrary_initXmlOfflineCryptByContentWithVersionNewSample(
        JNIEnv *env, jobject obj, jstring content, jstring version_name, jlong dicts_handle) {
    const char *c_content = env->GetStringUTFChars(content, 0);

    ConfigInfo *handle = nullptr;

    std::string c_version_name;
    if (version_name != nullptr) {
        const char *temp_version_name = env->GetStringUTFChars(version_name, 0);
        c_version_name = temp_version_name;
        env->ReleaseStringUTFChars(version_name, temp_version_name);
    }

    try {
        handle = init_xml_offline_crypt_by_content_new_sample(c_content, dicts_handle,
                                                              c_version_name.c_str());
    } catch (const std::exception &e) {
        env->ReleaseStringUTFChars(content, c_content);
        throw_jni_exception(env, e.what());
        return 0;
    } catch (...) {
        env->ReleaseStringUTFChars(content, c_content);
        throw_jni_exception(env, "unkown exception");
        return 0;
    }

    env->ReleaseStringUTFChars(content, c_content);
    return reinterpret_cast<long>(handle);
}

JNIEXPORT jboolean JNICALL Java_com_hihonor_cloudservice_extractenginefactory_NativeLibrary_releaseConfigHandle(
        JNIEnv *env, jobject obj, jlong handle) {
    return release_config(handle);
}

/*
 * Class:     com_hihonor_ai_utils_FeatureExtract
 * Method:    initOfflineDicts
 * Signature: (Ljava/lang/String;)J
 */
JNIEXPORT jlong JNICALL Java_com_hihonor_cloudservice_extractenginefactory_NativeLibrary_initOfflineDicts(
        JNIEnv *env, jobject obj, jstring dict_infos) {
    const char *c_dict_info = env->GetStringUTFChars(dict_infos, 0);
    try {
        return init_offline_dicts(c_dict_info);
    } catch (const std::exception &e) {
        env->ReleaseStringUTFChars(dict_infos, c_dict_info);
        throw_jni_exception(env, e.what());
        return 0;
    } catch (...) {
        env->ReleaseStringUTFChars(dict_infos, c_dict_info);
        throw_jni_exception(env, "unkown exception");
        return 0;
    }
    return 0;
}

/*
 * Class:     com_hihonor_ai_utils_FeatureExtract
 * Method:    getDictInfosByCryptContent
 * Signature: (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_com_hihonor_cloudservice_extractenginefactory_NativeLibrary_getDictInfosByCryptContent(
        JNIEnv *env, jobject obj, jstring fe_config_content, jstring version_name) {
    const char *c_content = env->GetStringUTFChars(fe_config_content, 0);
    const char *c_version_name = env->GetStringUTFChars(version_name, 0);
    std::string configs_json_str{};
    try {
        configs_json_str = get_dict_configs_from_string(c_content, c_version_name);
    } catch (const std::exception &e) {
        env->ReleaseStringUTFChars(fe_config_content, c_content);
        env->ReleaseStringUTFChars(version_name, c_version_name);
        throw_jni_exception(env, e.what());
        return nullptr;
    } catch (...) {
        env->ReleaseStringUTFChars(fe_config_content, c_content);
        env->ReleaseStringUTFChars(version_name, c_version_name);
        throw_jni_exception(env, "unkown exception");
        return nullptr;
    }
    jstring configs_json_str_j = env->NewStringUTF(configs_json_str.c_str());
    return configs_json_str_j;
}

/*
 * Class:     com_hihonor_ai_utils_FeatureExtract
 * Method:    toBatchTrainingSampleV2
 * Signature: ([BJ)[B
 */
JNIEXPORT jbyteArray JNICALL Java_com_hihonor_cloudservice_extractenginefactory_NativeLibrary_toBatchTrainingSampleV2(
        JNIEnv *env, jobject obj, jbyteArray fe_array, jbyteArray user_action_array, jlong config_handle) {
    jbyte *data = env->GetByteArrayElements(fe_array, nullptr);
    const int data_size = env->GetArrayLength(fe_array);
    jbyte *user_action_data = env->GetByteArrayElements(user_action_array, nullptr);
    const int user_action_data_size = env->GetArrayLength(user_action_array);

    std::string batch_training_samples_str;

    try {
        batch_training_samples_str = to_training_sample_v2(
                (const char *) data, data_size, (const char *) user_action_data, user_action_data_size, config_handle);
    } catch (const std::exception &e) {
        env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
        env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);
        throw_jni_exception(env, e.what());
        return nullptr;
    } catch (...) {
        env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
        env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);
        throw_jni_exception(env, "unkown exception");
        return nullptr;
    }

    env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
    env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);

    const int size = batch_training_samples_str.size();
    jbyteArray ret = env->NewByteArray(size);
    env->SetByteArrayRegion(ret, 0, size, (jbyte *) batch_training_samples_str.data());
    return ret;
}

/*
 * Class:     com_hihonor_cloudservice_extractenginefactory_NativeLibrary
 * Method:    toLTRTrainingSampleV2
 * Signature: ([B[BJ)[B
 */
JNIEXPORT jbyteArray JNICALL Java_com_hihonor_cloudservice_extractenginefactory_NativeLibrary_toLTRTrainingSampleV2(
        JNIEnv *env, jobject obj, jbyteArray fe_array, jbyteArray user_action_array, jlong config_handle) {
    jbyte *data = env->GetByteArrayElements(fe_array, nullptr);
    const int data_size = env->GetArrayLength(fe_array);
    jbyte *user_action_data = env->GetByteArrayElements(user_action_array, nullptr);
    const int user_action_data_size = env->GetArrayLength(user_action_array);

    std::string ltr_training_samples_str;

    try {
        ltr_training_samples_str = to_ltr_training_sample_v2(
                (const char *) data, data_size, (const char *) user_action_data, user_action_data_size, config_handle);
    } catch (const std::exception &e) {
        env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
        env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);
        throw_jni_exception(env, e.what());
        return nullptr;
    } catch (...) {
        env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
        env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);
        throw_jni_exception(env, "unkown exception");
        return nullptr;
    }

    env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
    env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);

    const int size = ltr_training_samples_str.size();
    jbyteArray ret = env->NewByteArray(size);
    env->SetByteArrayRegion(ret, 0, size, (jbyte *) ltr_training_samples_str.data());
    return ret;
}

/*
 * Class:     com_hihonor_cloudservice_extractenginefactory_NativeLibrary
 * Method:    toExtractorResponse
 * Signature: ([B[BJ)[B
 */
JNIEXPORT jbyteArray JNICALL Java_com_hihonor_cloudservice_extractenginefactory_NativeLibrary_toExtractorResponse(
        JNIEnv *env, jobject obj, jbyteArray fe_array, jbyteArray user_action_array, jlong config_handle) {
    jbyte *data = env->GetByteArrayElements(fe_array, nullptr);
    const int data_size = env->GetArrayLength(fe_array);
    jbyte *user_action_data = env->GetByteArrayElements(user_action_array, nullptr);
    const int user_action_data_size = env->GetArrayLength(user_action_array);

    std::string extractor_response_str;

    try {
        extractor_response_str = to_extractor_response(
                (const char *) data, data_size, (const char *) user_action_data, user_action_data_size, config_handle);
    } catch (const std::exception &e) {
        env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
        env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);
        throw_jni_exception(env, e.what());
        return nullptr;
    } catch (...) {
        env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
        env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);
        throw_jni_exception(env, "unkown exception");
        return nullptr;
    }

    env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
    env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);

    const int size = extractor_response_str.size();
    jbyteArray ret = env->NewByteArray(size);
    env->SetByteArrayRegion(ret, 0, size, (jbyte *) extractor_response_str.data());
    return ret;
}

/*
 * Class:     com_hihonor_cloudservice_extractenginefactory_NativeLibrary
 * Method:    toExtractorResponseLTR
 * Signature: ([B[BJ)[B
 */
JNIEXPORT jbyteArray JNICALL Java_com_hihonor_cloudservice_extractenginefactory_NativeLibrary_toExtractorResponseLTR(
        JNIEnv *env, jobject obj, jbyteArray fe_array, jbyteArray user_action_array, jlong config_handle) {
    jbyte *data = env->GetByteArrayElements(fe_array, nullptr);
    const int data_size = env->GetArrayLength(fe_array);
    jbyte *user_action_data = env->GetByteArrayElements(user_action_array, nullptr);
    const int user_action_data_size = env->GetArrayLength(user_action_array);

    std::string extractor_response_str;

    try {
        extractor_response_str = to_extractor_response_ltr(
                (const char *) data, data_size, (const char *) user_action_data, user_action_data_size, config_handle);
    } catch (const std::exception &e) {
        env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
        env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);
        throw_jni_exception(env, e.what());
        return nullptr;
    } catch (...) {
        env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
        env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);
        throw_jni_exception(env, "unkown exception");
        return nullptr;
    }

    env->ReleaseByteArrayElements(fe_array, data, JNI_ABORT);
    env->ReleaseByteArrayElements(user_action_array, user_action_data, JNI_ABORT);

    const int size = extractor_response_str.size();
    jbyteArray ret = env->NewByteArray(size);
    env->SetByteArrayRegion(ret, 0, size, (jbyte *) extractor_response_str.data());
    return ret;
}