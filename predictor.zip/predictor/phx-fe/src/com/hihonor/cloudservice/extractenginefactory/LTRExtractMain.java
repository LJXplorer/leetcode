package com.hihonor.cloudservice.extractenginefactory;

import com.hihonor.cloudservice.extractenginefactory.NativeLibrary;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;

class MyThread extends Thread {
    private byte[] fileContent;
    private byte[] actionfileContent;
    private int thdReqCnt = 0;
    private long handle = 0;
    private long dict_handle = 0;
    private NativeLibrary extractor;

    public MyThread(String fe_config_path, String dict_path, String version_name, String request_path, String user_action_path, int thd_req_cnt) {
        super(); // 调用Thread的无参构造函数

        thdReqCnt = thd_req_cnt;
        
        File file = new File(request_path);
        fileContent = new byte[(int) file.length()];

        try (FileInputStream fileInputStream = new FileInputStream(file)) {
            // 读取文件内容到byte数组中
            int bytesRead = fileInputStream.read(fileContent);
            
            if (bytesRead != file.length()) {
                System.out.println("文件未完全读取");
            } else {
                System.out.println("文件读取成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        File action_file = new File(user_action_path);
        actionfileContent = new byte[(int) action_file.length()];

        try (FileInputStream fileInputStream = new FileInputStream(action_file)) {
            // 读取文件内容到byte数组中
            int bytesRead = fileInputStream.read(actionfileContent);
            
            if (bytesRead != action_file.length()) {
                System.out.println("文件未完全读取");
            } else {
                System.out.println("文件读取成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        String dictfileContent = "";
        try {
            dictfileContent = new String(Files.readAllBytes(Paths.get(dict_path)), StandardCharsets.UTF_8);
            System.out.println("文件读取成功");
        } catch (IOException e) {
            e.printStackTrace();
        }

        String configContent = "";
        try {
            configContent = new String(Files.readAllBytes(Paths.get(fe_config_path)), StandardCharsets.UTF_8);
            System.out.println("文件读取成功");
        } catch (IOException e) {
            e.printStackTrace();
        }

        extractor = new NativeLibrary();

        try {
            dict_handle = extractor.initOfflineDicts(dictfileContent);
            handle = extractor.initXmlOfflineCryptByContentWithVersionNewSample(configContent, version_name, dict_handle);
        } catch (Exception e) {
            // 处理所有的异常,打印异常堆栈信息
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            Instant start = Instant.now();
            for (int i = 0; i < thdReqCnt; i++) {
                byte[] binaryData = extractor.toLTRTrainingSampleV2(fileContent, actionfileContent, handle);
                try (FileOutputStream fos = new FileOutputStream("./data.txt")) {
                    fos.write(binaryData);
                    fos.flush();
                    System.out.println("写入成功: ./data.txt");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            Instant end = Instant.now();
            Duration timeElapsed = Duration.between(start, end);
            System.out.println(thdReqCnt + "次 总耗时（毫秒）：" + timeElapsed.toMillis());
        } catch (Exception e) {
            // 处理所有的异常,打印异常堆栈信息
            e.printStackTrace();
        }
    }
}

public class LTRExtractMain {
    public static void main(String[] args) {
        if (args.length < 7) {
            System.out.println(args.length);
            System.out.println("Uage:./main fe_config dict_path version_name fe_request user_action thd_cnt thd_req_cnt");
            return;
        }

        String fe_config_path = args[0];
        String dict_path = args[1];
        String version_name = args[2];
        String fe_request = args[3];
        String user_action = args[4];
        int thd_cnt = 0;
        int thd_req_cnt = 0;

        try {
            thd_cnt = Integer.parseInt(args[5]);
            thd_req_cnt = Integer.parseInt(args[6]);
        } catch (NumberFormatException e) {
            System.out.println("字符串不是有效的整数格式");
        }

        /*
            cp ../bazel-bin/src/libfe.so /usr/lib 或者 spark resource目录
            javac FeatureExtract.java FeatureExtractMain.java
            java FeatureExtractMain
        */
        System.out.println(System.getProperty("java.library.path"));

        MyThread[] threads = new MyThread[thd_cnt];
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new MyThread(fe_config_path, dict_path, version_name, fe_request, user_action, thd_req_cnt);
        }

        for (int i = 0; i < threads.length; i++) {
            threads[i].start();
        }

        for (Thread thread : threads) {
            try {
                thread.join(); // 等待当前线程完成
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); // 重新设置中断状态
                System.out.println("主线程被中断。");
            }
        }

        System.out.println("所有线程执行完毕，主线程结束。");
    }
}