package com.hihonor.cloudservice.extractenginefactory;

import com.hihonor.cloudservice.extractenginefactory.NativeLibrary;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import java.time.Duration;
import java.time.Instant;

public class FeatureExtractMain {
    /**
     * 读取指定路径的文件内容，返回字符串
     * 
     * @param filePath 文件路径
     * @return 文件内容字符串，如果读取失败返回null
     */
    public static String readFileToString(String filePath) {
        try {
            return new String(Files.readAllBytes(Paths.get(filePath)));
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        NativeLibrary extractor = new NativeLibrary();
        System.out.println(extractor.getDictInfosByCryptContent( readFileToString("/home/tongzong/PHX-featureextractor/fe_config_encode.xml") , "union_ctr"));
    }
}