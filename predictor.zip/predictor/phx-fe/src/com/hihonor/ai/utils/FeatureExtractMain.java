package com.hihonor.ai.utils;
import com.hihonor.ai.utils.FeatureExtract;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.time.Duration;
import java.time.Instant;

class MyThread extends Thread {
    private byte[] fileContent;
    private int thdReqCnt = 0;
    private long handle = 0;
    private long model_input_handle = 0;
    private FeatureExtract extractor;

    public MyThread(String fe_config_path, String model_input_path, String request_path, int thd_req_cnt) {
        super(); // 调用Thread的无参构造函数

        thdReqCnt = thd_req_cnt;
        
        File file = new File(request_path);
        fileContent = new byte[(int) file.length()];
            
        try (FileInputStream fileInputStream = new FileInputStream(file)) {
            // 读取文件内容到byte数组中
            int bytesRead = fileInputStream.read(fileContent);
            
            if (bytesRead != file.length()) {
                System.out.println("文件未完全读取");
            } else {
                System.out.println("文件读取成功");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        extractor = new FeatureExtract();

        try {
            model_input_handle = extractor.initOnlineModelInputV2(model_input_path);
            handle = extractor.initOnlineV2(model_input_handle, fe_config_path);
        } catch (Exception e) {
            // 处理所有的异常,打印异常堆栈信息
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            Instant start = Instant.now();
            for (int i = 0; i < thdReqCnt; i++) {
                extractor.toPredictRequestV2(handle, model_input_handle, fileContent);
            }
            Instant end = Instant.now();
            Duration timeElapsed = Duration.between(start, end);
            System.out.println(thdReqCnt + "次 总耗时（毫秒）：" + timeElapsed.toMillis());
        } catch (Exception e) {
            // 处理所有的异常,打印异常堆栈信息
            e.printStackTrace();
        }
    }
}

public class FeatureExtractMain {
    public static void main(String[] args) {
        if (args.length < 5) {
            System.out.println(args.length);
            System.out.println("Uage:./main fe_config model_input fe_request thd_cnt thd_req_cnt");
            return;
        }

        String fe_config_path = args[0];
        String model_input_path = args[1];
        String request_path = args[2];
        int thd_cnt = 0;
        int thd_req_cnt = 0;

        try {
            thd_cnt = Integer.parseInt(args[3]);
            thd_req_cnt = Integer.parseInt(args[4]);
        } catch (NumberFormatException e) {
            System.out.println("字符串不是有效的整数格式");
        }

        /*
            cp ../bazel-bin/src/libfe.so /usr/lib 或者 spark resource目录
            javac FeatureExtract.java FeatureExtractMain.java
            java FeatureExtractMain
        */
        System.out.println(System.getProperty("java.library.path"));

        /*
        // V1
        try {
            FeatureExtract extractor = new FeatureExtract();
        
            byte[] inputData = {1, 2, 3};
            byte[] result = extractor.toBatchSequenceExample(inputData);
        } catch (Exception e) {
            // 处理所有的异常,打印异常堆栈信息
            e.printStackTrace();
        }

        // V2
        // 离线
        long handle = 0;
        try {
            FeatureExtract extractor = new FeatureExtract();
        
            handle = extractor.initOfflineV2();
            extractor.toBatchSequenceExampleV2(handle, );
        } catch (Exception e) {
            // 处理所有的异常,打印异常堆栈信息
            e.printStackTrace();
        } finally {
            // 等不再使用这套配置文件的时候 再释放，不用重复init
            extractor.freeHandleV2(handle);
        }
        */

       

        // 在线
        MyThread[] threads = new MyThread[thd_cnt];
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new MyThread(fe_config_path, model_input_path, request_path, thd_req_cnt);
        }

        for (int i = 0; i < threads.length; i++) {
            threads[i].start();
        }

        for (Thread thread : threads) {
            try {
                thread.join(); // 等待当前线程完成
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); // 重新设置中断状态
                System.out.println("主线程被中断。");
            }
        }

        System.out.println("所有线程执行完毕，主线程结束。");
    }
}