package com.hihonor.cloudservice.extractenginefactory;

class NativeLibrary {
    static {
        // 加载.so库,库名为libfe.so
        //System.loadLibrary("fe");
        System.load("/usr/lib/libfe.so");
    }

    // 通过加密的配置文件内容 初始化离线服务 xml版本 根据version筛选抽取特征
    public native long initXmlOfflineCryptByContentWithVersionNewSample(String fe_config_content, String version_name, long dicts_handle);
    // 通过加密的xml配置文件内容 获取文件路径list
    public native boolean releaseConfigHandle(long handle);
    
    public native String getDictInfosByCryptContent(String fe_config_content, String version_name);

    public native long initOfflineDicts(String dict_infos);

    public native byte[] toBatchTrainingSampleV2(byte[] fe, byte[] user_action, long handle);

    public native byte[] toLTRTrainingSampleV2(byte[] fe, byte[] user_action, long handle);

    public native byte[] toExtractorResponse(byte[] fe, byte[] user_action, long handle);

    public native byte[] toExtractorResponseLTR(byte[] fe, byte[] user_action, long handle);
}
