package com.hihonor.ai.utils;
import com.hihonor.ai.utils.FeatureExtract;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.time.Duration;
import java.time.Instant;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Comparator;

class MyThread extends Thread {
    private long handle = 0;
    private long model_input_handle = 0;
    private FeatureExtract extractor;
    private int req_times = 0;
    private List<String> file_list = new ArrayList<>();
    private List<String> dir_list = new ArrayList<>();
    private List<byte[]> file_contents = new ArrayList<>();
    private PointTimer timer;

    public MyThread(String fe_config_path, String model_input_path, String request_path_dir, int thd_req_cnt) {
        super(); // 调用Thread的无参构造函数

        req_times = thd_req_cnt;

        getSubPath(request_path_dir, file_list, dir_list);
        
        for (String file_path : file_list) {
            File file = new File(file_path);
            byte[] fileContent = new byte[(int) file.length()];

            try (FileInputStream fileInputStream = new FileInputStream(file)) {
                // 读取文件内容到byte数组中
                int bytesRead = fileInputStream.read(fileContent);

                if (bytesRead != file.length()) {
                    System.out.println("文件未完全读取: " + file_path);
                } else {
                    file_contents.add(fileContent);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        extractor = new FeatureExtract();

        try {
            model_input_handle = extractor.initOnlineModelInputV2(model_input_path);
            handle = extractor.initOnlineV2(model_input_handle, fe_config_path);
        } catch (Exception e) {
            // 处理所有的异常,打印异常堆栈信息
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            timer = new PointTimer("online");
            for (int i = 0; i < file_contents.size(); i++) {
                byte[] fileContent = file_contents.get(i);

                for (int j = 0; j < req_times; j++) {
                    extractor.toPredictRequestV2(handle, model_input_handle, fileContent);
                }
                timer.point("len" + fileContent.length, 1.0f / req_times);
            }
            timer.display();
        } catch (Exception e) {
            // 处理所有的异常,打印异常堆栈信息
            e.printStackTrace();
        }
    }

    private void getSubPath(String path, List<String> file_list, List<String> dir_list) {
        File dir = new File(path);
        if (!dir.exists() || !dir.isDirectory()) {
            return;
        }

        File[] entries = dir.listFiles();
        if (entries == null) {
            return;
        }

        for (File entry : entries) {
            String entryName = entry.getName();

            if (".".equals(entryName) || "..".equals(entryName)) {
                continue;
            }

            String fullPath = entry.getAbsolutePath();

            if (entry.isDirectory()) {
                dir_list.add(fullPath);
            } else {
                file_list.add(fullPath);
            }
        }

        Collections.sort(file_list);
        Collections.sort(dir_list);
    }

    private class PointTimer {
        private long begin_;
        private long end_;
        private String prefix_;
        private List<Pair<Long, String>> vec_;
        private long count_;
        private long sum_;

        public PointTimer() {
            this("");
        }

        public PointTimer(String prefix) {
            this.prefix_ = prefix;
            this.count_ = 0;
            this.sum_ = 0;
            this.vec_ = new ArrayList<>();
            this.begin_ = System.nanoTime();
            this.prefix_ += ":";
        }

        public void point(String str, float rate) {
            this.end_ = System.nanoTime();
            long cost = (long)(rate * (float)(this.end_ - this.begin_));

            this.vec_.add(new Pair<>(cost, str));
            this.count_++;
            this.sum_ += cost;

            this.begin_ = this.end_;
        }

        public void display() {
            if (this.vec_.size() < 1) {
                return;
            }

            Collections.sort(this.vec_, Comparator.comparingLong(Pair::getFirst));

            StringBuilder sb = new StringBuilder(this.prefix_);
            for (Pair<Long, String> pair : this.vec_) {
                sb.append(pair.getSecond());
                sb.append(" ");
                sb.append(pair.getFirst());
                sb.append("ns,");
            }

            System.out.println(String.format("%s count:%d sum:%.3fms min:%.3fms max:%.3fms p50:%.3fms p90:%.3fms p99:%.3fms",
                sb.toString(), this.count_, this.sum_ / 1000000.0,
                this.vec_.get(0).getFirst() / 1000000.0,
                this.vec_.get(this.vec_.size() - 1).getFirst() / 1000000.0,
                this.vec_.get(this.vec_.size() / 2).getFirst() / 1000000.0,
                this.vec_.get(this.vec_.size() * 90 / 100).getFirst() / 1000000.0,
                this.vec_.get(this.vec_.size() * 99 / 100).getFirst() / 1000000.0));
        }

        private class Pair<K, V> {
            private K first;
            private V second;

            public Pair(K first, V second) {
                this.first = first;
                this.second = second;
            }

            public K getFirst() {
                return first;
            }

            public V getSecond() {
                return second;
            }
        }
    }
}

public class FeatureExtractMainDir {
    public static void main(String[] args) {
        if (args.length < 5) {
            System.out.println(args.length);
            System.out.println("Uage:./main fe_config model_input fe_request_dir thd_cnt thd_req_cnt");
            return;
        }

        String fe_config_path = args[0];
        String model_input_path = args[1];
        String request_path_dir = args[2];
        int thd_cnt = 0;
        int thd_req_cnt = 0;

        try {
            thd_cnt = Integer.parseInt(args[3]);
            thd_req_cnt = Integer.parseInt(args[4]);
        } catch (NumberFormatException e) {
            System.out.println("Invalid thd_cnt: " + args[3]);
            return;
        }

        /*
            cp ../bazel-bin/src/libfe.so /usr/lib 或者 spark resource目录
            javac FeatureExtract.java FeatureExtractMain.java
            java FeatureExtractMain
        */
        System.out.println(System.getProperty("java.library.path"));

        /*
        // V1
        try {
            FeatureExtract extractor = new FeatureExtract();
        
            byte[] inputData = {1, 2, 3};
            byte[] result = extractor.toBatchSequenceExample(inputData);
        } catch (Exception e) {
            // 处理所有的异常,打印异常堆栈信息
            e.printStackTrace();
        }

        // V2
        // 离线
        long handle = 0;
        try {
            FeatureExtract extractor = new FeatureExtract();
        
            handle = extractor.initOfflineV2();
            extractor.toBatchSequenceExampleV2(handle, );
        } catch (Exception e) {
            // 处理所有的异常,打印异常堆栈信息
            e.printStackTrace();
        } finally {
            // 等不再使用这套配置文件的时候 再释放，不用重复init
            extractor.freeHandleV2(handle);
        }
        */

        // 在线
        MyThread[] threads = new MyThread[thd_cnt];
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new MyThread(fe_config_path, model_input_path, request_path_dir, thd_req_cnt);
        }

        for (int i = 0; i < threads.length; i++) {
            threads[i].start();
        }

        for (Thread thread : threads) {
            try {
                thread.join(); // 等待当前线程完成
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt(); // 重新设置中断状态
                System.out.println("主线程被中断。");
            }
        }

        System.out.println("所有线程执行完毕，主线程结束。");
    }
}