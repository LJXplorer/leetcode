javac -encoding utf8 -h . FeatureExtract.java
