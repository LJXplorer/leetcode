#ifndef FE_SERVISE
#define FE_SERVISE

#include "phx-fe/ad_dict/ad_dict_manager.h"
#include "framework.h"
#include "phx-fe/util/util.h"

#include <memory>
#include <string>
#include <vector>

// 新样本格式离线抽取接口
std::string to_training_sample_v2(const char *request_ptr, const int32_t request_size, const char *user_action_c_array,
                                  const int32_t user_action_c_array_length, long handle);
std::string to_ltr_training_sample_v2(const char *request_ptr, const int32_t request_size,
                                      const char *user_action_c_array, const int32_t user_action_c_array_length,
                                      long handle);
std::string to_extractor_response(const char* request_ptr, const int32_t request_size, const char* user_action_c_array, const int32_t user_action_c_array_length, long handle);
std::string to_extractor_response_ltr(const char* request_ptr, const int32_t request_size, const char* user_action_c_array, const int32_t user_action_c_array_length, long handle);
// 新词典格式初始化接口
std::string get_dict_configs_from_string(const char *config_content, const char *version_name);
long init_offline_dicts(const std::string &dict_configs_json_str);
ConfigInfo *init_xml_offline_by_content_new_sample(const char *config_content, long dicts_handle,
                                                   const char *version_name);
ConfigInfo* init_xml_offline_crypt_by_content_new_sample(const char* config_content, long dicts_handle, const char* version_name);
std::shared_ptr<ConfigInfo> init_xml_online_by_decypt_content_new_sample(const std::string &config_content_decrypt,const std::string &model_input_config, AdDict::AdDictCollector* dict_collector);
bool release_config(long handle);

#endif// FE_SERVISE