#include "service.h"
#include "common/hidict/dict_manager.h"
#include "phx-fe/config_mgr/xml_config_mgr.h"
#include "phx-fe/src/framework.h"
#include "phx-fe/src/session.h"
#include "phx-fe/util/item_class.h"
#include "phx-fe/util/log.h"
#include "phx-fe/util/timer.h"
#include "phx-fe/util/md5.h"
#include "phx-fe/decode/decode.h"
#include "phx-fe/util/util.h"
#include <json.hpp>
#include <memory>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <yaml-cpp/exceptions.h>
#include "yaml-cpp/yaml.h"
#include "user_action.pb.h"

#if __cplusplus >= 201703L
#include <shared_mutex>
#else
#include <mutex>
#endif

// 离线时会加载多个config,使用config map管理
std::unordered_map<ConfigInfo*, std::shared_ptr<ConfigInfo>> g_offline_config_info_map;

#if __cplusplus >= 201703L
static std::shared_timed_mutex rw_mutex_;
#else
static std::mutex mutex_;
#endif


std::string get_dict_configs_from_string(const char* config_content, const char* version_name) {
  auto dict_configs = XmlConfigMgr::get_dict_configs_from_string(Decode::decode_string(config_content), version_name);
  nlohmann::json json_array{};
  for(const auto& conf : dict_configs) {
    nlohmann::json object{};
    object["name"] = conf.name;
    object["path"] = conf.path;
    object["partition"] = conf.partition;
    object["value_proto"] = conf.value_proto;
    object["class_name"] = conf.class_name;
    json_array.emplace_back(object);
  }
  return json_array.dump();
}



ConfigInfo* insert_config(const ConfigInfo& fe_configs) {
  auto config_ptr = std::make_shared<ConfigInfo>(fe_configs);
  #if __cplusplus >= 201703L
  std::unique_lock<std::shared_timed_mutex> write_lock(rw_mutex_);
  #else
  std::unique_lock<std::mutex> lck(mutex_);
  #endif
  g_offline_config_info_map[config_ptr.get()] = config_ptr;
  return config_ptr.get();
}

bool release_config(long handle) {
  auto handle_ptr = reinterpret_cast<ConfigInfo*>(handle);
  #if __cplusplus >= 201703L
  std::unique_lock<std::shared_timed_mutex> write_lock(rw_mutex_);
  #else
  std::unique_lock<std::mutex> lck(mutex_);
  #endif
  return g_offline_config_info_map.erase(handle_ptr) > 0;
}

std::shared_ptr<ConfigInfo> get_config(long config_handle) {
  auto handle_ptr = reinterpret_cast<ConfigInfo*>(config_handle);
  #if __cplusplus >= 201703L
  std::unique_lock<std::shared_timed_mutex> write_lock(rw_mutex_);
  #else
  std::unique_lock<std::mutex> lck(mutex_);
  #endif
  auto iter = g_offline_config_info_map.find(handle_ptr);
  if (iter != g_offline_config_info_map.end()) {
    return iter->second;
  }
  return nullptr;
}



ConfigInfo* init_xml_offline_by_content_new_sample(const char* config_content, long dicts_handle, const char* version_name) {
  ConfigInfo config_info;
  config_info.md5_ = Md5::encode_string(config_content);

  XmlConfigMgr::parse_from_string(config_content, version_name,config_info, dicts_handle);
  return insert_config(config_info);
}
ConfigInfo* init_xml_offline_crypt_by_content_new_sample(const char* config_content, long dicts_handle, const char* version_name) {
  ConfigInfo config_info;
  config_info.md5_ = Md5::encode_string(config_content);

  XmlConfigMgr::parse_from_string(Decode::decode_string(config_content), version_name,config_info, dicts_handle);
  return insert_config(config_info);
}


std::string to_training_sample_v2(const char* request_ptr, const int32_t request_size, const char* user_action_c_array, const int32_t user_action_c_array_length, long handle) {
  std::string training_sample_str;
  google::protobuf::Arena arena;
  phx::FeRequest* fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
  phx::UserAction* user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
  phx::BatchTrainingSample* batch_training_sample = google::protobuf::Arena::CreateMessage<phx::BatchTrainingSample>(&arena);
  if (!fe_request->ParseFromArray(request_ptr, request_size)) {
    THROW_ERROR("fe request pb parse error!");
    return training_sample_str;
  }
  if (!user_action->ParseFromArray(user_action_c_array, user_action_c_array_length)) {
    THROW_ERROR("user action pb parse error!");
    return training_sample_str;
  }
  auto config = get_config(handle);
  if (config == nullptr) {
    THROW_ERROR("config handle not found! handle = " + std::to_string(handle));
    return training_sample_str;
  }

  toTraningSampleV2(&arena, *fe_request, *user_action, *config, *batch_training_sample);

  batch_training_sample->SerializeToString(&training_sample_str);
  return training_sample_str;
}

std::string to_ltr_training_sample_v2(const char* request_ptr, const int32_t request_size, const char* user_action_c_array, const int32_t user_action_c_array_length, long handle) {
  std::string ltr_training_sample_str;
  google::protobuf::Arena arena;
  phx::FeRequest* fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
  phx::UserAction* user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
  phx::LTRTrainingSample* ltr_training_sample = google::protobuf::Arena::CreateMessage<phx::LTRTrainingSample>(&arena);
  if (!fe_request->ParseFromArray(request_ptr, request_size)) {
    THROW_ERROR("fe request pb parse error!");
    return ltr_training_sample_str;
  }
  if (!user_action->ParseFromArray(user_action_c_array, user_action_c_array_length)) {
    THROW_ERROR("user action pb parse error!");
    return ltr_training_sample_str;
  }
  auto config = get_config(handle);
  if (config == nullptr) {
    THROW_ERROR("config handle not found! handle = " + std::to_string(handle));
    return ltr_training_sample_str;
  }

  toLTRTraningSampleV2(&arena, *fe_request, *user_action, *config, *ltr_training_sample);

  ltr_training_sample->SerializeToString(&ltr_training_sample_str);
  return ltr_training_sample_str;
}

std::string to_extractor_response(const char* request_ptr, const int32_t request_size, const char* user_action_c_array, const int32_t user_action_c_array_length, long handle) {
  std::string extractor_response_str;
  google::protobuf::Arena arena;
  phx::FeRequest* fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
  phx::UserAction* user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
  phx::ExtractorResponse* extractor_response = google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(&arena);
  if (!fe_request->ParseFromArray(request_ptr, request_size)) {
    THROW_ERROR("fe request pb parse error!");
    return extractor_response_str;
  }
  if (!user_action->ParseFromArray(user_action_c_array, user_action_c_array_length)) {
    THROW_ERROR("user action pb parse error!");
    return extractor_response_str;
  }
  auto config = get_config(handle);
  if (config == nullptr) {
    THROW_ERROR("config handle not found! handle = " + std::to_string(handle));
    return extractor_response_str;
  }
  phx_fe::Session session;
  phx_fe::Options options;
  options.expected_batch_size = fe_request->item_fea_size();
  options.arena = &arena;
  options.is_ltr = false;
  phx_fe::ToExtractorResponse(*fe_request, *user_action, *config, session, options, extractor_response, nullptr); 

  extractor_response->SerializeToString(&extractor_response_str);
  return extractor_response_str;
}

std::string to_extractor_response_ltr(const char* request_ptr, const int32_t request_size, const char* user_action_c_array, const int32_t user_action_c_array_length, long handle) {
  std::string extractor_response_str;
  google::protobuf::Arena arena;
  phx::FeRequest* fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
  phx::UserAction* user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
  phx::ExtractorResponse* extractor_response = google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(&arena);
  if (!fe_request->ParseFromArray(request_ptr, request_size)) {
    THROW_ERROR("fe request pb parse error!");
    return extractor_response_str;
  }
  if (!user_action->ParseFromArray(user_action_c_array, user_action_c_array_length)) {
    THROW_ERROR("user action pb parse error!");
    return extractor_response_str;
  }
  auto config = get_config(handle);
  if (config == nullptr) {
    THROW_ERROR("config handle not found! handle = " + std::to_string(handle));
    return extractor_response_str;
  }

  phx_fe::Session session;
  session.cache.reserve(config->configs_.size());
  phx_fe::Options options;
  options.expected_batch_size = fe_request->prerank_item_fea_size();
  options.arena = &arena;
  options.is_ltr = true;
  phx_fe::ToExtractorResponse(*fe_request, *user_action, *config, session, options, extractor_response, nullptr); 

  extractor_response->SerializeToString(&extractor_response_str);
  return extractor_response_str;
}

void free_handle_v2(uint64_t handle) {
  ConfigInfo* config_handle = reinterpret_cast<ConfigInfo*>(handle);

  if (config_handle) {
    delete config_handle;
    config_handle = nullptr;
  }
}

long init_offline_dicts(const std::string& dict_configs_json_str) {
  try {
    nlohmann::json config_array = nlohmann::json::parse(dict_configs_json_str);
    if(!config_array.is_array()) {
      THROW_ERROR("failed to init dict: type mismatch, not json array");
    }
    std::vector<hidict::DictConfig> hidict_configs{};
    std::string archived_dict_path{};
    for(const auto& dict_object : config_array) {
       auto name = dict_object["name"].get<std::string>();

       auto path = dict_object["path"].get<std::string>();
       auto class_name = dict_object["class_name"].get<std::string>();
       hidict::DictConfig hidict_config{};
       hidict_config.m_path = path;
       hidict_config.m_name = name;
       hidict_config.m_clazz = class_name;
       hidict_configs.emplace_back(hidict_config);  

    }
    AdDict::AdDictCollector* dict_collector = new AdDict::AdDictCollector();
    long handle = reinterpret_cast<long>(dict_collector);
    if (!hidict_configs.empty()) {
      bool ret = dict_collector->init(std::to_string(handle), hidict_configs);
      if(!ret) {
        delete dict_collector;
        return 0l;
      }
    }
    return handle;
  } catch (const nlohmann::json::exception& e) {
      THROW_ERROR("failed to init dict: json error, msg = " + std::string(e.what()));
  }
  return 0l;
};

std::shared_ptr<ConfigInfo> init_xml_online_by_decypt_content_new_sample(const std::string &config_content_decrypt,const std::string &model_input_config, AdDict::AdDictCollector* dict_collector) {
    ConfigInfo full_config_info{};
    XmlConfigMgr::parse_from_string(config_content_decrypt, "",full_config_info, (intptr_t) dict_collector);

    std::unordered_set<int64_t> model_slot_ids{};
    try {
      YAML::Node config = YAML::Load(model_input_config);
      for(const auto& input_part :  config["input_tensors"]) {
          const auto slot_id = input_part["input_part"]["slot"];
          if (slot_id) {
            model_slot_ids.emplace(slot_id.as<int64_t>());
          }

          const auto slot_ids = input_part["input_part"]["slots"];
          if (slot_ids) {
            const auto slot_id_vec = slot_ids.as<std::vector<int64_t>>();
            model_slot_ids.insert(slot_id_vec.begin(), slot_id_vec.end());
          }
      }
    } catch (const YAML::Exception& yaml_exception) {
      THROW_ERROR("yaml parse failed! msg = [" + std::string(yaml_exception.what()) + "]");
    }
    if (model_slot_ids.empty()) {
        THROW_ERROR("model input slot id number is empty!");
    }

    return GenerateConfigInfoFromModelInputs(full_config_info, model_slot_ids);
};
