#include "framework.h"
#include "phx-fe/config/config.h"
#include "phx-fe/util/debug_utils.h"
#include "phx-fe/util/farmhash.h"
#include "phx-fe/util/log.h"
#include "phx-fe/util/timer.h"
#include "phx-fe/util/util.h"
#include "tf/tensor.pb.h"
#include <cstddef>
#include <cstdint>
#include <json.hpp>
#include <memory>
#include <ostream>
#include <queue>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#if FASTFLOW_DEBUG_INFO_ENABLE
#include <google/protobuf/util/json_util.h>
#endif

enum HFeatureMode {
    /*
    对于非map字段 填充到feature字段
    对于map字段，根据map的value类型，填充到feature或者feature_list字段
  */
    HFEATURE_MODE_AUTO = 0,

    /*
    填充到feature_list中 最后一个元素feature的value list中，也就是一个具体value
    不支持map字段
  */
    HFEATURE_MODE_VALUE,

    /*
    填充到feature_list的一个元素中，也就是一个feature
    只支持map的value是feature，假如是feature_list则报错
  */
    HFEATURE_MODE_FEATURE,

    /*
    填充到feature的value list的尾部
  */
    HFEATURE_MODE_ADD_TO_FEATURE
};

#if FASTFLOW_DEBUG_INFO_ENABLE
//获取单feature中的数据，返回string
void get_string_feature(const tensorflow::Feature &feat, std::string &part) {
    part.clear();
    part.append("[");
    if (feat.has_bytes_list()) {
        for (auto &s: feat.bytes_list().value()) {
            part.append(s).append(",");
        }
    } else if (feat.has_float_list()) {
        for (float f: feat.float_list().value()) {
            part.append(std::to_string(f)).append(",");
        }
    } else if (feat.has_int64_list()) {
        for (int64_t l: feat.int64_list().value()) {
            part.append(std::to_string(l)).append(",");
        }
    }
    if (',' == part.back()) {
        part.pop_back();
    }
    part.append("]");
}

//打印value中的数据
void value_display(const Value &value, bool flag, uint32_t idx) {
    const InputFeature *inf = nullptr;
    std::string part;
    std::string ifeature_part;
    std::string out;
    out.append("{");
    for (uint32_t i = 0; i < value.ifeatures.size(); i++) {
        ifeature_part.clear();
        inf = &value.ifeatures[i];
        if (likely(inf->feature)) {
            get_string_feature(*inf->feature, part);
            ifeature_part.append(part);
        } else if (likely(inf->feature_list && inf->feature_list->feature_size() > 0)) {
            ifeature_part.append("[");
            for (auto &feat: inf->feature_list->feature()) {
                get_string_feature(feat, part);
                ifeature_part.append(part).append(",");
            }
            if (',' == ifeature_part.back()) {
                ifeature_part.pop_back();
            }
            ifeature_part.append("]");
        } else if (inf->messages.size() > 0) {
            ifeature_part.append("[messages_size: ").append(std::to_string(inf->messages.size())).append("]");
        }
        out.append(ifeature_part).append(",");
    }
    if (',' == out.back()) {
        out.pop_back();
    }
    out.append("}");
    if (flag) {
        LogInfo("Compute input{}:{}", idx, out);
    } else {
        LogInfo("Compute output{}:{}", idx, out);
    }
}

//LogInfo打印compute输入和输出
void compute_display(const std::shared_ptr<Config> config, const std::vector<const Output *> &input_values,
                     const Output &output) {
    LogInfo("Compute name:{}, {} ", config->output_, config->get_config());

    //打印输入
    for (uint32_t i = 0; i < config->inputs_.size(); i++) {
        if (config->inputs_[i].from_request || config->inputs_[i].from_userction) {
            value_display(input_values[i]->values[0], true, i);
        } else {
            value_display(input_values[i]->values[config->inputs_[i].idx], true, i);
        }
    }

    //打印输出
    for (uint32_t i = 0; i < output.values.size(); i++) {
        value_display(output.values[i], false, i);
    }
}
#endif

bool feature_is_not_empty(const tensorflow::Feature &feature) {
    if (feature.float_list().value_size() > 0) {
        return true;
    } else if (feature.int64_list().value_size() > 0) {
        return true;
    } else if (feature.bytes_list().value_size() > 0) {
        return true;
    } else {
        return false;
    }
}

bool featurelist_is_not_empty(const tensorflow::FeatureList &featurelist) {
    for (auto &feature: featurelist.feature()) {
        if (feature_is_not_empty(feature)) {
            return true;
        }
    }
    return false;
}

// 使用默认值填充Feature
bool fill_feature_by_default_value(tensorflow::Feature *feat, google::protobuf::FieldDescriptor::CppType cpp_type,
                                   const DefaultValue &default_value) {
    switch (cpp_type) {
        case google::protobuf::FieldDescriptor::CPPTYPE_INT32:
        case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
            feat->mutable_int64_list()->add_value(default_value.value_int64);
        } break;

        case google::protobuf::FieldDescriptor::CPPTYPE_FLOAT:
        case google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE: {
            feat->mutable_float_list()->add_value(default_value.value_float);
        } break;

        case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
            feat->mutable_bytes_list()->add_value(default_value.value_string);
        } break;

        default: {
            // 目标字段 类型未知，根据配置的默认值填充
            switch (default_value.dtype_) {
                case DATATYPE_INT32:
                case DATATYPE_INT64: {
                    feat->mutable_int64_list()->add_value(default_value.value_int64);
                } break;

                case DATATYPE_FLOAT: {
                    feat->mutable_float_list()->add_value(default_value.value_float);
                } break;

                case DATATYPE_STRING: {
                    feat->mutable_bytes_list()->add_value(default_value.value_string);
                } break;

                default: {
                    return false;
                } break;
            }
        } break;
    }

    return true;
}

// 使用默认值填充, 有多少个默认值，就填充出多少个Feature
bool fill_featurelist_by_default_value(tensorflow::FeatureList *featurelist,
                                       google::protobuf::FieldDescriptor::CppType cpp_type,
                                       const DefaultValue &default_value) {
    switch (cpp_type) {
        case google::protobuf::FieldDescriptor::CPPTYPE_INT32:
        case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
            featurelist->add_feature()->mutable_int64_list()->add_value(default_value.value_int64);
        } break;

        case google::protobuf::FieldDescriptor::CPPTYPE_FLOAT:
        case google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE: {
            featurelist->add_feature()->mutable_float_list()->add_value(default_value.value_float);
        } break;

        case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
            featurelist->add_feature()->mutable_bytes_list()->add_value(default_value.value_string);
        } break;

        default: {
            // 目标字段 类型未知，根据配置的默认值填充
            switch (default_value.dtype_) {
                case DATATYPE_INT32:
                case DATATYPE_INT64: {
                    featurelist->add_feature()->mutable_int64_list()->add_value(default_value.value_int64);
                } break;

                case DATATYPE_FLOAT: {
                    featurelist->add_feature()->mutable_float_list()->add_value(default_value.value_float);
                } break;

                case DATATYPE_STRING: {
                    featurelist->add_feature()->mutable_bytes_list()->add_value(default_value.value_string);
                } break;

                default: {
                    // 完全未知
                    return false;
                } break;
            }
        } break;
    }

    return true;
}

/* 存在map结构
    假如是map<string, Feature> 就填充一个Feature
    假如是map<string, FeatureList> 就填充一个FeatureList
*/
bool none_repeated(google::protobuf::Arena *arena, const google::protobuf::Message &root, const Input &input,
                   const uint32_t idx, InputFeature *ifeature, HFeatureMode mode, bool fill_default_value) {
    const std::vector<std::string> &path = input.name_parts;
    const google::protobuf::Message *mess = &root;
    const uint32_t path_size = path.size();

    for (uint32_t i = idx; i < path_size; i++) {
        LogDebug("path[i]:{}", path[i]);

        if (unlikely(nullptr == mess)) {
            THROW_ERROR("failed, message is nullptr, filed:" + path[i] + " name:" + input.name);
            return false;
        }

        auto desc = mess->GetDescriptor();
        auto ref = mess->GetReflection();
        auto field = desc->FindFieldByName(path[i]);

        if (unlikely(nullptr == ref || nullptr == field)) {
            THROW_ERROR("failed, get null_ptr on " + path[i] + " name:" + input.name);
            return false;
        }
        // 遍历到pb路径的最后一节
        if (i == path_size - 1) {
            LogDebug("ref->HasField(*mess, field):{}", ref->HasField(*mess, field));
            // 如果最后一节还是message，就在ifeature.messages插入数据，然后返回true
            if (field->cpp_type() == google::protobuf::FieldDescriptor::CPPTYPE_MESSAGE) {
                if (ref->HasField(*mess, field)) {
                    ifeature->messages.push_back(&(ref->GetMessage(*mess, field)));
                } else if (!input.is_allow_empty) {
                    THROW_ERROR("messages is empty:" + path[idx] + " name:" + input.name);
                    return false;
                }
                return true;
            }

            tensorflow::Feature *feat = nullptr;
            tensorflow::FeatureList *featurelist = nullptr;
            // 根据mode决策，map类型的mode==HFEATURE_MODE_AUTO，初始化ifeature.feature
            switch (mode) {
                case HFEATURE_MODE_AUTO: {
                    feat = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(arena);
                    ifeature->feature = feat;
                } break;

                case HFEATURE_MODE_VALUE: {
                    if (unlikely(!ifeature->feature_list || 0 == ifeature->feature_list->feature_size())) {
                        THROW_ERROR("invalid:" + path[i] + " name:" + input.name);
                        return false;
                    } else {
                        feat = const_cast<tensorflow::FeatureList *>(ifeature->feature_list)
                                       ->mutable_feature(ifeature->feature_list->feature_size() - 1);
                    }
                } break;

                case HFEATURE_MODE_FEATURE: {
                    if (!ifeature->feature_list) {
                        ifeature->feature_list = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(arena);
                    }
                    featurelist = const_cast<tensorflow::FeatureList *>(ifeature->feature_list);
                    feat = featurelist->add_feature();
                } break;

                case HFEATURE_MODE_ADD_TO_FEATURE: {
                    if (ifeature->feature == nullptr) {
                        feat = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(arena);
                        ifeature->feature = feat;
                    } else {
                        feat = const_cast<tensorflow::Feature *>(ifeature->feature);
                    }
                } break;

                default: {
                    THROW_ERROR("invalid mode:" + std::to_string((int32_t) mode) + " filed:" + path[i] +
                                " name:" + input.name);
                    return false;
                } break;
            }

            // proto3 字段一定要加上optional
            // 如果发现Input没设置值，就给默认值
            if (!ref->HasField(*mess, field) && fill_default_value) {
                // 填充默认值
                if (!fill_feature_by_default_value(feat, field->cpp_type(), input.default_value) &&
                    !input.is_allow_empty) {
                    THROW_ERROR("fill default failed:" + path[i] + " name:" + input.name);
                    return false;
                }
                return true;
            }
            // 根据基本类型插入值，如果在上一步设置默认值了就跳过
            switch (field->cpp_type()) {
                case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
                    LogDebug("ref->GetInt64(*mess, field):{}", ref->GetInt64(*mess, field));
                    feat->mutable_int64_list()->add_value(ref->GetInt64(*mess, field));
                    return true;
                } break;

                case google::protobuf::FieldDescriptor::CPPTYPE_INT32: {
                    LogDebug("ref->GetInt32(*mess, field):{}", ref->GetInt32(*mess, field));
                    feat->mutable_int64_list()->add_value(ref->GetInt32(*mess, field));
                    return true;
                } break;

                case google::protobuf::FieldDescriptor::CPPTYPE_FLOAT: {
                    LogDebug("ref->GetFloat(*mess, field):{}", ref->GetFloat(*mess, field));
                    feat->mutable_float_list()->add_value(ref->GetFloat(*mess, field));
                    return true;
                } break;

                case google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE: {
                    LogDebug("ref->GetDouble(*mess, field):{}", ref->GetDouble(*mess, field));
                    feat->mutable_float_list()->add_value(static_cast<float>(ref->GetDouble(*mess, field)));
                    return true;
                } break;

                case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
                    LogDebug("ref->GetString(*mess, field):{}", ref->GetString(*mess, field));
                    feat->mutable_bytes_list()->add_value(ref->GetString(*mess, field));
                    return true;
                } break;

                default: {
                    THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " filed:" + path[i] +
                                " name:" + input.name);
                } break;
            }
        } else {
            mess = &(ref->GetMessage(*mess, field));
        }
    }

    if (idx == path_size) {
        ifeature->messages.push_back(&root);
        return true;
    }

    return false;
}

/*
  构造填充feature_list的一个feature
*/
bool second_repeated(google::protobuf::Arena *arena, const google::protobuf::Message &root, const Input &input,
                     const uint32_t idx, InputFeature *ifeature) {
    const std::vector<std::string> &path = input.name_parts;
    auto desc = root.GetDescriptor();
    auto ref = root.GetReflection();
    auto field = desc->FindFieldByName(path[idx]);

    if (unlikely(nullptr == ref || nullptr == field)) {
        THROW_ERROR("failed, get null_ptr on " + path[idx] + " name:" + input.name);
        return false;
    }

    const uint32_t s = ref->FieldSize(root, field);
    tensorflow::FeatureList *featurelist = nullptr;
    tensorflow::Feature *feat = nullptr;

    if (idx != input.name_parts.size() - 1 || field->cpp_type() != google::protobuf::FieldDescriptor::CPPTYPE_MESSAGE) {
        if (!ifeature->feature_list) {
            ifeature->feature_list = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(arena);
        }
        featurelist = const_cast<tensorflow::FeatureList *>(ifeature->feature_list);
        feat = featurelist->add_feature();
    }

    if (s > 0) {
        switch (field->cpp_type()) {
            case google::protobuf::FieldDescriptor::CPPTYPE_MESSAGE: {
                for (uint32_t i = 0; i < s; i++) {
                    auto &m = ref->GetRepeatedMessage(root, field, i);
                    LogDebug("second, input:{}", input.name);
                    none_repeated(arena, m, input, idx + 1, ifeature, HFEATURE_MODE_VALUE, true);
                }
            } break;

            case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
                for (uint32_t i = 0; i < s; i++) {
                    feat->mutable_int64_list()->add_value(ref->GetRepeatedInt64(root, field, i));
                }
                break;
            }
            case google::protobuf::FieldDescriptor::CPPTYPE_INT32: {
                for (uint32_t i = 0; i < s; i++) {
                    feat->mutable_int64_list()->add_value(ref->GetRepeatedInt32(root, field, i));
                }
            } break;

            case google::protobuf::FieldDescriptor::CPPTYPE_FLOAT: {
                for (uint32_t i = 0; i < s; i++) {
                    feat->mutable_float_list()->add_value(ref->GetRepeatedFloat(root, field, i));
                }
            } break;

            case google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE: {
                for (uint32_t i = 0; i < s; i++) {
                    feat->mutable_float_list()->add_value(static_cast<float>(ref->GetRepeatedDouble(root, field, i)));
                }
            } break;

            case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
                for (uint32_t i = 0; i < s; i++) {
                    feat->mutable_bytes_list()->add_value(ref->GetRepeatedString(root, field, i));
                }
            } break;

            default: {
                THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " filed:" + path[idx] +
                            " name:" + input.name);
            } break;
        }
    } else {
        if (path.size() - 1 == idx && field->cpp_type() == google::protobuf::FieldDescriptor::CPPTYPE_MESSAGE) {
            if (!input.is_allow_empty) {
                THROW_ERROR("messages is empty:" + path[idx] + " name:" + input.name);
                return false;
            }
            return true;
        }
    }

    return true;
}

bool first_repeated_as_feature(google::protobuf::Arena *arena, const google::protobuf::Message &root,
                               const Input &input, const uint32_t idx, InputFeature *ifeature) {
    const std::vector<std::string> &path = input.name_parts;
    auto desc = root.GetDescriptor();
    auto ref = root.GetReflection();
    auto field = desc->FindFieldByName(path[idx]);
    if (unlikely(nullptr == ref || nullptr == field)) {
        THROW_ERROR("failed, get null_ptr on " + path[idx] + " name:" + input.name);
        return false;
    }
    // 查询数组的长度
    const uint32_t s = ref->FieldSize(root, field);
    tensorflow::Feature *feature;
    if (likely(s > 0)) {
        // 当前字段是message
        if (field->cpp_type() == google::protobuf::FieldDescriptor::CPPTYPE_MESSAGE) {
            LogDebug("CPPTYPE_MESSAGE:{}", s);
            // loop for every message
            for (uint32_t i = 0; i < s; i++) {
                const google::protobuf::Message *m = &(ref->GetRepeatedMessage(root, field, i));
                if (unlikely(nullptr == m)) {
                    THROW_ERROR("failed, m is null_ptr, input name:" + input.name);
                    return false;
                }

                LogDebug("first, input:{}", input.name);
                /**
                 * @brief 没有二级repeated字段，将结果填充到feature的value list尾部
                 * 由于repeated为message,这里为了处理取相同message的不同field导致对不齐的问题,所以需要填充默认值
                 * eg. message user_app_seq{ int64 app_id = 1; int64 event_time = 2;}
                 * repeated user_app_seq的长度为2,第一个user_app_seq的app_id填充，event_time未填充, 第二个user_app_seq的
                 * app_id和event_time均填充,如果不补齐则会导致行为序列对不齐
                 */
                none_repeated(arena, *m, input, idx + 1, ifeature, HFEATURE_MODE_ADD_TO_FEATURE, true);
            }
        } else {
            switch (field->cpp_type()) {
                case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
                    feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(arena);
                    ifeature->feature = feature;
                    for (uint32_t i = 0; i < s; i++) {
                        feature->mutable_int64_list()->add_value(ref->GetRepeatedInt64(root, field, i));
                    }
                } break;
                case google::protobuf::FieldDescriptor::CPPTYPE_INT32: {
                    LogDebug("CPPTYPE_INT32:{}", s);
                    feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(arena);
                    ifeature->feature = feature;
                    for (uint32_t i = 0; i < s; i++) {
                        feature->mutable_int64_list()->add_value(ref->GetRepeatedInt32(root, field, i));
                    }
                } break;

                case google::protobuf::FieldDescriptor::CPPTYPE_FLOAT: {
                    LogDebug("CPPTYPE_FLOAT:{}", s);
                    feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(arena);
                    ifeature->feature = feature;
                    for (uint32_t i = 0; i < s; i++) {
                        feature->mutable_float_list()->add_value(ref->GetRepeatedFloat(root, field, i));
                    }
                } break;

                case google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE: {
                    LogDebug("CPPTYPE_DOUBLE:{}", s);

                    feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(arena);
                    ifeature->feature = feature;
                    for (uint32_t i = 0; i < s; i++) {
                        feature->mutable_float_list()->add_value(
                                static_cast<float>(ref->GetRepeatedDouble(root, field, i)));
                    }
                } break;

                case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
                    LogDebug("CPPTYPE_STRING:{}", s);

                    feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(arena);
                    ifeature->feature = feature;
                    for (uint32_t i = 0; i < s; i++) {
                        feature->mutable_bytes_list()->add_value(ref->GetRepeatedString(root, field, i));
                    }
                } break;
                default: {
                    THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " filed:" + path[idx] +
                                " name:" + input.name);
                    return false;
                } break;
            }
        }

    } else {
        /**
         * @brief 一层repeated的情况
         *        1. 如果repeated的field为message类型,且size=0,填充空的feature
         *        2. 如果repeated的field为基本数据类型,且size=0,填充空的feature
         * 
         */

        tensorflow::Feature *feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(arena);
        ifeature->feature = feature;
    }
    return true;
}

/*
  构造填充feature_list
*/
bool first_repeated(google::protobuf::Arena *arena, const google::protobuf::Message &root, const Input &input,
                    const uint32_t idx, const bool has_second_repeated, InputFeature *ifeature) {
    const std::vector<std::string> &path = input.name_parts;
    auto desc = root.GetDescriptor();
    auto ref = root.GetReflection();
    auto field = desc->FindFieldByName(path[idx]);

    if (unlikely(nullptr == ref || nullptr == field)) {
        THROW_ERROR("failed, get null_ptr on " + path[idx] + " name:" + input.name);
        return false;
    }

    const uint32_t s = ref->FieldSize(root, field);
    LogDebug("path[idx]:{}, s:{}", path[idx], s);

    if (likely(s > 0)) {
        // 当前字段是结构体
        if (field->cpp_type() == google::protobuf::FieldDescriptor::CPPTYPE_MESSAGE) {
            LogDebug("CPPTYPE_MESSAGE:{}", s);
            // loop for every message
            for (uint32_t i = 0; i < s; i++) {
                const google::protobuf::Message *m = &(ref->GetRepeatedMessage(root, field, i));
                if (unlikely(nullptr == m)) {
                    THROW_ERROR("failed, m is null_ptr, input name:" + input.name);
                    return false;
                }

                LogDebug("has_second_repeated:{}", has_second_repeated);

                // 存在二级repeated字段
                if (has_second_repeated) {
                    for (uint32_t j = idx + 1; j < path.size(); j++) {
                        auto desc = m->GetDescriptor();
                        auto ref = m->GetReflection();
                        auto field = desc->FindFieldByName(path[j]);

                        if (unlikely(nullptr == ref || nullptr == field)) {
                            THROW_ERROR("failed, get null_ptr on " + path[j] + " name:" + input.name);
                            return false;
                        }

                        // 找到二级repeated字段，
                        if (field->is_repeated()) {
                            second_repeated(arena, *m, input, j, ifeature);
                            break;
                        } else {
                            m = &(ref->GetMessage(*m, field));
                            if (unlikely(nullptr == m)) {
                                THROW_ERROR("failed, m is null_ptr, input name:" + input.name);
                                return false;
                            }
                        }
                    }
                } else {
                    // 没有二级repeated字段了，每个结构体填充一个feature
                    LogDebug("first, input:{}", input.name);
                    none_repeated(arena, *m, input, idx + 1, ifeature, HFEATURE_MODE_FEATURE, true);
                }
            }
        } else {
            tensorflow::FeatureList *featurelist = nullptr;
            // 当前字段即是repeated具体数据，每个数据一个feature进行填充
            switch (field->cpp_type()) {
                case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
                    LogDebug("CPPTYPE_INT64:{}", s);

                    featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(arena);
                    ifeature->feature_list = featurelist;
                    for (uint32_t i = 0; i < s; i++) {
                        featurelist->add_feature()->mutable_int64_list()->add_value(
                                ref->GetRepeatedInt64(root, field, i));
                    }
                } break;

                case google::protobuf::FieldDescriptor::CPPTYPE_INT32: {
                    LogDebug("CPPTYPE_INT32:{}", s);

                    featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(arena);
                    ifeature->feature_list = featurelist;
                    for (uint32_t i = 0; i < s; i++) {
                        featurelist->add_feature()->mutable_int64_list()->add_value(
                                ref->GetRepeatedInt32(root, field, i));
                    }
                } break;

                case google::protobuf::FieldDescriptor::CPPTYPE_FLOAT: {
                    LogDebug("CPPTYPE_FLOAT:{}", s);

                    featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(arena);
                    ifeature->feature_list = featurelist;
                    for (uint32_t i = 0; i < s; i++) {
                        featurelist->add_feature()->mutable_float_list()->add_value(
                                ref->GetRepeatedFloat(root, field, i));
                    }
                } break;

                case google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE: {
                    LogDebug("CPPTYPE_DOUBLE:{}", s);

                    featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(arena);
                    ifeature->feature_list = featurelist;
                    for (uint32_t i = 0; i < s; i++) {
                        featurelist->add_feature()->mutable_float_list()->add_value(
                                static_cast<float>(ref->GetRepeatedDouble(root, field, i)));
                    }
                } break;

                case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
                    LogDebug("CPPTYPE_STRING:{}", s);

                    featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(arena);
                    ifeature->feature_list = featurelist;
                    for (uint32_t i = 0; i < s; i++) {
                        featurelist->add_feature()->mutable_bytes_list()->add_value(
                                ref->GetRepeatedString(root, field, i));
                    }
                } break;

                default: {
                    THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " filed:" + path[idx] +
                                " name:" + input.name);
                    return false;
                } break;
            }
        }
    } else {
        if (path.size() - 1 == idx && field->cpp_type() == google::protobuf::FieldDescriptor::CPPTYPE_MESSAGE) {
            if (!input.is_allow_empty) {
                THROW_ERROR("messages is empty:" + path[idx] + " name:" + input.name);
                return false;
            }
            return true;
        }
        // 使用默认值填充, 有多少个默认值，就填充出多少个Feature
        tensorflow::FeatureList *featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(arena);
        ifeature->feature_list = featurelist;
    }

    return true;
}

// 依次遍历 直至repeated字段
const google::protobuf::Message *find_until_repeated(const google::protobuf::Message *m,
                                                     const std::vector<std::string> &input_paths,
                                                     const std::string &input_name, uint32_t &index) {
    for (; index < input_paths.size(); index++) {
        if (unlikely(nullptr == m)) {
            THROW_ERROR("failed, m is null_ptr, input_paths:" + input_paths[index] + ", name:" + input_name);
            return nullptr;
        }

        auto desc = m->GetDescriptor();
        auto ref = m->GetReflection();
        auto field = desc->FindFieldByName(input_paths[index]);

        if (unlikely(nullptr == ref || nullptr == field)) {
            THROW_ERROR("failed, get null_ptr on " + input_paths[index] + ", name:" + input_name);
            return nullptr;
        }

        if (field->is_repeated()) {
            break;
        } else {
            m = &(ref->GetMessage(*m, field));
        }
    }

    return m;
}
void GenerateOutputFromRequest(const phx::FeRequest &fe_request, const phx::UserAction &user_action, const Input &input,
                               Output &output) {

    // 取pb路径
    const std::vector<std::string> &input_paths = input.name_parts;
    const uint32_t input_paths_len = input_paths.size();
    if (unlikely(input_paths_len < 1)) {
        THROW_ERROR("check faild, input name:" + input.name);
        return;
    }
    // 取重复个数
    const uint32_t repeated_field_num = input.repeated_count;
    auto *root_desc = input.from_userction ? phx::UserAction::GetDescriptor() : phx::FeRequest::GetDescriptor();
    auto *reflection = input.from_userction ? phx::UserAction::GetReflection() : phx::FeRequest::GetReflection();
    // 定义一个指向ferequest或user_action的指针
    const google::protobuf::Message *root_msg = &fe_request;
    if (input.from_userction) {
        root_msg = &user_action;
    }
    // 调整output大小为1，并插入一个value在values[0]
    output.values.resize(1);
    auto &value = output.values[0];
    // 若不是itemfeature
    if (!input.is_item_feature) {
        value.ifeatures.resize(1);
        // 存在map结构
        if (repeated_field_num == 0) {
            none_repeated(output.arena, *root_msg, input, 0, &value.ifeatures[0], HFEATURE_MODE_AUTO, true);
        } else if (repeated_field_num == 1) {
            uint32_t idx = 0;
            // 找到repeated的字段
            const google::protobuf::Message *m = find_until_repeated(root_msg, input_paths, input.name, idx);
            if (unlikely(nullptr == m)) {
                THROW_ERROR("find message failed, input name:" + input.name);
                return;
            }
            // m为repeated field的上一层message
            first_repeated_as_feature(output.arena, *m, input, idx, &value.ifeatures[0]);
        } else if (repeated_field_num == 2) {
            uint32_t idx = 0;
            const google::protobuf::Message *m = find_until_repeated(root_msg, input_paths, input.name, idx);
            if (unlikely(nullptr == m)) {
                THROW_ERROR("find message failed, input name:" + input.name);
                return;
            }

            first_repeated(output.arena, *m, input, idx, true, &value.ifeatures[0]);
        }
    } else {
        // 是itemfeature
        auto *field_desc = root_desc->FindFieldByName(input_paths[0]);
        int32_t field_size = reflection->FieldSize(*root_msg, field_desc);
        // itemfeature会先resize多个ifeatures
        value.ifeatures.resize(field_size);
        for (int32_t i = 0; i < field_size; i++) {
            auto &item_feature_root = reflection->GetRepeatedMessage(*root_msg, field_desc, i);
            auto item_ifeature = &value.ifeatures[i];
            // 存在map结构
            if (repeated_field_num == 0) {
                none_repeated(output.arena, item_feature_root, input, 1, item_ifeature, HFEATURE_MODE_AUTO, true);
            } else if (repeated_field_num == 1) {
                uint32_t idx = 1;
                const google::protobuf::Message *m =
                        find_until_repeated(&item_feature_root, input_paths, input.name, idx);
                if (unlikely(nullptr == m)) {
                    THROW_ERROR("find message failed, input name:" + input.name);
                    return;
                }

                first_repeated_as_feature(output.arena, *m, input, idx, item_ifeature);
            } else if (repeated_field_num == 2) {
                uint32_t idx = 1;
                const google::protobuf::Message *m =
                        find_until_repeated(&item_feature_root, input_paths, input.name, idx);
                if (unlikely(nullptr == m)) {
                    THROW_ERROR("find message failed, input name:" + input.name);
                    return;
                }

                first_repeated(output.arena, *m, input, idx, true, item_ifeature);
            }
        }
    }

    LogDebug("input_paths[0]:{}", input_paths[0]);
    LogDebug("repeated_field_num:{}", repeated_field_num);
}

uint32_t get_repeated_field_num(const google::protobuf::Message &root, const Input &input, const uint32_t from_idx) {
    const std::vector<std::string> &path = input.name_parts;
    const google::protobuf::Message *mess = &root;
    const uint32_t path_size = path.size();

    auto desc = mess->GetDescriptor();
    uint32_t repeated_field_size = 0;

    for (uint32_t i = from_idx; i < path_size; i++) {
        if (nullptr == desc) {
            THROW_ERROR("parse input failed, unknow pb, nullptr:" + path[i] + ", name" + input.name);
            break;
        }

        const google::protobuf::FieldDescriptor *field = desc->FindFieldByName(path[i]);
        if (nullptr == field) {
            THROW_ERROR("parse input failed, unknow pb, nullptr:" + path[i] + ", name" + input.name);
            break;
        }

        desc = field->message_type();

        if (field->is_map()) {
            THROW_ERROR("parse input failed, field is map , path:" + path[i] + ", name" + input.name);
            break;
        } else if (field->is_repeated()) {
            repeated_field_size++;
        }
    }

    return repeated_field_size;
}

void generateOutputFromMessage(const Input &input, const std::unordered_map<std::string, Output> &immutable_cache,
                               std::unordered_map<std::string, Output> &inc_cache, Output &output) {
    const Output *message_output_ptr = nullptr;
    auto immutable_cache_itr = immutable_cache.find(input.name_parts[0]);
    if (immutable_cache_itr != immutable_cache.end()) {
        message_output_ptr = &immutable_cache_itr->second;
    } else {
        auto inc_cache_itr = inc_cache.find(input.name_parts[0]);
        if (inc_cache_itr != inc_cache.end()) {
            message_output_ptr = &inc_cache_itr->second;
        }
    }
    if (likely(message_output_ptr != nullptr)) {
        auto &message_output = *message_output_ptr;
        if (unlikely(input.idx < 0 || input.idx >= (int32_t) message_output.values.size())) {
            THROW_ERROR("invalid idx:" + std::to_string(input.idx) +
                        ", value_size:" + std::to_string(message_output.values.size()) + ", name:" + input.name);
            return;
        }
        const Value *value_ptr = &message_output.values[input.idx];
        uint32_t value_size = value_ptr->ifeatures.size();
        output.values.resize(1);
        auto &value = output.values[0];
        value.ifeatures.resize(value_size);
        uint32_t repeated_field_num = input.repeated_count;
        for (uint32_t i = 0; i < value_size; i++) {
            if (!value_ptr->ifeatures[i].messages.empty()) {
                repeated_field_num = get_repeated_field_num(*value_ptr->ifeatures[i].messages[0], input, 1);
                break;
            }
        }

        for (uint32_t i = 0; i < value_size; i++) {
            auto &meassage_vec = value_ptr->ifeatures[i].messages;

            if (likely(!meassage_vec.empty())) {
                for (uint32_t j = 0; j < meassage_vec.size(); j++) {
                    if (repeated_field_num == 0) {
                        none_repeated(output.arena, *meassage_vec[j], input, 1, &value.ifeatures[i],
                                      HFEATURE_MODE_ADD_TO_FEATURE, true);
                    } else {
                        first_repeated_as_feature(output.arena, *meassage_vec[j], input, 1, &value.ifeatures[i]);
                    }
                }
            } else {
                // 如果message为空，生成一个空的feature
                value.ifeatures[i].feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            }
        }

    } else {
        THROW_ERROR("find feature_name failed:" + input.name_parts[0] + ", name:" + input.name);
        return;
    }
}

void getInputsResultV2(google::protobuf::Arena *arena, const phx::FeRequest &fe_request,
                       const phx::UserAction &user_action, const std::vector<Input> &inputs,
                       const std::unordered_map<std::string, Output> &immutable_cache,
                       std::unordered_map<std::string, Output> &inc_cache, std::vector<const Output *> &ret) {
    for (auto &input: inputs) {
        // 查找调用方输入的缓存,这个缓存应当是不可变的,防止出现线程安全问题
        auto iter = immutable_cache.find(input.name);
        if (iter != immutable_cache.end()) {
            LogDebug("find in cache:{}", input.name);
            ret.push_back(&(iter->second));
        } else {
            LogDebug("create to cache:{}", input.name);
            auto iter = inc_cache.find(input.name);
            if (iter == inc_cache.end()) {
                Output &output = inc_cache[input.name];
                output.arena = arena;
                if (input.from_request || input.from_userction) {
                    GenerateOutputFromRequest(fe_request, user_action, input, output);
                } else {
                    generateOutputFromMessage(input, immutable_cache, inc_cache, output);
                }
                ret.push_back(&output);
            } else {
                ret.push_back(&iter->second);
            }
        }
    }
}

nlohmann::json to_json(const std::vector<const Output *> &input_values) {
    nlohmann::json j;
    for (const auto output: input_values) {
        j.emplace_back(debug::ToJson(*output));
    }
    return j;
}

void generateFeMapV2(google::protobuf::Arena *arena, const phx::FeRequest &fe_request,
                     const phx::UserAction &user_action, const std::vector<std::shared_ptr<Config>> &configs,
                     const std::unordered_map<std::string, Output> &immutable_cache,
                     std::unordered_map<std::string, Output> *inc_cache, uint32_t batch_size) {
#if FASTFLOW_GENERATE_TIMER_ENABLE
    PointTimer ptimer("fe");
#endif

#if FASTFLOW_DEBUG_INFO_ENABLE
    nlohmann::json in_out_log;
#endif
    // 增量缓存
    inc_cache->reserve(configs.size() * 4);

    // 遍历config，将input是原始输入的，生成
    for (auto &config: configs) {
        // 该feature已经被抽取出来了,跳过
        if (immutable_cache.find(config->output_) != immutable_cache.end()) {
            continue;
        }
        LogDebug("config:{}", (uint64_t) config.get());

        Output &output = inc_cache->operator[](config->output_);
        output.arena = arena;
        output.allow_empty_output = config->allow_empty_output_;

        LogDebug("config->output_:{}", config->output_);

        std::vector<const Output *> input_values;
        {
            // DEBUG_TIMER("input_result");
            getInputsResultV2(arena, fe_request, user_action, config->inputs_, immutable_cache, *inc_cache,
                              input_values);
        }

        LogDebug("config->output_:{} start compute", config->output_);

        //#if FASTFLOW_GENERATE_TIMER_ENABLE
        //ptimer.point(config->output_ + "_input");
        //#endif

        config->compute(input_values, output);
        //策略处理
        for (auto &strategy: config->strategy_) {
            strategy->Execution(output, config->output_);
        }
#if FASTFLOW_DEBUG_INFO_ENABLE
        in_out_log[config->output_]["input"] = to_json(input_values);
        in_out_log[config->output_]["output"] = debug::ToJson(output);

        LogInfo("Compute ------------------------------------------------------");
        compute_display(config, input_values, output);
#endif

        LogDebug("config->output_:{} done compute", config->output_);

#if FASTFLOW_GENERATE_TIMER_ENABLE
        ptimer.point(config->output_ + "_compute");
#endif
    }
#if FASTFLOW_DEBUG_INFO_ENABLE
    LogCheck(in_out_log.dump());
#endif

#if FASTFLOW_GENERATE_TIMER_ENABLE
    ptimer.display();
#endif
}

void ToExtractorResponseImpl(const phx::FeRequest &fe_request, const phx::UserAction &user_action,
                             const ConfigInfo &fe_configs, const phx_fe::Session &session, const phx_fe::Options &options,
                             phx::ExtractorResponse *ret, std::unordered_map<std::string, Output> *inc_cache_output) {
#if FASTFLOW_OFFLINE_TIMER_ENABLE
    PointTimer ptimer("batch_size_" + std::to_string(batch_size));
#endif
    const std::unordered_map<std::string, Output> &immutable_cache = session.cache;
    const auto &configs = options.configs_supplier(fe_configs);
    if (configs.empty()) {
        THROW_ERROR("configs is empty");
    }
    auto batch_size = options.expected_batch_size;
    std::unordered_map<std::string, Output> inc_cache_local;
    std::unordered_map<std::string, Output> &inc_cache =
            (inc_cache_output != nullptr) ? *inc_cache_output : inc_cache_local;
    generateFeMapV2(options.arena, fe_request, user_action, configs, immutable_cache, &inc_cache, batch_size);

#if FASTFLOW_OFFLINE_TIMER_ENABLE
    ptimer.point("generateFeMap");
#endif

#if FASTFLOW_DEBUG_ENABLE
    LogDebug("cache.size():{}", cache.size());
    for (const auto &pair: cache) {
        LogDebug("cache name:{}", pair.first);
    }
#endif

    fill_extra_feature(fe_configs.labels_, fe_configs.name2config_, inc_cache, *ret, batch_size,
                       &phx::ExtractorResponse::add_labels, options.is_ltr);
    fill_extra_feature(fe_configs.weights_, fe_configs.name2config_, inc_cache, *ret, batch_size,
                       &phx::ExtractorResponse::add_weights, options.is_ltr);
    // 只有LTR样本要填充user_extra特征
    if (options.is_ltr) {
        fill_extra_feature(fe_configs.user_extras_int64_, fe_configs.name2config_, inc_cache, *ret, batch_size,
                           &phx::ExtractorResponse::add_user_extras_int64, options.is_ltr, true);
        fill_extra_feature(fe_configs.user_extras_float_, fe_configs.name2config_, inc_cache, *ret, batch_size,
                           &phx::ExtractorResponse::add_user_extras_float, options.is_ltr, true);
        fill_extra_feature(fe_configs.user_extras_bytes_, fe_configs.name2config_, inc_cache, *ret, batch_size,
                           &phx::ExtractorResponse::add_user_extras_bytes, options.is_ltr, true);
    }

    fill_extra_feature(fe_configs.item_extras_int64_, fe_configs.name2config_, inc_cache, *ret, batch_size,
                       &phx::ExtractorResponse::add_item_extras_int64, options.is_ltr);
    fill_extra_feature(fe_configs.item_extras_float_, fe_configs.name2config_, inc_cache, *ret, batch_size,
                       &phx::ExtractorResponse::add_item_extras_float, options.is_ltr);
    fill_extra_feature(fe_configs.item_extras_bytes_, fe_configs.name2config_, inc_cache, *ret, batch_size,
                       &phx::ExtractorResponse::add_item_extras_bytes, options.is_ltr);
    // inc_cahe_output为空指针时,说明外部不需要这个cache，我们可以使用swap
    bool own_inc_cache = inc_cache_output == nullptr;
    const auto &model_input_slots = options.model_slots_getter(fe_configs);
    for (auto &config: configs) {
        const std::string &name = config->output_;
        if (config->slot_id_ < 0) {
            LogDebug("config->slot_id_{}; skip", config->slot_id_);
            continue;
        }

        if (!model_input_slots.empty()) {
            auto iter = model_input_slots.find(config->slot_id_);
            // 如果配置了model_input_slots_且 slot不在model_input_slots_中，跳过这个slot
            if (iter == model_input_slots.end()) {
                continue;
            }
        }

        const Output *output_ptr = nullptr;
        bool can_swap_flag = false;
        auto inc_cache_iter = inc_cache.find(name);
        // 只有在命中增量缓存且增量缓存不作为返回值的情况下，我们才能进行swap
        if (inc_cache_iter != inc_cache.end()) {
            output_ptr = &(inc_cache_iter->second);
            can_swap_flag = own_inc_cache;
        } else {
            auto iter = immutable_cache.find(name);
            if (iter != immutable_cache.end()) {
                output_ptr = &(iter->second);
            }
        }

        if (unlikely(output_ptr == nullptr)) {
            THROW_ERROR("error happens, can not find output, config->output_:" + name);
            continue;
        }
        auto &output = *output_ptr;

        LogDebug("output.values.size():{}", output.values.size());

        if (unlikely(output.values.empty())) {
            THROW_ERROR("config->output_ empty:" + name);
            continue;
        }

        // 只保存1个结果的提取，多个计算结果如需保存，需使用direct
        if (1 != output.values.size()) {
            LogDebug("output.values.size():{}", output.values.size());
            THROW_ERROR("this config has contains multiple outputs, the extraction result is ambiguous. name:[" + name +
                        "]");
            continue;
        }

        if (unlikely(output.values[0].ifeatures.empty())) {
            if (config->allow_empty_output_) {
                std::cout << "output.values[0].ifeatures is empty! feature name = [" << name << "]" << std::endl;
                switch (config->attr_type_) {
                    case ATTR_TYPE_USER: {
                        auto *user_feature = ret->add_user_features();
                        user_feature->set_slot_id(config->slot_id_);
                        break;
                    }
                    case ATTR_TYPE_ITEM:
                    case ATTR_TYPE_CROSS: {
                        for (int32_t i = 0; i < batch_size; i++) {
                            auto *item_feature = ret->add_item_features();
                            item_feature->set_slot_id(config->slot_id_);
                        }
                        break;
                    }
                    default: {
                        THROW_ERROR("config attr_type not define, name:" + name);
                        break;
                    }
                }
            } else {
                THROW_ERROR("config->output_ empty:" + name);
            }
            continue;
        }

        auto &value = output.values[0];
        auto &real_values = value.ifeatures;
        const uint32_t real_values_size = real_values.size();

        LogDebug("name:" + name + " real_values_size:{} batch_size:{}", real_values_size, batch_size);

        if (unlikely(real_values_size < 1)) {
            THROW_ERROR("name:" + name + " nullptr, no value");
            continue;
        }

        if (unlikely(real_values_size != 1 && real_values_size != batch_size)) {
            THROW_ERROR("real_values_size:" + std::to_string(real_values_size) +
                        ", batch_size:" + std::to_string(batch_size) + ", name:" + name);
            continue;
        }

        auto &first_hf = real_values[0];

        if (first_hf.feature) {
            if (real_values_size == batch_size) {
                for (uint32_t i = 0; i < batch_size; i++) {
                    auto &batch_hf = real_values[i];
                    if ((batch_hf.feature->bytes_list().value_size() <= 0 &&
                         batch_hf.feature->float_list().value_size() <= 0 &&
                         batch_hf.feature->int64_list().value_size() <= 0) &&
                        !config->allow_empty_output_) {
                        THROW_ERROR("output type is empty feature, name:" + name);
                        continue;
                    }
                }
                if (config->slot_id_ > 0) {
                    switch (config->attr_type_) {
                        case ATTR_TYPE_USER: {
                            if (unlikely(real_values_size != 1)) {
                                THROW_ERROR("config attr_type is user, but real is item, name:" + name);
                            }
                            auto *user_feature = ret->add_user_features();
                            user_feature->set_slot_id(config->slot_id_);
                            if (can_swap_flag) {
                                Swap(const_cast<tensorflow::Feature *>(first_hf.feature), user_feature);
                            } else {
                                DeepCopy(first_hf.feature, user_feature);
                            }

                            break;
                        }
                        case ATTR_TYPE_ITEM:
                        case ATTR_TYPE_CROSS: {
                            if (can_swap_flag) {
                                for (uint32_t i = 0; i < batch_size; i++) {
                                    auto *item_feature = ret->add_item_features();
                                    item_feature->set_slot_id(config->slot_id_);
                                    Swap(const_cast<tensorflow::Feature *>(real_values[i].feature), item_feature);
                                }
                            } else {
                                for (uint32_t i = 0; i < batch_size; i++) {
                                    auto *item_feature = ret->add_item_features();
                                    item_feature->set_slot_id(config->slot_id_);
                                    DeepCopy(real_values[i].feature, item_feature);
                                }
                            }
                            break;
                        }
                        default: {
                            THROW_ERROR("config attr_type not define, name:" + name);
                            break;
                        }
                    }
                }
            } else {
                if ((first_hf.feature->bytes_list().value_size() <= 0 &&
                     first_hf.feature->float_list().value_size() <= 0 &&
                     first_hf.feature->int64_list().value_size() <= 0) &&
                    !config->allow_empty_output_) {
                    THROW_ERROR("output type is empty feature, name:" + name);
                    continue;
                }
                if (config->slot_id_ > 0) {
                    switch (config->attr_type_) {
                        case ATTR_TYPE_USER: {
                            auto *user_feature = ret->add_user_features();
                            user_feature->set_slot_id(config->slot_id_);
                            if (can_swap_flag) {
                                Swap(const_cast<tensorflow::Feature *>(first_hf.feature), user_feature);
                            } else {
                                DeepCopy(first_hf.feature, user_feature);
                            }
                            break;
                        }
                        case ATTR_TYPE_ITEM:
                        case ATTR_TYPE_CROSS: {
                            THROW_ERROR("config attr_type is item or cross, but real is user, name:" + name);
                            break;
                        }
                        default: {
                            THROW_ERROR("config attr_type not define, name:" + name);
                            break;
                        }
                    }
                }
            }
        } else if (first_hf.feature_list) {
            THROW_ERROR("new sample output type featurelists not supported, name:" + name +
                        "; slot:" + std::to_string(config->slot_id_));
            continue;
        } else {
            THROW_ERROR("output type not feature, name:" + name);
            continue;
        }

#if FASTFLOW_OFFLINE_TIMER_ENABLE
        ptimer.point("output_name_" + name);
#endif
    }

#if FASTFLOW_OFFLINE_TIMER_ENABLE
    ptimer.display();
#endif

#if FASTFLOW_DEBUG_INFO_ENABLE
    std::string json_string;
    google::protobuf::util::MessageToJsonString(*ret, &json_string);
    LogInfo("toExtractorResponse ------------------------------------------------------");
    LogInfo("toExtractorResponse:{}", json_string);
#endif
}

void toExtractorResponse(google::protobuf::Arena *arena, phx::FeRequest &fe_object, phx::UserAction &user_action,
                         const ConfigInfo &fe_configs, phx::ExtractorResponse &extractor_response, bool is_ltr) {
    phx_fe::Session session;
    phx_fe::Options options;
    options.arena = arena;
    options.is_ltr = is_ltr;
    if (!is_ltr) {
        options.expected_batch_size = fe_object.item_fea_size();
    } else {
        options.expected_batch_size = fe_object.prerank_item_fea_size();
    }
    phx_fe::ToExtractorResponse(fe_object, user_action, fe_configs, session, options, &extractor_response, nullptr);
}

namespace phx_fe {
    void ToExtractorResponse(const phx::FeRequest &fe_request, const phx::UserAction &user_action,
                             const ConfigInfo &fe_configs, const Session &session, const Options &options,
                             phx::ExtractorResponse *ret, std::unordered_map<std::string, Output> *inc_cache) {
        auto *arena = options.arena;
        if (unlikely(nullptr == arena)) {
            THROW_ERROR("failed, arena is nullptr");
            return;
        }

        if (!options.is_ltr) {
            if (!fe_configs.user_extras_int64_.empty() || !fe_configs.user_extras_float_.empty() ||
                !fe_configs.user_extras_bytes_.empty()) {
                THROW_ERROR("failed, non-LTR samples do not need user_extras configs");
                return;
            }
        }
        if (options.expected_batch_size == 0) {
            THROW_ERROR("expected_batch_size should > 0!");
            return;
        }
        ToExtractorResponseImpl(fe_request, user_action, fe_configs, session, options, ret, inc_cache);
        ret->set_item_cnt(options.expected_batch_size);
    }
}// namespace phx_fe

void toTraningSampleV2(google::protobuf::Arena *arena, phx::FeRequest &fe_object, phx::UserAction &user_action,
                       const ConfigInfo &fe_configs, phx::BatchTrainingSample &ret) {
    if (unlikely(nullptr == arena)) {
        THROW_ERROR("failed, arena is nullptr");
        return;
    }

    uint32_t batch_size = fe_object.item_fea_size();
    if (batch_size == 0) {
        THROW_ERROR("no item feature found!");
        return;
    }

#if FASTFLOW_OFFLINE_TIMER_ENABLE
    PointTimer ptimer("batch_size_" + std::to_string(batch_size));
#endif

    // 添加config_md5
    for (uint32_t index = 0; index < batch_size; index++) {
        ret.add_training_samples();
    }

    ret.mutable_fe_config_md5()->assign(fe_configs.md5_);

#if FASTFLOW_OFFLINE_TIMER_ENABLE
    ptimer.point("add config_md5");
#endif

    std::unordered_map<std::string, Output> cache;
    std::unordered_map<std::string, Output> empty_immutable_cache;
    generateFeMapV2(arena, fe_object, user_action, fe_configs.configs_, empty_immutable_cache, &cache, batch_size);

#if FASTFLOW_OFFLINE_TIMER_ENABLE
    ptimer.point("generateFeMap");
#endif

#if FASTFLOW_DEBUG_ENABLE
    LogDebug("cache.size():{}", cache.size());
    for (const auto &pair: cache) {
        LogDebug("cache name:{}", pair.first);
    }
#endif

    for (auto &config: fe_configs.configs_) {
        const std::string &name = config->output_;
        if (config->slot_id_ < 0) {
            LogDebug("config->slot_id_{}; skip", config->slot_id_);
            continue;
        }

        auto iter = cache.find(name);

        if (unlikely(iter == cache.end())) {
            THROW_ERROR("error happens, do not find result in cache, config->output_:" + name);
            continue;
        }

        auto &output = iter->second;

        LogDebug("output.values.size():{}", output.values.size());

        if (unlikely(output.values.empty())) {
            THROW_ERROR("config->output_ empty:" + name);
            continue;
        }

        // 只保存1个结果的提取，多个计算结果如需保存，需使用direct
        if (1 != output.values.size()) {
            LogDebug("output.values.size():{}", output.values.size());
            continue;
        }

        if (unlikely(output.values[0].ifeatures.empty())) {
            if (config->allow_empty_output_) {
                for (uint32_t i = 0; i < batch_size; i++) {
                    auto *new_feature = ret.mutable_training_samples(i)->add_features();
                    new_feature->set_slot_id(config->slot_id_);
                }
            } else {
                THROW_ERROR("config->output_ empty:" + name);
            }
            continue;
        }

        auto &value = output.values[0];
        auto &real_values = value.ifeatures;
        const uint32_t real_values_size = real_values.size();

        LogDebug("name:" + name + " real_values_size:{} batch_size:{}", real_values_size, batch_size);

        if (unlikely(real_values_size < 1)) {
            THROW_ERROR("name:" + name + " nullptr, no value");
            continue;
        }

        if (unlikely(real_values_size != 1 && real_values_size != batch_size)) {
            THROW_ERROR("real_values_size:" + std::to_string(real_values_size) +
                        ", batch_size:" + std::to_string(batch_size) + ", name:" + name);
            continue;
        }

        auto &first_hf = real_values[0];

        if (first_hf.feature) {
            if (real_values_size == batch_size) {
                for (uint32_t i = 0; i < batch_size; i++) {
                    auto &batch_hf = real_values[i];
                    if ((batch_hf.feature->bytes_list().value_size() <= 0 &&
                         batch_hf.feature->float_list().value_size() <= 0 &&
                         batch_hf.feature->int64_list().value_size() <= 0) &&
                        !config->allow_empty_output_) {
                        THROW_ERROR("output type is empty feature, name:" + name);
                        continue;
                    }
                }
                if (config->slot_id_ > 0) {
                    for (uint32_t i = 0; i < batch_size; i++) {
                        auto *training_sample = ret.mutable_training_samples(i);
                        auto *new_feature = training_sample->add_features();
                        new_feature->set_slot_id(config->slot_id_);
                        auto *real_value = const_cast<tensorflow::Feature *>(real_values[i].feature);
                        DeepCopy(real_value, new_feature);
                    }
                }
            } else {
                if ((first_hf.feature->bytes_list().value_size() <= 0 &&
                     first_hf.feature->float_list().value_size() <= 0 &&
                     first_hf.feature->int64_list().value_size() <= 0) &&
                    !config->allow_empty_output_) {
                    THROW_ERROR("output type is empty feature, name:" + name);
                    continue;
                }
                if (config->slot_id_ > 0) {
                    for (uint32_t i = 0; i < batch_size; i++) {
                        auto *new_feature = ret.mutable_training_samples(i)->add_features();
                        new_feature->set_slot_id(config->slot_id_);
                        DeepCopy(first_hf.feature, new_feature);
                        LogDebug("batch:{} Feature insert:{}", i, name);
                    }
                }
            }
        } else if (first_hf.feature_list) {
            THROW_ERROR("new sample output type featurelists not supported, name:" + name +
                        "; slot:" + std::to_string(config->slot_id_));
            continue;
        } else {
            // THROW_ERROR("output type not feature, name:" + name);
            continue;
        }

#if FASTFLOW_OFFLINE_TIMER_ENABLE
        ptimer.point("output_name_" + name);
#endif
    }

#if FASTFLOW_OFFLINE_TIMER_ENABLE
    ptimer.display();
#endif

#if FASTFLOW_DEBUG_INFO_ENABLE
    std::string json_string;
    google::protobuf::util::MessageToJsonString(ret, &json_string);
    LogInfo("toSequenceExample ------------------------------------------------------");
    LogInfo("toSequenceExample:{}", json_string);
#endif
}

void toLTRTraningSampleV2(google::protobuf::Arena *arena, phx::FeRequest &fe_object, phx::UserAction &user_action,
                          const ConfigInfo &fe_configs, phx::LTRTrainingSample &ret) {
    if (unlikely(nullptr == arena)) {
        THROW_ERROR("failed, arena is nullptr");
        return;
    }

    uint32_t batch_size = fe_object.prerank_item_fea_size();
    if (batch_size == 0) {
        THROW_ERROR("no item feature found!");
        return;
    }

#if FASTFLOW_OFFLINE_TIMER_ENABLE
    PointTimer ptimer("batch_size_" + std::to_string(batch_size));
#endif

    // 添加config_md5
    // ret.mutable_fe_config_md5()->assign(fe_configs.md5_);

#if FASTFLOW_OFFLINE_TIMER_ENABLE
    ptimer.point("add config_md5");
#endif

    std::unordered_map<std::string, Output> cache;
    std::unordered_map<std::string, Output> empty_immutable_cache;

    generateFeMapV2(arena, fe_object, user_action, fe_configs.configs_, empty_immutable_cache, &cache, batch_size);

#if FASTFLOW_OFFLINE_TIMER_ENABLE
    ptimer.point("generateFeMap");
#endif

#if FASTFLOW_DEBUG_ENABLE
    LogDebug("cache.size():{}", cache.size());
    for (const auto &pair: cache) {
        LogDebug("cache name:{}", pair.first);
    }
#endif

    std::unordered_map<std::string, std::shared_ptr<Config>> name2config;
    for (auto &config: fe_configs.configs_) {
        name2config[config->output_] = config;
        const std::string &name = config->output_;
        if (config->slot_id_ < 0) {
            LogDebug("config->slot_id_{}; skip", config->slot_id_);
            continue;
        }

        auto iter = cache.find(name);

        if (unlikely(iter == cache.end())) {
            THROW_ERROR("error happens, config->output_:" + name);
            continue;
        }

        auto &output = iter->second;

        LogDebug("output.values.size():{}", output.values.size());

        if (unlikely(output.values.empty())) {
            THROW_ERROR("config->output_ empty:" + name);
            continue;
        }

        // 只保存1个结果的提取，多个计算结果如需保存，需使用direct
        if (1 != output.values.size()) {
            LogDebug("output.values.size():{}", output.values.size());
            continue;
        }

        if (unlikely(output.values[0].ifeatures.empty())) {
            if (config->allow_empty_output_) {
                switch (config->attr_type_) {
                    case ATTR_TYPE_USER: {
                        auto *user_feature = ret.add_user_features();
                        user_feature->set_slot_id(config->slot_id_);
                        break;
                    }
                    case ATTR_TYPE_ITEM:
                    case ATTR_TYPE_CROSS: {
                        auto *item_feature = ret.add_item_features();
                        item_feature->set_slot_id(config->slot_id_);
                        for (uint32_t i = 0; i < batch_size; i++) {
                            auto *new_feature = item_feature->add_features();
                            new_feature->set_slot_id(config->slot_id_);
                        }
                        break;
                    }
                    default: {
                        THROW_ERROR("config attr_type not define, name:" + name);
                        break;
                    }
                }
            } else {
                THROW_ERROR("config->output_ empty:" + name);
            }
            continue;
        }

        auto &value = output.values[0];
        auto &real_values = value.ifeatures;
        const uint32_t real_values_size = real_values.size();

        LogDebug("name:" + name + " real_values_size:{} batch_size:{}", real_values_size, batch_size);

        if (unlikely(real_values_size < 1)) {
            THROW_ERROR("name:" + name + " nullptr, no value");
            continue;
        }

        if (unlikely(real_values_size != 1 && real_values_size != batch_size)) {
            THROW_ERROR("real_values_size:" + std::to_string(real_values_size) +
                        ", batch_size:" + std::to_string(batch_size) + ", name:" + name);
            continue;
        }

        auto &first_hf = real_values[0];

        if (first_hf.feature) {
            if (real_values_size == batch_size) {
                for (uint32_t i = 0; i < batch_size; i++) {
                    auto &batch_hf = real_values[i];
                    if ((batch_hf.feature->bytes_list().value_size() <= 0 &&
                         batch_hf.feature->float_list().value_size() <= 0 &&
                         batch_hf.feature->int64_list().value_size() <= 0) &&
                        !config->allow_empty_output_) {
                        THROW_ERROR("output type is empty feature, name:" + name);
                        continue;
                    }
                }
                if (config->slot_id_ > 0) {
                    switch (config->attr_type_) {
                        case ATTR_TYPE_USER: {
                            if (unlikely(real_values_size != 1)) {
                                THROW_ERROR("config attr_type is user, but real is item, name:" + name);
                            }
                            auto *user_feature = ret.add_user_features();
                            user_feature->set_slot_id(config->slot_id_);
                            DeepCopy(first_hf.feature, user_feature);
                            break;
                        }
                        case ATTR_TYPE_ITEM:
                        case ATTR_TYPE_CROSS: {
                            auto *item_feature = ret.add_item_features();
                            item_feature->set_slot_id(config->slot_id_);
                            for (uint32_t i = 0; i < batch_size; i++) {
                                auto *new_feature = item_feature->add_features();
                                new_feature->set_slot_id(config->slot_id_);
                                DeepCopy(real_values[i].feature, new_feature);
                            }
                            break;
                        }
                        default: {
                            THROW_ERROR("config attr_type not define, name:" + name);
                            break;
                        }
                    }
                }
            } else {
                if ((first_hf.feature->bytes_list().value_size() <= 0 &&
                     first_hf.feature->float_list().value_size() <= 0 &&
                     first_hf.feature->int64_list().value_size() <= 0) &&
                    !config->allow_empty_output_) {
                    THROW_ERROR("output type is empty feature, name:" + name);
                    continue;
                }
                if (config->slot_id_ > 0) {
                    switch (config->attr_type_) {
                        case ATTR_TYPE_USER: {
                            auto *user_feature = ret.add_user_features();
                            user_feature->set_slot_id(config->slot_id_);
                            DeepCopy(first_hf.feature, user_feature);
                            break;
                        }
                        case ATTR_TYPE_ITEM:
                        case ATTR_TYPE_CROSS: {
                            THROW_ERROR("config attr_type is item or cross, but real is user, name:" + name);
                            break;
                        }
                        default: {
                            THROW_ERROR("config attr_type not define, name:" + name);
                            break;
                        }
                    }
                }
            }
        } else if (first_hf.feature_list) {
            THROW_ERROR("new sample output type featurelists not supported, name:" + name +
                        "; slot:" + std::to_string(config->slot_id_));
            continue;
        } else {
            THROW_ERROR("output type not feature, name:" + name);
            continue;
        }

#if FASTFLOW_OFFLINE_TIMER_ENABLE
        ptimer.point("output_name_" + name);
#endif
    }

#if FASTFLOW_OFFLINE_TIMER_ENABLE
    ptimer.display();
#endif

#if FASTFLOW_DEBUG_INFO_ENABLE
    std::string json_string;
    google::protobuf::util::MessageToJsonString(ret, &json_string);
    LogInfo("toSequenceExample ------------------------------------------------------");
    LogInfo("toSequenceExample:{}", json_string);
#endif
}
std::vector<std::shared_ptr<Config>>
SelectModelInputConfig(const std::vector<std::shared_ptr<Config>> &all_configs,
                       const std::unordered_map<int64_t, std::shared_ptr<Config>> &all_slot2config,
                       const std::unordered_map<std::string, std::shared_ptr<Config>> &all_name2config,
                       const std::unordered_set<int64_t> &model_slot_ids) {
    std::vector<std::shared_ptr<Config>> selected_configs;
    selected_configs.reserve(model_slot_ids.size());
    std::queue<const std::string *> queue;
    std::unordered_set<std::string> filter_set;
    for (int64_t slot_id: model_slot_ids) {
        auto iter = all_slot2config.find(slot_id);
        if (iter == all_slot2config.end()) {
            THROW_ERROR("config not find, model input config slot id = :" + std::to_string(slot_id));
            return selected_configs;
        } else {
            queue.push(&iter->second->output_);
        }
    }
    while (!queue.empty()) {
        const std::string &name = *queue.front();
        queue.pop();
        auto iter = all_name2config.find(name);
        //检测set中是否已有对应的config_name，避免重复加载相同的input
        auto set_iter = filter_set.find(name);
        if (iter != all_name2config.end() && set_iter == filter_set.end()) {
            auto &config = iter->second;
            for (Input &input: config->inputs_) {
                if (!input.name_parts.empty()) {
                    queue.push(&input.name_parts[0]);
                }
            }
            filter_set.insert(name);
        }
    }
    for (auto &config: all_configs) {
        if (filter_set.find(config->output_) != filter_set.end()) {
            selected_configs.emplace_back(config);
        }
    }

    return selected_configs;
}
std::shared_ptr<ConfigInfo> GenerateConfigInfoFromModelInputs(const ConfigInfo &full_config_info,
                                                              const std::unordered_set<int64_t> &model_slot_ids) {
    const auto &all_configs = full_config_info.configs_;
    std::unordered_map<int64_t, std::shared_ptr<Config>> all_slot2config;
    std::unordered_map<std::string, std::shared_ptr<Config>> all_name2config;
    std::unordered_set<std::string> filter_set;
    for (auto &config: all_configs) {
        all_slot2config[config->slot_id_] = config;
        all_name2config[config->output_] = config;
    }
    auto config_info = std::shared_ptr<ConfigInfo>(new ConfigInfo());

    for (int64_t slot_id: model_slot_ids) {
        auto iter = all_slot2config.find(slot_id);
        if (iter == all_slot2config.end()) {
            THROW_ERROR("config not find, model input config slot id = :" + std::to_string(slot_id));
            return nullptr;
        }
        switch (iter->second->attr_type_) {
            case (ATTR_TYPE_USER): {
                config_info->model_input_user_slots_.insert(slot_id);
                break;
            }
            case (ATTR_TYPE_ITEM):
            case (ATTR_TYPE_CROSS): {
                config_info->model_input_item_or_cross_slots_.insert(slot_id);
                break;
            }
            default: {
                THROW_ERROR("not known attr_type, slot_id:" + std::to_string(slot_id));
                break;
            }
        }
    }
    // 全量slot
    config_info->configs_ = SelectModelInputConfig(all_configs, all_slot2config, all_name2config, model_slot_ids);
    // 挑选user slot和其依赖的特征算子
    config_info->user_configs_ =
            SelectModelInputConfig(all_configs, all_slot2config, all_name2config, config_info->model_input_user_slots_);
    // 挑选item/user算子和其依赖的特征算子
    config_info->item_or_cross_configs_ = SelectModelInputConfig(all_configs, all_slot2config, all_name2config,
                                                                 config_info->model_input_item_or_cross_slots_);
    config_info->dict_collector_ = full_config_info.dict_collector_;
    config_info->model_input_slots_ = model_slot_ids;
    return config_info;
}

uint32_t elementsNum(const tensorflow::DataType dtype, const std::vector<InputFeature> &ifeatures,
                     const std::string &input_name, uint32_t &max) {
    uint32_t temp;
    uint32_t sum = 0;

    max = 0;

    switch (dtype) {
        case tensorflow::DT_FLOAT: {
            for (auto &inf: ifeatures) {
                if (unlikely(!inf.feature)) {
                    THROW_ERROR("no feature, input_name:" + input_name);
                    return 0;
                }
                temp = inf.feature->float_list().value().size();
                sum += temp;
                if (temp > max) {
                    max = temp;
                }
            }
        } break;

        case tensorflow::DT_INT32: {
            for (auto &inf: ifeatures) {
                if (unlikely(!inf.feature)) {
                    THROW_ERROR("no feature, input_name:" + input_name);
                    return 0;
                }
                temp = inf.feature->int64_list().value().size();
                sum += temp;
                if (temp > max) {
                    max = temp;
                }
            }
        } break;

        case tensorflow::DT_INT64: {
            for (auto &inf: ifeatures) {
                if (unlikely(!inf.feature)) {
                    THROW_ERROR("no feature, input_name:" + input_name);
                    return 0;
                }
                temp = inf.feature->int64_list().value().size();
                sum += temp;
                if (temp > max) {
                    max = temp;
                }
            }
        } break;

        case tensorflow::DT_STRING: {
            for (auto &inf: ifeatures) {
                if (unlikely(!inf.feature)) {
                    THROW_ERROR("no feature, input_name:" + input_name);
                    return 0;
                }
                temp = inf.feature->bytes_list().value().size();
                sum += temp;
                if (temp > max) {
                    max = temp;
                }
            }
        } break;

        default: {
            THROW_ERROR("invalid dtype:" + std::to_string(dtype) + ", input_name:" + input_name);
            return 0;
        } break;
    }

    return sum;
}

void fillEmptySequenceTensor(tensorflow::TensorProto &tensor, const uint32_t batch_size, const int32_t dim,
                             int32_t *len_tensor_ptr) {
    tensor.mutable_tensor_shape()->add_dim()->set_size(0);
    tensor.mutable_tensor_shape()->add_dim()->set_size(dim);

    if (len_tensor_ptr) {
        for (uint32_t b = 0; b < batch_size; b++) {
            len_tensor_ptr[b] = 0;
        }
    }
}

void get_auto_type(const Output &value, tensorflow::DataType &tf_dtype) {
    if (unlikely(value.values.empty())) {
        return;
    }

    const std::vector<InputFeature> &values = value.values[0].ifeatures;
    if (unlikely(values.empty())) {
        return;
    }

    const tensorflow::Feature *feature = nullptr;

    if (values[0].feature) {
        feature = values[0].feature;
    } else if (values[0].feature_list && values[0].feature_list->feature_size() > 0) {
        feature = &values[0].feature_list->feature(0);
    }

    if (likely(feature)) {
        if (feature->float_list().value_size() > 0) {
            tf_dtype = tensorflow::DT_FLOAT;
        } else if (feature->int64_list().value_size() > 0 && tf_dtype != tensorflow::DT_INT32) {
            tf_dtype = tensorflow::DT_INT64;
        } else if (feature->bytes_list().value_size() > 0) {
            tf_dtype = tensorflow::DT_STRING;
        }
    }
}
void fill_extra_feature(const std::vector<std::string> &feature_name_list,
                        const std::unordered_map<std::string, std::shared_ptr<Config>> &name2config,
                        const std::unordered_map<std::string, Output> &cache, phx::ExtractorResponse &ret,
                        const uint32_t batch_size, AddExtraFeatureFunc add_extra_feature, bool is_ltr,
                        bool is_user_fea) {
    for (const auto &name: feature_name_list) {
        auto iter = cache.find(name);
        auto type_iter = name2config.find(name);

        if (unlikely(iter == cache.end() || type_iter == name2config.end())) {
            THROW_ERROR("error happens, config->output_:" + name);
            continue;
        }

        if (is_user_fea && type_iter->second->attr_type_ != ATTR_TYPE_USER) {
            THROW_ERROR("expect user feature, but config attr_type is item/cross: " + name);
            continue;
        }

        if (!is_user_fea && type_iter->second->attr_type_ == ATTR_TYPE_USER && is_ltr) {
            THROW_ERROR("expect item/cross feature, but config attr_type is user: " + name);
            continue;
        }

        auto &output = iter->second;

        LogDebug("output.values.size():{}", output.values.size());

        if (unlikely(output.values.empty())) {
            THROW_ERROR("config->output_ empty:" + name);
            continue;
        }

        // 只保存1个结果的提取，多个计算结果如需保存，需使用direct
        if (1 != output.values.size()) {
            LogDebug("output.values.size():{}", output.values.size());
            continue;
        }

        if (unlikely(output.values[0].ifeatures.empty())) {
            if (output.allow_empty_output) {
                switch (type_iter->second->attr_type_) {
                    case ATTR_TYPE_USER: {
                        if (is_ltr) {
                            auto *extra_feature = (ret.*add_extra_feature)();
                            extra_feature->set_name(name);
                        } else {
                            // 非LTR样本，传入是user特征，也需要复制batch份
                            for (uint32_t i = 0; i < batch_size; i++) {
                                auto *extra_feature = (ret.*add_extra_feature)();
                                extra_feature->set_name(name);
                            }
                        }
                        break;
                    }
                    case ATTR_TYPE_ITEM:
                    case ATTR_TYPE_CROSS: {
                        for (uint32_t i = 0; i < batch_size; i++) {
                            auto *extra_feature = (ret.*add_extra_feature)();
                            extra_feature->set_name(name);
                        }
                        break;
                    }
                    default: {
                        THROW_ERROR("config attr_type not define, name:" + name);
                        break;
                    }
                }
            } else {
                THROW_ERROR("config->output_ empty:" + name);
            }
            continue;
        }

        auto &value = output.values[0];
        auto &real_values = value.ifeatures;
        const uint32_t real_values_size = real_values.size();

        LogDebug("name:" + name + " real_values_size:{} batch_size:{}", real_values_size, batch_size);

        if (unlikely(real_values_size < 1)) {
            THROW_ERROR("name:" + name + " nullptr, no value");
            continue;
        }

        if (unlikely(real_values_size != 1 && real_values_size != batch_size)) {
            THROW_ERROR("real_values_size:" + std::to_string(real_values_size) +
                        ", batch_size:" + std::to_string(batch_size) + ", name:" + name);
            continue;
        }

        auto &first_hf = real_values[0];

        if (first_hf.feature) {
            if ((first_hf.feature->bytes_list().value_size() <= 0 && first_hf.feature->float_list().value_size() <= 0 &&
                 first_hf.feature->int64_list().value_size() <= 0) &&
                !output.allow_empty_output) {
                THROW_ERROR("output type is empty feature, name:" + name);
                continue;
            }
            if (real_values_size == batch_size) {
                switch (type_iter->second->attr_type_) {
                    case ATTR_TYPE_USER: {
                        if (unlikely(real_values_size != 1)) {
                            THROW_ERROR("config attr_type is user, but real is item, name:" + name);
                        }
                        auto *extra_feature = (ret.*add_extra_feature)();
                        extra_feature->set_name(name);
                        DeepCopy(first_hf.feature, extra_feature->mutable_feature());
                        break;
                    }
                    case ATTR_TYPE_ITEM:
                    case ATTR_TYPE_CROSS: {
                        for (uint32_t i = 0; i < batch_size; i++) {
                            auto *extra_feature = (ret.*add_extra_feature)();
                            extra_feature->set_name(name);
                            DeepCopy(real_values[i].feature, extra_feature->mutable_feature());
                        }
                        break;
                    }
                    default: {
                        THROW_ERROR("config attr_type not define, name:" + name);
                        break;
                    }
                }
            } else {
                switch (type_iter->second->attr_type_) {
                    case ATTR_TYPE_USER: {
                        if (is_ltr) {
                            auto *extra_feature = (ret.*add_extra_feature)();
                            extra_feature->set_name(name);
                            DeepCopy(first_hf.feature, extra_feature->mutable_feature());
                        } else {
                            // 非LTR样本，传入是user特征，也需要复制batch份
                            for (uint32_t i = 0; i < batch_size; i++) {
                                auto *extra_feature = (ret.*add_extra_feature)();
                                extra_feature->set_name(name);
                                DeepCopy(first_hf.feature, extra_feature->mutable_feature());
                            }
                        }
                        break;
                    }
                    case ATTR_TYPE_ITEM:
                    case ATTR_TYPE_CROSS: {
                        THROW_ERROR("config attr_type is item or cross, but real is user, name:" + name);
                        break;
                    }
                    default: {
                        THROW_ERROR("config attr_type not define, name:" + name);
                        break;
                    }
                }
            }
        } else if (first_hf.feature_list) {
            THROW_ERROR("new sample output type featurelists not supported, name:" + name);
            continue;
        } else {
            THROW_ERROR("output type not feature, name:" + name);
            continue;
        }
    }
}
