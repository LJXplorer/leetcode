#pragma once

#include "phx-fe/util/util.h"
#include <string>
#include <unordered_map>
#include <unordered_set>
namespace phx_fe {
    using ConfigsGetter = std::function<const std::vector<std::shared_ptr<Config>> &(const ConfigInfo &)>;
    using ModelSlotsGetter = std::function<const std::unordered_set<int64_t> &(const ConfigInfo &)>;
    inline const std::vector<std::shared_ptr<Config>> &DefaultConfigsGetter(const ConfigInfo &config) {
        return config.configs_;
    }

    inline const std::vector<std::shared_ptr<Config>> &UserConfigsGetter(const ConfigInfo &config) {
        return config.user_configs_;
    }

    inline const std::vector<std::shared_ptr<Config>> &ItemConfigsGetter(const ConfigInfo &config) {
        return config.item_or_cross_configs_;
    }
    inline const std::unordered_set<int64_t> &DefaultModelSlotsGetter(const ConfigInfo &config) {
        return config.model_input_slots_;
    }

    inline const std::unordered_set<int64_t> &UserModelSlotsGetter(const ConfigInfo &config) {
        return config.model_input_user_slots_;
    }
    inline const std::unordered_set<int64_t> &ItemModelSlotsGetter(const ConfigInfo &config) {
        return config.model_input_item_or_cross_slots_;
    }

    /**
    * @brief 特征抽取会话类
    * 
    * 用于维护特征抽取过程中的会话状态和数据缓存。
    * 通过缓存机制优化重复特征抽取的性能。
    */
    struct Session {
        std::unordered_map<std::string, Output> cache;
    };

    struct Options {
        /**
        * @brief 预期抽取的批处理大小
        * 
        * - 对于用户特征：通常为1（单个用户）
        * - 对于物品特征：批处理中的物品数量
        * 
        * @default 1
        */
        size_t expected_batch_size = 1;
        /**
        * @brief 算子的获取函数
        * 
        * 用于提供算子的函数指针。
        * 默认使用 DefaultConfigsGetter 获取所有算子配置。
        * 
        * @see DefaultConfigsGetter
        */
        ConfigsGetter configs_supplier = DefaultConfigsGetter;

        ModelSlotsGetter model_slots_getter = DefaultModelSlotsGetter;
        /**
        * @brief 算子输入输出的内存分配器
        * 
        * 指向 protobuf Arena 的指针，用于在特征抽取过程中
        * 管理算子输入输出的内存分配。
        * 
        */
        google::protobuf::Arena *arena;

        /**
        * @brief 是否为ltr场景
        * 
        */
        bool is_ltr = false;
    };
}// namespace phx_fe