#ifndef FE_FRAMEWORK
#define FE_FRAMEWORK

#include "fe_request.pb.h"
#include "phx-fe/config/config.h"
#include "phx-fe/src/session.h"
#include "phx-fe/util/util.h"
#include "user_action.pb.h"

using AddExtraFeatureFunc = phx::ExtraFeature *(phx::ExtractorResponse::*) ();

void ToExtractorResponseImpl(const phx::FeRequest &fe_request, const phx::UserAction &user_action,
                             const ConfigInfo &fe_configs, const phx_fe::Session &session, const phx_fe::Options &options,
                             phx::ExtractorResponse *ret, std::unordered_map<std::string, Output>* inc_cache_output);
void toExtractorResponse(google::protobuf::Arena *arena, phx::FeRequest &fe_object, phx::UserAction &user_action,
                       const ConfigInfo &fe_configs, phx::ExtractorResponse &ret, bool is_ltr);

void toTraningSampleV2(google::protobuf::Arena *arena, phx::FeRequest &fe_object, phx::UserAction &user_action,
                       const ConfigInfo &fe_configs, phx::BatchTrainingSample &ret);

void toLTRTraningSampleV2(google::protobuf::Arena *arena, phx::FeRequest &fe_object, phx::UserAction &user_action,
                          const ConfigInfo &fe_configs, phx::LTRTrainingSample &ret);

void getInputsResultV2(google::protobuf::Arena *arena, const phx::FeRequest &fe_request,
                       const phx::UserAction &user_action, const std::vector<Input> &inputs,
                       std::unordered_map<std::string, Output> &cache,
                       std::unordered_map<std::string, Output> &inc_cache, std::vector<const Output *> &ret);

std::shared_ptr<ConfigInfo> GenerateConfigInfoFromModelInputs(const ConfigInfo &full_config_info,
                                                              const std::unordered_set<int64_t> &model_slot_ids);

std::vector<std::shared_ptr<Config>>
SelectModelInputConfig(const std::vector<std::shared_ptr<Config>> &all_configs,
                       const std::unordered_map<int64_t, std::shared_ptr<Config>> &all_slot2config,
                       const std::unordered_map<std::string, std::shared_ptr<Config>> &all_name2config,
                       const std::unordered_set<int64_t> &model_slot_ids);

void GenerateOutputFromRequest(const phx::FeRequest &fe_request, const phx::UserAction &user_action, const Input &input,
                               Output &output);

void fill_extra_feature(const std::vector<std::string> &feature_name_list,
                        const std::unordered_map<std::string, std::shared_ptr<Config>> &name2config,
                        const std::unordered_map<std::string, Output> &cache, phx::ExtractorResponse &ret,
                        const uint32_t batch_size, AddExtraFeatureFunc add_extra_feature_func, bool is_ltr,
                        bool is_user_fea = false);

namespace phx_fe {
    void ToExtractorResponse(const phx::FeRequest &fe_request, const phx::UserAction &user_action,
                             const ConfigInfo &fe_configs, const Session &session, const Options &options,
                             phx::ExtractorResponse *ret, std::unordered_map<std::string, Output>* inc_cache);
}

#endif// FE_FRAMEWORK