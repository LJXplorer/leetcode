#!/bin/bash

if [ -z "$1" ]; then
  echo "请传入target名称，例如：phx_test_seq"
  exit 1
fi

TARGET_NAME=$1
FULL_TARGET="//test:$TARGET_NAME"

rm core.*17*
bazel build $FULL_TARGET
cp -f bazel-bin/test/$TARGET_NAME $TARGET_NAME
./$TARGET_NAME