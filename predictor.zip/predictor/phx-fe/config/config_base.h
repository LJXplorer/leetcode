#ifndef FE_CONFIG_BASE
#define FE_CONFIG_BASE

#include "config.h"
#include "phx-fe/util/item_class.h"
#include "phx-fe/util/invisible_character.h"

// 分桶
class BucketizedConfig : public OneInputConfig {
 public:
  std::vector<float> boundaries_;

  explicit BucketizedConfig(const std::string& output,
                            const std::vector<std::string>& source,
                            DefaultValue& default_input_value,
                            bool save,
                            bool allow_empty_output,
                            const std::vector<std::string>& strategy,
                            const std::vector<float>& boundaries)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy), boundaries_(boundaries) {}
  virtual ~BucketizedConfig() {}

  virtual std::string get_config() override {
    std::string display = "bucketize:boundaries:[";
    for (auto& f : boundaries_) {
      display.append(std::to_string(f)).append(",");
    }
    display.pop_back();
    display.append("]");
    return display;
  }

 private:
  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_INT64;
  }

  template<typename T>
  inline int64_t bucketized_bound(const T value, const std::vector<float>& boundary) {
    auto first_bigger_it = std::upper_bound(boundary.begin(), boundary.end(), value);
    return first_bigger_it - boundary.begin();
  }
};

// 查询在字典中的索引
class VocabListConfig : public OneInputConfig {
 public:
  std::map<std::string, uint64_t> vocab_map_;

  explicit VocabListConfig(const std::string& output,
                            const std::vector<std::string>& source,
                            DefaultValue& default_input_value,
                            bool save,
                            bool allow_empty_output,
                            const std::vector<std::string>& strategy,
                            const std::vector<std::string>& vocab_list)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy) {
    for (uint64_t i = 0; i < vocab_list.size(); i++) {
      vocab_map_[vocab_list[i]] = i;
    }
  }

  virtual ~VocabListConfig() {}

  virtual std::string get_config() override {
    std::string display = "vocab_list:vocab_map:[";
    for (auto& pair : vocab_map_) {
      display.append("[").append(pair.first).append(",").append(std::to_string(pair.second)).append("]").append(",");
    }
    display.pop_back();
    display.append("]");
    return display;
  }

 private:
  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_INT64;
  }
};

// 查字符串词典,查到返回查找的字符串，未查到返回空字符串
class VocabSetConfig : public OneInputConfig {
 public:
  explicit VocabSetConfig(const std::string& output,
                          const std::vector<std::string>& source,
                          DefaultValue& default_input_value,
                          bool save,
                          bool allow_empty_output,
                          const std::vector<std::string>& strategy,
                          const std::vector<std::string>& vec_dict,
                          std::shared_ptr<std::unordered_set<std::string>>& dict)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
        vec_dict_(vec_dict), dict_(dict) {}
  virtual ~VocabSetConfig() {}

  virtual std::string get_config() override {
    std::string display = "vocab_set:dict:[";
    for (auto& str : vec_dict_) {
      display.append(str).append(",");;
    }
    display.pop_back();
    display.append("]");
    return display;
  }

 private:
  std::vector<std::string> vec_dict_;                       //词典配置路径或信息
  std::shared_ptr<std::unordered_set<std::string>> dict_;   //词典
  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_STRING;
  }
};

// 查key(字符串)-value(int或float)词典,查到返回value,未查到返回-1.0或-1或空字符串(根据value的数据类型决定)
template<typename T>
class VocabMapConfig : public OneInputConfig {
 public:
  explicit VocabMapConfig(const std::string& output,
                          const std::vector<std::string>& source,
                          DefaultValue& default_input_value,
                          bool save,
                          bool allow_empty_output,
                          const std::vector<std::string>& strategy,
                          const std::string& dtype,
                          const std::vector<std::string>& vec_dict,
                          std::shared_ptr<std::unordered_map<std::string, T>>& dict)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
        dtype_(dtype), vec_dict_(vec_dict), dict_(dict) {}
  virtual ~VocabMapConfig() {}

  virtual std::string get_config() override {
    std::string display = "vocab_map:";
    display.append("dtype:").append(dtype_).append(", dict:[");
    for (auto& str : vec_dict_) {
      display.append(str).append(",");;
    }
    display.pop_back();
    display.append("]");

    return display;
  }

 private:
  std::string dtype_;                                         //数据类型，float,int64,string三者之一
  std::vector<std::string> vec_dict_;                         //词典配置路径或信息
  std::shared_ptr<std::unordered_map<std::string, T>> dict_;  //词典
  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override;
};

//  精确匹配appname，如果查到返回appname，没找到返回默认值
class IsMatchStrConfig : public OneInputConfig {
 public:
  explicit IsMatchStrConfig(const std::string& output,
                            const std::vector<std::string>& source,
                            DefaultValue& default_input_value,
                            bool save,
                            bool allow_empty_output,
                            const std::vector<std::string>& strategy,
                            std::shared_ptr<std::unordered_map<std::string, AllClasses>>& dict,
                            const std::string& default_value)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
        dict_(dict), default_value_(default_value) {}
  virtual ~IsMatchStrConfig() {}

  virtual std::string get_config() override {
    std::string display = "is_match_str:default_value:";
    display.append(default_value_);
    return display;
  }

 private:
  std::shared_ptr<std::unordered_map<std::string, AllClasses>> dict_;
  std::string default_value_; //默认值

  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_STRING;
  }
};

// 过滤指定天数的数据
class FilterAppIdConfig : public Config {
 public:
  std::vector<int32_t> days_;
  int32_t max_len_;
  std::string default_value_;

  explicit FilterAppIdConfig(const std::string& output,
                              const std::vector<std::string>& source,
                              DefaultValue& default_input_value,
                              bool save,
                              bool allow_empty_output,
                              const std::vector<std::string>& strategy,
                              const std::vector<int32_t>& days,
                              int32_t max_len,
                              const std::string& default_value)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy),
        days_(days), max_len_(max_len), default_value_(default_value) {}
  virtual ~FilterAppIdConfig() {}

  virtual std::string get_config() override {
    std::string display = "filter_appid:days:[";
    for (auto& l : days_) {
      display.append(std::to_string(l)).append(",");
    }
    display.pop_back();
    display.append("], max_len:").append(std::to_string(max_len_)).append(", default_value:").append(default_value_);
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
 private:
  static bool compareAppIdWithEventTime(const AppIdWithEventTime& info1, const AppIdWithEventTime& info2) {
    return info1.eventtime > info2.eventtime;
  }

  void fill_vec(const tensorflow::Feature& appid_feat,
                const tensorflow::Feature& time_feat,
                std::vector<AppIdWithEventTime>& info_vec);

  void compute_vec(std::vector<AppIdWithEventTime>& info_vec);
};

// 出现次数最多
class MaxExpoAppidConfig : public Config {
 public:
  explicit MaxExpoAppidConfig(const std::string& output,
                              const std::vector<std::string>& source,
                              DefaultValue& default_input_value,
                              bool save,
                              bool allow_empty_output,
                              const std::vector<std::string>& strategy)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy) {}
  virtual ~MaxExpoAppidConfig() {}

  virtual std::string get_config() override {
    return "max_expo_appid";
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
};

class NearestExpoAppidConfig : public Config {
 public:
  explicit NearestExpoAppidConfig(const std::string& output,
                                  const std::vector<std::string>& source,
                                  DefaultValue& default_input_value,
                                  bool save,
                                  bool allow_empty_output,
                                  const std::vector<std::string>& strategy)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy) {}
  virtual ~NearestExpoAppidConfig() {}

  virtual std::string get_config() override {
    return "nearest_expo_appid";
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
};

// 出现次数
class ExpoAppidCountConfig : public Config {
 public:
  explicit ExpoAppidCountConfig(const std::string& output,
                                const std::vector<std::string>& source,
                                DefaultValue& default_input_value,
                                bool save,
                                bool allow_empty_output,
                                const std::vector<std::string>& strategy)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy) {}
  virtual ~ExpoAppidCountConfig() {}

  virtual std::string get_config() override {
    return "expo_appid_count";
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
private:
  void compute_one_feature(const tensorflow::Feature& feat,
                            std::map<std::string, int32_t>& occur_map,
                            tensorflow::Feature* out);
};

// 最近一次曝光距离当前天数int(2*log(day + 1))
class NearestExpoDaysConfig : public Config {
 public:
  explicit NearestExpoDaysConfig(const std::string& output,
                                  const std::vector<std::string>& source,
                                  DefaultValue& default_input_value,
                                  bool save,
                                  bool allow_empty_output,
                                  const std::vector<std::string>& strategy)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy) {}
  virtual ~NearestExpoDaysConfig() {}

  virtual std::string get_config() override {
    return "nearest_expo_days";
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
 private:
  void comput_one_input(const tensorflow::Feature& appid_feat,
                        const tensorflow::Feature& time_feat,
                        std::map<std::string, int64_t>& time_map);
  void compute_one_feature(const tensorflow::Feature& feat,
                            int64_t now,
                            std::map<std::string, int64_t>& time_map,
                            tensorflow::Feature* out);
};

// 三级类目展现的最大次数
class Max123ClassConfig : public Config {
 public:
  std::shared_ptr<std::unordered_map<std::string, AllClasses>> dict_;
  explicit Max123ClassConfig(const std::string& output,
                              const std::vector<std::string>& source,
                              DefaultValue& default_input_value,
                              bool save,
                              bool allow_empty_output,
                              const std::vector<std::string>& strategy,
                              std::shared_ptr<std::unordered_map<std::string, AllClasses>>& dict)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), dict_(dict) {}
  virtual ~Max123ClassConfig() {}

  virtual std::string get_config() override {
    return "max_123_class";
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
};

// 三级类目累计的次数
class Expo123CountConfig : public Config {
 public:
  std::shared_ptr<std::unordered_map<std::string, AllClasses>> dict_;

  explicit Expo123CountConfig(const std::string& output,
                              const std::vector<std::string>& source,
                              DefaultValue& default_input_value,
                              bool save,
                              bool allow_empty_output,
                              const std::vector<std::string>& strategy,
                              std::shared_ptr<std::unordered_map<std::string, AllClasses>>& dict)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), dict_(dict) {}
  virtual ~Expo123CountConfig() {}

  virtual std::string get_config() override {
    return "expo_123_count";
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  void compute_one_feature(const tensorflow::Feature& feat,
                            std::vector<std::map<std::string, uint32_t>>& class_count,
                            std::vector<tensorflow::Feature*>& out_int_feat);
};

// 三级类目是否访问和访问累计的次数
class Expo123CountV2Config : public Config {
 public:
  std::shared_ptr<std::unordered_map<std::string, AllClasses>> dict_;

  explicit Expo123CountV2Config(const std::string& output,
                                const std::vector<std::string>& source,
                                DefaultValue& default_input_value,
                                bool save,
                                bool allow_empty_output,
                                const std::vector<std::string>& strategy,
                                std::shared_ptr<std::unordered_map<std::string, AllClasses>>& dict)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), dict_(dict) {}
  virtual ~Expo123CountV2Config() {}

  virtual std::string get_config() override {
    return "expo_123_count_v2";
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  void compute_one_feature(const tensorflow::Feature& feat,
                            std::vector<std::map<std::string, uint32_t>>& class_count,
                            std::vector<tensorflow::Feature*>& out_bool_feat,
                            std::vector<tensorflow::Feature*>& out_int_feat);
};

// 交叉后哈希
class AppidCrossConfig : public Config {
 public:
  int64_t bucket_size_;

  explicit AppidCrossConfig(const std::string& output,
                            const std::vector<std::string>& source,
                            DefaultValue& default_input_value,
                            bool save,
                            bool allow_empty_output,
                            const std::vector<std::string>& strategy,
                            int64_t bucket_size)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy),
        bucket_size_(bucket_size) {}

  virtual ~AppidCrossConfig() {}

  virtual std::string get_config() override {
    return "appid_cross:bucket_size:" + std::to_string(bucket_size_);
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
 private:
  void compute_one_ifeature(google::protobuf::Arena* arena, const std::vector<std::string>& vec, const InputFeature* hf_item, InputFeature* hf_out);
  void fill_ifeature_to_vec(const InputFeature* hf, std::vector<std::string>& vec);
  void fill_feature_to_vec(const tensorflow::Feature& feat, std::vector<std::string>& vec);
  void compute_one_feature(const std::vector<std::string>& vec, const tensorflow::Feature& item_feat, tensorflow::FeatureList* hf_out_featurelist);
};

// 将feature list 合并为1个feature
class ToFeatureConfig : public Config {
 public:
  explicit ToFeatureConfig(const std::string& output,
                            const std::vector<std::string>& source,
                            DefaultValue& default_input_value,
                            bool save,
                            bool allow_empty_output,
                            const std::vector<std::string>& strategy)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy) {}
  virtual ~ToFeatureConfig() {}

  virtual std::string get_config() override {
    return "to_feature";
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override; 

 private:
  FeatureStrategy strategy_;
};

// 将feature_list转换为batch个feature
class ToBatchFeatureConfig : public Config {
 public:
  explicit ToBatchFeatureConfig(const std::string& output,
                                const std::vector<std::string>& source,
                                DefaultValue& default_input_value,
                                bool save,
                                bool allow_empty_output,
                                const std::vector<std::string>& strategy)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy) {}
  virtual ~ToBatchFeatureConfig() {}

  virtual std::string get_config() override {
    return "to_batch_feature";
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
};

// 输入在[0, max_value_]直接输出，不在上述区间输出default_value_
class IdentityConfig : public OneInputConfig {
 public:
  int64_t max_value_;
  int64_t default_value_;

  explicit IdentityConfig(const std::string& output,
                          const std::vector<std::string>& source,
                          DefaultValue& default_input_value,
                          bool save,
                          bool allow_empty_output,
                          const std::vector<std::string>& strategy,
                          int64_t max_value,
                          int64_t default_value)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
        max_value_(max_value), default_value_(default_value) {}
  virtual ~IdentityConfig() {}

  virtual std::string get_config() override {
    return "identity:max_value:" + std::to_string(max_value_) + ", default_value:" + std::to_string(default_value_);
  }

 private:
  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_INT64;
  }
};

//输入string，如果为空或者无法转换int64，返回默认值，否则正常返回转换后的int64
class StringToInt64Config : public OneInputConfig {
 public:
  //int64默认值
  int64_t default_value_;

  explicit StringToInt64Config(const std::string& output,
                                const std::vector<std::string>& source,
                                DefaultValue& default_input_value,
                                bool save,
                                bool allow_empty_output,
                                const std::vector<std::string>& strategy,
                                int64_t default_value)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy), default_value_(default_value) {}
  virtual ~StringToInt64Config() {}

  virtual std::string get_config() override {
    return "string_to_int64:default_value:" + std::to_string(default_value_);
  }

 private:
  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_INT64;
  }
};

//id转换成对应type的Class名字
class AppidTo123ClassConfig : public OneInputConfig {
 public:
  explicit AppidTo123ClassConfig(const std::string& output,
                                const std::vector<std::string>& source,
                                DefaultValue& default_input_value,
                                bool save,
                                bool allow_empty_output,
                                const std::vector<std::string>& strategy,
                                std::shared_ptr<std::unordered_map<std::string, AllClasses>>& dict,
                                Class123Type class_type,
                                const std::string& default_value)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
        dict_(dict), class_type_(class_type), default_value_(default_value) {}
  virtual ~AppidTo123ClassConfig() {}

  virtual std::string get_config() override {
    std::string display = "appid_to_123_class:class_type:";
    display.append(std::to_string(static_cast<int64_t>(class_type_)));
    display.append(", default_value:").append(default_value_);
    return display;
  }

 private:
  std::shared_ptr<std::unordered_map<std::string, AllClasses>> dict_;
  Class123Type class_type_;  //类目类型
  std::string default_value_; //默认值

  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_STRING;
  }
};
class HashCompute {
 public:
  explicit HashCompute() {}
  virtual ~HashCompute() {}

  static void fill_one_feature_to_vec(const tensorflow::Feature& feat, std::vector<int64_t>& vec) {
    int64_t hash_value;
    switch (feat.kind_case()) {
      case tensorflow::Feature::kBytesList:
        vec.reserve(vec.size() + feat.bytes_list().value_size());
        for (const std::string& str : feat.bytes_list().value()) {
          murmur_hash(str, hash_value);
          vec.emplace_back(hash_value);
        }
        break;
      case tensorflow::Feature::kInt64List:
        vec.reserve(vec.size() + feat.int64_list().value_size());
        for (const int64_t value : feat.int64_list().value()) {
          murmur_hash(value, hash_value);
          vec.emplace_back(hash_value);
        }
        break;
      default:
        break;
    }
  }

  static void fill_input_to_vec(const InputFeature& input_feat, std::vector<int64_t>& vec) {
    if (likely(input_feat.feature)) {
      fill_one_feature_to_vec(*input_feat.feature, vec);
    } else if (likely(input_feat.feature_list && input_feat.feature_list->feature_size() > 0)) {
      for (auto& feat : input_feat.feature_list->feature()) {
        fill_one_feature_to_vec(feat, vec);
      }
    }
  }

  static void fill_value_to_vec(const Value* value, std::vector<int64_t>& vec) {
    for (uint32_t i = 0; i < value->ifeatures.size(); i++) {
      const InputFeature& input_feat = value->ifeatures[i];
      fill_input_to_vec(input_feat, vec);
    }
  }
};

//n个输入murmur_hash后用位运算交叉，并截断输出长度
class CrossHashBitsConfig : public Config {
 public:
  explicit CrossHashBitsConfig(const std::string& output,
                               const std::vector<std::string>& source,
                               DefaultValue& default_input_value,
                               bool save,
                               bool allow_empty_output,
                               const std::vector<std::string>& strategy,
                               int32_t clip_size)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), clip_size_(clip_size) {}
  virtual ~CrossHashBitsConfig() {}

  virtual std::string get_config() override {
    std::string display = "cross_hash_bits:clip_size:";
    display.append(std::to_string(clip_size_));
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  int32_t clip_size_; //输出的截断长度
};

//数据激活，如果第一个pb值大于等于激活值，第二个pb取原值，如果第一个pb值小于激活值，第二个pb取默认值
class ActValueConfig : public TowInputConfig {
 public:
  explicit ActValueConfig(const std::string& output,
                          const std::vector<std::string>& source,
                          DefaultValue& default_input_value,
                          bool save,
                          bool allow_empty_output,
                          const std::vector<std::string>& strategy,
                          const float activation_value,
                          const float default_value)
      : TowInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
        activation_int_(static_cast<int64_t>(activation_value)), activation_float_(activation_value),
        default_int_(static_cast<int64_t>(default_value)), default_float_(default_value) {
          data_type_ = tensorflow::DT_INVALID;
        }
  virtual ~ActValueConfig() {}

  virtual std::string get_config() override {
    std::string display = "act_value:activation_value:";
    display.append(std::to_string(activation_float_)).append(", default_value:");
    display.append(std::to_string(default_float_));
    return display;
  }

 private:
  const int64_t activation_int_;    //激活值int64_t
  const float activation_float_;    //激活值float
  const int64_t default_int_;       //默认值int64_t
  const float default_float_;       //默认值float
  tensorflow::DataType data_type_;  //数据类型

  virtual void compute_one_feature(const tensorflow::Feature& input_feat1,
                                    const tensorflow::Feature& input_feat2,
                                    tensorflow::Feature* out) override;
  void fill_value_to_feature(bool flag,
                             int32_t idx,
                             const tensorflow::Feature& input_feat,
                             tensorflow::Feature* out);
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = data_type_;
  }
};

// 对int64做偏移处理
class Int64OffsetConfig : public OneInputConfig {
 public:
  explicit Int64OffsetConfig(const std::string& output,
                             const std::vector<std::string>& source,
                             DefaultValue& default_input_value,
                             bool save,
                             bool allow_empty_output,
                             const std::vector<std::string>& strategy,
                             const int64_t offset)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
        offset_(offset) {}
  virtual ~Int64OffsetConfig() {}

  virtual std::string get_config() override {
    return "int64_offset:" + std::to_string(offset_);
  }

 private:
  int64_t offset_; //偏移值
  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_INT64;
  }
};

// 查指定词典,输出n个属性,未查到属性填默认值
class DictToAttributesConfig : public Config {
 public:
  explicit DictToAttributesConfig(const std::string& output,
                                  const std::vector<std::string>& source,
                                  DefaultValue& default_input_value,
                                  bool save,
                                  bool allow_empty_output,
                                  const std::vector<std::string>& strategy,
                                  std::shared_ptr<std::unordered_map<std::string, AllClasses>>& dict,
                                  const std::string& connector,
                                  const std::string& default_value)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy),
        dict_(dict), connector_(connector), trans_connector_(connector), default_value_(default_value) {
          InvisibleCharacter::character_replace(trans_connector_);
        }
  virtual ~DictToAttributesConfig() {}

  virtual std::string get_config() override {
    std::string display = "dict_to_attributes:connector:";
    display.append(connector_);
    display.append(", default_value:").append(default_value_);
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  std::shared_ptr<std::unordered_map<std::string, AllClasses>> dict_;  // 词典
  std::string connector_;                                              // 连接符原字符串
  std::string trans_connector_;                                        // 连接符转换字符串
  std::string default_value_;                                          // 默认值

  void compute_one_feature(const tensorflow::Feature& feat,
                           std::vector<tensorflow::Feature*>& out_feat);
};


// 在dict_to_attributes的基础上,自动扩展新增字段,按顺序输出,未查到属性填默认值
class DictToAttributesV2Config : public Config {
 public:
  explicit DictToAttributesV2Config(const std::string& output,
                                  const std::vector<std::string>& source,
                                  DefaultValue& default_input_value,
                                  bool save,
                                  bool allow_empty_output,
                                  const std::vector<std::string>& strategy,
                                  std::shared_ptr<std::unordered_map<std::string, AllClasses>>& dict,
                                  const std::string& connector,
                                  const std::string& default_value)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy),
        dict_(dict), connector_(connector), trans_connector_(connector), default_value_(default_value) {
          InvisibleCharacter::character_replace(trans_connector_);
        }
  virtual ~DictToAttributesV2Config() {}

  virtual std::string get_config() override {
    std::string display = "dict_to_attributes_v2:connector:";
    display.append(connector_);
    display.append(", default_value:").append(default_value_);
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  std::shared_ptr<std::unordered_map<std::string, AllClasses>> dict_;  // 词典
  std::string connector_;                                              // 连接符原字符串
  std::string trans_connector_;                                        // 连接符转换字符串
  std::string default_value_;                                          // 默认值

  void compute_one_feature(const tensorflow::Feature& feat,
                           std::vector<tensorflow::Feature*>& out_feat);
};

//特征过滤，根据指定的过滤字段和过滤条件，抽取n个指定的输出字段
class ConditionalFilterConfig : public Config {
 public:
  explicit ConditionalFilterConfig(const std::string& output,
                                   const std::vector<std::string>& source,
                                   DefaultValue& default_input_value,
                                   bool save,
                                   bool allow_empty_output,
                                   const std::vector<std::string>& strategy,
                                   const std::vector<std::string>& filter,
                                   const std::vector<std::set<std::string>>& filter_dict,
                                   const std::vector<std::string>& fields)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), filter_(filter), filter_dict_(filter_dict),
        fields_(fields) {}

  virtual ~ConditionalFilterConfig() {}

  virtual std::string get_config() override {
    std::string display = "conditional_filter:filter:[";
    for (uint32_t i = 0; i < filter_dict_.size(); i++) {
      display.append("[");
      display.append(filter_[i]).append(",");;
      for (auto& filter_str : filter_dict_[i]) {
        display.append(filter_str).append(",");;
      }
      display.pop_back();
      display.append("]");
    }
    display.append("], fields:[");
    for (auto& field_str : fields_) {
      display.append(field_str).append(",");
    }
    display.pop_back();
    display.append("]");
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  const std::vector<std::string> filter_;                 //n个维度值在路径中对应的字段
  const std::vector<std::set<std::string>> filter_dict_;  //n个维度值在路径中对应的过滤条件
  const std::vector<std::string> fields_;                 //最终抽取的字段
};

//message过滤，根据pb中指定的单个值的过滤条件，和对应的message中的字段，过滤或命中符合的message
class MessageFilterV2Config : public Config {
 public:
  explicit MessageFilterV2Config(const std::string& output,
                                 const std::vector<std::string>& source,
                                 DefaultValue& default_input_value,
                                 bool save,
                                 bool allow_empty_output,
                                 const std::vector<std::string>& strategy,
                                 const std::vector<std::string>& str_filter,
                                 const std::vector<bool>& str_hit,
                                 const std::vector<size_t>& str_idx,
                                 const std::vector<std::string>& str_value,
                                 const std::vector<std::string>& int_filter,
                                 const std::vector<bool>& int_hit,
                                 const std::vector<size_t>& int_idx,
                                 const std::vector<int64_t>& int_value,
                                 const std::string& eventtime_key,
                                 int64_t start_ms,
                                 int64_t end_ms)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), str_filter_(str_filter), str_hit_(str_hit),
        str_idx_(str_idx), str_value_(str_value), int_filter_(int_filter), int_hit_(int_hit), int_idx_(int_idx),
        int_value_(int_value), eventtime_key_(eventtime_key), start_(start_ms), end_(end_ms) {}

  virtual ~MessageFilterV2Config() {}

  virtual std::string get_config() override {
    std::string display = "message_filter_v2:str_filter:[";
    for (uint32_t i = 0; i < str_filter_.size(); i++) {
      display.append("[");
      display.append(str_filter_[i]).append(",");
      if (str_hit_[i]) {
        display.append("hit,");
      } else {
        display.append("miss,");
      }
      display.append(str_value_[i]).append("]");
    }
    display.append("], int_filter:[");
    for (uint32_t i = 0; i < int_filter_.size(); i++) {
      display.append("[");
      display.append(int_filter_[i]).append(",");
      if (int_hit_[i]) {
        display.append("hit,");
      } else {
        display.append("miss,");
      }
      display.append(std::to_string(int_value_[i])).append("]");
    }
    display.append("], eventtime_key:").append(eventtime_key_);
    display.append(", start_ms:").append(std::to_string(start_));
    display.append(", end_ms:").append(std::to_string(end_));
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  const std::vector<std::string> str_filter_;                 //n个维度值在路径中对应的string字段
  const std::vector<bool> str_hit_;                           //n个string字段，获取命中或者获取未命中
  const std::vector<size_t> str_idx_;                         //n个string字段，在pb中的偏移
  const std::vector<std::string> str_value_;                  //n个string字段，单值的默认值
  const std::vector<std::string> int_filter_;                 //n个维度值在路径中对应的int字段
  const std::vector<bool> int_hit_;                           //n个int字段，获取命中或者获取未命中
  const std::vector<size_t> int_idx_;                         //n个int字段，在pb中的偏移
  const std::vector<int64_t> int_value_;                      //n个int字段，单值的默认值
  const std::string eventtime_key_;                           //时间戳在路径中对应的字段
  int64_t start_;                                             //防穿越，毫秒级
  int64_t end_;                                               //最久时间范围，毫秒级
};

//message根据自身字段和pb中的属性，获取指定的内部messages
template<typename T>
class MessageSelectConfig : public Config {
 public:
  explicit MessageSelectConfig(const std::string& output,
                               const std::vector<std::string>& source,
                               DefaultValue& default_input_value,
                               bool save,
                               bool allow_empty_output,
                               const std::vector<std::string>& strategy,
                               const std::unordered_map<T, std::string>& select_map,
                               const std::string& default_value)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), select_map_(select_map), default_value_(default_value) {}

  virtual ~MessageSelectConfig() {}

  virtual std::string get_config() override;

  bool compute(const std::vector<const Output*>& input_values, Output& output) override {
    LogDebug("------------ compute {} start ------------", output_);

    const Value* message_value = get_value(input_values, inputs_, 0);
    const Value* select_value = get_value(input_values, inputs_, 1);

    const uint32_t batch_size = message_value->ifeatures.size();
    const InputFeature* inf_message = nullptr;
    const InputFeature* inf_select = nullptr;

    output.values.resize(1);
    Value& value = output.values[0];
    value.ifeatures.resize(batch_size);

    //输出
    for (uint32_t i = 0; i < batch_size; i++) {
      inf_message = &message_value->ifeatures[i];
      inf_select = get_idx_ifeatures(select_value, i);
      std::vector<const google::protobuf::Message*> filter_vec(inf_message->messages.size(), nullptr);

      T filter_value;
      if (get_ifeature_value(inf_select, filter_value)) {
        compute_one_message(filter_value, inf_message->messages, filter_vec);
      } else {
        filter_vec.clear();
      }

      output.values[0].ifeatures[i].messages.swap(filter_vec);
    }

    LogDebug("------------ compute {} done ------------", output_);
    return true;
  }

 private:
  const std::unordered_map<T, std::string> select_map_;
  const std::string default_value_;
  bool get_ifeature_value(const InputFeature* ifeature, T& filter_value);
  void compute_one_message(const T& filter_value, const std::vector<const google::protobuf::Message*>& messages, std::vector<const google::protobuf::Message*>& out) {
    auto itr = select_map_.find(filter_value);
    if (itr != select_map_.end()) {
      const google::protobuf::Message* mess = nullptr;
      for (uint32_t i = 0; i < messages.size(); i++) {
        mess = messages[i];
        auto desc = mess->GetDescriptor();
        auto ref = mess->GetReflection();
        auto field = desc->FindFieldByName(itr->second);

        if (unlikely(nullptr == ref || nullptr == field)) {
          THROW_ERROR("failed, get null_ptr on " + itr->second + " name:" + output_);
          return;
        }

        if (unlikely(field->type() != google::protobuf::FieldDescriptor::Type::TYPE_MESSAGE)) {
          THROW_ERROR("failed, is not mess on " + itr->second + " name:" + output_);
          return;
        }

        out[i] = &(ref->GetMessage(*mess, field));
      }
    } else {
      out.clear();
      return;
    }
  }
};

class RepetitionListConfig : public Config {
  public:
  explicit RepetitionListConfig(const std::string& output,
    const std::vector<std::string>& source,
    DefaultValue& default_input_value,
    bool save,
    bool allow_empty_output,
    const std::vector<std::string>& strategy)
: Config(output, source, default_input_value, save, allow_empty_output, strategy) {}
virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
virtual std::string get_config() override {
  return "repetition_list_config";
}
virtual ~RepetitionListConfig() {}
void compute_one_feature(const tensorflow::FeatureList& a_feature, const tensorflow::FeatureList& b_feature,
  tensorflow::Feature* out_feat);
void compute_one_feature(const tensorflow::Feature& a_feature, const tensorflow::Feature& b_feature,
  tensorflow::Feature* out_feat);
};

// 返回序列的长度，int或float类型还返回序列的平均值，最大值，总值
class CalcStatsConfig : public Config {
 public:
  explicit CalcStatsConfig(const std::string& output,
                           const std::vector<std::string>& source,
                           DefaultValue& default_input_value,
                           bool save,
                           bool allow_empty_output,
                           const std::vector<std::string>& strategy,
                           DataType data_type,
                           const std::string& default_value)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), data_type_(data_type), default_value_(default_value) {
        if (unlikely(!Calc::convert_int64(default_value, default_int_))) {
          default_int_ = 0;
        }
        if (unlikely(!Calc::convert_float(default_value, default_float_))) {
          default_float_ = 0;
        }
      }
  virtual ~CalcStatsConfig() {}

  virtual std::string get_config() override {
    std::string display = "calc_stats:data_type:";
    display.append(std::to_string(static_cast<int64_t>(data_type_)));
    display.append(", default_value:").append(default_value_);
    display.append(", default_int:").append(std::to_string(default_int_));
    display.append(", default_float:").append(std::to_string(default_float_));
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  DataType data_type_;        //输出的数据类型
  std::string default_value_; //string默认值
  int64_t default_int_;       //int默认值
  float default_float_;       //float默认值
};

#endif  // FE_CONFIG_BASE