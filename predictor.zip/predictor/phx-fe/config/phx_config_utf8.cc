#include "phx_config_utf8.h"
#include "phx-fe/util/calc.h"
#include "phx-fe/util/timer.h"
#include <algorithm>
#include <cstdlib>

namespace phx_fe {

    Utf8IsEqualConfig::Utf8IsEqualConfig(const std::string &output, const std::vector<std::string> &source,
                                         DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                         const std::vector<std::string> &strategy, bool cross)
        : TowInputConfig(output, source, default_input_value, save, allow_empty_output, strategy, cross) {
    }

    std::string Utf8IsEqualConfig::get_config() {
        return "utf8_is_equal";
    }

    void Utf8IsEqualConfig::compute_one_feature(const tensorflow::Feature &input_feat1,
                                                const tensorflow::Feature &input_feat2, tensorflow::Feature *out) {
        const auto &input_vec1 = input_feat1.bytes_list().value();
        const auto &input_vec2 = input_feat2.bytes_list().value();
        const uint32_t list_size = std::min(input_vec1.size(), input_vec2.size());

        for (uint32_t i = 0; i < list_size; i++) {
            out->mutable_int64_list()->add_value((input_vec1[i] == input_vec2[i]) ? 1 : 0);
        }
    }

    void Utf8IsEqualConfig::fill_value_dtype(tensorflow::DataType &data_type) {
        data_type = tensorflow::DT_INT64;
    }

    Utf8IsPrefixConfig::Utf8IsPrefixConfig(const std::string &output, const std::vector<std::string> &source,
                                           DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                           const std::vector<std::string> &strategy, bool cross)
        : TowInputConfig(output, source, default_input_value, save, allow_empty_output, strategy, cross) {
    }

    std::string Utf8IsPrefixConfig::get_config() {
        return "utf8_is_prefix";
    }

    void Utf8IsPrefixConfig::fill_value_dtype(tensorflow::DataType &data_type) {
        data_type = tensorflow::DT_INT64;
    }

    void Utf8IsPrefixConfig::compute_one_feature(const tensorflow::Feature &input_feat1,
                                                 const tensorflow::Feature &input_feat2, tensorflow::Feature *out) {
        auto &input_vec1 = input_feat1.bytes_list().value();
        auto &input_vec2 = input_feat2.bytes_list().value();
        const uint32_t list_size = std::min(input_vec1.size(), input_vec2.size());

        for (uint32_t i = 0; i < list_size; i++) {
            out->mutable_int64_list()->add_value(is_pre_fix(input_vec1[i], input_vec2[i]));
        }
    }

    int32_t Utf8IsPrefixConfig::is_pre_fix(const std::string &word1, const std::string &word2) {
        if (word1.length() < word2.length()) {
            return 0;
        }

        const char *p1 = word1.c_str();
        const char *p2 = word2.c_str();

        //遍历str2，判断word1的前缀和word2是否相等
        for (uint32_t i = 0; i < word2.length(); i++) {
            if (p1[i] != p2[i]) {
                return 0;
            }
        }

        return 1;
    }

    Utf8IsContainsConfig::Utf8IsContainsConfig(const std::string &output, const std::vector<std::string> &source,
                                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                               const std::vector<std::string> &strategy, bool cross)
        : TowInputConfig(output, source, default_input_value, save, allow_empty_output, strategy, cross) {
    }

    std::string Utf8IsContainsConfig::get_config() {
        return "utf8_is_contains";
    }

    void Utf8IsContainsConfig::compute_one_feature(const tensorflow::Feature &input_feat1,
                                                   const tensorflow::Feature &input_feat2, tensorflow::Feature *out) {
        auto &input_vec1 = input_feat1.bytes_list().value();
        auto &input_vec2 = input_feat2.bytes_list().value();
        const uint32_t list_size = std::min(input_vec1.size(), input_vec2.size());

        for (uint32_t i = 0; i < list_size; i++) {
            out->mutable_int64_list()->add_value(((input_vec1[i].find(input_vec2[i]) != std::string::npos) ? 1 : 0));
        }
    }

    void Utf8IsContainsConfig::fill_value_dtype(tensorflow::DataType &data_type) {
        data_type = tensorflow::DT_INT64;
    }

    Utf8PublicPrefixLengthConfig::Utf8PublicPrefixLengthConfig(const std::string &output,
                                                               const std::vector<std::string> &source,
                                                               DefaultValue &default_input_value, bool save,
                                                               bool allow_empty_output,
                                                               const std::vector<std::string> &strategy, bool cross)
        : TowInputConfig(output, source, default_input_value, save, allow_empty_output, strategy, cross) {
    }

    std::string Utf8PublicPrefixLengthConfig::get_config() {
        return "utf8_public_prefix_length";
    }

    void Utf8PublicPrefixLengthConfig::compute_one_feature(const tensorflow::Feature &input_feat1,
                                                           const tensorflow::Feature &input_feat2,
                                                           tensorflow::Feature *out) {
        auto &input_vec1 = input_feat1.bytes_list().value();
        auto &input_vec2 = input_feat2.bytes_list().value();
        const uint32_t list_size = std::min(input_vec1.size(), input_vec2.size());

        for (uint32_t i = 0; i < list_size; i++) {
            out->mutable_int64_list()->add_value(public_prefix_length(input_vec1[i], input_vec2[i]));
        }
    }

    void Utf8PublicPrefixLengthConfig::fill_value_dtype(tensorflow::DataType &data_type) {
        data_type = tensorflow::DT_INT64;
    }

    int32_t Utf8PublicPrefixLengthConfig::public_prefix_length(const std::string &word1, const std::string &word2) {
        const char *s_1 = word1.c_str();
        const char *end_1 = s_1 + word1.length();
        const char *s_2 = word2.c_str();
        const char *end_2 = s_2 + word2.length();
        int32_t ret = 0;

        while (s_1 < end_1 && s_2 < end_2) {
            if (!Utf8BaseCompute::is_equal(s_1, s_2)) {
                break;
            }

            ret++;
            s_1 = Utf8BaseCompute::get_next_word(s_1);
            s_2 = Utf8BaseCompute::get_next_word(s_2);
        }

        return ret;
    }

    Utf8DistanceConfig::Utf8DistanceConfig(const std::string &output, const std::vector<std::string> &source,
                                           DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                           const std::vector<std::string> &strategy, bool cross)
        : TowInputConfig(output, source, default_input_value, save, allow_empty_output, strategy, cross) {
    }

    std::string Utf8DistanceConfig::get_config() {
        return "utf8_distance";
    }

    void Utf8DistanceConfig::compute_one_feature(const tensorflow::Feature &input_feat1,
                                                 const tensorflow::Feature &input_feat2, tensorflow::Feature *out) {
        auto &input_vec1 = input_feat1.bytes_list().value();
        auto &input_vec2 = input_feat2.bytes_list().value();
        const uint32_t list_size = std::min(input_vec1.size(), input_vec2.size());

        for (uint32_t i = 0; i < list_size; i++) {
            out->mutable_int64_list()->add_value(min_distance(input_vec1[i], input_vec2[i]));
        }
    }

    void Utf8DistanceConfig::fill_value_dtype(tensorflow::DataType &data_type) {
        data_type = tensorflow::DT_INT64;
    }

    int32_t Utf8DistanceConfig::min_distance(const std::string &word1, const std::string &word2) {
        uint32_t str_n = word1.length();// 字符串长度
        uint32_t str_m = word2.length();

        // 有一个字符串为空串
        if (0 == str_n) {
            return Utf8BaseCompute::length(word2.c_str(), str_m);
        } else if (0 == str_m) {
            return Utf8BaseCompute::length(word1.c_str(), str_n);
        }
        // DP 数组，此时还不知道utf8字符长度，按照字符串长度多申请一些，空间换时间
        std::vector<std::vector<int32_t>> D(str_n + 1, std::vector<int32_t>(str_m + 1));

        // 边界状态初始化
        for (uint32_t i = 0; i < str_n + 1; i++) {
            D[i][0] = i;
        }
        for (uint32_t j = 0; j < str_m + 1; j++) {
            D[0][j] = j;
        }

        uint32_t n = 0;// utf8字符数
        uint32_t m = 0;
        const char *start_n = word1.c_str();//第一轴
        const char *end_n = start_n + str_n;
        const char *start_m = word2.c_str();//第二轴
        const char *end_m = start_m + str_m;

        // 计算所有 DP 值
        while (start_n < end_n) {
            m = 0;
            start_m = word2.c_str();

            //遍历固定n轴(utf8字节数)的m轴，看x字节时的最小变化距离
            while (start_m < end_m) {
                int32_t left_down = D[n][m];

                if (!Utf8BaseCompute::is_equal(start_n, start_m)) {
                    left_down += 1;
                }

                D[n + 1][m + 1] = std::min(left_down, std::min((D[n + 1][m] + 1), (D[n][m + 1] + 1)));

                start_m += Utf8BaseCompute::byte_width(*start_m);
                m++;
            }

            start_n += Utf8BaseCompute::byte_width(*start_n);
            n++;
        }

        return D[n][m];
    }

    Utf8GetReresultConfig::Utf8GetReresultConfig(const std::string &output, const std::vector<std::string> &source,
                                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                                 const std::vector<std::string> &strategy)
        : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy) {
    }

    std::string Utf8GetReresultConfig::get_config() {
        return "utf8_get_re_result";
    }

    void Utf8GetReresultConfig::fill_value_dtype(tensorflow::DataType &data_type) {
        data_type = tensorflow::DT_STRING;
    }

    const std::pair<uint32_t, size_t> Utf8GetReresultConfig::invalid_decode_ = {0xFFFD, 1};// REPLACEMENT CHARACTER �

    void Utf8GetReresultConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        for (const std::string &str: feat.bytes_list().value()) {
            out->mutable_bytes_list()->add_value(filter_utf8(str));
        }
    }

    std::pair<uint32_t, size_t> Utf8GetReresultConfig::decode_utf8(const std::string &str, const size_t pos) {
        const uint8_t lead = static_cast<uint8_t>(str[pos]);
        int32_t width = Utf8BaseCompute::byte_width(str[pos]);
        // 越界检查
        if (pos + width > str.size()) {
            return invalid_decode_;
        }

        switch (width) {
            case 1:
                return {lead, 1};

            case 2:
                return {((lead & 0x1F) << 6) | (str[pos + 1] & 0x3F), 2};

            case 3:
                return {((lead & 0x0F) << 12) | ((str[pos + 1] & 0x3F) << 6) | (str[pos + 2] & 0x3F), 3};

            case 4:
                return {((lead & 0x07) << 18) | ((str[pos + 1] & 0x3F) << 12) | ((str[pos + 2] & 0x3F) << 6) |
                                (str[pos + 3] & 0x3F),
                        4};

            default:
                return invalid_decode_;
        }
    }

    std::string Utf8GetReresultConfig::filter_utf8(const std::string &input) {
        std::string output;
        output.reserve(input.size());
        size_t pos = 0;

        while (pos < input.size()) {
            // 解码当前字符
            std::pair<uint32_t, size_t> pair = decode_utf8(input, pos);

            // 合法字符处理
            if (Utf8BaseCompute::is_allowed_codepoint(pair.first)) {
                output.append(input.substr(pos, pair.second));
            }

            pos += pair.second;
        }

        // 将结果转换为小写
        std::transform(output.begin(), output.end(), output.begin(), ::tolower);

        return output;
    }

    Utf8GetPrefixConfig::Utf8GetPrefixConfig(const std::string &output, const std::vector<std::string> &source,
                                             DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                             const std::vector<std::string> &strategy, int32_t max_size)
        : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy), max_size_(max_size) {
    }

    std::string Utf8GetPrefixConfig::get_config() {
        return "utf8_get_prefix:max_size:" + std::to_string(max_size_);
    }

    void Utf8GetPrefixConfig::fill_value_dtype(tensorflow::DataType &data_type) {
        data_type = tensorflow::DT_STRING;
    }

    void Utf8GetPrefixConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        std::vector<std::string> str_vec;
        for (const std::string &input_str: feat.bytes_list().value()) {
            str_vec.clear();
            Utf8BaseCompute::split_to_vec(input_str, 1, str_vec);
            std::string connect_str;
            // 如果切分后的字符数少于1，返回空，大于1，返回字符数减一数量的前缀
            uint32_t num = str_vec.size() > 1 ? std::min(max_size_, static_cast<uint32_t>(str_vec.size() - 1)) : 0;
            for (uint32_t i = 0; i < num; i++) {
                connect_str.append(str_vec[i]);
                out->mutable_bytes_list()->add_value(connect_str);
            }
        }
    }

    void Utf8CoincideConfig::compute_one_feature(const tensorflow::Feature &input_feat1,
                                                 const tensorflow::Feature &input_feat2, tensorflow::Feature *out) {
        auto &input_vec1 = input_feat1.bytes_list().value();
        auto &input_vec2 = input_feat2.bytes_list().value();
        const uint32_t list_size = std::min(input_vec1.size(), input_vec2.size());

        for (uint32_t i = 0; i < list_size; i++) {
            std::string coincide_str;
            coincide_string(input_vec1[i], input_vec2[i], coincide_str);
            out->mutable_bytes_list()->add_value(coincide_str);
        }
    }

    void Utf8CoincideConfig::coincide_string(const std::string &input1, const std::string &input2,
                                             std::string &output) {
        std::set<std::string> set;
        Utf8BaseCompute::split_to_set(input1, 1, set);

        const char *p = input2.c_str();
        const char *start = p;
        for (uint32_t i = 0; i < input2.length();) {
            i += Utf8BaseCompute::byte_width(p[i]);
            auto itr = set.find(std::string(start, p + i - start));
            if (itr != set.end()) {
                output.append(*itr);
            }
            start = p + i;
        }
    }

    Utf8SubStrConfig::Utf8SubStrConfig(const std::string &output, const std::vector<std::string> &source,
                                       DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                       const std::vector<std::string> &strategy, int32_t len)
        : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
          len_(static_cast<std::size_t>(len)) {
    }
    std::string Utf8SubStrConfig::get_config() {
        return "utf8_sub_str:len:" + std::to_string(len_);
    }
    void Utf8SubStrConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        for (const std::string &input_str: feat.bytes_list().value()) {
            out->mutable_bytes_list()->add_value(Utf8BaseCompute::utf8_substr(input_str, 0, len_));
        }
    }
    void Utf8SubStrConfig::fill_value_dtype(tensorflow::DataType &data_type) {
        data_type = tensorflow::DT_STRING;
    }

    Utf8IpToListConfig::Utf8IpToListConfig(const std::string &output, const std::vector<std::string> &source,
                                           DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                           const std::vector<std::string> &strategy, const std::string &sep)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy), sep_(sep) {
    }

    std::string Utf8IpToListConfig::get_config() {
        return "utf8_ip_to_list: sep_: " + sep_;
    }

    bool Utf8IpToListConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        const Value *input_value = get_value(input_values, inputs_, 0);
        uint32_t batch_size = input_value->ifeatures.size();

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_STRING;
        value.ifeatures.resize(batch_size);

        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;
        const InputFeature *inf = nullptr;

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &input_value->ifeatures[i];

            if (likely(inf->feature)) {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;
                compute_one_feature(*inf->feature, out_feature);
            } else {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;
                if (likely(inf->feature_list)) {
                    for (auto &feat: inf->feature_list->feature()) {
                        compute_one_feature(feat, out_featurelist->add_feature());
                    }
                }
            }
        }
        return true;
    }

    void Utf8IpToListConfig::compute_one_feature(const tensorflow::Feature &input_feat, tensorflow::Feature *out) {
        auto &input_vec = input_feat.bytes_list().value();
        const uint32_t list_size = input_vec.size();
        if (list_size > 0) {
            const auto &source = input_vec[0];
            size_t first_pos = source.find_first_of(sep_);
            //没有分割符，直接填充整个字符串
            if (first_pos == std::string::npos) {
                out->mutable_bytes_list()->add_value(source);
                return;
            }
            size_t next_pos = first_pos;
            while (next_pos != std::string::npos) {
                next_pos = source.find_first_of(sep_, next_pos + 1);
                out->mutable_bytes_list()->add_value(source.substr(0, next_pos));
            }
        }
    }

}// namespace phx_fe
