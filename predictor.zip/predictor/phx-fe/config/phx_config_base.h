#pragma once
#include "config.h"
#include "phx-fe/util/invisible_character.h"

namespace phx_fe {

    class HashCompute {
    public:
        explicit HashCompute() {
        }
        virtual ~HashCompute() {
        }

        static void fill_one_feature_to_vec(const tensorflow::Feature &feat, std::vector<int64_t> &vec) {
            int64_t hash_value;
            switch (feat.kind_case()) {
                case tensorflow::Feature::kBytesList:
                    vec.reserve(vec.size() + feat.bytes_list().value_size());
                    for (const std::string &str: feat.bytes_list().value()) {
                        murmur_hash(str, hash_value);
                        vec.emplace_back(hash_value);
                    }
                    break;
                case tensorflow::Feature::kInt64List:
                    vec.reserve(vec.size() + feat.int64_list().value_size());
                    for (const int64_t value: feat.int64_list().value()) {
                        murmur_hash(value, hash_value);
                        vec.emplace_back(hash_value);
                    }
                    break;
                case tensorflow::Feature::KindCase::kFloatList: {
                    THROW_ERROR("cross hash bits doesn't support float");
                    break;
                }
                default:
                    break;
            }
        }

        static void fill_input_to_vec(const InputFeature &input_feat, std::vector<int64_t> &vec) {
            if (likely(input_feat.feature)) {
                fill_one_feature_to_vec(*input_feat.feature, vec);
            } else if (likely(input_feat.feature_list && input_feat.feature_list->feature_size() > 0)) {
                for (auto &feat: input_feat.feature_list->feature()) {
                    fill_one_feature_to_vec(feat, vec);
                }
            }
        }

        static void fill_value_to_vec(const Value *value, std::vector<int64_t> &vec) {
            for (uint32_t i = 0; i < value->ifeatures.size(); i++) {
                const InputFeature &input_feat = value->ifeatures[i];
                fill_input_to_vec(input_feat, vec);
            }
        }
    };

    //n个输入murmur_hash后用位运算交叉，并截断输出长度，不同batch独立运算
    class CrossHashBitsV2Config : public Config {
    public:
        explicit CrossHashBitsV2Config(const std::string &output, const std::vector<std::string> &source,
                                       DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                       const std::vector<std::string> &strategy, int32_t clip_size)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), clip_size_(clip_size) {
        }
        virtual ~CrossHashBitsV2Config() {
        }

        virtual std::string get_config() override {
            std::string display = "cross_hash_bits_v2:clip_size:";
            display.append(std::to_string(clip_size_));
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        int32_t clip_size_;//输出的截断长度
    };

    // 分词
    class SegmentConfig : public OneInputConfig {
    public:
        explicit SegmentConfig(const std::string &output, const std::vector<std::string> &source,
                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                               const std::vector<std::string> &strategy, const cppjieba::MixSegment *segment,
                               const std::string &dict_name)
            : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
              segment_(segment), dict_name_(dict_name) {
        }
        virtual ~SegmentConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "segment:";
            display.append("dict name = [").append(dict_name_).append("]");
            return display;
        }

    private:
        const cppjieba::MixSegment *segment_;// 分词工具类
        std::string dict_name_;
        virtual void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;
        virtual void fill_value_dtype(tensorflow::DataType &data_type) override {
            data_type = tensorflow::DT_STRING;
        }
    };

    //全交叉拼接，连接符支持自定义，支持全数据类型
    class FullyCrossConfig : public Config {
    public:
        explicit FullyCrossConfig(const std::string &output, const std::vector<std::string> &source,
                                  DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                  const std::vector<std::string> &strategy, const std::string &connector,
                                  const std::string &default_value)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), connector_(connector),
              default_value_(default_value) {
        }
        virtual ~FullyCrossConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "fully_cross:connector:";
            display.append(connector_);
            display.append(", default_value:").append(default_value_);
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        std::string connector_;    //连接符
        std::string default_value_;//默认值

        void fill_ifea_to_vec(const InputFeature *ifea, std::vector<std::string> &vec);
        void fill_one_feature_to_vec(const tensorflow::Feature &feat, std::vector<std::string> &vec);
        void compute_one_feature(std::vector<std::string> &vec, const tensorflow::Feature &feat,
                                 tensorflow::Feature *out);
    };

    class CombineConfig : public Config {
    public:
        explicit CombineConfig(const std::string &output, const std::vector<std::string> &source,
                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                               const std::vector<std::string> &strategy, int max_size)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), _max_size(max_size) {
        }
        virtual ~CombineConfig() {
        }

        std::string get_config() override {
            std::string display = "combine config:[]";
            return display;
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        const int _max_size;
    };

    // 对int数据做差法运算，获得第一个输入(1个值)单独减去第二个输入(n个值)的差值(n个值)
    class Int64DifferenceConfig final : public Config {
    public:
        explicit Int64DifferenceConfig(const std::string &output, const std::vector<std::string> &source,
                                       DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                       const std::vector<std::string> &strategy);

        ~Int64DifferenceConfig() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        void compute_one_feature(const int64_t num, const tensorflow::Feature &feat, tensorflow::Feature *out);
    };

    // 截断
    class ClipConfig final : public OneInputConfig {
    public:
        explicit ClipConfig(const std::string &output, const std::vector<std::string> &source,
                            DefaultValue &default_input_value, bool save, bool allow_empty_output,
                            const std::vector<std::string> &strategy, int64_t start, int64_t size);
        ~ClipConfig() override = default;

        std::string get_config() override;

    private:
        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out_feature) override;
        void fill_value_dtype(tensorflow::DataType &data_type) override;

        int32_t start_;                 // 截断起始位置
        int32_t size_;                  // 截断长度
        tensorflow::DataType data_type_;//数据类型
    };

    // 数据源中是否存在数据，存在返回1，不存在返回0
    class ExistsConfig final : public Config {
    public:
        explicit ExistsConfig(const std::string &output, const std::vector<std::string> &source,
                              DefaultValue &default_input_value, bool save, bool allow_empty_output,
                              const std::vector<std::string> &strategy);

        ~ExistsConfig() override = default;

        std::string get_config() override;

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;
    };

    // 计算两个序列的长度差，返回第一个序列长度减去第二个序列长度的结果
    class LenDiffConfig final : public Config {
    public:
        explicit LenDiffConfig(const std::string &output, const std::vector<std::string> &source,
                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                               const std::vector<std::string> &strategy);

        ~LenDiffConfig() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;
    };

    // 计算两个序列的长度比值
    class LenRatioConfig final : public Config {
    public:
        enum LenRatioType {
            Ratio_ADD = 1,//分子分母同时+1做除法
            Ratio_DEFAULT,//如果分母为0，返回默认值
        };

        explicit LenRatioConfig(const std::string &output, const std::vector<std::string> &source,
                                DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                const std::vector<std::string> &strategy, LenRatioType len_ratio_type,
                                float default_value);

        ~LenRatioConfig() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        LenRatioType len_ratio_type_;
        float default_value_;
    };

    // 直出
    class DirectConfig final : public Config {
    public:
        explicit DirectConfig(const std::string &output, const std::vector<std::string> &source,
                              DefaultValue &default_value_map, bool save, bool allow_empty_output,
                              const std::vector<std::string> &strategy, bool auto_type)
            : Config(output, source, default_value_map, save, allow_empty_output, strategy) {
            // auto_type_已经在基类中通过策略赋值,假如没有被赋值，才根据传入的auto_type赋值
            if (!auto_type_) {
                auto_type_ = auto_type;
            }
        }

        ~DirectConfig() override = default;

        std::string get_config() override {
            return "direct";
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;
    };

    // 如果是将feature list 合并为1个feature，可设置指定的数据类型和默认值，E@非空策略填充默认值
    class DirectToFeatureV2Config final : public OneInputConfig {
    public:
        explicit DirectToFeatureV2Config(const std::string &output, const std::vector<std::string> &source,
                                         DefaultValue &default_value_map, bool save, bool allow_empty_output,
                                         const std::vector<std::string> &strategy, DataType data_type,
                                         const std::string &default_value)
            : OneInputConfig(output, source, default_value_map, save, allow_empty_output, strategy),
              data_type_(data_type), default_value_(default_value) {
            if (unlikely(!Calc::convert_int64(default_value, default_int_))) {
                default_int_ = 0;
            }
            if (unlikely(!Calc::convert_float(default_value, default_float_))) {
                default_float_ = 0;
            }
        }

        ~DirectToFeatureV2Config() override = default;

        std::string get_config() override {
            std::string display = "direct_to_feature_v2:data_type:";
            display.append(std::to_string(static_cast<int64_t>(data_type_)));
            display.append(", default_value:").append(default_value_);
            display.append(", default_int:").append(std::to_string(default_int_));
            display.append(", default_float:").append(std::to_string(default_float_));
            return display;
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    protected:
        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;

    private:
        DataType data_type_;       //输出的数据类型
        std::string default_value_;//string默认值
        int64_t default_int_;      //int默认值
        float default_float_;      //float默认值
    };

    //转换成特定的数据类型
    class TransTypeConfig final : public OneInputConfig {
    public:
        explicit TransTypeConfig(const std::string &output, const std::vector<std::string> &source,
                                 DefaultValue &default_value_map, bool save, bool allow_empty_output,
                                 const std::vector<std::string> &strategy, DataType data_type,
                                 const std::string &default_value)
            : OneInputConfig(output, source, default_value_map, save, allow_empty_output, strategy),
              data_type_(data_type), default_value_(default_value) {
            if (unlikely(!Calc::convert_int64(default_value, default_int_))) {
                default_int_ = 0;
            }
            if (unlikely(!Calc::convert_float(default_value, default_float_))) {
                default_float_ = 0;
            }
        }

    protected:
        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) override;
        void fill_value_dtype(tensorflow::DataType &data_type) override;

    private:
        DataType data_type_;       //输出的数据类型
        std::string default_value_;//string默认值
        int64_t default_int_;      //int默认值
        float default_float_;      //float默认值
    };

    //pb对应拼接，如果输入一的pb为空，返回空，输入二的pb为空则不拼接，连接符支持自定义，尾部字符支持自定义，支持全数据类型
    class ConnectConfig final : public Config {
    public:
        explicit ConnectConfig(const std::string &output, const std::vector<std::string> &source,
                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                               const std::vector<std::string> &strategy, const std::string &connector,
                               const std::string &tail);

        ~ConnectConfig() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        uint32_t get_feature_size(const tensorflow::Feature &feat);
        void compute_one_feature(const tensorflow::Feature &feat, std::vector<std::string> &vec);

        std::string org_connector_;//原始连接符
        std::string connector_;    //连接符
        std::string tail_;         //尾部字符
    };

    //pb全拼接到一个string，每个输入内使用连接符一拼接，不同输入间使用连接符二拼接，连接符支持自定义，尾部字符支持自定义，支持全数据类型
    class ConnectAllToStringConfig final : public Config {
    public:
        explicit ConnectAllToStringConfig(const std::string &output, const std::vector<std::string> &source,
                                          DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                          const std::vector<std::string> &strategy, const std::string &first_connector,
                                          const std::string &second_connector, const std::string &tail)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              org_first_connector_(first_connector), first_connector_(first_connector),
              org_second_connector_(second_connector), second_connector_(second_connector), tail_(tail) {
            InvisibleCharacter::character_replace(first_connector_);
            InvisibleCharacter::character_replace(second_connector_);
        }

        ~ConnectAllToStringConfig() override = default;

        std::string get_config() override {
            std::string display = "connect_all_to_string:first_connector:";
            display.append(org_first_connector_);
            display.append(", second_connector:").append(org_second_connector_);
            display.append(", tail:").append(tail_);
            return display;
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        void compute_one_feature(const tensorflow::Feature &feat, std::pair<bool, std::string> &pair);

        std::string org_first_connector_; //原始连接符
        std::string first_connector_;     //连接符
        std::string org_second_connector_;//原始连接符
        std::string second_connector_;    //连接符
        std::string tail_;                //尾部字符
    };

    // hash
    class HashBucketConfig final : public Config {
    public:
        int64_t bucket_size_;
        bool concat_with_name_;

        explicit HashBucketConfig(const std::string &output, const std::vector<std::string> &source,
                                  DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                  const std::vector<std::string> &strategy, int64_t bucket_size, bool concat_with_name)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              bucket_size_(bucket_size), concat_with_name_(concat_with_name) {
        }
        ~HashBucketConfig() override = default;

        std::string get_config() override {
            std::string display = "hash:bucket_size:";
            display.append(std::to_string(bucket_size_)).append(", concat_with_name:");
            if (concat_with_name_) {
                display.append("true");
            } else {
                display.append("false");
            }
            return display;
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        void compute_one_feature(const tensorflow::Feature &feat, const std::string &concat,
                                 tensorflow::Feature *hfeature_feature);
    };

    //message过滤，根据指定的过滤字段和过滤条件，以及时间范围和对应的时间字段，过滤或命中符合的message
    class MessageFilterConfig final : public Config {
    public:
        explicit MessageFilterConfig(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy,
                                     const std::vector<std::string> &str_filter, const std::vector<bool> &str_hit,
                                     const std::vector<std::set<std::string>> &str_filter_dict,
                                     const std::vector<std::string> &int_filter, const std::vector<bool> &int_hit,
                                     const std::vector<std::set<int64_t>> &int_filter_dict,
                                     const std::string &eventtime_key, int64_t start_ms, int64_t end_ms);

        ~MessageFilterConfig() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        const std::vector<std::string> str_filter_;               //n个维度值在路径中对应的string字段
        const std::vector<bool> str_hit_;                         //n个string字段，获取命中或者获取未命中
        const std::vector<std::set<std::string>> str_filter_dict_;//n个string字段，对应的过滤条件
        const std::vector<std::string> int_filter_;               //n个维度值在路径中对应的int字段
        const std::vector<bool> int_hit_;                         //n个int字段，获取命中或者获取未命中
        const std::vector<std::set<int64_t>> int_filter_dict_;    //n个int字段，对应的过滤条件
        const std::string eventtime_key_;                         //时间戳在路径中对应的字段
        int64_t start_;                                           //防穿越，毫秒级
        int64_t end_;                                             //最久时间范围，毫秒级
    };

    class MessageFilterV2Config final : public Config {
    public:
        explicit MessageFilterV2Config(const std::string &output, const std::vector<std::string> &source,
                                       DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                       const std::vector<std::string> &strategy, const std::string &str_filter,
                                       const std::string &int_filter, const std::string &eventtime_key,
                                       int64_t start_ms, int64_t end_ms);

        ~MessageFilterV2Config() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        template<typename T>
        struct SourceIndex {
            T _value;
            int32_t _index = -1;

            std::string to_string() const {
                std::stringstream ss;
                ss << "value = [" << _value << "];index = [" << _index << "]";
                return ss.str();
            }

            // 定义operator<, 以作为map的key
            bool operator<(const SourceIndex &other) const {
                if (_value < other._value) {
                    return true;
                }
                if (other._value < _value) {
                    return false;
                }
                return _index < other._index;
            }
        };

        std::map<SourceIndex<std::string>, std::pair<bool, std::set<SourceIndex<std::string>>>>
        transform_str_filter(const std::string &filter_str);

        std::map<SourceIndex<std::string>, std::pair<bool, std::set<SourceIndex<int64_t>>>>
        transform_int_filter(const std::string &filter_str);

        const std::map<SourceIndex<std::string>, std::pair<bool, std::set<SourceIndex<std::string>>>>
                str_filter_;// string类型的过滤条件: <过滤字段, <hit or miss, set<过滤条件>>>

        const std::map<SourceIndex<std::string>, std::pair<bool, std::set<SourceIndex<int64_t>>>>
                int_filter_;// int64_t类型的过滤条件: <过滤字段, <hit or miss, set<过滤条件>>>

        const std::string eventtime_key_;//时间戳在路径中对应的字段
        int64_t start_;                  //防穿越，毫秒级
        int64_t end_;                    //最久时间范围，毫秒级
    };

    //从两个相同数据类型(暂时只支持int64)pb中获取有效值，第一个pb值不符配置或取不到，取第二个pb值，如果第二个取不到，返回-1
    class GetValidValueConfig : public Config {
    public:
        explicit GetValidValueConfig(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy, int32_t config,
                                     int64_t config_int64_value, float config_float_value, int64_t default_int64_value,
                                     float default_float_value, float precision)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), _config(config),
              _config_int64_value(config_int64_value), _config_float_value(config_float_value),
              _default_int64_value(default_int64_value), _default_float_value(default_float_value),
              _precision(precision) {
            if (unlikely(_config < 1 || _config > 3)) {
                THROW_ERROR("config error");
            }
        }
        virtual ~GetValidValueConfig() {
        }

        virtual std::string get_config() override {
            return "get_valid_value: _config:" + std::to_string(_config) +
                   "_config_int64_value: " + std::to_string(_config_int64_value) +
                   "_config_float_value: " + std::to_string(_config_float_value) +
                   "_default_int64_value: " + std::to_string(_default_int64_value) + "_default_float_value" +
                   std::to_string(_default_float_value);
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        void compute_one_feature(const tensorflow::Feature *input_feat1, const tensorflow::Feature *input_feat2,
                                 tensorflow::Feature *out);
        int32_t _config;
        int64_t _config_int64_value;
        float _config_float_value;
        int64_t _default_int64_value;
        float _default_float_value;
        float _precision;
    };

    //从两个相同数据类型pb中获取有效值，第一个pb值等于invalid或取不到，取第二个pb值，如果第二个取不到，返回空
    class GetValidValueV2Config : public Config {
    public:
        explicit GetValidValueV2Config(const std::string &output, const std::vector<std::string> &source,
                                       DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                       const std::vector<std::string> &strategy, const std::string &invalid)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), invalid_(invalid) {
            data_type_ = tensorflow::DT_INVALID;
        }
        virtual ~GetValidValueV2Config() {
        }

        virtual std::string get_config() override {
            std::string display = "get_valid_value_v2:invalid:";
            display.append(invalid_);
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        const std::string invalid_;     //无效值
        tensorflow::DataType data_type_;//数据类型
        void compute_one_feature(const tensorflow::Feature *input_feat1, const tensorflow::Feature *input_feat2,
                                 tensorflow::Feature *out);
        void compute_valid_feature(const tensorflow::Feature *input_feat, tensorflow::Feature *out);
    };

}// namespace phx_fe
