#pragma once
#include "common/hidict/dict_manager.h"
#include "config.h"
#include "phx-fe/ad_dict/ad_dict_manager.h"
#include "phx-fe/ad_dict/appinfo_dict.h"
#include "phx-fe/util/calc.h"
#include "phx-fe/util/log.h"
#include "phx-fe/util/util.h"
#include "seq_utils.h"
#include <cstdint>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>

namespace phx_fe {
    //用户行为在有效期间内的最小时间间隔
    class SeqHitIntervalConfig : public Config {
    public:
        explicit SeqHitIntervalConfig(const std::string &output, const std::vector<std::string> &source,
                                      DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                      const std::vector<std::string> &strategy, int64_t start, int64_t default_value)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), filter_compute_(start),
              default_value_(default_value) {
        }

        virtual ~SeqHitIntervalConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_hit_interval:";
            display.append(filter_compute_.display_start());
            display.append(", default_value:").append(std::to_string(default_value_));
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        SeqFilterCompute filter_compute_;
        int64_t default_value_;

        void compute_one_feature(const tensorflow::Feature &feat, std::unordered_map<int64_t, int64_t> &time_map,
                                 tensorflow::Feature *out, bool has_input);
        void fill_default_value(tensorflow::Feature *out);
    };

    //用户行为序列中appid对应数据之和
    class SeqHitSumConfig : public Config {
    public:
        explicit SeqHitSumConfig(const std::string &output, const std::vector<std::string> &source,
                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                 const std::vector<std::string> &strategy, int64_t start, float default_value,
                                 const std::string &default_type)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), filter_compute_(start),
              default_value_(default_value) {
            default_int_ = static_cast<int64_t>(default_value);
            if (default_type == "float") {
                default_type_ = tensorflow::DT_FLOAT;
            } else {
                default_type_ = tensorflow::DT_INT64;
            }
        }

        virtual ~SeqHitSumConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_hit_sum:";
            display.append(filter_compute_.display_start());
            display.append(", default_value:").append(std::to_string(default_value_));
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        SeqFilterCompute filter_compute_;
        float default_value_;
        int64_t default_int_;
        tensorflow::DataType default_type_;

        void compute_one_feature(const tensorflow::Feature &feat, std::unordered_map<int64_t, float> &float_sum_map,
                                 std::unordered_map<int64_t, int64_t> &int_sum_map, tensorflow::DataType &data_type,
                                 tensorflow::Feature *out, bool has_input);

        void fill_default_value(tensorflow::Feature *out, tensorflow::DataType &data_type);
    };
    //请求时间n天内，指定活跃周期中，输出活跃或不活跃的最后n个appid及时间
    class SeqDiffDailyConfig : public Config {
    public:
        explicit SeqDiffDailyConfig(const std::string &output, const std::vector<std::string> &source,
                                    DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                    const std::vector<std::string> &strategy, int64_t start, int64_t day_n,
                                    int64_t delta_day, bool status, int64_t clip_size)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), delta_day_(delta_day),
              status_(status), filter_compute_(start, day_n),
              top_n_compute_(static_cast<SortType>(SortType::ByTimestamp), clip_size) {
        }

        virtual ~SeqDiffDailyConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_diff_daily:";
            display.append(filter_compute_.display_start()).append(", ");
            display.append(filter_compute_.display_day_n()).append(", ");
            display.append(", delta_day:").append(std::to_string(delta_day_));
            display.append(", status:");
            if (status_) {
                display.append("1, clip_size:");
            } else {
                display.append("0, clip_size:");
            }
            display.append(", clip_size:").append(std::to_string(top_n_compute_.get_topn()));
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        int64_t delta_day_;//有效时间天数
        bool status_;      //true输出符合活跃条件的，false输出不符合活跃条件的
        SeqFilterCompute filter_compute_;
        SeqTopNCompute top_n_compute_;

        void filter_unuse_appid(std::vector<AppIdWithEventTime> &appid_info_vec,
                                std::unordered_map<int64_t, std::vector<int64_t>> &appid_info_map,
                                std::vector<AppIdWithEventTime *> &appid_filter_vec_ptr);
    };

    //请求时间n天内，指定活跃周期中，输出活跃或不活跃的最后n个appid及时间
    class SeqDiffV2Config : public Config {
    public:
        explicit SeqDiffV2Config(const std::string &output, const std::vector<std::string> &source,
                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                 const std::vector<std::string> &strategy, int64_t start, int64_t day_n,
                                 int64_t delta_day, bool status, int64_t clip_size)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), delta_day_(delta_day),
              status_(status), filter_compute_(start, day_n),
              top_n_compute_(static_cast<SortType>(SortType::ByTimestamp), clip_size) {
        }

        virtual ~SeqDiffV2Config() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_diff_v2:";
            display.append(filter_compute_.display_start()).append(", ");
            display.append(filter_compute_.display_day_n()).append(", ");
            display.append(", delta_day:").append(std::to_string(delta_day_));
            display.append(", status:");
            if (status_) {
                display.append("1, clip_size:");
            } else {
                display.append("0, clip_size:");
            }
            display.append(", clip_size:").append(std::to_string(top_n_compute_.get_topn()));
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        int64_t delta_day_;//有效时间天数
        bool status_;      //true输出符合活跃条件的，false输出不符合活跃条件的
        SeqFilterCompute filter_compute_;
        SeqTopNCompute top_n_compute_;

        void filter_unuse_appid(std::vector<AppIdWithEventTime> &appid_info_vec,
                                std::unordered_map<int64_t, std::vector<int64_t>> &appid_info_map,
                                std::vector<AppIdWithEventTime *> &appid_filter_vec_ptr);
    };

    //过滤防穿越的n天内的clip_size个数据，如果对应的value_list，value超出阈值的数据也过滤掉
    class SeqValDirectConfig : public Config {
    public:
        explicit SeqValDirectConfig(const std::string &output, const std::vector<std::string> &source,
                                    DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                    const std::vector<std::string> &strategy, int64_t start, int64_t day_n,
                                    int64_t micro_second, int64_t clip_size, float upper_bound)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              filter_compute_(start, day_n, 0, micro_second), clip_size_(clip_size),
              upper_bound_(upper_bound), micro_second_(micro_second) {
        }

        virtual ~SeqValDirectConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_val_direct:";
            display.append(filter_compute_.display_start()).append(", ");
            display.append(filter_compute_.display_day_n());
            display.append(", micro_second:").append(std::to_string(micro_second_));
            display.append(", clip_size:").append(std::to_string(clip_size_));
            display.append(", upper_bound:").append(std::to_string(upper_bound_));
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        SeqFilterCompute filter_compute_;
        int64_t clip_size_;//截断长度
        float upper_bound_;//阈值，超出阈值上线过滤
        int64_t micro_second_;

        void filter_upper_bound_value(std::vector<AppIdWithEventTime> &appid_info_vec,
                                      std::vector<std::vector<int64_t>> &appid_feat_value_index,
                                      const InputFeature *inf_value,
                                      std::unordered_map<AppIdWithEventTime *, tensorflow::Feature> &appid_values);
    };

    //过滤防穿越的n天内的clip_size个数据，如果对应的value_list，value超出阈值的数据也过滤掉
    class SeqValDirectV2Config final : public Config {
    public:
        struct Bound {
            float value_ = 0.0f;// 阈值
            bool flag_ = false; // 是否设置

            explicit Bound(float value) : value_(value), flag_(true) {
            }

            explicit Bound(bool flag) : flag_(flag) {
            }

            explicit Bound(float value, bool flag) : value_(value), flag_(flag) {
            }
        };

        explicit SeqValDirectV2Config(const std::string &output, const std::vector<std::string> &source,
                                      DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                      const std::vector<std::string> &strategy, int64_t start, int64_t day_n,
                                      int64_t hour_n, int64_t clip_size, const Bound &upper_bound,
                                      const Bound &lower_bound);

        explicit SeqValDirectV2Config(const std::string &output, const std::vector<std::string> &source,
                                      DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                      const std::vector<std::string> &strategy, int64_t start, int64_t day_n,
                                      int64_t hour_n, int64_t clip_size, Bound &&upper_bound, Bound &&lower_bound);

        ~SeqValDirectV2Config() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        void filter_bound_value(std::vector<AppIdWithEventTime> &appid_info_vec,
                                std::vector<std::vector<int64_t>> &appid_feat_value_index,
                                const InputFeature *inf_value,
                                std::unordered_map<AppIdWithEventTime *, tensorflow::Feature> &appid_values);

        SeqFilterCompute filter_compute_;
        int64_t clip_size_;// 截断长度
        Bound upper_bound_;// 上限阈值
        Bound lower_bound_;// 下限阈值
        int64_t hour_n_;   // 小时数，打印信息用
    };

    //交互特征抽取，根据item字段的值，抽取值相同的user字段中指定的对应特征
    class SeqByInterConfig : public Config {
    public:
        explicit SeqByInterConfig(const std::string &output, const std::vector<std::string> &source,
                                  DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                  const std::vector<std::string> &strategy, const std::string &inter_key,
                                  const std::vector<std::string> &fields)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), inter_key_(inter_key),
              fields_(fields) {
        }

        virtual ~SeqByInterConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_by_inter:inter_key:";
            display.append(inter_key_);
            display.append(", fields:[");
            for (auto &field_str: fields_) {
                display.append(field_str).append(",");
            }
            display.pop_back();
            display.append("]");
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        const std::string inter_key_;          //维度值在路径中对应的字段
        const std::vector<std::string> fields_;//最终抽取的字段

        void compute_one_feature(const tensorflow::Feature &feat,
                                 std::unordered_map<int64_t, std::vector<uint32_t>> &index_map,
                                 const InputFeature *inf_message, std::vector<tensorflow::Feature *> &out_feat);
    };

    //离线特征和近线特征合并，根据离线特征的最大时间戳，合并大于max时间的近线特征和离线特征，结果不可直接输出
    class SeqMergeConfig : public Config {
    public:
        explicit SeqMergeConfig(const std::string &output, const std::vector<std::string> &source,
                                DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                const std::vector<std::string> &strategy, const std::string &eventtime_key)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              eventtime_key_(eventtime_key), top_n_compute_(static_cast<SortType>(SortType::ByValue), 0, 0) {
        }

        virtual ~SeqMergeConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_merge:eventtime_key:";
            display.append(eventtime_key_);
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        const std::string eventtime_key_;//事件时间在路径中对应的字段
        SeqTopNCompute top_n_compute_;

        void fill_message_to_vec(const InputFeature *mess_value, int64_t &max,
                                 std::vector<std::pair<int64_t, const google::protobuf::Message *>> &time_vec);
    };

    //获取用户行为序列
    class SeqNConfig : public Config {
    public:
        explicit SeqNConfig(const std::string &output, const std::vector<std::string> &source,
                            DefaultValue &default_input_value, bool save, bool allow_empty_output,
                            const std::vector<std::string> &strategy, int64_t start, int64_t end, int32_t clip_size,
                            int64_t default_value)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              filter_compute_(start, -1, 0, end), default_value_(default_value),
              top_n_compute_(static_cast<SortType>(SortType::ByTimestamp), clip_size) {
        }
        virtual ~SeqNConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_n:";
            display.append(filter_compute_.display_start()).append(", ");
            display.append(filter_compute_.display_end());
            display.append(", clip_size:").append(std::to_string(top_n_compute_.get_topn()));
            display.append(", default_value:").append(std::to_string(default_value_));
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        SeqFilterCompute filter_compute_;
        int64_t default_value_;
        SeqTopNCompute top_n_compute_;
    };

    //用户行为序列最多(最后)的n个三级类目
    class SeqAppCategoryTopNConfig : public Config {
    public:
        explicit SeqAppCategoryTopNConfig(const std::string &output, const std::vector<std::string> &source,
                                          DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                          const std::vector<std::string> &strategy, int64_t start, int64_t topn,
                                          int64_t type, const std::string &default_value,
                                          hidict::DictCollector *dict_collector, const std::string &dict_name)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), filter_compute_(start),
              default_value_(default_value), top_n_compute_(static_cast<SortType>(type), topn), dict_name_(dict_name) {
            dict_collector_ = (AdDict::AdDictCollector *) (dict_collector);
            auto dict_ptr = dict_collector_->get_dict(dict_name);
            if (dict_ptr == nullptr) {
                THROW_ERROR("can not find dict [" + dict_name + "]; output = [" + output + "]");
            }
        }

        virtual ~SeqAppCategoryTopNConfig() {
        }

        std::string get_config() override {
            std::string display = "seq_appcategory_topn:";
            display.append(filter_compute_.display_start()).append(", ");
            display.append(top_n_compute_.get_config());
            display.append(", default_value:").append(default_value_);
            display.append("dict_name:").append(dict_name_);
            return display;
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        SeqFilterCompute filter_compute_;
        std::string default_value_;
        SeqTopNCompute top_n_compute_;
        AdDict::AdDictCollector *dict_collector_;
        std::string dict_name_;
        static void fill_class_vec(std::vector<AppIdWithEventTime> &appid_vec,
                                   const std::vector<const phx::AppInfoDict *> &query_dict_result,
                                   std::vector<std::vector<ClassNameWithEventTime>> &class_count);
    };

    // 序列id转换成三级类目
    class SeqApp2CategoryConfig : public Config {
    public:
        explicit SeqApp2CategoryConfig(const std::string &output, const std::vector<std::string> &source,
                                       DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                       const std::vector<std::string> &strategy, int64_t start, bool dedup,
                                       int64_t clip_size, const std::string &default_value,
                                       hidict::DictCollector *dict_collector, const std::string &dict_name)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), dedup_(dedup),
              clip_size_(clip_size), default_value_(default_value), filter_compute_(start),
              top_n_compute_(static_cast<SortType>(SortType::ByTimestamp), -1), dict_name_(dict_name) {
            dict_collector_ = (AdDict::AdDictCollector *) (dict_collector);
            auto dict_ptr = dict_collector_->get_dict(dict_name);
            if (dict_ptr == nullptr) {
                THROW_ERROR("can not find dict [" + dict_name + "]; output = [" + output + "]");
            }
        }
        virtual ~SeqApp2CategoryConfig() {
        }

        std::string get_config() override {
            std::string display = "seq_app2category:";
            display.append(filter_compute_.display_start()).append(", dedup:");
            display.append(dedup_ ? "true" : "false");
            display.append(", clip_size:")
                    .append(std::to_string(clip_size_))
                    .append(", default_value:")
                    .append(default_value_);
            return display;
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        //去重参数，true去重，flase不去重
        bool dedup_;
        int64_t clip_size_;
        std::string default_value_;
        SeqFilterCompute filter_compute_;
        SeqTopNCompute top_n_compute_;
        AdDict::AdDictCollector *dict_collector_;
        std::string dict_name_;
        void compute_one_feature(std::vector<AppIdWithEventTime *> &appid_info_vec_ptr,
                                 std::vector<tensorflow::Feature *> &out_int_feat);
        void compute_one_featurelist(std::vector<AppIdWithEventTime *> &appid_info_vec_ptr,
                                     std::vector<tensorflow::FeatureList *> &out_int_featlist);
    };

    //过滤防穿越的n天内的请求时间前后n小时的数据
    class SeqNHourConfig : public Config {
    public:
        explicit SeqNHourConfig(const std::string &output, const std::vector<std::string> &source,
                                DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                const std::vector<std::string> &strategy, int64_t start, int64_t day_n, int64_t hour)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              filter_compute_(start, day_n), hour_(hour) {
        }

        virtual ~SeqNHourConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_n_hour:";
            display.append(filter_compute_.display_start()).append(", ");
            display.append(filter_compute_.display_day_n()).append(", ");
            display.append(", hour:").append(std::to_string(hour_));
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        SeqFilterCompute filter_compute_;
        int64_t hour_;//请求时间前后n小时

        void filter_appid_by_hour(int64_t now, std::vector<AppIdWithEventTime> &appid_info_vec,
                                  std::vector<const AppIdWithEventTime *> &appid_ptr_vec);
    };

    //输出用户行为序列的指定排序方式(三种，支持正序或逆序)前n个，以及对应的排序因子序列
    class SeqTopNV2Config : public Config {
    public:
        explicit SeqTopNV2Config(const std::string &output, const std::vector<std::string> &source,
                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                 const std::vector<std::string> &strategy, int64_t topn, int64_t type, int64_t reserve)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              top_n_compute_(static_cast<SortType>(type), topn, reserve) {
        }

        virtual ~SeqTopNV2Config() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_topn_v2:";
            display.append(top_n_compute_.get_config()).append(", ");
            display.append(top_n_compute_.get_reserve());
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        SeqTopNCompute top_n_compute_;

        void fill_appid_vec_with_index(const tensorflow::Feature &appid_feat, const tensorflow::Feature &time_feat,
                                       std::vector<AppIdWithEventTime> &appid_info_vec,
                                       std::vector<int64_t> &appid_index);

        template<typename T>
        void fill_feature_value(std::vector<AppIdWithEventTime> &appid_info_vec,
                                std::vector<std::vector<int64_t>> &appid_feat_value_index,
                                const InputFeature *inf_value,
                                std::unordered_map<AppIdWithEventTime *, T> &appid_values);
        void get_value_type(const InputFeature *inf_value, DataType &type);
    };

    //有效期间内统计次数的基类
    class SeqCountConfig : public Config {
    public:
        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) {
            LogDebug("------------ compute {} start ------------", output_);
            bool need_filter = input_values.size() == 4;
            const Value *item_value = nullptr;
            std::unordered_map<int64_t, int64_t> count_map;
            bool has_input = false;
            if (need_filter) {
                const Value *appid_value = get_value(input_values, inputs_, 0);
                const Value *eventtime_value = get_value(input_values, inputs_, 1);
                int64_t now = get_feature_one_int64(input_values, inputs_, 2);
                item_value = get_value(input_values, inputs_, 3);
                const InputFeature *inf_appid = nullptr;
                const InputFeature *inf_eventtime = nullptr;

                uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

                //防穿越，有效数据提取到count_map中计数
                for (uint32_t i = 0; i < input_size; i++) {
                    inf_appid = &appid_value->ifeatures[i];
                    inf_eventtime = &eventtime_value->ifeatures[i];

                    if (likely(inf_appid->feature && inf_eventtime->feature)) {
                        has_input |= filter_compute_.fill_count_map(*inf_appid->feature, *inf_eventtime->feature, now,
                                                                    count_map);
                    } else if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
                        uint32_t list_size = std::min(inf_appid->feature_list->feature_size(),
                                                      inf_eventtime->feature_list->feature_size());
                        for (uint32_t j = 0; j < list_size; j++) {
                            has_input |= filter_compute_.fill_count_map(inf_appid->feature_list->feature(j),
                                                                        inf_eventtime->feature_list->feature(j), now,
                                                                        count_map);
                        }
                    }
                }
            } else {
                const Value *appid_value = get_value(input_values, inputs_, 0);
                item_value = get_value(input_values, inputs_, 1);
                const InputFeature *inf_appid = nullptr;
                uint32_t input_size = appid_value->ifeatures.size();
                //无需防穿越过滤，提取到count_map中计数
                for (uint32_t i = 0; i < input_size; i++) {
                    inf_appid = &appid_value->ifeatures[i];

                    if (likely(inf_appid->feature)) {
                        auto &appid_vec = inf_appid->feature->int64_list().value();
                        for (auto &appid: appid_vec) {
                            count_map[appid]++;
                        }
                    } else if (likely(inf_appid->feature_list)) {
                        uint32_t list_size = inf_appid->feature_list->feature_size();
                        for (uint32_t j = 0; j < list_size; j++) {
                            auto &appid_vec = inf_appid->feature_list->feature(j).int64_list().value();
                            for (auto &appid: appid_vec) {
                                count_map[appid]++;
                            }
                        }
                    }
                }
                has_input = !count_map.empty();
            }
            if (item_value == nullptr)
                return false;
            generate_output(item_value, count_map, output, has_input);
            LogDebug("------------ compute {} done ------------", output_);
            return true;
        }

    protected:
        SeqFilterCompute filter_compute_;

        explicit SeqCountConfig(const std::string &output, const std::vector<std::string> &source,
                                DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                const std::vector<std::string> &strategy, int64_t start)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), filter_compute_(start) {
        }
        virtual ~SeqCountConfig() {
        }
        virtual void generate_output(const Value *item_value, std::unordered_map<int64_t, int64_t> &count_map,
                                     Output &output, bool has_input) = 0;
        virtual void fill_value_dtype(tensorflow::DataType &data_type) {
            data_type = tensorflow::DT_INT64;
        }
    };

    //用户行为在有效期间内出现次数
    class SeqHitCountV1Config : public SeqCountConfig {
    public:
        explicit SeqHitCountV1Config(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy, int64_t start, int32_t max_num,
                                     int64_t default_value)
            : SeqCountConfig(output, source, default_input_value, save, allow_empty_output, strategy, start),
              max_num_(max_num), default_value_(default_value) {
        }

        virtual ~SeqHitCountV1Config() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_hit_count_v1:start:";
            display.append(filter_compute_.display_start()).append(", max_num:").append(std::to_string(max_num_));
            display.append(", default_value:").append(std::to_string(default_value_));
            return display;
        }

    private:
        int32_t max_num_;
        int64_t default_value_;

        virtual void compute_one_feature(const tensorflow::Feature &feat,
                                         std::unordered_map<int64_t, int64_t> &count_map, tensorflow::Feature *out,
                                         bool has_input);
        virtual void fill_default_value(tensorflow::Feature *out) {
            if (out->int64_list().value_size() < 1) {
                out->mutable_int64_list()->add_value(default_value_);
            }
        }
        virtual void generate_output(const Value *item_value, std::unordered_map<int64_t, int64_t> &count_map,
                                     Output &output, bool has_input) override;
    };

    //用户行为在有效期间内出现次数
    class SeqHitCountV2Config : public SeqCountConfig {
    public:
        explicit SeqHitCountV2Config(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy, int64_t start, int32_t max_num,
                                     int64_t default_value)
            : SeqCountConfig(output, source, default_input_value, save, allow_empty_output, strategy, start),
              max_num_(max_num), default_value_(default_value) {
        }

        virtual ~SeqHitCountV2Config() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_hit_count_v2:start:";
            display.append(filter_compute_.display_start()).append(", max_num:").append(std::to_string(max_num_));
            display.append(", default_value:").append(std::to_string(default_value_));
            return display;
        }

    private:
        int32_t max_num_;
        int64_t default_value_;

        virtual void compute_one_feature(const tensorflow::Feature &feat,
                                         std::unordered_map<int64_t, int64_t> &count_map, tensorflow::Feature *out_bool,
                                         tensorflow::Feature *out_count, bool has_input);
        virtual void fill_default_value(tensorflow::Feature *out_bool, tensorflow::Feature *out_count) {
            if (out_bool->int64_list().value_size() < 1) {
                out_bool->mutable_int64_list()->add_value(0);
            }
            if (out_count->int64_list().value_size() < 1) {
                out_count->mutable_int64_list()->add_value(default_value_);
            }
        }
        virtual void generate_output(const Value *item_value, std::unordered_map<int64_t, int64_t> &count_map,
                                     Output &output, bool has_input) override;
    };

    //用户行为在有效期间内出现次数
    class SeqHitCountV3Config : public Config {
    public:
        enum class DataType { int64, string };

        explicit SeqHitCountV3Config(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy, int64_t start, const DataType &data_type,
                                     int32_t max_num, int64_t default_value)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), _filter_compute(start),
              _data_type(data_type), _max_num(max_num), _default_value(default_value) {
        }

        std::string get_config() override {
            std::string display = "seq_hit_count_v3:start:";
            display.append(_filter_compute.display_start())
                    .append(", data_type:")
                    .append(_data_type == DataType::int64 ? "int64" : "string")
                    .append(", max_num:")
                    .append(std::to_string(_max_num))
                    .append(", default_value:")
                    .append(std::to_string(_default_value));
            return display;
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        template<typename T>
        bool compute_(const std::vector<const Output *> &input_values, Output &output);

        template<typename T>
        void generate_output(const Value *item_value, const std::unordered_map<T, int64_t> &count_map, Output &output,
                             bool has_input);

        // int64版本
        void compute_one_feature(const tensorflow::Feature &feat, const std::unordered_map<int64_t, int64_t> &count_map,
                                 tensorflow::Feature *out, bool has_input);

        // int64版本
        void process_appid(const tensorflow::Feature &inf_appid, std::unordered_map<int64_t, int64_t> &count_map) {
            for (const auto &appid: inf_appid.int64_list().value()) {
                count_map[appid]++;
            }
        }

        // string版本
        void compute_one_feature(const tensorflow::Feature &feat,
                                 const std::unordered_map<std::string, int64_t> &count_map, tensorflow::Feature *out,
                                 bool has_input);

        // string版本
        void process_appid(const tensorflow::Feature &inf_appid, std::unordered_map<std::string, int64_t> &count_map) {
            for (const auto &appid: inf_appid.bytes_list().value()) {
                count_map[appid]++;
            }
        }

        void fill_default_value(tensorflow::Feature *out) {
            if (out->int64_list().value_size() < 1) {
                out->mutable_int64_list()->add_value(_default_value);
            }
        }

        SeqFilterCompute _filter_compute;
        const DataType _data_type;
        int32_t _max_num;
        int64_t _default_value;
    };

    // 计算ctr，返回num_click/num_expo 或默认值
    class StatCtrConfig : public Config {
    public:
        explicit StatCtrConfig(const std::string &output, const std::vector<std::string> &source,
                               DefaultValue &default_value_map, bool save, bool allow_empty_output,
                               const std::vector<std::string> &strategy, int64_t min_expo, float default_value)
            : Config(output, source, default_value_map, save, allow_empty_output, strategy), min_expo_(min_expo),
              default_value_(default_value) {
        }

        virtual ~StatCtrConfig() override = default;

        virtual std::string get_config() override {
            return "stat_ctr:min_expo:" + std::to_string(min_expo_) +
                   ", default_value:" + std::to_string(default_value_);
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

        virtual void compute_one_feature(const tensorflow::Feature &click_feat, const tensorflow::Feature &expo_feat,
                                         tensorflow::Feature *out);
        void fill_default_value(tensorflow::Feature *out);

        int64_t min_expo_;
        float default_value_;
    };

    class StatSmoothCtrConfig final : public StatCtrConfig {
    public:
        explicit StatSmoothCtrConfig(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_value_map, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy, int64_t min_expo, float default_value,
                                     float alpha, float beta)
            : StatCtrConfig(output, source, default_value_map, save, allow_empty_output, strategy, min_expo,
                            default_value),
              alpha_(alpha), beta_(beta) {
        }

        ~StatSmoothCtrConfig() override = default;

        std::string get_config() override {
            return "stat_smooth_ctr:min_expo:" + std::to_string(phx_fe::StatCtrConfig::min_expo_) +
                   ", alpha:" + std::to_string(alpha_) + ", beta:" + std::to_string(beta_) +
                   ",default_value:" + std::to_string(phx_fe::StatSmoothCtrConfig::default_value_);
        }

    private:
        void compute_one_feature(const tensorflow::Feature &click_feat, const tensorflow::Feature &expo_feat,
                                 tensorflow::Feature *out) override;

        float alpha_;
        float beta_;
    };

    // 对数据离散化,输入支持int64,float类型
    class StatCtrBucketConfig final : public Config {
    public:
        enum BucketType {
            BUCKET_INT = 1,
            BUCKET_LOG,
            BUCKET_DIRECT_FLOAT,
            BUCKET_LOG_V2,
        };

        explicit StatCtrBucketConfig(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_value_map, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy, float size, float b, float a, float k,
                                     BucketType bucket_type, float default_value)
            : Config(output, source, default_value_map, save, allow_empty_output, strategy), size_(size), b_(b), a_(a),
              k_(k), bucket_type_(bucket_type), default_value_(default_value) {
        }

        ~StatCtrBucketConfig() override = default;

        std::string get_config() override {
            return "stat_ctr_bucket:size:" + std::to_string(size_) +
                   ", bucket_type:" + std::to_string(static_cast<int64_t>(bucket_type_));
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out);
        void fill_default_value(tensorflow::Feature *out);

        float size_;//DIRECT_FLOAT缩放因子，默认1000
        float b_;   //DIRECT_FLOAT因子，默认1
        float a_;   //DIRECT_FLOAT因子，默认1，调节输出范围
        float k_;   //离散化函数类型

        BucketType bucket_type_;
        float default_value_;
    };

    // message序列融合，返回参数列表中第一个非空的message序列
    class SeqCoalesceConfig : public Config {
    public:
        explicit SeqCoalesceConfig(const std::string &output, const std::vector<std::string> &source,
                                   DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                   const std::vector<std::string> &strategy)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy) {
        }

        virtual ~SeqCoalesceConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_coalesce";
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;
    };

    class SeqPbClip : public Config {
    public:
        explicit SeqPbClip(const std::string &output, const std::vector<std::string> &source,
                           DefaultValue &default_input_value, bool save, bool allow_empty_output,
                           const std::vector<std::string> &strategy, int64_t start_day, int64_t end_day,
                           const std::string &timestamp_field_name)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), start_day_(start_day),
              end_day_(end_day), timestamp_field_name_(timestamp_field_name) {
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;
        std::string get_config() override {
            std::string display = "seq_pb_clip:";
            display.append("start_day=[")
                    .append(std::to_string(start_day_))
                    .append("],")
                    .append("end_day=[")
                    .append(std::to_string(end_day_))
                    .append("], event time field name = [")
                    .append(timestamp_field_name_)
                    .append("]");
            return display;
        }

    private:
        int64_t start_day_ = -1;
        int64_t end_day_ = 999;
        std::string timestamp_field_name_;
    };

    //优先级从高到低的三个序列中，按输入顺序，依次获取有效值。
    class SeqPriorityMergeConfig : public Config {
    public:
        explicit SeqPriorityMergeConfig(const std::string &output, const std::vector<std::string> &source,
                                        DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                        const std::vector<std::string> &strategy, int64_t illegal_int,
                                        float illegal_float, std::string illegal_string)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              illegal_int_(illegal_int), illegal_float_(illegal_float), illegal_string_(illegal_string) {
        }

        virtual ~SeqPriorityMergeConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_priority_merge:illegal_int:";
            display.append(std::to_string(illegal_int_));
            display.append(", illegal_float:").append(std::to_string(illegal_float_));
            display.append(", illegal_string:").append(illegal_string_);
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        int64_t illegal_int_;       //非法值，默认0
        float illegal_float_;       //非法值，默认0
        std::string illegal_string_;//非法值，默认空字符串
        const float espilon_ = 1e-6;

        void compute_one_feature(const tensorflow::Feature *first_feature, const tensorflow::Feature *second_feature,
                                 const tensorflow::Feature *third_feature, tensorflow::Feature *out);
    };
    class SeqCrossHashBits : public Config {
    public:
        explicit SeqCrossHashBits(const std::string &output, const std::vector<std::string> &source,
                                  DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                  const std::vector<std::string> &strategy, int32_t clip_size)

            : Config(output, source, default_input_value, save, allow_empty_output, strategy), clip_size_(clip_size) {
        }
        virtual ~SeqCrossHashBits() {
        }

        std::string get_config() override {
            std::string display = "seq_cross_hash_bits:";
            display.append("clip_size:").append(std::to_string(clip_size_));
            return display;
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;
        void ComputeOneFeature(const tensorflow::Feature &feature_1, const tensorflow::Feature &feature_2,
                               tensorflow::Feature *output);
        std::vector<int64_t> MurMurHash(const tensorflow::Feature &feature) const;

    private:
        int32_t clip_size_;
        int64_t default_output_value_;
    };

    // 计算序列中每个值在整个序列总和的占比
    class SeqRatioConfig : public Config {
    public:
        explicit SeqRatioConfig(const std::string &output, const std::vector<std::string> &source,
                                DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                const std::vector<std::string> &strategy, float default_value)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              default_value_(default_value) {
        }

        virtual ~SeqRatioConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_ratio:";
            display.append("default_value:").append(std::to_string(default_value_));
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        float default_value_;
        void compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out);
    };

    // 计算两个序列中每一项的比值
    class SeqDivConfig : public Config {
    public:
        explicit SeqDivConfig(const std::string &output, const std::vector<std::string> &source,
                              DefaultValue &default_input_value, bool save, bool allow_empty_output,
                              const std::vector<std::string> &strategy, float default_value)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              default_value_(default_value) {
        }

        virtual ~SeqDivConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_div:";
            display.append("default_value:").append(std::to_string(default_value_));
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        float default_value_;
        void compute_one_feature(const tensorflow::Feature &feat1, const tensorflow::Feature &feat2,
                                 tensorflow::Feature *out);
    };

    // 判断指定数据是否出现，同时若出现则提取对应字段的其他值
    class SeqHitValueV2Config : public Config {
    public:
        explicit SeqHitValueV2Config(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy, int64_t default_int64_value,
                                     float default_float_value, std::string default_string_value)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              default_int64_value_(default_int64_value), default_float_value_(default_float_value),
              default_string_value_(std::move(default_string_value)) {
        }

        virtual ~SeqHitValueV2Config() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_hit_value_v2:";
            display.append("default_int64_value:").append(std::to_string(default_int64_value_));
            display.append(",default_float_value:").append(std::to_string(default_float_value_));
            display.append(",default_string_value:").append(default_string_value_);
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        int64_t default_int64_value_;
        float default_float_value_;
        std::string default_string_value_;
        void compute_one_bool_feature(
                const tensorflow::Feature &feat,
                const std::unordered_map<int64_t, std::map<int64_t, std::vector<int64_t>>> &appid_idx_map,
                tensorflow::Feature *out);
        void compute_one_value_feature(
                const tensorflow::Feature &feat, const InputFeature *inf_value,
                const std::unordered_map<int64_t, std::map<int64_t, std::vector<int64_t>>> &appid_idx_map,
                tensorflow::DataType &data_type, tensorflow::Feature *out);
    };

    //筛选特定的appid和对应的n个数据序列
    class SeqHitListConfig : public Config {
    public:
        explicit SeqHitListConfig(const std::string &output, const std::vector<std::string> &source,
                                  DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                  const std::vector<std::string> &strategy)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy) {
        }

        virtual ~SeqHitListConfig() {
        }

        virtual std::string get_config() override {
            return "seq_hit_list";
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        void compute_one_input(const tensorflow::Feature &appid_feat,
                               std::vector<const tensorflow::Feature *> &list_fea,
                               std::unordered_map<int64_t, std::vector<tensorflow::Feature>> &value_map);
        void compute_one_feature(const tensorflow::Feature &feat,
                                 std::unordered_map<int64_t, std::vector<tensorflow::Feature>> &value_map,
                                 std::vector<tensorflow::DataType> &list_default_types,
                                 std::vector<tensorflow::Feature *> out_feat);
    };

    // Traits：根据T获取appid_vec
    template<typename T>
    struct AppIdVecGetter;

    // int64_t版本
    template<>
    struct AppIdVecGetter<int64_t> {
        static const google::protobuf::RepeatedField<int64_t> &get(const tensorflow::Feature &feat) {
            return feat.int64_list().value();
        }
    };

    // std::string版本
    template<>
    struct AppIdVecGetter<std::string> {
        static const google::protobuf::RepeatedPtrField<std::string> &get(const tensorflow::Feature &feat) {
            return feat.bytes_list().value();
        }
    };

    // 针对T为string
    template<typename T>
    typename std::enable_if<std::is_same<T, std::string>::value, void>::type
    add_id_to_outfeat(const T &id, tensorflow::Feature *out_feat) {
        out_feat->mutable_bytes_list()->add_value(id);
    }

    // 针对T为int64
    template<typename T>
    typename std::enable_if<std::is_same<T, int64_t>::value, void>::type
    add_id_to_outfeat(const T &id, tensorflow::Feature *out_feat) {
        out_feat->mutable_int64_list()->add_value(id);
    }

    //筛选特定的appid和对应的n个数据序列
    class SeqHitListV2Config : public Config {
    public:
        enum class DataType { int64, string };
        explicit SeqHitListV2Config(const std::string &output, const std::vector<std::string> &source,
                                    DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                    const std::vector<std::string> &strategy, const DataType &data_type)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), _data_type(data_type) {
        }

        ~SeqHitListV2Config() override = default;

        std::string get_config() override {
            return std::string("seq_hit_list_v2, data_type: ") + (_data_type == DataType::int64 ? "int64" : "string");
        }

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        template<typename T>
        void compute_one_input(const tensorflow::Feature &appid_feat,
                               std::vector<const tensorflow::Feature *> &list_fea,
                               std::unordered_map<T, std::vector<tensorflow::Feature>> &value_map);
        template<typename T>
        void compute_one_feature(const tensorflow::Feature &feat,
                                 std::unordered_map<T, std::vector<tensorflow::Feature>> &value_map,
                                 std::vector<tensorflow::DataType> &list_default_types,
                                 std::vector<tensorflow::Feature *> out_feat);

        const DataType _data_type;
    };

    //特征过滤，根据指定字段的值，抽取前n个相同的字段中指定的对应特征
    class SeqTopnDirectConfig : public Config {
    public:
        explicit SeqTopnDirectConfig(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy, const std::string &filter_key,
                                     const std::vector<std::string> &fields, int64_t topn, int64_t reserve)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy), filter_key_(filter_key),
              fields_(fields), top_n_compute_(static_cast<SortType>(SortType::ByValue), topn, reserve) {
        }

        virtual ~SeqTopnDirectConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_topn_direct:filter_key:";
            display.append(filter_key_);
            display.append(", fields:[");
            for (auto &field_str: fields_) {
                display.append(field_str).append(",");
            }
            display.pop_back();
            display.append("], ");
            display.append(top_n_compute_.get_config()).append(", ");
            display.append(top_n_compute_.get_reserve());
            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        const std::string filter_key_;         //维度值在路径中对应的字段
        const std::vector<std::string> fields_;//最终抽取的字段
        SeqTopNCompute top_n_compute_;
    };

    // 时间序列平均时间间隔，返回float类型
    class SeqAvgIntervalConfig final : public Config {
    public:
        enum TimeType {
            Day = 1,//天级别
            Hour,   //小时级别
        };

        explicit SeqAvgIntervalConfig(const std::string &output, const std::vector<std::string> &source,
                                      DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                      const std::vector<std::string> &strategy, TimeType time_type,
                                      float one_default_value, float empty_default_value);

        ~SeqAvgIntervalConfig() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        void fill_ifeature_to_vec(const InputFeature *hf, std::vector<int64_t> &vec);

        void fill_feature_to_vec(const tensorflow::Feature &feat, std::vector<int64_t> &vec);

        TimeType time_type_;
        float one_default_value_;  //序列长度为1时的默认值
        float empty_default_value_;//序列长度为0时的默认值
    };

    // 计算全局的min/max/avg或聚合的指标
    class SeqStatisticsConfig final : public Config {
    public:
        explicit SeqStatisticsConfig(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy, const std::string &math_type);

        ~SeqStatisticsConfig() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        std::vector<std::string> math_type_;
    };

    class SeqSortConfig final : public Config {
    public:
        explicit SeqSortConfig(const std::string &output, const std::vector<std::string> &source,
                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                               const std::vector<std::string> &strategy, const std::string &sort_cols,
                               const std::string &sort_orders);

        ~SeqSortConfig() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        enum class Order { desc, asc };

        std::vector<std::pair<std::size_t, Order>> orders_;// 保证排序规则按配置顺序，不宜使用map
    };

    class SeqFlattenConfig final : public Config {
    public:
        explicit SeqFlattenConfig(const std::string &output, const std::vector<std::string> &source,
                                  DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                  const std::vector<std::string> &strategy, const std::string &from_lv1,
                                  const std::string &from_lv2, const std::string &repeated_field);

        ~SeqFlattenConfig() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        std::vector<std::string> from_lv1_;
        std::vector<std::string> from_lv2_;
        std::string repeated_field_;
    };

    class SeqArithmeticConfig final : public Config {
    public:
        explicit SeqArithmeticConfig(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy, const std::string &math_type);

        ~SeqArithmeticConfig() override = default;

        std::string get_config() override;

        bool compute(const std::vector<const Output *> &input_values, Output &output) override;

    private:
        enum class Mathematic { Add, Sub, Mul } math_type_;

        template<typename T>
        T cacl(const T &a, const T &b);
    };

    template<typename T>
    inline T SeqArithmeticConfig::cacl(const T &a, const T &b) {
        switch (math_type_) {
            case Mathematic::Add:
                return a + b;
            case Mathematic::Sub:
                return a - b;
            case Mathematic::Mul:
                return a * b;
            default:
                THROW_ERROR("Invalid math_type_");
        }
    }

    //一定时间范围内，根据输入的条件和pb比较，过滤后输出appid最后的n个，以及对应的事件事件和给定的pb的value
    class SeqFilterConfig : public Config {
    public:
        explicit SeqFilterConfig(const std::string &output, const std::vector<std::string> &source,
                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                 const std::vector<std::string> &strategy, int64_t start, int64_t day_n,
                                 int64_t clip_size, const std::string &default_value,
                                 const std::vector<std::string> &filter_dicts)
            : Config(output, source, default_input_value, save, allow_empty_output, strategy),
              default_value_(default_value), filter_compute_(start, day_n),
              top_n_compute_(static_cast<SortType>(SortType::ByTimestamp), clip_size) {
            for (const auto &filter_cond: filter_dicts) {
                auto splited = Calc::split_string(filter_cond, ":");
                if (unlikely(splited.size() < 2)) {
                    THROW_ERROR("filter cond invalid, split num < 2:[" + filter_cond + "], config = [" + output + "]");
                }
                FilterDict filter;
                if (splited[0] == "int64_filter") {
                    filter.kind_case = tensorflow::Feature::kInt64List;
                    size_t source_index = 0;
                    if (GetSourceIndex(splited[1], source_index)) {
                        filter.source_index = source_index;
                        filter_dicts_.emplace_back(std::move(filter));
                    } else {
                        auto conds = Calc::split_string(splited[1], ",");
                        try {
                            for (const auto &num: conds) {
                                filter.int64_filter.emplace(std::stol(num));
                            }
                            if (unlikely(filter.int64_filter.empty())) {
                                THROW_ERROR("int64_filter is empty; config = [" + output + "]");
                            } else {
                                filter_dicts_.emplace_back(std::move(filter));
                            }
                        } catch (const std::exception &e) {
                            THROW_ERROR("parse int64 filter failed! config = [" + output + "]; int64_filer = [" +
                                        filter_cond + "]");
                        }
                    }

                } else if (splited[0] == "float_filter") {
                    filter.kind_case = tensorflow::Feature::kFloatList;
                    size_t source_index = 0;
                    if (GetSourceIndex(splited[1], source_index)) {
                        filter.source_index = source_index;
                        filter_dicts_.emplace_back(std::move(filter));

                    } else {
                        auto conds = Calc::split_string(splited[1], ",");
                        try {
                            for (const auto &num: conds) {
                                filter.float_filter.emplace(std::stof(num));
                            }
                            if (unlikely(filter.float_filter.empty())) {
                                THROW_ERROR("float_filter is empty; config = [" + output + "]");
                            } else {
                                filter_dicts_.emplace_back(std::move(filter));
                            }
                        } catch (const std::exception &e) {
                            THROW_ERROR("parse int64 float_filter failed! config = [" + output + "]; float_filter = [" +
                                        filter_cond + "]");
                        }
                    }
                } else if (splited[0] == "str_filter") {
                    filter.kind_case = tensorflow::Feature::kBytesList;
                    size_t source_index = 0;
                    if (GetSourceIndex(splited[1], source_index)) {
                        filter.source_index = source_index;
                        filter_dicts_.emplace_back(std::move(filter));

                    } else {
                        auto str_filters = Calc::split_string(splited[1], ",");
                        filter.str_filter.insert(str_filters.begin(), str_filters.end());
                        if (unlikely(filter.str_filter.empty())) {
                            THROW_ERROR("str_filter is empty; config = [" + output + "]");
                        } else {
                            filter_dicts_.emplace_back(std::move(filter));
                        }
                    }
                } else {
                    THROW_ERROR("not supported filter type = [" + splited[0] + "]");
                }
            }
        }

        virtual ~SeqFilterConfig() {
        }

        virtual std::string get_config() override {
            std::string display = "seq_filter:";
            display.append(filter_compute_.display_start()).append(", ");
            display.append(filter_compute_.display_day_n());
            display.append(", clip_size:").append(std::to_string(top_n_compute_.get_topn()));
            display.append(", filter:[");
            // for (auto &set: filter_dict_) {
            //     display.append("[");
            //     for (auto &filter_str: set) {
            //         display.append(filter_str).append(",");
            //         ;
            //     }
            //     display.pop_back();
            //     display.append("]");
            // }
            display.append("]").append(", default_value:").append(default_value_);

            return display;
        }

        virtual bool compute(const std::vector<const Output *> &input_values, Output &output) override;
        struct FilterDict {
            tensorflow::Feature::KindCase kind_case = tensorflow::Feature::KindCase::KIND_NOT_SET;
            std::unordered_set<std::string> str_filter;
            std::unordered_set<float> float_filter;
            std::unordered_set<int64_t> int64_filter;
            int32_t source_index = -1;

            std::string to_string() const {
                std::stringstream ss;
                ss << "kind case = [" << std::to_string(kind_case) << "];"
                   << "source index = " << source_index;
                return ss.str();
            }
        };

    private:
        std::string default_value_;
        std::vector<FilterDict> filter_dicts_;
        SeqFilterCompute filter_compute_;
        SeqTopNCompute top_n_compute_;

        FilterDict FeatureToFilterDicts(const tensorflow::Feature *fea, tensorflow::Feature::KindCase kind_case);
        bool InFilterDict(const FilterDict *filter_dict, const tensorflow::Feature *feature_to_check,
                          int32_t value_index);
        /**
         * @brief 根据过滤条件full_filter_dicts过滤appid、event_time和inf_value
         * 
         * @param appid_info_vec 输入放穿越后的app_id与event_time, appid_info_vec[i]在防穿越前的索引位置为appid_feat_value_index[i]
         * @param filter_conds_to_check 要检查的过滤条件,需要通过防穿越前的索引取到对应的值
         * @param appid_feat_value_index appid_info_vec中的元素在防穿越前的位置索引
         * @param inf_value 与appid关联的值，根据appid的过滤结果进行输出
         * @param appid_values AppIdWithEventTime*到inf_value的映射，AppIdWithEventTime*为appid_info_vec元素中的地址
         * @param appid_filter_vec_ptr 过滤后的AppIdWithEventTime*
         * @param full_filter_dicts 过滤词典
         */
        void FilterFeature(std::vector<AppIdWithEventTime> &appid_info_vec,
                           std::vector<const InputFeature *> &filter_conds_to_check,
                           std::vector<int64_t> &appid_feat_value_index, const InputFeature *inf_value,
                           std::unordered_map<AppIdWithEventTime *, int64_t> &appid_values,
                           std::vector<AppIdWithEventTime *> &appid_filter_vec_ptr,
                           const std::vector<const FilterDict *> &full_filter_dicts);
        int32_t FeatureSize(const tensorflow::Feature *feature) {
            switch (feature->kind_case()) {
                case (tensorflow::Feature::kFloatList): {
                    return feature->float_list().value_size();
                }
                case (tensorflow::Feature::kInt64List): {
                    return feature->int64_list().value_size();
                }
                case (tensorflow::Feature::kBytesList): {
                    return feature->bytes_list().value_size();
                }
                default:
                    return 0;
            }
            return 0;
        }
    };

}// namespace phx_fe
