#include "phx_config_time.h"
#include "sys/time.h"

#include <algorithm>
#include <cstdlib>

namespace phx_fe {

    void TimeHourConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        for (int64_t time_stamp: feat.int64_list().value()) {
            //13位时间戳，先除1000转换成秒，小时加8，时间转换成东八区
            out->mutable_int64_list()->add_value(((time_stamp / (int64_t) 1000 / (int64_t) 3600) + (int64_t) 8) %
                                                 (int64_t) 24);
        }
    }

    void TimeHourScopeConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        for (int64_t time_stamp: feat.int64_list().value()) {
            auto first_bigger_it =
                    std::upper_bound(hour_boundaries_.begin(), hour_boundaries_.end(),
                                     ((time_stamp / (int64_t) 1000 / (int64_t) 3600) + (int64_t) 8) % (int64_t) 24);
            out->mutable_bytes_list()->add_value(name_boundaries_[first_bigger_it - hour_boundaries_.begin()]);
        }
    }

    void TimeDayConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        struct tm timeinfo;
        for (int64_t time_stamp: feat.int64_list().value()) {
            time_t timestamp = static_cast<time_t>(time_stamp / (int64_t) 1000);
            //线程安全
            localtime_r(&timestamp, &timeinfo);
            out->mutable_int64_list()->add_value(timeinfo.tm_mday);
        }
    }

    void TimeDayScopeConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        struct tm timeinfo;
        for (int64_t time_stamp: feat.int64_list().value()) {
            time_t timestamp = static_cast<time_t>(time_stamp / (int64_t) 1000);
            localtime_r(&timestamp, &timeinfo);
            auto first_bigger_it = std::upper_bound(day_boundaries_.begin(), day_boundaries_.end(), timeinfo.tm_mday);
            out->mutable_bytes_list()->add_value(name_boundaries_[first_bigger_it - day_boundaries_.begin()]);
        }
    }

    void TimeWeekConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        struct tm timeinfo;
        for (int64_t time_stamp: feat.int64_list().value()) {
            time_t timestamp = static_cast<time_t>(time_stamp / (int64_t) 1000);
            localtime_r(&timestamp, &timeinfo);
            out->mutable_int64_list()->add_value(timeinfo.tm_wday ? timeinfo.tm_wday : 7);
        }
    }

    void TimeWeekScopeConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        struct tm timeinfo;
        for (int64_t time_stamp: feat.int64_list().value()) {
            time_t timestamp = static_cast<time_t>(time_stamp / (int64_t) 1000);
            localtime_r(&timestamp, &timeinfo);
            auto first_bigger_it = std::upper_bound(week_boundaries_.begin(), week_boundaries_.end(),
                                                    (timeinfo.tm_wday ? timeinfo.tm_wday : 7));
            out->mutable_bytes_list()->add_value(name_boundaries_[first_bigger_it - week_boundaries_.begin()]);
        }
    }

    void TimeMonthConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        struct tm timeinfo;
        for (int64_t time_stamp: feat.int64_list().value()) {
            time_t timestamp = static_cast<time_t>(time_stamp / (int64_t) 1000);
            localtime_r(&timestamp, &timeinfo);
            out->mutable_int64_list()->add_value(timeinfo.tm_mon + 1);
        }
    }

    void TimeMonthScopeConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        struct tm timeinfo;
        for (int64_t time_stamp: feat.int64_list().value()) {
            time_t timestamp = static_cast<time_t>(time_stamp / (int64_t) 1000);
            localtime_r(&timestamp, &timeinfo);
            auto first_bigger_it =
                    std::upper_bound(month_boundaries_.begin(), month_boundaries_.end(), timeinfo.tm_mon + 1);
            out->mutable_bytes_list()->add_value(name_boundaries_[first_bigger_it - month_boundaries_.begin()]);
        }
    }

    void TimeHolidayScopeConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        struct tm timeinfo;
        for (int64_t time_stamp: feat.int64_list().value()) {
            time_t timestamp = static_cast<time_t>(time_stamp / (int64_t) 1000);
            localtime_r(&timestamp, &timeinfo);
            int64_t year = timeinfo.tm_year + 1900;
            int64_t month = timeinfo.tm_mon + 1;
            int64_t day = timeinfo.tm_mday;
            int32_t find_idx = -1;

            auto itr = holiday_boundaries_.find(year);
            if (itr != holiday_boundaries_.end()) {
                for (uint32_t i = 0; i < itr->second.size(); i++) {
                    //如果假日开始月份和结束月份在同一月，且时间戳在该月份
                    if (itr->second[i].month_start_ == itr->second[i].month_end_ &&
                        month == itr->second[i].month_start_) {
                        //时间戳天数在开始日期和结束日期之间
                        if (day >= itr->second[i].day_start_ && day <= itr->second[i].day_end_) {
                            find_idx = i;
                            break;
                        }
                        //如果假日开始月份和结束月份不在同一月
                    } else if (itr->second[i].month_start_ < itr->second[i].month_end_) {
                        //时间戳在开始月份，且天数大于开始日期
                        if (month == itr->second[i].month_start_ && day >= itr->second[i].day_start_) {
                            find_idx = i;
                            break;
                            //时间戳在开始月份和结束月份之间
                        } else if (month > itr->second[i].month_start_ && month < itr->second[i].month_end_) {
                            find_idx = i;
                            break;
                            //时间戳在结束月份，且天数小于结束日期
                        } else if (month == itr->second[i].month_end_ && day <= itr->second[i].day_end_) {
                            find_idx = i;
                            break;
                        }
                    }
                }
                if (find_idx < 0) {
                    out->mutable_bytes_list()->add_value(default_value_);
                } else {
                    out->mutable_bytes_list()->add_value(itr->second[find_idx].holiday_name_);
                }
            } else {
                out->mutable_bytes_list()->add_value(default_value_);
            }
        }
    }

}// namespace phx_fe