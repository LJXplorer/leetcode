#include "config_seq.h"
#include "phx-fe/util/timer.h"
#include "phx-fe/util/math.h"
#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <limits>

bool SeqTopNConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqTopNConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* appid_value = get_value(input_values, inputs_, 0);
  const Value* eventtime_value = get_value(input_values, inputs_, 1);
  int64_t now = get_feature_one_int64(input_values, inputs_, 2);

  const InputFeature* inf_appid = nullptr;
  const InputFeature* inf_eventtime = nullptr;

  uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_STRING;
  value.ifeatures.resize(input_size);

  for (uint32_t i = 0; i < input_size; ++i) {
    inf_appid = &appid_value->ifeatures[i];
    inf_eventtime = &eventtime_value->ifeatures[i];

    std::vector<AppIdWithEventTime> appid_info_vec;
    std::vector<AppIdWithEventTime*> appid_info_vec_ptr;

    if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {

      uint32_t list_size = std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());
      for (uint32_t j = 0; j < list_size; j++) {
        filter_compute_.fill_appid_vec(inf_appid->feature_list->feature(j), inf_eventtime->feature_list->feature(j), now, appid_info_vec);
      }
      //排序
      top_n_compute_.compute_vec(appid_info_vec, appid_info_vec_ptr);

      tensorflow::FeatureList* out_feature_list = nullptr;
      out_feature_list = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_feature_list;

      //空值处理
      if (appid_info_vec_ptr.empty()) {
        if (!allow_empty_output_) {
          out_feature_list->add_feature()->mutable_bytes_list()->add_value(default_value_);
        }
      } else {
        for (const auto& elem : appid_info_vec_ptr) {
          out_feature_list->add_feature()->mutable_bytes_list()->add_value(*elem->appid);
        }
      }
    } else {
      tensorflow::Feature* out_feature = nullptr;
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;

      if (likely(inf_appid->feature && inf_eventtime->feature)) {
        //防穿越
        filter_compute_.fill_appid_vec(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_vec);
        //按照type类型，lastest,hotest排序
        top_n_compute_.compute_vec(appid_info_vec, appid_info_vec_ptr);
      }

      //空值处理
      if (appid_info_vec_ptr.empty()) {
        if (!allow_empty_output_) {
          out_feature->mutable_bytes_list()->add_value(default_value_);
        }
      } else {
        for (const auto& elem : appid_info_vec_ptr) {
          out_feature->mutable_bytes_list()->add_value(*elem->appid);
        }
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

bool SeqNV2Config::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqNV2Config::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* appid_value = get_value(input_values, inputs_, 0);
  const Value* eventtime_value = get_value(input_values, inputs_, 1);
  int64_t now = get_feature_one_int64(input_values, inputs_, 2);

  const InputFeature* inf_appid = nullptr;
  const InputFeature* inf_eventtime = nullptr;

  uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

  output.values.resize(4);
  for (uint32_t i = 0; i < 4; i++) {
    Value& value = output.values[i];
    value.defalut_type = tensorflow::DT_STRING;
    value.ifeatures.resize(input_size);
  }

  std::vector<tensorflow::Feature*> out_feat(4);
  std::vector<tensorflow::FeatureList*> out_featlist(4);

  for (uint32_t i = 0; i < input_size; ++i) {
    inf_appid = &appid_value->ifeatures[i];
    inf_eventtime = &eventtime_value->ifeatures[i];
    std::vector<AppIdWithEventTime> appid_info_vec;
    std::vector<AppIdWithEventTime*> appid_info_vec_ptr;
    std::map<std::string, int64_t> count_map;

    if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
      uint32_t list_size = std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

      //过滤数据
      for (uint32_t j = 0; j < list_size; j++) {
        filter_compute_.fill_appid_vec(inf_appid->feature_list->feature(j), inf_eventtime->feature_list->feature(j), now, appid_info_vec);
      }

      //排序、截断
      top_n_compute_.compute_vec(appid_info_vec, appid_info_vec_ptr);

      for (uint32_t j = 0; j < 4; j++) {
        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_featlist[j];
      }

      //空值处理
      if (appid_info_vec_ptr.empty()) {
        if (!allow_empty_output_) {
          for (uint32_t j = 0; j < 4; j++) {
            out_featlist[j]->add_feature()->mutable_bytes_list()->add_value(default_value_);
          }
        }
      } else {
        //统计次数
        fill_count_map(appid_info_vec_ptr, count_map);
        for (auto& pair : count_map) {
          out_featlist[0]->add_feature()->mutable_bytes_list()->add_value(pair.first);
          out_featlist[1]->add_feature()->mutable_bytes_list()->add_value(pair.first + "_" + std::to_string(pair.second));
        }
        for (const auto& elem : appid_info_vec_ptr) {
          out_featlist[2]->add_feature()->mutable_bytes_list()->add_value(*elem->appid + "_" + std::to_string((elem->eventtime) / 1000));
          out_featlist[3]->add_feature()->mutable_bytes_list()->add_value(*elem->appid + "_" + std::to_string((now - elem->eventtime) / 1000));
        }
      }
    } else {
      for (uint32_t j = 0; j < 4; j++) {
        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_feat[j];
      }

      //过滤数据
      if (likely(inf_appid->feature && inf_eventtime->feature)) {
        filter_compute_.fill_appid_vec(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_vec);

        //排序、截断
        top_n_compute_.compute_vec(appid_info_vec, appid_info_vec_ptr);
      }

      //空值处理
      if (appid_info_vec_ptr.empty()) {
        if (!allow_empty_output_) {
          for (uint32_t j = 0; j < 4; j++) {
            out_feat[j]->mutable_bytes_list()->add_value(default_value_);
          }
        }
      } else {
        //统计次数
        fill_count_map(appid_info_vec_ptr, count_map);
        for (auto& pair : count_map) {
          out_feat[0]->mutable_bytes_list()->add_value(pair.first);
          out_feat[1]->mutable_bytes_list()->add_value(pair.first + "_" + std::to_string(pair.second));
        }
        for (const auto& elem : appid_info_vec_ptr) {
          out_feat[2]->mutable_bytes_list()->add_value(*elem->appid + "_" + std::to_string((elem->eventtime) / 1000));
          out_feat[3]->mutable_bytes_list()->add_value(*elem->appid + "_" + std::to_string((now - elem->eventtime) / 1000));
        }
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqNV2Config::fill_count_map(std::vector<AppIdWithEventTime*>& appid_info_vec_ptr,
                                  std::map<std::string, int64_t>& count_map) {
  for (const auto& elem : appid_info_vec_ptr) {
    count_map[*elem->appid]++;
  }
}


void SeqHitValueConfig::compute_one_feature(const tensorflow::Feature& feat,
                                              std::map<std::string, int64_t>& count_map,
                                              tensorflow::Feature* out) {
  for (const std::string& appid : feat.bytes_list().value()) {
    out->mutable_bytes_list()->add_value(count_map.count(appid) ? appid : default_value_);
  }
  if (!allow_empty_output_) {
    fill_default_value(out);
  }
}

bool Cross2Config::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("Cross2Config::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* fea1_input_value = get_value(input_values, inputs_, 0);
  const Value* fea2_input_value = get_value(input_values, inputs_, 1);

  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_STRING;
  value.ifeatures.resize(1);

  tensorflow::FeatureList* out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
  value.ifeatures[0].feature_list = out_featurelist;

  //获取最多至截断长度的fe1数据
  std::vector<const std::string*> fea1_vec;
  fill_value_to_vec(fea1_input_value, fea1_clip_, fea1_vec);
  if (unlikely(fea1_vec.empty())) {
    if (!allow_empty_output_) {
      out_featurelist->add_feature()->mutable_bytes_list()->add_value(default_value_);
    }
    return true;
  }

  //获取最多至截断长度的fe2数据
  std::vector<const std::string*> fea2_vec;
  fill_value_to_vec(fea2_input_value, fea2_clip_, fea2_vec);
  if (unlikely(fea2_vec.empty())) {
    if (!allow_empty_output_) {
      out_featurelist->add_feature()->mutable_bytes_list()->add_value(default_value_);
    }
    return true;
  }

  //交叉全部数据
  for (uint32_t i = 0; i < fea1_vec.size(); i++) {
    for (uint32_t j = 0; j < fea2_vec.size(); j++) {
      out_featurelist->add_feature()->mutable_bytes_list()->add_value(*fea1_vec[i] + *fea2_vec[j]);
      if (clip_size_ > 0 && clip_size_ == out_featurelist->feature_size()) {
        return true;
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void Cross2Config::fill_value_to_vec(const Value* value, const int64_t fea_clip, std::vector<const std::string*>& vec) {
  for (uint32_t i = 0; i < value->ifeatures.size(); i++) {
    const InputFeature* hf = &value->ifeatures[i];
    if (likely(hf->feature)) {
      vec.reserve(vec.size() + hf->feature->bytes_list().value_size());
      for (const std::string& str : hf->feature->bytes_list().value()) {
        vec.push_back(&str);
        if (fea_clip > 0 && fea_clip == (int64_t)vec.size()) {
          return;
        }
      }
    } else if (likely(hf->feature_list && hf->feature_list->feature_size() > 0)) {
      for (auto& feat : hf->feature_list->feature()) {
        vec.reserve(vec.size() + feat.bytes_list().value_size());
        for (const std::string& str : feat.bytes_list().value()) {
          vec.push_back(&str);
          if (fea_clip > 0 && fea_clip == (int64_t)vec.size()) {
            return;
          }
        }
      }
    }
  }
}

bool SeqFilterConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqFilterConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* appid_value = get_value(input_values, inputs_, 0);
  const Value* eventtime_value = get_value(input_values, inputs_, 1);
  const Value* out_value = get_value(input_values, inputs_, 2);
  int64_t now = get_feature_one_int64(input_values, inputs_, 3);

  //取过滤条件pb
  std::vector<const Value*> type_value;
  type_value.resize(filter_dict_.size());
  for (uint32_t j = 0; j < type_value.size(); j++) {
    type_value[j] = get_value(input_values, inputs_, 4 + j);
  }

  const InputFeature* inf_appid = nullptr;
  const InputFeature* inf_eventtime = nullptr;
  const InputFeature* inf_value = nullptr;
  std::vector<const InputFeature*> inf_type;
  inf_type.resize(type_value.size());

  uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

  output.values.resize(3);
  for (uint32_t i = 0; i < 3; i++) {
    Value& value = output.values[i];
    value.ifeatures.resize(input_size);
  }
  output.values[0].defalut_type = tensorflow::DT_STRING;
  output.values[1].defalut_type = tensorflow::DT_INT64;
  output.values[2].defalut_type = tensorflow::DT_INT64;

  std::vector<tensorflow::Feature*> out_feat(3);
  std::vector<tensorflow::FeatureList*> out_featlist(3);

  for (uint32_t i = 0; i < input_size; ++i) {
    inf_appid = &appid_value->ifeatures[i];
    inf_eventtime = &eventtime_value->ifeatures[i];
    if (out_value->ifeatures.size() > i) {
      inf_value = &out_value->ifeatures[i];
    } else {
      inf_value = nullptr;
    }

    for (uint32_t j = 0; j < type_value.size(); j++) {
      if (type_value[j]->ifeatures.size() > i) {
        inf_type[j] = &type_value[j]->ifeatures[i];
      } else {
        inf_type[j] = nullptr;
      }
    }

    std::vector<AppIdWithEventTime> appid_info_vec;
    std::vector<AppIdWithEventTime*> appid_filter_vec_ptr;
    std::vector<AppIdWithEventTime*> appid_info_vec_ptr;
    std::vector<std::vector<int64_t>> appid_feat_value_index;
    std::map<AppIdWithEventTime*, int64_t> appid_values;

    if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
      uint32_t list_size = std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

      appid_feat_value_index.resize(list_size);
      //过滤时间
      for (uint32_t j = 0; j < list_size; j++) {
        filter_compute_.fill_appid_vec_with_index(inf_appid->feature_list->feature(j), inf_eventtime->feature_list->feature(j), now, appid_info_vec, appid_feat_value_index[j]);
      }
      //过滤
      filter_feature_type(appid_info_vec, inf_type, appid_feat_value_index, inf_value, appid_values, appid_filter_vec_ptr);

      //排序、截断
      top_n_compute_.compute_ptr_vec(appid_filter_vec_ptr, appid_info_vec_ptr);

      for (uint32_t j = 0; j < 3; j++) {
        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_featlist[j];
      }

      //空值处理
      if (appid_info_vec_ptr.empty()) {
        if (!allow_empty_output_) {
          out_featlist[0]->add_feature()->mutable_bytes_list()->add_value(default_value_);
          out_featlist[1]->add_feature()->mutable_int64_list()->add_value(-1);
          out_featlist[2]->add_feature()->mutable_int64_list()->add_value(-1);
        }
      } else {
        for (const auto& elem : appid_info_vec_ptr) {
          out_featlist[0]->add_feature()->mutable_bytes_list()->add_value(*elem->appid);
          out_featlist[1]->add_feature()->mutable_int64_list()->add_value(elem->eventtime);
          auto itr = appid_values.find(elem);
          if (itr != appid_values.end()) {
            out_featlist[2]->add_feature()->mutable_int64_list()->add_value(itr->second);
          } else {
            out_featlist[2]->add_feature()->mutable_int64_list()->add_value(-1);
          }
        }
      }
    } else {
      for (uint32_t j = 0; j < 3; j++) {
        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_feat[j];
      }

      if (likely(inf_appid->feature && inf_eventtime->feature)) {
        appid_feat_value_index.emplace_back();
        filter_compute_.fill_appid_vec_with_index(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_vec, appid_feat_value_index[0]);

        //过滤
        filter_feature_type(appid_info_vec, inf_type, appid_feat_value_index, inf_value, appid_values, appid_filter_vec_ptr);

        //排序、截断
        top_n_compute_.compute_ptr_vec(appid_filter_vec_ptr, appid_info_vec_ptr);
      }

      //空值处理
      if (appid_info_vec_ptr.empty()) {
        if (!allow_empty_output_) {
          out_feat[0]->mutable_bytes_list()->add_value(default_value_);
          out_feat[1]->mutable_int64_list()->add_value(-1);
          out_feat[2]->mutable_int64_list()->add_value(-1);
        }
      } else {
        for (const auto& elem : appid_info_vec_ptr) {
          out_feat[0]->mutable_bytes_list()->add_value(*elem->appid);
          out_feat[1]->mutable_int64_list()->add_value(elem->eventtime);
          auto itr = appid_values.find(elem);
          if (itr != appid_values.end()) {
            out_feat[2]->mutable_int64_list()->add_value(itr->second);
          } else {
            out_feat[2]->mutable_int64_list()->add_value(-1);
          }
        }
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqFilterConfig::filter_feature_type(std::vector<AppIdWithEventTime>& appid_info_vec,
                                          std::vector<const InputFeature*>& inf_type,
                                          std::vector<std::vector<int64_t>>& appid_feat_value_index,
                                          const InputFeature* inf_value,
                                          std::map<AppIdWithEventTime*, int64_t>& appid_values,
                                          std::vector<AppIdWithEventTime*>& appid_filter_vec_ptr) {
  int64_t index = 0;
  const tensorflow::Feature* feature = nullptr;
  std::vector<uint32_t> allow_count(appid_info_vec.size(), 0);
  appid_filter_vec_ptr.reserve(appid_info_vec.size());
  //遍历n个过滤条件字段
  for (uint32_t i = 0; i < filter_dict_.size(); i++) {
    index = 0;
    //过滤条件为空，直接跳过该条件
    if (filter_dict_[i].empty()) {
      std::for_each(allow_count.begin(), allow_count.end(), [](uint32_t& val) {
        val += 1;
      });
      continue;
    } else if (inf_type[i] == nullptr) {  //过滤字段为空，不符合
      continue;
    }

    for (uint32_t j = 0; j < appid_feat_value_index.size(); j++) {
      //获取当前过滤字段的feature,feature获取失败不符合
      if (inf_type[i]->feature_list && inf_type[i]->feature_list->feature_size() > (int64_t)j) {
        feature = &inf_type[i]->feature_list->feature(j);
      } else if (inf_type[i]->feature) {
        feature = inf_type[i]->feature;
      } else {
        index += appid_feat_value_index[j].size();
        continue;
      }
      auto& type_vec = feature->bytes_list().value();
      for (uint32_t k = 0; k < appid_feat_value_index[j].size(); k++) {
        if (type_vec.size() > appid_feat_value_index[j][k]
            && filter_dict_[i].find(type_vec[appid_feat_value_index[j][k]]) != filter_dict_[i].end()) {
          allow_count[index++]++;
        } else {
          index++;
        }
      }
    }
  }

  //   填充value信息
  if (inf_value) {
    index = 0;
    for (uint32_t i = 0; i < appid_feat_value_index.size(); i++) {
      //获取当前value字段的feature,feature获取失败不符合
      if (inf_value->feature_list && inf_value->feature_list->feature_size() > (int64_t)i) {
        feature = &inf_value->feature_list->feature(i);
      } else if (inf_value->feature) {
        feature = inf_value->feature;
      } else {
        index += appid_feat_value_index[i].size();
        continue;
      }
      auto& value_vec = feature->int64_list().value();
      for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
        if (value_vec.size() > appid_feat_value_index[i][j]) {
          appid_values[&appid_info_vec[index]] = value_vec[appid_feat_value_index[i][j]];
        }
        index++;
      }
    }
  }

  //  全部条件符合，填充
  for (uint32_t i = 0; i < allow_count.size(); i++) {
    if (allow_count[i] == filter_dict_.size()) {
      appid_filter_vec_ptr.emplace_back(&appid_info_vec[i]);
    }
  }
}

bool SeqFilterV2Config::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqFilterV2Config::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input1_value = get_value(input_values, inputs_, 0);
  const Value* input2_value = get_value(input_values, inputs_, 1);

  uint32_t input1_size = input1_value->ifeatures.size();
  uint32_t input2_size = input2_value->ifeatures.size();

  if (std::min(input1_size, input2_size) < 0) {
    THROW_ERROR("invalid ifeatures_size, input1_size:" + std::to_string(input1_size) + ", input2_size:" + std::to_string(input2_size) + ", name:" + output_);
  }
  uint32_t batch_size = std::max(input1_size, input2_size);

  const InputFeature* input1_inf = nullptr;
  const InputFeature* input2_inf = nullptr;
  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;

  output.values.resize(1);
  Value& value = output.values[0];
  value.ifeatures.resize(batch_size);

  std::set<std::string> str_filter;
  std::set<int64_t> int_filter;
  tensorflow::DataType data_type = tensorflow::DT_INVALID;
  tensorflow::DataType input2_type = tensorflow::DT_INVALID;

  for (uint32_t i = 0; i < batch_size; ++i) {
    data_type = tensorflow::DT_INVALID;
    if (input1_size == batch_size) {
      input1_inf = &input1_value->ifeatures[i];
    } else {
      input1_inf = &input1_value->ifeatures[0];
    }

    if (input2_size == batch_size) {
      input2_inf = &input2_value->ifeatures[i];
      str_filter.clear();
      int_filter.clear();
    } else {
      input2_inf = &input2_value->ifeatures[0];
      data_type = input2_type;
    }

    if (str_filter.empty() && int_filter.empty()) {
      tensorflow::DataType temp_type = tensorflow::DT_INVALID;
      fill_ifeature_to_set(input2_inf, str_filter, int_filter, temp_type);
      input2_type = temp_type;
      data_type = temp_type;
    }

    if (likely(input1_inf->feature_list)) {
      out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_featurelist;

      for (int32_t j = 0; j < input1_inf->feature_list->feature_size(); j++) {
        compute_one_feature(str_filter, int_filter, input1_inf->feature_list->feature(j), data_type, out_featurelist, nullptr);
      }

      // 为空填充默认值
      switch (data_type) {
        case tensorflow::DT_INT64: {
          if (unlikely(out_featurelist->feature_size() == 0)) {
            out_featurelist->add_feature()->mutable_int64_list()->add_value(default_int_);
          }
        }
        break;

        case tensorflow::DT_STRING: {
          if (unlikely(out_featurelist->feature_size() == 0)) {
            out_featurelist->add_feature()->mutable_bytes_list()->add_value(default_value_);
          }
        }
        break;

        default:
        break;
      }
    } else {
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;

      if (likely(input1_inf->feature)) {
        compute_one_feature(str_filter, int_filter, *input1_inf->feature, data_type, nullptr, out_feature);
      }

      // 为空填充默认值
      switch (data_type) {
        case tensorflow::DT_INT64: {
          if (unlikely(out_feature->int64_list().value_size() == 0)) {
            out_feature->mutable_int64_list()->add_value(default_int_);
          }
        }
        break;

        case tensorflow::DT_STRING: {
          if (unlikely(out_feature->bytes_list().value_size() == 0)) {
            out_feature->mutable_bytes_list()->add_value(default_value_);
          }
        }
        break;

        default:
        break;
      }
    }
    if (value.defalut_type == tensorflow::DT_INVALID) {
      value.defalut_type = data_type;
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqFilterV2Config::fill_ifeature_to_set(const InputFeature* inf_value,
                                             std::set<std::string>& str_filter,
                                             std::set<int64_t>& int_filter,
                                             tensorflow::DataType& data_type) {
  if (likely(inf_value->feature)) {
    fill_feature_to_set(*inf_value->feature, str_filter, int_filter, data_type);
  } else if (likely(inf_value->feature_list)) {
    for (auto& feat : inf_value->feature_list->feature()) {
      fill_feature_to_set(feat, str_filter, int_filter, data_type);
    }
  }
}

void SeqFilterV2Config::fill_feature_to_set(const tensorflow::Feature& feat,
                                            std::set<std::string>& str_filter,
                                            std::set<int64_t>& int_filter,
                                            tensorflow::DataType& data_type) {
  switch (feat.kind_case()) {
    case tensorflow::Feature::kBytesList: {
      data_type = tensorflow::DT_STRING;
      for (const std::string& str : feat.bytes_list().value()) {
        str_filter.insert(str);
      }
      break;
    }   
    case tensorflow::Feature::kInt64List: {
      data_type = tensorflow::DT_INT64;
      for (const int64_t value : feat.int64_list().value()) {
        int_filter.insert(value);
      }
      break;
    }
    default: {
      break;
    }
  }
}

void SeqFilterV2Config::compute_one_feature(const std::set<std::string>& str_filter,
                                            const std::set<int64_t>& int_filter,
                                            const tensorflow::Feature& feat,
                                            tensorflow::DataType& data_type,
                                            tensorflow::FeatureList* out_featurelist,
                                            tensorflow::Feature* out) {
  switch (feat.kind_case()) {
    case tensorflow::Feature::kBytesList: {
      data_type = tensorflow::DT_STRING;
      for (const std::string& str : feat.bytes_list().value()) {
        if (str_filter.find(str) == str_filter.end()) {
          if (!out) {
            out = out_featurelist->add_feature();
          }
          out->mutable_bytes_list()->add_value(str);
        }
      }
      break;
    }
    case tensorflow::Feature::kInt64List: {
      data_type = tensorflow::DT_INT64;
      for (const int64_t value : feat.int64_list().value()) {
        if (int_filter.find(value) == int_filter.end()) {
          if (!out) {
            out = out_featurelist->add_feature();
          }
          out->mutable_int64_list()->add_value(value);
        }
      }
      break;
    }
    default: {
      break;
    }
  }
}

bool SeqFilterV3Config::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqFilterV3Config::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* appid_value = get_value(input_values, inputs_, 0);
  const Value* eventtime_value = get_value(input_values, inputs_, 1);
  int64_t now = get_feature_one_int64(input_values, inputs_, 2);

  //取输出pb
  size_t out_size = input_values.size() - 1;
  std::vector<const Value*> out_value;
  out_value.resize(out_size - 2);
  for (uint32_t i = 0; i < out_value.size(); i++) {
    out_value[i] = get_value(input_values, inputs_, 3 + i);
  }

  const InputFeature* inf_appid = nullptr;
  const InputFeature* inf_eventtime = nullptr;
  std::vector<const InputFeature*> inf_value(out_value.size(), nullptr);

  uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

  output.values.resize(out_size);
  for (uint32_t i = 0; i < out_size; i++) {
    Value& value = output.values[i];
    value.ifeatures.resize(input_size);
  }
  output.values[0].defalut_type = tensorflow::DT_STRING;
  output.values[1].defalut_type = tensorflow::DT_INT64;

  std::vector<tensorflow::Feature*> out_feat(out_size);
  std::vector<tensorflow::FeatureList*> out_featlist(out_size);

  for (uint32_t i = 0; i < input_size; ++i) {
    inf_appid = &appid_value->ifeatures[i];
    inf_eventtime = &eventtime_value->ifeatures[i];
    for (uint32_t j = 0; j < out_value.size(); ++j) {
      if (out_value[j]->ifeatures.size() > i) {
        inf_value[j] = &out_value[j]->ifeatures[i];
      } else {
        inf_value[j] = nullptr;
      }
    }

    std::vector<AppIdWithEventTime> appid_info_vec;
    std::vector<AppIdWithEventTime*> appid_filter_vec_ptr;
    std::vector<std::vector<int64_t>> appid_feat_value_index;
    std::map<AppIdWithEventTime*, std::vector<tensorflow::Feature>> appid_values;

    if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
      for (uint32_t j = 0; j < out_size; j++) {
        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_featlist[j];
      }

      uint32_t list_size = std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

      appid_feat_value_index.resize(list_size);
      //过滤时间
      for (uint32_t j = 0; j < list_size; j++) {
        filter_compute_.fill_appid_vec_with_index(inf_appid->feature_list->feature(j), inf_eventtime->feature_list->feature(j), now, appid_info_vec, appid_feat_value_index[j]);
      }
      //过滤
      filter_feature_type(appid_info_vec, appid_filter_vec_ptr);

      //获取out_value
      get_values_map(appid_info_vec, inf_value, appid_feat_value_index, appid_values);

      // 截断
      if (clip_size_ > 0 && (int64_t)appid_filter_vec_ptr.size() > clip_size_) {
        appid_filter_vec_ptr.resize(clip_size_);
      }

      for (const auto& elem : appid_filter_vec_ptr) {
        out_featlist[0]->add_feature()->mutable_bytes_list()->add_value(*elem->appid);
        out_featlist[1]->add_feature()->mutable_int64_list()->add_value(elem->eventtime);
        auto itr = appid_values.find(elem);
        if (itr != appid_values.end()) {
          auto& vec = itr->second;
          for (uint32_t j = 0; j < vec.size(); j++) {
            switch (vec[j].kind_case()) {
              case tensorflow::Feature::kBytesList: {
                output.values[2 + j].defalut_type = tensorflow::DT_STRING;
                out_featlist[2 + j]->add_feature()->mutable_bytes_list()->add_value(vec[j].bytes_list().value(0));
              }
              break;

              case tensorflow::Feature::kFloatList: {
                output.values[2 + j].defalut_type = tensorflow::DT_FLOAT;
                out_featlist[2 + j]->add_feature()->mutable_float_list()->add_value(vec[j].float_list().value(0));
              }
              break;

              case tensorflow::Feature::kInt64List: {
                output.values[2 + j].defalut_type = tensorflow::DT_INT64;
                out_featlist[2 + j]->add_feature()->mutable_int64_list()->add_value(vec[j].int64_list().value(0));
              }
              break;

              default: {
                continue;
              }
              break;
            }
          }
        }
      }
    } else {
      for (uint32_t j = 0; j < out_size; j++) {
        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_feat[j];
      }

      if (likely(inf_appid->feature && inf_eventtime->feature)) {
        appid_feat_value_index.emplace_back();
        filter_compute_.fill_appid_vec_with_index(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_vec, appid_feat_value_index[0]);

        //过滤
        filter_feature_type(appid_info_vec, appid_filter_vec_ptr);

        //获取out_value
        get_values_map(appid_info_vec, inf_value, appid_feat_value_index, appid_values);

        // 截断
        if (clip_size_ > 0 && (int64_t)appid_filter_vec_ptr.size() > clip_size_) {
          appid_filter_vec_ptr.resize(clip_size_);
        }
      }

      for (const auto& elem : appid_filter_vec_ptr) {
        out_feat[0]->mutable_bytes_list()->add_value(*elem->appid);
        out_feat[1]->mutable_int64_list()->add_value(elem->eventtime);
        auto itr = appid_values.find(elem);
        if (itr != appid_values.end()) {
          auto& vec = itr->second;
          for (uint32_t j = 0; j < vec.size(); j++) {
            switch (vec[j].kind_case()) {
              case tensorflow::Feature::kBytesList: {
                output.values[2 + j].defalut_type = tensorflow::DT_STRING;
                out_feat[2 + j]->mutable_bytes_list()->add_value(vec[j].bytes_list().value(0));
              }
              break;

              case tensorflow::Feature::kFloatList: {
                output.values[2 + j].defalut_type = tensorflow::DT_FLOAT;
                out_feat[2 + j]->mutable_float_list()->add_value(vec[j].float_list().value(0));
              }
              break;

              case tensorflow::Feature::kInt64List: {
                output.values[2 + j].defalut_type = tensorflow::DT_INT64;
                out_feat[2 + j]->mutable_int64_list()->add_value(vec[j].int64_list().value(0));
              }
              break;

              default: {
                continue;
              }
              break;
            }
          }
        }
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqFilterV3Config::filter_feature_type(std::vector<AppIdWithEventTime>& appid_info_vec,
                                            std::vector<AppIdWithEventTime*>& appid_filter_vec_ptr) {
  appid_filter_vec_ptr.reserve(appid_info_vec.size());

  for (uint32_t i = 0; i < appid_info_vec.size(); i++) {
    auto itr = filter_dict_.find(*appid_info_vec[i].appid);
    if (reverse_ && itr != filter_dict_.end()) {
      appid_filter_vec_ptr.emplace_back(&appid_info_vec[i]);
    } else if (!reverse_ && itr == filter_dict_.end()) {
      appid_filter_vec_ptr.emplace_back(&appid_info_vec[i]);
    }
  }
}

void SeqFilterV3Config::get_values_map(std::vector<AppIdWithEventTime>& appid_info_vec,
                                       std::vector<const InputFeature*>& inf_value,
                                       std::vector<std::vector<int64_t>>& appid_feat_value_index,
                                       std::map<AppIdWithEventTime*, std::vector<tensorflow::Feature>>& appid_values) {
  const tensorflow::Feature* feature = nullptr;
  for (auto& one_value : inf_value) {
    int64_t index = 0;

    for (uint32_t i = 0; i < appid_info_vec.size(); i++) {
      auto& vec = appid_values[&appid_info_vec[i]];
      vec.emplace_back();
    }
    for (uint32_t i = 0; i < appid_feat_value_index.size(); i++) {
      //  获取当前value字段的feature,feature获取失败不符合
      get_value_feature(one_value, i, feature);
      if (feature) {
        switch (feature->kind_case()) {
          case tensorflow::Feature::kBytesList: {
            auto& value_vec = feature->bytes_list().value();
            for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
              if (value_vec.size() > appid_feat_value_index[i][j]) {
                auto& vec = appid_values[&appid_info_vec[index]];
                vec.back().mutable_bytes_list()->add_value(value_vec[appid_feat_value_index[i][j]]);
              }
              index++;
            }
          }
          break;

          case tensorflow::Feature::kFloatList: {
            auto& value_vec = feature->float_list().value();
            for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
              if (value_vec.size() > appid_feat_value_index[i][j]) {
                auto& vec = appid_values[&appid_info_vec[index]];
                vec.back().mutable_float_list()->add_value(value_vec[appid_feat_value_index[i][j]]);
              }
              index++;
            }
          }
          break;

          case tensorflow::Feature::kInt64List: {
            auto& value_vec = feature->int64_list().value();
            for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
              if (value_vec.size() > appid_feat_value_index[i][j]) {
                auto& vec = appid_values[&appid_info_vec[index]];
                vec.back().mutable_int64_list()->add_value(value_vec[appid_feat_value_index[i][j]]);
              }
              index++;
            }
          }
          break;

          default: {
            index += appid_feat_value_index[i].size();
          }
          break;
        }
      } else {
        index += appid_feat_value_index[i].size();
      }
    }
  }
}

bool SeqDiffConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqDiffConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* appid_value = get_value(input_values, inputs_, 0);
  const Value* eventtime_value = get_value(input_values, inputs_, 1);
  const Value* appid_use_value = get_value(input_values, inputs_, 2);
  const Value* eventtime_use_value = get_value(input_values, inputs_, 3);
  int64_t now = get_feature_one_int64(input_values, inputs_, 4);

  const InputFeature* inf_appid = nullptr;
  const InputFeature* inf_eventtime = nullptr;

  uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());
  uint32_t input_use_size = std::min(appid_use_value->ifeatures.size(), eventtime_use_value->ifeatures.size());
  input_size = std::min(input_size, input_use_size);

  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_STRING;
  value.ifeatures.resize(input_size);

  for (uint32_t i = 0; i < input_size; ++i) {
    inf_appid = &appid_use_value->ifeatures[i];
    inf_eventtime = &eventtime_use_value->ifeatures[i];
    std::map<std::string, std::vector<int64_t>> appid_info_map;

    //获取使用信息
    if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
      uint32_t list_size = std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());
      for (uint32_t j = 0; j < list_size; j++) {
        filter_compute_.fill_appid_map(inf_appid->feature_list->feature(j), inf_eventtime->feature_list->feature(j), now, appid_info_map);
      }
    } else if (likely(inf_appid->feature && inf_eventtime->feature)) {
      filter_compute_.fill_appid_map(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_map);
    }

    inf_appid = &appid_value->ifeatures[i];
    inf_eventtime = &eventtime_value->ifeatures[i];
    std::vector<AppIdWithEventTime> appid_info_vec;
    std::vector<AppIdWithEventTime*> appid_filter_vec_ptr;
    std::vector<AppIdWithEventTime*> appid_info_vec_ptr;

    if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
      uint32_t list_size = std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

      for (uint32_t j = 0; j < list_size; j++) {
        filter_compute_.fill_appid_vec(inf_appid->feature_list->feature(j), inf_eventtime->feature_list->feature(j), now, appid_info_vec);
      }
      //筛选不经常使用的appid信息
      filter_unuse_appid(appid_info_vec, appid_info_map, appid_filter_vec_ptr);

      //排序、截断
      top_n_compute_.compute_ptr_vec(appid_filter_vec_ptr, appid_info_vec_ptr);

      tensorflow::FeatureList* out_feature_list = nullptr;
      out_feature_list = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_feature_list;

      //空值处理
      if (appid_info_vec_ptr.empty()) {
        if (!allow_empty_output_) {
          out_feature_list->add_feature()->mutable_bytes_list()->add_value(default_value_);
        }
      } else {
        for (const auto& elem : appid_info_vec_ptr) {
          out_feature_list->add_feature()->mutable_bytes_list()->add_value(*elem->appid);
        }
      }
    } else {
      tensorflow::Feature* out_feature = nullptr;
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;

      if (likely(inf_appid->feature && inf_eventtime->feature)) {
        filter_compute_.fill_appid_vec(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_vec);

        //筛选
        filter_unuse_appid(appid_info_vec, appid_info_map, appid_filter_vec_ptr);

        //排序、截断
        top_n_compute_.compute_ptr_vec(appid_filter_vec_ptr, appid_info_vec_ptr);
      }

      //空值处理
      if (appid_info_vec_ptr.empty()) {
        if (!allow_empty_output_) {
          out_feature->mutable_bytes_list()->add_value(default_value_);
        }
      } else {
        for (const auto& elem : appid_info_vec_ptr) {
          out_feature->mutable_bytes_list()->add_value(*elem->appid);
        }
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqDiffConfig::filter_unuse_appid(std::vector<AppIdWithEventTime>& appid_info_vec,
                                        std::map<std::string, std::vector<int64_t>>& appid_info_map,
                                        std::vector<AppIdWithEventTime*>& appid_filter_vec_ptr) {
  appid_filter_vec_ptr.reserve(appid_info_vec.size());
  for (auto& appid_info : appid_info_vec) {
    //查找是否有使用记录
    bool flag = true;
    auto itr = appid_info_map.find(*appid_info.appid);
    if (itr != appid_info_map.end()) {
      for (const int64_t& event_time : itr->second) {
        //如果时间段内有符合的使用记录，直接跳出
        if (event_time > appid_info.eventtime && event_time <= appid_info.eventtime + delta_day_ * (int64_t)(60 * 60 * 24) * (int64_t)1000) {
          flag = false;
          break;
        }
      }
    }
    if (flag) {
      appid_filter_vec_ptr.emplace_back(&appid_info);
    }
  }
}

bool SeqInterestConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqInterestConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* subkey_value = get_value(input_values, inputs_, 0);
  const Value* eventtime_value = get_value(input_values, inputs_, 1);
  int64_t now = get_feature_one_int64(input_values, inputs_, 2);
  const Value* info_value = get_value(input_values, inputs_, 3);

  const InputFeature* inf_subkey = nullptr;
  const InputFeature* inf_eventtime = nullptr;

  uint32_t input_size = std::min(subkey_value->ifeatures.size(), eventtime_value->ifeatures.size());

  output.values.resize(5);
  for (uint32_t i = 0; i < 5; i++) {
    Value& value = output.values[i];
    value.ifeatures.resize(input_size);
  }
  output.values[0].defalut_type = tensorflow::DT_STRING;
  output.values[1].defalut_type = tensorflow::DT_INT64;
  output.values[2].defalut_type = tensorflow::DT_FLOAT;
  output.values[3].defalut_type = tensorflow::DT_INT64;
  output.values[4].defalut_type = tensorflow::DT_FLOAT;

  std::vector<tensorflow::Feature*> out_feat(5);
  std::vector<tensorflow::FeatureList*> out_featlist(5);

  for (uint32_t i = 0; i < input_size; ++i) {
    inf_subkey = &subkey_value->ifeatures[i];
    inf_eventtime = &eventtime_value->ifeatures[i];

    std::vector<const std::string*> subkey_vec;
    std::vector<std::vector<int64_t>> index_vecs;
    std::map<std::string, std::pair<int64_t, int64_t>> info_map;
    const tensorflow::Feature* feature = nullptr;
    int64_t index = 0;
    int64_t count = 0;
    int64_t value = 0;

    if (likely(inf_subkey->feature_list && inf_eventtime->feature_list)) {
      for (uint32_t j = 0; j < 5; j++) {
        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_featlist[j];
      }

      uint32_t list_size = std::min(inf_subkey->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

      index_vecs.resize(list_size);
      //过滤时间,根据now_hour是否筛选当前相同小时数据
      for (uint32_t j = 0; j < list_size; j++) {
        if (now_hour_) {
          filter_compute_.fill_subkey_vec_with_index_by_hour(inf_subkey->feature_list->feature(j),
                                                             inf_eventtime->feature_list->feature(j), now, subkey_vec, index_vecs[j]);
        } else {
          filter_compute_.fill_subkey_vec_with_index(inf_subkey->feature_list->feature(j),
                                                     inf_eventtime->feature_list->feature(j), now, subkey_vec, index_vecs[j]);
        }
      }
      //数据写入map
      if (i < info_value->ifeatures.size() && info_value->ifeatures[i].feature_list) {
        for (uint32_t j = 0; j < index_vecs.size(); ++j) {
          if (info_value->ifeatures[i].feature_list->feature_size() > (int64_t)j) {
            feature = &info_value->ifeatures[i].feature_list->feature(j);
            compute_one_feature(subkey_vec, index, index_vecs[j], feature, value, count, info_map);
          } else {
            index += index_vecs[j].size();
          }
        }
      }

      //空值处理
      if (info_map.empty()) {
        if (!allow_empty_output_) {
          out_featlist[0]->add_feature()->mutable_bytes_list()->add_value(default_value_);
          out_featlist[1]->add_feature()->mutable_int64_list()->add_value(0);
          out_featlist[2]->add_feature()->mutable_float_list()->add_value(0);
          out_featlist[3]->add_feature()->mutable_int64_list()->add_value(0);
          out_featlist[4]->add_feature()->mutable_float_list()->add_value(0);
        }
      } else {
        for (const auto& pair : info_map) {
          for (uint32_t j = 0; j < 5; j++) {
            out_feat[j] = out_featlist[j]->add_feature();
          }
          compute_out_features(pair, value, count, out_feat);
        }
      }

    } else {
      for (uint32_t j = 0; j < 5; j++) {
        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_feat[j];
      }

      if (likely(inf_subkey->feature && inf_eventtime->feature)) {
        index_vecs.emplace_back();

        //过滤时间,根据now_hour是否筛选当前相同小时数据
        if (now_hour_) {
          filter_compute_.fill_subkey_vec_with_index_by_hour(*inf_subkey->feature, *inf_eventtime->feature, now, subkey_vec, index_vecs[0]);
        } else {
          filter_compute_.fill_subkey_vec_with_index(*inf_subkey->feature, *inf_eventtime->feature, now, subkey_vec, index_vecs[0]);
        }
        //数据写入map
        if (i < info_value->ifeatures.size() && info_value->ifeatures[i].feature) {
          feature = info_value->ifeatures[i].feature;
          compute_one_feature(subkey_vec, index, index_vecs[0], feature, value, count, info_map);
        }
      }

      //空值处理
      if (info_map.empty()) {
        if (!allow_empty_output_) {
          out_feat[0]->mutable_bytes_list()->add_value(default_value_);
          out_feat[1]->mutable_int64_list()->add_value(0);
          out_feat[2]->mutable_float_list()->add_value(0);
          out_feat[3]->mutable_int64_list()->add_value(0);
          out_feat[4]->mutable_float_list()->add_value(0);
        }
      } else {
        for (const auto& pair : info_map) {
          compute_out_features(pair, value, count, out_feat);
        }
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqInterestConfig::compute_one_feature(std::vector<const std::string*>& subkey_vec,
                                            int64_t& index,
                                            std::vector<int64_t>& index_vec,
                                            const tensorflow::Feature* info_feat,
                                            int64_t& value,
                                            int64_t& count,
                                            std::map<std::string, std::pair<int64_t, int64_t>>& info_map) {
  auto& info_vec = info_feat->int64_list().value();
  for (uint32_t i = 0; i < index_vec.size(); i++) {
    if (info_vec.size() > index_vec[i]) {
      auto& pair = info_map[*subkey_vec[index]];
      pair.first += info_vec[index_vec[i]];
      pair.second++;
      value += info_vec[index_vec[i]];
      count++;
    }
    index++;
  }
}

void SeqInterestConfig::compute_out_features(const std::pair<const std::string, std::pair<int64_t, int64_t>>& pair,
                                              int64_t value,
                                              int64_t count,
                                              std::vector<tensorflow::Feature*>& out_feat) {
  out_feat[0]->mutable_bytes_list()->add_value(pair.first);
  out_feat[1]->mutable_int64_list()->add_value(pair.second.first);
  out_feat[2]->mutable_float_list()->add_value(static_cast<float>(pair.second.first) / static_cast<float>(value));
  out_feat[3]->mutable_int64_list()->add_value(pair.second.second);
  out_feat[4]->mutable_float_list()->add_value(static_cast<float>(pair.second.second) / static_cast<float>(count));
}

bool SeqFreshConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqFreshConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* subkey_value = get_value(input_values, inputs_, 0);
  const Value* eventtime_value = get_value(input_values, inputs_, 1);
  int64_t now = get_feature_one_int64(input_values, inputs_, 2);
  const Value* find_value = get_value(input_values, inputs_, 3);

  const InputFeature* inf_subkey = nullptr;
  const InputFeature* inf_eventtime = nullptr;

  uint32_t input_size = std::min(subkey_value->ifeatures.size(), eventtime_value->ifeatures.size());
  std::map<std::string, int64_t> count_map;

  for (uint32_t i = 0; i < input_size; ++i) {
    inf_subkey = &subkey_value->ifeatures[i];
    inf_eventtime = &eventtime_value->ifeatures[i];

    if (likely(inf_subkey->feature_list && inf_eventtime->feature_list)) {
      uint32_t list_size = std::min(inf_subkey->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());
      //过滤时间,根据now_hour是否筛选当前相同小时数据
      for (uint32_t j = 0; j < list_size; j++) {
        if (now_hour_) {
          filter_compute_.fill_count_map_by_hour(inf_subkey->feature_list->feature(j), inf_eventtime->feature_list->feature(j), now, count_map);
        } else {
          filter_compute_.fill_count_map(inf_subkey->feature_list->feature(j), inf_eventtime->feature_list->feature(j), now, count_map);
        }
      }
    } else if (likely(inf_subkey->feature && inf_eventtime->feature)) {
      //过滤时间,根据now_hour是否筛选当前相同小时数据
      if (now_hour_) {
        filter_compute_.fill_count_map_by_hour(*inf_subkey->feature, *inf_eventtime->feature, now, count_map);
      } else {
        filter_compute_.fill_count_map(*inf_subkey->feature, *inf_eventtime->feature, now, count_map);
      }
    }
  }

  uint32_t item_size = find_value->ifeatures.size();

  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_INT64;
  value.ifeatures.resize(item_size);

  for (uint32_t i = 0; i < item_size; ++i) {
    const InputFeature& inf_find = find_value->ifeatures[i];
    if (likely(inf_find.feature_list)) {
      tensorflow::FeatureList* out_feature_list = nullptr;
      out_feature_list = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_feature_list;

      for (auto& feat : inf_find.feature_list->feature()) {
        compute_one_feature(feat, count_map, out_feature_list->add_feature());
      }
    } else {
      tensorflow::Feature* out_feature = nullptr;
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;

      if (likely(inf_find.feature)) {
        compute_one_feature(*inf_find.feature, count_map, out_feature);
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqFreshConfig::compute_one_feature(const tensorflow::Feature& feat,
                                         std::map<std::string, int64_t>& count_map,
                                         tensorflow::Feature* out_feature) {
  auto& string_vec = feat.bytes_list().value();
  for (auto& str : string_vec) {
    auto itr = count_map.find(str);
    if (itr != count_map.end()) {
      out_feature->mutable_int64_list()->add_value(itr->second);
    } else {
      out_feature->mutable_int64_list()->add_value(0);
    }
  }
}

bool SeqDspConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqDspConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* subkey_value = get_value(input_values, inputs_, 0);
  const Value* eventtime_value = get_value(input_values, inputs_, 1);
  int64_t now = get_feature_one_int64(input_values, inputs_, 2);

  //设置source中需要提取pb个数的输出
  uint64_t info_size = input_values.size() - 3;
  std::vector<const Value*> info_vec(info_size, nullptr);
  for (uint32_t i = 0; i < info_size; ++i) {
    info_vec[i] = get_value(input_values, inputs_, i + 3);
  }

  const InputFeature* inf_subkey = nullptr;
  const InputFeature* inf_eventtime = nullptr;

  uint32_t input_size = std::min(subkey_value->ifeatures.size(), eventtime_value->ifeatures.size());

  output.values.resize(1 + info_size);
  for (uint32_t i = 0; i < output.values.size(); i++) {
    Value& value = output.values[i];
    value.ifeatures.resize(input_size);
    if (0 == i) {
      value.defalut_type = tensorflow::DT_STRING;
    } else {
      value.defalut_type = tensorflow::DT_FLOAT;
    }
  }

  std::vector<tensorflow::Feature*> out_feat(1 + info_size);
  std::vector<tensorflow::FeatureList*> out_featlist(1 + info_size);

  for (uint32_t i = 0; i < input_size; ++i) {
    inf_subkey = &subkey_value->ifeatures[i];
    inf_eventtime = &eventtime_value->ifeatures[i];

    std::vector<const std::string*> subkey_vec;
    std::vector<std::vector<int64_t>> index_vecs;
    std::map<std::string, std::vector<float>> info_map;
    std::vector<const tensorflow::Feature*> info_feat(info_size, nullptr);
  
    int64_t index = 0;

    if (likely(inf_subkey->feature_list && inf_eventtime->feature_list)) {
      for (uint32_t j = 0; j < out_featlist.size(); j++) {
        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_featlist[j];
      }

      uint32_t list_size = std::min(inf_subkey->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());
      
      index_vecs.resize(list_size);
      //过滤时间,根据now_hour是否筛选当前相同小时数据
      for (uint32_t j = 0; j < list_size; j++) {
        if (now_hour_) {
          filter_compute_.fill_subkey_vec_with_index_by_hour(inf_subkey->feature_list->feature(j),
                                                             inf_eventtime->feature_list->feature(j), now, subkey_vec, index_vecs[j]);
        } else {
          filter_compute_.fill_subkey_vec_with_index(inf_subkey->feature_list->feature(j),
                                                     inf_eventtime->feature_list->feature(j), now, subkey_vec, index_vecs[j]);
        }
      }

      for (uint32_t j = 0; j < index_vecs.size(); ++j) {
        for (uint32_t k = 0; k < info_vec.size(); ++k) {
          if (i < info_vec[k]->ifeatures.size()
              && info_vec[k]->ifeatures[i].feature_list
              && info_vec[k]->ifeatures[i].feature_list->feature_size() > (int64_t)j) {
            info_feat[k] = &info_vec[k]->ifeatures[i].feature_list->feature(j);
          } else {
            info_feat[k] = nullptr;
          }
        }
        //数据写入map
        compute_one_features(subkey_vec, index, index_vecs[j], info_feat, info_map);
      }

      //空值处理
      if (info_map.empty()) {
        if (!allow_empty_output_) {
          out_featlist[0]->add_feature()->mutable_bytes_list()->add_value(default_value_);
          for (uint32_t j = 1; j < out_featlist.size(); j++) {
            out_featlist[j]->add_feature()->mutable_float_list()->add_value(0);
          }
        }
      } else {
        for (const auto& pair : info_map) {
          for (uint32_t j = 0; j < out_featlist.size(); j++) {
            out_feat[j] = out_featlist[j]->add_feature();
          }
          compute_out_features(pair, out_feat);
        }
      }

    } else {
      for (uint32_t j = 0; j < out_feat.size(); j++) {
        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_feat[j];
      }

      if (likely(inf_subkey->feature && inf_eventtime->feature)) {
        index_vecs.emplace_back();
        //过滤时间,根据now_hour是否筛选当前相同小时数据
        if (now_hour_) {
          filter_compute_.fill_subkey_vec_with_index_by_hour(*inf_subkey->feature, *inf_eventtime->feature, now, subkey_vec, index_vecs[0]);
        } else {
          filter_compute_.fill_subkey_vec_with_index(*inf_subkey->feature, *inf_eventtime->feature, now, subkey_vec, index_vecs[0]);
        }

        for (uint32_t j = 0; j < info_vec.size(); ++j) {
          if (i < info_vec[j]->ifeatures.size() && info_vec[j]->ifeatures[i].feature) {
            info_feat[j] = info_vec[j]->ifeatures[i].feature;
          }
        }
        //数据写入map
        compute_one_features(subkey_vec, index, index_vecs[0], info_feat, info_map);
      }

      //空值处理
      if (info_map.empty()) {
        if (!allow_empty_output_) {
          out_feat[0]->mutable_bytes_list()->add_value(default_value_);
          for (uint32_t j = 1; j < out_feat.size(); j++) {
            out_feat[j]->mutable_float_list()->add_value(0);
          }
        }
      } else {
        for (const auto& pair : info_map) {
          compute_out_features(pair, out_feat);
        }
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqDspConfig::compute_one_features(std::vector<const std::string*>& subkey_vec,
                                        int64_t& index,
                                        std::vector<int64_t>& index_vec,
                                        std::vector<const tensorflow::Feature*>& info_feat,
                                        std::map<std::string, std::vector<float>>& info_map) {
  std::vector<const google::protobuf::RepeatedField<float>*> info_vecs(info_feat.size(), nullptr);
  int64_t value_size = 0;
  for (uint32_t i = 0; i < info_feat.size(); i++) {
    if (unlikely(nullptr == info_feat[i])) {
      return;
    }
    
    info_vecs[i] = &info_feat[i]->float_list().value();
    if (0 == i){
      value_size = info_vecs[i]->size();
    } else {
      value_size = std::min(value_size, static_cast<int64_t>(info_vecs[i]->size()));
    }
  }
  for (uint32_t i = 0; i < index_vec.size(); i++) {
    if (value_size > index_vec[i]) {
        auto& vec = info_map[*subkey_vec[index]];
        vec.resize(info_feat.size() + 1, 0);
        vec[0] += 1;
        for (uint32_t j = 0; j < info_feat.size(); j++) {
          vec[j + 1] += (*info_vecs[j])[index_vec[i]];
        }
    }
    index++;
  }
}

void SeqDspConfig::compute_out_features(const std::pair<const std::string, std::vector<float>>& pair,
                                        std::vector<tensorflow::Feature*>& out_feat) {
  if (unlikely(pair.second.size() != out_feat.size())) {
    return;
  }
  out_feat[0]->mutable_bytes_list()->add_value(pair.first);
  for (uint32_t i = 1; i < pair.second.size(); i++) {
    out_feat[i]->mutable_float_list()->add_value(pair.second[i] / pair.second[0]);
  }
}

bool SeqNumConvertConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqNumConvertConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);
  const uint32_t batch_size = input_value->ifeatures.size();

  output.values.resize(2);
  for (uint32_t i = 0; i < 2; i++) {
    Value& value = output.values[i];
    value.ifeatures.resize(batch_size);
  }

  output.values[0].defalut_type = tensorflow::DT_STRING;
  switch (type_) {
    case 0:
    case 1: {
      output.values[1].defalut_type = tensorflow::DT_INT64;
    }
    break;

    case 2: {
      output.values[0].defalut_type = tensorflow::DT_FLOAT;
    }
    break;

    default: {
      THROW_ERROR("invalid type :" + std::to_string(type_) + ", name:" + output_);
    }
    break;
  }

  std::vector<tensorflow::Feature*> out_feat(2);
  std::vector<tensorflow::FeatureList*> out_featlist(2);
  const InputFeature* inf = nullptr;

  for (uint32_t i = 0; i < batch_size; i++) {
    inf = &input_value->ifeatures[i];
    std::map<std::string, int32_t> count_map;
    int32_t count = 0;

    if (likely(inf->feature_list)) {
      for (uint32_t j = 0; j < 2; j++) {
        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_featlist[j];
      }
      // 遍历featurelist填充count_map
      for (int32_t j = 0; j < inf->feature_list->feature_size(); j++) {
        compute_one_feature(inf->feature_list->feature(j), count, count_map);
      }
      // 输出
      for (auto& pair : count_map) {
        out_featlist[0]->add_feature()->mutable_bytes_list()->add_value(pair.first);
        switch (type_) {
          case 0:
            out_featlist[1]->add_feature()->mutable_int64_list()->add_value(pair.second);
          break;

          case 1:
            out_featlist[1]->add_feature()->mutable_int64_list()->add_value(100 * pair.second / count);
          break;

          case 2:
            out_featlist[1]->add_feature()->mutable_float_list()->add_value(100 * static_cast<float>(pair.second) / count);
          break;

          default:
            THROW_ERROR("invalid type :" + std::to_string(type_) + ", name:" + output_);
          break;
        }
      }
    } else {
      for (uint32_t j = 0; j < 2; j++) {
        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_feat[j];
      }
      // 遍历feature填充count_map
      if (likely(inf->feature)) {
        compute_one_feature(*inf->feature, count, count_map);
      }
      // 输出
      for (auto& pair : count_map) {
        out_feat[0]->mutable_bytes_list()->add_value(pair.first);
        switch (type_) {
          case 0:
            out_feat[1]->mutable_int64_list()->add_value(pair.second);
          break;

          case 1:
            out_feat[1]->mutable_int64_list()->add_value(100 * pair.second / count);
          break;

          case 2:
            out_feat[1]->mutable_float_list()->add_value(100 * static_cast<float>(pair.second) / count);
          break;

          default:
            THROW_ERROR("invalid type :" + std::to_string(type_) + ", name:" + output_);
          break;
        }
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqNumConvertConfig::compute_one_feature(const tensorflow::Feature& feat, int32_t& count, std::map<std::string, int32_t>& count_map) {
  auto& appid_vec = feat.bytes_list().value();
  count += appid_vec.size();
  for (int32_t i = 0; i < appid_vec.size(); i++) {
    count_map[appid_vec[i]]++;
  }
}

bool SeqDayNDirectConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqDayNDirectConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* message_value = get_value(input_values, inputs_, 0);
  int64_t now = get_feature_one_int64(input_values, inputs_, 1);

  const uint32_t batch_size = message_value->ifeatures.size();
  const InputFeature* inf_message = nullptr;
  const google::protobuf::Message* mess = nullptr;
  uint32_t extract_size = fields_.size();
  std::vector<tensorflow::Feature*> out_feat(extract_size);
  std::vector<tensorflow::FeatureList*> out_featlist(extract_size);

  output.values.resize(extract_size);
  for (uint32_t i = 0; i < extract_size; i++) {
    Value& value = output.values[i];
    value.ifeatures.resize(batch_size);
  }
  MessageCompute::message_fill_fields_dtype_to_value(message_value, fields_, output.values, output_);

  //输出
  for (uint32_t i = 0; i < batch_size; i++) {
    inf_message = &message_value->ifeatures[i];
    std::vector<const google::protobuf::Message*> topn_vec;
    int64_t time = 0;

    //将value和message填充到vec
    for (uint32_t j = 0; j < inf_message->messages.size(); j++) {
      mess = inf_message->messages[j];
      MessageCompute::message_fill_to_int64(mess, eventtime_key_, output_, time);
      //时间戳数据为13位
      if ((now - time) > start_ && (end_ < 0 || (now - time) < end_)) {
        topn_vec.emplace_back(mess);
      }
    }

    //长度截断,按数据顺序截断
    if (clip_size_ > 0 && (int64_t)topn_vec.size() > clip_size_) {
      topn_vec.resize(clip_size_);
    }

    // 输出符合条件的message指定的fields
    if (likely(!inputs_[0].from_request || inputs_[0].repeated_count != 0)) {
      for (uint32_t j = 0; j < extract_size; j++) {
        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_featlist[j];
      }

      for (const google::protobuf::Message* mess : topn_vec) {
        for (uint32_t j = 0; j < extract_size; j++) {
          out_feat[j] = out_featlist[j]->add_feature();
        }
        MessageCompute::message_fill_fields_to_feature(mess, fields_, output_, out_feat);
      }
    } else {
      for (uint32_t j = 0; j < extract_size; j++) {
        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_feat[j];
      }

      for (const google::protobuf::Message* mess : topn_vec) {
        MessageCompute::message_fill_fields_to_feature(mess, fields_, output_, out_feat);
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

bool SeqMergeV2Config::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqMergeV2Config::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* off_message_value = get_value(input_values, inputs_, 0);
  const Value* nl_message_value = get_value(input_values, inputs_, 1);

  uint32_t input1_size = off_message_value->ifeatures.size();
  uint32_t input2_size = nl_message_value->ifeatures.size();

  // 不支持user数据和item数据之间，进行有效值代替读取
  if (input1_size != input2_size) {
    THROW_ERROR("invalid source, input1_value_size not euqal input2_value_size, name:" + output_);
    return false;
  }

  output.values.resize(1);
  Value& value = output.values[0];
  value.ifeatures.resize(input1_size);

  const InputFeature* inf_value1 = nullptr;
  const InputFeature* inf_value2 = nullptr;

  for (uint32_t i = 0; i < input1_size; i++) {
    inf_value1 = &off_message_value->ifeatures[i];
    inf_value2 = &nl_message_value->ifeatures[i];

    std::set<std::string> filter_set;
    std::vector<std::pair<int64_t, const google::protobuf::Message*>> time_vec;
    std::vector<const google::protobuf::Message*> topn_vec;

    //获取离线信息和时间,填充appid+eventime信息
    fill_message_to_vec(inf_value1, filter_set, time_vec);
    //获取不重复的近线信息和时间
    fill_message_to_vec(inf_value2, filter_set, time_vec);
  
    //排序
    top_n_compute_.compute_vec<int64_t>(time_vec, topn_vec);

    for (auto& mess : topn_vec) {
      value.ifeatures[i].messages.push_back(mess);
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqMergeV2Config::fill_message_to_vec(const InputFeature* mess_value,
                                           std::set<std::string>& filter_set,
                                           std::vector<std::pair<int64_t, const google::protobuf::Message*>>& time_vec) {
  if (mess_value) {
    const google::protobuf::Message* mess = nullptr;
    int64_t time = 0;
    std::string appid;

    for (uint32_t i = 0; i < mess_value->messages.size(); i++) {
      mess = mess_value->messages[i];
      MessageCompute::message_fill_to_int64(mess, eventtime_key_, output_, time);
      MessageCompute::message_fill_to_string(mess, appid_key_, output_, appid);
      //拼接
      appid.append(std::to_string(time));

      if (filter_set.insert(appid).second) {
        time_vec.emplace_back(time, mess);
      }
    }
  }
}

bool SeqInterval::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqInterval::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* appid_list_value = get_value(input_values, inputs_, 0);
  const Value* first_eventtime_value = get_value(input_values, inputs_, 1);
  const Value* second_eventtime_value = get_value(input_values, inputs_, 2);
  const Value* third_eventtime_value = get_value(input_values, inputs_, 3);
  int64_t now = get_feature_one_int64(input_values, inputs_, 4);
  const Value* appid_value = get_value(input_values, inputs_, 5);

  uint32_t input_size = std::min(static_cast<uint32_t>(appid_value->ifeatures.size()), static_cast<uint32_t>(first_eventtime_value->ifeatures.size()));
  input_size = std::min(input_size, static_cast<uint32_t>(second_eventtime_value->ifeatures.size()));
  input_size = std::min(input_size, static_cast<uint32_t>(third_eventtime_value->ifeatures.size()));

  const InputFeature* inf_appid = nullptr;
  const InputFeature* inf_eventtime = nullptr;
  std::vector<AppIdWithEventTime> appid_info_vec;
  std::vector<std::vector<int64_t>> appid_feat_value_index;
  std::vector<AppIdWithEventTime*> appid_info_vec_ptr;
  std::map<std::string, std::vector<int64_t>> appid_info_map;
  appid_feat_value_index.resize(input_size);

  const uint32_t batch_size = appid_value->ifeatures.size();
  output.values.resize(2);
  for (uint32_t i = 0; i < 2; i++) {
    Value& value = output.values[i];
    value.ifeatures.resize(batch_size);
  }
  output.values[0].defalut_type = tensorflow::DT_FLOAT;
  output.values[1].defalut_type = tensorflow::DT_INT64;

  std::vector<tensorflow::Feature*> out_feat(2);
  std::vector<tensorflow::FeatureList*> out_featlist(2);

  for (uint32_t i = 0; i < batch_size; ++i) {
    if (i < input_size) {
      appid_info_vec_ptr.clear();
      appid_info_vec.clear();
      appid_feat_value_index.clear();
      appid_info_map.clear();

      inf_appid = &appid_list_value->ifeatures[i];
      inf_eventtime = &first_eventtime_value->ifeatures[i];
      if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
        uint32_t list_size = std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());
        appid_feat_value_index.resize(list_size);
        for (uint32_t j = 0; j < list_size; j++) {
          filter_compute_.fill_appid_vec_with_index(inf_appid->feature_list->feature(j), inf_eventtime->feature_list->feature(j), now, appid_info_vec, appid_feat_value_index[j]);
        }
      } else if (likely(inf_appid->feature && inf_eventtime->feature)) {
        appid_feat_value_index.emplace_back();
        filter_compute_.fill_appid_vec_with_index(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_vec, appid_feat_value_index[0]);
      }

      //获得last2,last3的eventtime
      fill_eventtime_map(second_eventtime_value, third_eventtime_value, appid_info_vec, i, appid_feat_value_index, appid_info_map);

      //排序、截断
      top_n_compute_.compute_vec(appid_info_vec, appid_info_vec_ptr);

      //填充map
      fill_appid_map(appid_info_vec_ptr, now, appid_info_map);
    }

    inf_appid = &appid_value->ifeatures[i];

    if (likely(inf_appid->feature_list)) {
      for (uint32_t j = 0; j < 2; j++) {
        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_featlist[j];
      }

      for (uint32_t j = 0; j < (uint32_t)inf_appid->feature_list->feature_size(); j++) {
        out_feat[0] = out_featlist[0]->add_feature();
        out_feat[1] = out_featlist[1]->add_feature();
        compute_one_feature(inf_appid->feature_list->feature(j), appid_info_map, out_feat);
      }
    } else {
      for (uint32_t j = 0; j < 2; j++) {
        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_feat[j];
      }

      if (likely(inf_appid->feature)) {
        compute_one_feature(*inf_appid->feature, appid_info_map, out_feat);
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqInterval::fill_eventtime_map(const Value* second_eventtime_value,
                                     const Value* third_eventtime_value,
                                     const std::vector<AppIdWithEventTime>& appid_info_vec,
                                     uint32_t i,
                                     const std::vector<std::vector<int64_t>>& appid_feat_value_index,
                                     std::map<std::string, std::vector<int64_t>>& appid_info_map) {
  uint32_t index = 0;
  for (uint32_t j = 0; j < appid_feat_value_index.size(); ++j) {
    auto& vec = appid_feat_value_index[j];
    for (uint32_t k = 0; k < vec.size(); ++k) {
      appid_info_map[*appid_info_vec[index].appid].emplace_back(appid_info_vec[index].eventtime);
      fill_eventtime_one(second_eventtime_value, i, j, vec[k], *appid_info_vec[index].appid, appid_info_map);
      fill_eventtime_one(third_eventtime_value, i, j, vec[k], *appid_info_vec[index].appid, appid_info_map);
      index++;
    }
  }
}

void SeqInterval::fill_eventtime_one(const Value* value,
                                     uint32_t i,
                                     uint32_t j,
                                     uint32_t k,
                                     const std::string& str,
                                     std::map<std::string, std::vector<int64_t>>& appid_info_map) {
  const InputFeature* inf = nullptr;
  const tensorflow::Feature* feat = nullptr;
  if (value->ifeatures.size() > i) {
    inf = &value->ifeatures[i];
    if (inf->feature_list && (uint32_t)inf->feature_list->feature_size() > j) {
      feat = &inf->feature_list->feature(j);
    } else if (inf->feature && 0 == j) {
      feat = inf->feature;
    }
    if (feat && (uint32_t)feat->int64_list().value_size() > k) {
      appid_info_map[str].emplace_back(feat->int64_list().value(k));
      return;
    }
  }
  //没有数据填0
  appid_info_map[str].emplace_back(0);
}

void SeqInterval::fill_appid_map(const std::vector<AppIdWithEventTime*>& appid_info_vec_ptr,
                                 int64_t now,
                                 std::map<std::string, std::vector<int64_t>>& appid_info_map) {
  std::map<std::string, std::vector<int64_t>> temp_map;
  appid_info_map.swap(temp_map);
  for(auto& ptr : appid_info_vec_ptr) {
    auto itr = temp_map.find(*ptr->appid);
    auto& vec = appid_info_map[*(ptr->appid)];
    vec.emplace_back(itr->second[0]);
    vec.emplace_back(itr->second[1]);
    vec.emplace_back(itr->second[2]);
    fill_diffreence(vec, now);
  }
}

void SeqInterval::compute_one_feature(const tensorflow::Feature& feat,
                                      const std::map<std::string, std::vector<int64_t>>& appid_info_map,
                                      std::vector<tensorflow::Feature*>& out_feat) {
  float mean = 0;
  for (const std::string& appid : feat.bytes_list().value()) {
    auto itr = appid_info_map.find(appid);
    if (itr != appid_info_map.end()) {
      auto& vec = itr->second;
      out_feat[1]->mutable_int64_list()->add_value(vec[0]);
      // last_time2为空，时间间隔和均值差填默认值
      if (vec[1] == 0) {
        out_feat[1]->mutable_int64_list()->add_value(default_interval_);
        out_feat[0]->mutable_float_list()->add_value(default_mean_);
      } else {
        out_feat[1]->mutable_int64_list()->add_value(vec[1]);
        mean = Math::round_to_n_decimal_places(std::fabs(calculate_mean_ratio(vec)), 4);
        out_feat[0]->mutable_float_list()->add_value(mean);
      }
      // last_time3为空，时间间隔填默认值
      if (vec[2] == 0) {
        out_feat[1]->mutable_int64_list()->add_value(default_interval_);
      } else {
        out_feat[1]->mutable_int64_list()->add_value(vec[2]);
      }
    } else {
      out_feat[0]->mutable_float_list()->add_value(default_mean_);
      out_feat[1]->mutable_int64_list()->add_value(default_interval_);
      out_feat[1]->mutable_int64_list()->add_value(default_interval_);
      out_feat[1]->mutable_int64_list()->add_value(default_interval_);
    }
  }
}

void SeqInterval::fill_diffreence(std::vector<int64_t>& data, int64_t now) {
  int64_t num1 = now - data[0];
  int64_t num2 = 0;
  int64_t num3 = 0;
  if (data[1] != 0) {
    num2 = data[0] - data[1];
  } 
  if (data[2] != 0) {
    num3 = data[1] - data[2];
  }
  data[0] = num1;
  data[1] = num2;
  data[2] = num3;
}

float SeqInterval::calculate_mean_ratio(const std::vector<int64_t>& data) {
  // 计算均值
  float mean1 = (data[0] + data[1] + data[2]) / 3; // 均值1
  float mean2 = (data[1] + data[2]) / 2;     // 均值2

  // 计算均值比值
  float ratio = mean1 / mean2;
  return ratio;
}

void SeqMaxValueConfig::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out, int64_t now) {
  bool found_max_event_time = false;
  int64_t max_event_time = std::numeric_limits<int64_t>::min();
  bool found_start_bounded_time = false;
  const auto& event_time_list = feat.int64_list();
  for (int i = 0; i < event_time_list.value_size(); i++) {
    int64_t event_time = event_time_list.value(i);
    if (now - event_time > start_ && event_time > max_event_time) {
      max_event_time = event_time;
      found_start_bounded_time = true;
    }
  }
  if (found_start_bounded_time && (day_n_ms_ < 0 || now - max_event_time < day_n_ms_)) {
    found_max_event_time = true;
  }

  if (found_max_event_time) {
    out->mutable_int64_list()->add_value(max_event_time);
  } else {
    out->mutable_int64_list()->add_value(default_value_);
  }
}

void SeqMaxValueConfig::compute_one_featurelist(const tensorflow::FeatureList& featlist, tensorflow::Feature* out, int64_t now) {
  bool found_max_event_time = false;
  int64_t max_event_time = std::numeric_limits<int64_t>::min();
  bool found_start_bounded_time = false;
  for (const auto& feat : featlist.feature()) {
    const auto& event_time_list = feat.int64_list();
    for (int i = 0; i < event_time_list.value_size(); i++) {
      int64_t event_time = event_time_list.value(i);
      if (now - event_time > start_ && event_time > max_event_time) {
        max_event_time = event_time;
        found_start_bounded_time = true;
      }
    }
  }
  if (found_start_bounded_time && (day_n_ms_ < 0 || now - max_event_time < day_n_ms_)) {
    found_max_event_time = true;
  }

  if (found_max_event_time) {
    out->mutable_int64_list()->add_value(max_event_time);
  } else {
    out->mutable_int64_list()->add_value(default_value_);
  }
}


bool SeqMaxValueConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  LogDebug("------------ SeqMaxValue::compute {} start ------------", input_values);
  const Value* input_value = get_value(input_values, inputs_, 0);
  int64_t now = get_feature_one_int64(input_values, inputs_, 1);
  const uint32_t batch_size = input_value->ifeatures.size();
  const InputFeature* inf = nullptr;
  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;

  // Output output;
  output.values.resize(1);
  auto& value = output.values[0];
  value.ifeatures.resize(batch_size);

  for (uint32_t i = 0; i < batch_size; i++) {
    inf = &input_value->ifeatures[i];
    if (likely(inf->feature)) {
      //PointTimer t("OneInputConfig");
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      //t.point("arena");
      value.ifeatures[i].feature = out_feature;
      compute_one_feature(*inf->feature, out_feature, now);
      //t.point("compute");
      //t.display();
    } else if (likely(inf->feature_list)) {
      out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_featurelist;
      compute_one_featurelist(*(inf->feature_list), out_featurelist->add_feature(), now);
    }
  }

  fill_value_dtype(value.defalut_type);

  LogDebug("------------ SeqMaxValue::compute {} done ------------", output_);
  return true;
}

bool SeqBackDaysConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqBackDaysConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* eventtime_value = get_value(input_values, inputs_, 0);
  int64_t now = get_feature_one_int64(input_values, inputs_, 1);

  const InputFeature* inf_eventtime = nullptr;

  uint32_t input_size = eventtime_value->ifeatures.size();

  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_INT64;
  value.ifeatures.resize(input_size);

  for (uint32_t i = 0; i < input_size; ++i) {
    inf_eventtime = &eventtime_value->ifeatures[i];

    std::vector<int64_t> eventtime_sub_vec;
    std::vector<int64_t> back_days_vec;

    if (likely(inf_eventtime->feature_list)) {
      uint32_t list_size = inf_eventtime->feature_list->feature_size();
      for (uint32_t j = 0; j < list_size; j++) {
        filter_compute_.fill_time_vec(inf_eventtime->feature_list->feature(j), now, eventtime_sub_vec);
      }

      compute_back_days(eventtime_sub_vec, now, back_days_vec);

      tensorflow::FeatureList* out_feature_list = nullptr;
      out_feature_list = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_feature_list;

      for (const auto& back_day : back_days_vec) {
        out_feature_list->add_feature()->mutable_int64_list()->add_value(back_day);
      }
    } else {
      tensorflow::Feature* out_feature = nullptr;
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;

      if (likely(inf_eventtime->feature)) {
        //防穿越
        filter_compute_.fill_time_vec(*inf_eventtime->feature, now, eventtime_sub_vec);
        compute_back_days(eventtime_sub_vec, now, back_days_vec);
      }

      for (const auto& back_day : back_days_vec) {
        out_feature->mutable_int64_list()->add_value(back_day);
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqBackDaysConfig::compute_back_days(const std::vector<int64_t>& eventtime_vec, const int64_t& now, std::vector<int64_t>& back_days_vec) {
  back_days_vec.reserve(eventtime_vec.size());
  int64_t millisecondsInADay = 1000 * 60 * 60 * 24; // 86400000
  for (const int64_t& time: eventtime_vec) {
    int64_t back_day = (now - time) / millisecondsInADay;
    back_days_vec.emplace_back(back_day);
  }
}

bool SeqIntervalDaysConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("SeqIntervalDaysConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* eventtime_value = get_value(input_values, inputs_, 0);
  int64_t now = get_feature_one_int64(input_values, inputs_, 1);

  const InputFeature* inf_eventtime = nullptr;

  uint32_t input_size = eventtime_value->ifeatures.size();

  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_INT64;
  value.ifeatures.resize(input_size);

  for (uint32_t i = 0; i < input_size; ++i) {
    inf_eventtime = &eventtime_value->ifeatures[i];

    std::vector<int64_t> eventtime_sub_vec;
    std::vector<int64_t> interval_days_vec;

    if (likely(inf_eventtime->feature_list)) {
      uint32_t list_size = inf_eventtime->feature_list->feature_size();
      for (uint32_t j = 0; j < list_size; j++) {
        filter_compute_.fill_time_vec(inf_eventtime->feature_list->feature(j), now, eventtime_sub_vec);
      }

      compute_interval_days(eventtime_sub_vec, interval_days_vec);

      tensorflow::FeatureList* out_feature_list = nullptr;
      out_feature_list = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_feature_list;

      for (const auto& interval_day : interval_days_vec) {
        out_feature_list->add_feature()->mutable_int64_list()->add_value(interval_day);
      }
    } else {
      tensorflow::Feature* out_feature = nullptr;
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;

      if (likely(inf_eventtime->feature)) {
        //防穿越
        filter_compute_.fill_time_vec(*inf_eventtime->feature, now, eventtime_sub_vec);
        compute_interval_days(eventtime_sub_vec, interval_days_vec);
      }

      for (const auto& interval_day : interval_days_vec) {
        out_feature->mutable_int64_list()->add_value(interval_day);
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void SeqIntervalDaysConfig::compute_interval_days(const std::vector<int64_t>& eventtime_vec, std::vector<int64_t>& interval_days_vec) {
  if (eventtime_vec.size() <= 1) return;
  interval_days_vec.reserve(eventtime_vec.size() - 1);
  int64_t millisecondsInADay = 1000 * 60 * 60 * 24; // 86400000
  for (uint32_t i = 0; i < eventtime_vec.size() - 1; i++) {
    int64_t interval_day = (eventtime_vec[i] - eventtime_vec[i+1]) / millisecondsInADay;
    interval_days_vec.emplace_back(interval_day);
  }
}