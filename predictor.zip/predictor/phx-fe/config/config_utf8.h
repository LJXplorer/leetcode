#ifndef FE_CONFIG_UTF8
#define FE_CONFIG_UTF8

#include "config.h"
#include "phx-fe/util/calc.h"
#include <unordered_set>

class Utf8BaseCompute {
 public:
  explicit Utf8BaseCompute() {}

  virtual ~Utf8BaseCompute() {}

  //c最高位为0，为单字节字符首字节
  static bool is_1byte_head(const char c) {
    return 0 == (0x80 & c & 0xFF);
  }

  //c最高位为1，次高位为1，即0xC0，为双字节字符首字节
  static bool is_2byte_head(const char c) {
    return 0xC0 == (0xE0 & c & 0xFF);
  }

  //c最高位为1，次高位为1，第三位为1，即0xE0，为三字节字符首字节
  static bool is_3byte_head(const char c) {
    return 0xE0 == (0xF0 & c & 0xFF);
  }

  //c最高位为1，次高位为1，第三第四位为1，即0xF0，为四字节字符首字节
  static bool is_4byte_head(const char c) {
    return 0xF0 == (0xF8 & c & 0xFF);
  }

  //获得当前字符的字节宽度
  static int32_t byte_width(const char c) {
    if (is_1byte_head(c)) {
      return 1;
    }

    if (is_2byte_head(c)) {
      return 2;
    }

    if (is_3byte_head(c)) {
      return 3;
    }

    if (is_4byte_head(c)) {
      return 4;
    }

    return 1;
  }

  //判断两个utf8字符是否相等
  static bool is_equal(const char* word1, const char* word2) {
    int32_t w1 = byte_width(*word1);
    int32_t w2 = byte_width(*word2);

    //先判断长度
    if (w1 != w2) {
      return false;
    }

    //再判断字符字节
    for (int32_t i = 0; i < w1; i++) {
      if (word1[i] != word2[i]) {
        return false;
      }
    }

    return true;
  }

  //判断当前字符是不是特定字符,二字节
  static bool is_equal(const char* word1, char word2_1, char word2_2) {
    if (word1[0] != word2_1 || word1[1] != word2_2) {
      return false;
    }

    return true;
  }

  //判断当前字符是不是特定字符，三字节
  static bool is_equal(const char* word1, char word2_1, char word2_2, char word2_3) {
    if (word1[0] != word2_1 || word1[1] != word2_2 || word1[2] != word2_3) {
      return false;
    }

    return true;
  }


  //判断二字节是不是中文标点符号,如果是，返回当前字符宽度，如果不是，返回0
  static int32_t is_cn2_punct(const char* word) {
    static std::vector<std::vector<char>> vec2 = {
      {(char)0xC2, (char)0xB7}, // 中文 ·
    };

    for (uint32_t i = 0; i < vec2.size(); i++) {
      if (is_equal(word, vec2[i][0], vec2[i][1])) {
        return 2;
      }
    }

    return 0;
  }

  //判断三字节是不是中文标点符号,如果是，返回当前字符宽度，如果不是，返回0
  static int is_cn3_punct(const char* word) {
    static std::vector<std::vector<char>> vec3 = {
      {(char)0xEF, (char)0xBC, (char)0x8C}, // 中文 逗号，
      {(char)0xE3, (char)0x80, (char)0x82}, // 中文 句号。
      {(char)0xEF, (char)0xBC, (char)0x9F}, // 中文 问号？
      {(char)0xEF, (char)0xBC, (char)0x81}, // 中文 叹号！
      {(char)0xEF, (char)0xBC, (char)0x9B}, // 中文 分号；
      {(char)0xEF, (char)0xBC, (char)0x9A}, // 中文 冒号：
      {(char)0xE2, (char)0x80, (char)0x9C}, // 中文 左引号“
      {(char)0xE2, (char)0x80, (char)0x9D}, // 中文 右引号“
      {(char)0xEF, (char)0xBC, (char)0x88}, // 中文 左括号（
      {(char)0xEF, (char)0xBC, (char)0x89}, // 中文 右括号）
      {(char)0xEF, (char)0xBF, (char)0xA5}, // 中文 ￥
      {(char)0xE3, (char)0x80, (char)0x90}, // 【
      {(char)0xE3, (char)0x80, (char)0x91}, // 】
      {(char)0xE3, (char)0x80, (char)0x8A}, // 《
      {(char)0xE3, (char)0x80, (char)0x8B}, // 》
      {(char)0xE2, (char)0x80, (char)0xA6}, // …
      {(char)0xE3, (char)0x80, (char)0x81}, // 、
      {(char)0xE2, (char)0x80, (char)0x94}, // —
      {(char)0xE2, (char)0x80, (char)0x98}, // ‘
      {(char)0xE2, (char)0x80, (char)0x99}, // ’
    };

    for (uint32_t i = 0; i < vec3.size(); i++) {
      if (is_equal(word, vec3[i][0], vec3[i][1], vec3[i][2])) {
        return 3;
      }
    }

    return 0;
  }

  static bool is_allowed_codepoint(uint32_t code_point) {
    // 定义允许的字符范围
    static const std::array<std::pair<uint32_t, uint32_t>, 8> allowed_ranges = { {
        {0x4E00, 0x9FFF}, // 中文 (CJK Unified)
        {0x3040, 0x309F}, // 日文平假名
        {0x0600, 0x06FF}, // 阿拉伯语
        {0xAC00, 0xD7AF}, // 韩文 (Hangul Syllables)
        {0x3400, 0x4DBF}, // 中文扩展A区
        {'0', '9'},       // 数字
        {'A', 'Z'},       // 大写字母
        {'a', 'z'}        // 小写字母
      }
    };

    // 遍历所有范围进行检查
    for (const auto& range : allowed_ranges) {
      if (code_point >= range.first && code_point <= range.second) {
        return true;
      }
    }
    return false;
  }

  //跳转到下一个字符的起始位置
  static const char* get_next_word(const char* word) {
    return word + byte_width(*word);
  }

  //判断字符串的字符数
  static int32_t length(const char* word, const int32_t len) {
    int32_t l = 0; // utf8字符数
    for (int32_t i = 0; i < len; ) {
      l++;
      i += byte_width(word[i]);
    }

    return l;
  }

  static void split_to_vec(const std::string& word, const int32_t split_width, std::vector<std::string>& vec) {
    const char* p = word.c_str();
    int32_t w = 0;
    const char* start = p;        // 本次分割数据的起始位置
    int32_t item = 0;             // 本次分割数据的累计字符数

    for (uint32_t i = 0; i < word.length(); ) {
      w = byte_width(p[i]);
      i += w;

      //累计字符数大于等于切割字符数，容器加入一个utf8字符串
      if (++item >= split_width) {
        vec.emplace_back(start, p + i - start);

        item = 0;
        start = p + i;
      }
    }

    if (item > 0) {
      vec.emplace_back(start, p + word.length() - start);
    }
  }

  static void split_to_set(const std::string& word, const int32_t split_width, std::set<std::string>& set) {
    const char* p = word.c_str();
    int32_t w = 0;
    const char* start = p;        // 本次分割数据的起始位置
    int32_t item = 0;             // 本次分割数据的累计字符数

    for (uint32_t i = 0; i < word.length(); ) {
      w = byte_width(p[i]);
      i += w;

      //累计字符数大于等于切割字符数，容器加入一个utf8字符串
      if (++item >= split_width) {
        set.emplace(start, p + i - start);

        item = 0;
        start = p + i;
      }
    }

    if (item > 0) {
      set.emplace(start, p + word.length() - start);
    }
  }

  static void split_to_pair_map(const std::string& word, const int32_t split_width, bool first, std::map<std::string, std::pair<int64_t, int64_t>>& pair_map) {
    const char* p = word.c_str();
    int32_t w = 0;
    const char* start = p;        // 本次分割数据的起始位置
    int32_t item = 0;             // 本次分割数据的累计字符数

    for (uint32_t i = 0; i < word.length(); ) {
      w = byte_width(p[i]);
      i += w;

      //累计字符数大于等于切割字符数，容器加入一个utf8字符串
      if (++item >= split_width) {
        auto& pair = pair_map[std::string(start, p + i - start)];
        if (first) {
          pair.first++;
        } else {
          pair.second++;
        }

        item = 0;
        start = p + i;
      }
    }

    if (item > 0) {
      auto& pair = pair_map[std::string(start, p + word.length() - start)];
      if (first) {
        pair.first++;
      } else {
        pair.second++;
      }
    }
  }

static void cosine_similarity(const std::map<std::string, std::pair<int64_t, int64_t>>& pair_map, float& value) {
  float sum = 0;
  float first_dividend = 0;
  float second_dividend = 0;

  for (auto& pair : pair_map) {
    sum += pair.second.first * pair.second.second;
    first_dividend += pair.second.first * pair.second.first;
    second_dividend += pair.second.second * pair.second.second;
  }

  value = sum / (pow(first_dividend, 0.5) * pow(second_dividend, 0.5));
}
};

//int_input：int32转string + 私有成员 delimiter_ + join_length：int32转string
class Utf8JoinConfig : public TowInputConfig {
 public:
  explicit Utf8JoinConfig(const std::string& output,
                          const std::vector<std::string>& source,
                          DefaultValue& default_input_value,
                          bool save,
                          bool allow_empty_output,
                          const std::vector<std::string>& strategy,
                          const std::string& delimiter,
                          bool cross = false)
      : TowInputConfig(output, source, default_input_value, save, allow_empty_output, strategy, cross), delimiter_(delimiter) {}
  virtual std::string get_config() override {
    return "utf8_join:delimiter:" + delimiter_;
  }

  virtual ~Utf8JoinConfig() {}

 private:
  //分隔符
  std::string delimiter_;

  virtual void compute_one_feature(const tensorflow::Feature& input_feat1,
                                    const tensorflow::Feature& input_feat2,
                                    tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_STRING;
  }
};

// 判断str1和str2公共的utf8前缀长度
class Utf8PrefixRepetitionStringConfig : public TowInputConfig {
 public:
  explicit Utf8PrefixRepetitionStringConfig(const std::string& output,
                                        const std::vector<std::string>& source,
                                        DefaultValue& default_input_value,
                                        bool save,
                                        bool allow_empty_output,
                                        const std::vector<std::string>& strategy,
                                        bool cross = false)
      : TowInputConfig(output, source, default_input_value, save, allow_empty_output, strategy, cross) {}
  virtual std::string get_config() override {
    return "utf8_prefix_repetition_string";
  }

  virtual ~Utf8PrefixRepetitionStringConfig() {}

 private:
  virtual void compute_one_feature(const tensorflow::Feature& input_feat1,
                                    const tensorflow::Feature& input_feat2,
                                    tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_FLOAT;
  }
  float get_prefix_repetition(const std::string& word1, const std::string& word2);
};

//转换成utf8长度
class Utf8LengthConfig : public OneInputConfig {
 public:
  explicit Utf8LengthConfig(const std::string& output,
                            const std::vector<std::string>& source,
                            DefaultValue& default_input_value,
                            bool save,
                            bool allow_empty_output,
                            const std::vector<std::string>& strategy)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy) {}
  virtual std::string get_config() override {
    return "utf8_length";
  }

  virtual ~Utf8LengthConfig() {}

 private:
  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_INT64;
  }
};

//去除中文符号、制表符、换行符和空格
class Utf8PreprocessConfig : public OneInputConfig {
 public:
  explicit Utf8PreprocessConfig(const std::string& output,
                                const std::vector<std::string>& source,
                                DefaultValue& default_input_value,
                                bool save,
                                bool allow_empty_output,
                                const std::vector<std::string>& strategy)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy) {}
  virtual std::string get_config() override {
    return "utf8_preprocess";
  }

  virtual ~Utf8PreprocessConfig() {}

 private:
  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_STRING;
  }
  std::string format(const std::string& word);
};

//按split_width_长度切词utf8,只取feature中的第一个string
class Utf8SplitConfig : public Config {
 public:
  explicit Utf8SplitConfig(const std::string& output,
                            const std::vector<std::string>& source,
                            DefaultValue& default_input_value,
                            bool save,
                            bool allow_empty_output,
                            const std::vector<std::string>& strategy,
                            int32_t split_width)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), split_width_(split_width) {}
  virtual std::string get_config() override {
    return "utf8_split:split_width:" + std::to_string(split_width_);
  }

  virtual ~Utf8SplitConfig() {}

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  //utf8字符截断长度
  uint32_t split_width_;

  void compute_one_feature(const tensorflow::Feature& input_feat,
                            tensorflow::Feature* out);
};

class Utf8SplitToListConfig : public Config {
  public:
  explicit Utf8SplitToListConfig(const std::string& output,
    const std::vector<std::string>& source,
    DefaultValue& default_input_value,
    bool save,
    bool allow_empty_output,
    const std::vector<std::string>& strategy,
    const std::string& sep,
    const std::string& filters)
: Config(output, source, default_input_value, save, allow_empty_output, strategy), sep_(sep) {
    auto vec = Calc::split_string(filters, ",");
    filters_.insert(vec.begin(), vec.end());
  }
  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
  virtual ~Utf8SplitToListConfig() {}
  private:
    void compute_one_feature(const tensorflow::Feature& input_feat, tensorflow::Feature* out);
    std::unordered_set<std::string> filters_;
    std::string sep_;
};

class Utf8IpToListConfig : public Config {
  public:
  explicit Utf8IpToListConfig(const std::string& output,
    const std::vector<std::string>& source,
    DefaultValue& default_input_value,
    bool save,
    bool allow_empty_output,
    const std::vector<std::string>& strategy,
    const std::string& sep)
: Config(output, source, default_input_value, save, allow_empty_output, strategy), sep_(sep) {}
  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
  virtual ~Utf8IpToListConfig() {}
  private:
    void compute_one_feature(const tensorflow::Feature& input_feat, tensorflow::Feature* out);
    std::string sep_;
};

//过滤掉长度为n的utf8字符串
class Utf8FilterConfig : public OneInputConfig {
 public:
  explicit Utf8FilterConfig(const std::string& output,
                            const std::vector<std::string>& source,
                            DefaultValue& default_input_value,
                            bool save,
                            bool allow_empty_output,
                            const std::vector<std::string>& strategy,
                            int64_t length)
      : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy),
        length_(length) {}
  virtual std::string get_config() override {
    std::string display = "utf8_filter:length:";
    display.append(std::to_string(length_));
    return display;
  }

  virtual ~Utf8FilterConfig() {}

 private:
  int64_t length_; //过滤的长度
  virtual void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_STRING;
  }
};

// 返回两个输入utf8字符的重复的余弦相似度,cross默认开启
class Utf8RepetitionStringConfig : public TowInputConfig {
 public:
  explicit Utf8RepetitionStringConfig(const std::string& output,
                                      const std::vector<std::string>& source,
                                      DefaultValue& default_input_value,
                                      bool save,
                                      bool allow_empty_output,
                                      const std::vector<std::string>& strategy,
                                      bool cross = true)
      : TowInputConfig(output, source, default_input_value, save, allow_empty_output, strategy, cross) {}
  virtual std::string get_config() override {
    return "utf8_repetition_string";
  }

  virtual ~Utf8RepetitionStringConfig() {}

 private:
  virtual void compute_one_feature(const tensorflow::Feature& input_feat1,
                                    const tensorflow::Feature& input_feat2,
                                    tensorflow::Feature* out) override;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_FLOAT;
  }
  void coincide_string(const std::string& input1, const std::string& input2, std::string& output);
};

#endif  // FE_CONFIG_UTF8