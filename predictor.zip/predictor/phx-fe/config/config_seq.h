#ifndef FE_CONFIG_SEQ
#define FE_CONFIG_SEQ

#include "config.h"
#include "phx-fe/util/item_class.h"
#include <cstdint>
#include <string>

// 排序方式
enum SortType {
  ByTimestamp = 1,  //ByTimestamp按时间戳的大小排序
  ByCount = 2,      //ByCount按次数排序，次数相同按最新时间戳的大小排序
  ByValue = 3       //ByValue按次数排序，次数相同按最新时间戳的大小排序
};

// 用于TopN计算
class SeqTopNCompute {
 public:
  explicit SeqTopNCompute(SortType type, int64_t topn, int64_t reserve = 0) : type_(type), topn_(topn), reserve_(reserve) {}
  virtual ~SeqTopNCompute() {}

  void compute_vec(std::vector<AppIdWithEventTime>& appid_info_vec, std::vector<AppIdWithEventTime*>& appid_info_vec_ptr) {
    uint32_t size = appid_info_vec.size();
    if (size == 0) {
      return;
    }
    appid_info_vec_ptr.reserve(size);

    //ByCount按次数排序，次数相同按最新时间戳的大小排序
    if (type_ == SortType::ByCount) {
      // std::unordered_map<std::string, AppIdWithEventTime*> appid_value;
      std::unordered_map<std::string, int64_t> appid_count;
      appid_count.reserve(size);
      // appid_value.reserve(size);

      for (uint32_t i = 0; i < size; ++i) {
        appid_count[*appid_info_vec[i].appid]++;
        // auto& ptr = appid_value[*appid_info_vec[i].appid];
        // if (ptr == nullptr || ptr->eventtime < appid_info_vec[i].eventtime) {
        //   ptr = &appid_info_vec[i];
        // }
      }

      // 保持原有顺序
      // for (uint32_t i = 0; i < size; ++i) {
      //   if (&appid_info_vec[i] == appid_value[*appid_info_vec[i].appid]) {
      //     appid_info_vec_ptr.emplace_back(&appid_info_vec[i]);
      //   }
      // }

      // std::sort(appid_info_vec_ptr.begin(), appid_info_vec_ptr.end(), [this, &appid_count](const AppIdWithEventTime* a, const AppIdWithEventTime* b) {
      //   return compareAppIdWithEventTimeByCount<int64_t>(*a, *b, appid_count, reserve_);
      // });
  
      std::sort(appid_info_vec.begin(), appid_info_vec.end(), [this, &appid_count](const AppIdWithEventTime& a, const AppIdWithEventTime& b) {
        return compareAppIdWithEventTimeByCount<int64_t>(a, b, appid_count, reserve_);
      });

      std::unordered_set<std::string> str_set;
      str_set.reserve(size);
      for (uint32_t i = 0; i < size; ++i) {
        if (str_set.insert(*appid_info_vec[i].appid).second) {
          appid_info_vec_ptr.emplace_back(&appid_info_vec[i]);
        }
      }
    } else {
      //默认按时间戳大小排序
      std::sort(appid_info_vec.begin(), appid_info_vec.end(), [this](const AppIdWithEventTime& a, const AppIdWithEventTime& b) {
        return compareAppIdWithEventTime(a, b, reserve_);
      });

      for (uint32_t i = 0; i < size; ++i) {
        appid_info_vec_ptr.emplace_back(&appid_info_vec[i]);
      }
    }

    //截断
    if (topn_ > 0 && (int64_t)appid_info_vec_ptr.size() > topn_) {
      appid_info_vec_ptr.resize(topn_);
    }
  }

  template <typename T>
  void compute_vec_with_value(std::vector<AppIdWithEventTime>& appid_info_vec, 
                              std::unordered_map<AppIdWithEventTime*, T>& appid_values,
                              std::vector<std::pair<const std::string*, T>>& out_vec) {
    uint32_t size = appid_info_vec.size();
    if (size == 0) {
      return;
    }
    out_vec.reserve(size);

    //ByCount按次数排序，次数相同按最新时间戳的大小排序
    if (type_ == SortType::ByCount) {
      // std::unordered_map<std::string, AppIdWithEventTime*> appid_value;
      std::unordered_map<std::string, int64_t> appid_count;
      appid_count.reserve(size);
      // appid_value.reserve(size);

      for (uint32_t i = 0; i < size; ++i) {
        appid_count[*appid_info_vec[i].appid]++;
        // auto& ptr = appid_value[*appid_info_vec[i].appid];
        // if (ptr == nullptr || ptr->eventtime < appid_info_vec[i].eventtime) {
        //   ptr = &appid_info_vec[i];
        // }
      }

      // std::vector<AppIdWithEventTime*> appid_info_vec_ptr;
      // appid_info_vec_ptr.reserve(appid_value.size());
      // // 保持原有顺序
      // for (uint32_t i = 0; i < size; ++i) {
      //   if (&appid_info_vec[i] == appid_value[*appid_info_vec[i].appid]) {
      //     appid_info_vec_ptr.emplace_back(&appid_info_vec[i]);
      //   }
      // }

      // std::sort(appid_info_vec_ptr.begin(), appid_info_vec_ptr.end(), [this, &appid_count](const AppIdWithEventTime* a, const AppIdWithEventTime* b) {
      //   return compareAppIdWithEventTimeByCount<int64_t>(*a, *b, appid_count, reserve_);
      // });

      // for (uint32_t i = 0; i < appid_info_vec_ptr.size(); ++i) {
      //   out_vec.emplace_back(appid_info_vec_ptr[i]->appid, static_cast<T>(appid_count[*appid_info_vec_ptr[i]->appid]));
      // }

      std::sort(appid_info_vec.begin(), appid_info_vec.end(), [this, &appid_count](const AppIdWithEventTime& a, const AppIdWithEventTime& b) {
        return compareAppIdWithEventTimeByCount<int64_t>(a, b, appid_count, reserve_);
      });

      std::unordered_set<std::string> str_set;
      str_set.reserve(size);
      for (uint32_t i = 0; i < size; ++i) {
        if (str_set.insert(*appid_info_vec[i].appid).second) {
          out_vec.emplace_back(appid_info_vec[i].appid, static_cast<T>(appid_count[*appid_info_vec[i].appid]));
        }
      }
      //ByValue按对应的值的聚合排序，次数相同按最新时间戳的大小排序
    } else if (type_ == SortType::ByValue) {
      // std::unordered_map<std::string, AppIdWithEventTime*> appid_value;
      std::unordered_map<std::string, T> appid_map;
      appid_map.reserve(size);
      // appid_value.reserve(size);

      for (uint32_t i = 0; i < size; ++i) {
        appid_map[*appid_info_vec[i].appid] += appid_values[&appid_info_vec[i]];
        // auto& ptr = appid_value[*appid_info_vec[i].appid];
        // if (ptr == nullptr || ptr->eventtime < appid_info_vec[i].eventtime) {
        //   ptr = &appid_info_vec[i];
        // }
      }

      // std::vector<AppIdWithEventTime*> appid_info_vec_ptr;
      // appid_info_vec_ptr.reserve(appid_value.size());
      // // 保持原有顺序
      // for (uint32_t i = 0; i < size; ++i) {
      //   if (&appid_info_vec[i] == appid_value[*appid_info_vec[i].appid]) {
      //     appid_info_vec_ptr.emplace_back(&appid_info_vec[i]);
      //   }
      // }

      // std::sort(appid_info_vec_ptr.begin(), appid_info_vec_ptr.end(), [this, &appid_map](const AppIdWithEventTime* a, const AppIdWithEventTime* b) {
      //   return compareAppIdWithEventTimeByCount<T>(*a, *b, appid_map, reserve_);
      // });

      // for (uint32_t i = 0; i < appid_info_vec_ptr.size(); ++i) {
      //   out_vec.emplace_back(appid_info_vec_ptr[i]->appid, static_cast<T>(appid_map[*appid_info_vec_ptr[i]->appid]));
      // }

      std::sort(appid_info_vec.begin(), appid_info_vec.end(), [this, &appid_map](const AppIdWithEventTime& a, const AppIdWithEventTime& b) {
        return compareAppIdWithEventTimeByCount<T>(a, b, appid_map, reserve_);
      });

      std::unordered_set<std::string> str_set;
      str_set.reserve(size);
      for (uint32_t i = 0; i < size; ++i) {
        if (str_set.insert(*appid_info_vec[i].appid).second) {
          out_vec.emplace_back(appid_info_vec[i].appid, static_cast<T>(appid_map[*appid_info_vec[i].appid]));
        }
      }
    } else {
      //默认按时间戳大小排序
      std::sort(appid_info_vec.begin(), appid_info_vec.end(), [this](const AppIdWithEventTime& a, const AppIdWithEventTime& b) {
        return compareAppIdWithEventTime(a, b, reserve_);
      });

      for (uint32_t i = 0; i < size; ++i) {
        out_vec.emplace_back(appid_info_vec[i].appid, static_cast<T>(appid_info_vec[i].eventtime));
      }
    }

    int64_t truly_size = topn_;
    //截断至给定大小，如果尾部有相同值，截断至相同值的最后一个
    while (truly_size > 0 && (int64_t)out_vec.size() > truly_size) {
      if (out_vec[truly_size - 1].second != out_vec[truly_size].second) {
        out_vec.resize(truly_size);
        break;
      }
      truly_size++;
    }
  }

  void compute_ptr_vec(std::vector<AppIdWithEventTime*>& appid_info_vec, std::vector<AppIdWithEventTime*>& appid_info_vec_ptr) {
    uint32_t size = appid_info_vec.size();
    if (size == 0) {
      return;
    }
    appid_info_vec_ptr.reserve(size);

    //ByCount按次数排序，次数相同按最新时间戳的大小排序
    if (type_ == SortType::ByCount) {
      // std::unordered_map<std::string, AppIdWithEventTime*> appid_value;
      std::unordered_map<std::string, std::int64_t> appid_count;
      appid_count.reserve(size);
      // appid_value.reserve(size);

      for (uint32_t i = 0; i < size; ++i) {
        appid_count[*appid_info_vec[i]->appid]++;
        // auto& ptr = appid_value[*appid_info_vec[i]->appid];
        // if (ptr == nullptr || ptr->eventtime < appid_info_vec[i]->eventtime) {
        //   ptr = appid_info_vec[i];
        // }
      }

      // 保持原有顺序
      // for (uint32_t i = 0; i < size; ++i) {
      //   if (appid_info_vec[i] == appid_value[*appid_info_vec[i]->appid]) {
      //     appid_info_vec_ptr.emplace_back(appid_info_vec[i]);
      //   }
      // }

      // std::sort(appid_info_vec_ptr.begin(), appid_info_vec_ptr.end(), [this, &appid_count](const AppIdWithEventTime* a, const AppIdWithEventTime* b) {
      //   return compareAppIdWithEventTimeByCount(*a, *b, appid_count, reserve_);
      // });

      std::sort(appid_info_vec.begin(), appid_info_vec.end(), [this, &appid_count](const AppIdWithEventTime* a, const AppIdWithEventTime* b) {
        return compareAppIdWithEventTimeByCount(*a, *b, appid_count, reserve_);
      });

      std::unordered_set<std::string> str_set;
      str_set.reserve(size);
      for (uint32_t i = 0; i < size; ++i) {
        if (str_set.insert(*appid_info_vec[i]->appid).second) {
          appid_info_vec_ptr.emplace_back(appid_info_vec[i]);
        }
      }
    } else {
      //默认按时间戳大小排序
      std::sort(appid_info_vec.begin(), appid_info_vec.end(), [this](const AppIdWithEventTime* a, const AppIdWithEventTime* b) {
        return compareAppIdWithEventTime(*a, *b, reserve_);
      });

      for (uint32_t i = 0; i < size; ++i) {
        appid_info_vec_ptr.emplace_back(appid_info_vec[i]);
      }
    }

    //截断
    if (topn_ > 0 && (int64_t)appid_info_vec_ptr.size() > topn_) {
      appid_info_vec_ptr.resize(topn_);
    }
  }

  template <typename T>
  void compute_vec(std::vector<std::pair<T, const google::protobuf::Message*>>& vec, std::vector<const google::protobuf::Message*>& topn_vec) {
    uint32_t size = vec.size();
    if (size == 0) {
      return;
    }

    //默认按value排序
    std::sort(vec.begin(), vec.end(), [this](const std::pair<T, const google::protobuf::Message*>& a, const std::pair<T, const google::protobuf::Message*>& b) {
      return compareMessageByValue<T>(a, b, reserve_);
    });

    topn_vec.reserve(size);
    for (uint32_t i = 0; i < size; ++i) {
      topn_vec.push_back(vec[i].second);
    }

    int64_t truly_size = topn_;
    //截断至给定大小，如果尾部有相同值，截断至相同值的最后一个
    while (truly_size > 0 && (int64_t)topn_vec.size() > truly_size) {
      if (vec[truly_size - 1].first != vec[truly_size].first) {
        topn_vec.resize(truly_size);
        break;
      }
      truly_size++;
    }
  }

  std::string get_config() {
    return "type:" + std::to_string(static_cast<int64_t>(type_)) + ", topn:" + std::to_string(topn_);
  }

  std::string get_reserve() {
    return "reserve:" + std::to_string(reserve_);
  }

  SortType get_type() {
    return type_;
  }

  int64_t get_topn() {
    return topn_;
  }

 private:
  SortType type_;
  int64_t topn_;     //获取的长度，不设置默认-1报错，设置0不限制长度
  int64_t reserve_;  //0为从大到小排序，1为从小到大排序

  static bool compareAppIdWithEventTime(const AppIdWithEventTime& info1,
                                        const AppIdWithEventTime& info2,
                                        int64_t reserve) {
    if (reserve) {
      return info1.eventtime < info2.eventtime;
    } else {
      return info1.eventtime > info2.eventtime;
    }
  }

  template <typename T>
  static bool compareAppIdWithEventTimeByCount(const AppIdWithEventTime& info1,
                                               const AppIdWithEventTime& info2,
                                               std::unordered_map<std::string, T>& appid_count,
                                               int64_t reserve) {
    const T& value1 = appid_count[*info1.appid];
    const T& value2 = appid_count[*info2.appid];
    if (value1 == value2) {
      return info1.eventtime > info2.eventtime;
    } else if (reserve) {
      return value1 < value2;
    } else {
      return value1 > value2;
    }
  }

  template <typename T>
  static bool compareMessageByValue(const std::pair<T, const google::protobuf::Message*>& value1,
                                    const std::pair<T, const google::protobuf::Message*>& value2,
                                    int64_t reserve) {
    if (reserve) {
      return value1.first < value2.first;
    } else {
      return value1.first > value2.first;
    }
  }
};

// 用于防穿越和控制时间范围计算
class SeqFilterCompute {
 public:
  explicit SeqFilterCompute(int64_t start, int64_t day_n = -1, int64_t delta_day = 0, int64_t end = -1) : start_(start), day_n_(day_n), delta_day_(delta_day), end_(end) {
    if (day_n > 0) {
      end_ = day_n_ * (int64_t)(60 * 60 * 24) * (int64_t)1000;
    }
  }
  virtual ~SeqFilterCompute() {}

  void fill_appid_vec(const tensorflow::Feature& appid_feat,
                      const tensorflow::Feature& time_feat,
                      int64_t now,
                      std::vector<AppIdWithEventTime>& appid_info_vec,
                      int64_t max_time = -1) {
    auto& appid_vec = appid_feat.bytes_list().value();
    auto& eventtime_vec = time_feat.int64_list().value();
    const uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
    appid_info_vec.reserve(appid_info_vec.size() + list_size);

    int64_t start = start_;
    int64_t sub = now - max_time;
    if (max_time > 0 && sub > 0) {
      start = sub;
    }

    for (uint32_t i = 0; i < list_size; i++) {
      //时间戳数据为13位
      if ((now - eventtime_vec[i]) > start && (end_ < 0 || (now - eventtime_vec[i]) < end_)) {
        appid_info_vec.emplace_back(&appid_vec[i], eventtime_vec[i]);
      }
    }
  }

  void fill_appid_vec_with_index(const tensorflow::Feature& appid_feat,
                                  const tensorflow::Feature& time_feat,
                                  int64_t now,
                                  std::vector<AppIdWithEventTime>& appid_info_vec,
                                  std::vector<int64_t>& appid_index) {
    auto& appid_vec = appid_feat.bytes_list().value();
    auto& eventtime_vec = time_feat.int64_list().value();
    uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
    appid_info_vec.reserve(appid_info_vec.size() + list_size);
    appid_index.reserve(list_size);

    for (uint32_t i = 0; i < list_size; i++) {
      //时间戳数据为13位
      if ((now - eventtime_vec[i]) > start_ && (end_ < 0 || (now - eventtime_vec[i]) < end_)) {
        appid_info_vec.emplace_back(&appid_vec[i], eventtime_vec[i]);
        appid_index.emplace_back(i);
      }
    }
  }

  void fill_subkey_vec_with_index(const tensorflow::Feature& subkey_feat,
                                  const tensorflow::Feature& time_feat,
                                  int64_t now,
                                  std::vector<const std::string*>& subkey_vec,
                                  std::vector<int64_t>& index_vec) {
    auto& appid_vec = subkey_feat.bytes_list().value();
    auto& eventtime_vec = time_feat.int64_list().value();
    uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
    subkey_vec.reserve(subkey_vec.size() + list_size);
    index_vec.reserve(list_size);

    for (uint32_t i = 0; i < list_size; i++) {
      //时间戳数据为13位
      if ((now - eventtime_vec[i]) > start_ && (end_ < 0 || (now - eventtime_vec[i]) < end_)) {
        subkey_vec.emplace_back(&appid_vec[i]);
        index_vec.emplace_back(i);
      }
    }
  }

  void fill_subkey_vec_with_index_by_hour(const tensorflow::Feature& subkey_feat,
                                          const tensorflow::Feature& time_feat,
                                          int64_t now, 
                                          std::vector<const std::string*>& subkey_vec,
                                          std::vector<int64_t>& index_vec) {
    auto& appid_vec = subkey_feat.bytes_list().value();
    auto& eventtime_vec = time_feat.int64_list().value();
    uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
    subkey_vec.reserve(subkey_vec.size() + list_size);
    index_vec.reserve(list_size);
    int64_t req_hour = ((now / 1000 / 3600) + 8) % 24; //东八区时区

    for (uint32_t i = 0; i < list_size; i++) {
      //时间戳数据为13位
      if ((now - eventtime_vec[i]) > start_
           && (end_ < 0 || (now - eventtime_vec[i]) < end_) 
           && (req_hour == ((eventtime_vec[i] / 1000 / 3600) + 8) % 24)) {
        subkey_vec.emplace_back(&appid_vec[i]);
        index_vec.emplace_back(i);
      }
    }
  }

  void fill_count_map(const tensorflow::Feature& subkey_feat,
                      const tensorflow::Feature& time_feat,
                      int64_t now,
                      std::map<std::string ,int64_t>& count_map) {
    auto& appid_vec = subkey_feat.bytes_list().value();
    auto& eventtime_vec = time_feat.int64_list().value();
    uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());

    for (uint32_t i = 0; i < list_size; i++) {
      //时间戳数据为13位
      if ((now - eventtime_vec[i]) > start_ && (end_ < 0 || (now - eventtime_vec[i]) < end_)) {
        count_map[appid_vec[i]]++;
      }
    }
  }

  void fill_count_map_by_hour(const tensorflow::Feature& subkey_feat,
                              const tensorflow::Feature& time_feat,
                              int64_t now,
                              std::map<std::string, int64_t>& count_map) {
    auto& appid_vec = subkey_feat.bytes_list().value();
    auto& eventtime_vec = time_feat.int64_list().value();
    uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
    int64_t req_hour = ((now / 1000 / 3600) + 8) % 24; //东八区时区

    for (uint32_t i = 0; i < list_size; i++) {
      //时间戳数据为13位
      if ((now - eventtime_vec[i]) > start_
           && (end_ < 0 || (now - eventtime_vec[i]) < end_)
           && (req_hour == ((eventtime_vec[i] / 1000 / 3600) + 8) % 24)) {
        count_map[appid_vec[i]]++;
      }
    }
  }

  void fill_appid_map(const tensorflow::Feature& appid_feat,
                      const tensorflow::Feature& time_feat,
                      int64_t now,
                      std::map<std::string, std::vector<int64_t>>& appid_info_map,
                      int64_t max_time = -1) {
    auto& appid_vec = appid_feat.bytes_list().value();
    auto& eventtime_vec = time_feat.int64_list().value();
    const uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());

    int64_t start = start_;
    int64_t sub = now - max_time;
    if (max_time > 0 && sub > 0) {
      start = sub;
    }

    for (uint32_t i = 0; i < list_size; i++) {
      //时间戳数据为13位
      if ((now - eventtime_vec[i]) > start && (now - eventtime_vec[i]) < (day_n_ + delta_day_) * (int64_t)(60 * 60 * 24) * (int64_t)1000) {
        appid_info_map[appid_vec[i]].push_back(eventtime_vec[i]);
      }
    }
  }

  void fill_time_map(const tensorflow::Feature& appid_feat,
                     const tensorflow::Feature& time_feat,
                     int64_t now,
                     std::map<std::string, int64_t>& time_map) {
    auto& appid_vec = appid_feat.bytes_list().value();
    auto& eventtime_vec = time_feat.int64_list().value();
    const uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());

    for (uint32_t i = 0; i < list_size; i++) {
      int64_t duration = now - eventtime_vec[i];
      if (duration > start_ && (end_ < 0 || duration < end_)) {
        int64_t& time = time_map[appid_vec[i]];
        if (0 == time || time < eventtime_vec[i]) {
          time = eventtime_vec[i];
        }
      }
    }
  }

  void fill_duration_time_map(const tensorflow::Feature& appid_feat,
                              const tensorflow::Feature& time_feat,
                              int64_t now,
                              std::map<std::string, int64_t>& time_map) {
    auto& appid_vec = appid_feat.bytes_list().value();
    auto& eventtime_vec = time_feat.int64_list().value();
    const uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());

    for (uint32_t i = 0; i < list_size; i++) {
      int64_t duration = now - eventtime_vec[i];
      if (duration > start_ && (end_ < 0 || duration < end_)) {
        int64_t& time = time_map[appid_vec[i]];
        if (0 == time || duration < time) {
          time = duration;
        }
      }
    }
  }

  void fill_time_vec(const tensorflow::Feature& time_feat,
                      int64_t now,
                      std::vector<int64_t>& eventtime_sub_vec) {
    auto& eventtime_vec = time_feat.int64_list().value();
    const uint32_t list_size = eventtime_vec.size();
    eventtime_sub_vec.reserve(eventtime_sub_vec.size() + list_size);
    for (uint32_t i = 0; i < list_size; i++) {
      int64_t duration = now - eventtime_vec[i];
      if (duration > start_ && (end_ < 0 || duration < end_)) {
        eventtime_sub_vec.emplace_back(eventtime_vec[i]);
      }
    }
  }

  std::string display_start() {
    return "start:" + std::to_string(start_);
  }

  std::string display_day_n() {
    return "day_n:" + std::to_string(day_n_);
  }

  std::string display_delta_day() {
    return "delta_day:" + std::to_string(delta_day_);
  }

  std::string display_end() {
    return "end:" + std::to_string(end_);
  }

 private:
  int64_t start_; //防穿越，单位已转换ms
  int64_t day_n_; //有效天数，单位day
  int64_t delta_day_; //间隔天数，单位day
  int64_t end_;//有效时间，单位已转换ms
};

//用户行为序列最多(最后)的n个
class SeqTopNConfig : public Config {
 public:
  explicit SeqTopNConfig(const std::string& output,
                         const std::vector<std::string>& source,
                         DefaultValue& default_input_value,
                         bool save,
                         bool allow_empty_output,
                         const std::vector<std::string>& strategy,
                         int64_t start,
                         int64_t topn,
                         int64_t type,
                         const std::string& default_value)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy),
        default_value_(default_value), top_n_compute_(static_cast<SortType>(type), topn),
        filter_compute_(start) {}

  virtual ~SeqTopNConfig() {}

  virtual std::string get_config() override {
    std::string display = "seq_topn:";
    display.append(filter_compute_.display_start()).append(", ");
    display.append(top_n_compute_.get_config());
    display.append(", default_value:").append(default_value_);
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  std::string default_value_;
  SeqTopNCompute top_n_compute_;
  SeqFilterCompute filter_compute_;                
};

//一定时间范围内，未激活或不经常使用的app最后的n个
class SeqNV2Config : public Config {
 public:
  explicit SeqNV2Config(const std::string& output,
                        const std::vector<std::string>& source,
                        DefaultValue& default_input_value,
                        bool save,
                        bool allow_empty_output,
                        const std::vector<std::string>& strategy,
                        int64_t start,
                        int64_t end,
                        int64_t clip_size,
                        const std::string& default_value)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy),
        default_value_(default_value), filter_compute_(start, -1, 0, end),
        top_n_compute_(static_cast<SortType>(SortType::ByTimestamp), clip_size) {}

  virtual ~SeqNV2Config() {}

  virtual std::string get_config() override {
    std::string display = "seq_n_v2:";
    display.append(filter_compute_.display_start()).append(", ");
    display.append(filter_compute_.display_end()).append(", clip_size:");
    display.append(std::to_string(top_n_compute_.get_topn()));
    display.append(", default_value:").append(default_value_);
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  std::string default_value_; //默认值
  SeqFilterCompute filter_compute_; //采用end作为截止时间，单位为ms，day_n设置-1，delta_day设置0
  SeqTopNCompute top_n_compute_;

  void fill_count_map(std::vector<AppIdWithEventTime*>& appid_info_vec_ptr,
                      std::map<std::string, int64_t>& count_map);
};

//有效期间内统计次数的基类
class SeqCountConfig : public Config {
 public:
  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) {
    LogDebug("------------ compute {} start ------------", output_);

    const Value* appid_value = get_value(input_values, inputs_, 0);
    const Value* eventtime_value = get_value(input_values, inputs_, 1);
    int64_t now = get_feature_one_int64(input_values, inputs_, 2);
    const Value* item_value = get_value(input_values, inputs_, 3);

    const InputFeature* inf_appid = nullptr;
    const InputFeature* inf_eventtime = nullptr;

    uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());
    std::map<std::string, int64_t> count_map;

    //防穿越，有效数据提取到count_map中计数
    for (uint32_t i = 0; i < input_size; i++) {
      inf_appid = &appid_value->ifeatures[i];
      inf_eventtime = &eventtime_value->ifeatures[i];

      if (likely(inf_appid->feature && inf_eventtime->feature)) {
        filter_compute_.fill_count_map(*inf_appid->feature, *inf_eventtime->feature, now, count_map);
      } else if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
        uint32_t list_size = std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

        for (uint32_t j = 0; j < list_size; j++) {
          filter_compute_.fill_count_map(inf_appid->feature_list->feature(j), inf_eventtime->feature_list->feature(j), now, count_map);
        }
      }
    }

    const uint32_t batch_size = item_value->ifeatures.size();
    const InputFeature* inf = nullptr;
    tensorflow::Feature* out_feature = nullptr;
    tensorflow::FeatureList* out_featurelist = nullptr;

    output.values.resize(1);
    Value& value = output.values[0];
    value.ifeatures.resize(batch_size);

    //输出
    for (uint32_t i = 0; i < batch_size; i++) {
      inf = &item_value->ifeatures[i];

      if (likely(inf->feature_list)) {
        out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        value.ifeatures[i].feature_list = out_featurelist;

        for (auto& feat : inf->feature_list->feature()) {
          compute_one_feature(feat, count_map, out_featurelist->add_feature());
        }
      if ((out_featurelist->feature_size() == 0) && !allow_empty_output_) {
        fill_default_value(out_featurelist->add_feature());
      }
      } else {
        out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        value.ifeatures[i].feature = out_feature;

        if (likely(inf->feature)) {
          compute_one_feature(*inf->feature, count_map, out_feature);
        } else if (!allow_empty_output_) {
          fill_default_value(out_feature);
        }
      }
    }

    fill_value_dtype(value.defalut_type);

    LogDebug("------------ compute {} done ------------", output_);
    return true;
  }

 protected:
  SeqFilterCompute filter_compute_;   

  explicit SeqCountConfig(const std::string& output,
                          const std::vector<std::string>& source,
                          DefaultValue& default_input_value,
                          bool save,
                          bool allow_empty_output,
                          const std::vector<std::string>& strategy,
                          int64_t start)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), filter_compute_(start) {}
  virtual ~SeqCountConfig() {}

  virtual void compute_one_feature(const tensorflow::Feature& feat,
                                    std::map<std::string, int64_t>& count_map,
                                    tensorflow::Feature* out) = 0;
  virtual void fill_default_value(tensorflow::Feature* out) = 0;
  virtual void fill_value_dtype(tensorflow::DataType& data_type) = 0;
};

//用户行为在有效期间内出现的id值
class SeqHitValueConfig : public SeqCountConfig {
 public:
  explicit SeqHitValueConfig(const std::string& output,
                              const std::vector<std::string>& source,
                              DefaultValue& default_input_value,
                              bool save,
                              bool allow_empty_output,
                              const std::vector<std::string>& strategy,
                              int64_t start,
                              const std::string& default_value)
      : SeqCountConfig(output, source, default_input_value, save, allow_empty_output, strategy, start), default_value_(default_value) {}
  virtual std::string get_config() override {
    std::string display = "seq_hit_value:";
    display.append(filter_compute_.display_start());
    display.append(", default_value:").append(default_value_);
    return display;
  }
  
  virtual ~SeqHitValueConfig() {}

 private:
  std::string default_value_;

  virtual void compute_one_feature(const tensorflow::Feature& feat,
                                    std::map<std::string, int64_t>& count_map,
                                    tensorflow::Feature* out) override;
  virtual void fill_default_value(tensorflow::Feature* out) override {
    if (out->bytes_list().value_size() < 1) {
      out->mutable_bytes_list()->add_value(default_value_);
    }
  }
  virtual void fill_value_dtype(tensorflow::DataType& data_type) override {
    data_type = tensorflow::DT_STRING;
  }
};

class Cross2Config : public Config {
 public:
  explicit Cross2Config(const std::string& output,
                        const std::vector<std::string>& source,
                        DefaultValue& default_input_value,
                        bool save,
                        bool allow_empty_output,
                        const std::vector<std::string>& strategy,
                        int64_t fea1_clip,
                        int64_t fea2_clip,
                        int64_t clip_size,
                        const std::string& default_value)
    : Config(output, source, default_input_value, save, allow_empty_output, strategy),
      fea1_clip_(fea1_clip), fea2_clip_(fea2_clip), clip_size_(clip_size), default_value_(default_value) {
  }
  virtual ~Cross2Config() {}

  virtual std::string get_config() override {
    std::string display = "cross2:fea1_clip:";
    display.append(std::to_string(fea1_clip_)).append(", fea2_clip:").append(std::to_string(fea2_clip_)).append(", clip_size:");
    display.append(std::to_string(clip_size_)).append(", default_value:").append(default_value_);
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  int64_t fea1_clip_;
  int64_t fea2_clip_;
  int64_t clip_size_;
  std::string default_value_;

  void fill_value_to_vec(const Value* value, const int64_t fea_clip, std::vector<const std::string*>& vec);
};

//一定时间范围内，根据输入的条件和pb比较，过滤后输出appid最后的n个，以及对应的事件事件和给定的pb的value
class SeqFilterConfig : public Config {
 public:
  explicit SeqFilterConfig(const std::string& output,
                           const std::vector<std::string>& source,
                           DefaultValue& default_input_value,
                           bool save,
                           bool allow_empty_output,
                           const std::vector<std::string>& strategy,
                           int64_t start,
                           int64_t day_n,
                           int64_t clip_size,
                           const std::string& default_value,
                           const std::vector<std::set<std::string>>& filter_dict)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), default_value_(default_value),
        filter_dict_(filter_dict), filter_compute_(start, day_n),
        top_n_compute_(static_cast<SortType>(SortType::ByTimestamp), clip_size) {}

  virtual ~SeqFilterConfig() {}

  virtual std::string get_config() override {
    std::string display = "seq_filter:";
    display.append(filter_compute_.display_start()).append(", ");
    display.append(filter_compute_.display_day_n());
    display.append(", clip_size:").append(std::to_string(top_n_compute_.get_topn()));
    display.append(", filter:[");
    for (auto& set : filter_dict_) {
      display.append("[");
      for (auto& filter_str : set) {
        display.append(filter_str).append(",");;
      }
      display.pop_back();
      display.append("]");
    }
    display.append("]").append(", default_value:").append(default_value_);

    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  std::string default_value_;
  const std::vector<std::set<std::string>> filter_dict_;
  SeqFilterCompute filter_compute_;
  SeqTopNCompute top_n_compute_;

  void filter_feature_type(std::vector<AppIdWithEventTime>& appid_info_vec,
                           std::vector<const InputFeature*>& inf_type,
                           std::vector<std::vector<int64_t>>& appid_feat_value_index,
                           const InputFeature* inf_value,
                           std::map<AppIdWithEventTime*, int64_t>& appid_values,
                           std::vector<AppIdWithEventTime*>& appid_filter_vec_ptr);
};

//从数据源中过滤掉另一个pb中的数据
class SeqFilterV2Config : public Config {
 public:
  explicit SeqFilterV2Config(const std::string& output,
                             const std::vector<std::string>& source,
                             DefaultValue& default_input_value,
                             bool save,
                             bool allow_empty_output,
                             const std::vector<std::string>& strategy,
                             const std::string& default_value)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), default_value_(default_value) {
        if (unlikely(!Calc::convert_int64(default_value, default_int_))) {
          default_int_ = 0;
        }
      }

  virtual ~SeqFilterV2Config() {}

  virtual std::string get_config() override {
    std::string display = "seq_filter_v2:default_value:";
    display.append(default_value_);
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  std::string default_value_;       //string默认值
  int64_t default_int_;             //int默认值
  void fill_ifeature_to_set(const InputFeature* inf_value,
                            std::set<std::string>& str_filter,
                            std::set<int64_t>& int_filter,
                            tensorflow::DataType& data_type);
  void fill_feature_to_set(const tensorflow::Feature& feat,
                           std::set<std::string>& str_filter,
                           std::set<int64_t>& int_filter,
                           tensorflow::DataType& data_type);
  void compute_one_feature(const std::set<std::string>& str_filter,
                           const std::set<int64_t>& int_filter,
                           const tensorflow::Feature& feat,
                           tensorflow::DataType& data_type,
                           tensorflow::FeatureList* out_featurelist,
                           tensorflow::Feature* out);  
};

//过滤或保留，一定时间范围内，根据输入的条件和pb比较，输出符合的最后n个，以及对应的事件时间和给定的pb的value
class SeqFilterV3Config : public Config {
 public:
  explicit SeqFilterV3Config(const std::string& output,
                             const std::vector<std::string>& source,
                             DefaultValue& default_input_value,
                             bool save,
                             bool allow_empty_output,
                             const std::vector<std::string>& strategy,
                             int64_t start,
                             int64_t day_n,
                             int64_t clip_size,
                             int64_t reverse,
                             const std::unordered_set<std::string>& filter_dict)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), clip_size_(clip_size),
        reverse_(reverse), filter_dict_(filter_dict), filter_compute_(start, day_n) {}

  virtual ~SeqFilterV3Config() {}

  virtual std::string get_config() override {
    std::string display = "seq_filter_v3:";
    display.append(filter_compute_.display_start()).append(", ");
    display.append(filter_compute_.display_day_n());
    display.append(", clip_size:").append(std::to_string(clip_size_));
    display.append(", reverse:").append(std::to_string(reverse_));
    display.append(", filter:[");
    for (auto& filter_str : filter_dict_) {
      display.append(filter_str).append(",");;
    }
    display.pop_back();
    display.append("]");

    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  int64_t clip_size_;  //截断长度
  int64_t reverse_;    //0过滤掉符合条件的，1保留符合条件的
  std::unordered_set<std::string> filter_dict_;
  SeqFilterCompute filter_compute_;

  void filter_feature_type(std::vector<AppIdWithEventTime>& appid_info_vec,
                           std::vector<AppIdWithEventTime*>& appid_filter_vec_ptr);
  void get_values_map(std::vector<AppIdWithEventTime>& appid_info_vec,
                      std::vector<const InputFeature*>& inf_value,
                      std::vector<std::vector<int64_t>>& appid_feat_value_index,
                      std::map<AppIdWithEventTime*, std::vector<tensorflow::Feature>>& appid_values);                    
};

//一定时间范围内，未激活或不经常使用的app最后的n个
class SeqDiffConfig : public Config {
 public:
  explicit SeqDiffConfig(const std::string& output,
                          const std::vector<std::string>& source,
                          DefaultValue& default_input_value,
                          bool save,
                          bool allow_empty_output,
                          const std::vector<std::string>& strategy,
                          int64_t start,
                          int64_t day_n,
                          int64_t delta_day,
                          int64_t clip_size,
                          const std::string& default_value)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy),
        delta_day_(delta_day), default_value_(default_value), filter_compute_(start, day_n, delta_day),
        top_n_compute_(static_cast<SortType>(SortType::ByTimestamp), clip_size) {}

  virtual ~SeqDiffConfig() {}

  virtual std::string get_config() override {
    std::string display = "seq_diff:";
    display.append(filter_compute_.display_start()).append(", ");
    display.append(filter_compute_.display_day_n()).append(", ");
    display.append(", delta_day:").append(std::to_string(delta_day_));
    display.append(", clip_size:").append(std::to_string(top_n_compute_.get_topn()));
    display.append(", default_value:").append(default_value_);
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  int64_t delta_day_; //有效时间天数
  std::string default_value_;
  SeqFilterCompute filter_compute_;
  SeqTopNCompute top_n_compute_;

  void filter_unuse_appid(std::vector<AppIdWithEventTime>& appid_info_vec,
                          std::map<std::string, std::vector<int64_t>>& appid_info_map,
                          std::vector<AppIdWithEventTime*>& appid_filter_vec_ptr);
};

//兴趣算子，输出5个value，分别是subkey枚举，时长，时长占比，次数，次数占比
class SeqInterestConfig : public Config {
 public:
  explicit SeqInterestConfig(const std::string& output,
                              const std::vector<std::string>& source,
                              DefaultValue& default_input_value,
                              bool save,
                              bool allow_empty_output,
                              const std::vector<std::string>& strategy,
                              bool now_hour,
                              int64_t start,
                              int64_t end,
                              const std::string& default_value)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), now_hour_(now_hour),
        filter_compute_(start, -1, 0, end), default_value_(default_value) {}

  virtual ~SeqInterestConfig() {}

  virtual std::string get_config() override {
    std::string display = "seq_interest:";
    display.append(filter_compute_.display_start()).append(", ");
    display.append(filter_compute_.display_end()).append(", now_hour:");
    if (now_hour_) {
      display.append("true, default_value:");
    } else {
      display.append("false, default_value:");
    }
    display.append(default_value_);
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  bool now_hour_;   //是否只筛选当前请求相同小时的数据
  SeqFilterCompute filter_compute_; //采用end作为截止时间，单位为ms，day_n设置-1，delta_day设置0
  std::string default_value_; //默认值

  void compute_one_feature(std::vector<const std::string*>& subkey_vec,
                           int64_t& index,
                           std::vector<int64_t>& index_vec,
                           const tensorflow::Feature* info_feat,
                           int64_t& count,
                           int64_t& value,
                           std::map<std::string, std::pair<int64_t, int64_t>>& info_map);

  void compute_out_features(const std::pair<const std::string, std::pair<int64_t, int64_t>>& pair,
                            int64_t value,
                            int64_t count,
                            std::vector<tensorflow::Feature*>& out_feat);
};

//新鲜度特征，查找符合过滤条件的subkey，出现的次数
class SeqFreshConfig : public Config {
 public:
  explicit SeqFreshConfig(const std::string& output,
                          const std::vector<std::string>& source,
                          DefaultValue& default_input_value,
                          bool save,
                          bool allow_empty_output,
                          const std::vector<std::string>& strategy,
                          bool now_hour,
                          int64_t start,
                          int64_t end)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), now_hour_(now_hour),
        filter_compute_(start, -1, 0, end) {}

  virtual ~SeqFreshConfig() {}

  virtual std::string get_config() override {
    std::string display = "seq_fresh:";
    display.append(filter_compute_.display_start()).append(", ");
    display.append(filter_compute_.display_end()).append(", now_hour:");
    if (now_hour_) {
      display.append("true");
    } else {
      display.append("false");
    }
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  std::shared_ptr<std::unordered_map<std::string, AllClasses>> dict_;
  bool now_hour_;   //是否只筛选当前请求相同小时的数据
  SeqFilterCompute filter_compute_; //采用end作为截止时间，单位为ms，day_n设置-1，delta_day设置0

  void compute_one_feature(const tensorflow::Feature& feat,
                           std::map<std::string, int64_t>& count_map,
                           tensorflow::Feature* out_feature);
};

//dsp行为数据特征，提取符合过滤条件的subkey，返回subkey枚举和对应pb的平均值
class SeqDspConfig : public Config {
 public:
  explicit SeqDspConfig(const std::string& output,
                        const std::vector<std::string>& source,
                        DefaultValue& default_input_value,
                        bool save,
                        bool allow_empty_output,
                        const std::vector<std::string>& strategy,
                        bool now_hour,
                        int64_t start,
                        int64_t end,
                        const std::string& default_value)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), now_hour_(now_hour),
        filter_compute_(start, -1, 0, end), default_value_(default_value) {}

  virtual ~SeqDspConfig() {}

  virtual std::string get_config() override {
    std::string display = "seq_dsp:";
    display.append(filter_compute_.display_start()).append(", ");
    display.append(filter_compute_.display_end()).append(", now_hour:");
    if (now_hour_) {
      display.append("true, default_value:");
    } else {
      display.append("false, default_value:");
    }
    display.append(default_value_);
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  bool now_hour_;   //是否只筛选当前请求相同小时的数据
  SeqFilterCompute filter_compute_; //采用end作为截止时间，单位为ms，day_n设置-1，delta_day设置0
  std::string default_value_; //默认值

  void compute_one_features(std::vector<const std::string*>& subkey_vec,
                            int64_t& index,
                            std::vector<int64_t>& index_vec,
                            std::vector<const tensorflow::Feature*>& info_feat,
                            std::map<std::string, std::vector<float>>& info_map);

  void compute_out_features(const std::pair<const std::string, std::vector<float>>& pair,
                            std::vector<tensorflow::Feature*>& out_feat);
};

//统计用户行为的次数或比例
class SeqNumConvertConfig : public Config {
 public:
  explicit SeqNumConvertConfig(const std::string& output,
                               const std::vector<std::string>& source,
                               DefaultValue& default_input_value,
                               bool save,
                               bool allow_empty_output,
                               const std::vector<std::string>& strategy,
                               const int64_t type)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), type_(type) {}

  virtual ~SeqNumConvertConfig() {}

  virtual std::string get_config() override {
    return "seq_num_convert:type:" + std::to_string(type_);
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  int64_t type_; //type为0，返回次数；type为1，返回int(100*比例)；type为2，返回float(100*比例)；

  void compute_one_feature(const tensorflow::Feature& feat,
                           int32_t& count,
                           std::map<std::string, int32_t>& count_map);  
};

//特征过滤，抽取n天内，指定截断长度以内的对应特征数据
class SeqDayNDirectConfig : public Config {
 public:
  explicit SeqDayNDirectConfig(const std::string& output,
                               const std::vector<std::string>& source,
                               DefaultValue& default_input_value,
                               bool save,
                               bool allow_empty_output,
                               const std::vector<std::string>& strategy,
                               const std::string& eventtime_key,
                               const std::vector<std::string>& fields,
                               int64_t start,
                               int64_t day_n,
                               int64_t clip_size)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), eventtime_key_(eventtime_key), fields_(fields),
        start_(start), day_n_(day_n), clip_size_(clip_size) {
          end_ = day_n_ * (int64_t)(60 * 60 * 24) * (int64_t)1000;
        }

  virtual ~SeqDayNDirectConfig() {}

  virtual std::string get_config() override {
    std::string display = "seq_day_n_direct:eventtime_key:";
    display.append(eventtime_key_);
    display.append(", fields:[");
    for (auto& field_str : fields_) {
      display.append(field_str).append(",");
    }
    display.pop_back();
    display.append("], ");
    display.append(", start:").append(std::to_string(start_));
    display.append(", day_n:").append(std::to_string(day_n_));
    display.append(", clip_size:").append(std::to_string(clip_size_));
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  const std::string eventtime_key_;        //时间戳在路径中对应的字段
  const std::vector<std::string> fields_;  //最终抽取的字段
  int64_t start_;                          //防穿越
  int64_t day_n_;                          //N天的数据
  int64_t clip_size_;                      //截断长度
  int64_t end_;                            //N天转换的毫秒
};

//离线特征和近线特征合并，按appid+eventtime对数据去重，最后按时间戳排序
class SeqMergeV2Config : public Config {
 public:
  explicit SeqMergeV2Config(const std::string& output,
                            const std::vector<std::string>& source,
                            DefaultValue& default_input_value,
                            bool save,
                            bool allow_empty_output,
                            const std::vector<std::string>& strategy,
                            const std::string& appid_key,
                            const std::string& eventtime_key)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), appid_key_(appid_key),
        eventtime_key_(eventtime_key), top_n_compute_(static_cast<SortType>(SortType::ByValue), 0, 0) {}

  virtual ~SeqMergeV2Config() {}

  virtual std::string get_config() override {
    std::string display = "seq_merge_v2:appid_key:";
    display.append(appid_key_);
    display.append(", eventtime_key:").append(eventtime_key_);
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  const std::string appid_key_;           //app_id在路径中对应的字段
  const std::string eventtime_key_;       //事件时间在路径中对应的字段
  SeqTopNCompute top_n_compute_;

  void fill_message_to_vec(const InputFeature* mess_value,
                           std::set<std::string>& filter_set,
                           std::vector<std::pair<int64_t, const google::protobuf::Message*>>& time_vec);
};

//请求时间n天内，命中的app最后三次使用时间的均值差比值和时间间隔
class SeqInterval : public Config {
 public:
  explicit SeqInterval(const std::string& output,
                       const std::vector<std::string>& source,
                       DefaultValue& default_input_value,
                       bool save,
                       bool allow_empty_output,
                       const std::vector<std::string>& strategy,
                       int64_t start,
                       int64_t day_n,
                       int64_t clip_size,
                       float default_mean,
                       int64_t default_interval)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy), default_mean_(default_mean),
         default_interval_(default_interval), filter_compute_(start, day_n),
         top_n_compute_(static_cast<SortType>(SortType::ByTimestamp), clip_size) {}

  virtual ~SeqInterval() {}

  virtual std::string get_config() override {
    std::string display = "seq_interval:";
    display.append(filter_compute_.display_start()).append(", ");
    display.append(filter_compute_.display_day_n()).append(", ");
    display.append(", clip_size:").append(std::to_string(top_n_compute_.get_topn()));
    display.append(", default_mean:").append(std::to_string(default_mean_));
    display.append(", default_interval:").append(std::to_string(default_interval_));
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  float default_mean_;          //默认均值差比值
  int64_t default_interval_;    //默认时间间隔
  SeqFilterCompute filter_compute_;
  SeqTopNCompute top_n_compute_;

  void fill_eventtime_map(const Value* second_eventtime_value,
                          const Value* third_eventtime_value,
                          const std::vector<AppIdWithEventTime>& appid_info_vec,
                          uint32_t i,
                          const std::vector<std::vector<int64_t>>& appid_feat_value_index,
                          std::map<std::string, std::vector<int64_t>>& appid_info_map);
  void fill_eventtime_one(const Value* value,
                          uint32_t i,
                          uint32_t j,
                          uint32_t k,
                          const std::string& str,
                          std::map<std::string, std::vector<int64_t>>& appid_info_map);
  void fill_appid_map(const std::vector<AppIdWithEventTime*>& appid_info_vec_ptr,
                      int64_t now,
                      std::map<std::string, std::vector<int64_t>>& appid_info_map);
  void compute_one_feature(const tensorflow::Feature& feat,
                           const std::map<std::string, std::vector<int64_t>>& appid_info_map,
                           std::vector<tensorflow::Feature*>& out_feat);
  void fill_diffreence(std::vector<int64_t>& data, int64_t now);
  float calculate_mean_ratio(const std::vector<int64_t>& data);
};

class SeqMaxValueConfig : public Config { 
  public:
  explicit SeqMaxValueConfig(const std::string& output,
                        const std::vector<std::string>& source,
                        DefaultValue& default_input_value,
                        bool save,
                        bool allow_empty_output,
                        const std::vector<std::string>& strategy,
                        int64_t day_n,
                        int64_t start,
                        int64_t default_value) : Config(output, source, default_input_value, save, allow_empty_output, strategy), day_n_ms_(day_n * 86400 * 1000), start_(start), default_value_(default_value) {}
  
  virtual ~SeqMaxValueConfig() {}

  virtual std::string get_config() override {
    std::string display = "seq_max_value:day_n:";
    display.append(std::to_string(day_n_ms_ / (86400 * 1000)));
    display.append(", start:").append(std::to_string(start_));
    display.append(", default_value:").append(std::to_string(default_value_));
    return display;
  }

  private:
    int64_t day_n_ms_;
    int64_t start_;
    int64_t default_value_;
    void compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out, int64_t request_time);
    void compute_one_featurelist(const tensorflow::FeatureList& featlist, tensorflow::Feature* out, int64_t request_time);
    void fill_value_dtype(tensorflow::DataType& data_type) {
      data_type = tensorflow::DT_INT64;
    }
    bool compute(const std::vector<const Output*>& input_values, Output& output) override;
};

//用户行为时间序列距今天数
class SeqBackDaysConfig : public Config {
 public:
  explicit SeqBackDaysConfig(const std::string& output,
                         const std::vector<std::string>& source,
                         DefaultValue& default_input_value,
                         bool save,
                         bool allow_empty_output,
                         const std::vector<std::string>& strategy,
                         int64_t start)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy),
        filter_compute_(start) {}

  virtual ~SeqBackDaysConfig() {}

  virtual std::string get_config() override {
    std::string display = "seq_back_days:";
    display.append(filter_compute_.display_start());
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  SeqFilterCompute filter_compute_;
  void compute_back_days(const std::vector<int64_t>& eventtime_vec, const int64_t& now, std::vector<int64_t>& back_days_vec);
};

//用户行为时间序列距今天数
class SeqIntervalDaysConfig : public Config {
 public:
  explicit SeqIntervalDaysConfig(const std::string& output,
                         const std::vector<std::string>& source,
                         DefaultValue& default_input_value,
                         bool save,
                         bool allow_empty_output,
                         const std::vector<std::string>& strategy,
                         int64_t start)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy),
        filter_compute_(start) {}

  virtual ~SeqIntervalDaysConfig() {}

  virtual std::string get_config() override {
    std::string display = "seq_interval_days:";
    display.append(filter_compute_.display_start());
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;

 private:
  SeqFilterCompute filter_compute_;   
  void compute_interval_days(const std::vector<int64_t>& eventtime_vec, std::vector<int64_t>& interval_days_vec);             
};

#endif  // FE_CONFIG_SEQ