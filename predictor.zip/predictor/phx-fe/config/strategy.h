#ifndef FE_STRATEGY
#define FE_STRATEGY

#include "phx-fe/util/murmur_hash3.h"
#include "phx-fe/util/util.h"
#include "phx-fe/util/log.h"

#include <map>
#include <unordered_map>
#include <memory>
#include <queue>
#include <set>
#include <string>
#include <vector>

// 策略类，对输出进行处理
class Strategy {
 public:
  virtual void Execution(Output& out, const std::string& config_name) {
    for (uint32_t i = 0; i < out.values.size(); i++) {
      for (uint32_t j = 0; j < out.values[i].ifeatures.size(); j++) {
        execution_one_input(out.values[i].ifeatures[j], out.arena, config_name);
      }
    }
  }

  virtual void execution_one_input(InputFeature& inf, google::protobuf::Arena* arena, const std::string& config_name) {}
};

// hash策略，将int64和string类型输出转化为hash后的int64输出
class HashStrategy : public Strategy {
 public:
  std::vector<uint64_t> slots_;       //hash策略的slot，先插入share，再插入私有，运算取最后一个做slot

 public:
  virtual void Execution(Output& out, const std::string& config_name) override {

    //std::vector<Value>* values = &out.values;
    if (!out.own_values) {

      //先预分配好空间
      std::vector<Value> values;
      values.resize(out.values.size());
      for (size_t i = 0; i< out.values.size(); i++) {
        Value& owned_output_value  = values[i];
        owned_output_value.ifeatures.resize(out.values[i].ifeatures.size());
        if (tensorflow::DT_STRING == out.values[i].defalut_type) {
          owned_output_value.defalut_type = tensorflow::DT_INT64;
        }
 
        for (uint32_t j = 0; j < out.values[i].ifeatures.size(); j++) {
          execution_one_input(out.values[i].ifeatures[j], owned_output_value.ifeatures[j], out.arena, config_name);
        }
      }
      out.values.swap(values);
      out.own_values = true;
    } else {
      for (uint32_t i = 0; i < out.values.size(); i++) {
        if (tensorflow::DT_STRING == out.values[i].defalut_type) {
          out.values[i].defalut_type = tensorflow::DT_INT64;
        }
        for (uint32_t j = 0; j < out.values[i].ifeatures.size(); j++) {
          execution_one_input(out.values[i].ifeatures[j], out.arena, config_name);
        }
      }
    }

  }
  void execution_one_input(InputFeature& inf, InputFeature& output_feature, google::protobuf::Arena* arena, const std::string& config_name) {
    if (inf.feature_list) {
      tensorflow::FeatureList* one_output_feature_list = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(arena);
      output_feature.feature_list = one_output_feature_list;
      for (auto& feat : inf.feature_list->feature()) {
         auto* one_output_feature = one_output_feature_list->add_feature();
         hash_feature(feat, one_output_feature);
      }
    } else if (inf.feature) {
      tensorflow::Feature* one_output_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(arena);
      output_feature.feature = one_output_feature;
      hash_feature(*inf.feature, one_output_feature);
    }
  }

  virtual void execution_one_input(InputFeature& inf, google::protobuf::Arena* arena, const std::string& config_name) override {
    tensorflow::Feature* out_feature = nullptr;
    if (inf.feature_list) {
      for (auto& feat : inf.feature_list->feature()) {
        out_feature = const_cast<tensorflow::Feature*>(&feat);
        hash_feature(out_feature);
      }
    } else if (inf.feature) {
      out_feature = const_cast<tensorflow::Feature*>(inf.feature);
      hash_feature(out_feature);
    }
  }

  void hash_feature(const tensorflow::Feature& input_feature, tensorflow::Feature* output_feature) {
    switch (input_feature.kind_case()) {
      case tensorflow::Feature::kBytesList: {
        auto& vec = input_feature.bytes_list().value();

        if (unlikely(vec.empty())) {
          return;
        }
        uint32_t vec_size = vec.size();
        std::vector<int64_t> hash_vec(vec_size);
        for (uint32_t i = 0; i < vec_size; i++) {
          int64_t out_hash;
          murmur_hash(vec[i], out_hash);
          if (!slots_.empty()) {
            out_hash &= 0x00FFFFFFFFFFFF;
            out_hash |= slots_.back();
          }
          output_feature->mutable_int64_list()->add_value(out_hash);
        }
      }
      break;

      case tensorflow::Feature::kFloatList:
      THROW_ERROR("hash strategy doesn't support float");
      break;

      case tensorflow::Feature::kInt64List: {
        auto& vec = input_feature.int64_list().value();

        if (unlikely(vec.empty())) {
          return;
        }
        int64_t out = 0;
        for (int32_t i = 0; i < vec.size(); i++) {
          murmur_hash(vec[i], out);
          if (!slots_.empty()) {
            out &= 0x00FFFFFFFFFFFF;
            out |= slots_.back();
          }
          output_feature->mutable_int64_list()->add_value(out); // 重新设置 int64_value
        }
      }
      break;

      default: {
        return;
      }
      break;
    }
  }

  void hash_feature(tensorflow::Feature* feat) {
    switch (feat->kind_case()) {
      case tensorflow::Feature::kBytesList: {
        auto& vec = feat->bytes_list().value();

        if (unlikely(vec.empty())) {
          return;
        }
        uint32_t vec_size = vec.size();
        std::vector<int64_t> hash_vec(vec_size);
        for (uint32_t i = 0; i < vec_size; i++) {
          murmur_hash(vec[i], hash_vec[i]);
          if (!slots_.empty()) {
            hash_vec[i] &= 0x00FFFFFFFFFFFF;
            hash_vec[i] |= slots_.back();
          }
        }
        feat->clear_bytes_list(); // 清除 bytes_list

        // 设置 int64_list
        for (uint32_t i = 0; i < vec_size; i++) {
          feat->mutable_int64_list()->add_value(hash_vec[i]);
        }
      }
      break;

      case tensorflow::Feature::kFloatList:
      THROW_ERROR("hash strategy doesn't support float");
      break;

      case tensorflow::Feature::kInt64List: {
        auto& vec = feat->int64_list().value();

        if (unlikely(vec.empty())) {
          return;
        }
        int64_t out = 0;
        for (int32_t i = 0; i < vec.size(); i++) {
          murmur_hash(vec[i], out);
          if (!slots_.empty()) {
            out &= 0x00FFFFFFFFFFFF;
            out |= slots_.back();
          }
          feat->mutable_int64_list()->set_value(i, out); // 重新设置 int64_value
        }
      }
      break;

      default: {
        return;
      }
      break;
    }
  }

};

// feature策略，将feature_list合并成一个feature
class FeatureStrategy : public Strategy {
public:
  bool allow_empty_output_ = false; //是否允许空feature

public:
  virtual void execution_one_input(InputFeature& inf, google::protobuf::Arena* arena, const std::string& config_name) override {
    if (inf.feature_list) {
      tensorflow::Feature* out_feature = nullptr;
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(arena);
      inf.feature = out_feature;
      for (auto& feat : inf.feature_list->feature()) {
        merge_feature(feat, *out_feature, config_name, allow_empty_output_);
      }
      inf.feature_list = nullptr;
    }
  }

  void merge_feature(const tensorflow::Feature& from, tensorflow::Feature& to, const std::string& config_name, bool allow_empty_output) {
    switch (from.kind_case()) {
      case tensorflow::Feature::kBytesList: {
        auto& vec = from.bytes_list().value();

        if (unlikely(vec.empty())) {
          THROW_ERROR("feature no data, name:" + config_name);
          return;
        }

        to.mutable_bytes_list()->add_value(vec[0]);
      }
      break;

      case tensorflow::Feature::kFloatList: {
        auto& vec = from.float_list().value();

        if (unlikely(vec.empty())) {
          THROW_ERROR("feature no data, name:" + config_name);
          return;
        }

        to.mutable_float_list()->add_value(vec[0]);
      }
      break;

      case tensorflow::Feature::kInt64List: {
        auto& vec = from.int64_list().value();

        if (unlikely(vec.empty())) {
          THROW_ERROR("feature no data, name:" + config_name);
          return;
        }

        to.mutable_int64_list()->add_value(vec[0]);
      }
      break;

      default: {
        if (!allow_empty_output) {
          THROW_ERROR("invalid:" + std::to_string((int32_t)from.kind_case()) + ", name:" + config_name);
          return;
        }
      }
      break;
    }
  }
};

// slot策略，将hash结果的int64与slot做位运算
class HashSlotStrategy : public Strategy {
 public:
  std::vector<uint64_t> slots_;       //slot，先插入share，再插入私有，运算取最后一个做slot

public:
  virtual void Execution(Output& out, const std::string& config_name) override {
    if (!slots_.empty()) {
      for (uint32_t i = 0; i < out.values.size(); i++) {
        for (uint32_t j = 0; j < out.values[i].ifeatures.size(); j++) {
          execution_one_input(out.values[i].ifeatures[j], out.arena, config_name);
        }
      }
    }
  }

  virtual void execution_one_input(InputFeature& inf, google::protobuf::Arena* arena, const std::string& config_name) override {
    tensorflow::Feature* out_feature = nullptr;
    if (inf.feature_list) {
      for (auto& feat : inf.feature_list->feature()) {
        out_feature = const_cast<tensorflow::Feature*>(&feat);
        slot_feature(out_feature);
      }
    } else if (inf.feature) {
      out_feature = const_cast<tensorflow::Feature*>(inf.feature);
      slot_feature(out_feature);
    }
  }

  void slot_feature(tensorflow::Feature* feat) {
    switch (feat->kind_case()) {
      case tensorflow::Feature::kInt64List: {
        auto& vec = feat->int64_list().value();

        if (unlikely(vec.empty())) {
          return;
        }
        int64_t out = 0;
        for (int32_t i = 0; i < vec.size(); i++) {
          out = vec[i];
          if (!slots_.empty()) {
            out &= 0x00FFFFFFFFFFFF;
            out |= slots_.back();
          }
          feat->mutable_int64_list()->set_value(i, out); // 重新设置 int64_value
        }
      }
      break;

      default: {
        return;
      }
      break;
    }
  }

};

#endif  // FE_STRATEGY