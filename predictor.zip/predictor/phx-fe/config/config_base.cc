#include "config_base.h"
#include "phx-fe/util/calc.h"
#include "phx-fe/util/math.h"
#include "phx-fe/util/timer.h"
#include "phx-fe/util/farmhash.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <unordered_map>

// 根据feat 计算填充hfeature_feature
void BucketizedConfig::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  if (likely(feat.float_list().value_size() > 0)) {
    for (float f : feat.float_list().value()) {
      DEBUG_TIMER("bucket " + std::to_string(f) + " bsize:" + std::to_string(boundaries_.size()));
      out->mutable_int64_list()->add_value(bucketized_bound<float>(f, boundaries_));
    }
  } else if (likely(feat.int64_list().value_size() > 0)) {
    for (int64_t l : feat.int64_list().value()) {
      DEBUG_TIMER("bucket" + std::to_string(l) + " bsize:" + std::to_string(boundaries_.size()));
      out->mutable_int64_list()->add_value(bucketized_bound<int64_t>(l, boundaries_));
    }
  }
}

void VocabListConfig::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (const std::string& str : feat.bytes_list().value()) {
    auto itr = vocab_map_.find(str);

    if (itr != vocab_map_.end()) {
      out->mutable_int64_list()->add_value(itr->second);
    } else {
      out->mutable_int64_list()->add_value(0);
    }
  }
}

void VocabSetConfig::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (const std::string& str : feat.bytes_list().value()) {
    if (dict_->find(str) != dict_->end()) {
      out->mutable_bytes_list()->add_value(str);
    } else {
      out->mutable_bytes_list()->add_value("");
    }
  }
}

template<>
void VocabMapConfig<float>::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (const std::string& str : feat.bytes_list().value()) {
    auto itr = dict_->find(str);
    if (itr != dict_->end()) {
      out->mutable_float_list()->add_value(itr->second);
    } else {
      out->mutable_float_list()->add_value(-1);
    }
  }
}

template<>
void VocabMapConfig<float>::fill_value_dtype(tensorflow::DataType& data_type) {
  data_type = tensorflow::DT_FLOAT;
}

template<>
void VocabMapConfig<int64_t>::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (const std::string& str : feat.bytes_list().value()) {
    auto itr = dict_->find(str);
    if (itr != dict_->end()) {
      out->mutable_int64_list()->add_value(itr->second);
    } else {
      out->mutable_int64_list()->add_value(-1);
    }
  }
}

template<>
void VocabMapConfig<int64_t>::fill_value_dtype(tensorflow::DataType& data_type) {
  data_type = tensorflow::DT_INT64;
}

template<>
void VocabMapConfig<std::string>::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (const std::string& str : feat.bytes_list().value()) {
    auto itr = dict_->find(str);
    if (itr != dict_->end()) {
      out->mutable_bytes_list()->add_value(itr->second);
    } else {
      out->mutable_bytes_list()->add_value("");
    }
  }
}

template<>
void VocabMapConfig<std::string>::fill_value_dtype(tensorflow::DataType& data_type) {
  data_type = tensorflow::DT_STRING;
}

void IsMatchStrConfig::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (const std::string& str : feat.bytes_list().value()) {
    const AllClasses* all_class = Item2Class::lookup(*dict_, str);
    if (nullptr != all_class) {
      out->mutable_bytes_list()->add_value(str);
    } else {
      out->mutable_bytes_list()->add_value(default_value_);
    }
  }
}

bool FilterAppIdConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("FilterAppIdConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* appid_value = get_value(input_values, inputs_, 0);
  const Value* eventtime_value = get_value(input_values, inputs_, 1);
  int64_t now = get_feature_one_int64(input_values, inputs_, 2);

  const uint32_t days_num = days_.size();
  uint32_t batch_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

  // Output output;
  output.values.resize(days_num);
  for (auto& value : output.values) {
    value.ifeatures.resize(batch_size);
    value.defalut_type = tensorflow::DT_STRING;
  }

  const InputFeature* inf_appid = nullptr;
  const InputFeature* inf_eventtime = nullptr;

  for (uint32_t i = 0; i < batch_size; i++) {
    inf_appid = &appid_value->ifeatures[i];
    inf_eventtime = &eventtime_value->ifeatures[i];

    if (likely(inf_appid->feature && inf_eventtime->feature)) {
      LogDebug("Feature");
      std::vector<AppIdWithEventTime> info_vec;
      std::vector<tensorflow::Feature*> out_feature_vec(days_num);

      // 填充feature中所有值
      fill_vec(*inf_appid->feature, *inf_eventtime->feature, info_vec);

      // 排序筛选
      compute_vec(info_vec);

      for (uint32_t d = 0; d < days_num; d++) {
        out_feature_vec[d] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[d].ifeatures[i].feature = out_feature_vec[d];
      }

      // 输出到feature中
      for (uint32_t v = 0; v < info_vec.size(); v++) {
        auto& info = info_vec[v];
        const int32_t diff = diff_days(now / 1000, info.eventtime / 1000);

        for (uint32_t d = 0; d < days_num; d++) {
          LogDebug("appid:{} now:{} info.eventtime:{} diff:{}", *info.appid, now, info.eventtime, diff);

          if (days_[d] > diff) {
            LogDebug("{} append to {}", *info.appid, d);
            out_feature_vec[d]->mutable_bytes_list()->add_value(*info.appid);
          }
        }
      }

      // add default value
      for (uint32_t d = 0; d < days_num; d++) {
        if ((out_feature_vec[d]->bytes_list().value_size() < 1) && !allow_empty_output_) {
          out_feature_vec[d]->mutable_bytes_list()->add_value(default_value_);
        }
      }
    } else if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
      uint32_t list_size = std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

      LogDebug("FeatureList {}", list_size);

      std::vector<AppIdWithEventTime> info_vec;
      std::vector<tensorflow::FeatureList*> out_feature_list_vec(days_num);

      // 填充feature_list中每个feature的所有值
      for (uint32_t j = 0; j < list_size; j++) {
        fill_vec(inf_appid->feature_list->feature(j), inf_eventtime->feature_list->feature(j), info_vec);
      }

      // 排序筛选
      compute_vec(info_vec);

      // 每个元素作为一个feature，最终结果为feature_list
      for(uint32_t d = 0; d < days_num; d++) {
        out_feature_list_vec[d] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[d].ifeatures[i].feature_list = out_feature_list_vec[d];
      }

      for (uint32_t v = 0; v < info_vec.size(); v++) {
        auto& info = info_vec[v];
        const int32_t diff = diff_days(now / 1000, info.eventtime / 1000);

        for (uint32_t d = 0; d < days_num; d++) {
          LogDebug("appid:{} now:{} info.eventtime:{} diff:{}", *info.appid, now, info.eventtime, diff);

          if (days_[d] > diff) {
            LogDebug("{} append to {}", *info.appid, d);
            out_feature_list_vec[d]->add_feature()->mutable_bytes_list()->add_value(*info.appid);
          }
        }
      }

      // add default value
      for (uint32_t d = 0; d < days_num; d++) {
        if ((out_feature_list_vec[d]->feature_size() == 0) && !allow_empty_output_) {
          out_feature_list_vec[d]->add_feature()->mutable_bytes_list()->add_value(default_value_);
        }
      }
    }
  }

  return true;
}

void FilterAppIdConfig::fill_vec(const tensorflow::Feature& appid_feat,
                                  const tensorflow::Feature& time_feat,
                                  std::vector<AppIdWithEventTime>& info_vec) {
  auto& appid_vec = appid_feat.bytes_list().value();
  auto& time_vec = time_feat.int64_list().value();
  uint32_t list_size = std::min(appid_vec.size(), time_vec.size());

  info_vec.reserve(info_vec.size() + list_size);

  for (uint32_t i = 0; i < list_size; i++) {
    LogDebug("Feature:{} i:{} appid_vec[i]:{}", (uint64_t)&appid_feat, i, appid_vec[i]);

    info_vec.emplace_back(&appid_vec[i], time_vec[i]);
  }
}

void FilterAppIdConfig::compute_vec(std::vector<AppIdWithEventTime>& info_vec) {
  // 排序筛选
  std::sort(info_vec.begin(), info_vec.end(), FilterAppIdConfig::compareAppIdWithEventTime);

  if ((int32_t)info_vec.size() > max_len_) {
    info_vec.resize(max_len_);
  }

  std::reverse(info_vec.begin(), info_vec.end());
}

bool MaxExpoAppidConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("MaxExpoAppidConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);

  std::map<std::string, uint32_t> count;
  for (const InputFeature& inf : input_value->ifeatures) {
    if (likely(inf.feature)) {
      for (const std::string& str : inf.feature->bytes_list().value()) {
        count[str]++;
      }
    } else if (likely(inf.feature_list)) {
      for (auto& feat : inf.feature_list->feature()) {
        for (const std::string& str : feat.bytes_list().value()) {
          count[str]++;
        }
      }
    }
  }

  uint32_t max = 0;
  const std::string* ret = nullptr;
  for (auto& pair : count) {
    if (pair.second > max) {
      ret = &pair.first;
      max = pair.second;
    }
  }

  output.values.resize(1);
  Value& value = output.values[0];
  value.ifeatures.resize(1);
  value.defalut_type = tensorflow::DT_STRING;
  tensorflow::Feature* out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
  value.ifeatures[0].feature = out_feature;
  if (!allow_empty_output_ || ret) {
    out_feature->mutable_bytes_list()->add_value(ret ? *ret : "");
  }
  
  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

bool NearestExpoAppidConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("NearestExpoAppidConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);
  uint32_t batch_size = input_value->ifeatures.size();
  const InputFeature* inf = nullptr;
  tensorflow::Feature* out_feature = nullptr;

  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = input_value->defalut_type;
  value.ifeatures.resize(batch_size);

  for (uint32_t i = 0; i < batch_size; i++) {
    inf = &input_value->ifeatures[i];

    out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
    value.ifeatures[i].feature = out_feature;

    if (likely(inf->feature)) {
      *out_feature = *(inf->feature);
    } else if (likely(inf->feature_list && inf->feature_list->feature_size() > 0)) {
      *out_feature = inf->feature_list->feature(inf->feature_list->feature_size() - 1);
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

bool ExpoAppidCountConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("ExpoAppidCountConfig::compute");

  const Value* input_value_list = get_value(input_values, inputs_, 0);
  const Value* input_value_dst = get_value(input_values, inputs_, 1);

  std::map<std::string, int32_t> occur_map;

  // 计算输入
  for (const InputFeature& inf : input_value_list->ifeatures) {
    if (likely(inf.feature)) {
      for (const std::string& appid : inf.feature->bytes_list().value()) {
        occur_map[appid]++;
      }
    } else if (likely(inf.feature_list)) {
      for (auto& feat : inf.feature_list->feature()) {
        for (const std::string& appid : feat.bytes_list().value()) {
          occur_map[appid]++;
        }
      }
    }
  }

  // 输出
  const InputFeature* inf = nullptr;
  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;
  const uint32_t batch_size = input_value_dst->ifeatures.size();

  output.values.resize(1);
  Value& value_count = output.values[0];
  value_count.defalut_type = tensorflow::DT_INT64;
  value_count.ifeatures.resize(batch_size);

  for (uint32_t i = 0; i < batch_size; i++) {
    inf = &input_value_dst->ifeatures[i];
    if (likely(inf->feature)) {
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value_count.ifeatures[i].feature = out_feature;
      compute_one_feature(*inf->feature, occur_map, out_feature);
    } else if (likely(inf->feature_list)) {
      out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value_count.ifeatures[i].feature_list = out_featurelist;
      for (auto& feat : inf->feature_list->feature()) {
        compute_one_feature(feat, occur_map, out_featurelist->add_feature());
      }
    }
  }

  return true;
}

void ExpoAppidCountConfig::compute_one_feature(const tensorflow::Feature& feat,
                                                std::map<std::string, int32_t>& occur_map,
                                                tensorflow::Feature* out) {
  for (const std::string& str : feat.bytes_list().value()) {
    out->mutable_int64_list()->add_value(occur_map[str]);
  }
}

bool NearestExpoDaysConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("NearestExpoDaysConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* appid_value = get_value(input_values, inputs_, 0);
  const Value* eventtime_value = get_value(input_values, inputs_, 1);
  int64_t now = get_feature_one_int64(input_values, inputs_, 2);
  const Value* item_value = get_value(input_values, inputs_, 3);

  const InputFeature* inf_appid = nullptr;
  const InputFeature* inf_eventtime = nullptr;

  uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());
  std::map<std::string, int64_t> time_map;

  for (uint32_t i = 0; i < input_size; i++) {
    inf_appid = &appid_value->ifeatures[i];
    inf_eventtime = &eventtime_value->ifeatures[i];

    if (likely(inf_appid->feature && inf_eventtime->feature)) {
      comput_one_input(*inf_appid->feature, *inf_eventtime->feature, time_map);
    } else if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
      uint32_t list_size = std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

      for (uint32_t i = 0; i < list_size; i++) {
        comput_one_input(inf_appid->feature_list->feature(i), inf_eventtime->feature_list->feature(i), time_map);
      }
    }
  }

  const uint32_t batch_size = item_value->ifeatures.size();
  const InputFeature* inf = nullptr;
  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;

  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_INT64;
  value.ifeatures.resize(batch_size);

  for (uint32_t i = 0; i < batch_size; i++) {
    inf = &item_value->ifeatures[i];

    if (likely(inf->feature)) {
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;
      compute_one_feature(*inf->feature, now, time_map, out_feature);
    } else if (likely(inf->feature_list)) {
      out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_featurelist;

      for (auto& feat : inf->feature_list->feature()) {
        compute_one_feature(feat, now, time_map, out_featurelist->add_feature());
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void NearestExpoDaysConfig::comput_one_input(const tensorflow::Feature& appid_feat,
                                              const tensorflow::Feature& time_feat,
                                              std::map<std::string, int64_t>& time_map) {
  auto& appid_vec = appid_feat.bytes_list().value();
  auto& eventtime_vec = time_feat.int64_list().value();
  const uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());

  for (uint32_t i = 0; i < list_size; i++) {
    int64_t& time = time_map[appid_vec[i]];
    if (0 == time || time < eventtime_vec[i]) {
      time = eventtime_vec[i];
    }
  }
}

void NearestExpoDaysConfig::compute_one_feature(const tensorflow::Feature& feat,
                                                int64_t now,
                                                std::map<std::string, int64_t>& time_map,
                                                tensorflow::Feature* out) {
  for (const std::string& appid : feat.bytes_list().value()) {
    int64_t day = 100;
    auto itr = time_map.find(appid);
    if (itr != time_map.end()) {
      LogDebug("now:{} itr->second:{}", now, itr->second);
      day = diff_days(now / 1000, itr->second / 1000);
    }

    LogDebug("day:{}", day);

    // 防止请求时间小于事件发生时间，返回负值导致std::log运算失败
    if (unlikely(day < 0)) {
      day = 100;
    }
    day = 2 * std::log(day + 1);

    LogDebug("day:{}", day);

    out->mutable_int64_list()->add_value(day);
  }
}

bool Max123ClassConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("Max123ClassConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);
  std::vector<std::map<std::string, uint32_t>> class_count(3);
  
  for (const InputFeature& inf : input_value->ifeatures) {
    if (likely(inf.feature)) {
      Item2Class::count(*dict_, inf.feature->bytes_list().value(), class_count);
    } else if (likely(inf.feature_list)) {
      for (auto& feat : inf.feature_list->feature()) {
        Item2Class::count(*dict_, feat.bytes_list().value(), class_count);
      }
    }
  }

  output.values.resize(3);
  for (uint32_t i = 0; i < 3; i++) {
    const std::string* c = nullptr;
    uint32_t max = 0;
    for (auto& pair : class_count[i]) {
      if (pair.second > max) {
        max = pair.second;
        c = &pair.first;
      }
    }

    Value& value = output.values[i];
    value.defalut_type = tensorflow::DT_STRING;
    value.ifeatures.resize(1);
    tensorflow::Feature* out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
    value.ifeatures[0].feature = out_feature;
    if (!allow_empty_output_ || c) {
      out_feature->mutable_bytes_list()->add_value(nullptr != c ? *c : "");
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

bool Expo123CountConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("Expo123CountConfig::compute");

  const Value* src_app_id_value = get_value(input_values, inputs_, 0);
  const Value* dst_app_id_value = get_value(input_values, inputs_, 1);
  std::vector<std::map<std::string, uint32_t>> class_count(3);

  for (const InputFeature& inf : src_app_id_value->ifeatures) {
    if (likely(inf.feature)) {
      Item2Class::count(*dict_, inf.feature->bytes_list().value(), class_count);
    } else if (likely(inf.feature_list)) {
      for (auto& feat : inf.feature_list->feature()) {
        Item2Class::count(*dict_, feat.bytes_list().value(), class_count);
      }
    }
  }

  const InputFeature* inf = nullptr;
  const uint32_t batch_size = dst_app_id_value->ifeatures.size();

  output.values.resize(3);
  for (uint32_t i = 0; i < 3; i++) {
    Value& value = output.values[i];
    value.defalut_type = tensorflow::DT_INT64;
    value.ifeatures.resize(batch_size);
  }

  std::vector<tensorflow::Feature*> out_int_feat(3);
  std::vector<tensorflow::FeatureList*> out_int_featlsit(3);

  for (uint32_t i = 0; i < batch_size; i++) {
    inf = &dst_app_id_value->ifeatures[i];

    if (likely(inf->feature)) {
      for (uint32_t j = 0; j < 3; j++) {
        out_int_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_int_feat[j];
      }
      compute_one_feature(*inf->feature, class_count, out_int_feat);
    } else if (likely(inf->feature_list)) {
      for (uint32_t j = 0; j < 3; j++) {
        out_int_featlsit[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_int_featlsit[j];
      }

      for (auto& feat : inf->feature_list->feature()) {
        for (uint32_t j = 0; j < 3; j++) {
          out_int_feat[j] = out_int_featlsit[j]->add_feature();
        }
        compute_one_feature(feat, class_count, out_int_feat);
      }
    }
  }

  return true;
}

void Expo123CountConfig::compute_one_feature(const tensorflow::Feature& feat,
                                              std::vector<std::map<std::string, uint32_t>>& class_count,
                                              std::vector<tensorflow::Feature*>& out_int_feat) {
  for(const std::string& dst_id: feat.bytes_list().value()) {
    const AllClasses* all_class = Item2Class::lookup(*dict_, dst_id);

    if (nullptr == all_class || 3 != all_class->three_class.size()) {
      LogDebug("find {} failed, size:{}", dst_id, dict_->size());
      out_int_feat[0]->mutable_int64_list()->add_value(0);
      out_int_feat[1]->mutable_int64_list()->add_value(0);
      out_int_feat[2]->mutable_int64_list()->add_value(0);
    } else {
      out_int_feat[0]->mutable_int64_list()->add_value(class_count[0][all_class->three_class[0]]);
      out_int_feat[1]->mutable_int64_list()->add_value(class_count[1][all_class->three_class[1]]);
      out_int_feat[2]->mutable_int64_list()->add_value(class_count[2][all_class->three_class[2]]);
    }
  }
}

bool Expo123CountV2Config::compute(const std::vector<const Output*>& input_values, Output& output) {
  const Value* src_app_id_value = get_value(input_values, inputs_, 0);
  const Value* dst_app_id_value = get_value(input_values, inputs_, 1);
  std::vector<std::map<std::string, uint32_t>> class_count(3);

  for (const InputFeature& inf : src_app_id_value->ifeatures) {
    if (likely(inf.feature)) {
      Item2Class::count(*dict_, inf.feature->bytes_list().value(), class_count);
    } else if (likely(inf.feature_list)) {
      for (auto& feat : inf.feature_list->feature()) {
        Item2Class::count(*dict_, feat.bytes_list().value(), class_count);
      }
    }
  }

  const InputFeature* inf = nullptr;
  const uint32_t batch_size = dst_app_id_value->ifeatures.size();

  output.values.resize(6);
  for (uint32_t i = 0; i < 6; i++) {
    Value& value = output.values[i];
    value.defalut_type = tensorflow::DT_INT64;
    value.ifeatures.resize(batch_size);
  }

  std::vector<tensorflow::Feature*> out_bool_feat(3);
  std::vector<tensorflow::Feature*> out_int_feat(3);
  std::vector<tensorflow::FeatureList*> out_bool_featlist(3);
  std::vector<tensorflow::FeatureList*> out_int_featlist(3);

  for (uint32_t i = 0; i < batch_size; i++) {
    inf = &dst_app_id_value->ifeatures[i];

    if (likely(inf->feature)) {
      for (uint32_t j = 0; j < 3; j++) {
        out_bool_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[2 * j].ifeatures[i].feature = out_bool_feat[j];
        out_int_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[2 * j + 1].ifeatures[i].feature = out_int_feat[j];
      }
      compute_one_feature(*inf->feature, class_count, out_bool_feat, out_int_feat);
    } else if (likely(inf->feature_list)) {
      for (uint32_t j = 0; j < 3; j++) {
        out_bool_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[2 * j].ifeatures[i].feature_list = out_bool_featlist[j];
        out_int_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[2 * j + 1].ifeatures[i].feature_list = out_int_featlist[j];
      }
      for (auto& feat : inf->feature_list->feature()) {
        for (uint32_t j = 0; j < 3; j++) {
          out_bool_feat[j] = out_bool_featlist[j]->add_feature();
          out_int_feat[j] = out_int_featlist[j]->add_feature();
        }
        compute_one_feature(feat, class_count, out_bool_feat, out_int_feat);
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void Expo123CountV2Config::compute_one_feature(const tensorflow::Feature& feat,
                                                std::vector<std::map<std::string, uint32_t>>& class_count,
                                                std::vector<tensorflow::Feature*>& out_bool_feat,
                                                std::vector<tensorflow::Feature*>& out_int_feat) {
  for(const std::string& dst_id: feat.bytes_list().value()) {
    const AllClasses* all_class = Item2Class::lookup(*dict_, dst_id);

    if (nullptr == all_class || 3 != all_class->three_class.size()) {
      LogDebug("find {} failed, size:{}", dst_id, dict_->size());
      out_bool_feat[0]->mutable_int64_list()->add_value(0);
      out_int_feat[0]->mutable_int64_list()->add_value(0);
      out_bool_feat[1]->mutable_int64_list()->add_value(0);
      out_int_feat[1]->mutable_int64_list()->add_value(0);
      out_bool_feat[2]->mutable_int64_list()->add_value(0);
      out_int_feat[2]->mutable_int64_list()->add_value(0);
    } else {
      out_bool_feat[0]->mutable_int64_list()->add_value(class_count[0].count(all_class->three_class[0]));
      out_int_feat[0]->mutable_int64_list()->add_value(class_count[0][all_class->three_class[0]]);
      out_bool_feat[1]->mutable_int64_list()->add_value(class_count[1].count(all_class->three_class[1]));
      out_int_feat[1]->mutable_int64_list()->add_value(class_count[1][all_class->three_class[1]]);
      out_bool_feat[2]->mutable_int64_list()->add_value(class_count[2].count(all_class->three_class[2]));
      out_int_feat[2]->mutable_int64_list()->add_value(class_count[2][all_class->three_class[2]]);
    }
  }
}

bool AppidCrossConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("AppidCross::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* appid_input_value = get_value(input_values, inputs_, 0);
  const Value* item_input_value = get_value(input_values, inputs_, 1);
  const uint32_t batch_size = item_input_value->ifeatures.size();
  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_INT64;
  value.ifeatures.resize(batch_size);

  if (likely(appid_input_value->ifeatures.size() == batch_size)) {
    for (uint32_t i = 0; i < batch_size; i++) {
      std::vector<std::string> appid_vec;
      fill_ifeature_to_vec(&appid_input_value->ifeatures[i], appid_vec);
      compute_one_ifeature(output.arena, appid_vec, &item_input_value->ifeatures[i], &value.ifeatures[i]);
    }
  } else if (likely(1 == appid_input_value->ifeatures.size())) {
    std::vector<std::string> appid_vec;
    fill_ifeature_to_vec(&appid_input_value->ifeatures[0], appid_vec);
    for (uint32_t i = 0; i < batch_size; i++) {
      compute_one_ifeature(output.arena, appid_vec, &item_input_value->ifeatures[i], &value.ifeatures[i]);
    }
  } else {
    THROW_ERROR("invalid appid_input_value_size, not euqal to 1 or item_size, name:" + output_);
    return false;
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void AppidCrossConfig::compute_one_ifeature(google::protobuf::Arena* arena, const std::vector<std::string>& vec, const InputFeature* hf_item, InputFeature* hf_out) {
  if (nullptr == hf_item) {
    THROW_ERROR("null hf, name:" + output_);
    return;
  }

  tensorflow::FeatureList* out_featurelist = nullptr;
  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(arena);
  hf_out->feature_list = out_featurelist;

  // 交叉
  if (likely(hf_item->feature)) {
    compute_one_feature(vec, *hf_item->feature, out_featurelist);
  } else if (likely(hf_item->feature_list)) {
    for (auto& feat : hf_item->feature_list->feature()) {
      compute_one_feature(vec, feat, out_featurelist);
    }
  }
}

void AppidCrossConfig::fill_ifeature_to_vec(const InputFeature* hf, std::vector<std::string>& vec) {
  // 展开所有的appid
  if (likely(hf->feature)) {
    fill_feature_to_vec(*hf->feature, vec);
  } else if (likely(hf->feature_list)) {
    for (auto& feat : hf->feature_list->feature()) {
      fill_feature_to_vec(feat, vec);
    }
  }
}

void AppidCrossConfig::fill_feature_to_vec(const tensorflow::Feature& feat, std::vector<std::string>& vec) {
  vec.reserve(vec.size() + feat.bytes_list().value_size());
  for (const std::string& str : feat.bytes_list().value()) {
    vec.push_back(str);
  }
}

void AppidCrossConfig::compute_one_feature(const std::vector<std::string>& vec, const tensorflow::Feature& item_feat, tensorflow::FeatureList* hf_out_featurelist) {
  std::string concat;

  // 每一个appid 都和 item做交叉，输出feature_list的一个新的feature
  for (const std::string& appid : vec) {
    concat = appid + item_feat.bytes_list().value(0);
    hf_out_featurelist->add_feature()->mutable_int64_list()->add_value(util::Fingerprint64(concat.data(), concat.size()) % bucket_size_);
  }
}

bool ToFeatureConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("ToFeatureConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);
  const InputFeature* inf = nullptr;
  const uint32_t batch_size = input_value->ifeatures.size();
  tensorflow::Feature* out_feature = nullptr;

  // Output output;
  output.values.resize(1);
  auto& value = output.values[0];
  value.defalut_type = input_value->defalut_type;
  value.ifeatures.resize(batch_size);

  for (uint32_t i = 0; i < batch_size; i++) {
    inf = &input_value->ifeatures[i];

    out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
    value.ifeatures[i].feature = out_feature;

    if (likely(inf->feature)) {
      *(out_feature) = *inf->feature;
    } else if (likely(inf->feature_list)) {
      for (auto& feat : inf->feature_list->feature()) {
        strategy_.merge_feature(feat, *out_feature, output_, allow_empty_output_);
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

bool ToBatchFeatureConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("ToBatchFeatureConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);

  if (unlikely(1 != input_value->ifeatures.size())) {
    THROW_ERROR("invalid ifeatures size:" + std::to_string(input_value->ifeatures.size()) + ", name:" + output_);
    return false;
  }

  // Output output;
  output.values.resize(1);
  auto& value = output.values[0];
  value.defalut_type = input_value->defalut_type;
  const InputFeature* inf = &input_value->ifeatures[0];
  tensorflow::Feature* out_feature = nullptr;

  if (likely(inf->feature_list)) {
    value.ifeatures.resize(inf->feature_list->feature_size());

    for (int32_t i = 0; i < inf->feature_list->feature_size(); i++) {
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;
      *(out_feature) = inf->feature_list->feature(i);
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void IdentityConfig::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (int64_t d : feat.int64_list().value()) {
    if (d < 0 || d > max_value_) {
      out->mutable_int64_list()->add_value(default_value_);
    } else {
      out->mutable_int64_list()->add_value(d);
    }
  }
}

void StringToInt64Config::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  int64_t num = 0;
  for (const std::string& str : feat.bytes_list().value()) {
    //转换成功填入int64,转换失败填入默认值
    if (unlikely(!Calc::convert_int64(str, num))) {
      num = default_value_;
    }
    out->mutable_int64_list()->add_value(num);
  }
  //如果数据源中的bytes_list为空，填入一个默认值确保返回结果不为空
  if (!allow_empty_output_ && out->int64_list().value_size() < 1) {
    out->mutable_int64_list()->add_value(default_value_);
  }
}

void AppidTo123ClassConfig::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (const std::string& str : feat.bytes_list().value()) {
    const AllClasses* all_class = Item2Class::lookup(*dict_, str);
    if (nullptr != all_class && 3 == all_class->three_class.size()) {
      out->mutable_bytes_list()->add_value(all_class->three_class[static_cast<int64_t>(class_type_)]);
    } else if (!default_value_.empty()) {
      out->mutable_bytes_list()->add_value(default_value_);
    }
  }
  //如果数据源中的bytes_list为空，输出不允许空且存在默认值，填入一个默认值确保返回结果不为空
  if (!allow_empty_output_ && !default_value_.empty() && out->bytes_list().value_size() < 1) {
    out->mutable_bytes_list()->add_value(default_value_);
  }
}

bool CrossHashBitsConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("CrossHashBitsConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  int64_t info_size = input_values.size() - 1;

  const Value* item_input_value = get_value(input_values, inputs_, info_size);

  std::vector<const Value*> info_vec(info_size, nullptr);
  for (int64_t i = 0; i < info_size; ++i) {
    info_vec[i] = get_value(input_values, inputs_, i);
  }

  //获取info数据
  std::vector<std::vector<int64_t>> info_hash_vec(info_size);
  for (int64_t i = 0; i < info_size; ++i) {
    HashCompute::fill_value_to_vec(info_vec[i], info_hash_vec[i]);
  }

  const uint32_t batch_size = item_input_value->ifeatures.size();
  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_INT64;
  value.ifeatures.resize(batch_size);

  const InputFeature* inf_item = nullptr;
  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;

  //每个item和fea1全交叉
  for (uint32_t i = 0; i < batch_size; i++) {
    inf_item = &item_input_value->ifeatures[i];

    std::vector<int64_t> item_vec;
    std::vector<std::vector<int64_t>> out_vec(info_size);
    //获取一个item数据
    HashCompute::fill_input_to_vec(*inf_item, item_vec);

    // 全交叉
    if (info_size > 1) {
      Math::bitwise_cross(info_hash_vec[0], info_hash_vec[1], clip_size_, out_vec[0]);
      for (uint32_t i = 1; i < info_size - 1; ++i) {
        Math::bitwise_cross_continue(out_vec[i - 1], info_hash_vec[i + 1], i + 2, clip_size_, out_vec[i]);
      }
      Math::bitwise_cross_continue(out_vec[info_size - 2], item_vec, info_size + 1, clip_size_, out_vec[info_size - 1]);
    } else if (info_size == 1) {
      Math::bitwise_cross(info_hash_vec[0], item_vec, clip_size_, out_vec[0]);
    }

    if (likely(inf_item->feature_list)) {
      out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_featurelist;

      if (info_size > 0) {
        for (uint32_t j = 0; j < out_vec[info_size - 1].size(); j++) {
          Math::set_highest_bit_to_zero(out_vec[info_size - 1][j]);
          out_featurelist->add_feature()->mutable_int64_list()->add_value(out_vec[info_size - 1][j]);
        }
      }
    } else {
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;

      if (info_size > 0) {
        for (uint32_t j = 0; j < out_vec[info_size - 1].size(); j++) {
          Math::set_highest_bit_to_zero(out_vec[info_size - 1][j]);
          out_feature->mutable_int64_list()->add_value(out_vec[info_size - 1][j]);
        }
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void ActValueConfig::compute_one_feature(const tensorflow::Feature& input_feat1,
                                         const tensorflow::Feature& input_feat2,
                                         tensorflow::Feature* out) {
  switch (input_feat1.kind_case()) {
    case tensorflow::Feature::kFloatList: {
      for (int32_t i = 0; i < input_feat1.float_list().value_size(); i++) {
        if (input_feat1.float_list().value(i) >= activation_float_) {
          fill_value_to_feature(true, i, input_feat2, out);
        } else {
          fill_value_to_feature(false, i, input_feat2, out);
        }
      }
      break;
    }
    case tensorflow::Feature::kInt64List: {
      for (int32_t i = 0; i < input_feat1.int64_list().value_size(); i++) {
        if (input_feat1.int64_list().value(i) >= activation_int_) {
          fill_value_to_feature(true, i, input_feat2, out);
        } else {
          fill_value_to_feature(false, i, input_feat2, out);
        }
      }
      break;
    }
    case tensorflow::Feature::KIND_NOT_SET: {
      break;
    }
    default: {
      THROW_ERROR("invalid type: first source is not int or float, name:" + output_);
      break;
    }
  }
}

void ActValueConfig::fill_value_to_feature(bool flag,
                                           int32_t idx,
                                           const tensorflow::Feature& input_feat,
                                           tensorflow::Feature* out) {
  switch (input_feat.kind_case()) {
    case tensorflow::Feature::kFloatList: {
      data_type_ = tensorflow::DT_FLOAT;
      if (input_feat.float_list().value_size() > idx) {
        if (flag) {
          out->mutable_float_list()->add_value(input_feat.float_list().value(idx));
        } else {
          out->mutable_float_list()->add_value(default_float_);
        }
      }
      break;
    }
    case tensorflow::Feature::kInt64List: {
      data_type_ = tensorflow::DT_INT64;
      if (input_feat.int64_list().value_size() > idx) {
        if (flag) {
          out->mutable_int64_list()->add_value(input_feat.int64_list().value(idx));
        } else {
          out->mutable_int64_list()->add_value(default_int_);
        }
      }
      break;
    }
    // feature为空，输出空
    case tensorflow::Feature::KIND_NOT_SET: {
      break;
    }
    default: {
      THROW_ERROR("invalid type: second source is not int or float, name:" + output_);
      break;
    }
  }
}

void Int64OffsetConfig::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (int64_t l : feat.int64_list().value()) {
    out->mutable_int64_list()->add_value(l + offset_);
  }
}

bool DictToAttributesConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("DictToAttributesConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);

  uint32_t batch_size = input_value->ifeatures.size();
  uint32_t values_size = AllClasses::size;

  output.values.resize(values_size);
  for (uint32_t i = 0; i < values_size; i++) {
    Value& value = output.values[i];
    value.defalut_type = tensorflow::DT_STRING;
    value.ifeatures.resize(batch_size);
  }

  std::vector<tensorflow::Feature*> out_feat(values_size);
  std::vector<tensorflow::FeatureList*> out_featlist(values_size);

  const InputFeature* inf_value = nullptr;

  for (uint32_t i = 0; i < batch_size; i++) {
    inf_value = &input_value->ifeatures[i];

    if (likely(inf_value->feature_list)) {
      for (uint32_t j = 0; j < values_size; j++) {
        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_featlist[j];
      }

      for (auto& feat : inf_value->feature_list->feature()) {
        for (uint32_t j = 0; j < values_size; j++) {
          out_feat[j] = out_featlist[j]->add_feature();
        }
        compute_one_feature(feat, out_feat);
      }
    } else {
      for (uint32_t j = 0; j < values_size; j++) {
        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_feat[j];
      }

      compute_one_feature(*inf_value->feature, out_feat);
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void DictToAttributesConfig::compute_one_feature(const tensorflow::Feature& feat, std::vector<tensorflow::Feature*>& out_feat) {
  for (const std::string& str : feat.bytes_list().value()) {
    const AllClasses* all_class = Item2Class::lookup(*dict_, str);
    if (nullptr != all_class && !all_class->app_id.empty() && 3 == all_class->three_class.size()) {
      out_feat[0]->mutable_bytes_list()->add_value(all_class->app_id);
      out_feat[1]->mutable_bytes_list()->add_value(all_class->package_name);
      out_feat[2]->mutable_bytes_list()->add_value(all_class->app_name);
      out_feat[3]->mutable_bytes_list()->add_value(all_class->three_class[0]);
      out_feat[4]->mutable_bytes_list()->add_value(all_class->three_class[1]);
      out_feat[5]->mutable_bytes_list()->add_value(all_class->three_class[2]);
      std::string tags;
      for (uint32_t i = 0; i < all_class->app_tags.size() - 1; i++) {
        tags.append(all_class->app_tags[i]).append(trans_connector_);
      }
      tags.append(all_class->app_tags[all_class->app_tags.size() - 1]);
      out_feat[6]->mutable_bytes_list()->add_value(tags);
      out_feat[7]->mutable_bytes_list()->add_value(all_class->dev_name);
      out_feat[8]->mutable_bytes_list()->add_value(all_class->develop_id);
    } else if (!default_value_.empty()) {
      for (uint32_t i = 0; i < out_feat.size(); i++) {
        out_feat[i]->mutable_bytes_list()->add_value(default_value_);
      }
    }
  }
}

uint32_t AllClasses::max_extra_size;
bool DictToAttributesV2Config::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("DictToAttributesV2Config::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);

  uint32_t batch_size = input_value->ifeatures.size();
  uint32_t values_size = AllClasses::size + AllClasses::max_extra_size;

  output.values.resize(values_size);
  for (uint32_t i = 0; i < values_size; i++) {
    Value& value = output.values[i];
    value.defalut_type = tensorflow::DT_STRING;
    value.ifeatures.resize(batch_size);
  }

  std::vector<tensorflow::Feature*> out_feat(values_size);
  std::vector<tensorflow::FeatureList*> out_featlist(values_size);

  const InputFeature* inf_value = nullptr;

  for (uint32_t i = 0; i < batch_size; i++) {
    inf_value = &input_value->ifeatures[i];

    if (likely(inf_value->feature_list)) {
      for (uint32_t j = 0; j < values_size; j++) {
        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_featlist[j];
      }

      for (auto& feat : inf_value->feature_list->feature()) {
        for (uint32_t j = 0; j < values_size; j++) {
          out_feat[j] = out_featlist[j]->add_feature();
        }
        compute_one_feature(feat, out_feat);
      }
    } else {
      for (uint32_t j = 0; j < values_size; j++) {
        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_feat[j];
      }
      compute_one_feature(*inf_value->feature, out_feat);
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void DictToAttributesV2Config::compute_one_feature(const tensorflow::Feature& feat, std::vector<tensorflow::Feature*>& out_feat) {
  for (const std::string& str : feat.bytes_list().value()) {
    const AllClasses* all_class = Item2Class::lookup(*dict_, str);

    if (nullptr != all_class && !all_class->app_id.empty() && 3 == all_class->three_class.size()) {
      out_feat[0]->mutable_bytes_list()->add_value(all_class->app_id);
      out_feat[1]->mutable_bytes_list()->add_value(all_class->package_name);
      out_feat[2]->mutable_bytes_list()->add_value(all_class->app_name);
      out_feat[3]->mutable_bytes_list()->add_value(all_class->three_class[0]);
      out_feat[4]->mutable_bytes_list()->add_value(all_class->three_class[1]);
      out_feat[5]->mutable_bytes_list()->add_value(all_class->three_class[2]);
      if (!connector_.empty()) {
        std::string tags;
        for (uint32_t i = 0; i < all_class->app_tags.size() - 1; i++) {
          tags.append(all_class->app_tags[i]).append(trans_connector_);
        }
        tags.append(all_class->app_tags[all_class->app_tags.size() - 1]);
        out_feat[6]->mutable_bytes_list()->add_value(tags);
      } else {
        for (uint32_t i = 0; i < all_class->app_tags.size(); i++) {
          out_feat[6]->mutable_bytes_list()->add_value(all_class->app_tags[i]);
        }
      }
      out_feat[7]->mutable_bytes_list()->add_value(all_class->dev_name);
      out_feat[8]->mutable_bytes_list()->add_value(all_class->develop_id);

      // 扩展字段
      uint32_t dict_value_size = AllClasses::size + all_class->extra_fields.size();
      for (uint32_t out_idx = AllClasses::size; out_idx < out_feat.size(); out_idx++) {
        if (out_idx < dict_value_size && !all_class->extra_fields[out_idx-AllClasses::size].empty()) {
          const auto& extra_field = all_class->extra_fields[out_idx-AllClasses::size];
          if (!connector_.empty()) {
            std::string extra_vals;
            for (uint32_t i = 0; i < extra_field.size() - 1; i++) {
              extra_vals.append(extra_field[i]).append(trans_connector_);
            }
            extra_vals.append(extra_field.back()); 
            out_feat[out_idx]->mutable_bytes_list()->add_value(extra_vals);
          } else {
            for (uint32_t i = 0; i < extra_field.size(); i++) {
              out_feat[out_idx]->mutable_bytes_list()->add_value(extra_field[i]);
            }
          }
        } else if (!default_value_.empty()) {
          out_feat[out_idx]->mutable_bytes_list()->add_value(default_value_);
        }
      }
    } else if (!default_value_.empty()) {
      for (uint32_t out_idx = 0; out_idx < out_feat.size(); out_idx++) {
        out_feat[out_idx]->mutable_bytes_list()->add_value(default_value_);
      }
    }
  }
}

bool ConditionalFilterConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("ConditionalFilterConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* message_value = get_value(input_values, inputs_, 0);

  const uint32_t batch_size = message_value->ifeatures.size();
  const InputFeature* inf_message = nullptr;
  const google::protobuf::Message* mess = nullptr;
  uint32_t extract_size = fields_.size();
  std::vector<tensorflow::Feature*> out_feat(extract_size);
  std::vector<tensorflow::FeatureList*> out_featlist(extract_size);

  output.values.resize(extract_size);
  for (uint32_t i = 0; i < extract_size; i++) {
    Value& value = output.values[i];
    value.ifeatures.resize(batch_size);
  }
  MessageCompute::message_fill_fields_dtype_to_value(message_value, fields_, output.values, output_);

  //输出
  for (uint32_t i = 0; i < batch_size; i++) {
    inf_message = &message_value->ifeatures[i];
    uint32_t message_size = inf_message->messages.size();
    std::vector<uint32_t> allow_count(message_size, 0);
    std::vector<const google::protobuf::Message*> filter_vec;

    //遍历所有message
    for (uint32_t j = 0; j < message_size; j++) {
      mess = inf_message->messages[j];
      auto desc = mess->GetDescriptor();
      auto ref = mess->GetReflection();
      for (uint32_t k = 0; k < filter_.size(); k++) {
        auto field = desc->FindFieldByName(filter_[k]);

        if (unlikely(nullptr == ref || nullptr == field)) {
          THROW_ERROR("failed, get null_ptr on filter:" + filter_[k] + ", name:" + output_);
          return false;
        }

        if (unlikely(field->is_repeated())) {
          THROW_ERROR("failed, is repeated filter:" + filter_[k] + ", name:" + output_);
          return false;
        }

        switch (field->cpp_type()) {
          case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
            if (filter_dict_[k].empty() || filter_dict_[k].find(ref->GetString(*mess, field)) != filter_dict_[k].end()) {
              allow_count[j]++;
            }
          }
          break;

          default: {
            THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) + " filter:" + filter_[k] + " name:" + output_);
            return false;
          }
          break;
        }
      }

      //  全部条件符合，填充
      if (allow_count[j] == filter_dict_.size()) {
        filter_vec.emplace_back(mess);
      }
    }

    if (likely(!inputs_[0].from_request || inputs_[0].repeated_count != 0)) {
      for (uint32_t j = 0; j < extract_size; j++) {
        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
        output.values[j].ifeatures[i].feature_list = out_featlist[j];
      }

      for (const google::protobuf::Message* mess : filter_vec) {
        for (uint32_t j = 0; j < extract_size; j++) {
          out_feat[j] = out_featlist[j]->add_feature();
        }
        MessageCompute::message_fill_fields_to_feature(mess, fields_, output_, out_feat);
      }
    } else {
      for (uint32_t j = 0; j < extract_size; j++) {
        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
        output.values[j].ifeatures[i].feature = out_feat[j];
      }

      for (const google::protobuf::Message* mess : filter_vec) {
        MessageCompute::message_fill_fields_to_feature(mess, fields_, output_, out_feat);
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

bool MessageFilterV2Config::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("MessageFilterV2Config::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* message_value = get_value(input_values, inputs_, 0);

  const uint32_t batch_size = message_value->ifeatures.size();
  const InputFeature* inf_message = nullptr;
  const google::protobuf::Message* mess = nullptr;

  int64_t now = 0;
  if (!eventtime_key_.empty()) {
    now = get_feature_one_int64(input_values, inputs_, 1 + str_idx_.size() + int_idx_.size());
  }

  std::vector<const Value*> str_idx_vec(str_idx_.size(), nullptr);
  std::vector<const Value*> int_idx_vec(int_idx_.size(), nullptr);

  for (uint32_t i = 0; i < str_idx_.size(); i++) {
    str_idx_vec[i] = get_value(input_values, inputs_, str_idx_[i]);
  }

  for (uint32_t i = 0; i < int_idx_.size(); i++) {
    int_idx_vec[i] = get_value(input_values, inputs_, int_idx_[i]);
  }

  output.values.resize(1);
  Value& value = output.values[0];
  value.ifeatures.resize(batch_size);

  //输出
  for (uint32_t i = 0; i < batch_size; i++) {
    inf_message = &message_value->ifeatures[i];
    std::vector<const google::protobuf::Message*> filter_vec;

    if (!eventtime_key_.empty()) {
      int64_t time = 0;
      for (uint32_t j = 0; j < inf_message->messages.size(); j++) {
        mess = inf_message->messages[j];
        MessageCompute::message_fill_to_int64(mess, eventtime_key_, output_, time);
        //时间戳数据为13位
        if ((now - time) > start_ && (end_ < 0 || (now - time) < end_)) {
          filter_vec.emplace_back(mess);
        }
      }
    } else {
      filter_vec = inf_message->messages;
    }

    // 过滤str条件
    for (uint32_t j = 0; j < str_idx_.size(); j++) {
      std::string filter_str;
      if (get_ifeature_one_string(get_idx_ifeatures(str_idx_vec[j], i), filter_str)) {
        MessageCompute::message_filter_to_message<std::string>(output_, str_filter_[j], str_hit_[j], {filter_str}, filter_vec);
      } else if (!str_value_.empty()) {
        MessageCompute::message_filter_to_message<std::string>(output_, str_filter_[j], str_hit_[j], {str_value_[j]}, filter_vec);
      } else {
        if (str_hit_[j]) {
          filter_vec.clear();
        }
      }
    }

    // 过滤int条件
    for (uint32_t j = 0; j < int_idx_.size(); j++) {
      int64_t filter_num = 0;
      if (get_ifeature_one_int64(get_idx_ifeatures(int_idx_vec[j], i), filter_num)) {
        MessageCompute::message_filter_to_message<int64_t>(output_, int_filter_[j], int_hit_[j], {filter_num}, filter_vec);
      } else if (!int_value_.empty()) {
        MessageCompute::message_filter_to_message<int64_t>(output_, int_filter_[j], int_hit_[j], {int_value_[j]}, filter_vec);
      } else {
        if (int_hit_[j]) {
          filter_vec.clear();
        }
      }
    }

    output.values[0].ifeatures[i].messages.swap(filter_vec);
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

template<>
std::string MessageSelectConfig<int64_t>::get_config() {
  std::string display = "message_select:select_option:[int;";
  for (auto& pair : select_map_) {
    display.append(std::to_string(pair.first)).append(",").append(pair.second).append(";");
  }
  display.pop_back();
  display.append("], default_value:").append(default_value_);
  return display;
}

template<>
std::string MessageSelectConfig<std::string>::get_config() {
  std::string display = "message_select:select_option:[str;";
  for (auto& pair : select_map_) {
    display.append(pair.first).append(",").append(pair.second).append(";");
  }
  display.pop_back();
  display.append("], default_value:").append(default_value_);
  return display;
}

template<>
bool MessageSelectConfig<int64_t>::get_ifeature_value(const InputFeature* ifeature, int64_t& filter_value) {
  if (get_ifeature_one_int64(ifeature, filter_value)) {
    return true;
  } else if (!default_value_.empty()) {
    Calc::convert_int64(default_value_, filter_value);
    return true;
  }

  return false;
}

template<>
bool MessageSelectConfig<std::string>::get_ifeature_value(const InputFeature* ifeature, std::string& filter_value) {
  if (get_ifeature_one_string(ifeature, filter_value)) {
    return true;
  } else if (!default_value_.empty()) {
    filter_value = default_value_;
    return true;
  }

  return false;
}

bool RepetitionListConfig::compute(const std::vector<const Output*>& input_values, Output& output)  {
  DEBUG_TIMER("RepetitionListConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);
  const Value* a_batch_string_list = get_value(input_values, inputs_, 0);
  const Value* b_batch_string_list = get_value(input_values, inputs_, 1);
  size_t batch_size = std::min(a_batch_string_list->ifeatures.size(), b_batch_string_list->ifeatures.size());
  output.values.resize(batch_size);
  for (size_t i = 0; i < batch_size; i++) {
    Value& output_value = output.values[i];
    output_value.defalut_type = tensorflow::DT_FLOAT;
    output_value.ifeatures.resize(1);
    const InputFeature& a_feature = a_batch_string_list->ifeatures[i];
    const InputFeature& b_feature = b_batch_string_list->ifeatures[i];
    tensorflow::Feature* output_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
    output_value.ifeatures[0].feature = output_feature;
    if (a_feature.feature != nullptr && b_feature.feature != nullptr) {
      compute_one_feature(*a_feature.feature, *b_feature.feature, output_feature);
    } else if (a_feature.feature_list != nullptr && b_feature.feature_list != nullptr) { 
      compute_one_feature(*a_feature.feature_list, *b_feature.feature_list, output_feature);
    } else {
      output_feature->mutable_float_list()->add_value(0.0f);
    }
  }
  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void RepetitionListConfig::compute_one_feature(const tensorflow::Feature& a_feature, const tensorflow::Feature& b_feature,
  tensorflow::Feature* out_feat) {
    if (!a_feature.has_bytes_list() || a_feature.bytes_list().value_size() == 0 
        || !b_feature.has_bytes_list() || b_feature.bytes_list().value_size() == 0) {
          out_feat->mutable_float_list()->add_value(0);
          return;
    }
    std::unordered_map<std::string, uint64_t> a_word_counts{};
    a_word_counts.reserve(a_feature.bytes_list().value_size());
    std::unordered_map<std::string, uint64_t> b_word_counts;
    b_word_counts.reserve(b_feature.bytes_list().value_size());
    for (int i = 0; i < a_feature.bytes_list().value_size(); i++) {
      a_word_counts[a_feature.bytes_list().value(i)]++;
    }
    for (int i = 0; i < b_feature.bytes_list().value_size(); i++) {
      b_word_counts[b_feature.bytes_list().value(i)]++;
    }

    std::unordered_map<std::string, uint64_t>* traversed_words = &a_word_counts;
    std::unordered_map<std::string, uint64_t>* words_to_search = &b_word_counts;
    if (a_word_counts.size() > b_word_counts.size()) {
      traversed_words = &b_word_counts;
      words_to_search = &a_word_counts;
    }

    std::unordered_map<std::string, uint64_t> intersection{};
    uint64_t cos_distance = 0;

    for (const auto& pair : *traversed_words) {
      const auto& word = pair.first;
      uint64_t count_a = pair.second;
      auto b_iter = words_to_search->find(word);
      if (b_iter != words_to_search->cend()) {
        cos_distance = cos_distance + (count_a * b_iter->second);
      }
    }
    if (cos_distance == 0) {
      out_feat->mutable_float_list()->add_value(0.0f);
      return;
    }
    
    float a_magnitude = 0;
    float b_magnitude = 0;
    for (const auto& pair : a_word_counts) {
      a_magnitude = a_magnitude + (pair.second * pair.second);
    }
    for (const auto& pair : b_word_counts) {
      b_magnitude = b_magnitude + (pair.second * pair.second);
    }

    out_feat->mutable_float_list()->add_value(cos_distance / (std::sqrt(a_magnitude) * std::sqrt(b_magnitude)));
  }

  void RepetitionListConfig::compute_one_feature(const tensorflow::FeatureList& a_feature, const tensorflow::FeatureList& b_feature,
    tensorflow::Feature* out_feat) {
      if (a_feature.feature_size() == 0 || b_feature.feature_size() == 0) {
            out_feat->mutable_float_list()->add_value(0.0f);
            return;
      }
      std::unordered_map<std::string, uint64_t> a_word_counts{};
      a_word_counts.reserve(a_feature.feature_size());
      std::unordered_map<std::string, uint64_t> b_word_counts;
      b_word_counts.reserve(b_feature.feature_size());
      for (int i = 0; i < a_feature.feature_size(); i++) {
        a_word_counts[a_feature.feature(i).bytes_list().value(0)]++;
      }
      for (int i = 0; i < b_feature.feature_size(); i++) {
        b_word_counts[b_feature.feature(i).bytes_list().value(0)]++;
      }
  
      std::unordered_map<std::string, uint64_t>* traversed_words = &a_word_counts;
      std::unordered_map<std::string, uint64_t>* words_to_search = &b_word_counts;
      if (a_word_counts.size() > b_word_counts.size()) {
        traversed_words = &b_word_counts;
        words_to_search = &a_word_counts;
      }
  
      std::unordered_map<std::string, uint64_t> intersection{};
      uint64_t cos_distance = 0;
  
      for (const auto& pair : *traversed_words) {
        const auto& word = pair.first;
        uint64_t count_a = pair.second;
        auto b_iter = words_to_search->find(word);
        if (b_iter != words_to_search->cend()) {
          cos_distance = cos_distance + (count_a * b_iter->second);
        }
      }
      if (cos_distance == 0) {
        out_feat->mutable_float_list()->add_value(0.0f);
        return;
      }
      
      float a_magnitude = 0;
      float b_magnitude = 0;
      for (const auto& pair : a_word_counts) {
        a_magnitude = a_magnitude + (pair.second * pair.second);
      }
  
      for (const auto& pair : b_word_counts) {
        b_magnitude = b_magnitude + (pair.second * pair.second);
      }
      out_feat->mutable_float_list()->add_value(cos_distance / (std::sqrt(a_magnitude) * std::sqrt(b_magnitude)));
    }

bool CalcStatsConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("CalcStatsConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);
  size_t batch_size = input_value->ifeatures.size();

  output.values.resize(4);
  for (uint32_t i = 0; i < 4; i++) {
    Value& value = output.values[i];
    value.ifeatures.resize(batch_size);
  }
  output.values[0].defalut_type = tensorflow::DT_INT64;

  std::vector<tensorflow::Feature*> out_feat(4);
  const InputFeature* inf = nullptr;

  for (uint32_t i = 0; i < batch_size; i++) {
    for (uint32_t j = 0; j < 4; j++) {
      out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      output.values[j].ifeatures[i].feature = out_feat[j];
    }

    inf = &input_value->ifeatures[i];
    const tensorflow::Feature* feature = nullptr;
    get_value_feature(inf, 0, feature);

    if (feature) {
      switch (feature->kind_case()) {
        // 字符串值avg、max、sum输出空
        case tensorflow::Feature::kBytesList: {
          break;
        }

        case tensorflow::Feature::kFloatList: {
          std::vector<float> nums;
          if (inf->feature_list) {
            for (auto& feat : inf->feature_list->feature()) {
              for (float value : feat.float_list().value()) {
                nums.push_back(value);
              }
            }
          } else if (inf->feature) {
            for (float value : inf->feature->float_list().value()) {
              nums.push_back(value);
            }
          }
          if (nums.size() > 0) {
            float max = *std::max_element(nums.begin(), nums.end());
            float sum = std::accumulate(nums.begin(), nums.end(), 0.0f);
            float avg = static_cast<float>(sum) / nums.size();

            out_feat[0]->mutable_int64_list()->add_value(nums.size());
            out_feat[1]->mutable_float_list()->add_value(avg);
            out_feat[2]->mutable_float_list()->add_value(max);
            out_feat[3]->mutable_float_list()->add_value(sum);
          }
        }

        case tensorflow::Feature::kInt64List: {
          std::vector<int64_t> nums;
          if (inf->feature_list) {
            for (auto& feat : inf->feature_list->feature()) {
              for (int64_t value : feat.int64_list().value()) {
                nums.push_back(value);
              }
            }
          } else if (inf->feature) {
            for (int64_t value : inf->feature->int64_list().value()) {
              nums.push_back(value);
            }
          }

          if (nums.size() > 0) {
            int64_t max = *std::max_element(nums.begin(), nums.end());
            int64_t sum = std::accumulate(nums.begin(), nums.end(), 0);
            float avg = static_cast<float>(sum) / nums.size();

            out_feat[0]->mutable_int64_list()->add_value(nums.size());
            out_feat[1]->mutable_float_list()->add_value(avg);
            out_feat[2]->mutable_int64_list()->add_value(max);
            out_feat[3]->mutable_int64_list()->add_value(sum);
          }
        }

        case tensorflow::Feature::KIND_NOT_SET: {
          break;
        }
      }
    }

    // 如果类型为string或者输入空，长度填入
    if (out_feat[0]->int64_list().value_size() == 0) {
      int64_t len1 = get_ifeature_date_size(inf);
      out_feat[0]->mutable_int64_list()->add_value(len1);
    }

    // 如果输入空,填充默认值，或者输出空
    if (!allow_empty_output_ && out_feat[1]->float_list().value_size() == 0) {
      switch (data_type_) {
        case DATATYPE_FLOAT: {
          out_feat[1]->mutable_float_list()->add_value(default_float_);
          out_feat[2]->mutable_float_list()->add_value(default_float_);
          out_feat[3]->mutable_float_list()->add_value(default_float_);
        }
        break;

        case DATATYPE_INT32:
        case DATATYPE_INT64: {
          out_feat[1]->mutable_float_list()->add_value(default_int_);
          out_feat[2]->mutable_int64_list()->add_value(default_int_);
          out_feat[3]->mutable_int64_list()->add_value(default_int_);
        }
        break;

        default:
        break;
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}