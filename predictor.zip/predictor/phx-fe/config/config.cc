#include "config.h"

static void dont_save_strategy(Config* config_ptr) {
  config_ptr->save_ = false;
}

static void not_empty_strategy(Config* config_ptr) {  
  config_ptr->allow_empty_output_ = false;
}

static void empty_strategy(Config* config_ptr) {
  config_ptr->allow_empty_output_ = true;
}

static void auto_type_strategy(Config* config_ptr) {
  config_ptr->auto_type_ = true;
}

static void int32_strategy(Config* config_ptr) {
  config_ptr->int32_ = true;
  config_ptr->defalut_type_ = tensorflow::DT_INT32;
}

static void float_strategy(Config* config_ptr) {
  config_ptr->defalut_type_ = tensorflow::DT_FLOAT;
}

static void int64_strategy(Config* config_ptr) {
  config_ptr->defalut_type_ = tensorflow::DT_INT64;
}

static void string_strategy(Config* config_ptr) {
  config_ptr->defalut_type_ = tensorflow::DT_STRING;
}

static void hash_strategy(Config* config_ptr) {
  config_ptr->strategy_.emplace_back(std::make_shared<HashStrategy>());
}

static void feature_strategy(Config* config_ptr) {
  auto ptr = std::make_shared<FeatureStrategy>();
  ptr->allow_empty_output_ = config_ptr->allow_empty_output_;
  config_ptr->strategy_.emplace_back(ptr);
}

static void hash_slot_strategy(Config* config_ptr) {
  config_ptr->strategy_.emplace_back(std::make_shared<HashSlotStrategy>());
}

/*
  新加一个策略只需要三步：
  1 继承Strategy实现一个策略子类实现策略 XxxStrategy 或 改变Config控制变量
  2 实现xxx_strategy策略函数
  3 将策略名称和xxx_strategy添加到strategy_creator_map定义中
*/
void Config::create_strategy(const std::string& type, Config* config_ptr) {
  auto itr = strategy_creator_map.find(type);
  if (itr != strategy_creator_map.end() && nullptr != config_ptr) {
    itr->second(config_ptr);
  }
}

const std::map<std::string, Config::StrategyCreatorFunc> Config::strategy_creator_map = {
  {"dont_save",               dont_save_strategy},
  {"empty",                   empty_strategy},
  {"auto_type",               auto_type_strategy},
  {"int32",                   int32_strategy},
  {"float",                   float_strategy},
  {"int64",                   int64_strategy},
  {"string",                  string_strategy},
  {"hash",                    hash_strategy},
  {"feature",                 feature_strategy},
  {"hash_slot",               hash_slot_strategy},
  {"not_empty",               not_empty_strategy},
};