#include "phx_config_dict.h"
#include "phx-fe/util/log.h"
#include <cstddef>
#include <cstdint>

namespace phx_fe {

    QueryDictConfig::QueryDictConfig(const std::string &output, const std::vector<std::string> &source,
                                     DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                     const std::vector<std::string> &strategy, hidict::DictCollector *dict_collector,
                                     const std::string &dict_name, const std::string &output_fields_str,
                                     int64_t default_int64_value, float default_float_value,
                                     std::string default_string_value)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy),
          handler_((AdDict::AdDictCollector *) dict_collector, dict_name), default_int64_value_(default_int64_value),
          default_float_value_(default_float_value), default_string_value_(std::move(default_string_value)) {
        const google::protobuf::Descriptor *root_descriptor = handler_.GetValueTypeDescriptor();

        if (root_descriptor == nullptr) {
            THROW_ERROR("descriptor not found, dict_name = " + dict_name);
        }
        const google::protobuf::Message *prototype =
                google::protobuf::MessageFactory::generated_factory()->GetPrototype(root_descriptor);
        if (prototype == nullptr) {
            THROW_ERROR("prototype is null, can not get reflection! dict_name = " + dict_name);
        }
        this->reflection_ = prototype->GetReflection();
        if (this->reflection_ == nullptr) {
            THROW_ERROR("reflection is null! dict_name =" + dict_name);
        }
        auto output_fields = Calc::split_string(output_fields_str, ",");
        this->output_field_desc_index_.resize(output_fields.size());
        for (size_t output_field_index = 0; output_field_index < output_fields.size(); output_field_index++) {
            auto field_vec = Calc::split_string(output_fields[output_field_index], ".");
            size_t start_index = field_vec[0] == "." ? 1 : 0;
            const google::protobuf::FieldDescriptor *field_desc = nullptr;
            const ::google::protobuf::Descriptor *descriptor = root_descriptor;
            auto &cur_field_num_index = output_field_desc_index_[output_field_index];
            for (size_t index = start_index; index < field_vec.size(); index++) {
                field_desc = descriptor->FindFieldByName(field_vec[index]);
                if (unlikely(field_desc == nullptr)) {
                    THROW_ERROR("field not found! field name = [" + field_vec[index] + "]; dict_name = [" + dict_name +
                                "]");
                }
                cur_field_num_index.emplace_back(field_desc);
            }
        }
    }

    bool QueryDictConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        auto keys = get_value(input_values, inputs_, 0);

        output.values.resize(output_field_desc_index_.size());
        for (auto &value: output.values) {
            value.ifeatures.resize(keys->ifeatures.size());
            for (auto &ifeature: value.ifeatures) {
                ifeature.feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            }
        }
        for (size_t batch_index = 0; batch_index < keys->ifeatures.size(); batch_index++) {
            const auto fea = keys->ifeatures[batch_index].feature;
            if (!fea)
                THROW_ERROR("feature is nullptr");
            std::vector<const google::protobuf::Message *> messages{};
            this->handler_.QueryDict(*fea, &messages);
            for (const google::protobuf::Message *msg: messages) {
                for (size_t output_field_index = 0; output_field_index < output_field_desc_index_.size();
                     output_field_index++) {
                    const auto &sub_field_desc_index = output_field_desc_index_[output_field_index];
                    for (size_t i = 0; i < sub_field_desc_index.size(); i++) {
                        //字段为空
                        if (msg == nullptr) {
                            auto output_feature = const_cast<tensorflow::Feature *>(
                                    output.values[output_field_index].ifeatures[batch_index].feature);
                            const auto &sub_field_desc_index = output_field_desc_index_[output_field_index];
                            FillDefaultValue(sub_field_desc_index.back(), output_feature);
                            break;
                        }
                        auto field_desc = sub_field_desc_index[i];
                        if (i == sub_field_desc_index.size() - 1) {
                            if (field_desc->is_repeated()) {
                                auto output_feature = const_cast<tensorflow::Feature *>(
                                        output.values[output_field_index].ifeatures[batch_index].feature);
                                int32_t repeated_field_size = this->reflection_->FieldSize(*msg, field_desc);
                                if (repeated_field_size > 0) {
                                    switch (field_desc->cpp_type()) {
                                        case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_INT32): {
                                            for (int32_t repeated_index = 0; repeated_index < repeated_field_size;
                                                 repeated_index++) {
                                                output_feature->mutable_int64_list()->add_value(
                                                        this->reflection_->GetRepeatedInt32(*msg, field_desc,
                                                                                            repeated_index));
                                            }
                                            break;
                                        }
                                        case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_INT64): {
                                            for (int32_t repeated_index = 0; repeated_index < repeated_field_size;
                                                 repeated_index++) {
                                                output_feature->mutable_int64_list()->add_value(
                                                        this->reflection_->GetRepeatedInt64(*msg, field_desc,
                                                                                            repeated_index));
                                            }
                                            break;
                                        }
                                        case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_FLOAT): {
                                            for (int32_t repeated_index = 0; repeated_index < repeated_field_size;
                                                 repeated_index++) {
                                                output_feature->mutable_float_list()->add_value(
                                                        this->reflection_->GetRepeatedFloat(*msg, field_desc,
                                                                                            repeated_index));
                                            }
                                            break;
                                        }
                                        case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_DOUBLE): {
                                            for (int32_t repeated_index = 0; repeated_index < repeated_field_size;
                                                 repeated_index++) {
                                                output_feature->mutable_float_list()->add_value(
                                                        static_cast<float>(this->reflection_->GetRepeatedDouble(
                                                                *msg, field_desc, repeated_index)));
                                            }
                                            break;
                                        }
                                        case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_STRING): {
                                            for (int32_t repeated_index = 0; repeated_index < repeated_field_size;
                                                 repeated_index++) {
                                                output_feature->mutable_bytes_list()->add_value(
                                                        this->reflection_->GetRepeatedString(*msg, field_desc,
                                                                                             repeated_index));
                                            }
                                            break;
                                        }
                                        default: {
                                            THROW_ERROR("not support field value type! field = " +
                                                        field_desc->full_name());
                                            return false;
                                        }
                                    }
                                }

                            } else {
                                if (this->reflection_->HasField(*msg, field_desc)) {
                                    auto output_feature = const_cast<tensorflow::Feature *>(
                                            output.values[output_field_index].ifeatures[batch_index].feature);
                                    switch (field_desc->cpp_type()) {
                                        case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_INT32): {
                                            output_feature->mutable_int64_list()->mutable_value()->Add(
                                                    this->reflection_->GetInt32(*msg, field_desc));
                                            break;
                                        }
                                        case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_INT64): {
                                            output_feature->mutable_int64_list()->mutable_value()->Add(
                                                    this->reflection_->GetInt64(*msg, field_desc));
                                            break;
                                        }
                                        case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_FLOAT): {
                                            output_feature->mutable_float_list()->mutable_value()->Add(
                                                    this->reflection_->GetFloat(*msg, field_desc));
                                            break;
                                        }
                                        case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_DOUBLE): {
                                            output_feature->mutable_float_list()->mutable_value()->Add(
                                                    static_cast<float>(this->reflection_->GetDouble(*msg, field_desc)));
                                            break;
                                        }
                                        case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_STRING): {
                                            output_feature->mutable_bytes_list()->add_value(
                                                    this->reflection_->GetString(*msg, field_desc));
                                            break;
                                        }
                                        default: {
                                            THROW_ERROR("not support field value type! field = " +
                                                        field_desc->full_name());
                                            return false;
                                        }
                                    }
                                } else {
                                    auto output_feature = const_cast<tensorflow::Feature *>(
                                            output.values[output_field_index].ifeatures[batch_index].feature);
                                    const auto &sub_field_desc_index = output_field_desc_index_[output_field_index];
                                    FillDefaultValue(sub_field_desc_index.back(), output_feature);
                                    break;
                                }
                            }

                        } else {
                            msg = &(this->reflection_->GetMessage(*msg, field_desc));
                        }
                    }
                }
            }
        }

        return true;
    }

    bool QueryDictConfig::FillDefaultValue(const google::protobuf::FieldDescriptor *field_desc,
                                           tensorflow::Feature *output_feature) {
        switch (field_desc->cpp_type()) {
            case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_INT32):
            case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_INT64): {
                output_feature->mutable_int64_list()->mutable_value()->Add(this->default_int64_value_);
                break;
            }
            case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_FLOAT):
            case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_DOUBLE): {
                output_feature->mutable_float_list()->mutable_value()->Add(this->default_float_value_);
                break;
            }
            case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_STRING): {
                output_feature->mutable_bytes_list()->add_value(this->default_string_value_);
                break;
            }
            default: {
                THROW_ERROR("not support field value type! field = " + field_desc->full_name());
                return false;
            }
        }
        return true;
    }

    bool PreConnectToStringConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        LogDebug("------------ compute {} start ------------", output_);

        uint32_t info_size = input_values.size();
        uint32_t batch_size = 0;
        std::vector<const Value *> info_vec(info_size, nullptr);
        for (uint32_t i = 0; i < info_size; ++i) {
            info_vec[i] = get_value(input_values, inputs_, i);
            batch_size = std::max(batch_size, static_cast<uint32_t>(info_vec[i]->ifeatures.size()));
        }

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_STRING;
        value.ifeatures.resize(batch_size);

        const InputFeature *inf_value = nullptr;
        tensorflow::Feature *out_feature = nullptr;
        std::vector<std::string> str_vec(info_size, "");

        for (uint32_t i = 0; i < batch_size; i++) {
            for (uint32_t j = 0; j < info_size; j++) {

                uint32_t input_size = info_vec[j]->ifeatures.size();
                std::cout << "size" << input_size << std::endl;
                if (1 == input_size) {
                    inf_value = &info_vec[j]->ifeatures[0];
                    if (i != 0) {
                        continue;
                    }
                } else if (batch_size == input_size) {
                    inf_value = &info_vec[j]->ifeatures[i];
                    str_vec[j].clear();
                } else {
                    THROW_ERROR("real_values_size:" + std::to_string(input_size) +
                                ", batch_size:" + std::to_string(batch_size) + ", name:" + output_);
                }
                if (inf_value->feature_list) {
                    if (inf_value->feature_list->feature_size() > 0) {
                        compute_one_feature(inf_value->feature_list->feature(0), j, str_vec[j]);
                    } else {
                        str_vec[j].append(prefixs_[j]);
                    }
                } else if (likely(inf_value->feature)) {
                    compute_one_feature(*inf_value->feature, j, str_vec[j]);
                }
            }

            std::string all_str;
            for (const std::string &str: str_vec) {
                if (all_str.empty()) {
                    all_str.append(str);
                } else {
                    all_str.append(connector_).append(str);
                }
            }

            out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            value.ifeatures[i].feature = out_feature;
            if (!all_str.empty()) {
                out_feature->mutable_bytes_list()->add_value(all_str);
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void PreConnectToStringConfig::compute_one_feature(const tensorflow::Feature &feat, size_t idx, std::string &str) {
        str.append(prefixs_[idx]);
        switch (feat.kind_case()) {
            case tensorflow::Feature::kBytesList: {
                if (feat.bytes_list().value_size() > 0) {
                    str.append(feat.bytes_list().value(0));
                }
                break;
            }

            case tensorflow::Feature::kFloatList: {
                if (feat.float_list().value_size() > 0) {
                    str.append(std::to_string(feat.float_list().value(0)));
                }
                break;
            }

            case tensorflow::Feature::kInt64List: {
                if (feat.int64_list().value_size() > 0) {
                    str.append(std::to_string(feat.int64_list().value(0)));
                }
                break;
            }

            default: {
                break;
            }
        }
    }

    const std::unordered_map<std::string, std::string> QueryStatsDictConfig::types_map_ = {
            {"creative_id", "c"},     {"adgroup_id", "g"},     {"app_id", "a"},        {"first_type_id", "t1"},
            {"second_type_id", "t2"}, {"third_type_id", "t3"}, {"adunit_id", "u"},     {"conv_type", "v"},
            {"host_app_id", "h"},     {"query", "q"},          {"advertiser_id", "s"}, {"ad_unit_type", "ut"},
            {"ads_run_plt", "arp"}};

    QueryStatsDictConfig::QueryStatsDictConfig(const std::string &output, const std::vector<std::string> &source,
                                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                               const std::vector<std::string> &strategy,
                                               hidict::DictCollector *dict_collector, const std::string &dict_name,
                                               const std::string &output_fields_str, const std::string &keys,
                                               const std::string &types, int64_t default_int64_value,
                                               float default_float_value, const std::string &default_string_value)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy),
          handler_((AdDict::AdDictCollector *) dict_collector, dict_name), default_int64_value_(default_int64_value),
          default_float_value_(default_float_value), default_string_value_(default_string_value) {
        const google::protobuf::Descriptor *root_descriptor = handler_.GetValueTypeDescriptor();

        if (root_descriptor == nullptr) {
            THROW_ERROR("descriptor not found, dict_name = " + dict_name);
        }
        const google::protobuf::Message *prototype =
                google::protobuf::MessageFactory::generated_factory()->GetPrototype(root_descriptor);
        if (prototype == nullptr) {
            THROW_ERROR("prototype is null, can not get reflection! dict_name = " + dict_name);
        }
        this->reflection_ = prototype->GetReflection();
        if (this->reflection_ == nullptr) {
            THROW_ERROR("reflection is null! dict_name =" + dict_name);
        }
        auto output_fields = Calc::split_string(output_fields_str, ",");
        this->output_field_desc_index_.resize(output_fields.size());
        for (size_t output_field_index = 0; output_field_index < output_fields.size(); output_field_index++) {
            auto field_vec = Calc::split_string(output_fields[output_field_index], ".");
            size_t start_index = field_vec[0] == "." ? 1 : 0;
            const google::protobuf::FieldDescriptor *field_desc = nullptr;
            const ::google::protobuf::Descriptor *descriptor = root_descriptor;
            auto &cur_field_num_index = output_field_desc_index_[output_field_index];
            for (size_t index = start_index; index < field_vec.size(); index++) {
                field_desc = descriptor->FindFieldByName(field_vec[index]);
                if (unlikely(field_desc == nullptr)) {
                    THROW_ERROR("field not found! field name = [" + field_vec[index] + "]; dict_name = [" + dict_name +
                                "]; " + "output = [" + output_ + "]");
                }
                descriptor = field_desc->message_type();
                cur_field_num_index.emplace_back(field_desc);
            }
        }

        const auto keys_vec_str = Calc::split_string(keys, ",");
        const auto types_vec_str = Calc::split_string(types, ",");
        if (unlikely(types_vec_str.size() < keys_vec_str.size())) {
            THROW_ERROR("type's size less than key's size");
        }
        for (std::size_t i = 0; i < keys_vec_str.size(); ++i) {
            KeyType key_type;
            auto it = types_map_.find(types_vec_str[i]);
            if (it == types_map_.end()) {
                THROW_ERROR("unknown key's type:" + types_vec_str[i]);
            }
            key_type.type_ = it->second;

            std::size_t tmp_index = 0;
            if (GetSourceIndex(keys_vec_str[i], tmp_index)) {
                key_type.from_source_ = true;
                key_type.source_index_ = tmp_index;
            } else {
                key_type.from_source_ = false;
                key_type.value_ = keys_vec_str[i];
            }

            keys_.emplace_back(std::move(key_type));
        }

        if (unlikely(keys_.empty())) {
            THROW_ERROR("keys is empty");
        }
    }

    bool QueryStatsDictConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        std::vector<const Value *> values_vec;
        for (std::size_t i = 0; i < inputs_.size(); ++i) {
            values_vec.emplace_back(get_value(input_values, inputs_, i));
        }

        const std::size_t batch_size =
                (*std::max_element(values_vec.begin(), values_vec.end(), [](const Value *a, const Value *b) {
                    return a->ifeatures.size() < b->ifeatures.size();
                }))->ifeatures.size();

        output.values.resize(output_field_desc_index_.size());
        for (auto &value: output.values) {
            value.ifeatures.resize(batch_size);
            for (auto &ifeature: value.ifeatures) {
                ifeature.feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            }
        }

        for (std::size_t batch_index = 0; batch_index < batch_size; ++batch_index) {
            std::size_t feature_size = 0;
            const auto kind_case = values_vec[0]->ifeatures[0].feature->kind_case();
            if (kind_case == tensorflow::Feature::KindCase::kBytesList) {
                feature_size = values_vec[0]->ifeatures[0].feature->bytes_list().value_size();
            } else if (kind_case == tensorflow::Feature::KindCase::kInt64List) {
                feature_size = values_vec[0]->ifeatures[0].feature->int64_list().value_size();
            }

            std::vector<std::string> keys_vec;
            for (std::size_t feature_index = 0; feature_index < feature_size; ++feature_index) {
                std::string source_string;
                bool appendConnector = false;
                for (const auto &k: keys_) {
                    if (appendConnector) {
                        source_string.append("\001");
                    }
                    source_string.append(k.type_);
                    if (k.from_source_) {
                        source_string.append(GetSourceKey(values_vec[k.source_index_], batch_index, feature_index));
                    } else {
                        source_string.append(k.value_);
                    }
                    appendConnector = true;
                }
                keys_vec.emplace_back(std::move(source_string));
            }

            std::vector<const google::protobuf::Message *> messages;
            handler_.QueryDict(keys_vec, messages);
            for (const google::protobuf::Message *msg: messages) {
                for (size_t output_field_index = 0; output_field_index < output_field_desc_index_.size();
                     output_field_index++) {
                    const auto &sub_field_desc_index = output_field_desc_index_[output_field_index];

                    // 这里用一个临时指针，避免修改外部msg
                    const google::protobuf::Message *cur_msg = msg;

                    for (size_t i = 0; i < sub_field_desc_index.size(); i++) {
                        // 字段为空时填默认值
                        if (cur_msg == nullptr) {
                            auto output_feature = const_cast<tensorflow::Feature *>(
                                    output.values[output_field_index].ifeatures[batch_index].feature);
                            const auto &sub_field_desc_index = output_field_desc_index_[output_field_index];
                            FillDefaultValue(sub_field_desc_index.back(), output_feature);
                            break;
                        }

                        auto field_desc = sub_field_desc_index[i];
                        const auto *reflection = cur_msg->GetReflection();

                        if (i == sub_field_desc_index.size() - 1) {
                            // 最后一个字段，处理具体值
                            auto output_feature = const_cast<tensorflow::Feature *>(
                                    output.values[output_field_index].ifeatures[batch_index].feature);

                            if (field_desc->is_repeated()) {
                                int32_t repeated_field_size = reflection->FieldSize(*cur_msg, field_desc);
                                if (repeated_field_size > 0) {
                                    switch (field_desc->cpp_type()) {
                                        case google::protobuf::FieldDescriptor::CPPTYPE_INT32: {
                                            for (int32_t repeated_index = 0; repeated_index < repeated_field_size;
                                                 repeated_index++) {
                                                output_feature->mutable_int64_list()->add_value(
                                                        reflection->GetRepeatedInt32(*cur_msg, field_desc,
                                                                                     repeated_index));
                                            }
                                            break;
                                        }
                                        case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
                                            for (int32_t repeated_index = 0; repeated_index < repeated_field_size;
                                                 repeated_index++) {
                                                output_feature->mutable_int64_list()->add_value(
                                                        reflection->GetRepeatedInt64(*cur_msg, field_desc,
                                                                                     repeated_index));
                                            }
                                            break;
                                        }
                                        case google::protobuf::FieldDescriptor::CPPTYPE_FLOAT: {
                                            for (int32_t repeated_index = 0; repeated_index < repeated_field_size;
                                                 repeated_index++) {
                                                output_feature->mutable_float_list()->add_value(
                                                        reflection->GetRepeatedFloat(*cur_msg, field_desc,
                                                                                     repeated_index));
                                            }
                                            break;
                                        }
                                        case google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE: {
                                            for (int32_t repeated_index = 0; repeated_index < repeated_field_size;
                                                 repeated_index++) {
                                                output_feature->mutable_float_list()->add_value(
                                                        static_cast<float>(reflection->GetRepeatedDouble(
                                                                *cur_msg, field_desc, repeated_index)));
                                            }
                                            break;
                                        }
                                        case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
                                            for (int32_t repeated_index = 0; repeated_index < repeated_field_size;
                                                 repeated_index++) {
                                                output_feature->mutable_bytes_list()->add_value(
                                                        reflection->GetRepeatedString(*cur_msg, field_desc,
                                                                                      repeated_index));
                                            }
                                            break;
                                        }
                                        default: {
                                            THROW_ERROR("not support field value type! field = " +
                                                        field_desc->full_name());
                                            return false;
                                        }
                                    }
                                } else {
                                    FillDefaultValue(field_desc, output_feature);
                                }
                            } else {
                                // 非 repeated 字段，调用 HasField 前先判断字段是否属于当前消息
                                if (reflection->HasField(*cur_msg, field_desc)) {
                                    switch (field_desc->cpp_type()) {
                                        case google::protobuf::FieldDescriptor::CPPTYPE_INT32: {
                                            output_feature->mutable_int64_list()->mutable_value()->Add(
                                                    reflection->GetInt32(*cur_msg, field_desc));
                                            break;
                                        }
                                        case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
                                            output_feature->mutable_int64_list()->mutable_value()->Add(
                                                    reflection->GetInt64(*cur_msg, field_desc));
                                            break;
                                        }
                                        case google::protobuf::FieldDescriptor::CPPTYPE_FLOAT: {
                                            output_feature->mutable_float_list()->mutable_value()->Add(
                                                    reflection->GetFloat(*cur_msg, field_desc));
                                            break;
                                        }
                                        case google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE: {
                                            output_feature->mutable_float_list()->mutable_value()->Add(
                                                    static_cast<float>(reflection->GetDouble(*cur_msg, field_desc)));
                                            break;
                                        }
                                        case google::protobuf::FieldDescriptor::CPPTYPE_STRING: {
                                            output_feature->mutable_bytes_list()->add_value(
                                                    reflection->GetString(*cur_msg, field_desc));
                                            break;
                                        }
                                        default: {
                                            THROW_ERROR("not support field value type! field = " +
                                                        field_desc->full_name());
                                            return false;
                                        }
                                    }
                                } else {
                                    FillDefaultValue(field_desc, output_feature);
                                    break;
                                }
                            }
                        } else {
                            // 非最后一个字段，必须是消息类型，才能继续深入
                            if (field_desc->cpp_type() == google::protobuf::FieldDescriptor::CPPTYPE_MESSAGE) {
                                if (reflection->HasField(*cur_msg, field_desc)) {
                                    cur_msg = &(reflection->GetMessage(*cur_msg, field_desc));
                                } else {
                                    // 子消息不存在，填默认值并跳出
                                    auto output_feature = const_cast<tensorflow::Feature *>(
                                            output.values[output_field_index].ifeatures[batch_index].feature);
                                    FillDefaultValue(sub_field_desc_index.back(), output_feature);
                                    break;
                                }
                            } else {
                                // 不是消息类型，但不是最后一个字段，逻辑异常
                                THROW_ERROR("Field " + field_desc->full_name() +
                                            " is not a message type but not last field");
                                break;
                            }
                        }
                    }
                }
            }
        }

        return true;
    }

    bool QueryStatsDictConfig::FillDefaultValue(const google::protobuf::FieldDescriptor *field_desc,
                                                tensorflow::Feature *output_feature) {
        switch (field_desc->cpp_type()) {
            case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_INT32):
            case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_INT64): {
                output_feature->mutable_int64_list()->mutable_value()->Add(this->default_int64_value_);
                break;
            }
            case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_FLOAT):
            case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_DOUBLE): {
                output_feature->mutable_float_list()->mutable_value()->Add(this->default_float_value_);
                break;
            }
            case (google::protobuf::FieldDescriptor::CppType::CPPTYPE_STRING): {
                output_feature->mutable_bytes_list()->add_value(this->default_string_value_);
                break;
            }
            default: {
                THROW_ERROR("not support field value type! field = " + field_desc->full_name());
                return false;
            }
        }
        return true;
    }

    std::string QueryStatsDictConfig::GetSourceKey(const Value *key, size_t batch_size, size_t feature_index) {
        std::string result;
        size_t ifeature_index = 0;
        if (batch_size < key->ifeatures.size()) {
            ifeature_index = batch_size;
        }
        const auto kind_case = key->ifeatures[ifeature_index].feature->kind_case();
        if (kind_case == tensorflow::Feature::KindCase::kBytesList) {
            result = key->ifeatures[ifeature_index].feature->bytes_list().value(feature_index);
        } else {
            result = std::to_string(key->ifeatures[ifeature_index].feature->int64_list().value(feature_index));
        }
        return result;
    }

    QueryCustomDictConfig::QueryCustomDictConfig(const std::string &output, const std::vector<std::string> &source,
                                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                                 const std::vector<std::string> &strategy,
                                                 hidict::DictCollector *dict_collector, const std::string &dict_name,
                                                 const std::string &prefix, int64_t default_int64_value,
                                                 const std::string &default_string_value, float default_float_value,
                                                 int type, const std::string& key_type)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy),
          _handler((AdDict::AdDictCollector *) dict_collector, dict_name, prefix),
          _default_int64_value(default_int64_value), _default_string_value(default_string_value),
          _default_float_value(default_float_value), _type(type) {
        const google::protobuf::Descriptor *root_descriptor = _handler.GetValueTypeDescriptor();

        if (root_descriptor == nullptr) {
            THROW_ERROR("descriptor not found, dict_name = " + dict_name);
        }
        const google::protobuf::Message *prototype =
                google::protobuf::MessageFactory::generated_factory()->GetPrototype(root_descriptor);
        if (prototype == nullptr) {
            THROW_ERROR("prototype is null, can not get reflection! dict_name = " + dict_name);
        }
        _reflection = prototype->GetReflection();
        if (_reflection == nullptr) {
            THROW_ERROR("reflection is null! dict_name =" + dict_name);
        }
        auto key_type_it = QueryStatsDictConfig::types_map_.find(key_type);
        if (key_type_it == QueryStatsDictConfig::types_map_.end()) {
            THROW_ERROR("unknown key's type: [" + key_type + "]");
        }
        _key_type = key_type_it->second;
    }

    bool QueryCustomDictConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        const auto *keys = get_value(input_values, inputs_, 0);
        output.values.resize(1);
        output.values[0].ifeatures.resize(keys->ifeatures.size());

        for (std::size_t i = 0; i < keys->ifeatures.size(); ++i) {
            const auto *fea = keys->ifeatures[i].feature;
            if (!fea) {
                THROW_ERROR("feature is nullptr");
            }
            
            const tensorflow::Feature *message = _handler.QueryDict(*fea, _key_type);

            auto out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            if (!message) {
                // message 未找到，填充默认值
                if (_type == 0) {
                    out_feature->mutable_int64_list()->add_value(_default_int64_value);
                } else if (_type == 1) {
                    out_feature->mutable_bytes_list()->add_value(_default_string_value);
                } else if (_type == 2) {
                    out_feature->mutable_float_list()->add_value(_default_float_value);
                } else {
                    THROW_ERROR("error type");
                }
                message = out_feature;
            } else {
                // 检查类型是否一致
                if ((_type == 0 && message->kind_case() != tensorflow::Feature::kInt64List) || (_type == 1 && message->kind_case() != tensorflow::Feature::kBytesList) ||(_type == 2 && message->kind_case() != tensorflow::Feature::kFloatList)) {
                    THROW_ERROR("The value type of the dict does not match the config");
                }
                out_feature->CopyFrom(*message); // out_feature由output.arena管理，内容从message拷贝
            }

            output.values[0].ifeatures[i].feature = out_feature;
        }

        return true;
    }

}// namespace phx_fe