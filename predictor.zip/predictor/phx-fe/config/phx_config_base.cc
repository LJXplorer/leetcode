#include "phx_config_base.h"
#include "phx-fe/util/farmhash.h"
#include "phx-fe/util/invisible_character.h"
#include "phx-fe/util/math.h"
#include "phx-fe/util/timer.h"
#include <limits>
#include <string>

namespace phx_fe {

    bool CrossHashBitsV2Config::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("CrossHashBitsConfigV2::compute");
        LogDebug("------------ compute {} start ------------", output_);

        int64_t info_size = input_values.size();
        int64_t out_size = info_size - 1;

        std::vector<const Value *> info_vec(info_size, nullptr);
        std::vector<uint32_t> batch_vec(info_size);
        uint32_t batch_size = 0;

        for (int64_t i = 0; i < info_size; ++i) {
            info_vec[i] = get_value(input_values, inputs_, i);
            batch_vec[i] = info_vec[i]->ifeatures.size();
            batch_size = std::max(batch_size, batch_vec[i]);
        }

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_INT64;
        value.ifeatures.resize(batch_size);

        std::vector<std::vector<int64_t>> info_hash_vec(info_size);
        const InputFeature *input = nullptr;
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;

        for (uint32_t i = 0; i < batch_size; ++i) {
            // 获取batch的数据
            for (int64_t j = 0; j < info_size; ++j) {
                if (0 == i || batch_size == batch_vec[j]) {
                    input = &info_vec[j]->ifeatures[i];
                    info_hash_vec[j].clear();
                    HashCompute::fill_input_to_vec(*input, info_hash_vec[j]);
                }
            }

            std::vector<std::vector<int64_t>> out_vec(out_size);

            // 全交叉
            if (out_size > 0) {
                Math::bitwise_cross(info_hash_vec[0], info_hash_vec[1], clip_size_, out_vec[0]);
                for (uint32_t i = 1; i < out_size; ++i) {
                    Math::bitwise_cross_continue(out_vec[i - 1], info_hash_vec[i + 1], i + 2, clip_size_, out_vec[i]);
                }
            }

            if (input->feature_list) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;

                if (out_size > 0) {
                    for (uint32_t j = 0; j < out_vec[out_size - 1].size(); j++) {
                        Math::set_highest_bit_to_zero(out_vec[out_size - 1][j]);
                        out_featurelist->add_feature()->mutable_int64_list()->add_value(out_vec[out_size - 1][j]);
                    }
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (out_size > 0) {
                    for (uint32_t j = 0; j < out_vec[out_size - 1].size(); j++) {
                        Math::set_highest_bit_to_zero(out_vec[out_size - 1][j]);
                        out_feature->mutable_int64_list()->add_value(out_vec[out_size - 1][j]);
                    }
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SegmentConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        std::vector<std::string> words;
        for (const std::string &str: feat.bytes_list().value()) {
            segment_->Cut(str, words);
            for (std::string &part: words) {
                out->mutable_bytes_list()->add_value(part);
            }
        }
    }

    bool FullyCrossConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("FullyCrossConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *fea_input_value = get_value(input_values, inputs_, 0);
        const Value *item_input_value = get_value(input_values, inputs_, 1);

        uint32_t fea_input_size = fea_input_value->ifeatures.size();
        uint32_t batch_size = std::max(fea_input_size, static_cast<uint32_t>(item_input_value->ifeatures.size()));
        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_STRING;
        value.ifeatures.resize(batch_size);

        const InputFeature *inf_item = nullptr;
        const InputFeature *inf_fea = nullptr;
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;
        std::vector<std::string> fea_vec;

        //全交叉输出
        for (uint32_t i = 0; i < batch_size; i++) {
            if (i == 0 || fea_input_size == batch_size) {
                fea_vec.clear();
                inf_fea = get_idx_ifeatures(fea_input_value, i);
                fill_ifea_to_vec(inf_fea, fea_vec);
            }

            inf_item = get_idx_ifeatures(item_input_value, i);

            if (inf_item->feature_list) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;

                if (unlikely(fea_vec.empty() || 0 == inf_item->feature_list->feature_size())) {
                    out_featurelist->add_feature()->mutable_bytes_list()->add_value(default_value_);
                    continue;
                }

                for (int32_t j = 0; j < inf_item->feature_list->feature_size(); j++) {
                    compute_one_feature(fea_vec, inf_item->feature_list->feature(j), out_featurelist->add_feature());
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (unlikely(fea_vec.empty())) {
                    out_feature->mutable_bytes_list()->add_value(default_value_);
                    continue;
                }

                if (likely(inf_item->feature)) {
                    compute_one_feature(fea_vec, *inf_item->feature, out_feature);
                } else {
                    out_feature->mutable_bytes_list()->add_value(default_value_);
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void FullyCrossConfig::fill_ifea_to_vec(const InputFeature *ifea, std::vector<std::string> &vec) {
        if (ifea) {
            if (likely(ifea->feature)) {
                fill_one_feature_to_vec(*ifea->feature, vec);
            } else if (likely(ifea->feature_list && ifea->feature_list->feature_size() > 0)) {
                for (auto &feat: ifea->feature_list->feature()) {
                    fill_one_feature_to_vec(feat, vec);
                }
            }
        }
    }

    void FullyCrossConfig::fill_one_feature_to_vec(const tensorflow::Feature &feat, std::vector<std::string> &vec) {
        switch (feat.kind_case()) {
            case tensorflow::Feature::kBytesList: {
                vec.reserve(vec.size() + feat.bytes_list().value_size());
                for (const std::string &str: feat.bytes_list().value()) {
                    vec.emplace_back(str + connector_);
                }
                break;
            }
            case tensorflow::Feature::kFloatList: {
                vec.reserve(vec.size() + feat.float_list().value_size());
                for (const float f: feat.float_list().value()) {
                    vec.emplace_back(std::to_string(f) + connector_);
                }
                break;
            }
            case tensorflow::Feature::kInt64List: {
                vec.reserve(vec.size() + feat.int64_list().value_size());
                for (const int64_t value: feat.int64_list().value()) {
                    vec.emplace_back(std::to_string(value) + connector_);
                }
                break;
            }
            default: {
                break;
            }
        }
    }

    void FullyCrossConfig::compute_one_feature(std::vector<std::string> &vec, const tensorflow::Feature &feat,
                                               tensorflow::Feature *out) {
        std::string connect_str;
        switch (feat.kind_case()) {
            case tensorflow::Feature::kBytesList: {
                for (const std::string &str: feat.bytes_list().value()) {
                    for (const std::string &vec_str: vec) {
                        connect_str = vec_str + str;
                        out->mutable_bytes_list()->add_value(connect_str);
                    }
                }
                break;
            }
            case tensorflow::Feature::kFloatList: {
                for (const float f: feat.float_list().value()) {
                    for (const std::string &vec_str: vec) {
                        connect_str = vec_str + std::to_string(f);
                        out->mutable_bytes_list()->add_value(connect_str);
                    }
                }
                break;
            }
            case tensorflow::Feature::kInt64List: {
                for (const int64_t value: feat.int64_list().value()) {
                    for (const std::string &vec_str: vec) {
                        connect_str = vec_str + std::to_string(value);
                        out->mutable_bytes_list()->add_value(connect_str);
                    }
                }
                break;
            }
            default: {
                break;
            }
        }
        if (unlikely(out->bytes_list().value_size() == 0)) {
            out->mutable_bytes_list()->add_value(default_value_);
        }
    }

    bool CombineConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        output.values.resize(1);
        size_t size = input_values.size();
        size_t batch_size = std::numeric_limits<int32_t>::max();

        std::vector<tensorflow::Feature *> input_features;
        std::vector<const Value *> values;
        for (int32_t i = 0; i < size; ++i) {
            auto f = get_value(input_values, inputs_, i);
            values.emplace_back(f);
            if (batch_size > f->ifeatures.size()) {
                batch_size = f->ifeatures.size();
            }
        }
        output.values[0].ifeatures.resize(batch_size);
        for (int32_t batch_index = 0; batch_index < batch_size; batch_index++) {
            auto *out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            output.values[0].ifeatures[batch_index].feature = out_feature;
            tensorflow::Feature::KindCase first_kind_case = tensorflow::Feature::KIND_NOT_SET;
            for (int32_t i = 0; i < size; i++) {
                auto *input_feature = values[i]->ifeatures[batch_index].feature;
                if (input_feature != nullptr) {
                    if (first_kind_case == tensorflow::Feature::KIND_NOT_SET) {
                        first_kind_case = input_feature->kind_case();
                    }
                    switch (first_kind_case) {
                        case (tensorflow::Feature::KindCase::KIND_NOT_SET):
                            break;
                        case (tensorflow::Feature::KindCase::kBytesList): {
                            const int remain_size = _max_size - out_feature->bytes_list().value_size();
                            if (input_feature->bytes_list().value_size() <= remain_size) {
                                out_feature->mutable_bytes_list()->mutable_value()->Add(
                                        input_feature->bytes_list().value().begin(),
                                        input_feature->bytes_list().value().end());
                            } else {
                                out_feature->mutable_bytes_list()->mutable_value()->Add(
                                        input_feature->bytes_list().value().begin(),
                                        input_feature->bytes_list().value().begin() + remain_size);
                            }
                            break;
                        }
                        case (tensorflow::Feature::KindCase::kFloatList): {
                            const int remain_size = _max_size - out_feature->float_list().value_size();
                            if (input_feature->float_list().value_size() <= remain_size) {
                                out_feature->mutable_float_list()->mutable_value()->Add(
                                        input_feature->float_list().value().begin(),
                                        input_feature->float_list().value().end());
                            } else {
                                out_feature->mutable_float_list()->mutable_value()->Add(
                                        input_feature->float_list().value().begin(),
                                        input_feature->float_list().value().begin() + remain_size);
                            }
                            break;
                        }
                        case (tensorflow::Feature::KindCase::kInt64List): {
                            const int remain_size = _max_size - out_feature->int64_list().value_size();
                            if (input_feature->int64_list().value_size() <= remain_size) {
                                out_feature->mutable_int64_list()->mutable_value()->Add(
                                        input_feature->int64_list().value().begin(),
                                        input_feature->int64_list().value().end());
                            } else {
                                out_feature->mutable_int64_list()->mutable_value()->Add(
                                        input_feature->int64_list().value().begin(),
                                        input_feature->int64_list().value().begin() + remain_size);
                            }
                            break;
                        }
                    }
                }
            }
        }
        return true;
    }

    ConnectConfig::ConnectConfig(const std::string &output, const std::vector<std::string> &source,
                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                 const std::vector<std::string> &strategy, const std::string &connector,
                                 const std::string &tail)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy), org_connector_(connector),
          connector_(connector), tail_(tail) {
        InvisibleCharacter::character_replace(connector_);
    }

    std::string ConnectConfig::get_config() {
        std::string display = "connect:connector:";
        display.append(org_connector_);
        display.append(", tail:").append(tail_);
        return display;
    }

    bool ConnectConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("ConnectConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        std::vector<const Value *> value_vec(inputs_.size());
        const Value *first_input_value = get_value(input_values, inputs_, 0);
        value_vec[0] = first_input_value;
        uint32_t batch_size = first_input_value->ifeatures.size();
        for (uint32_t i = 1; i < inputs_.size(); i++) {
            const Value *input_value = get_value(input_values, inputs_, i);
            value_vec[i] = input_value;
            if (batch_size != input_value->ifeatures.size()) {
                THROW_ERROR("Invalid input,the feature sizes must be consistent, name:" + output_);
            }
        }

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_STRING;
        value.ifeatures.resize(batch_size);

        const InputFeature *inf_value = nullptr;
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;

        std::vector<std::string> str_vec;
        for (uint32_t i = 0; i < batch_size; i++) {
            //目前只能处理类型相同的特征字段，以第一个输入类型为主，然后判断其他输入的类型是否一致，如果存在不一致则抛异常
            inf_value = &value_vec[0]->ifeatures[i];
            if (inf_value->feature_list) {
                //需要先初始化
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;
                //遍历并获取feature list size,
                uint32_t min_feature_list_size = INT_MAX;
                for (uint32_t j = 0; j < value_vec.size(); j++) {
                    inf_value = &value_vec[j]->ifeatures[i];
                    if (unlikely(!inf_value->feature_list)) {
                        THROW_ERROR("The input feature types must be consistent, name:" + output_);
                    }
                    uint32_t feature_list_size = inf_value->feature_list->feature_size();
                    min_feature_list_size = std::min(min_feature_list_size, feature_list_size);
                }
                if (min_feature_list_size == INT_MAX || min_feature_list_size == 0) {
                    continue;
                }
                for (uint32_t k = 0; k < min_feature_list_size; k++) {
                    uint32_t min_feature_size = INT_MAX;
                    for (uint32_t j = 0; j < value_vec.size(); j++) {
                        inf_value = &value_vec[j]->ifeatures[i];
                        uint32_t feature_size = get_feature_size(inf_value->feature_list->feature(k));
                        min_feature_size = std::min(min_feature_size, feature_size);
                    }
                    if (min_feature_size == INT_MAX || min_feature_size == 0) {
                        continue;
                    }
                    str_vec.clear();
                    str_vec.resize(min_feature_size);
                    for (uint32_t j = 0; j < value_vec.size(); j++) {
                        inf_value = &value_vec[j]->ifeatures[i];
                        compute_one_feature(inf_value->feature_list->feature(k), str_vec);
                    }
                    auto feat = out_featurelist->add_feature();
                    for (std::string &str: str_vec) {
                        if (!tail_.empty()) {
                            str.append(connector_).append(tail_);
                        }
                        feat->mutable_bytes_list()->add_value(str);
                    }
                }
            } else {
                //需要先初始化
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;
                uint32_t min_feature_size = INT_MAX;
                for (uint32_t j = 0; j < value_vec.size(); j++) {
                    inf_value = &value_vec[j]->ifeatures[i];
                    if (unlikely(!inf_value->feature)) {
                        THROW_ERROR("The input feature types must be consistent, name:" + output_);
                    }
                    uint32_t feature_size = get_feature_size(*inf_value->feature);
                    min_feature_size = std::min(min_feature_size, feature_size);
                }
                //如果没有属性或者属性为0则直接跳过
                if (min_feature_size == INT_MAX || min_feature_size == 0) {
                    continue;
                }
                str_vec.clear();
                str_vec.resize(min_feature_size);
                for (uint32_t j = 0; j < value_vec.size(); j++) {
                    inf_value = &value_vec[j]->ifeatures[i];
                    compute_one_feature(*inf_value->feature, str_vec);
                }
                for (std::string &str: str_vec) {
                    if (!tail_.empty()) {
                        str.append(connector_).append(tail_);
                    }
                    out_feature->mutable_bytes_list()->add_value(str);
                }
            }
        }
        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    uint32_t ConnectConfig::get_feature_size(const tensorflow::Feature &feat) {
        switch (feat.kind_case()) {
            case tensorflow::Feature::kBytesList: {
                return feat.bytes_list().value_size();
            }
            case tensorflow::Feature::kFloatList: {
                return feat.float_list().value_size();
            }
            case tensorflow::Feature::kInt64List: {
                return feat.int64_list().value_size();
            }
            default: {
                return 0;
            }
        }
    }

    void ConnectConfig::compute_one_feature(const tensorflow::Feature &feat, std::vector<std::string> &vec) {
        switch (feat.kind_case()) {
            case tensorflow::Feature::kBytesList: {
                for (uint32_t i = 0; i < vec.size(); i++) {
                    if (vec[i].empty()) {
                        vec[i].append(feat.bytes_list().value(i));
                    } else {
                        vec[i].append(connector_).append(feat.bytes_list().value(i));
                    }
                }
                break;
            }
            case tensorflow::Feature::kFloatList: {
                for (uint32_t i = 0; i < vec.size(); i++) {
                    if (vec[i].empty()) {
                        vec[i].append(std::to_string(feat.float_list().value(i)));
                    } else {
                        vec[i].append(connector_).append(std::to_string(feat.float_list().value(i)));
                    }
                }
                break;
            }
            case tensorflow::Feature::kInt64List: {
                for (uint32_t i = 0; i < vec.size(); i++) {
                    if (vec[i].empty()) {
                        vec[i].append(std::to_string(feat.int64_list().value(i)));
                    } else {
                        vec[i].append(connector_).append(std::to_string(feat.int64_list().value(i)));
                    }
                }
                break;
            }
            default: {
                break;
            }
        }
    }

    Int64DifferenceConfig::Int64DifferenceConfig(const std::string &output, const std::vector<std::string> &source,
                                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                                 const std::vector<std::string> &strategy)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy) {
    }

    std::string Int64DifferenceConfig::get_config() {
        return "int64_difference";
    }

    bool Int64DifferenceConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("Int64DifferenceConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        int64_t num = get_feature_one_int64(input_values, inputs_, 0);
        const Value *input_value = get_value(input_values, inputs_, 1);
        const uint32_t batch_size = input_value->ifeatures.size();

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_INT64;
        value.ifeatures.resize(batch_size);

        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_feature_list = nullptr;
        const InputFeature *inf = nullptr;

        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &input_value->ifeatures[i];

            if (inf->feature_list) {
                out_feature_list = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_feature_list;

                for (int32_t j = 0; j < inf->feature_list->feature_size(); j++) {
                    compute_one_feature(num, inf->feature_list->feature(j), out_feature_list->add_feature());
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (likely(inf->feature)) {
                    compute_one_feature(num, *inf->feature, out_feature);
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void Int64DifferenceConfig::compute_one_feature(const int64_t num, const tensorflow::Feature &feat,
                                                    tensorflow::Feature *out) {
        auto &value_vec = feat.int64_list().value();
        for (int64_t value: value_vec) {
            out->mutable_int64_list()->add_value(num - value);
        }
    }

    ClipConfig::ClipConfig(const std::string &output, const std::vector<std::string> &source,
                           DefaultValue &default_input_value, bool save, bool allow_empty_output,
                           const std::vector<std::string> &strategy, int64_t start, int64_t size)
        : OneInputConfig(output, source, default_input_value, save, allow_empty_output, strategy), start_(start),
          size_(size) {
        data_type_ = tensorflow::DT_INVALID;
    }

    std::string ClipConfig::get_config() {
        std::string display = "clip:start:";
        display.append(std::to_string(start_));
        display.append(", size:").append(std::to_string(size_));
        return display;
    }

    void ClipConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out_feature) {
        int32_t size = size_;

        switch (feat.kind_case()) {
            case tensorflow::Feature::kBytesList: {
                data_type_ = tensorflow::DT_STRING;
                // 处理 bytes_list
                if (-1 == size) {
                    size = feat.bytes_list().value_size();
                } else {
                    size = std::min(start_ + size, feat.bytes_list().value_size());
                }

                for (int32_t i = start_; i < size; i++) {
                    out_feature->mutable_bytes_list()->add_value(feat.bytes_list().value(i));
                }
            } break;
            case tensorflow::Feature::kFloatList: {
                data_type_ = tensorflow::DT_FLOAT;
                // 处理 float_list
                if (-1 == size) {
                    size = feat.float_list().value_size();
                } else {
                    size = std::min(start_ + size, feat.float_list().value_size());
                }

                for (int32_t i = start_; i < size; i++) {
                    out_feature->mutable_float_list()->add_value(feat.float_list().value(i));
                }
            } break;
            case tensorflow::Feature::kInt64List: {
                // 处理 int64_list
                data_type_ = tensorflow::DT_INT64;
                if (-1 == size) {
                    size = feat.int64_list().value_size();
                } else {
                    size = std::min(start_ + size, feat.int64_list().value_size());
                }

                for (int32_t i = start_; i < size; i++) {
                    out_feature->mutable_int64_list()->add_value(feat.int64_list().value(i));
                }
            } break;
            default: {
            } break;
        }
    }

    void ClipConfig::fill_value_dtype(tensorflow::DataType &data_type) {
        data_type = data_type_;
    }

    ExistsConfig::ExistsConfig(const std::string &output, const std::vector<std::string> &source,
                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                               const std::vector<std::string> &strategy)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy) {
    }

    std::string ExistsConfig::get_config() {
        return "exists";
    }

    bool ExistsConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("ExistsConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *input_value = get_value(input_values, inputs_, 0);
        size_t batch_size = input_value->ifeatures.size();

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);

        output.values[0].defalut_type = tensorflow::DT_INT64;
        tensorflow::Feature *out_feature = nullptr;
        const InputFeature *inf = nullptr;

        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &input_value->ifeatures[i];
            int64_t exists = get_ifeature_date_size(inf) > 0 ? 1 : 0;

            out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            value.ifeatures[i].feature = out_feature;

            out_feature->mutable_int64_list()->add_value(exists);
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    LenDiffConfig::LenDiffConfig(const std::string &output, const std::vector<std::string> &source,
                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                 const std::vector<std::string> &strategy)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy) {
    }

    std::string LenDiffConfig::get_config() {
        return "len_diff";
    }

    bool LenDiffConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("LenDiffConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *input_value1 = get_value(input_values, inputs_, 0);
        const Value *input_value2 = get_value(input_values, inputs_, 1);
        size_t batch_size = std::max(input_value1->ifeatures.size(), input_value2->ifeatures.size());

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);

        output.values[0].defalut_type = tensorflow::DT_INT64;
        tensorflow::Feature *out_feature = nullptr;
        const InputFeature *inf_value1 = nullptr;
        const InputFeature *inf_value2 = nullptr;

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            if (0 == i || batch_size == input_value1->ifeatures.size()) {
                inf_value1 = &input_value1->ifeatures[i];
            }
            if (0 == i || batch_size == input_value2->ifeatures.size()) {
                inf_value2 = &input_value2->ifeatures[i];
            }

            int64_t len1 = get_ifeature_date_size(inf_value1);
            int64_t len2 = get_ifeature_date_size(inf_value2);

            out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            value.ifeatures[i].feature = out_feature;

            out_feature->mutable_int64_list()->add_value(len1 - len2);
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    LenRatioConfig::LenRatioConfig(const std::string &output, const std::vector<std::string> &source,
                                   DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                   const std::vector<std::string> &strategy, LenRatioType len_ratio_type,
                                   float default_value)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy),
          len_ratio_type_(len_ratio_type), default_value_(default_value) {
    }

    std::string LenRatioConfig::get_config() {
        std::string display = "len_ratio:ratio_type:";
        display.append(std::to_string(static_cast<int64_t>(len_ratio_type_)));
        display.append(", default_value:").append(std::to_string(default_value_));
        return display;
    }

    bool LenRatioConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("LenRatioConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *input_value1 = get_value(input_values, inputs_, 0);
        const Value *input_value2 = get_value(input_values, inputs_, 1);
        size_t batch_size = std::max(input_value1->ifeatures.size(), input_value2->ifeatures.size());

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);

        output.values[0].defalut_type = tensorflow::DT_FLOAT;
        tensorflow::Feature *out_feature = nullptr;
        const InputFeature *inf_value1 = nullptr;
        const InputFeature *inf_value2 = nullptr;

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            if (0 == i || batch_size == input_value1->ifeatures.size()) {
                inf_value1 = &input_value1->ifeatures[i];
            }
            if (0 == i || batch_size == input_value2->ifeatures.size()) {
                inf_value2 = &input_value2->ifeatures[i];
            }

            int64_t len1 = get_ifeature_date_size(inf_value1);
            int64_t len2 = get_ifeature_date_size(inf_value2);
            out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            value.ifeatures[i].feature = out_feature;

            switch (len_ratio_type_) {
                case Ratio_ADD: {
                    float ratio = static_cast<float>(len1 + 1) / (len2 + 1);
                    out_feature->mutable_float_list()->add_value(ratio);
                } break;

                case Ratio_DEFAULT: {
                    if (0 != len2) {
                        float ratio = static_cast<float>(len1) / len2;
                        out_feature->mutable_float_list()->add_value(ratio);
                    } else {
                        out_feature->mutable_float_list()->add_value(default_value_);
                    }
                } break;

                default:
                    break;
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    bool DirectConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("DirectConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        output.own_values = false;
        const Value *input_value = get_value(input_values, inputs_, 0);
        const uint32_t batch_size = input_value->ifeatures.size();
        const InputFeature *inf = nullptr;

        output.values.resize(1);
        auto &value = output.values[0];
        value.defalut_type = input_value->defalut_type;
        value.ifeatures.resize(batch_size);
        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &input_value->ifeatures[i];
            if (likely(inf->feature)) {
                value.ifeatures[i].feature = inf->feature;

            } else if (likely(inf->feature_list)) {
                value.ifeatures[i].feature_list = inf->feature_list;
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    bool DirectToFeatureV2Config::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("DirectToFeatureV2Config::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *input_value = get_value(input_values, inputs_, 0);
        const InputFeature *inf = nullptr;
        const uint32_t batch_size = input_value->ifeatures.size();
        tensorflow::Feature *out_feature = nullptr;

        output.values.resize(1);
        auto &value = output.values[0];
        value.defalut_type = input_value->defalut_type;
        value.ifeatures.resize(batch_size);

        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &input_value->ifeatures[i];
            out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            value.ifeatures[i].feature = out_feature;

            if (likely(inf->feature)) {
                compute_one_feature(*inf->feature, out_feature);
            } else if (likely(inf->feature_list)) {
                for (auto &feat: inf->feature_list->feature()) {
                    compute_one_feature(feat, out_feature);
                }
            }

            // 填充默认值
            if (!allow_empty_output_ && out_feature->bytes_list().value_size() <= 0 &&
                out_feature->float_list().value_size() <= 0 && out_feature->int64_list().value_size() <= 0) {
                switch (data_type_) {
                    case DATATYPE_STRING: {
                        out_feature->mutable_bytes_list()->add_value(default_value_);
                    } break;

                    case DATATYPE_FLOAT: {
                        out_feature->mutable_float_list()->add_value(default_float_);
                    } break;

                    case DATATYPE_INT32:
                    case DATATYPE_INT64: {
                        out_feature->mutable_int64_list()->add_value(default_int_);
                    } break;

                    default:
                        break;
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void DirectToFeatureV2Config::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        float float_value = 0;
        int64_t num = 0;
        switch (feat.kind_case()) {
            case tensorflow::Feature::kBytesList: {
                for (const std::string &str: feat.bytes_list().value()) {
                    switch (data_type_) {
                        case DATATYPE_STRING:
                            out->mutable_bytes_list()->add_value(str);
                            break;
                        case DATATYPE_FLOAT:
                            //转换成功填入float,转换失败填入默认值
                            if (unlikely(!Calc::convert_float(str, float_value))) {
                                float_value = default_float_;
                            }
                            out->mutable_float_list()->add_value(float_value);
                            break;
                        case DATATYPE_INT32:
                        case DATATYPE_INT64:
                            //转换成功填入int64,转换失败填入默认值
                            if (unlikely(!Calc::convert_int64(str, num))) {
                                num = default_int_;
                            }
                            out->mutable_int64_list()->add_value(num);
                            break;
                        default:
                            break;
                    }
                }
                break;
            }
            case tensorflow::Feature::kFloatList: {
                for (const float f: feat.float_list().value()) {
                    switch (data_type_) {
                        case DATATYPE_STRING:
                            out->mutable_bytes_list()->add_value(std::to_string(f));
                            break;
                        case DATATYPE_FLOAT:
                            out->mutable_float_list()->add_value(f);
                            break;
                        case DATATYPE_INT32:
                        case DATATYPE_INT64:
                            out->mutable_int64_list()->add_value(static_cast<int64_t>(f));
                            break;
                        default:
                            break;
                    }
                }
                break;
            }
            case tensorflow::Feature::kInt64List: {
                for (const int64_t value: feat.int64_list().value()) {
                    switch (data_type_) {
                        case DATATYPE_STRING:
                            out->mutable_bytes_list()->add_value(std::to_string(value));
                            break;
                        case DATATYPE_FLOAT:
                            out->mutable_float_list()->add_value(static_cast<float>(value));
                            break;
                        case DATATYPE_INT32:
                        case DATATYPE_INT64:
                            out->mutable_int64_list()->add_value(value);
                            break;
                        default:
                            break;
                    }
                }
                break;
            }
            default: {
                break;
            }
        }
    }

    void TransTypeConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        float float_value = 0;
        int64_t num = 0;
        switch (feat.kind_case()) {
            case tensorflow::Feature::kBytesList: {
                for (const std::string &str: feat.bytes_list().value()) {
                    switch (data_type_) {
                        case DATATYPE_STRING:
                            out->mutable_bytes_list()->add_value(str);
                            break;
                        case DATATYPE_FLOAT:
                            //转换成功填入float,转换失败填入默认值
                            if (unlikely(!Calc::convert_float(str, float_value))) {
                                float_value = default_float_;
                            }
                            out->mutable_float_list()->add_value(float_value);
                            break;
                        case DATATYPE_INT32:
                        case DATATYPE_INT64:
                            //转换成功填入int64,转换失败填入默认值
                            if (unlikely(!Calc::convert_int64(str, num))) {
                                num = default_int_;
                            }
                            out->mutable_int64_list()->add_value(num);
                            break;
                        default:
                            break;
                    }
                }
                break;
            }
            case tensorflow::Feature::kFloatList: {
                for (const float f: feat.float_list().value()) {
                    switch (data_type_) {
                        case DATATYPE_STRING:
                            out->mutable_bytes_list()->add_value(std::to_string(f));
                            break;
                        case DATATYPE_FLOAT:
                            out->mutable_float_list()->add_value(f);
                            break;
                        case DATATYPE_INT32:
                        case DATATYPE_INT64:
                            out->mutable_int64_list()->add_value(static_cast<int64_t>(f));
                            break;
                        default:
                            break;
                    }
                }
                break;
            }
            case tensorflow::Feature::kInt64List: {
                for (const int64_t value: feat.int64_list().value()) {
                    switch (data_type_) {
                        case DATATYPE_STRING:
                            out->mutable_bytes_list()->add_value(std::to_string(value));
                            break;
                        case DATATYPE_FLOAT:
                            out->mutable_float_list()->add_value(static_cast<float>(value));
                            break;
                        case DATATYPE_INT32:
                        case DATATYPE_INT64:
                            out->mutable_int64_list()->add_value(value);
                            break;
                        default:
                            break;
                    }
                }
                break;
            }
            default: {
                break;
            }
        }

        //如果数据源中的bytes_list为空，填入一个默认值确保返回结果不为空
        if (!allow_empty_output_) {
            switch (data_type_) {
                case DATATYPE_STRING:
                    if (out->bytes_list().value_size() < 1) {
                        out->mutable_bytes_list()->add_value(default_value_);
                    }
                    break;
                case DATATYPE_FLOAT:
                    if (out->float_list().value_size() < 1) {
                        out->mutable_float_list()->add_value(default_float_);
                    }
                    break;
                case DATATYPE_INT32:
                case DATATYPE_INT64:
                    if (out->int64_list().value_size() < 1) {
                        out->mutable_int64_list()->add_value(default_int_);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    void TransTypeConfig::fill_value_dtype(tensorflow::DataType &data_type) {
        data_type = static_cast<tensorflow::DataType>(data_type_);
    }

    bool ConnectAllToStringConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("ConnectAllToStringConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        uint32_t info_size = input_values.size();
        uint32_t batch_size = 0;
        std::vector<const Value *> info_vec(info_size, nullptr);
        for (uint32_t i = 0; i < info_size; ++i) {
            info_vec[i] = get_value(input_values, inputs_, i);
            batch_size = std::max(batch_size, static_cast<uint32_t>(info_vec[i]->ifeatures.size()));
        }

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_STRING;
        value.ifeatures.resize(batch_size);

        const InputFeature *inf_value = nullptr;
        tensorflow::Feature *out_feature = nullptr;
        std::vector<std::pair<bool, std::string>> str_vec(info_size, {false, ""});

        for (uint32_t i = 0; i < batch_size; i++) {
            for (uint32_t j = 0; j < info_size; j++) {
                uint32_t input_size = info_vec[j]->ifeatures.size();
                if (1 == input_size) {
                    inf_value = &info_vec[j]->ifeatures[0];
                    if (i != 0) {
                        continue;
                    }
                } else if (batch_size == input_size) {
                    inf_value = &info_vec[j]->ifeatures[i];
                    str_vec[j].first = false;
                    str_vec[j].second.clear();
                } else {
                    THROW_ERROR("real_values_size:" + std::to_string(input_size) +
                                ", batch_size:" + std::to_string(batch_size) + ", name:" + output_);
                }
                if (likely(inf_value->feature_list)) {
                    for (auto &feat: inf_value->feature_list->feature()) {
                        compute_one_feature(feat, str_vec[j]);
                    }
                } else if (likely(inf_value->feature)) {
                    compute_one_feature(*inf_value->feature, str_vec[j]);
                }
            }

            std::string all_atr;
            for (size_t str_vec_index = 0; str_vec_index < str_vec.size(); str_vec_index++) {
                if (str_vec_index == 0) {
                    all_atr.append(str_vec[str_vec_index].second);
                } else {
                    all_atr.append(second_connector_).append(str_vec[str_vec_index].second);
                }
            }
            if (!all_atr.empty() && !tail_.empty()) {
                all_atr.append(second_connector_).append(tail_);
            }

            out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            value.ifeatures[i].feature = out_feature;
            if (!all_atr.empty()) {
                out_feature->mutable_bytes_list()->add_value(all_atr);
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void ConnectAllToStringConfig::compute_one_feature(const tensorflow::Feature &feat,
                                                       std::pair<bool, std::string> &pair) {
        switch (feat.kind_case()) {
            case tensorflow::Feature::kBytesList: {
                pair.first = true;
                int32_t fea_size = feat.bytes_list().value_size();
                for (int i = 0; i < fea_size; i++) {
                    if (i == 0) {
                        pair.second.append(feat.bytes_list().value(i));
                    } else {
                        pair.second.append(first_connector_).append(feat.bytes_list().value(i));
                    }
                }
                break;
            }
            case tensorflow::Feature::kFloatList: {
                pair.first = true;
                int32_t fea_size = feat.float_list().value_size();
                for (int32_t i = 0; i < fea_size; i++) {
                    float value = feat.float_list().value(i);
                    if (i == 0) {
                        pair.second.append(std::to_string(value));
                    } else {
                        pair.second.append(first_connector_).append(std::to_string(value));
                    }
                }
                break;
            }
            case tensorflow::Feature::kInt64List: {
                pair.first = true;
                int32_t fea_size = feat.int64_list().value_size();
                for (int32_t i = 0; i < fea_size; i++) {
                    int64_t value = feat.int64_list().value(i);
                    if (i == 0) {
                        pair.second.append(std::to_string(value));
                    } else {
                        pair.second.append(first_connector_).append(std::to_string(value));
                    }
                }
                break;
            }
            default: {
                break;
            }
        }
    }

    bool HashBucketConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("HashBucketConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *input_value = get_value(input_values, inputs_, 0);
        const uint32_t batch_size = input_value->ifeatures.size();
        const InputFeature *inf = nullptr;
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;

        std::string concat = "";
        if (likely(concat_with_name_)) {
            // get_value 未出错，表示inputs_肯定不为空
            concat = inputs_[0].name;
        }

        output.values.resize(1);
        auto &value = output.values[0];
        value.ifeatures.resize(batch_size);
        value.defalut_type = tensorflow::DT_INT64;

        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &input_value->ifeatures[i];

            if (likely(inf->feature)) {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;
                compute_one_feature(*inf->feature, concat, out_feature);
            } else if (likely(inf->feature_list)) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;
                for (auto &feat: inf->feature_list->feature()) {
                    compute_one_feature(feat, concat, out_featurelist->add_feature());
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);

        return true;
    }

    void HashBucketConfig::compute_one_feature(const tensorflow::Feature &feat, const std::string &concat,
                                               tensorflow::Feature *out) {
        std::string temp;

        if (likely(feat.bytes_list().value_size() > 0)) {
            for (auto &s: feat.bytes_list().value()) {
                if (s.empty() && concat.empty()) {
                    out->mutable_int64_list()->add_value(0);
                } else {
                    temp = s + concat;

                    LogDebug("f:{} temp:{}", s, temp);
                    out->mutable_int64_list()->add_value(util::Fingerprint64(temp.data(), temp.size()) % bucket_size_);
                }
            }
        } else if (likely(feat.int64_list().value_size() > 0)) {
            for (int64_t l: feat.int64_list().value()) {
                temp = std::to_string(l) + concat;

                out->mutable_int64_list()->add_value(util::Fingerprint64(temp.data(), temp.size()) % bucket_size_);
            }
        }
    }

    MessageFilterConfig::MessageFilterConfig(
            const std::string &output, const std::vector<std::string> &source, DefaultValue &default_input_value,
            bool save, bool allow_empty_output, const std::vector<std::string> &strategy,
            const std::vector<std::string> &str_filter, const std::vector<bool> &str_hit,
            const std::vector<std::set<std::string>> &str_filter_dict, const std::vector<std::string> &int_filter,
            const std::vector<bool> &int_hit, const std::vector<std::set<int64_t>> &int_filter_dict,
            const std::string &eventtime_key, int64_t start_ms, int64_t end_ms)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy), str_filter_(str_filter),
          str_hit_(str_hit), str_filter_dict_(str_filter_dict), int_filter_(int_filter), int_hit_(int_hit),
          int_filter_dict_(int_filter_dict), eventtime_key_(eventtime_key), start_(start_ms), end_(end_ms) {
    }

    std::string MessageFilterConfig::get_config() {
        std::string display = "message_filter:str_filter:[";
        for (uint32_t i = 0; i < str_filter_dict_.size(); i++) {
            display.append("[");
            display.append(str_filter_[i]).append(",");
            if (str_hit_[i]) {
                display.append("hit,");
            } else {
                display.append("miss,");
            }
            for (auto &filter_str: str_filter_dict_[i]) {
                display.append(filter_str).append(",");
                ;
            }
            display.pop_back();
            display.append("]");
        }
        display.append("], int_filter:[");
        for (uint32_t i = 0; i < int_filter_dict_.size(); i++) {
            display.append("[");
            display.append(int_filter_[i]).append(",");
            if (int_hit_[i]) {
                display.append("hit,");
            } else {
                display.append("miss,");
            }
            for (auto &filter_int: int_filter_dict_[i]) {
                display.append(std::to_string(filter_int)).append(",");
                ;
            }
            display.pop_back();
            display.append("]");
        }
        display.append("], eventtime_key:").append(eventtime_key_);
        display.append(", start_ms:").append(std::to_string(start_));
        display.append(", end_ms:").append(std::to_string(end_));
        return display;
    }

    bool MessageFilterConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("MessageFilterConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *message_value = get_value(input_values, inputs_, 0);
        int64_t now = 0;
        if (input_values.size() > 1) {
            now = get_feature_one_int64(input_values, inputs_, 1);
        }

        const uint32_t batch_size = message_value->ifeatures.size();
        const InputFeature *inf_message = nullptr;
        const google::protobuf::Message *mess = nullptr;

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            inf_message = &message_value->ifeatures[i];
            std::vector<const google::protobuf::Message *> filter_vec;

            if (!eventtime_key_.empty()) {
                int64_t time = 0;
                for (uint32_t j = 0; j < inf_message->messages.size(); j++) {
                    mess = inf_message->messages[j];
                    MessageCompute::message_fill_to_int64(mess, eventtime_key_, output_, time);
                    //时间戳数据为13位
                    if ((now - time) > start_ && (end_ < 0 || (now - time) < end_)) {
                        filter_vec.emplace_back(mess);
                    }
                }
            } else {
                filter_vec = inf_message->messages;
            }

            // 过滤str条件
            for (uint32_t j = 0; j < str_filter_.size(); j++) {
                MessageCompute::message_filter_to_message<std::string>(output_, str_filter_[j], str_hit_[j],
                                                                       str_filter_dict_[j], filter_vec);
            }

            // 过滤int条件
            for (uint32_t j = 0; j < int_filter_.size(); j++) {
                MessageCompute::message_filter_to_message<int64_t>(output_, int_filter_[j], int_hit_[j],
                                                                   int_filter_dict_[j], filter_vec);
            }

            output.values[0].ifeatures[i].messages.swap(filter_vec);
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    MessageFilterV2Config::MessageFilterV2Config(const std::string &output, const std::vector<std::string> &source,
                                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                                 const std::vector<std::string> &strategy,
                                                 const std::string &str_filter, const std::string &int_filter,
                                                 const std::string &eventtime_key, int64_t start_ms, int64_t end_ms)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy),
          str_filter_(transform_str_filter(str_filter)), int_filter_(transform_int_filter(int_filter)),
          eventtime_key_(eventtime_key), start_(start_ms), end_(end_ms) {
    }

    std::string MessageFilterV2Config::get_config() {
        std::string display = "message_filter_v2:str_filter:[";
        for (const auto &it: str_filter_) {
            display.append("[");
            display.append(it.first.to_string()).append(",");
            if (it.second.first) {
                display.append("hit,");
            } else {
                display.append("miss,");
            }
            for (auto &filter: it.second.second) {
                display.append(filter.to_string()).append(",");
                ;
            }
            display.pop_back();
            display.append("]");
        }
        display.append("], int_filter:[");
        for (const auto &it: int_filter_) {
            display.append("[");
            display.append(it.first.to_string()).append(",");
            if (it.second.first) {
                display.append("hit,");
            } else {
                display.append("miss,");
            }
            for (auto &filter: it.second.second) {
                display.append(filter.to_string()).append(",");
                ;
            }
            display.pop_back();
            display.append("]");
        }
        display.append("], eventtime_key:").append(eventtime_key_);
        display.append(", start_ms:").append(std::to_string(start_));
        display.append(", end_ms:").append(std::to_string(end_));
        return display;
    }

    bool MessageFilterV2Config::compute(const std::vector<const Output *> &input_values, Output &output) {
        std::unordered_map<std::size_t, const Value *> input_value_map;
        input_value_map[0] = get_value(input_values, inputs_, 0);

        const Value *message_value = input_value_map[0];
        int64_t now = 0;
        if (input_values.size() > 1) {
            now = get_feature_one_int64(input_values, inputs_, 1);
        }

        const uint32_t batch_size = message_value->ifeatures.size();
        std::vector<InputFeature>::const_iterator inf_message;

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            inf_message = message_value->ifeatures.begin() + i;
            std::unordered_set<std::size_t> need_remove_index_set;// 记录执行完过滤逻辑之后需要删除的message的索引

            // 过滤时间戳
            if (!eventtime_key_.empty()) {
                int64_t time = 0;
                for (std::size_t j = 0; j < inf_message->messages.size(); j++) {
                    MessageCompute::message_fill_to_int64(inf_message->messages[j], eventtime_key_, output_, time);
                    //时间戳数据为13位
                    if ((now - time) <= start_ || (end_ >= 0 && (now - time) >= end_)) {
                        need_remove_index_set.emplace(j);
                    }
                }
            }

            // 过滤str条件
            for (const auto &it: str_filter_) {// 遍历每一条str过滤条件
                // 提取过滤条件
                std::unordered_set<std::string> str_filter_dict;
                for (const auto &dict: it.second.second) {
                    if (dict._index < 0) {// 如果过滤条件 index < 0, 说明条件是原始值
                        str_filter_dict.emplace(dict._value);
                    } else {
                        auto dict_iter = input_value_map.find(dict._index);
                        if (likely(dict_iter == input_value_map.end())) {
                            input_value_map[dict._index] = get_value(input_values, inputs_, dict._index);
                            dict_iter = input_value_map.find(dict._index);
                        }
                        for (const auto &dict_str: dict_iter->second->ifeatures[i].feature->bytes_list().value()) {
                            str_filter_dict.emplace(dict_str);
                        }
                    }
                }

                if (it.first._index < 0) {// 过滤字段 index < 0, 说明字段是原始值
                    MessageCompute::message_filter_to_message<std::string>(output_, it.first._value, it.second.first,
                                                                           str_filter_dict, inf_message->messages,
                                                                           need_remove_index_set);
                } else {
                    // 先从input_value_map中找，未找到再get_value
                    auto iter = input_value_map.find(it.first._index);
                    if (likely(iter == input_value_map.end())) {
                        input_value_map[it.first._index] = get_value(input_values, inputs_, it.first._index);
                        iter = input_value_map.find(it.first._index);
                    }

                    const auto &repeated_str = iter->second->ifeatures[i].feature->bytes_list().value();
                    if (static_cast<std::size_t>(repeated_str.size()) != inf_message->messages.size()) {
                        THROW_ERROR("${source[" + std::to_string(it.first._index) + "]} size not equal messages size");
                    }

                    for (int j = 0; j < repeated_str.size(); ++j) {
                        // 过滤条件中没有的索引, 添加进 need_remove_index_set
                        if (str_filter_dict.find(repeated_str[j]) == str_filter_dict.end()) {
                            need_remove_index_set.emplace(static_cast<std::size_t>(j));
                        }
                    }
                }
            }

            // 过滤int条件
            for (const auto &it: int_filter_) {// 遍历每一条int过滤条件
                // 提取过滤条件
                std::unordered_set<int64_t> int_filter_dict;
                for (const auto &dict: it.second.second) {
                    if (dict._index < 0) {// 如果过滤条件 index < 0, 说明条件是原始值
                        int_filter_dict.emplace(dict._value);
                    } else {
                        auto dict_iter = input_value_map.find(dict._index);
                        if (likely(dict_iter == input_value_map.end())) {
                            input_value_map[dict._index] = get_value(input_values, inputs_, dict._index);
                            dict_iter = input_value_map.find(dict._index);
                        }
                        for (const auto &dict_int: dict_iter->second->ifeatures[i].feature->int64_list().value()) {
                            int_filter_dict.emplace(dict_int);
                        }
                    }
                }

                if (it.first._index < 0) {// 过滤字段 index < 0, 说明字段是原始值
                    MessageCompute::message_filter_to_message<int64_t>(output_, it.first._value, it.second.first,
                                                                       int_filter_dict, inf_message->messages,
                                                                       need_remove_index_set);
                } else {
                    // 先从input_value_map中找，未找到再get_value
                    auto iter = input_value_map.find(it.first._index);
                    if (likely(iter == input_value_map.end())) {
                        input_value_map[it.first._index] = get_value(input_values, inputs_, it.first._index);
                        iter = input_value_map.find(it.first._index);
                    }

                    const auto &repeated_int = iter->second->ifeatures[i].feature->int64_list().value();
                    if (static_cast<std::size_t>(repeated_int.size()) != inf_message->messages.size()) {
                        THROW_ERROR("${source[" + std::to_string(it.first._index) + "]} size not equal messages size");
                    }

                    for (int j = 0; j < repeated_int.size(); ++j) {
                        // 过滤条件中没有的索引, 添加进 need_remove_index_set
                        if (int_filter_dict.find(repeated_int[j]) == int_filter_dict.end()) {
                            need_remove_index_set.emplace(static_cast<std::size_t>(j));
                        }
                    }
                }
            }

            for (std::size_t j = 0; j < inf_message->messages.size(); ++j) {
                if (need_remove_index_set.find(j) == need_remove_index_set.end())// 不在待删除集合里的，写入输出
                    output.values[0].ifeatures[i].messages.emplace_back(inf_message->messages[j]);
            }
        }
        return true;
    }

    std::map<MessageFilterV2Config::SourceIndex<std::string>,
             std::pair<bool, std::set<MessageFilterV2Config::SourceIndex<std::string>>>>
    MessageFilterV2Config::transform_str_filter(const std::string &filter_str) {
        std::map<SourceIndex<std::string>, std::pair<bool, std::set<SourceIndex<std::string>>>> result;

        if (filter_str.empty())
            return result;

        std::size_t index = 0;
        for (const auto &filter: Calc::split_string(filter_str, ";")) {
            auto condition = Calc::split_string(filter, ",");
            if (condition.size() < 2)
                THROW_ERROR("filter cond invalid, split num < 2:[" + filter + "]");
            SourceIndex<std::string> key;
            std::pair<bool, std::set<SourceIndex<std::string>>> value;
            if (GetSourceIndex(condition[0], index)) {
                key._index = index;
            } else {
                key._value = std::move(condition[0]);
            }

            if (condition[1] == "hit")
                value.first = true;
            else if (condition[1] == "miss")
                value.first = false;
            else
                THROW_ERROR("unknown filter type, should be hit or miss");

            for (std::size_t i = 2; i < condition.size(); ++i) {
                SourceIndex<std::string> source_index;
                if (GetSourceIndex(condition[i], index)) {
                    source_index._index = index;
                } else {
                    source_index._value = std::move(condition[i]);
                }
                value.second.emplace(source_index);
            }
            result[key] = value;
        }
        return result;
    }

    std::map<MessageFilterV2Config::SourceIndex<std::string>,
             std::pair<bool, std::set<MessageFilterV2Config::SourceIndex<int64_t>>>>
    MessageFilterV2Config::transform_int_filter(const std::string &filter_str) {
        std::map<SourceIndex<std::string>, std::pair<bool, std::set<SourceIndex<int64_t>>>> result;

        if (filter_str.empty())
            return result;

        std::size_t index = 0;
        for (const auto &filter: Calc::split_string(filter_str, ";")) {
            auto condition = Calc::split_string(filter, ",");
            if (condition.size() < 2)
                THROW_ERROR("filter cond invalid, split num < 2:[" + filter + "]");
            SourceIndex<std::string> key;
            std::pair<bool, std::set<SourceIndex<int64_t>>> value;
            if (GetSourceIndex(condition[0], index)) {
                key._index = index;
            } else {
                key._value = std::move(condition[0]);
            }

            if (condition[1] == "hit")
                value.first = true;
            else if (condition[1] == "miss")
                value.first = false;
            else
                THROW_ERROR("unknown filter type, should be hit or miss");

            for (std::size_t i = 2; i < condition.size(); ++i) {
                SourceIndex<int64_t> source_index;
                if (GetSourceIndex(condition[i], index)) {
                    source_index._index = index;
                } else {
                    source_index._value = std::stol(condition[i]);
                }
                value.second.emplace(source_index);
            }
            result[key] = value;
        }

        return result;
    }

    bool GetValidValueConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("GetValidValueConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *input1_value = get_value(input_values, inputs_, 0);
        const Value *input2_value = get_value(input_values, inputs_, 1);

        uint32_t input1_size = input1_value->ifeatures.size();
        uint32_t input2_size = input2_value->ifeatures.size();
        // 不支持user数据和item数据之间，进行有效值代替读取
        if (input1_size != input2_size) {
            THROW_ERROR("invalid source, input1_value_size not euqal input2_value_size, name:" + output_);
            return false;
        }

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_INT64;
        value.ifeatures.resize(input1_size);
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;

        const InputFeature *inf_value1 = nullptr;
        const InputFeature *inf_value2 = nullptr;

        for (uint32_t i = 0; i < input1_size; i++) {
            inf_value1 = &input1_value->ifeatures[i];
            inf_value2 = &input2_value->ifeatures[i];

            if (likely(inf_value1->feature_list && inf_value2->feature_list)) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;
                uint32_t value1_list_size = inf_value1->feature_list->feature_size();
                uint32_t value2_list_size = inf_value2->feature_list->feature_size();
                uint32_t min_list_size = std::min(value1_list_size, value2_list_size);

                if (likely(min_list_size) > 0) {
                    // list不为空，取最少feature_size个数的数据
                    for (uint32_t j = 0; j < min_list_size; j++) {
                        compute_one_feature(&inf_value1->feature_list->feature(j),
                                            &inf_value2->feature_list->feature(j), out_featurelist->add_feature());
                    }
                    // list2不为空，取input2数据
                } else if (value2_list_size != 0) {
                    for (uint32_t j = 0; j < value2_list_size; j++) {
                        compute_one_feature(&inf_value2->feature_list->feature(j),
                                            &inf_value2->feature_list->feature(j), out_featurelist->add_feature());
                    }
                } else {
                    // list2为空，返回-1
                    out_featurelist->add_feature()->mutable_int64_list()->add_value(-1);
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (likely(inf_value1->feature && inf_value2->feature)) {
                    compute_one_feature(inf_value1->feature, inf_value2->feature, out_feature);
                    //feature_list和feature同时为空，返回-1
                } else {
                    out_feature->mutable_int64_list()->add_value(-1);
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void GetValidValueConfig::compute_one_feature(const tensorflow::Feature *input_feat1,
                                                  const tensorflow::Feature *input_feat2, tensorflow::Feature *out) {

        tensorflow::Feature::KindCase kind_case = tensorflow::Feature::KindCase::KIND_NOT_SET;
        if (input_feat1->kind_case() != tensorflow::Feature::KindCase::KIND_NOT_SET) {
            kind_case = input_feat1->kind_case();
        } else {
            kind_case = input_feat2->kind_case();
        }

        switch (kind_case) {
            case tensorflow::Feature::KindCase::kInt64List: {
                const auto &value1_vec = input_feat1->int64_list().value();
                const auto &value2_vec = input_feat2->int64_list().value();

                const int value1_size = value1_vec.size();
                const int value2_size = value2_vec.size();
                const int max_size = std::max(value1_size, value2_size);

                auto valid_value = [&](int i) -> int64_t {
                    switch (_config) {
                        case 1:
                            return (i < value1_size && value1_vec[i] != _config_int64_value)
                                           ? value1_vec[i]
                                           : ((i < value2_size && value2_vec[i] != _config_int64_value)
                                                      ? value2_vec[i]
                                                      : _default_int64_value);
                        case 2:
                            return (i < value1_size && value1_vec[i] < _config_int64_value)
                                           ? value1_vec[i]
                                           : ((i < value2_size && value2_vec[i] < _config_int64_value)
                                                      ? value2_vec[i]
                                                      : _default_int64_value);
                        case 3:
                        default:
                            return (i < value1_size && value1_vec[i] > _config_int64_value)
                                           ? value1_vec[i]
                                           : ((i < value2_size && value2_vec[i] > _config_int64_value)
                                                      ? value2_vec[i]
                                                      : _default_int64_value);
                    };
                };

                for (int i = 0; i < max_size; ++i) {
                    out->mutable_int64_list()->add_value(valid_value(i));
                }

                break;
            }
            case tensorflow::Feature::KindCase::kFloatList: {
                const auto &value1_vec = input_feat1->float_list().value();
                const auto &value2_vec = input_feat2->float_list().value();

                const int value1_size = value1_vec.size();
                const int value2_size = value2_vec.size();
                const int max_size = std::max(value1_size, value2_size);

                auto valid_value = [&](int i) -> float {
                    switch (_config) {
                        case 1:
                            return (i < value1_size && (value1_vec[i] < _config_float_value - _precision ||
                                                        value1_vec[i] > _config_float_value + _precision))
                                           ? value1_vec[i]
                                           : ((i < value2_size && (value2_vec[i] < _config_float_value - _precision ||
                                                                   value2_vec[i] > _config_float_value + _precision))
                                                      ? value2_vec[i]
                                                      : _default_float_value);
                        case 2:
                            return (i < value1_size && value1_vec[i] < _config_float_value)
                                           ? value1_vec[i]
                                           : ((i < value2_size && value2_vec[i] < _config_float_value)
                                                      ? value2_vec[i]
                                                      : _default_float_value);
                        case 3:
                        default:
                            return (i < value1_size && value1_vec[i] > _config_float_value)
                                           ? value1_vec[i]
                                           : ((i < value2_size && value2_vec[i] > _config_float_value)
                                                      ? value2_vec[i]
                                                      : _default_float_value);
                    };
                };

                for (int i = 0; i < max_size; ++i) {
                    out->mutable_float_list()->add_value(valid_value(i));
                }
                break;
            }
            default:
                break;
        }
    }

    bool GetValidValueV2Config::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("GetValidValueV2Config::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *input1_value = get_value(input_values, inputs_, 0);
        const Value *input2_value = get_value(input_values, inputs_, 1);

        uint32_t input1_size = input1_value->ifeatures.size();
        uint32_t input2_size = input2_value->ifeatures.size();
        // 不支持user数据和item数据之间，进行有效值代替读取
        if (input1_size != input2_size) {
            THROW_ERROR("invalid source, input1_value_size not euqal input2_value_size, name:" + output_);
            return false;
        }

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(input1_size);
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;

        const InputFeature *inf_value1 = nullptr;
        const InputFeature *inf_value2 = nullptr;

        for (uint32_t i = 0; i < input1_size; i++) {
            inf_value1 = &input1_value->ifeatures[i];
            inf_value2 = &input2_value->ifeatures[i];

            if (likely(inf_value1->feature_list && inf_value2->feature_list)) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;
                uint32_t value1_list_size = inf_value1->feature_list->feature_size();
                uint32_t value2_list_size = inf_value2->feature_list->feature_size();
                uint32_t min_list_size = std::min(value1_list_size, value2_list_size);

                if (likely(min_list_size) > 0) {
                    // list1不为空，取list1个数的数据
                    for (uint32_t j = 0; j < min_list_size; j++) {
                        compute_one_feature(&inf_value1->feature_list->feature(j),
                                            &inf_value2->feature_list->feature(j), out_featurelist->add_feature());
                    }
                    for (uint32_t j = min_list_size; j < value1_list_size; j++) {
                        compute_one_feature(&inf_value1->feature_list->feature(j), nullptr,
                                            out_featurelist->add_feature());
                    }
                    // list2不为空，取list2数据
                } else if (value2_list_size != 0) {
                    for (uint32_t j = 0; j < value2_list_size; j++) {
                        compute_one_feature(nullptr, &inf_value2->feature_list->feature(j),
                                            out_featurelist->add_feature());
                    }
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (likely(inf_value1->feature)) {
                    compute_one_feature(inf_value1->feature, inf_value2->feature, out_feature);
                } else if (inf_value2->feature) {
                    compute_one_feature(nullptr, inf_value2->feature, out_feature);
                }
            }
        }

        value.defalut_type = data_type_;

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void GetValidValueV2Config::compute_one_feature(const tensorflow::Feature *input_feat1,
                                                    const tensorflow::Feature *input_feat2, tensorflow::Feature *out) {
        if (input_feat1) {
            switch (input_feat1->kind_case()) {
                case tensorflow::Feature::kBytesList: {
                    data_type_ = tensorflow::DT_STRING;
                    auto &value1_vec = input_feat1->bytes_list().value();
                    for (int32_t i = 0; i < value1_vec.size(); i++) {
                        if (value1_vec[i] != invalid_) {
                            out->mutable_bytes_list()->add_value(value1_vec[i]);
                        } else if (input_feat2 && i < input_feat2->bytes_list().value_size()) {
                            out->mutable_bytes_list()->add_value(input_feat2->bytes_list().value(i));
                        }
                    }
                    break;
                }
                case tensorflow::Feature::kFloatList: {
                    float float_value = 0;
                    //转换失败抛出异常
                    if (unlikely(!Calc::convert_float(invalid_, float_value))) {
                        THROW_ERROR("trans float failed, invalid:" + invalid_ + ", name:" + output_);
                    }
                    data_type_ = tensorflow::DT_FLOAT;
                    auto &value1_vec = input_feat1->float_list().value();
                    for (int32_t i = 0; i < value1_vec.size(); i++) {
                        if (value1_vec[i] != float_value) {
                            out->mutable_float_list()->add_value(value1_vec[i]);
                        } else if (input_feat2 && i < input_feat2->float_list().value_size()) {
                            out->mutable_float_list()->add_value(input_feat2->float_list().value(i));
                        }
                    }
                    break;
                }
                case tensorflow::Feature::kInt64List: {
                    int64_t int64_value = 0;
                    //转换失败抛出异常
                    if (unlikely(!Calc::convert_int64(invalid_, int64_value))) {
                        THROW_ERROR("trans int64_t failed, invalid:" + invalid_ + ", name:" + output_);
                    }
                    data_type_ = tensorflow::DT_INT64;
                    auto &value1_vec = input_feat1->int64_list().value();
                    for (int32_t i = 0; i < value1_vec.size(); i++) {
                        if (value1_vec[i] != int64_value) {
                            out->mutable_int64_list()->add_value(value1_vec[i]);
                        } else if (input_feat2 && i < input_feat2->int64_list().value_size()) {
                            out->mutable_int64_list()->add_value(input_feat2->int64_list().value(i));
                        }
                    }
                    break;
                }
                default: {
                    compute_valid_feature(input_feat2, out);
                    break;
                }
            }
        } else {
            compute_valid_feature(input_feat2, out);
        }
    }

    void GetValidValueV2Config::compute_valid_feature(const tensorflow::Feature *input_feat, tensorflow::Feature *out) {
        if (input_feat) {
            switch (input_feat->kind_case()) {
                case tensorflow::Feature::kBytesList: {
                    data_type_ = tensorflow::DT_STRING;
                    for (const std::string &str: input_feat->bytes_list().value()) {
                        out->mutable_bytes_list()->add_value(str);
                    }
                    break;
                }
                case tensorflow::Feature::kFloatList: {
                    data_type_ = tensorflow::DT_FLOAT;
                    for (const float f: input_feat->float_list().value()) {
                        out->mutable_float_list()->add_value(f);
                    }
                    break;
                }
                case tensorflow::Feature::kInt64List: {
                    data_type_ = tensorflow::DT_INT64;
                    for (const int64_t value: input_feat->int64_list().value()) {
                        out->mutable_int64_list()->add_value(value);
                    }
                    break;
                }
                default: {
                    break;
                }
            }
        }
    }

}// namespace phx_fe
