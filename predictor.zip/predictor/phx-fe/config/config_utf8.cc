#include "config_utf8.h"
#include "phx-fe/util/calc.h"
#include "phx-fe/util/timer.h"
#include <algorithm>
#include <cstdlib>

void Utf8JoinConfig::compute_one_feature(const tensorflow::Feature& input_feat1,
                                          const tensorflow::Feature& input_feat2,
                                          tensorflow::Feature* out) {
  auto& input_vec1 = input_feat1.int64_list().value();
  auto& input_vec2 = input_feat2.int64_list().value();
  const uint32_t list_size = std::min(input_vec1.size(), input_vec2.size());

  for (uint32_t i = 0; i < list_size; i++) {
    out->mutable_bytes_list()->add_value(std::to_string(input_vec1[i]) + delimiter_ + std::to_string(input_vec2[i]));
  }
}

void Utf8PrefixRepetitionStringConfig::compute_one_feature(const tensorflow::Feature& input_feat1,
                                                        const tensorflow::Feature& input_feat2,
                                                        tensorflow::Feature* out) {
  auto& input_vec1 = input_feat1.bytes_list().value();
  auto& input_vec2 = input_feat2.bytes_list().value();
  const uint32_t list_size = std::min(input_vec1.size(), input_vec2.size());

  for (uint32_t i = 0; i < list_size; i++) {
    out->mutable_float_list()->add_value(get_prefix_repetition(input_vec1[i], input_vec2[i]));
  }
}

float Utf8PrefixRepetitionStringConfig::get_prefix_repetition(const std::string& word1, const std::string& word2) {
  if (word1.empty() || word2.empty()) return 0.0;
  const char* s_1 = word1.c_str();
  const char* end_1 = s_1 + word1.length();
  const char* s_2 = word2.c_str();
  const char* end_2 = s_2 + word2.length();
  const int32_t len_1 = Utf8BaseCompute::length(s_1, word1.length());
  const int32_t len_2 = Utf8BaseCompute::length(s_2, word2.length());
  int32_t max_len = len_1 > len_2 ? len_1 : len_2;
  int32_t prefix_len = 0;

  while (s_1 < end_1 && s_2 < end_2) {
    if (!Utf8BaseCompute::is_equal(s_1, s_2)) {
      break;
    }

    prefix_len++;
    s_1 = Utf8BaseCompute::get_next_word(s_1);
    s_2 = Utf8BaseCompute::get_next_word(s_2);
  }

  return static_cast<float>(prefix_len) / max_len;
}

void Utf8LengthConfig::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (const std::string& input_str : feat.bytes_list().value()) {
    out->mutable_int64_list()->add_value(Utf8BaseCompute::length(input_str.c_str(), input_str.length()));
  }
}

void Utf8PreprocessConfig::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (const std::string& input_str : feat.bytes_list().value()) {
    out->mutable_bytes_list()->add_value(format(input_str));
  }
}

std::string Utf8PreprocessConfig::format(const std::string& word) {
  std::string ret;
  ret.reserve(word.length());

  int32_t w;
  const char* p = word.c_str();

  for (uint32_t i = 0; i < word.length(); ) {
    //w为单字节判断的utf8长度
    w = Utf8BaseCompute::byte_width(p[i]);

    switch (w) {
      case 1: {
        if (std::isupper(p[i])) { //大写字母转小写
          ret.push_back(std::tolower(p[i]));
        } else if (std::ispunct(p[i]) || ' ' == p[i] //标点符号，或' '或'\t'或'\n'，直接跳过
                  || '\t' == p[i] || '\n' == p[i]) {
        } else {
          ret.push_back(p[i]);
        }
        i++;
      }
      break;

      //判断是不是字节3的中文符号，不是就尾加
      case 3: {
        if (Utf8BaseCompute::is_cn3_punct(p + i) <= 0) {
          ret.append(p + i, 3);
        }
        i += 3;
      }
      break;

      //判断是不是字节2的中文符号，不是就尾加
      case 2: {
        if (Utf8BaseCompute::is_cn2_punct(p + i) <= 0) {
          ret.append(p + i, 2);
        }
        i += 2;
      }
      break;

      case 4: {
        ret.append(p + i, 4);
        i += 4;
      }
      break;

      default: {
        ret.push_back(p[i]);
        i++;
      }
      break;
    }
  }

  return std::move(ret);
}

bool Utf8SplitConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("Utf8SplitConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);
  uint32_t batch_size = input_value->ifeatures.size();

  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_STRING;
  value.ifeatures.resize(batch_size);

  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;
  const InputFeature* inf = nullptr;

  //输出
  for (uint32_t i = 0; i < batch_size; i++) {
    inf = &input_value->ifeatures[i];

    if (likely(inf->feature_list)) {
      out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_featurelist;

      for (auto& feat : inf->feature_list->feature()) {
        compute_one_feature(feat, out_featurelist->add_feature());
      }
    } else {
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;

      if (likely(inf->feature)) {
        compute_one_feature(*inf->feature, out_feature);
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void Utf8SplitConfig::compute_one_feature(const tensorflow::Feature& input_feat,
                                          tensorflow::Feature* out) {
  auto& input_vec = input_feat.bytes_list().value();
  const uint32_t list_size = input_vec.size();
  if (list_size > 0) {
    std::vector<std::string> ret;

    //第一个string
    Utf8BaseCompute::split_to_vec(input_vec[0], split_width_, ret);
    for (uint32_t i = 0; i < ret.size(); i++) {
      out->mutable_bytes_list()->add_value(std::move(ret[i]));
    }
  }
}

bool Utf8SplitToListConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("Utf8SplitToListConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);
  uint32_t batch_size = input_value->ifeatures.size();

  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_STRING;
  value.ifeatures.resize(batch_size);

  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;
  const InputFeature* inf = nullptr;

  //输出
  for (uint32_t i = 0; i < batch_size; i++) {
    inf = &input_value->ifeatures[i];

    if (likely(inf->feature)) {
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;
      compute_one_feature(*inf->feature, out_feature);
    } else {
      out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_featurelist;
      if (likely(inf->feature_list)) {
        for (auto& feat : inf->feature_list->feature()) {
          compute_one_feature(feat, out_featurelist->add_feature());
        }
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}
void Utf8SplitToListConfig::compute_one_feature(const tensorflow::Feature& input_feat, tensorflow::Feature* out) {
  auto& input_vec = input_feat.bytes_list().value();
  const uint32_t list_size = input_vec.size();
  if (list_size > 0) {
    //第一个string转小写
    std::string lower_str = Calc::to_lower(input_vec[0]);
    std::vector<std::string> ret = Calc::split_string(lower_str, sep_);
    for (uint32_t i = 0; i < ret.size(); i++) {
      auto iter = filters_.find(ret[i]);
      if (iter == filters_.end()) {
        out->mutable_bytes_list()->add_value(std::move(ret[i]));
      }
    }
  }
}

bool Utf8IpToListConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("Utf8IpToListConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  const Value* input_value = get_value(input_values, inputs_, 0);
  uint32_t batch_size = input_value->ifeatures.size();

  output.values.resize(1);
  Value& value = output.values[0];
  value.defalut_type = tensorflow::DT_STRING;
  value.ifeatures.resize(batch_size);

  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;
  const InputFeature* inf = nullptr;

  //输出
  for (uint32_t i = 0; i < batch_size; i++) {
    inf = &input_value->ifeatures[i];

    if (likely(inf->feature)) {
      out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
      value.ifeatures[i].feature = out_feature;
      compute_one_feature(*inf->feature, out_feature);
    } else {
      out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
      value.ifeatures[i].feature_list = out_featurelist;
      if (likely(inf->feature_list)) {
        for (auto& feat : inf->feature_list->feature()) {
          compute_one_feature(feat, out_featurelist->add_feature());
        }
      }
    }
  }

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}

void Utf8IpToListConfig::compute_one_feature(const tensorflow::Feature& input_feat, tensorflow::Feature* out) {
  auto& input_vec = input_feat.bytes_list().value();
  const uint32_t list_size = input_vec.size();
  if (list_size > 0) {
    const auto& source = input_vec[0];
    size_t first_pos = source.find_first_of(sep_);
    //没有分割符，直接填充整个字符串
    if (first_pos == std::string::npos) {
      out->mutable_bytes_list()->add_value(source);
      return;
    }
    size_t next_pos= first_pos;
    while(next_pos != std::string::npos) {
      next_pos = source.find_first_of(sep_, next_pos + 1);
      out->mutable_bytes_list()->add_value(source.substr(0, next_pos));
    }
  }
}

void Utf8FilterConfig::compute_one_feature(const tensorflow::Feature& feat, tensorflow::Feature* out) {
  for (const std::string& input_str : feat.bytes_list().value()) {
    if (Utf8BaseCompute::length(input_str.c_str(), input_str.length()) != length_) {
      out->mutable_bytes_list()->add_value(input_str);
    }
  }
}

void Utf8RepetitionStringConfig::compute_one_feature(const tensorflow::Feature& input_feat1,
                                                     const tensorflow::Feature& input_feat2,
                                                     tensorflow::Feature* out) {
  auto& input_vec1 = input_feat1.bytes_list().value();
  auto& input_vec2 = input_feat2.bytes_list().value();
  const uint32_t list_size = std::min(input_vec1.size(), input_vec2.size());

  for (uint32_t i = 0; i < list_size; i++) {
    float value = 0;
    if (!input_vec1[i].empty() && !input_vec2[i].empty()) {
      std::map<std::string, std::pair<int64_t, int64_t>> pair_map;
      Utf8BaseCompute::split_to_pair_map(input_vec1[i], 1, true, pair_map);
      Utf8BaseCompute::split_to_pair_map(input_vec2[i], 1, false, pair_map);
      Utf8BaseCompute::cosine_similarity(pair_map, value);
    }
    out->mutable_float_list()->add_value(value);
  }
}