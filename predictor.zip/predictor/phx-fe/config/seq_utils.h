#pragma once
#include "tf/feature.pb.h"
#include "tf/types.pb.h"
#include <cstdint>
#include <google/protobuf/message.h>
#include <string>
#include <unordered_map>
#include <vector>

namespace phx_fe {
    // 东八区，先加8小时，再除一天的时间
    inline int64_t timestamp_to_cast_days(int64_t time) {
        return (time + 28800000) / 86400000;
    }
    // 排序方式
    enum SortType {
        ByTimestamp = 1,//ByTimestamp按时间戳的大小排序
        ByCount = 2,    //ByCount按次数排序，次数相同按最新时间戳的大小排序
        ByValue = 3     //ByValue按次数排序，次数相同按最新时间戳的大小排序
    };

    // 自定义哈希函数，基于指针指向的字符串内容
    struct StringPtrHash {
        std::size_t operator()(const std::string *s) const {
            return std::hash<std::string>()(*s);
        }
    };

    // 自定义相等比较函数，比较指针指向的字符串内容
    struct StringPtrEqual {
        bool operator()(const std::string *lhs, const std::string *rhs) const {
            return *lhs == *rhs;
        }
    };
    using StringPtrCountMap = std::unordered_map<const std::string *, int64_t, StringPtrHash, StringPtrEqual>;
    class AppIdWithEventTime {
    public:
        AppIdWithEventTime() : appid(0), eventtime(0) {
        }
        AppIdWithEventTime(int64_t app_id, int64_t time) : appid(app_id), eventtime(time) {
        }
        int64_t appid;
        int64_t eventtime;
    };

    struct ClassNameWithEventTime {
        ClassNameWithEventTime() : class_name(nullptr), event_time(0) {
        }
        ClassNameWithEventTime(const std::string *class_name_ptr, int64_t time)
            : class_name(class_name_ptr), event_time(time) {
        }
        const std::string *class_name;
        int64_t event_time;
    };

    // 用于TopN计算
    class SeqTopNCompute {
    public:
        explicit SeqTopNCompute(SortType type, int64_t topn, int64_t reserve = 0)
            : type_(type), topn_(topn), reserve_(reserve) {
        }
        virtual ~SeqTopNCompute() {
        }

        void compute_vec(std::vector<ClassNameWithEventTime> &class_info_vec,
                         std::vector<ClassNameWithEventTime *> *sorted_class_info_vec_ptr) {

            size_t size = class_info_vec.size();
            if (size == 0) {
                return;
            }
            sorted_class_info_vec_ptr->reserve(size);
            if (type_ == SortType::ByCount) {
                StringPtrCountMap class_count{};
                class_count.reserve(size);
                for (const auto &class_info: class_info_vec) {
                    class_count[class_info.class_name]++;
                }
                std::sort(class_info_vec.begin(), class_info_vec.end(),
                          [this, &class_count](const ClassNameWithEventTime &a, const ClassNameWithEventTime &b) {
                              return compareClassNameWithEventTimeByCount(a, b, class_count, reserve_);
                          });
                std::unordered_set<const std::string *, StringPtrHash, StringPtrEqual> class_name_set{};
                class_name_set.reserve(size);
                for (size_t i = 0; i < size; ++i) {
                    if (class_name_set.insert(class_info_vec[i].class_name).second) {
                        sorted_class_info_vec_ptr->emplace_back(&class_info_vec[i]);
                    }
                }
            } else {
                //默认按时间戳大小排序
                std::sort(class_info_vec.begin(), class_info_vec.end(),
                          [this](const ClassNameWithEventTime &a, const ClassNameWithEventTime &b) {
                              return compareClassNameWithEventTime(a, b, reserve_);
                          });
                for (size_t i = 0; i < size; i++) {
                    sorted_class_info_vec_ptr->emplace_back(&class_info_vec[i]);
                }
            }
            //截断
            if (topn_ > 0 && (int64_t) class_info_vec.size() > topn_) {
                sorted_class_info_vec_ptr->resize(topn_);
            }
        }

        void compute_vec(std::vector<AppIdWithEventTime> &appid_info_vec,
                         std::vector<AppIdWithEventTime *> &appid_info_vec_ptr) {
            uint32_t size = appid_info_vec.size();
            if (size == 0) {
                return;
            }
            appid_info_vec_ptr.reserve(size);

            //ByCount按次数排序，次数相同按最新时间戳的大小排序
            if (type_ == SortType::ByCount) {
                // std::unordered_map<std::string, AppIdWithEventTime*> appid_value;
                std::unordered_map<int64_t, int64_t> appid_count;
                appid_count.reserve(size);
                // appid_value.reserve(size);

                for (uint32_t i = 0; i < size; ++i) {
                    appid_count[appid_info_vec[i].appid]++;
                    // auto& ptr = appid_value[*appid_info_vec[i].appid];
                    // if (ptr == nullptr || ptr->eventtime < appid_info_vec[i].eventtime) {
                    //   ptr = &appid_info_vec[i];
                    // }
                }

                // 保持原有顺序
                // for (uint32_t i = 0; i < size; ++i) {
                //   if (&appid_info_vec[i] == appid_value[*appid_info_vec[i].appid]) {
                //     appid_info_vec_ptr.emplace_back(&appid_info_vec[i]);
                //   }
                // }

                // std::sort(appid_info_vec_ptr.begin(), appid_info_vec_ptr.end(), [this, &appid_count](const AppIdWithEventTime* a, const AppIdWithEventTime* b) {
                //   return compareAppIdWithEventTimeByCount<int64_t>(*a, *b, appid_count, reserve_);
                // });

                std::sort(appid_info_vec.begin(), appid_info_vec.end(),
                          [this, &appid_count](const AppIdWithEventTime &a, const AppIdWithEventTime &b) {
                              return compareAppIdWithEventTimeByCount<int64_t>(a, b, appid_count, reserve_);
                          });

                std::unordered_set<int64_t> app_id_set;
                app_id_set.reserve(size);
                for (uint32_t i = 0; i < size; ++i) {
                    if (app_id_set.insert(appid_info_vec[i].appid).second) {
                        appid_info_vec_ptr.emplace_back(&appid_info_vec[i]);
                    }
                }
            } else {
                //默认按时间戳大小排序
                std::sort(appid_info_vec.begin(), appid_info_vec.end(),
                          [this](const AppIdWithEventTime &a, const AppIdWithEventTime &b) {
                              return compareAppIdWithEventTime(a, b, reserve_);
                          });

                for (uint32_t i = 0; i < size; ++i) {
                    appid_info_vec_ptr.emplace_back(&appid_info_vec[i]);
                }
            }

            //截断
            if (topn_ > 0 && (int64_t) appid_info_vec_ptr.size() > topn_) {
                appid_info_vec_ptr.resize(topn_);
            }
        }

        template<typename T>
        void compute_vec_with_value(std::vector<AppIdWithEventTime> &appid_info_vec,
                                    std::unordered_map<AppIdWithEventTime *, T> &appid_values,
                                    std::vector<std::pair<int64_t, T>> &out_vec) {
            uint32_t size = appid_info_vec.size();
            if (size == 0) {
                return;
            }
            out_vec.reserve(size);

            //ByCount按次数排序，次数相同按最新时间戳的大小排序
            if (type_ == SortType::ByCount) {
                // std::unordered_map<std::string, AppIdWithEventTime*> appid_value;
                std::unordered_map<int64_t, int64_t> appid_count;
                appid_count.reserve(size);
                // appid_value.reserve(size);

                for (uint32_t i = 0; i < size; ++i) {
                    appid_count[appid_info_vec[i].appid]++;
                    // auto& ptr = appid_value[*appid_info_vec[i].appid];
                    // if (ptr == nullptr || ptr->eventtime < appid_info_vec[i].eventtime) {
                    //   ptr = &appid_info_vec[i];
                    // }
                }

                // std::vector<AppIdWithEventTime*> appid_info_vec_ptr;
                // appid_info_vec_ptr.reserve(appid_value.size());
                // // 保持原有顺序
                // for (uint32_t i = 0; i < size; ++i) {
                //   if (&appid_info_vec[i] == appid_value[*appid_info_vec[i].appid]) {
                //     appid_info_vec_ptr.emplace_back(&appid_info_vec[i]);
                //   }
                // }

                // std::sort(appid_info_vec_ptr.begin(), appid_info_vec_ptr.end(), [this, &appid_count](const AppIdWithEventTime* a, const AppIdWithEventTime* b) {
                //   return compareAppIdWithEventTimeByCount<int64_t>(*a, *b, appid_count, reserve_);
                // });

                // for (uint32_t i = 0; i < appid_info_vec_ptr.size(); ++i) {
                //   out_vec.emplace_back(appid_info_vec_ptr[i]->appid, static_cast<T>(appid_count[*appid_info_vec_ptr[i]->appid]));
                // }

                std::sort(appid_info_vec.begin(), appid_info_vec.end(),
                          [this, &appid_count](const AppIdWithEventTime &a, const AppIdWithEventTime &b) {
                              return compareAppIdWithEventTimeByCount<int64_t>(a, b, appid_count, reserve_);
                          });

                std::unordered_set<int64_t> app_id_set;
                app_id_set.reserve(size);
                for (uint32_t i = 0; i < size; ++i) {
                    if (app_id_set.insert(appid_info_vec[i].appid).second) {
                        out_vec.emplace_back(appid_info_vec[i].appid,
                                             static_cast<T>(appid_count[appid_info_vec[i].appid]));
                    }
                }
                //ByValue按对应的值的聚合排序，次数相同按最新时间戳的大小排序
            } else if (type_ == SortType::ByValue) {
                // std::unordered_map<std::string, AppIdWithEventTime*> appid_value;
                std::unordered_map<int64_t, T> appid_map;
                appid_map.reserve(size);
                // appid_value.reserve(size);

                for (uint32_t i = 0; i < size; ++i) {
                    appid_map[appid_info_vec[i].appid] += appid_values[&appid_info_vec[i]];
                    // auto& ptr = appid_value[*appid_info_vec[i].appid];
                    // if (ptr == nullptr || ptr->eventtime < appid_info_vec[i].eventtime) {
                    //   ptr = &appid_info_vec[i];
                    // }
                }

                // std::vector<AppIdWithEventTime*> appid_info_vec_ptr;
                // appid_info_vec_ptr.reserve(appid_value.size());
                // // 保持原有顺序
                // for (uint32_t i = 0; i < size; ++i) {
                //   if (&appid_info_vec[i] == appid_value[*appid_info_vec[i].appid]) {
                //     appid_info_vec_ptr.emplace_back(&appid_info_vec[i]);
                //   }
                // }

                // std::sort(appid_info_vec_ptr.begin(), appid_info_vec_ptr.end(), [this, &appid_map](const AppIdWithEventTime* a, const AppIdWithEventTime* b) {
                //   return compareAppIdWithEventTimeByCount<T>(*a, *b, appid_map, reserve_);
                // });

                // for (uint32_t i = 0; i < appid_info_vec_ptr.size(); ++i) {
                //   out_vec.emplace_back(appid_info_vec_ptr[i]->appid, static_cast<T>(appid_map[*appid_info_vec_ptr[i]->appid]));
                // }

                std::sort(appid_info_vec.begin(), appid_info_vec.end(),
                          [this, &appid_map](const AppIdWithEventTime &a, const AppIdWithEventTime &b) {
                              return compareAppIdWithEventTimeByCount<T>(a, b, appid_map, reserve_);
                          });

                std::unordered_set<int64_t> app_id_set;
                app_id_set.reserve(size);
                for (uint32_t i = 0; i < size; ++i) {
                    if (app_id_set.insert(appid_info_vec[i].appid).second) {
                        out_vec.emplace_back(appid_info_vec[i].appid,
                                             static_cast<T>(appid_map[appid_info_vec[i].appid]));
                    }
                }
            } else {
                //默认按时间戳大小排序
                std::sort(appid_info_vec.begin(), appid_info_vec.end(),
                          [this](const AppIdWithEventTime &a, const AppIdWithEventTime &b) {
                              return compareAppIdWithEventTime(a, b, reserve_);
                          });

                for (uint32_t i = 0; i < size; ++i) {
                    out_vec.emplace_back(appid_info_vec[i].appid, static_cast<T>(appid_info_vec[i].eventtime));
                }
            }

            //截断,取消尾部相同值获取
            if (topn_ > 0 && (int64_t) out_vec.size() > topn_) {
                out_vec.resize(topn_);
            }

            // int64_t truly_size = topn_;
            // //截断至给定大小，如果尾部有相同值，截断至相同值的最后一个
            // while (truly_size > 0 && (int64_t) out_vec.size() > truly_size) {
            //     if (out_vec[truly_size - 1].second != out_vec[truly_size].second) {
            //         out_vec.resize(truly_size);
            //         break;
            //     }
            //     truly_size++;
            // }
        }

        void compute_ptr_vec(std::vector<AppIdWithEventTime *> &appid_info_vec,
                             std::vector<AppIdWithEventTime *> &appid_info_vec_ptr) {
            uint32_t size = appid_info_vec.size();
            if (size == 0) {
                return;
            }
            appid_info_vec_ptr.reserve(size);

            //ByCount按次数排序，次数相同按最新时间戳的大小排序
            if (type_ == SortType::ByCount) {
                // std::unordered_map<std::string, AppIdWithEventTime*> appid_value;
                std::unordered_map<int64_t, std::int64_t> appid_count;
                appid_count.reserve(size);
                // appid_value.reserve(size);

                for (uint32_t i = 0; i < size; ++i) {
                    appid_count[appid_info_vec[i]->appid]++;
                    // auto& ptr = appid_value[*appid_info_vec[i]->appid];
                    // if (ptr == nullptr || ptr->eventtime < appid_info_vec[i]->eventtime) {
                    //   ptr = appid_info_vec[i];
                    // }
                }

                // 保持原有顺序
                // for (uint32_t i = 0; i < size; ++i) {
                //   if (appid_info_vec[i] == appid_value[*appid_info_vec[i]->appid]) {
                //     appid_info_vec_ptr.emplace_back(appid_info_vec[i]);
                //   }
                // }

                // std::sort(appid_info_vec_ptr.begin(), appid_info_vec_ptr.end(), [this, &appid_count](const AppIdWithEventTime* a, const AppIdWithEventTime* b) {
                //   return compareAppIdWithEventTimeByCount(*a, *b, appid_count, reserve_);
                // });

                std::sort(appid_info_vec.begin(), appid_info_vec.end(),
                          [this, &appid_count](const AppIdWithEventTime *a, const AppIdWithEventTime *b) {
                              return compareAppIdWithEventTimeByCount(*a, *b, appid_count, reserve_);
                          });

                std::unordered_set<int64_t> app_id_set;
                app_id_set.reserve(size);
                for (uint32_t i = 0; i < size; ++i) {
                    if (app_id_set.insert(appid_info_vec[i]->appid).second) {
                        appid_info_vec_ptr.emplace_back(appid_info_vec[i]);
                    }
                }
            } else {
                //默认按时间戳大小排序
                std::sort(appid_info_vec.begin(), appid_info_vec.end(),
                          [this](const AppIdWithEventTime *a, const AppIdWithEventTime *b) {
                              return compareAppIdWithEventTime(*a, *b, reserve_);
                          });

                for (uint32_t i = 0; i < size; ++i) {
                    appid_info_vec_ptr.emplace_back(appid_info_vec[i]);
                }
            }

            //截断
            if (topn_ > 0 && (int64_t) appid_info_vec_ptr.size() > topn_) {
                appid_info_vec_ptr.resize(topn_);
            }
        }

        template<typename T>
        void compute_vec(std::vector<std::pair<T, const google::protobuf::Message *>> &vec,
                         std::vector<const google::protobuf::Message *> &topn_vec) {
            uint32_t size = vec.size();
            if (size == 0) {
                return;
            }

            //默认按value排序
            std::sort(vec.begin(), vec.end(),
                      [this](const std::pair<T, const google::protobuf::Message *> &a,
                             const std::pair<T, const google::protobuf::Message *> &b) {
                          return compareMessageByValue<T>(a, b, reserve_);
                      });

            topn_vec.reserve(size);
            for (uint32_t i = 0; i < size; ++i) {
                topn_vec.push_back(vec[i].second);
            }

            int64_t truly_size = topn_;
            //截断至给定大小，如果尾部有相同值，截断至相同值的最后一个
            // while (truly_size > 0 && (int64_t) topn_vec.size() > truly_size) {
            //     if (vec[truly_size - 1].first != vec[truly_size].first) {
            //         topn_vec.resize(truly_size);
            //         break;
            //     }
            //     truly_size++;
            // }

            // 截断至给定大小
            if (truly_size > 0 && (int64_t) topn_vec.size() > truly_size) {
                topn_vec.resize(truly_size);
            }
        }

        std::string get_config() {
            return "type:" + std::to_string(static_cast<int64_t>(type_)) + ", topn:" + std::to_string(topn_);
        }

        std::string get_reserve() {
            return "reserve:" + std::to_string(reserve_);
        }

        SortType get_type() {
            return type_;
        }

        int64_t get_topn() {
            return topn_;
        }

    private:
        SortType type_;
        int64_t topn_;   //获取的长度，不设置默认-1报错，设置0不限制长度
        int64_t reserve_;//0为从大到小排序，1为从小到大排序

        static bool compareAppIdWithEventTime(const AppIdWithEventTime &info1, const AppIdWithEventTime &info2,
                                              int64_t reserve) {
            if (reserve) {
                return info1.eventtime < info2.eventtime;
            } else {
                return info1.eventtime > info2.eventtime;
            }
        }

        template<typename T>
        static bool compareAppIdWithEventTimeByCount(const AppIdWithEventTime &info1, const AppIdWithEventTime &info2,
                                                     std::unordered_map<int64_t, T> &appid_count, int64_t reserve) {
            const T &value1 = appid_count[info1.appid];
            const T &value2 = appid_count[info2.appid];
            if (value1 == value2) {
                return info1.eventtime > info2.eventtime;
            } else if (reserve) {
                return value1 < value2;
            } else {
                return value1 > value2;
            }
        }

        static bool compareClassNameWithEventTimeByCount(const ClassNameWithEventTime &info1,
                                                         const ClassNameWithEventTime &info2,
                                                         StringPtrCountMap &class_count, int64_t reserve) {
            int64_t value1 = class_count[info1.class_name];
            int64_t value2 = class_count[info2.class_name];
            if (value1 == value2) {
                return info1.event_time > info2.event_time;
            } else if (reserve) {
                return value1 < value2;
            } else {
                return value1 > value2;
            }
        }

        static bool compareClassNameWithEventTime(const ClassNameWithEventTime &info1,
                                                  const ClassNameWithEventTime &info2, int64_t reserve) {
            if (reserve) {
                return info1.event_time < info2.event_time;
            } else {
                return info1.event_time > info2.event_time;
            }
        }

        template<typename T>
        static bool compareMessageByValue(const std::pair<T, const google::protobuf::Message *> &value1,
                                          const std::pair<T, const google::protobuf::Message *> &value2,
                                          int64_t reserve) {
            if (reserve) {
                return value1.first < value2.first;
            } else {
                return value1.first > value2.first;
            }
        }
    };

    // 用于防穿越和控制时间范围计算
    class SeqFilterCompute {
    public:
        explicit SeqFilterCompute(int64_t start, int64_t day_n = -1, int64_t delta_day = 0, int64_t end = -1)
            : start_(start), day_n_(day_n), delta_day_(delta_day), end_(end) {
            if (day_n > 0) {
                end_ = day_n_ * (int64_t) (60 * 60 * 24) * (int64_t) 1000;
            }
        }
        virtual ~SeqFilterCompute() {
        }

        void fill_appid_vec(const tensorflow::Feature &appid_feat, const tensorflow::Feature &time_feat, int64_t now,
                            std::vector<AppIdWithEventTime> &appid_info_vec, int64_t max_time = -1) {
            auto &appid_vec = appid_feat.int64_list().value();
            auto &eventtime_vec = time_feat.int64_list().value();
            const uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
            appid_info_vec.reserve(appid_info_vec.size() + list_size);

            int64_t start = start_;
            int64_t sub = now - max_time;
            if (max_time > 0 && sub > 0) {
                start = sub;
            }

            for (uint32_t i = 0; i < list_size; i++) {
                //时间戳数据为13位
                if ((now - eventtime_vec[i]) > start && (end_ < 0 || (now - eventtime_vec[i]) < end_)) {
                    appid_info_vec.emplace_back(appid_vec[i], eventtime_vec[i]);
                }
            }
        }

        void fill_appid_vec_with_index(const tensorflow::Feature &appid_feat, const tensorflow::Feature &time_feat,
                                       int64_t now, std::vector<AppIdWithEventTime> &appid_info_vec,
                                       std::vector<int64_t> &appid_index) {
            auto &appid_vec = appid_feat.int64_list().value();
            auto &eventtime_vec = time_feat.int64_list().value();
            uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
            appid_info_vec.reserve(appid_info_vec.size() + list_size);
            appid_index.reserve(list_size);

            for (uint32_t i = 0; i < list_size; i++) {
                //时间戳数据为13位
                if ((now - eventtime_vec[i]) > start_ && (end_ < 0 || (now - eventtime_vec[i]) < end_)) {
                    appid_info_vec.emplace_back(appid_vec[i], eventtime_vec[i]);
                    appid_index.emplace_back(i);
                }
            }
        }

        void fill_subkey_vec_with_index(const tensorflow::Feature &subkey_feat, const tensorflow::Feature &time_feat,
                                        int64_t now, std::vector<int64_t> &subkey_vec,
                                        std::vector<int64_t> &index_vec) {
            auto &appid_vec = subkey_feat.int64_list().value();
            auto &eventtime_vec = time_feat.int64_list().value();
            uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
            subkey_vec.reserve(subkey_vec.size() + list_size);
            index_vec.reserve(list_size);

            for (uint32_t i = 0; i < list_size; i++) {
                //时间戳数据为13位
                if ((now - eventtime_vec[i]) > start_ && (end_ < 0 || (now - eventtime_vec[i]) < end_)) {
                    subkey_vec.emplace_back(appid_vec[i]);
                    index_vec.emplace_back(i);
                }
            }
        }

        void fill_subkey_vec_with_index_by_hour(const tensorflow::Feature &subkey_feat,
                                                const tensorflow::Feature &time_feat, int64_t now,
                                                std::vector<int64_t> &subkey_vec, std::vector<int64_t> &index_vec) {
            auto &appid_vec = subkey_feat.int64_list().value();
            auto &eventtime_vec = time_feat.int64_list().value();
            uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
            subkey_vec.reserve(subkey_vec.size() + list_size);
            index_vec.reserve(list_size);
            int64_t req_hour = ((now / 1000 / 3600) + 8) % 24;//东八区时区

            for (uint32_t i = 0; i < list_size; i++) {
                //时间戳数据为13位
                if ((now - eventtime_vec[i]) > start_ && (end_ < 0 || (now - eventtime_vec[i]) < end_) &&
                    (req_hour == ((eventtime_vec[i] / 1000 / 3600) + 8) % 24)) {
                    subkey_vec.emplace_back(appid_vec[i]);
                    index_vec.emplace_back(i);
                }
            }
        }

        bool fill_count_map(const tensorflow::Feature &subkey_feat, const tensorflow::Feature &time_feat, int64_t now,
                            std::unordered_map<int64_t, int64_t> &count_map) {
            auto &appid_vec = subkey_feat.int64_list().value();
            auto &eventtime_vec = time_feat.int64_list().value();
            uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());

            if (list_size == 0)
                return false;

            for (uint32_t i = 0; i < list_size; i++) {
                //时间戳数据为13位
                if ((now - eventtime_vec[i]) > start_ && (end_ < 0 || (now - eventtime_vec[i]) < end_)) {
                    count_map[appid_vec[i]]++;
                }
            }
            return true;
        }

        bool fill_count_map(const tensorflow::Feature &subkey_feat, const tensorflow::Feature &time_feat, int64_t now,
                            std::unordered_map<std::string, int64_t> &count_map) {
            auto &appid_vec = subkey_feat.bytes_list().value();
            auto &eventtime_vec = time_feat.int64_list().value();
            uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
            if (list_size == 0)
                return false;

            for (uint32_t i = 0; i < list_size; i++) {
                //时间戳数据为13位
                if ((now - eventtime_vec[i]) > start_ && (end_ < 0 || (now - eventtime_vec[i]) < end_)) {
                    count_map[appid_vec[i]]++;
                }
            }
            return true;
        }

        void fill_count_map_by_hour(const tensorflow::Feature &subkey_feat, const tensorflow::Feature &time_feat,
                                    int64_t now, std::unordered_map<int64_t, int64_t> &count_map) {
            auto &appid_vec = subkey_feat.int64_list().value();
            auto &eventtime_vec = time_feat.int64_list().value();
            uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
            int64_t req_hour = ((now / 1000 / 3600) + 8) % 24;//东八区时区

            for (uint32_t i = 0; i < list_size; i++) {
                //时间戳数据为13位
                if ((now - eventtime_vec[i]) > start_ && (end_ < 0 || (now - eventtime_vec[i]) < end_) &&
                    (req_hour == ((eventtime_vec[i] / 1000 / 3600) + 8) % 24)) {
                    count_map[appid_vec[i]]++;
                }
            }
        }

        void fill_appid_map(const tensorflow::Feature &appid_feat, const tensorflow::Feature &time_feat, int64_t now,
                            std::unordered_map<int64_t, std::vector<int64_t>> &appid_info_map, int64_t max_time = -1) {
            auto &appid_vec = appid_feat.int64_list().value();
            auto &eventtime_vec = time_feat.int64_list().value();
            const uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());

            int64_t start = start_;
            int64_t sub = now - max_time;
            if (max_time > 0 && sub > 0) {
                start = sub;
            }

            for (uint32_t i = 0; i < list_size; i++) {
                //时间戳数据为13位
                if ((now - eventtime_vec[i]) > start &&
                    (end_ < 0 ||
                     (now - eventtime_vec[i]) < (end_ + delta_day_ * (int64_t) (60 * 60 * 24) * (int64_t) 1000))) {
                    appid_info_map[appid_vec[i]].push_back(eventtime_vec[i]);
                }
            }
        }

        void fill_time_map(const tensorflow::Feature &appid_feat, const tensorflow::Feature &time_feat, int64_t now,
                           std::unordered_map<int64_t, int64_t> &time_map) {
            auto &appid_vec = appid_feat.int64_list().value();
            auto &eventtime_vec = time_feat.int64_list().value();
            const uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());

            for (uint32_t i = 0; i < list_size; i++) {
                int64_t duration = now - eventtime_vec[i];
                if (duration > start_ && (end_ < 0 || duration < end_)) {
                    int64_t &time = time_map[appid_vec[i]];
                    if (0 == time || time < eventtime_vec[i]) {
                        time = eventtime_vec[i];
                    }
                }
            }
        }

        bool fill_duration_time_map(const tensorflow::Feature &appid_feat, const tensorflow::Feature &time_feat,
                                    int64_t now, std::unordered_map<int64_t, int64_t> &time_map) {
            auto &appid_vec = appid_feat.int64_list().value();
            auto &eventtime_vec = time_feat.int64_list().value();
            const uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());

            if (list_size == 0)
                return false;

            for (uint32_t i = 0; i < list_size; i++) {
                int64_t duration = now - eventtime_vec[i];
                if (duration > start_ && (end_ < 0 || duration < end_)) {
                    int64_t &time = time_map[appid_vec[i]];
                    if (0 == time || duration < time) {
                        time = duration;
                    }
                }
            }

            return true;
        }

        void fill_time_vec(const tensorflow::Feature &time_feat, int64_t now, std::vector<int64_t> &eventtime_sub_vec) {
            auto &eventtime_vec = time_feat.int64_list().value();
            const uint32_t list_size = eventtime_vec.size();
            eventtime_sub_vec.reserve(eventtime_sub_vec.size() + list_size);
            for (uint32_t i = 0; i < list_size; i++) {
                int64_t duration = now - eventtime_vec[i];
                if (duration > start_ && (end_ < 0 || duration < end_)) {
                    eventtime_sub_vec.emplace_back(eventtime_vec[i]);
                }
            }
        }

        bool fill_sum_map(const tensorflow::Feature &appid_feat, const tensorflow::Feature &time_feat,
                          const tensorflow::Feature &event_feat, int64_t now,
                          std::unordered_map<int64_t, float> &float_sum_map,
                          std::unordered_map<int64_t, int64_t> &int_sum_map, tensorflow::DataType &data_type) {
            auto &appid_vec = appid_feat.int64_list().value();
            auto &time_vec = time_feat.int64_list().value();
            const int list_size = std::min(appid_vec.size(), time_vec.size());
            if (list_size == 0)
                return false;

            switch (event_feat.kind_case()) {
                case tensorflow::Feature::kFloatList: {
                    if (data_type == tensorflow::DT_INVALID)
                        data_type = tensorflow::DT_FLOAT;
                    auto &event_vec = event_feat.float_list().value();
                    const int real_size = std::min(list_size, event_vec.size());
                    for (int i = 0; i < real_size; i++) {
                        int64_t duration = now - time_vec[i];
                        if (duration > start_ && (end_ < 0 || duration < end_)) {
                            float &sum = float_sum_map[appid_vec[i]];
                            sum += event_vec[i];
                        }
                    }
                    break;
                }
                case tensorflow::Feature::kInt64List: {
                    if (data_type == tensorflow::DT_INVALID)
                        data_type = tensorflow::DT_INT64;
                    auto &event_vec = event_feat.int64_list().value();
                    const int real_size = std::min(list_size, event_vec.size());
                    for (int i = 0; i < real_size; i++) {
                        int64_t duration = now - time_vec[i];
                        if (duration > start_ && (end_ < 0 || duration < end_)) {
                            int64_t &sum = int_sum_map[appid_vec[i]];
                            sum += event_vec[i];
                        }
                    }
                    break;
                }
                default: {
                    break;
                }
            }
            return true;
        }

        std::string display_start() {
            return "start:" + std::to_string(start_);
        }

        std::string display_day_n() {
            return "day_n:" + std::to_string(day_n_);
        }

        std::string display_delta_day() {
            return "delta_day:" + std::to_string(delta_day_);
        }

        std::string display_end() {
            return "end:" + std::to_string(end_);
        }

    private:
        int64_t start_;    //防穿越，单位已转换ms
        int64_t day_n_;    //有效天数，单位day
        int64_t delta_day_;//间隔天数，单位day
        int64_t end_;      //有效时间，单位已转换ms
    };
}// namespace phx_fe
