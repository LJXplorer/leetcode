#ifndef FE_CONFIG_GATHER
#define FE_CONFIG_GATHER

#include "phx-fe/config/config_seq.h"
#include "phx-fe/config/config_base.h"
#include "phx-fe/config/config_utf8.h"
#include "phx-fe/config/phx_config_time.h"
#include "phx-fe/config/config.h"

// gather聚合config的基类
class GatherConfig : public Config {
 public:
  explicit GatherConfig(const std::string& output,
                        const std::vector<std::string>& source,
                        DefaultValue& default_input_value,
                        bool save,
                        bool allow_empty_output,
                        const std::vector<std::string>& strategy,
                        const std::vector<std::shared_ptr<Config>>& configs)
      : Config(output, source, default_input_value, save, allow_empty_output, strategy),
        configs_(configs) {}
  virtual ~GatherConfig() {}

  virtual std::string get_config() override {
    std::string display;
    for (auto& config : configs_) {
      display.append(config->get_config());
    }
    return display;
  }

 protected:
  std::vector<std::shared_ptr<Config>> configs_;
};

// 对查询词分词后过滤指定长度字符，截断至指定长度后，拼接字符串再查map词典
class CrossByGramsSegConfig : public GatherConfig {
 public:
  explicit CrossByGramsSegConfig(const std::string& output,
                                 const std::vector<std::string>& source,
                                 DefaultValue& default_input_value,
                                 bool save,
                                 bool allow_empty_output,
                                 const std::vector<std::string>& strategy,
                                 const std::vector<std::shared_ptr<Config>>& configs)
      : GatherConfig(output, source, default_input_value, save, allow_empty_output, strategy, configs) {}
  virtual ~CrossByGramsSegConfig() {}

  virtual std::string get_config() override {
    std::string display = "cross_by_grams_seg{";
    display.append(GatherConfig::get_config());
    display.append("}");
    return display;
  }

  virtual bool compute(const std::vector<const Output*>& input_values, Output& output) override;
};

#endif  // FE_CONFIG_GATHER