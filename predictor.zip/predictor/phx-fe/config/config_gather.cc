#include "config_gather.h"
#include "phx-fe/util/timer.h"
#include <algorithm>
#include <cstdlib>

bool CrossByGramsSegConfig::compute(const std::vector<const Output*>& input_values, Output& output) {
  DEBUG_TIMER("CrossByGramsSegConfig::compute");
  LogDebug("------------ compute {} start ------------", output_);

  if (unlikely(input_values.size() < 2 || configs_.size() < 5)) {
    THROW_ERROR("input size:" + std::to_string(input_values.size()) + ",name:" + output_);
    return false;
  }

  std::vector<const Output*> temp_input_values(input_values.size());
  for (uint32_t i = 0; i < input_values.size(); i++) {
    temp_input_values[i] = input_values[i];
  }

  uint32_t config_size = configs_.size();
  std::vector<Output> temp_output(config_size - 1);

  configs_[0]->compute(temp_input_values, temp_output[0]);

  for (uint32_t i = 1; i < config_size - 1; i++) {
    temp_input_values[0] = &temp_output[i - 1];
    configs_[i]->compute(temp_input_values, temp_output[i]);
  }

  temp_input_values[0] = &temp_output[config_size - 2];
  configs_[config_size - 1]->compute(temp_input_values, output);

  LogDebug("------------ compute {} done ------------", output_);
  return true;
}