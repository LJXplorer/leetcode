#include "phx_config_seq.h"
#include "phx-fe/util/log.h"
#include "phx-fe/util/timer.h"
#include "phx-fe/util/util.h"
#include "seq_utils.h"
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace phx_fe {

    void fill_feature_to_vec(const tensorflow::Feature &feat, std::vector<int64_t> &vec) {
        vec.reserve(vec.size() + feat.int64_list().value_size());
        for (int64_t num: feat.int64_list().value()) {
            vec.emplace_back(num);
        }
    }

    void fill_feature_to_vec(const tensorflow::Feature &feat, std::vector<float> &vec) {
        vec.reserve(vec.size() + feat.float_list().value_size());
        for (float num: feat.float_list().value()) {
            vec.emplace_back(num);
        }
    }

    void fill_feature_to_vec(const tensorflow::Feature &feat, std::vector<std::string> &vec) {
        vec.reserve(vec.size() + feat.bytes_list().value_size());
        for (const std::string &num: feat.bytes_list().value()) {
            vec.emplace_back(num);
        }
    }

    template<typename T,
             typename = typename std::enable_if<std::is_same<T, float>::value || std::is_same<T, int64_t>::value ||
                                                std::is_same<T, std::string>::value>::type>
    void fill_ifeature_to_vec(const InputFeature &hf, std::vector<T> &vec) {
        // 展开所有的appid
        if (likely(hf.feature)) {
            fill_feature_to_vec(*(hf.feature), vec);
        } else if (likely(hf.feature_list)) {
            for (auto &feat: hf.feature_list->feature()) {
                fill_feature_to_vec(feat, vec);
            }
        }
    }

    bool SeqHitIntervalConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqHitIntervalConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *eventtime_value = get_value(input_values, inputs_, 1);
        int64_t now = get_feature_one_int64(input_values, inputs_, 2);
        const Value *item_value = get_value(input_values, inputs_, 3);

        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_eventtime = nullptr;
        bool has_input = false;

        uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());
        std::unordered_map<int64_t, int64_t> time_map;
        //防穿越，获取有效数据的最大时间戳
        for (uint32_t i = 0; i < input_size; i++) {
            inf_appid = &appid_value->ifeatures[i];
            inf_eventtime = &eventtime_value->ifeatures[i];

            if (likely(inf_appid->feature && inf_eventtime->feature)) {
                has_input |= filter_compute_.fill_duration_time_map(*inf_appid->feature, *inf_eventtime->feature, now,
                                                                    time_map);
            } else if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
                uint32_t list_size =
                        std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

                for (uint32_t j = 0; j < list_size; j++) {
                    has_input |= filter_compute_.fill_duration_time_map(inf_appid->feature_list->feature(j),
                                                                        inf_eventtime->feature_list->feature(j), now,
                                                                        time_map);
                }
            }
        }

        const uint32_t batch_size = item_value->ifeatures.size();
        const InputFeature *inf = nullptr;
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_INT64;
        value.ifeatures.resize(batch_size);

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &item_value->ifeatures[i];

            if (inf->feature_list) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;

                for (auto &feat: inf->feature_list->feature()) {
                    compute_one_feature(feat, time_map, out_featurelist->add_feature(), has_input);
                }
                if ((out_featurelist->feature_size() == 0) && !allow_empty_output_) {
                    fill_default_value(out_featurelist->add_feature());
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (likely(inf->feature)) {
                    compute_one_feature(*inf->feature, time_map, out_feature, has_input);
                } else if (!allow_empty_output_) {
                    fill_default_value(out_feature);
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqHitIntervalConfig::compute_one_feature(const tensorflow::Feature &feat,
                                                   std::unordered_map<int64_t, int64_t> &time_map,
                                                   tensorflow::Feature *out, bool has_input) {
        if (has_input) {
            for (const int64_t &appid: feat.int64_list().value()) {
                auto itr = time_map.find(appid);
                if (itr != time_map.end()) {
                    out->mutable_int64_list()->add_value(itr->second / 1000);
                } else {
                    out->mutable_int64_list()->add_value(default_value_);
                }
            }
        }

        if (!allow_empty_output_) {
            fill_default_value(out);
        }
    }

    void SeqHitIntervalConfig::fill_default_value(tensorflow::Feature *out) {
        if (out->int64_list().value_size() < 1) {
            out->mutable_int64_list()->add_value(default_value_);
        }
    }

    bool SeqHitSumConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqHitSumConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        int64_t now = get_feature_one_int64(input_values, inputs_, 0);
        const Value *appid_value = get_value(input_values, inputs_, 1);
        const Value *time_value = get_value(input_values, inputs_, 2);
        const Value *event_value = get_value(input_values, inputs_, 3);
        const Value *item_value = get_value(input_values, inputs_, 4);

        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_time = nullptr;
        const InputFeature *inf_event = nullptr;
        bool has_input = false;

        uint32_t input_size = std::min(std::min(appid_value->ifeatures.size(), time_value->ifeatures.size()),
                                       event_value->ifeatures.size());
        std::unordered_map<int64_t, int64_t> int_sum_map;
        std::unordered_map<int64_t, float> float_sum_map;
        tensorflow::DataType data_type = tensorflow::DT_INVALID;

        for (uint32_t i = 0; i < input_size; i++) {
            inf_appid = &appid_value->ifeatures[i];
            inf_time = &time_value->ifeatures[i];
            inf_event = &event_value->ifeatures[i];
            if (likely(inf_appid->feature && inf_event->feature)) {
                has_input |= filter_compute_.fill_sum_map(*inf_appid->feature, *inf_time->feature, *inf_event->feature,
                                                          now, float_sum_map, int_sum_map, data_type);
            } else if (likely(inf_appid->feature_list && inf_event->feature_list)) {
                uint32_t list_size =
                        std::min(inf_appid->feature_list->feature_size(), inf_event->feature_list->feature_size());
                for (uint32_t j = 0; j < list_size; j++) {
                    has_input |= filter_compute_.fill_sum_map(
                            inf_appid->feature_list->feature(j), inf_time->feature_list->feature(j),
                            inf_event->feature_list->feature(j), now, float_sum_map, int_sum_map, data_type);
                }
            }
        }

        const uint32_t batch_size = item_value->ifeatures.size();
        const InputFeature *inf = nullptr;
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;

        // data_type默认先从实际输入中推导，如果没推导出来，则采用配置中的type
        if (data_type == tensorflow::DT_INVALID) {
            data_type = default_type_;
        }

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = data_type;
        value.ifeatures.resize(batch_size);

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &item_value->ifeatures[i];

            if (inf->feature_list) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;

                for (auto &feat: inf->feature_list->feature()) {
                    compute_one_feature(feat, float_sum_map, int_sum_map, data_type, out_featurelist->add_feature(),
                                        has_input);
                }
                if ((out_featurelist->feature_size() == 0) && !allow_empty_output_) {
                    fill_default_value(out_featurelist->add_feature(), data_type);
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (likely(inf->feature)) {
                    compute_one_feature(*inf->feature, float_sum_map, int_sum_map, data_type, out_feature, has_input);
                } else if (!allow_empty_output_) {
                    fill_default_value(out_feature, data_type);
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqHitSumConfig::compute_one_feature(const tensorflow::Feature &feat,
                                              std::unordered_map<int64_t, float> &float_sum_map,
                                              std::unordered_map<int64_t, int64_t> &int_sum_map,
                                              tensorflow::DataType &data_type, tensorflow::Feature *out,
                                              bool has_input) {
        if (has_input) {
            for (const int64_t &appid: feat.int64_list().value()) {
                switch (data_type) {
                    case tensorflow::DT_FLOAT: {
                        auto itr = float_sum_map.find(appid);
                        if (itr != float_sum_map.end()) {
                            out->mutable_float_list()->add_value(itr->second);
                        } else {
                            out->mutable_float_list()->add_value(default_value_);
                        }
                        break;
                    }
                    case tensorflow::DT_INT64: {
                        auto itr = int_sum_map.find(appid);
                        if (itr != int_sum_map.end()) {
                            out->mutable_int64_list()->add_value(itr->second);
                        } else {
                            out->mutable_int64_list()->add_value(default_int_);
                        }
                        break;
                    }
                    default: {
                        break;
                    }
                }
            }
        }

        if (!allow_empty_output_) {
            fill_default_value(out, data_type);
        }
    }

    void SeqHitSumConfig::fill_default_value(tensorflow::Feature *out, tensorflow::DataType &data_type) {
        switch (data_type) {
            case tensorflow::DT_FLOAT: {
                if (unlikely(out->float_list().value_size() == 0)) {
                    out->mutable_float_list()->add_value(default_value_);
                }
                break;
            }
            case tensorflow::DT_INT64: {
                if (unlikely(out->int64_list().value_size() == 0)) {
                    out->mutable_int64_list()->add_value(default_int_);
                }
                break;
            }
            default: {
                break;
            }
        }
    }

    bool SeqDiffDailyConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *eventtime_value = get_value(input_values, inputs_, 1);
        const Value *appid_use_value = get_value(input_values, inputs_, 2);
        const Value *eventtime_use_value = get_value(input_values, inputs_, 3);
        int64_t now = get_feature_one_int64(input_values, inputs_, 4);
        const Value *max_value = nullptr;

        if (input_values.size() > 5) {
            max_value = get_value(input_values, inputs_, 5);
        }

        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_eventtime = nullptr;

        uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());
        uint32_t input_use_size = std::min(appid_use_value->ifeatures.size(), eventtime_use_value->ifeatures.size());
        input_size = std::max(input_size, input_use_size);

        output.values.resize(2);
        for (uint32_t i = 0; i < 2; i++) {
            Value &value = output.values[i];
            value.ifeatures.resize(input_size);
        }
        output.values[0].defalut_type = tensorflow::DT_INT64;
        output.values[1].defalut_type = tensorflow::DT_INT64;

        std::vector<tensorflow::Feature *> out_feat(2);
        std::vector<tensorflow::FeatureList *> out_featlist(2);
        std::unordered_map<int64_t, std::vector<int64_t>> appid_info_map;

        for (uint32_t i = 0; i < input_size; ++i) {
            int64_t max_time = -1;
            if (max_value && !get_ifeature_one_int64(get_idx_ifeatures(max_value, i), max_time)) {
                THROW_ERROR("max_value feature no data, name:" + output_);
            }

            if (i == 0 || input_size == input_use_size) {
                appid_info_map.clear();
                inf_appid = get_idx_ifeatures(appid_use_value, i);
                inf_eventtime = get_idx_ifeatures(eventtime_use_value, i);

                if (inf_appid->feature_list && inf_eventtime->feature_list) {
                    uint32_t list_size = std::min(inf_appid->feature_list->feature_size(),
                                                  inf_eventtime->feature_list->feature_size());
                    for (uint32_t j = 0; j < list_size; j++) {
                        filter_compute_.fill_appid_map(inf_appid->feature_list->feature(j),
                                                       inf_eventtime->feature_list->feature(j), now, appid_info_map,
                                                       max_time);
                    }
                } else if (likely(inf_appid->feature && inf_eventtime->feature)) {
                    filter_compute_.fill_appid_map(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_map,
                                                   max_time);
                }
            }

            inf_appid = get_idx_ifeatures(appid_value, i);
            inf_eventtime = get_idx_ifeatures(eventtime_value, i);
            std::vector<AppIdWithEventTime> appid_info_vec;
            std::vector<AppIdWithEventTime *> appid_filter_vec_ptr;
            std::vector<AppIdWithEventTime *> appid_info_vec_ptr;

            if (inf_appid->feature_list && inf_eventtime->feature_list) {
                for (uint32_t j = 0; j < 2; j++) {
                    out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[j].ifeatures[i].feature_list = out_featlist[j];
                }
                uint32_t list_size =
                        std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

                for (uint32_t j = 0; j < list_size; j++) {
                    filter_compute_.fill_appid_vec(inf_appid->feature_list->feature(j),
                                                   inf_eventtime->feature_list->feature(j), now, appid_info_vec,
                                                   max_time);
                }
                //筛选不经常使用的appid信息
                filter_unuse_appid(appid_info_vec, appid_info_map, appid_filter_vec_ptr);

                //排序、截断
                top_n_compute_.compute_ptr_vec(appid_filter_vec_ptr, appid_info_vec_ptr);

                //输出
                for (const auto &elem: appid_info_vec_ptr) {
                    out_featlist[0]->add_feature()->mutable_int64_list()->add_value(elem->appid);
                    out_featlist[1]->add_feature()->mutable_int64_list()->add_value(elem->eventtime);
                }
            } else {
                for (uint32_t j = 0; j < 2; j++) {
                    out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[j].ifeatures[i].feature = out_feat[j];
                }

                if (likely(inf_appid->feature && inf_eventtime->feature)) {
                    filter_compute_.fill_appid_vec(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_vec,
                                                   max_time);

                    //筛选
                    filter_unuse_appid(appid_info_vec, appid_info_map, appid_filter_vec_ptr);

                    //排序、截断
                    top_n_compute_.compute_ptr_vec(appid_filter_vec_ptr, appid_info_vec_ptr);
                }

                //输出
                for (const auto &elem: appid_info_vec_ptr) {
                    out_feat[0]->mutable_int64_list()->add_value(elem->appid);
                    out_feat[1]->mutable_int64_list()->add_value(elem->eventtime);
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqDiffDailyConfig::filter_unuse_appid(std::vector<AppIdWithEventTime> &appid_info_vec,
                                                std::unordered_map<int64_t, std::vector<int64_t>> &appid_info_map,
                                                std::vector<AppIdWithEventTime *> &appid_filter_vec_ptr) {
        appid_filter_vec_ptr.reserve(appid_info_vec.size());
        for (auto &appid_info: appid_info_vec) {
            //查找是否有使用记录
            bool flag = true;
            auto itr = appid_info_map.find(appid_info.appid);
            if (itr != appid_info_map.end()) {
                int64_t day = timestamp_to_cast_days(appid_info.eventtime);
                for (const int64_t &event_time: itr->second) {
                    int64_t event_time_day = timestamp_to_cast_days(event_time);
                    //delta_day_ >= 0表明需要被过滤的appid列表的event_time需要在作为过滤条件的app_info_map的event_time[发生后]的delta_day_内自然天之内
                    if (delta_day_ >= 0) {
                        //如果时间段内有符合的使用记录，直接跳出
                        if ((event_time > appid_info.eventtime) && (event_time_day <= day + delta_day_)) {
                            flag = false;
                            break;
                        }
                        //delta_day_ < 0表明需要被过滤的appid列表的event_time需要在作为过滤条件的app_info_map的event_time[发生前]的delta_day_内自然天之内
                    } else {
                        if ((event_time < appid_info.eventtime) && (event_time_day >= day + delta_day_)) {
                            flag = false;
                            break;
                        }
                    }
                }
            }

            if (flag && !status_) {
                //flag为true没有符合记录，且过滤符合条件的
                appid_filter_vec_ptr.emplace_back(&appid_info);
            } else if (!flag && status_) {
                //flag为flase有符合记录，且输出符合条件的
                appid_filter_vec_ptr.emplace_back(&appid_info);
            }
        }
    }

    bool SeqDiffV2Config::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqDiffV2Config::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *eventtime_value = get_value(input_values, inputs_, 1);
        const Value *appid_use_value = get_value(input_values, inputs_, 2);
        const Value *eventtime_use_value = get_value(input_values, inputs_, 3);
        int64_t now = get_feature_one_int64(input_values, inputs_, 4);
        const Value *max_value = nullptr;

        if (input_values.size() > 5) {
            max_value = get_value(input_values, inputs_, 5);
        }

        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_eventtime = nullptr;

        uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());
        uint32_t input_use_size = std::min(appid_use_value->ifeatures.size(), eventtime_use_value->ifeatures.size());
        input_size = std::max(input_size, input_use_size);

        output.values.resize(2);
        for (uint32_t i = 0; i < 2; i++) {
            Value &value = output.values[i];
            value.ifeatures.resize(input_size);
        }
        output.values[0].defalut_type = tensorflow::DT_INT64;
        output.values[1].defalut_type = tensorflow::DT_INT64;

        std::vector<tensorflow::Feature *> out_feat(2);
        std::vector<tensorflow::FeatureList *> out_featlist(2);
        std::unordered_map<int64_t, std::vector<int64_t>> appid_info_map;

        for (uint32_t i = 0; i < input_size; ++i) {
            int64_t max_time = -1;
            if (max_value && !get_ifeature_one_int64(get_idx_ifeatures(max_value, i), max_time)) {
                THROW_ERROR("max_value feature no data, name:" + output_);
            }

            //获取使用信息
            if (i == 0 || input_size == input_use_size) {
                appid_info_map.clear();
                inf_appid = get_idx_ifeatures(appid_use_value, i);
                inf_eventtime = get_idx_ifeatures(eventtime_use_value, i);

                if (inf_appid->feature_list && inf_eventtime->feature_list) {
                    uint32_t list_size = std::min(inf_appid->feature_list->feature_size(),
                                                  inf_eventtime->feature_list->feature_size());
                    for (uint32_t j = 0; j < list_size; j++) {
                        filter_compute_.fill_appid_map(inf_appid->feature_list->feature(j),
                                                       inf_eventtime->feature_list->feature(j), now, appid_info_map,
                                                       max_time);
                    }

                } else if (likely(inf_appid->feature && inf_eventtime->feature)) {
                    filter_compute_.fill_appid_map(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_map,
                                                   max_time);
                }
            }

            inf_appid = get_idx_ifeatures(appid_value, i);
            inf_eventtime = get_idx_ifeatures(eventtime_value, i);
            std::vector<AppIdWithEventTime> appid_info_vec;
            std::vector<AppIdWithEventTime *> appid_filter_vec_ptr;
            std::vector<AppIdWithEventTime *> appid_info_vec_ptr;

            if (inf_appid->feature_list && inf_eventtime->feature_list) {
                for (uint32_t j = 0; j < 2; j++) {
                    out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[j].ifeatures[i].feature_list = out_featlist[j];
                }

                uint32_t list_size =
                        std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

                for (uint32_t j = 0; j < list_size; j++) {
                    filter_compute_.fill_appid_vec(inf_appid->feature_list->feature(j),
                                                   inf_eventtime->feature_list->feature(j), now, appid_info_vec,
                                                   max_time);
                }

                //筛选不经常使用的appid信息
                filter_unuse_appid(appid_info_vec, appid_info_map, appid_filter_vec_ptr);

                //排序、截断
                top_n_compute_.compute_ptr_vec(appid_filter_vec_ptr, appid_info_vec_ptr);

                //输出
                for (const auto &elem: appid_info_vec_ptr) {
                    out_featlist[0]->add_feature()->mutable_int64_list()->add_value(elem->appid);
                    out_featlist[1]->add_feature()->mutable_int64_list()->add_value(elem->eventtime);
                }
            } else {
                for (uint32_t j = 0; j < 2; j++) {
                    out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[j].ifeatures[i].feature = out_feat[j];
                }

                if (likely(inf_appid->feature && inf_eventtime->feature)) {
                    filter_compute_.fill_appid_vec(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_vec,
                                                   max_time);

                    //筛选
                    filter_unuse_appid(appid_info_vec, appid_info_map, appid_filter_vec_ptr);

                    //排序、截断
                    top_n_compute_.compute_ptr_vec(appid_filter_vec_ptr, appid_info_vec_ptr);
                }

                //输出
                for (const auto &elem: appid_info_vec_ptr) {
                    out_feat[0]->mutable_int64_list()->add_value(elem->appid);
                    out_feat[1]->mutable_int64_list()->add_value(elem->eventtime);
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqDiffV2Config::filter_unuse_appid(std::vector<AppIdWithEventTime> &appid_info_vec,
                                             std::unordered_map<int64_t, std::vector<int64_t>> &appid_info_map,
                                             std::vector<AppIdWithEventTime *> &appid_filter_vec_ptr) {
        appid_filter_vec_ptr.reserve(appid_info_vec.size());
        for (auto &appid_info: appid_info_vec) {
            //查找是否有使用记录
            bool flag = true;
            auto itr = appid_info_map.find(appid_info.appid);
            if (itr != appid_info_map.end()) {
                for (const int64_t &event_time: itr->second) {
                    if (delta_day_ > 0) {
                        //如果时间段内有符合的使用记录，直接跳出
                        if (event_time >= appid_info.eventtime &&
                            event_time <=
                                    appid_info.eventtime + delta_day_ * (int64_t) (60 * 60 * 24) * (int64_t) 1000) {
                            flag = false;
                            break;
                        }
                    } else {
                        if (event_time <= appid_info.eventtime &&
                            event_time >=
                                    appid_info.eventtime + delta_day_ * (int64_t) (60 * 60 * 24) * (int64_t) 1000) {
                            flag = false;
                            break;
                        }
                    }
                }
            }

            if (flag && !status_) {
                //flag为true没有符合记录，且过滤符合条件的
                appid_filter_vec_ptr.emplace_back(&appid_info);
            } else if (!flag && status_) {
                //flag为flase有符合记录，且输出符合条件的
                appid_filter_vec_ptr.emplace_back(&appid_info);
            }
        }
    }

    bool SeqValDirectConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqValDirectConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *eventtime_value = get_value(input_values, inputs_, 1);
        int64_t now = get_feature_one_int64(input_values, inputs_, 2);
        const Value *out_value = nullptr;

        if (input_values.size() > 3) {
            out_value = get_value(input_values, inputs_, 3);
            output.values.resize(3);
        } else {
            output.values.resize(2);
        }

        uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());
        uint32_t values_size = output.values.size();

        for (uint32_t i = 0; i < values_size; i++) {
            Value &value = output.values[i];
            value.ifeatures.resize(input_size);
        }

        output.values[0].defalut_type = tensorflow::DT_INT64;
        output.values[1].defalut_type = tensorflow::DT_INT64;

        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_eventtime = nullptr;
        const InputFeature *inf_value = nullptr;
        std::vector<tensorflow::Feature *> out_feat(values_size);
        std::vector<tensorflow::FeatureList *> out_featlist(values_size);
        const tensorflow::Feature *feature = nullptr;

        for (uint32_t i = 0; i < input_size; i++) {
            inf_appid = &appid_value->ifeatures[i];
            inf_eventtime = &eventtime_value->ifeatures[i];
            if (out_value && out_value->ifeatures.size() > i) {
                inf_value = &out_value->ifeatures[i];
            } else {
                inf_value = nullptr;
            }

            std::vector<AppIdWithEventTime> appid_info_vec;
            std::vector<std::vector<int64_t>> appid_feat_value_index;
            int64_t count = 0;

            if (inf_appid->feature_list && inf_eventtime->feature_list) {
                for (uint32_t j = 0; j < values_size; j++) {
                    out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[j].ifeatures[i].feature_list = out_featlist[j];
                }

                uint32_t list_size =
                        std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

                // val_list存在，过滤超出阈值的value
                if (out_value) {
                    get_value_feature(inf_value, 0, feature);
                    if (likely(feature)) {
                        appid_feat_value_index.resize(list_size);
                        // 过滤时间
                        for (uint32_t j = 0; j < list_size; j++) {
                            filter_compute_.fill_appid_vec_with_index(inf_appid->feature_list->feature(j),
                                                                      inf_eventtime->feature_list->feature(j), now,
                                                                      appid_info_vec, appid_feat_value_index[j]);
                        }

                        std::unordered_map<AppIdWithEventTime *, tensorflow::Feature> appid_values;
                        // 过滤阈值
                        filter_upper_bound_value(appid_info_vec, appid_feat_value_index, inf_value, appid_values);
                        for (auto &elem: appid_info_vec) {
                            auto itr = appid_values.find(&elem);
                            if (itr != appid_values.end()) {
                                switch (itr->second.kind_case()) {
                                    case tensorflow::Feature::kBytesList: {
                                        output.values[2].defalut_type = tensorflow::DT_STRING;
                                        out_featlist[2]->add_feature()->mutable_bytes_list()->add_value(
                                                itr->second.bytes_list().value(0));
                                    } break;

                                    case tensorflow::Feature::kFloatList: {
                                        output.values[2].defalut_type = tensorflow::DT_FLOAT;
                                        out_featlist[2]->add_feature()->mutable_float_list()->add_value(
                                                itr->second.float_list().value(0));
                                    } break;

                                    case tensorflow::Feature::kInt64List: {
                                        output.values[2].defalut_type = tensorflow::DT_INT64;
                                        out_featlist[2]->add_feature()->mutable_int64_list()->add_value(
                                                itr->second.int64_list().value(0));
                                    } break;

                                    default: {
                                        continue;
                                    } break;
                                }
                                out_featlist[0]->add_feature()->mutable_int64_list()->add_value(elem.appid);
                                out_featlist[1]->add_feature()->mutable_int64_list()->add_value(elem.eventtime);
                                count++;
                            }

                            if (clip_size_ > 0 && count == clip_size_) {
                                break;
                            }
                        }
                    }

                } else {
                    for (uint32_t j = 0; j < list_size; j++) {
                        filter_compute_.fill_appid_vec(inf_appid->feature_list->feature(j),
                                                       inf_eventtime->feature_list->feature(j), now, appid_info_vec);
                    }
                    // 截断
                    if (clip_size_ > 0 && (int64_t) appid_info_vec.size() > clip_size_) {
                        appid_info_vec.resize(clip_size_);
                    }
                    for (const auto &elem: appid_info_vec) {
                        out_featlist[0]->add_feature()->mutable_int64_list()->add_value(elem.appid);
                        out_featlist[1]->add_feature()->mutable_int64_list()->add_value(elem.eventtime);
                    }
                }

            } else {
                for (uint32_t j = 0; j < values_size; j++) {
                    out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[j].ifeatures[i].feature = out_feat[j];
                }

                if (likely(inf_appid->feature && inf_eventtime->feature)) {
                    // val_list存在，过滤超出阈值的value
                    if (out_value) {
                        get_value_feature(inf_value, 0, feature);
                        if (likely(feature)) {
                            appid_feat_value_index.emplace_back();
                            // 过滤时间
                            filter_compute_.fill_appid_vec_with_index(*inf_appid->feature, *inf_eventtime->feature, now,
                                                                      appid_info_vec, appid_feat_value_index[0]);
                            std::unordered_map<AppIdWithEventTime *, tensorflow::Feature> appid_values;
                            // 过滤阈值
                            filter_upper_bound_value(appid_info_vec, appid_feat_value_index, inf_value, appid_values);
                            for (auto &elem: appid_info_vec) {
                                auto itr = appid_values.find(&elem);
                                if (itr != appid_values.end()) {
                                    switch (itr->second.kind_case()) {
                                        case tensorflow::Feature::kBytesList: {
                                            output.values[2].defalut_type = tensorflow::DT_STRING;
                                            out_feat[2]->mutable_bytes_list()->add_value(
                                                    itr->second.bytes_list().value(0));
                                        } break;

                                        case tensorflow::Feature::kFloatList: {
                                            output.values[2].defalut_type = tensorflow::DT_FLOAT;
                                            out_feat[2]->mutable_float_list()->add_value(
                                                    itr->second.float_list().value(0));
                                        } break;

                                        case tensorflow::Feature::kInt64List: {
                                            output.values[2].defalut_type = tensorflow::DT_INT64;
                                            out_feat[2]->mutable_int64_list()->add_value(
                                                    itr->second.int64_list().value(0));
                                        } break;

                                        default: {
                                            continue;
                                        } break;
                                    }
                                    out_feat[0]->mutable_int64_list()->add_value(elem.appid);
                                    out_feat[1]->mutable_int64_list()->add_value(elem.eventtime);
                                    count++;
                                }
                                if (clip_size_ > 0 && count == clip_size_) {
                                    break;
                                }
                            }
                        }
                    } else {
                        filter_compute_.fill_appid_vec(*inf_appid->feature, *inf_eventtime->feature, now,
                                                       appid_info_vec);
                        // 截断
                        if (clip_size_ > 0 && (int64_t) appid_info_vec.size() > clip_size_) {
                            appid_info_vec.resize(clip_size_);
                        }
                        for (const auto &elem: appid_info_vec) {
                            out_feat[0]->mutable_int64_list()->add_value(elem.appid);
                            out_feat[1]->mutable_int64_list()->add_value(elem.eventtime);
                        }
                    }
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqValDirectConfig::filter_upper_bound_value(
            std::vector<AppIdWithEventTime> &appid_info_vec, std::vector<std::vector<int64_t>> &appid_feat_value_index,
            const InputFeature *inf_value,
            std::unordered_map<AppIdWithEventTime *, tensorflow::Feature> &appid_values) {
        const tensorflow::Feature *feature = nullptr;
        int64_t index = 0;
        for (uint32_t i = 0; i < appid_feat_value_index.size(); i++) {
            //  获取当前value字段的feature,feature获取失败不符合
            get_value_feature(inf_value, i, feature);
            if (feature) {
                switch (feature->kind_case()) {
                    case tensorflow::Feature::kBytesList: {
                        auto &value_vec = feature->bytes_list().value();
                        for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
                            if (value_vec.size() > appid_feat_value_index[i][j]) {
                                appid_values[&appid_info_vec[index]].mutable_bytes_list()->add_value(
                                        value_vec[appid_feat_value_index[i][j]]);
                            }
                            index++;
                        }
                    } break;

                    case tensorflow::Feature::kFloatList: {
                        auto &value_vec = feature->float_list().value();
                        for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
                            if (value_vec.size() > appid_feat_value_index[i][j]) {
                                const float value = value_vec[appid_feat_value_index[i][j]];
                                if (upper_bound_ < 0 || value <= upper_bound_) {
                                    appid_values[&appid_info_vec[index]].mutable_float_list()->add_value(value);
                                }
                            }
                            index++;
                        }
                    } break;

                    case tensorflow::Feature::kInt64List: {
                        auto &value_vec = feature->int64_list().value();
                        for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
                            if (value_vec.size() > appid_feat_value_index[i][j]) {
                                const int64_t value = value_vec[appid_feat_value_index[i][j]];
                                if (upper_bound_ < 0 || value <= upper_bound_) {
                                    appid_values[&appid_info_vec[index]].mutable_int64_list()->add_value(value);
                                }
                            }
                            index++;
                        }
                    } break;

                    default: {
                        index += appid_feat_value_index[i].size();
                    } break;
                }

            } else {
                index += appid_feat_value_index[i].size();
            }
        }
    }

    SeqValDirectV2Config::SeqValDirectV2Config(const std::string &output, const std::vector<std::string> &source,
                                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                               const std::vector<std::string> &strategy, int64_t start, int64_t day_n,
                                               int64_t hour_n, int64_t clip_size, const Bound &upper_bound,
                                               const Bound &lower_bound)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy),
          filter_compute_(start, day_n, 0, hour_n * 1000 * 60 * 60), clip_size_(clip_size), upper_bound_(upper_bound),
          lower_bound_(lower_bound), hour_n_(hour_n) {
        if (unlikely(upper_bound_.flag_ && lower_bound_.flag_ && upper_bound_.value_ < lower_bound_.value_)) {
            THROW_ERROR("upper_bound_ is less than lower_bound_");
        }
    }

    SeqValDirectV2Config::SeqValDirectV2Config(const std::string &output, const std::vector<std::string> &source,
                                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                               const std::vector<std::string> &strategy, int64_t start, int64_t day_n,
                                               int64_t hour_n, int64_t clip_size, Bound &&upper_bound,
                                               Bound &&lower_bound)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy),
          filter_compute_(start, day_n, 0, hour_n * 1000 * 60 * 60), clip_size_(clip_size),
          upper_bound_(std::move(upper_bound)), lower_bound_(std::move(lower_bound)), hour_n_(hour_n) {
        if (unlikely(upper_bound_.flag_ && lower_bound_.flag_ && upper_bound_.value_ < lower_bound_.value_)) {
            THROW_ERROR("upper_bound_ is less than lower_bound_");
        }
    }

    std::string SeqValDirectV2Config::get_config() {
        std::string display = "seq_val_direct_v2:";
        display.append(filter_compute_.display_start()).append(", ");
        display.append(filter_compute_.display_day_n());
        display.append(", hour_n:").append(std::to_string(hour_n_));
        display.append(", clip_size:").append(std::to_string(clip_size_));
        display.append(", upper_bound: isSetted = ")
                .append(upper_bound_.flag_ ? "true" : "flase")
                .append(" value = ")
                .append(std::to_string(upper_bound_.value_));
        display.append(", lower_bound: isSetted = ")
                .append(lower_bound_.flag_ ? "true" : "flase")
                .append(" value = ")
                .append(std::to_string(lower_bound_.value_));
        return display;
    }

    bool SeqValDirectV2Config::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqValDirectConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *eventtime_value = get_value(input_values, inputs_, 1);
        int64_t now = get_feature_one_int64(input_values, inputs_, 2);
        const Value *out_value = nullptr;

        if (input_values.size() > 3) {
            out_value = get_value(input_values, inputs_, 3);
            output.values.resize(3);
        } else {
            output.values.resize(2);
        }

        uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());
        uint32_t values_size = output.values.size();

        for (uint32_t i = 0; i < values_size; i++) {
            Value &value = output.values[i];
            value.ifeatures.resize(input_size);
        }

        output.values[0].defalut_type = tensorflow::DT_INT64;
        output.values[1].defalut_type = tensorflow::DT_INT64;

        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_eventtime = nullptr;
        const InputFeature *inf_value = nullptr;
        std::vector<tensorflow::Feature *> out_feat(values_size);
        std::vector<tensorflow::FeatureList *> out_featlist(values_size);
        const tensorflow::Feature *feature = nullptr;

        for (uint32_t i = 0; i < input_size; i++) {
            inf_appid = &appid_value->ifeatures[i];
            inf_eventtime = &eventtime_value->ifeatures[i];
            if (out_value && out_value->ifeatures.size() > i) {
                inf_value = &out_value->ifeatures[i];
            } else {
                inf_value = nullptr;
            }

            std::vector<AppIdWithEventTime> appid_info_vec;
            std::vector<std::vector<int64_t>> appid_feat_value_index;
            int64_t count = 0;

            if (inf_appid->feature_list && inf_eventtime->feature_list) {
                for (uint32_t j = 0; j < values_size; j++) {
                    out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[j].ifeatures[i].feature_list = out_featlist[j];
                }

                uint32_t list_size =
                        std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());

                // val_list存在，过滤超出阈值的value
                if (out_value) {
                    get_value_feature(inf_value, 0, feature);
                    if (likely(feature)) {
                        appid_feat_value_index.resize(list_size);
                        // 过滤时间
                        for (uint32_t j = 0; j < list_size; j++) {
                            filter_compute_.fill_appid_vec_with_index(inf_appid->feature_list->feature(j),
                                                                      inf_eventtime->feature_list->feature(j), now,
                                                                      appid_info_vec, appid_feat_value_index[j]);
                        }

                        std::unordered_map<AppIdWithEventTime *, tensorflow::Feature> appid_values;
                        // 过滤阈值
                        filter_bound_value(appid_info_vec, appid_feat_value_index, inf_value, appid_values);
                        for (auto &elem: appid_info_vec) {
                            auto itr = appid_values.find(&elem);
                            if (itr != appid_values.end()) {
                                switch (itr->second.kind_case()) {
                                    case tensorflow::Feature::kBytesList: {
                                        output.values[2].defalut_type = tensorflow::DT_STRING;
                                        out_featlist[2]->add_feature()->mutable_bytes_list()->add_value(
                                                itr->second.bytes_list().value(0));
                                    } break;

                                    case tensorflow::Feature::kFloatList: {
                                        output.values[2].defalut_type = tensorflow::DT_FLOAT;
                                        out_featlist[2]->add_feature()->mutable_float_list()->add_value(
                                                itr->second.float_list().value(0));
                                    } break;

                                    case tensorflow::Feature::kInt64List: {
                                        output.values[2].defalut_type = tensorflow::DT_INT64;
                                        out_featlist[2]->add_feature()->mutable_int64_list()->add_value(
                                                itr->second.int64_list().value(0));
                                    } break;

                                    default: {
                                        continue;
                                    } break;
                                }
                                out_featlist[0]->add_feature()->mutable_int64_list()->add_value(elem.appid);
                                out_featlist[1]->add_feature()->mutable_int64_list()->add_value(elem.eventtime);
                                count++;
                            }

                            if (clip_size_ > 0 && count == clip_size_) {
                                break;
                            }
                        }
                    }

                } else {
                    for (uint32_t j = 0; j < list_size; j++) {
                        filter_compute_.fill_appid_vec(inf_appid->feature_list->feature(j),
                                                       inf_eventtime->feature_list->feature(j), now, appid_info_vec);
                    }
                    // 截断
                    if (clip_size_ > 0 && (int64_t) appid_info_vec.size() > clip_size_) {
                        appid_info_vec.resize(clip_size_);
                    }
                    for (const auto &elem: appid_info_vec) {
                        out_featlist[0]->add_feature()->mutable_int64_list()->add_value(elem.appid);
                        out_featlist[1]->add_feature()->mutable_int64_list()->add_value(elem.eventtime);
                    }
                }

            } else {
                for (uint32_t j = 0; j < values_size; j++) {
                    out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[j].ifeatures[i].feature = out_feat[j];
                }

                if (likely(inf_appid->feature && inf_eventtime->feature)) {
                    // val_list存在，过滤超出阈值的value
                    if (out_value) {
                        get_value_feature(inf_value, 0, feature);
                        if (likely(feature)) {
                            appid_feat_value_index.emplace_back();
                            // 过滤时间
                            filter_compute_.fill_appid_vec_with_index(*inf_appid->feature, *inf_eventtime->feature, now,
                                                                      appid_info_vec, appid_feat_value_index[0]);
                            std::unordered_map<AppIdWithEventTime *, tensorflow::Feature> appid_values;
                            // 过滤阈值
                            filter_bound_value(appid_info_vec, appid_feat_value_index, inf_value, appid_values);
                            for (auto &elem: appid_info_vec) {
                                auto itr = appid_values.find(&elem);
                                if (itr != appid_values.end()) {
                                    switch (itr->second.kind_case()) {
                                        case tensorflow::Feature::kBytesList: {
                                            output.values[2].defalut_type = tensorflow::DT_STRING;
                                            out_feat[2]->mutable_bytes_list()->add_value(
                                                    itr->second.bytes_list().value(0));
                                        } break;

                                        case tensorflow::Feature::kFloatList: {
                                            output.values[2].defalut_type = tensorflow::DT_FLOAT;
                                            out_feat[2]->mutable_float_list()->add_value(
                                                    itr->second.float_list().value(0));
                                        } break;

                                        case tensorflow::Feature::kInt64List: {
                                            output.values[2].defalut_type = tensorflow::DT_INT64;
                                            out_feat[2]->mutable_int64_list()->add_value(
                                                    itr->second.int64_list().value(0));
                                        } break;

                                        default: {
                                            continue;
                                        } break;
                                    }
                                    out_feat[0]->mutable_int64_list()->add_value(elem.appid);
                                    out_feat[1]->mutable_int64_list()->add_value(elem.eventtime);
                                    count++;
                                }
                                if (clip_size_ > 0 && count == clip_size_) {
                                    break;
                                }
                            }
                        }
                    } else {
                        filter_compute_.fill_appid_vec(*inf_appid->feature, *inf_eventtime->feature, now,
                                                       appid_info_vec);
                        // 截断
                        if (clip_size_ > 0 && (int64_t) appid_info_vec.size() > clip_size_) {
                            appid_info_vec.resize(clip_size_);
                        }
                        for (const auto &elem: appid_info_vec) {
                            out_feat[0]->mutable_int64_list()->add_value(elem.appid);
                            out_feat[1]->mutable_int64_list()->add_value(elem.eventtime);
                        }
                    }
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqValDirectV2Config::filter_bound_value(
            std::vector<AppIdWithEventTime> &appid_info_vec, std::vector<std::vector<int64_t>> &appid_feat_value_index,
            const InputFeature *inf_value,
            std::unordered_map<AppIdWithEventTime *, tensorflow::Feature> &appid_values) {
        const tensorflow::Feature *feature = nullptr;
        int64_t index = 0;
        for (uint32_t i = 0; i < appid_feat_value_index.size(); i++) {
            //  获取当前value字段的feature,feature获取失败不符合
            get_value_feature(inf_value, i, feature);
            if (feature) {
                switch (feature->kind_case()) {
                    case tensorflow::Feature::kBytesList: {
                        auto &value_vec = feature->bytes_list().value();
                        for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
                            if (value_vec.size() > appid_feat_value_index[i][j]) {
                                appid_values[&appid_info_vec[index]].mutable_bytes_list()->add_value(
                                        value_vec[appid_feat_value_index[i][j]]);
                            }
                            index++;
                        }
                    } break;

                    case tensorflow::Feature::kFloatList: {
                        auto &value_vec = feature->float_list().value();
                        for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
                            if (value_vec.size() > appid_feat_value_index[i][j]) {
                                const float value = value_vec[appid_feat_value_index[i][j]];

                                if ((!upper_bound_.flag_ && !lower_bound_.flag_) /* // 不设置阈值, 不过滤 */
                                    || (upper_bound_.flag_ && !lower_bound_.flag_ &&
                                        value <= upper_bound_.value_) /* 设置了阈值上限, value <= upper_bound_ */
                                    || (!upper_bound_.flag_ && lower_bound_.flag_ &&
                                        value >= lower_bound_.value_) /* 设置了阈值下限, value >= upper_bound_ */
                                    ||
                                    (upper_bound_.flag_ && lower_bound_.flag_ && value <= upper_bound_.value_ &&
                                     value >= lower_bound_
                                                      .value_) /* 同时设置上下限, lower_bound_ <= x <=upper_bound_ */) {
                                    appid_values[&appid_info_vec[index]].mutable_float_list()->add_value(value);
                                }
                            }
                            index++;
                        }
                    } break;

                    case tensorflow::Feature::kInt64List: {
                        auto &value_vec = feature->int64_list().value();
                        for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
                            if (value_vec.size() > appid_feat_value_index[i][j]) {
                                const int64_t value = value_vec[appid_feat_value_index[i][j]];
                                if ((!upper_bound_.flag_ && !lower_bound_.flag_) /* // 不设置阈值, 不过滤 */
                                    || (upper_bound_.flag_ && !lower_bound_.flag_ &&
                                        value <= upper_bound_.value_) /* 设置了阈值上限, value <= upper_bound_ */
                                    || (!upper_bound_.flag_ && lower_bound_.flag_ &&
                                        value >= lower_bound_.value_) /* 设置了阈值下限, value >= upper_bound_ */
                                    ||
                                    (upper_bound_.flag_ && lower_bound_.flag_ && value <= upper_bound_.value_ &&
                                     value >= lower_bound_
                                                      .value_) /* 同时设置上下限, lower_bound_ <= x <=upper_bound_ */) {
                                    appid_values[&appid_info_vec[index]].mutable_int64_list()->add_value(value);
                                }
                            }
                            index++;
                        }
                    } break;

                    default: {
                        index += appid_feat_value_index[i].size();
                    } break;
                }

            } else {
                index += appid_feat_value_index[i].size();
            }
        }
    }

    bool SeqByInterConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqByInterConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *message_value = get_value(input_values, inputs_, 0);
        const Value *item_value = get_value(input_values, inputs_, 1);

        const uint32_t message_size = message_value->ifeatures.size();
        const uint32_t batch_size = item_value->ifeatures.size();
        const InputFeature *inf = nullptr;
        uint32_t extract_size = fields_.size();
        std::vector<tensorflow::Feature *> out_feat(extract_size);
        std::vector<tensorflow::FeatureList *> out_featlist(extract_size);

        output.values.resize(extract_size);
        for (uint32_t i = 0; i < extract_size; i++) {
            Value &value = output.values[i];
            value.ifeatures.resize(batch_size);
        }
        MessageCompute::message_fill_fields_dtype_to_value(message_value, fields_, output.values, output_);

        std::unordered_map<int64_t, std::vector<uint32_t>> index_map;
        const InputFeature *inf_message = nullptr;
        const google::protobuf::Message *mess = nullptr;

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            inf_message = get_idx_ifeatures(message_value, i);
            //取对应的字段的值和索引
            if (i == 0 || batch_size == message_size) {
                index_map.clear();
                for (uint32_t j = 0; j < inf_message->messages.size(); j++) {
                    mess = inf_message->messages[j];
                    auto desc = mess->GetDescriptor();
                    auto ref = mess->GetReflection();
                    auto field = desc->FindFieldByName(inter_key_);

                    if (unlikely(nullptr == ref || nullptr == field)) {
                        THROW_ERROR("failed, get null_ptr on inter_key:" + inter_key_ + ", name:" + output_);
                        return false;
                    }

                    if (field->cpp_type() != google::protobuf::FieldDescriptor::CPPTYPE_INT64) {
                        THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) +
                                    " inter_key:" + inter_key_ + " name:" + output_);
                        return false;
                    }

                    if (ref->HasField(*mess, field)) {
                        index_map[ref->GetInt64(*mess, field)].push_back(j);
                    }
                }
            }

            inf = get_idx_ifeatures(item_value, i);
            if (inf->feature_list) {
                for (uint32_t j = 0; j < extract_size; j++) {
                    out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[j].ifeatures[i].feature_list = out_featlist[j];
                }

                for (auto &feat: inf->feature_list->feature()) {
                    for (uint32_t j = 0; j < extract_size; j++) {
                        out_feat[j] = out_featlist[j]->add_feature();
                    }
                    compute_one_feature(feat, index_map, inf_message, out_feat);
                }
            } else {
                for (uint32_t j = 0; j < extract_size; j++) {
                    out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[j].ifeatures[i].feature = out_feat[j];
                }

                if (likely(inf->feature)) {
                    compute_one_feature(*inf->feature, index_map, inf_message, out_feat);
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqByInterConfig::compute_one_feature(const tensorflow::Feature &feat,
                                               std::unordered_map<int64_t, std::vector<uint32_t>> &index_map,
                                               const InputFeature *inf_message,
                                               std::vector<tensorflow::Feature *> &out_feat) {
        const google::protobuf::Message *mess = nullptr;
        for (int64_t appid: feat.int64_list().value()) {
            auto itr = index_map.find(appid);
            if (itr != index_map.end()) {
                auto &vec = itr->second;
                for (uint32_t i = 0; i < vec.size(); i++) {
                    // 获取id对应的message
                    mess = inf_message->messages[vec[i]];
                    MessageCompute::message_fill_fields_to_feature(mess, fields_, output_, out_feat);
                }
            }
        }
    }

    bool SeqMergeConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqMergeConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *off_message_value = get_value(input_values, inputs_, 0);
        const Value *nl_message_value = get_value(input_values, inputs_, 1);

        uint32_t input1_size = off_message_value->ifeatures.size();
        uint32_t input2_size = nl_message_value->ifeatures.size();

        // 不支持user数据和item数据之间，进行有效值代替读取
        if (input1_size != input2_size) {
            THROW_ERROR("invalid source, input1_value_size not euqal input2_value_size, name:" + output_);
            return false;
        }

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(input1_size);

        const InputFeature *inf_value1 = nullptr;
        const InputFeature *inf_value2 = nullptr;

        for (uint32_t i = 0; i < input1_size; i++) {
            inf_value1 = &off_message_value->ifeatures[i];
            inf_value2 = &nl_message_value->ifeatures[i];

            int64_t max = -1;
            std::vector<std::pair<int64_t, const google::protobuf::Message *>> time_vec;
            std::vector<const google::protobuf::Message *> topn_vec;

            //获取离线信息和时间
            fill_message_to_vec(inf_value1, max, time_vec);
            //获取大于离线max时间的近线信息和时间
            fill_message_to_vec(inf_value2, max, time_vec);

            //排序
            top_n_compute_.compute_vec<int64_t>(time_vec, topn_vec);

            for (auto &mess: topn_vec) {
                value.ifeatures[i].messages.push_back(mess);
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void
    SeqMergeConfig::fill_message_to_vec(const InputFeature *mess_value, int64_t &max,
                                        std::vector<std::pair<int64_t, const google::protobuf::Message *>> &time_vec) {
        if (mess_value) {
            const google::protobuf::Message *mess = nullptr;
            int64_t time = 0;
            int64_t max_time = 0;

            for (uint32_t i = 0; i < mess_value->messages.size(); i++) {
                mess = mess_value->messages[i];
                MessageCompute::message_fill_to_int64(mess, eventtime_key_, output_, time);

                if (time > max) {
                    time_vec.emplace_back(time, mess);
                    max_time = std::max(time, max_time);
                }
            }

            if (max < 0) {
                max = max_time;
            }
        }
    }

    bool SeqNConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqNConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *eventtime_value = get_value(input_values, inputs_, 1);
        int64_t now = get_feature_one_int64(input_values, inputs_, 2);

        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_eventtime = nullptr;

        uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_INT64;
        value.ifeatures.resize(input_size);

        for (uint32_t i = 0; i < input_size; i++) {
            inf_appid = &appid_value->ifeatures[i];
            inf_eventtime = &eventtime_value->ifeatures[i];

            std::vector<AppIdWithEventTime> appid_info_vec;
            std::vector<AppIdWithEventTime *> appid_info_vec_ptr;
            std::unordered_map<int64_t, int64_t> appid_map;

            if (inf_appid->feature_list && inf_eventtime->feature_list) {
                uint32_t list_size =
                        std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());
                for (uint32_t j = 0; j < list_size; j++) {
                    filter_compute_.fill_time_map(inf_appid->feature_list->feature(j),
                                                  inf_eventtime->feature_list->feature(j), now, appid_map);
                }

                appid_info_vec.reserve(appid_map.size());

                for (const auto &item: appid_map) {
                    appid_info_vec.emplace_back(item.first, item.second);
                }
                top_n_compute_.compute_vec(appid_info_vec, appid_info_vec_ptr);

                tensorflow::FeatureList *out_feature_list = nullptr;
                out_feature_list = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_feature_list;

                //空值处理
                if (appid_info_vec_ptr.empty()) {
                    if (!allow_empty_output_) {
                        out_feature_list->add_feature()->mutable_int64_list()->add_value(default_value_);
                    }
                } else {
                    for (const auto &item: appid_info_vec_ptr) {
                        out_feature_list->add_feature()->mutable_int64_list()->add_value(item->appid);
                    }
                }
            } else {
                tensorflow::Feature *out_feature = nullptr;
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (likely(inf_appid->feature && inf_eventtime->feature)) {
                    filter_compute_.fill_time_map(*inf_appid->feature, *inf_eventtime->feature, now, appid_map);
                    //用于将map内容转移至vector排序并截断
                    appid_info_vec.reserve(appid_map.size());

                    for (const auto &item: appid_map) {
                        appid_info_vec.emplace_back(item.first, item.second);
                    }
                    top_n_compute_.compute_vec(appid_info_vec, appid_info_vec_ptr);
                }

                //空值处理
                if (appid_info_vec_ptr.empty()) {
                    if (!allow_empty_output_) {
                        out_feature->mutable_int64_list()->add_value(default_value_);
                    }
                } else {
                    for (const auto &item: appid_info_vec_ptr) {
                        out_feature->mutable_int64_list()->add_value(item->appid);
                    }
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqAppCategoryTopNConfig::fill_class_vec(std::vector<AppIdWithEventTime> &appid_vec,
                                                  const std::vector<const phx::AppInfoDict *> &query_dict_result,
                                                  std::vector<std::vector<ClassNameWithEventTime>> &class_count) {
        for (uint32_t i = 0; i < class_count.size(); i++) {
            class_count[i].reserve(appid_vec.size());
        }
        for (uint32_t i = 0; i < appid_vec.size(); i++) {
            auto &app_info_pb = query_dict_result[i];
            if (app_info_pb != nullptr) {
                class_count[0].emplace_back(&app_info_pb->first_class(), appid_vec[i].eventtime);
                class_count[1].emplace_back(&app_info_pb->second_class(), appid_vec[i].eventtime);
                class_count[2].emplace_back(&app_info_pb->third_class(), appid_vec[i].eventtime);
            }
        }
    }
    bool SeqAppCategoryTopNConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqAppCategoryTopNConfig::compute");

        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *eventtime_value = get_value(input_values, inputs_, 1);
        int64_t now = get_feature_one_int64(input_values, inputs_, 2);

        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_eventtime = nullptr;

        uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

        //对应三个级别的类目
        output.values.resize(3);
        for (uint32_t i = 0; i < 3; i++) {
            Value &value = output.values[i];
            value.defalut_type = tensorflow::DT_STRING;
            value.ifeatures.resize(input_size);
        }

        for (uint32_t index_of_batch = 0; index_of_batch < input_size; index_of_batch++) {
            inf_appid = &appid_value->ifeatures[index_of_batch];
            inf_eventtime = &eventtime_value->ifeatures[index_of_batch];

            std::vector<AppIdWithEventTime> appid_vec;
            std::vector<std::vector<ClassNameWithEventTime>> class_count(3);
            std::vector<std::vector<ClassNameWithEventTime *>> sorted_class_count_ptr(3);
            if (inf_appid->feature && inf_eventtime->feature) {
                std::vector<tensorflow::Feature *> out_int_feat(3);
                for (size_t index_of_class = 0; index_of_class < 3; index_of_class++) {
                    out_int_feat[index_of_class] =
                            google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[index_of_class].ifeatures[index_of_batch].feature = out_int_feat[index_of_class];
                }
                filter_compute_.fill_appid_vec(*inf_appid->feature, *inf_eventtime->feature, now, appid_vec);
                std::vector<const phx::AppInfoDict *> query_dict_result;
                query_dict_result.reserve(appid_vec.size());
                for (const auto &elem: appid_vec) {
                    const phx::AppInfoDict *result = dict_collector_->get_appinfo(dict_name_, elem.appid);
                    query_dict_result.emplace_back(result);
                }
                fill_class_vec(appid_vec, query_dict_result, class_count);
                top_n_compute_.compute_vec(class_count[0], &sorted_class_count_ptr[0]);
                top_n_compute_.compute_vec(class_count[1], &sorted_class_count_ptr[1]);
                top_n_compute_.compute_vec(class_count[2], &sorted_class_count_ptr[2]);

                for (size_t index_of_class = 0; index_of_class < 3; index_of_class++) {
                    if (sorted_class_count_ptr[index_of_class].empty()) {
                        if (!allow_empty_output_) {
                            out_int_feat[index_of_class]->mutable_bytes_list()->add_value(default_value_);
                        }
                    } else {
                        for (const auto &class_count: sorted_class_count_ptr[index_of_class]) {
                            out_int_feat[index_of_class]->mutable_bytes_list()->add_value(*(class_count->class_name));
                        }
                    }
                }
            } else if (inf_appid->feature_list && inf_eventtime->feature_list) {
                int32_t list_size =
                        std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());
                for (int32_t index_of_feature = 0; index_of_feature < list_size; index_of_feature++) {
                    filter_compute_.fill_appid_vec(inf_appid->feature_list->feature(index_of_feature),
                                                   inf_eventtime->feature_list->feature(index_of_feature), now,
                                                   appid_vec);
                }

                std::vector<const phx::AppInfoDict *> query_dict_result;
                query_dict_result.reserve(appid_vec.size());
                for (const auto &elem: appid_vec) {
                    query_dict_result.emplace_back(dict_collector_->get_appinfo(dict_name_, elem.appid));
                }
                fill_class_vec(appid_vec, query_dict_result, class_count);
                top_n_compute_.compute_vec(class_count[0], &sorted_class_count_ptr[0]);
                top_n_compute_.compute_vec(class_count[1], &sorted_class_count_ptr[1]);
                top_n_compute_.compute_vec(class_count[2], &sorted_class_count_ptr[2]);

                std::vector<tensorflow::FeatureList *> out_int_featlsit(3);
                for (size_t index_of_class = 0; index_of_class < 3; index_of_class++) {
                    out_int_featlsit[index_of_class] =
                            google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[index_of_class].ifeatures[index_of_batch].feature_list =
                            out_int_featlsit[index_of_class];
                    if (sorted_class_count_ptr[index_of_class].empty()) {
                        if (!allow_empty_output_) {
                            out_int_featlsit[index_of_class]->add_feature()->mutable_bytes_list()->add_value(
                                    default_value_);
                        }
                    } else {
                        for (const auto &class_count: sorted_class_count_ptr[index_of_class]) {
                            out_int_featlsit[index_of_class]->add_feature()->mutable_bytes_list()->add_value(
                                    *class_count->class_name);
                        }
                    }
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    bool SeqApp2CategoryConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqApp2CategoryConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *eventtime_value = get_value(input_values, inputs_, 1);
        int64_t now = get_feature_one_int64(input_values, inputs_, 2);

        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_eventtime = nullptr;

        uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

        output.values.resize(3);
        for (uint32_t i = 0; i < 3; i++) {
            Value &value = output.values[i];
            value.defalut_type = tensorflow::DT_STRING;
            value.ifeatures.resize(input_size);
        }

        std::vector<tensorflow::Feature *> out_int_feat(3);
        std::vector<tensorflow::FeatureList *> out_int_featlsit(3);

        for (uint32_t i = 0; i < input_size; i++) {
            inf_appid = &appid_value->ifeatures[i];
            inf_eventtime = &eventtime_value->ifeatures[i];

            std::vector<AppIdWithEventTime> appid_info_vec;
            std::vector<AppIdWithEventTime *> appid_info_vec_ptr;

            if (inf_appid->feature_list && inf_eventtime->feature_list) {
                uint32_t list_size =
                        std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());
                //防穿越
                for (uint32_t j = 0; j < list_size; j++) {
                    filter_compute_.fill_appid_vec(inf_appid->feature_list->feature(j),
                                                   inf_eventtime->feature_list->feature(j), now, appid_info_vec);
                }

                //时间戳从大到小排序
                top_n_compute_.compute_vec(appid_info_vec, appid_info_vec_ptr);

                for (uint32_t j = 0; j < 3; j++) {
                    out_int_featlsit[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[j].ifeatures[0].feature_list = out_int_featlsit[j];
                }

                if (!appid_info_vec_ptr.empty()) {
                    compute_one_featurelist(appid_info_vec_ptr, out_int_featlsit);
                }

                if (!allow_empty_output_) {
                    for (uint32_t j = 0; j < 3; j++) {
                        if (out_int_featlsit[j]->feature_size() < 1) {
                            out_int_featlsit[j]->add_feature()->mutable_bytes_list()->add_value(default_value_);
                        }
                    }
                }
            } else {
                for (uint32_t j = 0; j < 3; j++) {
                    out_int_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[j].ifeatures[i].feature = out_int_feat[j];
                }

                if (likely(inf_appid->feature && inf_eventtime->feature)) {
                    //防穿越
                    filter_compute_.fill_appid_vec(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_vec);

                    //时间戳从大到小排序
                    top_n_compute_.compute_vec(appid_info_vec, appid_info_vec_ptr);
                }

                if (!appid_info_vec_ptr.empty()) {
                    compute_one_feature(appid_info_vec_ptr, out_int_feat);
                }

                if (!allow_empty_output_) {
                    for (uint32_t j = 0; j < 3; j++) {
                        if (out_int_feat[j]->bytes_list().value_size() < 1) {
                            out_int_feat[j]->mutable_bytes_list()->add_value(default_value_);
                        }
                    }
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqApp2CategoryConfig::compute_one_feature(std::vector<AppIdWithEventTime *> &appid_info_vec_ptr,
                                                    std::vector<tensorflow::Feature *> &out_int_feat) {
        // dedup_ 去重
        if (dedup_) {
            std::vector<std::unordered_set<std::string>> class_set(3);
            for (auto &set: class_set) {
                set.reserve(appid_info_vec_ptr.size());
            }
            for (const auto &item: appid_info_vec_ptr) {
                const auto *app_info = dict_collector_->get_appinfo(dict_name_, item->appid);

                if (app_info != nullptr) {
                    if ((clip_size_ < 0 || out_int_feat[0]->bytes_list().value_size() < clip_size_) &&
                        class_set[0].insert(app_info->first_class()).second) {
                        out_int_feat[0]->mutable_bytes_list()->add_value(app_info->first_class());
                    }
                    if ((clip_size_ < 0 || out_int_feat[1]->bytes_list().value_size() < clip_size_) &&
                        class_set[1].insert(app_info->second_class()).second) {
                        out_int_feat[1]->mutable_bytes_list()->add_value(app_info->second_class());
                    }

                    if ((clip_size_ < 0 || out_int_feat[2]->bytes_list().value_size() < clip_size_) &&
                        class_set[2].insert(app_info->second_class()).second) {
                        out_int_feat[2]->mutable_bytes_list()->add_value(app_info->third_class());
                    }

                    if (clip_size_ > 0 && clip_size_ == out_int_feat[0]->bytes_list().value_size() &&
                        clip_size_ == out_int_feat[1]->bytes_list().value_size() &&
                        clip_size_ == out_int_feat[2]->bytes_list().value_size()) {
                        return;
                    }
                }
            }
        } else {
            for (const auto &item: appid_info_vec_ptr) {
                const auto *app_info = dict_collector_->get_appinfo(dict_name_, item->appid);
                if (app_info != nullptr) {
                    if (clip_size_ < 0 || clip_size_ > out_int_feat[0]->bytes_list().value_size()) {
                        out_int_feat[0]->mutable_bytes_list()->add_value(app_info->first_class());
                        out_int_feat[1]->mutable_bytes_list()->add_value(app_info->second_class());
                        out_int_feat[2]->mutable_bytes_list()->add_value(app_info->third_class());
                    } else {
                        return;
                    }
                }
            }
        }
    }

    void SeqApp2CategoryConfig::compute_one_featurelist(std::vector<AppIdWithEventTime *> &appid_info_vec_ptr,
                                                        std::vector<tensorflow::FeatureList *> &out_int_featlist) {
        //是否去重，dedup_为true去重，false不去重
        if (dedup_) {
            std::vector<std::unordered_set<std::string>> class_set(3);
            for (auto &set: class_set) {
                set.reserve(appid_info_vec_ptr.size());
            }
            for (const auto &item: appid_info_vec_ptr) {
                auto appinfo = dict_collector_->get_appinfo(dict_name_, item->appid);
                if (appinfo != nullptr) {

                    if ((clip_size_ < 0 || out_int_featlist[0]->feature_size() < clip_size_) &&
                        class_set[0].insert(appinfo->first_class()).second) {
                        out_int_featlist[0]->add_feature()->mutable_bytes_list()->add_value(appinfo->first_class());
                    }
                    if ((clip_size_ < 0 || out_int_featlist[1]->feature_size() < clip_size_) &&
                        class_set[1].insert(appinfo->second_class()).second) {
                        out_int_featlist[1]->add_feature()->mutable_bytes_list()->add_value(appinfo->second_class());
                    }

                    if ((clip_size_ < 0 || out_int_featlist[2]->feature_size() < clip_size_) &&
                        class_set[2].insert(appinfo->second_class()).second) {
                        out_int_featlist[2]->add_feature()->mutable_bytes_list()->add_value(appinfo->third_class());
                    }

                    if (clip_size_ > 0 && clip_size_ == out_int_featlist[0]->feature_size() &&
                        clip_size_ == out_int_featlist[1]->feature_size() &&
                        clip_size_ == out_int_featlist[2]->feature_size()) {
                        return;
                    }
                }
            }
        } else {
            for (const auto &item: appid_info_vec_ptr) {
                auto appinfo = dict_collector_->get_appinfo(dict_name_, item->appid);
                if (appinfo != nullptr) {
                    if (clip_size_ < 0 || clip_size_ > out_int_featlist[0]->feature_size()) {
                        out_int_featlist[0]->add_feature()->mutable_bytes_list()->add_value(appinfo->first_class());
                        out_int_featlist[1]->add_feature()->mutable_bytes_list()->add_value(appinfo->second_class());
                        out_int_featlist[2]->add_feature()->mutable_bytes_list()->add_value(appinfo->third_class());
                    } else {
                        return;
                    }
                }
            }
        }
    }

    bool SeqNHourConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqNHourConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *eventtime_value = get_value(input_values, inputs_, 1);
        int64_t now = get_feature_one_int64(input_values, inputs_, 2);

        uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

        output.values.resize(2);
        for (uint32_t i = 0; i < output.values.size(); i++) {
            Value &value = output.values[i];
            value.ifeatures.resize(input_size);
        }
        output.values[0].defalut_type = tensorflow::DT_INT64;
        output.values[1].defalut_type = tensorflow::DT_INT64;

        std::vector<tensorflow::Feature *> out_feat(output.values.size());
        std::vector<tensorflow::FeatureList *> out_featlist(output.values.size());
        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_eventtime = nullptr;

        for (uint32_t i = 0; i < input_size; i++) {
            inf_appid = &appid_value->ifeatures[i];
            inf_eventtime = &eventtime_value->ifeatures[i];

            std::vector<AppIdWithEventTime> appid_info_vec;
            std::vector<const AppIdWithEventTime *> appid_ptr_vec;

            if (inf_appid->feature_list && inf_eventtime->feature_list) {
                for (uint32_t j = 0; j < output.values.size(); j++) {
                    out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[j].ifeatures[i].feature_list = out_featlist[j];
                }

                uint32_t list_size =
                        std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());
                // 筛选指定时间范围内的数据
                for (uint32_t j = 0; j < list_size; j++) {
                    filter_compute_.fill_appid_vec(inf_appid->feature_list->feature(j),
                                                   inf_eventtime->feature_list->feature(j), now, appid_info_vec);
                }
                // 筛选所在小时前后n小时的数据
                filter_appid_by_hour(now, appid_info_vec, appid_ptr_vec);

                for (const auto &elem: appid_ptr_vec) {
                    out_featlist[0]->add_feature()->mutable_int64_list()->add_value(elem->appid);
                    out_featlist[1]->add_feature()->mutable_int64_list()->add_value(elem->eventtime);
                }
            } else {
                for (uint32_t j = 0; j < output.values.size(); j++) {
                    out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[j].ifeatures[i].feature = out_feat[j];
                }

                if (likely(inf_appid->feature && inf_eventtime->feature)) {
                    filter_compute_.fill_appid_vec(*inf_appid->feature, *inf_eventtime->feature, now, appid_info_vec);
                    filter_appid_by_hour(now, appid_info_vec, appid_ptr_vec);

                    for (const auto &elem: appid_ptr_vec) {
                        out_feat[0]->mutable_int64_list()->add_value(elem->appid);
                        out_feat[1]->mutable_int64_list()->add_value(elem->eventtime);
                    }
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqNHourConfig::filter_appid_by_hour(int64_t now, std::vector<AppIdWithEventTime> &appid_info_vec,
                                              std::vector<const AppIdWithEventTime *> &appid_ptr_vec) {
        int64_t req_hour = ((now / 1000 / 3600) + 8) % 24;//东八区时区
        int64_t cross_hour = 24 - hour_;
        int64_t event_hour = 0;
        int64_t difference = 0;
        for (const auto &elem: appid_info_vec) {
            event_hour = ((elem.eventtime / 1000 / 3600) + 8) % 24;//东八区时区
            difference = std::abs(req_hour - event_hour);
            if (difference <= hour_ || difference >= cross_hour) {
                appid_ptr_vec.push_back(&elem);
            }
        }
    }

    bool SeqTopNV2Config::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqTopNV2Config::compute");
        LogDebug("------------ compute {} start ------------", output_);
        DataType out_type = DataType::DATATYPE_INT64;
        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *eventtime_value = get_value(input_values, inputs_, 1);
        const Value *out_value = nullptr;
        if (top_n_compute_.get_type() == SortType::ByValue) {
            out_value = get_value(input_values, inputs_, 2);
        }

        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_eventtime = nullptr;
        const InputFeature *inf_value = nullptr;

        uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

        output.values.resize(2);
        for (uint32_t i = 0; i < 2; i++) {
            Value &value = output.values[i];
            value.ifeatures.resize(input_size);
        }
        std::vector<tensorflow::Feature *> out_feat(2);
        std::vector<tensorflow::FeatureList *> out_featlist(2);

        for (uint32_t i = 0; i < input_size; ++i) {
            inf_appid = &appid_value->ifeatures[i];
            inf_eventtime = &eventtime_value->ifeatures[i];
            if (out_value && out_value->ifeatures.size() > i) {
                inf_value = &out_value->ifeatures[i];
            } else {
                inf_value = nullptr;
            }

            std::vector<AppIdWithEventTime> appid_info_vec;
            std::vector<std::vector<int64_t>> appid_feat_value_index;
            get_value_type(inf_value, out_type);

            if (inf_appid->feature_list && inf_eventtime->feature_list) {
                for (uint32_t j = 0; j < 2; j++) {
                    out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[j].ifeatures[i].feature_list = out_featlist[j];
                }

                uint32_t list_size =
                        std::min(inf_appid->feature_list->feature_size(), inf_eventtime->feature_list->feature_size());
                appid_feat_value_index.resize(list_size);
                //填充数据和位移
                for (uint32_t j = 0; j < list_size; j++) {
                    fill_appid_vec_with_index(inf_appid->feature_list->feature(j),
                                              inf_eventtime->feature_list->feature(j), appid_info_vec,
                                              appid_feat_value_index[j]);
                }

                if (out_type == DataType::DATATYPE_INT64) {
                    std::unordered_map<AppIdWithEventTime *, int64_t> appid_values;
                    std::vector<std::pair<int64_t, int64_t>> out_vec;
                    appid_values.reserve(appid_info_vec.size());
                    //如果inf_value不为空，获取对应的值
                    fill_feature_value<int64_t>(appid_info_vec, appid_feat_value_index, inf_value, appid_values);
                    //按照type类型排序
                    top_n_compute_.compute_vec_with_value<int64_t>(appid_info_vec, appid_values, out_vec);

                    for (const auto &pair: out_vec) {
                        out_featlist[0]->add_feature()->mutable_int64_list()->add_value(pair.first);
                        out_featlist[1]->add_feature()->mutable_int64_list()->add_value(pair.second);
                    }
                } else if (out_type == DataType::DATATYPE_FLOAT) {
                    std::unordered_map<AppIdWithEventTime *, float> appid_values;
                    std::vector<std::pair<int64_t, float>> out_vec;
                    appid_values.reserve(appid_info_vec.size());
                    //如果inf_value不为空，获取对应的值
                    fill_feature_value<float>(appid_info_vec, appid_feat_value_index, inf_value, appid_values);
                    //按照type类型排序
                    top_n_compute_.compute_vec_with_value<float>(appid_info_vec, appid_values, out_vec);

                    for (const auto &pair: out_vec) {
                        out_featlist[0]->add_feature()->mutable_int64_list()->add_value(pair.first);
                        out_featlist[1]->add_feature()->mutable_float_list()->add_value(pair.second);
                    }
                }
            } else {
                for (uint32_t j = 0; j < 2; j++) {
                    out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[j].ifeatures[i].feature = out_feat[j];
                }

                if (likely(inf_appid->feature && inf_eventtime->feature)) {
                    appid_feat_value_index.emplace_back();
                    //填充数据和位移
                    fill_appid_vec_with_index(*inf_appid->feature, *inf_eventtime->feature, appid_info_vec,
                                              appid_feat_value_index[0]);

                    if (out_type == DataType::DATATYPE_INT64) {
                        std::unordered_map<AppIdWithEventTime *, int64_t> appid_values;
                        std::vector<std::pair<int64_t, int64_t>> out_vec;
                        appid_values.reserve(appid_info_vec.size());
                        //如果inf_value不为空，获取对应的值
                        fill_feature_value<int64_t>(appid_info_vec, appid_feat_value_index, inf_value, appid_values);
                        //按照type类型排序
                        top_n_compute_.compute_vec_with_value<int64_t>(appid_info_vec, appid_values, out_vec);

                        for (const auto &pair: out_vec) {
                            out_feat[0]->mutable_int64_list()->add_value(pair.first);
                            out_feat[1]->mutable_int64_list()->add_value(pair.second);
                        }
                    } else if (out_type == DataType::DATATYPE_FLOAT) {
                        std::unordered_map<AppIdWithEventTime *, float> appid_values;
                        std::vector<std::pair<int64_t, float>> out_vec;
                        appid_values.reserve(appid_info_vec.size());
                        //如果inf_value不为空，获取对应的值
                        fill_feature_value<float>(appid_info_vec, appid_feat_value_index, inf_value, appid_values);
                        //按照type类型排序
                        top_n_compute_.compute_vec_with_value<float>(appid_info_vec, appid_values, out_vec);

                        for (const auto &pair: out_vec) {
                            out_feat[0]->mutable_int64_list()->add_value(pair.first);
                            out_feat[1]->mutable_float_list()->add_value(pair.second);
                        }
                    }
                }
            }
        }

        output.values[0].defalut_type = tensorflow::DT_INT64;
        output.values[1].defalut_type = static_cast<tensorflow::DataType>(out_type);

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqTopNV2Config::fill_appid_vec_with_index(const tensorflow::Feature &appid_feat,
                                                    const tensorflow::Feature &time_feat,
                                                    std::vector<AppIdWithEventTime> &appid_info_vec,
                                                    std::vector<int64_t> &appid_index) {
        auto &appid_vec = appid_feat.int64_list().value();
        auto &eventtime_vec = time_feat.int64_list().value();
        uint32_t list_size = std::min(appid_vec.size(), eventtime_vec.size());
        appid_info_vec.reserve(appid_info_vec.size() + list_size);
        appid_index.resize(list_size);

        for (uint32_t i = 0; i < list_size; i++) {
            appid_info_vec.emplace_back(appid_vec[i], eventtime_vec[i]);
            appid_index[i] = i;
        }
    }

    void SeqTopNV2Config::get_value_type(const InputFeature *inf_value, DataType &type) {
        const tensorflow::Feature *feature = nullptr;
        if (inf_value) {
            if (inf_value->feature_list && inf_value->feature_list->feature_size() > 0) {
                feature = &inf_value->feature_list->feature(0);
            } else if (inf_value->feature) {
                feature = inf_value->feature;
            } else {
                type = DataType::DATATYPE_UNKNOWN;
            }
            if (feature) {
                switch (feature->kind_case()) {
                    case tensorflow::Feature::kBytesList: {
                        type = DataType::DATATYPE_STRING;
                    } break;

                    case tensorflow::Feature::kFloatList: {
                        type = DataType::DATATYPE_FLOAT;
                    } break;

                    case tensorflow::Feature::kInt64List: {
                        type = DataType::DATATYPE_INT64;
                    } break;

                    default: {
                        type = DataType::DATATYPE_UNKNOWN;
                    } break;
                }
            }
        }
    }

    template<typename T>
    void SeqTopNV2Config::fill_feature_value(std::vector<AppIdWithEventTime> &appid_info_vec,
                                             std::vector<std::vector<int64_t>> &appid_feat_value_index,
                                             const InputFeature *inf_value,
                                             std::unordered_map<AppIdWithEventTime *, T> &appid_values) {
        const tensorflow::Feature *feature = nullptr;
        if (inf_value) {
            int64_t index = 0;
            for (uint32_t i = 0; i < appid_feat_value_index.size(); i++) {
                //获取当前value字段的feature,feature获取失败不符合
                if (inf_value->feature_list && inf_value->feature_list->feature_size() > (int64_t) i) {
                    feature = &inf_value->feature_list->feature(i);
                } else if (inf_value->feature) {
                    feature = inf_value->feature;
                } else {
                    index += appid_feat_value_index[i].size();
                    continue;
                }
                if (std::is_same<T, int64_t>::value) {
                    auto &value_vec = feature->int64_list().value();
                    for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
                        if (value_vec.size() > appid_feat_value_index[i][j]) {
                            appid_values[&appid_info_vec[index]] =
                                    static_cast<T>(value_vec[appid_feat_value_index[i][j]]);
                        }
                        index++;
                    }
                } else if (std::is_same<T, float>::value) {
                    auto &value_vec = feature->float_list().value();
                    for (uint32_t j = 0; j < appid_feat_value_index[i].size(); j++) {
                        if (value_vec.size() > appid_feat_value_index[i][j]) {
                            appid_values[&appid_info_vec[index]] =
                                    static_cast<T>(value_vec[appid_feat_value_index[i][j]]);
                        }
                        index++;
                    }
                }
            }
        }
    }

    void SeqHitCountV1Config::generate_output(const Value *item_value, std::unordered_map<int64_t, int64_t> &count_map,
                                              Output &output, bool has_input) {
        const uint32_t batch_size = item_value->ifeatures.size();
        const InputFeature *inf = nullptr;
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &item_value->ifeatures[i];

            if (inf->feature_list) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;

                for (auto &feat: inf->feature_list->feature()) {
                    compute_one_feature(feat, count_map, out_featurelist->add_feature(), has_input);
                }
                if ((out_featurelist->feature_size() == 0) && !allow_empty_output_) {
                    fill_default_value(out_featurelist->add_feature());
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (likely(inf->feature)) {
                    compute_one_feature(*inf->feature, count_map, out_feature, has_input);
                } else if (!allow_empty_output_) {
                    fill_default_value(out_feature);
                }
            }
        }

        fill_value_dtype(value.defalut_type);
    }

    void SeqHitCountV1Config::compute_one_feature(const tensorflow::Feature &feat,
                                                  std::unordered_map<int64_t, int64_t> &count_map,
                                                  tensorflow::Feature *out, bool has_input) {
        int32_t count = 0;
        if (has_input) {
            for (const int64_t &appid: feat.int64_list().value()) {
                auto itr = count_map.find(appid);
                count = (itr != count_map.end() ? itr->second : 0);
                out->mutable_int64_list()->add_value(count > max_num_ ? max_num_ : count);
            }
        }
        if (!allow_empty_output_) {
            fill_default_value(out);
        }
    }

    void SeqHitCountV2Config::generate_output(const Value *item_value, std::unordered_map<int64_t, int64_t> &count_map,
                                              Output &output, bool has_input) {
        const InputFeature *inf = nullptr;
        tensorflow::Feature *out_feature_bool = nullptr;
        tensorflow::Feature *out_feature_count = nullptr;
        tensorflow::FeatureList *out_featurelist_bool = nullptr;
        tensorflow::FeatureList *out_featurelist_count = nullptr;
        const uint32_t batch_size = item_value->ifeatures.size();

        output.values.resize(2);
        Value &value_bool = output.values[0];
        Value &value_count = output.values[1];
        fill_value_dtype(value_bool.defalut_type);
        fill_value_dtype(value_count.defalut_type);

        value_bool.ifeatures.resize(batch_size);
        value_count.ifeatures.resize(batch_size);

        LogDebug("batch_size:{}", batch_size);

        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &item_value->ifeatures[i];
            if (likely(inf->feature)) {
                out_feature_bool = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value_bool.ifeatures[i].feature = out_feature_bool;
                out_feature_count = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value_count.ifeatures[i].feature = out_feature_count;
                compute_one_feature(*inf->feature, count_map, out_feature_bool, out_feature_count, has_input);
            } else if (likely(inf->feature_list)) {
                out_featurelist_bool = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value_bool.ifeatures[i].feature_list = out_featurelist_bool;
                out_featurelist_count = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value_count.ifeatures[i].feature_list = out_featurelist_count;
                for (auto &feat: inf->feature_list->feature()) {
                    compute_one_feature(feat, count_map, out_featurelist_bool->add_feature(),
                                        out_featurelist_count->add_feature(), has_input);
                }
            }
        }
    }

    void SeqHitCountV2Config::compute_one_feature(const tensorflow::Feature &feat,
                                                  std::unordered_map<int64_t, int64_t> &count_map,
                                                  tensorflow::Feature *out_feature_bool,
                                                  tensorflow::Feature *out_feature_count, bool has_input) {
        int32_t count = 0;
        if (has_input) {
            for (const int64_t &appid: feat.int64_list().value()) {
                auto itr = count_map.find(appid);
                count = (itr != count_map.end() ? itr->second : 0);
                out_feature_bool->mutable_int64_list()->add_value(count > 0 ? 1 : 0);
                out_feature_count->mutable_int64_list()->add_value(count > max_num_ ? max_num_ : count);
            }
        }
        if (!allow_empty_output_) {
            fill_default_value(out_feature_bool, out_feature_count);
        }
    }

    bool SeqHitCountV3Config::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqHitCountV3Config::compute");
        LogDebug("------------ compute {} start ------------", output_);
        bool res = false;
        if (_data_type == DataType::int64) {
            res = compute_<int64_t>(input_values, output);
        } else {
            res = compute_<std::string>(input_values, output);
        }
        LogDebug("------------ compute {} done ------------", output_);
        return res;
    }

    template<typename T>
    bool SeqHitCountV3Config::compute_(const std::vector<const Output *> &input_values, Output &output) {
        bool need_filter = (input_values.size() == 4);
        const Value *item_value = nullptr;
        std::unordered_map<T, int64_t> count_map;
        bool has_input = false;
        if (need_filter) {
            const Value *appid_value = get_value(input_values, inputs_, 0);
            const Value *eventtime_value = get_value(input_values, inputs_, 1);
            int64_t now = get_feature_one_int64(input_values, inputs_, 2);
            item_value = get_value(input_values, inputs_, 3);
            const InputFeature *inf_appid = nullptr;
            const InputFeature *inf_eventtime = nullptr;
            uint32_t input_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());
            //防穿越，有效数据提取到count_map中计数
            for (uint32_t i = 0; i < input_size; i++) {
                inf_appid = &appid_value->ifeatures[i];
                inf_eventtime = &eventtime_value->ifeatures[i];
                if (likely(inf_appid->feature && inf_eventtime->feature)) {
                    has_input |= _filter_compute.fill_count_map(*inf_appid->feature, *inf_eventtime->feature, now,
                                                                count_map);
                } else if (likely(inf_appid->feature_list && inf_eventtime->feature_list)) {
                    uint32_t list_size = std::min(inf_appid->feature_list->feature_size(),
                                                  inf_eventtime->feature_list->feature_size());
                    for (uint32_t j = 0; j < list_size; j++) {
                        has_input |=
                                _filter_compute.fill_count_map(inf_appid->feature_list->feature(j),
                                                               inf_eventtime->feature_list->feature(j), now, count_map);
                    }
                }
            }
        } else {
            const Value *appid_value = get_value(input_values, inputs_, 0);
            item_value = get_value(input_values, inputs_, 1);
            const InputFeature *inf_appid = nullptr;
            uint32_t input_size = appid_value->ifeatures.size();
            //无需防穿越过滤，提取到count_map中计数
            for (uint32_t i = 0; i < input_size; i++) {
                inf_appid = &appid_value->ifeatures[i];
                if (likely(inf_appid->feature)) {
                    process_appid(*inf_appid->feature, count_map);
                } else if (likely(inf_appid->feature_list)) {
                    uint32_t list_size = inf_appid->feature_list->feature_size();
                    for (uint32_t j = 0; j < list_size; j++) {
                        process_appid(inf_appid->feature_list->feature(j), count_map);
                    }
                }
            }
            has_input = !count_map.empty();
        }
        if (item_value == nullptr)
            return false;

        generate_output(item_value, count_map, output, has_input);
        return true;
    }

    template<typename T>
    void SeqHitCountV3Config::generate_output(const Value *item_value, const std::unordered_map<T, int64_t> &count_map,
                                              Output &output, bool has_input) {
        const int batch_size = item_value->ifeatures.size();
        std::vector<InputFeature>::const_iterator inf;
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;
        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);
        //输出
        for (int i = 0; i < batch_size; ++i) {
            inf = item_value->ifeatures.begin() + i;
            if (inf->feature_list) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;
                for (auto &feat: inf->feature_list->feature()) {
                    compute_one_feature(feat, count_map, out_featurelist->add_feature(), has_input);
                }
                if ((out_featurelist->feature_size() == 0) && !allow_empty_output_) {
                    fill_default_value(out_featurelist->add_feature());
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;
                if (likely(inf->feature)) {
                    compute_one_feature(*inf->feature, count_map, out_feature, has_input);
                } else if (!allow_empty_output_) {
                    fill_default_value(out_feature);
                }
            }
        }
#if __cplusplus >= 201703L
        if constexpr (std::is_same<T, int64_t>::value) {
#else
        if (std::is_same<T, int64_t>::value) {
#endif
            value.defalut_type = tensorflow::DT_INT64;
        }
#if __cplusplus >= 201703L
        else if constexpr (std::is_same<T, std::string>::value) {
#else
        else if (std::is_same<T, std::string>::value) {
#endif
            value.defalut_type = tensorflow::DT_STRING;
        }
    }

    void SeqHitCountV3Config::compute_one_feature(const tensorflow::Feature &feat,
                                                  const std::unordered_map<int64_t, int64_t> &count_map,
                                                  tensorflow::Feature *out, bool has_input) {
        int32_t count = 0;
        if (has_input) {
            for (const auto &appid: feat.int64_list().value()) {
                auto itr = count_map.find(appid);
                count = (itr != count_map.end() ? itr->second : 0);
                out->mutable_int64_list()->add_value(std::min(_max_num, count));
            }
        }
        if (!allow_empty_output_) {
            fill_default_value(out);
        }
    }

    void SeqHitCountV3Config::compute_one_feature(const tensorflow::Feature &feat,
                                                  const std::unordered_map<std::string, int64_t> &count_map,
                                                  tensorflow::Feature *out, bool has_input) {
        int32_t count = 0;
        if (has_input) {
            for (const auto &appid: feat.bytes_list().value()) {
                auto itr = count_map.find(appid);
                count = (itr != count_map.end() ? itr->second : 0);
                out->mutable_int64_list()->add_value(std::min(_max_num, count));
            }
        }
        if (!allow_empty_output_) {
            fill_default_value(out);
        }
    }

    bool StatCtrConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("StatCtrConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *click_value = get_value(input_values, inputs_, 0);
        const Value *expo_value = get_value(input_values, inputs_, 1);

        const std::size_t batch_size = std::min(click_value->ifeatures.size(), expo_value->ifeatures.size());

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_FLOAT;
        value.ifeatures.resize(batch_size);
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;

        const InputFeature *inf_click = nullptr;
        const InputFeature *inf_expo = nullptr;

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            inf_click = &click_value->ifeatures[i];
            inf_expo = &expo_value->ifeatures[i];

            if (inf_click->feature_list && inf_expo->feature_list) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;
                uint32_t list_size =
                        std::min(inf_click->feature_list->feature_size(), inf_expo->feature_list->feature_size());

                for (uint32_t j = 0; j < list_size; j++) {
                    compute_one_feature(inf_click->feature_list->feature(j), inf_expo->feature_list->feature(j),
                                        out_featurelist->add_feature());
                }
                if ((out_featurelist->feature_size() == 0) && !allow_empty_output_) {
                    fill_default_value(out_featurelist->add_feature());
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (likely(inf_click->feature && inf_expo->feature)) {
                    compute_one_feature(*inf_click->feature, *inf_expo->feature, out_feature);
                } else if (!allow_empty_output_) {
                    fill_default_value(out_feature);
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void StatCtrConfig::compute_one_feature(const tensorflow::Feature &click_feat, const tensorflow::Feature &expo_feat,
                                            tensorflow::Feature *out) {
        auto &click_vec = click_feat.int64_list().value();
        auto &expo_vec = expo_feat.int64_list().value();
        const uint32_t list_size = std::min(click_vec.size(), expo_vec.size());

        for (uint32_t i = 0; i < list_size; i++) {
            //min_expo_最小为1，不为0
            if (expo_vec[i] < min_expo_) {
                out->mutable_float_list()->add_value(default_value_);
            } else {
                out->mutable_float_list()->add_value(static_cast<float>(click_vec[i]) /
                                                     static_cast<float>(expo_vec[i]));
            }
        }

        if (!allow_empty_output_) {
            fill_default_value(out);
        }
    }

    void StatCtrConfig::fill_default_value(tensorflow::Feature *out) {
        if (out->float_list().value_size() < 1) {
            out->mutable_float_list()->add_value(default_value_);
        }
    }

    bool StatCtrBucketConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("StatCtrBucketConfig::compute");

        LogDebug("------------ compute {} start ------------", output_);

        const Value *input_value = get_value(input_values, inputs_, 0);
        uint32_t batch_size = input_value->ifeatures.size();

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);
        switch (bucket_type_) {
            case BUCKET_INT:
            case BUCKET_DIRECT_FLOAT: {
                value.defalut_type = tensorflow::DT_INT64;
            } break;

            case BUCKET_LOG:
            case BUCKET_LOG_V2: {
                value.defalut_type = tensorflow::DT_FLOAT;
            } break;

            default:
                break;
        }

        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;
        const InputFeature *inf = nullptr;

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &input_value->ifeatures[i];

            if (inf->feature_list) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;

                for (int32_t j = 0; j < inf->feature_list->feature_size(); j++) {
                    compute_one_feature(inf->feature_list->feature(j), out_featurelist->add_feature());
                }
                if ((out_featurelist->feature_size() == 0) && !allow_empty_output_) {
                    fill_default_value(out_featurelist->add_feature());
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (likely(inf->feature)) {
                    compute_one_feature(*inf->feature, out_feature);
                } else if (!allow_empty_output_) {
                    fill_default_value(out_feature);
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void StatCtrBucketConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        switch (feat.kind_case()) {
            case tensorflow::Feature::kFloatList: {
                for (const float score: feat.float_list().value()) {
                    //离散化函数int(score * size) 或 log2(score + size) 或 int(k * log2(a + score * b)) 或 log2(a + score * b)
                    switch (bucket_type_) {
                        case BUCKET_INT: {
                            out->mutable_int64_list()->add_value(static_cast<int64_t>(score * size_));
                        } break;

                        case BUCKET_LOG: {
                            float value = score + size_;
                            if (unlikely(value <= 0)) {
                                out->mutable_float_list()->add_value(default_value_);
                            } else {
                                out->mutable_float_list()->add_value(std::log2(value));
                            }
                        } break;

                        case BUCKET_DIRECT_FLOAT: {
                            float value = a_ + score * b_;
                            if (unlikely(value <= 0)) {
                                out->mutable_int64_list()->add_value(static_cast<int64_t>(default_value_));
                            } else {
                                out->mutable_int64_list()->add_value(static_cast<int64_t>(k_ * std::log2(value)));
                            }
                        } break;

                        case BUCKET_LOG_V2: {
                            float value = a_ + score * b_;
                            if (unlikely(value <= 0)) {
                                out->mutable_float_list()->add_value(default_value_);
                            } else {
                                out->mutable_float_list()->add_value(std::log2(value));
                            }
                        } break;

                        default:
                            break;
                    }
                }
            } break;

            case tensorflow::Feature::kInt64List: {
                for (const int64_t score: feat.int64_list().value()) {
                    //离散化函数int(score * size) 或 log2(score + size) 或 int(k * log2(a + score * b)) 或 log2(a + score * b)
                    switch (bucket_type_) {
                        case BUCKET_INT: {
                            out->mutable_int64_list()->add_value(static_cast<int64_t>(score * size_));
                        } break;

                        case BUCKET_LOG: {
                            float value = score + size_;
                            if (unlikely(value <= 0)) {
                                out->mutable_float_list()->add_value(default_value_);
                            } else {
                                out->mutable_float_list()->add_value(std::log2(value));
                            }
                        } break;

                        case BUCKET_DIRECT_FLOAT: {
                            float value = a_ + score * b_;
                            if (unlikely(value <= 0)) {
                                out->mutable_int64_list()->add_value(static_cast<int64_t>(default_value_));
                            } else {
                                out->mutable_int64_list()->add_value(static_cast<int64_t>(k_ * std::log2(value)));
                            }
                        } break;

                        case BUCKET_LOG_V2: {
                            float value = a_ + score * b_;
                            if (unlikely(value <= 0)) {
                                out->mutable_float_list()->add_value(default_value_);
                            } else {
                                out->mutable_float_list()->add_value(std::log2(value));
                            }
                        } break;

                        default:
                            break;
                    }
                }
            } break;

            default:
                break;
        }

        if (!allow_empty_output_) {
            fill_default_value(out);
        }
    }

    void StatCtrBucketConfig::fill_default_value(tensorflow::Feature *out) {
        switch (bucket_type_) {
            case BUCKET_INT:
            case BUCKET_DIRECT_FLOAT:
                if (out->int64_list().value_size() < 1) {
                    out->mutable_int64_list()->add_value(static_cast<int64_t>(default_value_));
                }
                break;

            case BUCKET_LOG:
            case BUCKET_LOG_V2:
                if (out->float_list().value_size() < 1) {
                    out->mutable_float_list()->add_value(default_value_);
                }
                break;

            default:
                break;
        }
    }

    void StatSmoothCtrConfig::compute_one_feature(const tensorflow::Feature &click_feat,
                                                  const tensorflow::Feature &expo_feat, tensorflow::Feature *out) {
        auto &click_vec = click_feat.int64_list().value();
        auto &expo_vec = expo_feat.int64_list().value();
        const uint32_t list_size = std::min(click_vec.size(), expo_vec.size());

        for (uint32_t i = 0; i < list_size; i++) {
            //min_expo_最小为1，不为0
            if (expo_vec[i] < min_expo_ || expo_vec[i] == 0) {
                out->mutable_float_list()->add_value(default_value_);
            } else {
                float ctr_smooth =
                        (static_cast<float>(click_vec[i]) + alpha_) / (static_cast<float>(expo_vec[i]) + beta_);
                out->mutable_float_list()->add_value(ctr_smooth);
            }
        }

        if (!allow_empty_output_) {
            phx_fe::StatCtrConfig::fill_default_value(out);
        }
    }

    bool SeqCoalesceConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqCoalesceConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        int64_t info_size = input_values.size();
        std::vector<const Value *> info_vec(info_size, nullptr);

        uint32_t batch_size = 0;
        for (int64_t i = 0; i < info_size; i++) {
            info_vec[i] = get_value(input_values, inputs_, i);
            if (i == 0) {
                batch_size = info_vec[i]->ifeatures.size();
            } else if (info_vec[i]->ifeatures.size() != batch_size) {
                THROW_ERROR("invalid source, input_value_size not euqal, name:" + output_);
                return false;
            }
        }

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);

        const InputFeature *input = nullptr;

        for (int64_t i = 0; i < batch_size; i++) {
            for (int64_t j = 0; j < info_size; j++) {
                input = &info_vec[j]->ifeatures[i];
                if (input && !input->messages.empty()) {
                    value.ifeatures[i].messages = input->messages;
                    break;
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    bool SeqPbClip::compute(const std::vector<const Output *> &input_values, Output &output) {
        int64_t request_time = get_feature_one_int64(input_values, inputs_, 0);
        auto request_time_of_calendar_day = timestamp_to_cast_days(request_time);
        auto batch_pb_value = get_value(input_values, inputs_, 1);
        auto batch_size = batch_pb_value->ifeatures.size();
        output.values.resize(1);
        output.values[0].ifeatures.resize(batch_size);
        for (size_t batch_index = 0; batch_index < batch_size; batch_index++) {
            auto &pb_values = batch_pb_value->ifeatures[batch_index].messages;
            if (pb_values.empty()) {
                continue;
            }
            auto descriptor = pb_values[0]->GetDescriptor();
            auto reflection = pb_values[0]->GetReflection();
            auto timestamp_field_desc = descriptor->FindFieldByName(timestamp_field_name_);
            if (unlikely(timestamp_field_desc == nullptr)) {
                THROW_ERROR("can not find field:[" + timestamp_field_name_ + "]");
                return false;
            }
            if (unlikely(timestamp_field_desc->cpp_type() != google::protobuf::FieldDescriptor::CPPTYPE_INT64)) {
                THROW_ERROR("field name:[" + timestamp_field_name_ + "] is not int64!");
                return false;
            }
            auto &filter_pb_values = output.values[0].ifeatures[batch_index].messages;
            for (auto &message: pb_values) {
                int64_t event_time = reflection->GetInt64(*message, timestamp_field_desc);
                int64_t event_time_of_calendar_day = timestamp_to_cast_days(event_time);
                int64_t diff_of_calendar_day = request_time_of_calendar_day - event_time_of_calendar_day;
                if (diff_of_calendar_day <= end_day_ && (start_day_ < 0 || diff_of_calendar_day >= start_day_)) {
                    filter_pb_values.emplace_back(message);
                }
            }
        }
        return true;
    }

    bool SeqPriorityMergeConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqPriorityMergeConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *first_value = get_value(input_values, inputs_, 0);
        const Value *second_value = get_value(input_values, inputs_, 1);
        const Value *third_value = get_value(input_values, inputs_, 2);

        uint32_t batch_size = std::max(first_value->ifeatures.size(), second_value->ifeatures.size());
        batch_size = std::max(static_cast<uint32_t>(third_value->ifeatures.size()), batch_size);

        const InputFeature *first_inf = nullptr;
        const InputFeature *second_inf = nullptr;
        const InputFeature *third_inf = nullptr;
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            first_inf = get_idx_ifeatures(first_value, i);
            second_inf = get_idx_ifeatures(second_value, i);
            third_inf = get_idx_ifeatures(third_value, i);

            if (first_inf->feature_list && second_inf->feature_list && third_inf->feature_list) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;

                int32_t first_size = first_inf->feature_list->feature_size();
                int32_t second_size = second_inf->feature_list->feature_size();
                int32_t third_size = third_inf->feature_list->feature_size();

                int32_t list_size = std::max(first_size, second_size);
                list_size = std::max(list_size, third_size);

                for (int32_t j = 0; j < list_size; j++) {
                    const tensorflow::Feature *first_feature = nullptr;
                    const tensorflow::Feature *second_feature = nullptr;
                    const tensorflow::Feature *third_feature = nullptr;
                    if (j < first_size) {
                        first_feature = &first_inf->feature_list->feature(j);
                    }
                    if (j < second_size) {
                        second_feature = &second_inf->feature_list->feature(j);
                    }
                    if (j < third_size) {
                        third_feature = &third_inf->feature_list->feature(j);
                    }
                    compute_one_feature(first_feature, second_feature, third_feature, out_featurelist->add_feature());
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                const tensorflow::Feature *first_feature = nullptr;
                const tensorflow::Feature *second_feature = nullptr;
                const tensorflow::Feature *third_feature = nullptr;
                if (first_inf->feature) {
                    first_feature = first_inf->feature;
                }
                if (second_inf->feature) {
                    second_feature = second_inf->feature;
                }
                if (third_inf->feature) {
                    third_feature = third_inf->feature;
                }
                compute_one_feature(first_feature, second_feature, third_feature, out_feature);
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqPriorityMergeConfig::compute_one_feature(const tensorflow::Feature *first_feature,
                                                     const tensorflow::Feature *second_feature,
                                                     const tensorflow::Feature *third_feature,
                                                     tensorflow::Feature *out) {
        DataType dtype = DataType::DATATYPE_UNKNOWN;
        const ::google::protobuf::RepeatedPtrField<std::string> *first_str_vec = nullptr;
        const ::google::protobuf::RepeatedPtrField<std::string> *second_str_vec = nullptr;
        const ::google::protobuf::RepeatedPtrField<std::string> *third_str_vec = nullptr;
        const ::google::protobuf::RepeatedField<int64_t> *first_int_vec = nullptr;
        const ::google::protobuf::RepeatedField<int64_t> *second_int_vec = nullptr;
        const ::google::protobuf::RepeatedField<int64_t> *third_int_vec = nullptr;
        const ::google::protobuf::RepeatedField<float> *first_float_vec = nullptr;
        const ::google::protobuf::RepeatedField<float> *second_float_vec = nullptr;
        const ::google::protobuf::RepeatedField<float> *third_float_vec = nullptr;

        if (first_feature) {
            switch (first_feature->kind_case()) {
                case tensorflow::Feature::kBytesList: {
                    first_str_vec = &first_feature->bytes_list().value();
                    dtype = DataType::DATATYPE_STRING;
                    break;
                }

                case tensorflow::Feature::kFloatList: {
                    first_float_vec = &first_feature->float_list().value();
                    dtype = DataType::DATATYPE_FLOAT;
                    break;
                }

                case tensorflow::Feature::kInt64List: {
                    first_int_vec = &first_feature->int64_list().value();
                    dtype = DataType::DATATYPE_INT64;
                    break;
                }

                default: {
                    break;
                }
            }
        }
        if (second_feature) {
            switch (second_feature->kind_case()) {
                case tensorflow::Feature::kBytesList: {
                    second_str_vec = &second_feature->bytes_list().value();
                    if (dtype == DataType::DATATYPE_UNKNOWN) {
                        dtype = DataType::DATATYPE_STRING;
                    }
                    break;
                }

                case tensorflow::Feature::kFloatList: {
                    second_float_vec = &second_feature->float_list().value();
                    if (dtype == DataType::DATATYPE_UNKNOWN) {
                        dtype = DataType::DATATYPE_FLOAT;
                    }
                    break;
                }

                case tensorflow::Feature::kInt64List: {
                    second_int_vec = &second_feature->int64_list().value();
                    if (dtype == DataType::DATATYPE_UNKNOWN) {
                        dtype = DataType::DATATYPE_INT64;
                    }
                    break;
                }

                default: {
                    break;
                }
            }
        }
        if (third_feature) {
            switch (third_feature->kind_case()) {
                case tensorflow::Feature::kBytesList: {
                    third_str_vec = &third_feature->bytes_list().value();
                    if (dtype == DataType::DATATYPE_UNKNOWN) {
                        dtype = DataType::DATATYPE_STRING;
                    }
                    break;
                }

                case tensorflow::Feature::kFloatList: {
                    third_float_vec = &third_feature->float_list().value();
                    if (dtype == DataType::DATATYPE_UNKNOWN) {
                        dtype = DataType::DATATYPE_FLOAT;
                    }
                    break;
                }

                case tensorflow::Feature::kInt64List: {
                    third_int_vec = &third_feature->int64_list().value();
                    if (dtype == DataType::DATATYPE_UNKNOWN) {
                        dtype = DataType::DATATYPE_INT64;
                    }
                    break;
                }

                default: {
                    break;
                }
            }
        }

        switch (dtype) {
            case DataType::DATATYPE_STRING: {
                // 取三个 vec 的最大长度
                int32_t max_len = 0;
                if (first_str_vec)
                    max_len = std::max(max_len, first_str_vec->size());
                if (second_str_vec)
                    max_len = std::max(max_len, second_str_vec->size());
                if (third_str_vec)
                    max_len = std::max(max_len, third_str_vec->size());

                auto *out_list = out->mutable_bytes_list();

                for (int32_t i = 0; i < max_len; ++i) {
                    // 优先级: first -> second -> third
                    const std::string *val = nullptr;
                    if (first_str_vec && i < first_str_vec->size() && (*first_str_vec)[i] != illegal_string_) {
                        val = &(*first_str_vec)[i];
                    } else if (second_str_vec && i < second_str_vec->size() &&
                               (*second_str_vec)[i] != illegal_string_) {
                        val = &(*second_str_vec)[i];
                    } else if (third_str_vec && i < third_str_vec->size() && (*third_str_vec)[i] != illegal_string_) {
                        val = &(*third_str_vec)[i];
                    }
                    // 只要有有效值就写入
                    if (val) {
                        out_list->add_value(*val);
                    }
                }
                break;
            }

            case DataType::DATATYPE_FLOAT: {
                // 取三个 vec 的最大长度
                int32_t max_len = 0;
                if (first_float_vec)
                    max_len = std::max(max_len, first_float_vec->size());
                if (second_float_vec)
                    max_len = std::max(max_len, second_float_vec->size());
                if (third_float_vec)
                    max_len = std::max(max_len, third_float_vec->size());

                auto *out_list = out->mutable_float_list();

                for (int32_t i = 0; i < max_len; ++i) {
                    // 优先级: first -> second -> third
                    const float *val = nullptr;
                    if (first_float_vec && i < first_float_vec->size() &&
                        fabs((*first_float_vec)[i] - illegal_float_) > espilon_) {
                        val = &(*first_float_vec)[i];
                    } else if (second_float_vec && i < second_float_vec->size() &&
                               fabs((*second_float_vec)[i] - illegal_float_) > espilon_) {
                        val = &(*second_float_vec)[i];
                    } else if (third_float_vec && i < third_float_vec->size() &&
                               fabs((*third_float_vec)[i] - illegal_float_) > espilon_) {
                        val = &(*third_float_vec)[i];
                    }
                    // 只要有有效值就写入
                    if (val) {
                        out_list->add_value(*val);
                    }
                }
                break;
            }

            case DataType::DATATYPE_INT64: {
                // 取三个 vec 的最大长度
                int32_t max_len = 0;
                if (first_int_vec)
                    max_len = std::max(max_len, first_int_vec->size());
                if (second_int_vec)
                    max_len = std::max(max_len, second_int_vec->size());
                if (third_int_vec)
                    max_len = std::max(max_len, third_int_vec->size());

                auto *out_list = out->mutable_int64_list();

                for (int32_t i = 0; i < max_len; ++i) {
                    // 优先级: first -> second -> third
                    const int64_t *val = nullptr;
                    if (first_int_vec && i < first_int_vec->size() && (*first_int_vec)[i] != illegal_int_) {
                        val = &(*first_int_vec)[i];
                    } else if (second_int_vec && i < second_int_vec->size() && (*second_int_vec)[i] != illegal_int_) {
                        val = &(*second_int_vec)[i];
                    } else if (third_int_vec && i < third_int_vec->size() && (*third_int_vec)[i] != illegal_int_) {
                        val = &(*third_int_vec)[i];
                    }
                    // 只要有有效值就写入
                    if (val) {
                        out_list->add_value(*val);
                    }
                }
                break;
            }

            default: {
                break;
            }
        }
    }
    bool SeqCrossHashBits::compute(const std::vector<const Output *> &input_values, Output &output) {
        if (unlikely(input_values.size() < 2)) {
            THROW_ERROR("input values count < 2!");
        }
        auto input_1 = get_value(input_values, inputs_, 0);
        auto input_2 = get_value(input_values, inputs_, 1);
        auto batch_size = std::max(input_1->ifeatures.size(), input_2->ifeatures.size());
        output.values.resize(batch_size);
        // 计算batch size相同的情况
        if (input_1->ifeatures.size() == input_2->ifeatures.size()) {
            auto batch_size = input_1->ifeatures.size();
            output.values[0].ifeatures.resize(batch_size);
            for (size_t i = 0; i < batch_size; i++) {
                auto ifeature_1 = input_1->ifeatures[i];
                auto ifeature_2 = input_2->ifeatures[i];
                if (ifeature_1.feature && ifeature_2.feature) {
                    auto *output_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[0].ifeatures[i].feature = output_feature;
                    ComputeOneFeature(*ifeature_1.feature, *ifeature_2.feature, output_feature);
                } else if (ifeature_1.feature_list && ifeature_2.feature_list) {
                    auto output_feature_list =
                            google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[0].ifeatures[i].feature_list = output_feature_list;
                    int32_t feature_size =
                            std::min(ifeature_1.feature_list->feature_size(), ifeature_2.feature_list->feature_size());
                    for (int32_t feature_index = 0; feature_index < feature_size; feature_index++) {
                        ComputeOneFeature(ifeature_1.feature_list->feature(feature_index),
                                          ifeature_2.feature_list->feature(feature_index),
                                          output_feature_list->add_feature());
                    }
                }
            }
        } else {
            // 计算item和user特征的cross hash bits
            const Value *user_feature = nullptr;
            const Value *item_feature = nullptr;
            if (input_1->ifeatures.size() == 1) {
                user_feature = input_1;
                item_feature = input_2;
            } else if (input_2->ifeatures.size() == 1) {
                user_feature = input_2;
                item_feature = input_1;
            } else {
                THROW_ERROR("feature seq not match!");
                return false;
            }

            auto batch_size = item_feature->ifeatures.size();
            for (size_t batch_index = 0; batch_index < batch_size; batch_index++) {
                auto ifeature_1 = user_feature->ifeatures[0];
                auto ifeature_2 = item_feature->ifeatures[batch_index];
                if (ifeature_1.feature && ifeature_2.feature) {
                    auto *output_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[0].ifeatures[batch_index].feature = output_feature;
                    ComputeOneFeature(*ifeature_1.feature, *ifeature_2.feature, output_feature);
                } else if (ifeature_1.feature_list && ifeature_2.feature_list) {
                    auto output_feature_list =
                            google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[0].ifeatures[batch_index].feature_list = output_feature_list;
                    int32_t feature_size =
                            std::min(ifeature_1.feature_list->feature_size(), ifeature_2.feature_list->feature_size());
                    for (int32_t feature_index = 0; feature_index < feature_size; feature_index++) {
                        ComputeOneFeature(ifeature_1.feature_list->feature(feature_index),
                                          ifeature_2.feature_list->feature(feature_index),
                                          output_feature_list->add_feature());
                    }
                }
            }
        }

        return true;
    }

    std::vector<int64_t> SeqCrossHashBits::MurMurHash(const tensorflow::Feature &feature) const {
        std::vector<int64_t> hash_result{};
        switch (feature.kind_case()) {
            case tensorflow::Feature::kInt64List: {
                int32_t real_size = std::min(clip_size_, feature.int64_list().value_size());
                for (int32_t i = 0; i < real_size; i++) {
                    int64_t hash_feature = 0;
                    murmur_hash(feature.int64_list().value(i), hash_feature);
                    hash_result.emplace_back(hash_feature);
                }
                break;
            }
            case tensorflow::Feature::kBytesList: {
                int32_t real_size = std::min(clip_size_, feature.bytes_list().value_size());
                for (int32_t i = 0; i < real_size; i++) {
                    int64_t hash_feature = 0;
                    murmur_hash(feature.bytes_list().value(i), hash_feature);
                    hash_result.emplace_back(hash_feature);
                }
                break;
            }
            case tensorflow::Feature::KindCase::kFloatList: {
                THROW_ERROR("seq_cross_hash_bits doesn't support float");
                break;
            }
            default:
                break;
        }
        return hash_result;
    }
    void SeqCrossHashBits::ComputeOneFeature(const tensorflow::Feature &feature_1, const tensorflow::Feature &feature_2,
                                             tensorflow::Feature *output) {
        std::vector<int64_t> hash_1 = MurMurHash(feature_1);
        std::vector<int64_t> hash_2 = MurMurHash(feature_2);
        size_t min_size = std::min(hash_1.size(), hash_2.size());
        for (int i = 0; i < min_size; i++) {
            output->mutable_int64_list()->add_value(hash_1[i] ^ hash_2[i]);
        }
    }

    bool SeqRatioConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqRatioConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *in_value = get_value(input_values, inputs_, 0);
        const InputFeature *inf = nullptr;
        uint32_t batch_size = in_value->ifeatures.size();
        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;
        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_FLOAT;
        value.ifeatures.resize(batch_size);

        for (uint32_t i = 0; i < batch_size; i++) {
            inf = &in_value->ifeatures[i];
            if (inf->feature_list) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;
                for (auto &feat: inf->feature_list->feature()) {
                    compute_one_feature(feat, out_featurelist->add_feature());
                }
                if ((out_featurelist->feature_size() == 0) && !allow_empty_output_) {
                    auto *out = out_featurelist->add_feature();
                    if (unlikely(out->float_list().value_size() == 0)) {
                        out->mutable_float_list()->add_value(default_value_);
                    }
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;

                if (likely(inf->feature)) {
                    compute_one_feature(*inf->feature, out_feature);
                } else if (!allow_empty_output_) {
                    if (unlikely(out_feature->float_list().value_size() == 0)) {
                        out_feature->mutable_float_list()->add_value(default_value_);
                    }
                }
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqRatioConfig::compute_one_feature(const tensorflow::Feature &feat, tensorflow::Feature *out) {
        float sum = 0.0;
        switch (feat.kind_case()) {
            case tensorflow::Feature::kFloatList: {
                for (const float &value: feat.float_list().value()) {
                    sum += value;
                }
                for (const float &value: feat.float_list().value()) {
                    if (sum != 0.0) {
                        out->mutable_float_list()->add_value(value / sum);
                    } else {
                        out->mutable_float_list()->add_value(default_value_);
                    }
                }
                break;
            }
            case tensorflow::Feature::kInt64List: {
                for (const int64_t &value: feat.int64_list().value()) {
                    sum += value;
                }
                for (const int64_t &value: feat.int64_list().value()) {
                    if (sum != 0) {
                        out->mutable_float_list()->add_value(value / sum);
                    } else {
                        out->mutable_float_list()->add_value(default_value_);
                    }
                }
                break;
            }
            default: {
                break;
            }
        }
        if (out->float_list().value_size() < 1 && !allow_empty_output_) {
            out->mutable_float_list()->add_value(default_value_);
        }
    }

    bool SeqDivConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqDivConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *in_value_1 = get_value(input_values, inputs_, 0);
        const Value *in_value_2 = get_value(input_values, inputs_, 1);
        uint32_t input_size = std::min(in_value_1->ifeatures.size(), in_value_2->ifeatures.size());

        const InputFeature *inf_1 = nullptr;
        const InputFeature *inf_2 = nullptr;

        tensorflow::Feature *out_feature = nullptr;
        tensorflow::FeatureList *out_featurelist = nullptr;

        output.values.resize(1);
        Value &value = output.values[0];
        value.defalut_type = tensorflow::DT_FLOAT;
        value.ifeatures.resize(input_size);

        for (uint32_t i = 0; i < input_size; i++) {
            inf_1 = &in_value_1->ifeatures[i];
            inf_2 = &in_value_2->ifeatures[i];
            if (inf_1->feature_list && inf_2->feature_list) {
                out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value.ifeatures[i].feature_list = out_featurelist;
                uint32_t list_size = std::min(inf_1->feature_list->feature_size(), inf_2->feature_list->feature_size());
                for (uint32_t j = 0; j < list_size; j++) {
                    compute_one_feature(inf_1->feature_list->feature(j), inf_2->feature_list->feature(j),
                                        out_featurelist->add_feature());
                }
                if ((out_featurelist->feature_size() == 0) && !allow_empty_output_) {
                    auto *out = out_featurelist->add_feature();
                    if (unlikely(out->float_list().value_size() == 0)) {
                        out->mutable_float_list()->add_value(default_value_);
                    }
                }
            } else {
                out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value.ifeatures[i].feature = out_feature;
                if (likely(inf_1->feature && inf_2->feature)) {
                    compute_one_feature(*inf_1->feature, *inf_2->feature, out_feature);
                } else if (!allow_empty_output_) {
                    if (unlikely(out_feature->float_list().value_size() == 0)) {
                        out_feature->mutable_float_list()->add_value(default_value_);
                    }
                }
            }
        }
        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqDivConfig::compute_one_feature(const tensorflow::Feature &feat1, const tensorflow::Feature &feat2,
                                           tensorflow::Feature *out) {
        uint32_t feat1_size = std::max(feat1.float_list().value_size(), feat1.int64_list().value_size());
        uint32_t feat2_size = std::max(feat2.float_list().value_size(), feat2.int64_list().value_size());
        std::vector<float> feat1_vec, feat2_vec;
        feat1_vec.reserve(feat1_size);
        feat2_vec.reserve(feat2_size);
        switch (feat1.kind_case()) {
            case tensorflow::Feature::kFloatList: {
                for (const float &value: feat1.float_list().value()) {
                    feat1_vec.emplace_back(value);
                }
                break;
            }
            case tensorflow::Feature::kInt64List: {
                for (const int64_t &value: feat1.int64_list().value()) {
                    feat1_vec.emplace_back(value);
                }
                break;
            }
            default: {
                break;
            }
        }

        switch (feat2.kind_case()) {
            case tensorflow::Feature::kFloatList: {
                for (const float &value: feat2.float_list().value()) {
                    feat2_vec.emplace_back(value);
                }
                break;
            }
            case tensorflow::Feature::kInt64List: {
                for (const int64_t &value: feat2.int64_list().value()) {
                    feat2_vec.emplace_back(value);
                }
                break;
            }
            default: {
                break;
            }
        }

        uint32_t list_size = std::min(feat1_vec.size(), feat2_vec.size());
        for (uint32_t i = 0; i < list_size; i++) {
            if (feat2_vec[i] == 0.0f) {
                out->mutable_float_list()->add_value(default_value_);
            } else {
                out->mutable_float_list()->add_value(feat1_vec[i] / feat2_vec[i]);
            }
        }

        if (out->float_list().value_size() < 1 && !allow_empty_output_) {
            out->mutable_float_list()->add_value(default_value_);
        }
    }

    bool SeqHitValueV2Config::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqHitValueV2Config::compute");
        LogDebug("------------ compute {} start ------------", output_);

        int64_t info_size = input_values.size();
        int64_t out_size = info_size - 1;

        std::vector<const Value *> info_vec(info_size, nullptr);
        for (int64_t i = 0; i < info_size; ++i) {
            info_vec[i] = get_value(input_values, inputs_, i);
            if (info_vec[i]->ifeatures.empty()) {
                THROW_ERROR("input feature is empty, source index: " + std::to_string(i));
                return false;
            }
        }

        const InputFeature *inf_appid = &info_vec[0]->ifeatures[0];                        // 用户特征，ifeature长度为1
        std::unordered_map<int64_t, std::map<int64_t, std::vector<int64_t>>> appid_idx_map;// 二级索引适配feature_list
        if (inf_appid->feature) {
            auto &appid_vec = inf_appid->feature->int64_list().value();
            for (int64_t j = 0; j < appid_vec.size(); j++) {
                appid_idx_map[appid_vec[j]][0].emplace_back(j);
            }
        } else if (inf_appid->feature_list) {
            for (int64_t i = 0; i < inf_appid->feature_list->feature_size(); i++) {
                auto &appid_vec = inf_appid->feature_list->feature(i).int64_list().value();
                for (int64_t j = 0; j < appid_vec.size(); j++) {
                    appid_idx_map[appid_vec[j]][i].emplace_back(j);
                }
            }
        }

        // 最后一个输入是item维度的
        const Value *item_value = info_vec[info_size - 1];
        uint32_t batch_size = item_value->ifeatures.size();
        output.values.resize(out_size);
        std::vector<tensorflow::DataType> data_type_vec(out_size, tensorflow::DT_INVALID);
        data_type_vec[0] = tensorflow::DT_INT64;
        for (uint32_t i = 0; i < out_size; i++) {
            output.values[i].ifeatures.resize(batch_size);
        }
        const InputFeature *inf_item = nullptr;
        for (uint32_t i = 0; i < batch_size; i++) {
            inf_item = &item_value->ifeatures[i];
            if (likely(inf_item->feature)) {
                Value &value_bool = output.values[0];
                auto *out_feature_bool = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                value_bool.ifeatures[i].feature = out_feature_bool;
                compute_one_bool_feature(*inf_item->feature, appid_idx_map, out_feature_bool);
                for (uint32_t j = 1; j < out_size; j++) {
                    Value &value = output.values[j];
                    auto *out_feature_value = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    value.ifeatures[i].feature = out_feature_value;
                    auto &data_type = data_type_vec[j];
                    compute_one_value_feature(*inf_item->feature, &info_vec[j]->ifeatures[0], appid_idx_map, data_type,
                                              out_feature_value);
                }
            } else if (likely(inf_item->feature_list)) {
                Value &value_bool = output.values[0];
                // value_bool.defalut_type = tensorflow::DT_INT64;
                auto *out_featurelist_bool =
                        google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                value_bool.ifeatures[i].feature_list = out_featurelist_bool;
                for (auto &feat: inf_item->feature_list->feature()) {
                    compute_one_bool_feature(feat, appid_idx_map, out_featurelist_bool->add_feature());
                    for (uint32_t j = 1; j < out_size; j++) {
                        Value &value = output.values[j];
                        auto *out_featurelist_value =
                                google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                        value.ifeatures[i].feature_list = out_featurelist_value;
                        auto &data_type = data_type_vec[j];
                        compute_one_value_feature(feat, &info_vec[j]->ifeatures[0], appid_idx_map, data_type,
                                                  out_featurelist_value->add_feature());
                    }
                }
            }
        }

        for (uint32_t i = 0; i < out_size; i++) {
            output.values[i].defalut_type = data_type_vec[i];
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqHitValueV2Config::compute_one_bool_feature(
            const tensorflow::Feature &feat,
            const std::unordered_map<int64_t, std::map<int64_t, std::vector<int64_t>>> &appid_idx_map,
            tensorflow::Feature *out) {
        if (!appid_idx_map.empty()) {
            for (const int64_t &appid: feat.int64_list().value()) {
                auto itr = appid_idx_map.find(appid);
                if (itr != appid_idx_map.end() && !itr->second.empty()) {
                    out->mutable_int64_list()->add_value(1);
                } else {
                    out->mutable_int64_list()->add_value(0);
                }
            }
        }
    }

    void SeqHitValueV2Config::compute_one_value_feature(
            const tensorflow::Feature &feat, const InputFeature *inf_value,
            const std::unordered_map<int64_t, std::map<int64_t, std::vector<int64_t>>> &appid_idx_map,
            tensorflow::DataType &data_type, tensorflow::Feature *out) {
        if (appid_idx_map.empty())
            return;
        for (const int64_t &appid: feat.int64_list().value()) {
            auto itr = appid_idx_map.find(appid);
            if (itr == appid_idx_map.end()) {
                continue;
            }
            for (const auto &idx_pair: itr->second) {
                if (inf_value->feature) {
                    if (idx_pair.first > 0)
                        continue;
                    switch (inf_value->feature->kind_case()) {
                        case tensorflow::Feature::kFloatList: {
                            if (data_type == tensorflow::DT_INVALID)
                                data_type = tensorflow::DT_FLOAT;
                            for (const int64_t &idx: idx_pair.second) {
                                if (idx >= inf_value->feature->float_list().value_size())
                                    continue;
                                out->mutable_float_list()->add_value(inf_value->feature->float_list().value(idx));
                            }
                            break;
                        }
                        case tensorflow::Feature::kInt64List: {
                            if (data_type == tensorflow::DT_INVALID)
                                data_type = tensorflow::DT_INT64;
                            for (const int64_t &idx: idx_pair.second) {
                                if (idx >= inf_value->feature->int64_list().value_size())
                                    continue;
                                out->mutable_int64_list()->add_value(inf_value->feature->int64_list().value(idx));
                            }
                            break;
                        }
                        case tensorflow::Feature::kBytesList: {
                            if (data_type == tensorflow::DT_INVALID)
                                data_type = tensorflow::DT_STRING;
                            for (const int64_t &idx: idx_pair.second) {
                                if (idx >= inf_value->feature->bytes_list().value_size())
                                    continue;
                                out->mutable_bytes_list()->add_value(inf_value->feature->bytes_list().value(idx));
                            }
                            break;
                        }
                        default: {
                            break;
                        }
                    }
                } else if (inf_value->feature_list) {
                    if (idx_pair.first >= inf_value->feature_list->feature_size())
                        continue;
                    const auto &tmp_feature = inf_value->feature_list->feature(idx_pair.first);
                    switch (tmp_feature.kind_case()) {
                        case tensorflow::Feature::kFloatList: {
                            if (data_type == tensorflow::DT_INVALID)
                                data_type = tensorflow::DT_FLOAT;
                            for (const int64_t &idx: idx_pair.second) {
                                if (idx >= tmp_feature.float_list().value_size())
                                    continue;
                                out->mutable_float_list()->add_value(tmp_feature.float_list().value(idx));
                            }
                            break;
                        }
                        case tensorflow::Feature::kInt64List: {
                            if (data_type == tensorflow::DT_INVALID)
                                data_type = tensorflow::DT_INT64;
                            for (const int64_t &idx: idx_pair.second) {
                                if (idx >= tmp_feature.int64_list().value_size())
                                    continue;
                                out->mutable_int64_list()->add_value(tmp_feature.int64_list().value(idx));
                            }
                            break;
                        }
                        case tensorflow::Feature::kBytesList: {
                            if (data_type == tensorflow::DT_INVALID)
                                data_type = tensorflow::DT_STRING;
                            for (const int64_t &idx: idx_pair.second) {
                                if (idx >= tmp_feature.bytes_list().value_size())
                                    continue;
                                out->mutable_bytes_list()->add_value(tmp_feature.bytes_list().value(idx));
                            }
                            break;
                        }
                        default: {
                            break;
                        }
                    }
                }
            }
        }

        // if (out->int64_list().value_size() == 0 && out->float_list().value_size() == 0 &&
        //     out->bytes_list().value_size() == 0) {
        //     switch (data_type) {
        //         case tensorflow::DT_FLOAT: {
        //             out->mutable_float_list()->add_value(default_float_value_);
        //             break;
        //         }
        //         case tensorflow::DT_INT64: {
        //             out->mutable_int64_list()->add_value(default_int64_value_);
        //             break;
        //         }
        //         case tensorflow::DT_STRING: {
        //             out->mutable_bytes_list()->add_value(default_string_value_);
        //             break;
        //         }
        //         default: {
        //             break;
        //         }
        //     }
        // }
    }

    bool SeqHitListConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqHitListConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *item_value = get_value(input_values, inputs_, 1);
        uint32_t list_size = input_values.size() - 2;
        std::vector<const Value *> list_values(list_size, nullptr);
        std::vector<tensorflow::DataType> list_default_types(list_size, tensorflow::DT_INVALID);

        uint32_t input_size = appid_value->ifeatures.size();

        for (uint32_t i = 2; i < input_values.size(); i++) {
            list_values[i - 2] = get_value(input_values, inputs_, i);
            input_size = std::min(input_size, static_cast<uint32_t>(list_values[i - 2]->ifeatures.size()));
        }

        const uint32_t batch_size = std::max(input_size, static_cast<uint32_t>(item_value->ifeatures.size()));
        uint32_t out_size = list_size + 1;
        std::vector<tensorflow::Feature *> out_feat(out_size);
        std::vector<tensorflow::FeatureList *> out_featlist(out_size);
        output.values.resize(out_size);
        for (uint32_t i = 0; i < out_size; i++) {
            Value &value = output.values[i];
            value.ifeatures.resize(batch_size);
        }

        const InputFeature *inf = nullptr;
        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_list = nullptr;
        std::vector<const InputFeature *> list_ifea(list_size, nullptr);
        std::vector<const tensorflow::Feature *> list_fea(list_size, nullptr);
        std::unordered_map<int64_t, std::vector<tensorflow::Feature>> value_map;

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            if (i == 0 || input_size == batch_size) {
                value_map.clear();

                inf_appid = get_idx_ifeatures(appid_value, i);
                bool is_list = true;
                for (uint32_t j = 0; j < list_size; j++) {
                    list_ifea[j] = get_idx_ifeatures(list_values[j], i);
                    if (list_ifea[j]->feature_list == nullptr) {
                        is_list = false;
                    }
                }

                if (inf_appid->feature_list && is_list) {
                    uint32_t min_list_size = inf_appid->feature_list->feature_size();
                    for (uint32_t j = 0; j < list_size; j++) {
                        min_list_size = std::min(min_list_size,
                                                 static_cast<uint32_t>(list_ifea[j]->feature_list->feature_size()));
                    }

                    for (uint32_t j = 0; j < min_list_size; j++) {
                        for (uint32_t k = 0; k < list_size; k++) {
                            list_fea[k] = &list_ifea[k]->feature_list->feature(j);
                        }
                        compute_one_input(inf_appid->feature_list->feature(j), list_fea, value_map);
                    }
                } else {
                    for (uint32_t j = 0; j < list_size; j++) {
                        list_fea[j] = list_ifea[j]->feature;
                    }
                    compute_one_input(*inf_appid->feature, list_fea, value_map);
                }
            }

            inf = get_idx_ifeatures(item_value, i);

            if (inf->feature_list) {
                for (uint32_t j = 0; j < out_size; j++) {
                    out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                    output.values[j].ifeatures[i].feature_list = out_featlist[j];
                }

                if (unlikely(value_map.empty())) {
                    continue;
                }

                for (auto &feat: inf->feature_list->feature()) {
                    for (uint32_t j = 0; j < out_size; j++) {
                        out_feat[j] = out_featlist[j]->add_feature();
                    }
                    compute_one_feature(feat, value_map, list_default_types, out_feat);
                }
            } else {
                for (uint32_t j = 0; j < out_size; j++) {
                    out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    output.values[j].ifeatures[i].feature = out_feat[j];
                }

                if (unlikely(value_map.empty())) {
                    continue;
                }

                if (likely(inf->feature)) {
                    compute_one_feature(*inf->feature, value_map, list_default_types, out_feat);
                }
            }
        }

        output.values[0].defalut_type = tensorflow::DT_STRING;
        for (uint32_t i = 0; i < list_size; i++) {
            output.values[i + 1].defalut_type = list_default_types[i];
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqHitListConfig::compute_one_input(const tensorflow::Feature &appid_feat,
                                             std::vector<const tensorflow::Feature *> &list_fea,
                                             std::unordered_map<int64_t, std::vector<tensorflow::Feature>> &value_map) {
        auto &appid_vec = appid_feat.int64_list().value();
        uint32_t list_size = appid_vec.size();

        for (uint32_t i = 0; i < list_fea.size(); i++) {
            // 如果某个list为空，无对应数据，则直接返回
            if (list_fea[i] == nullptr) {
                return;
            }
            list_size = std::min(list_size, static_cast<uint32_t>(get_feature_size(*list_fea[i])));
        }

        for (uint32_t i = 0; i < list_fea.size(); i++) {
            switch (list_fea[i]->kind_case()) {
                case tensorflow::Feature::kBytesList: {
                    auto &vec = list_fea[i]->bytes_list().value();
                    for (uint32_t j = 0; j < list_size; j++) {
                        auto &vec_fea = value_map[appid_vec[j]];
                        if (vec_fea.empty()) {
                            vec_fea.resize(list_fea.size());
                        }
                        vec_fea[i].mutable_bytes_list()->add_value(vec[j]);
                    }
                    break;
                }

                case tensorflow::Feature::kFloatList: {
                    auto &vec = list_fea[i]->float_list().value();
                    for (uint32_t j = 0; j < list_size; j++) {
                        auto &vec_fea = value_map[appid_vec[j]];
                        if (vec_fea.empty()) {
                            vec_fea.resize(list_fea.size());
                        }
                        vec_fea[i].mutable_float_list()->add_value(vec[j]);
                    }
                    break;
                }

                case tensorflow::Feature::kInt64List: {
                    auto &vec = list_fea[i]->int64_list().value();
                    for (uint32_t j = 0; j < list_size; j++) {
                        auto &vec_fea = value_map[appid_vec[j]];
                        if (vec_fea.empty()) {
                            vec_fea.resize(list_fea.size());
                        }
                        vec_fea[i].mutable_int64_list()->add_value(vec[j]);
                    }
                    break;
                }

                default: {
                    break;
                }
            }
        }
    }

    void SeqHitListConfig::compute_one_feature(const tensorflow::Feature &feat,
                                               std::unordered_map<int64_t, std::vector<tensorflow::Feature>> &value_map,
                                               std::vector<tensorflow::DataType> &list_default_types,
                                               std::vector<tensorflow::Feature *> out_feat) {
        auto &item_vec = feat.int64_list().value();
        for (int64_t id: item_vec) {
            auto itr = value_map.find(id);
            if (itr != value_map.end()) {
                auto &feat_vec = itr->second;
                for (uint32_t i = 0; i < feat_vec.size(); i++) {
                    auto &feat = feat_vec[i];
                    switch (feat.kind_case()) {
                        case tensorflow::Feature::kBytesList: {
                            list_default_types[i] = tensorflow::DT_STRING;
                            for (const std::string &value: feat.bytes_list().value()) {
                                if (0 == i) {
                                    out_feat[0]->mutable_int64_list()->add_value(id);
                                }
                                out_feat[i + 1]->mutable_bytes_list()->add_value(value);
                            }
                            break;
                        }

                        case tensorflow::Feature::kFloatList: {
                            list_default_types[i] = tensorflow::DT_FLOAT;
                            for (const float f: feat.float_list().value()) {
                                if (0 == i) {
                                    out_feat[0]->mutable_int64_list()->add_value(id);
                                }
                                out_feat[i + 1]->mutable_float_list()->add_value(f);
                            }
                            break;
                        }

                        case tensorflow::Feature::kInt64List: {
                            list_default_types[i] = tensorflow::DT_INT64;
                            for (const int64_t value: feat.int64_list().value()) {
                                if (0 == i) {
                                    out_feat[0]->mutable_int64_list()->add_value(id);
                                }
                                out_feat[i + 1]->mutable_int64_list()->add_value(value);
                            }
                            break;
                        }

                        default:
                            break;
                    }
                }
            }
        }
    }

    bool SeqHitListV2Config::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqHitListV2Config::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *item_value = get_value(input_values, inputs_, 1);
        uint32_t list_size = input_values.size() - 2;
        std::vector<const Value *> list_values(list_size, nullptr);
        std::vector<tensorflow::DataType> list_default_types(list_size, tensorflow::DT_INVALID);

        uint32_t input_size = appid_value->ifeatures.size();

        for (uint32_t i = 2; i < input_values.size(); i++) {
            list_values[i - 2] = get_value(input_values, inputs_, i);
            input_size = std::min(input_size, static_cast<uint32_t>(list_values[i - 2]->ifeatures.size()));
        }

        const uint32_t batch_size = std::max(input_size, static_cast<uint32_t>(item_value->ifeatures.size()));
        uint32_t out_size = list_size + 1;
        std::vector<tensorflow::Feature *> out_feat(out_size);
        std::vector<tensorflow::FeatureList *> out_featlist(out_size);
        output.values.resize(out_size);
        for (uint32_t i = 0; i < out_size; i++) {
            Value &value = output.values[i];
            value.ifeatures.resize(batch_size);
        }

        const InputFeature *inf = nullptr;
        const InputFeature *inf_appid = nullptr;
        std::vector<const InputFeature *> list_ifea(list_size, nullptr);
        std::vector<const tensorflow::Feature *> list_fea(list_size, nullptr);

        // 根据 _data_type 分支处理
        if (_data_type == DataType::int64) {
            std::unordered_map<int64_t, std::vector<tensorflow::Feature>> value_map;

            for (uint32_t i = 0; i < batch_size; i++) {
                if (i == 0 || input_size == batch_size) {
                    value_map.clear();

                    inf_appid = get_idx_ifeatures(appid_value, i);
                    bool is_list = true;
                    for (uint32_t j = 0; j < list_size; j++) {
                        list_ifea[j] = get_idx_ifeatures(list_values[j], i);
                        if (list_ifea[j]->feature_list == nullptr) {
                            is_list = false;
                        }
                    }

                    if (inf_appid->feature_list && is_list) {
                        uint32_t min_list_size = inf_appid->feature_list->feature_size();
                        for (uint32_t j = 0; j < list_size; j++) {
                            min_list_size = std::min(min_list_size,
                                                     static_cast<uint32_t>(list_ifea[j]->feature_list->feature_size()));
                        }
                        for (uint32_t j = 0; j < min_list_size; j++) {
                            for (uint32_t k = 0; k < list_size; k++) {
                                list_fea[k] = &list_ifea[k]->feature_list->feature(j);
                            }
                            compute_one_input(inf_appid->feature_list->feature(j), list_fea, value_map);
                        }
                    } else {
                        for (uint32_t j = 0; j < list_size; j++) {
                            list_fea[j] = list_ifea[j]->feature;
                        }
                        compute_one_input(*inf_appid->feature, list_fea, value_map);
                    }
                }

                inf = get_idx_ifeatures(item_value, i);

                if (inf->feature_list) {
                    for (uint32_t j = 0; j < out_size; j++) {
                        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                        output.values[j].ifeatures[i].feature_list = out_featlist[j];
                    }

                    if (unlikely(value_map.empty())) {
                        continue;
                    }

                    for (auto &feat: inf->feature_list->feature()) {
                        for (uint32_t j = 0; j < out_size; j++) {
                            out_feat[j] = out_featlist[j]->add_feature();
                        }
                        compute_one_feature(feat, value_map, list_default_types, out_feat);
                    }
                } else {
                    for (uint32_t j = 0; j < out_size; j++) {
                        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                        output.values[j].ifeatures[i].feature = out_feat[j];
                    }

                    if (unlikely(value_map.empty())) {
                        continue;
                    }

                    if (likely(inf->feature)) {
                        compute_one_feature(*inf->feature, value_map, list_default_types, out_feat);
                    }
                }
            }

            output.values[0].defalut_type = tensorflow::DT_INT64;
            for (uint32_t i = 0; i < list_size; i++) {
                output.values[i + 1].defalut_type = tensorflow::DT_INT64;
            }

        } else {// DataType::string
            std::unordered_map<std::string, std::vector<tensorflow::Feature>> value_map;

            for (uint32_t i = 0; i < batch_size; i++) {
                if (i == 0 || input_size == batch_size) {
                    value_map.clear();

                    inf_appid = get_idx_ifeatures(appid_value, i);
                    bool is_list = true;
                    for (uint32_t j = 0; j < list_size; j++) {
                        list_ifea[j] = get_idx_ifeatures(list_values[j], i);
                        if (list_ifea[j]->feature_list == nullptr) {
                            is_list = false;
                        }
                    }

                    if (inf_appid->feature_list && is_list) {
                        uint32_t min_list_size = inf_appid->feature_list->feature_size();
                        for (uint32_t j = 0; j < list_size; j++) {
                            min_list_size = std::min(min_list_size,
                                                     static_cast<uint32_t>(list_ifea[j]->feature_list->feature_size()));
                        }
                        for (uint32_t j = 0; j < min_list_size; j++) {
                            for (uint32_t k = 0; k < list_size; k++) {
                                list_fea[k] = &list_ifea[k]->feature_list->feature(j);
                            }
                            compute_one_input(inf_appid->feature_list->feature(j), list_fea, value_map);
                        }
                    } else {
                        for (uint32_t j = 0; j < list_size; j++) {
                            list_fea[j] = list_ifea[j]->feature;
                        }
                        compute_one_input(*inf_appid->feature, list_fea, value_map);
                    }
                }

                inf = get_idx_ifeatures(item_value, i);

                if (inf->feature_list) {
                    for (uint32_t j = 0; j < out_size; j++) {
                        out_featlist[j] = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(output.arena);
                        output.values[j].ifeatures[i].feature_list = out_featlist[j];
                    }

                    if (unlikely(value_map.empty())) {
                        continue;
                    }

                    for (auto &feat: inf->feature_list->feature()) {
                        for (uint32_t j = 0; j < out_size; j++) {
                            out_feat[j] = out_featlist[j]->add_feature();
                        }
                        compute_one_feature(feat, value_map, list_default_types, out_feat);
                    }
                } else {
                    for (uint32_t j = 0; j < out_size; j++) {
                        out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                        output.values[j].ifeatures[i].feature = out_feat[j];
                    }

                    if (unlikely(value_map.empty())) {
                        continue;
                    }

                    if (likely(inf->feature)) {
                        compute_one_feature(*inf->feature, value_map, list_default_types, out_feat);
                    }
                }
            }

            output.values[0].defalut_type = tensorflow::DT_STRING;
            for (uint32_t i = 0; i < list_size; i++) {
                output.values[i + 1].defalut_type = tensorflow::DT_STRING;
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    template<typename T>
    void SeqHitListV2Config::compute_one_input(const tensorflow::Feature &appid_feat,
                                               std::vector<const tensorflow::Feature *> &list_fea,
                                               std::unordered_map<T, std::vector<tensorflow::Feature>> &value_map) {
        // 通过traits获取appid_vec
        const auto &appid_vec = AppIdVecGetter<T>::get(appid_feat);
        uint32_t list_size = appid_vec.size();

        // 遍历每个list_fea，检查长度并更新list_size为最小值
        for (uint32_t i = 0; i < list_fea.size(); i++) {
            if (list_fea[i] == nullptr) {
                return;// 某项为空则直接返回
            }
            list_size = std::min(list_size, static_cast<uint32_t>(get_feature_size(*list_fea[i])));
        }

        // 遍历feature，按类型分发
        for (uint32_t i = 0; i < list_fea.size(); i++) {
            switch (list_fea[i]->kind_case()) {
                case tensorflow::Feature::kBytesList: {
                    auto &vec = list_fea[i]->bytes_list().value();
                    for (uint32_t j = 0; j < list_size; j++) {
                        T key = appid_vec[j];
                        auto &vec_fea = value_map[key];
                        if (vec_fea.empty()) {
                            vec_fea.resize(list_fea.size());
                        }
                        vec_fea[i].mutable_bytes_list()->add_value(vec[j]);
                    }
                    break;
                }
                case tensorflow::Feature::kFloatList: {
                    auto &vec = list_fea[i]->float_list().value();
                    for (uint32_t j = 0; j < list_size; j++) {
                        T key = appid_vec[j];
                        auto &vec_fea = value_map[key];
                        if (vec_fea.empty()) {
                            vec_fea.resize(list_fea.size());
                        }
                        vec_fea[i].mutable_float_list()->add_value(vec[j]);
                    }
                    break;
                }
                case tensorflow::Feature::kInt64List: {
                    auto &vec = list_fea[i]->int64_list().value();
                    for (uint32_t j = 0; j < list_size; j++) {
                        T key = appid_vec[j];
                        auto &vec_fea = value_map[key];
                        if (vec_fea.empty()) {
                            vec_fea.resize(list_fea.size());
                        }
                        vec_fea[i].mutable_int64_list()->add_value(vec[j]);
                    }
                    break;
                }
                default: {
                    break;
                }
            }
        }
    }

    template<typename T>
    void SeqHitListV2Config::compute_one_feature(const tensorflow::Feature &feat,
                                                 std::unordered_map<T, std::vector<tensorflow::Feature>> &value_map,
                                                 std::vector<tensorflow::DataType> &list_default_types,
                                                 std::vector<tensorflow::Feature *> out_feat) {
        // traits获取appid列表（泛型T）
        const auto &item_vec = AppIdVecGetter<T>::get(feat);

        for (const T &id: item_vec) {
            auto itr = value_map.find(id);
            if (itr != value_map.end()) {
                auto &feat_vec = itr->second;
                for (uint32_t i = 0; i < feat_vec.size(); i++) {
                    const auto &cur_feat = feat_vec[i];
                    switch (cur_feat.kind_case()) {
                        case tensorflow::Feature::kBytesList: {
                            list_default_types[i] = tensorflow::DT_STRING;
                            const auto &values = cur_feat.bytes_list().value();
                            for (const std::string &value: values) {
                                if (i == 0) {
                                    add_id_to_outfeat(id, out_feat[0]);
                                }
                                out_feat[i + 1]->mutable_bytes_list()->add_value(value);
                            }
                            break;
                        }
                        case tensorflow::Feature::kFloatList: {
                            list_default_types[i] = tensorflow::DT_FLOAT;
                            const auto &values = cur_feat.float_list().value();
                            for (const float f: values) {
                                if (i == 0) {
                                    add_id_to_outfeat(id, out_feat[0]);
                                }
                                out_feat[i + 1]->mutable_float_list()->add_value(f);
                            }
                            break;
                        }
                        case tensorflow::Feature::kInt64List: {
                            list_default_types[i] = tensorflow::DT_INT64;
                            const auto &values = cur_feat.int64_list().value();
                            for (const int64_t v: values) {
                                if (i == 0) {
                                    add_id_to_outfeat(id, out_feat[0]);
                                }
                                out_feat[i + 1]->mutable_int64_list()->add_value(v);
                            }
                            break;
                        }
                        default:
                            break;
                    }
                }
            }
        }
    }

    bool SeqTopnDirectConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqTopnDirectConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *message_value = get_value(input_values, inputs_, 0);

        const uint32_t batch_size = message_value->ifeatures.size();
        const InputFeature *inf_message = nullptr;
        const google::protobuf::Message *mess = nullptr;
        uint32_t extract_size = fields_.size();
        std::vector<tensorflow::Feature *> out_feat(extract_size);
        std::vector<tensorflow::FeatureList *> out_featlist(extract_size);

        output.values.resize(extract_size);
        for (uint32_t i = 0; i < extract_size; i++) {
            Value &value = output.values[i];
            value.ifeatures.resize(batch_size);
        }
        MessageCompute::message_fill_fields_dtype_to_value(message_value, fields_, output.values, output_);

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            inf_message = &message_value->ifeatures[i];
            std::vector<std::pair<int64_t, const google::protobuf::Message *>> int_vec;
            std::vector<std::pair<float, const google::protobuf::Message *>> float_vec;
            std::vector<const google::protobuf::Message *> topn_vec;

            //将value和message填充到vec
            for (uint32_t j = 0; j < inf_message->messages.size(); j++) {
                mess = inf_message->messages[j];
                auto desc = mess->GetDescriptor();
                auto ref = mess->GetReflection();
                auto field = desc->FindFieldByName(filter_key_);

                if (unlikely(nullptr == ref || nullptr == field)) {
                    THROW_ERROR("failed, get null_ptr on filter_key:" + filter_key_ + ", name:" + output_);
                    return false;
                }

                if (unlikely(field->is_repeated())) {
                    THROW_ERROR("failed, is repeated filter_key:" + filter_key_ + ", name:" + output_);
                    return false;
                }

                switch (field->cpp_type()) {
                    case google::protobuf::FieldDescriptor::CPPTYPE_INT64: {
                        int_vec.emplace_back(ref->GetInt64(*mess, field), mess);
                    } break;

                    case google::protobuf::FieldDescriptor::CPPTYPE_INT32: {
                        int_vec.emplace_back(ref->GetInt32(*mess, field), mess);
                    } break;

                    case google::protobuf::FieldDescriptor::CPPTYPE_FLOAT: {
                        float_vec.emplace_back(ref->GetFloat(*mess, field), mess);
                    } break;

                    case google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE: {
                        float_vec.emplace_back(ref->GetDouble(*mess, field), mess);
                    } break;

                    default: {
                        THROW_ERROR("invalid cpp_type:" + std::to_string(field->cpp_type()) +
                                    " filter_key:" + filter_key_ + " name:" + output_);
                        return false;
                    } break;
                }
            }

            //排序筛选topn
            if (int_vec.size() > 0) {
                top_n_compute_.compute_vec<int64_t>(int_vec, topn_vec);
            } else {
                top_n_compute_.compute_vec<float>(float_vec, topn_vec);
            }

            for (uint32_t j = 0; j < extract_size; j++) {
                out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                output.values[j].ifeatures[i].feature = out_feat[j];
            }

            for (const google::protobuf::Message *mess: topn_vec) {
                MessageCompute::message_fill_fields_to_feature(mess, fields_, output_, out_feat);
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    SeqAvgIntervalConfig::SeqAvgIntervalConfig(const std::string &output, const std::vector<std::string> &source,
                                               DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                               const std::vector<std::string> &strategy, TimeType time_type,
                                               float one_default_value, float empty_default_value)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy), time_type_(time_type),
          one_default_value_(one_default_value), empty_default_value_(empty_default_value) {
    }

    std::string SeqAvgIntervalConfig::get_config() {
        std::string display = "seq_avg_interval:time_type:";
        display.append(std::to_string(static_cast<int64_t>(time_type_)));
        display.append(", one_default_value:").append(std::to_string(one_default_value_));
        display.append(", empty_default_value:").append(std::to_string(empty_default_value_));
        return display;
    }

    bool SeqAvgIntervalConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqAvgIntervalConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *input_value = get_value(input_values, inputs_, 0);
        size_t batch_size = input_value->ifeatures.size();

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);

        output.values[0].defalut_type = tensorflow::DT_FLOAT;
        tensorflow::Feature *out_feature = nullptr;
        const InputFeature *inf_value = nullptr;

        //输出
        for (uint32_t i = 0; i < batch_size; i++) {
            inf_value = &input_value->ifeatures[i];
            std::vector<int64_t> time_vec;
            float sum = 0;
            float avg = 0;

            fill_ifeature_to_vec(inf_value, time_vec);

            out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            value.ifeatures[i].feature = out_feature;

            if (time_vec.size() > 1) {
                switch (time_type_) {
                    case Day: {
                        for (uint32_t j = 0; j < time_vec.size() - 1; j++) {
                            sum += diff_days_flaot(time_vec[j + 1] / 1000, time_vec[j] / 1000);
                        }
                        avg = sum / (time_vec.size() - 1);
                        out_feature->mutable_float_list()->add_value(avg);
                    } break;

                    case Hour: {
                        for (uint32_t j = 0; j < time_vec.size() - 1; j++) {
                            sum += diff_hours_flaot(time_vec[j + 1] / 1000, time_vec[j] / 1000);
                        }
                        avg = sum / (time_vec.size() - 1);
                        out_feature->mutable_float_list()->add_value(avg);
                    } break;

                    default:
                        break;
                }
            } else if (!time_vec.empty()) {
                out_feature->mutable_float_list()->add_value(one_default_value_);
            } else {
                out_feature->mutable_float_list()->add_value(empty_default_value_);
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    void SeqAvgIntervalConfig::fill_ifeature_to_vec(const InputFeature *hf, std::vector<int64_t> &vec) {
        // 展开所有的appid
        if (likely(hf->feature)) {
            fill_feature_to_vec(*hf->feature, vec);
        } else if (likely(hf->feature_list)) {
            for (auto &feat: hf->feature_list->feature()) {
                fill_feature_to_vec(feat, vec);
            }
        }
    }

    void SeqAvgIntervalConfig::fill_feature_to_vec(const tensorflow::Feature &feat, std::vector<int64_t> &vec) {
        vec.reserve(vec.size() + feat.int64_list().value_size());
        for (int64_t num: feat.int64_list().value()) {
            vec.push_back(num);
        }
    }

    SeqStatisticsConfig::SeqStatisticsConfig(const std::string &output, const std::vector<std::string> &source,
                                             DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                             const std::vector<std::string> &strategy, const std::string &math_type)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy) {
        static const std::unordered_set<std::string> math_type_set = {"min", "max", "avg"};

        const auto str_vec = Calc::split_string(math_type, ",");
        math_type_.reserve(str_vec.size());
        for (const auto &str: str_vec) {
            if (math_type_set.count(str)) {
                math_type_.emplace_back(str);
            } else {
                THROW_ERROR("UNKNOWN MATH_TYPE" + str);
            }
        }
    }

    std::string SeqStatisticsConfig::get_config() {
        std::string display = "seq_statistics:math_type:";
        bool comma = false;
        for (const auto &type: math_type_) {
            if (comma)
                display.append(",");
            display.append(type);
            comma = true;
        }
        return display;
    }

    bool SeqStatisticsConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqStatisticsConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const std::size_t input_values_size = input_values.size();

        if (input_values_size == 1) {
            const Value *input_value = get_value(input_values, inputs_, 0);
            const std::size_t batch_size = input_value->ifeatures.size();

            output.values.resize(math_type_.size());

            std::vector<InputFeature>::const_iterator inf;
            tensorflow::Feature *out_feature = nullptr;
            tensorflow::Feature::KindCase kind_case = tensorflow::Feature::KindCase::KIND_NOT_SET;

            for (std::size_t i = 0; i < math_type_.size(); ++i) {// 遍历math_type
                Value &value = output.values[i];
                value.ifeatures.resize(batch_size);

                for (std::size_t j = 0; j < batch_size; ++j) {
                    inf = input_value->ifeatures.begin() + j;

                    if (likely(inf->feature)) {
                        kind_case = inf->feature->kind_case();
                    } else if (likely(inf->feature_list)) {
                        for (const auto &feat: inf->feature_list->feature()) {
                            kind_case = feat.kind_case();
                        }
                    }
                    out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    value.ifeatures[j].feature = out_feature;
                    switch (kind_case) {
                        case tensorflow::Feature::KindCase::kInt64List: {
                            std::vector<int64_t> num_vector;
                            fill_ifeature_to_vec(*inf, num_vector);
                            if (num_vector.empty()) {
                                continue;
                            }
                            const auto &math_type = math_type_[i];
                            if (math_type == "min") {
                                auto iter = std::min_element(num_vector.begin(), num_vector.end());
                                out_feature->mutable_int64_list()->add_value(*iter);
                            } else if (math_type == "max") {
                                auto iter = std::max_element(num_vector.begin(), num_vector.end());
                                out_feature->mutable_int64_list()->add_value(*iter);
                            } else if (math_type == "avg") {
                                float avg =
                                        std::accumulate(num_vector.begin(), num_vector.end(), 0.0f) / num_vector.size();
                                out_feature->mutable_float_list()->add_value(avg);
                            } else {
                                THROW_ERROR("UNKNOWN MATH_TYPE" + math_type);
                            }

                            break;
                        }
                        case tensorflow::Feature::KindCase::kFloatList: {
                            std::vector<float> num_vector;
                            fill_ifeature_to_vec(*inf, num_vector);
                            if (num_vector.empty()) {
                                continue;
                            }
                            const auto &math_type = math_type_[i];
                            if (math_type == "min") {
                                auto iter = std::min_element(num_vector.begin(), num_vector.end());
                                out_feature->mutable_float_list()->add_value(*iter);
                            } else if (math_type == "max") {
                                auto iter = std::max_element(num_vector.begin(), num_vector.end());
                                out_feature->mutable_float_list()->add_value(*iter);
                            } else if (math_type == "avg") {
                                float avg =
                                        std::accumulate(num_vector.begin(), num_vector.end(), 0.0f) / num_vector.size();
                                out_feature->mutable_float_list()->add_value(avg);
                            } else {
                                THROW_ERROR("UNKNOWN MATH_TYPE" + math_type);
                            }

                            break;
                        }
                        case tensorflow::Feature::KindCase::kBytesList: {
                            THROW_ERROR("unsupport data type [string]!");
                            break;
                        }
                        default: {
                            break;
                        }
                    }
                }
            }
        } else if (input_values_size == 2) {
            const Value *input_value = get_value(input_values, inputs_, 0);     // 金额序列
            const Value *aggregation_list = get_value(input_values, inputs_, 1);// 聚合序列
            if (input_value->ifeatures.size() != aggregation_list->ifeatures.size()) {
                THROW_ERROR("input source batch size not match agg batch size!");
                return false;
            }
            const std::size_t batch_size = input_value->ifeatures.size();

            output.values.resize(math_type_.size() + 1);// 最后一列是聚合序列
            Value &value = output.values[0];
            value.ifeatures.resize(batch_size);

            std::vector<InputFeature>::const_iterator inf;
            tensorflow::Feature *out_feature = nullptr;
            tensorflow::Feature::KindCase kind_case = tensorflow::Feature::KindCase::KIND_NOT_SET;

            for (std::size_t i = 0; i <= math_type_.size(); ++i) {// 遍历math_type
                Value &value = output.values[i];
                value.ifeatures.resize(batch_size);

                for (std::size_t j = 0; j < batch_size; ++j) {
                    inf = input_value->ifeatures.begin() + j;

                    std::vector<int64_t> aggregation_vec;
                    fill_ifeature_to_vec(*(aggregation_list->ifeatures.begin() + j), aggregation_vec);

                    if (likely(inf->feature)) {
                        kind_case = inf->feature->kind_case();
                    } else if (likely(inf->feature_list)) {
                        for (const auto &feat: inf->feature_list->feature()) {
                            kind_case = feat.kind_case();
                        }
                    }
                    out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                    value.ifeatures[j].feature = out_feature;
                    switch (kind_case) {
                        case tensorflow::Feature::KindCase::kInt64List: {
                            std::vector<int64_t> num_vector;
                            fill_ifeature_to_vec(*inf, num_vector);
                            if (unlikely(num_vector.size() != aggregation_vec.size())) {
                                THROW_ERROR("aggregation's size not equal num's size");
                            }

                            std::map<int64_t, std::vector<int64_t>> aggregation_num_map;
                            for (std::size_t k = 0; k < aggregation_vec.size(); ++k) {
                                aggregation_num_map[aggregation_vec[k]].emplace_back(num_vector[k]);
                            }

                            const auto &math_type = math_type_[i];
                            for (const auto &it: aggregation_num_map) {
                                if (i == math_type_.size()) {
                                    out_feature->mutable_int64_list()->add_value(it.first);
                                } else {
                                    if (math_type == "min") {
                                        auto iter = std::min_element(it.second.begin(), it.second.end());
                                        out_feature->mutable_int64_list()->add_value(*iter);
                                    } else if (math_type == "max") {
                                        auto iter = std::max_element(it.second.begin(), it.second.end());
                                        out_feature->mutable_int64_list()->add_value(*iter);
                                    } else if (math_type == "avg") {
                                        float avg = std::accumulate(it.second.begin(), it.second.end(), 0.0f) /
                                                    it.second.size();
                                        out_feature->mutable_float_list()->add_value(avg);
                                    } else {
                                        THROW_ERROR("UNKNOWN MATH_TYPE" + math_type);
                                    }
                                }
                            }

                            break;
                        }
                        case tensorflow::Feature::KindCase::kFloatList: {
                            std::vector<float> num_vector;
                            fill_ifeature_to_vec(*inf, num_vector);

                            if (unlikely(num_vector.size() != aggregation_vec.size())) {
                                THROW_ERROR("aggregation's size not equal num's size");
                            }

                            std::map<int64_t, std::vector<int64_t>> aggregation_num_map;
                            for (std::size_t k = 0; k < aggregation_vec.size(); ++k) {
                                aggregation_num_map[aggregation_vec[k]].emplace_back(num_vector[k]);
                            }

                            const auto &math_type = math_type_[i];

                            for (const auto &it: aggregation_num_map) {
                                if (i == math_type_.size()) {
                                    out_feature->mutable_int64_list()->add_value(it.first);
                                } else {
                                    if (math_type == "min") {
                                        auto iter = std::min_element(it.second.begin(), it.second.end());
                                        out_feature->mutable_float_list()->add_value(*iter);
                                    } else if (math_type == "max") {
                                        auto iter = std::max_element(it.second.begin(), it.second.end());
                                        out_feature->mutable_float_list()->add_value(*iter);
                                    } else if (math_type == "avg") {
                                        float avg = std::accumulate(it.second.begin(), it.second.end(), 0.0f) /
                                                    it.second.size();
                                        out_feature->mutable_float_list()->add_value(avg);
                                    } else {
                                        THROW_ERROR("UNKNOWN MATH_TYPE" + math_type);
                                    }
                                }
                            }
                            break;
                        }
                        case tensorflow::Feature::KindCase::kBytesList: {
                            THROW_ERROR("unsupport data type [string]!");
                            break;
                        }
                        default: {
                            break;
                        }
                    }
                }
            }
        }
        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    SeqSortConfig::SeqSortConfig(const std::string &output, const std::vector<std::string> &source,
                                 DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                 const std::vector<std::string> &strategy, const std::string &sort_cols,
                                 const std::string &sort_orders)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy) {
        const auto cols = Calc::split_string(sort_cols, ",");
        const auto orders = Calc::split_string(sort_orders, ",");

        // 校验cols和orders长度是否相等
        if (cols.size() != orders.size()) {
            THROW_ERROR("sort_cols's size not equal sort_orders's size");
        }

        // 以cols和orders初始化orders_，并校验cols是否有重复元素，cols中的值是否都小于inputs_size，orders是否只能取desc和asc
        const std::size_t inputs_size = inputs_.size();
        std::unordered_set<std::size_t> col_set;
        for (std::size_t i = 0; i < cols.size(); ++i) {
            std::size_t key = std::stoul(cols[i]);
            if (col_set.emplace(key).second) {
                if (key < inputs_size) {
                    if (orders[i] == "desc") {
                        orders_.emplace_back(key, Order::desc);
                    } else if (orders[i] == "asc") {
                        orders_.emplace_back(key, Order::asc);
                    } else {
                        THROW_ERROR("unknown order");
                    }
                } else {
                    THROW_ERROR("col >= inputs_size");
                }
            } else {
                THROW_ERROR("duplicate columns");
            }
        }
    }

    std::string SeqSortConfig::get_config() {
        std::string config_str = "seq_sort:";
        for (const auto &order: orders_) {
            config_str.append(std::to_string(order.first))
                    .append(":")
                    .append(order.second == Order::desc ? std::string("desc") : std::string("asc"))
                    .append(" ");
        }
        return config_str;
    }

    bool SeqSortConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqStatisticsConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const std::size_t input_values_size = input_values.size();
        output.values.resize(input_values_size);

        std::size_t batch_size = std::numeric_limits<int64_t>::max();
        std::vector<const Value *> value_vec;
        value_vec.reserve(input_values_size);
        for (size_t i = 0; i < input_values_size; ++i) {
            const Value *input_value = get_value(input_values, inputs_, i);
            batch_size = std::min(input_value->ifeatures.size(), batch_size);
            value_vec.emplace_back(input_value);
        }
        for (auto &value: output.values) {
            value.ifeatures.resize(batch_size);
        }

        for (std::size_t i = 0; i < batch_size; ++i) {
            std::vector<const tensorflow::Feature *> feature_inputs;

            for (const auto &it: value_vec) {
                feature_inputs.emplace_back(it->ifeatures[i].feature);
            }

            // 获取索引长度，取所有序列的最短长度
            int index_size = std::numeric_limits<int>::max();
            for (const auto &it: feature_inputs) {
                switch (it->kind_case()) {
                    case tensorflow::Feature::KindCase::kInt64List: {
                        index_size = std::min(index_size, it->int64_list().value_size());
                        break;
                    }
                    case tensorflow::Feature::KindCase::kFloatList: {
                        index_size = std::min(index_size, it->float_list().value_size());
                        break;
                    }
                    case tensorflow::Feature::KindCase::kBytesList: {
                        index_size = std::min(index_size, it->bytes_list().value_size());
                        break;
                    }
                    default:
                        break;
                }
            }
            index_size = (index_size == std::numeric_limits<int>::max()) ? 0 : index_size;

            auto compare = [this, feature_inputs](int index_1, int index_2) {
                for (const auto &pair: orders_) {
                    auto &feature_to_cmp = feature_inputs[pair.first];
                    switch (feature_to_cmp->kind_case()) {
                        case tensorflow::Feature::KindCase::kInt64List: {
                            int64_t value_1 = feature_to_cmp->int64_list().value(index_1);
                            int64_t value_2 = feature_to_cmp->int64_list().value(index_2);
                            if (pair.second == Order::desc) {
                                if (value_1 < value_2) {
                                    return false;
                                } else if (value_1 > value_2) {
                                    return true;
                                } else {
                                    continue;
                                }
                            } else {
                                if (value_1 > value_2) {
                                    return false;
                                } else if (value_1 < value_2) {
                                    return true;
                                } else {
                                    continue;
                                }
                            }
                            break;
                        }
                        case tensorflow::Feature::KindCase::kFloatList: {
                            float value_1 = feature_to_cmp->float_list().value(index_1);
                            float value_2 = feature_to_cmp->float_list().value(index_2);
                            if (pair.second == Order::desc) {
                                if (value_1 < value_2) {
                                    return false;
                                } else if (value_1 > value_2) {
                                    return true;
                                } else {
                                    continue;
                                }
                            } else {
                                if (value_1 > value_2) {
                                    return false;
                                } else if (value_1 < value_2) {
                                    return true;
                                } else {
                                    continue;
                                }
                            }
                            break;
                        }
                        case tensorflow::Feature::KindCase::kBytesList: {
                            const std::string &value_1 = feature_to_cmp->bytes_list().value(index_1);
                            const std::string &value_2 = feature_to_cmp->bytes_list().value(index_2);
                            if (pair.second == Order::desc) {
                                if (value_1 < value_2) {
                                    return false;
                                } else if (value_1 > value_2) {
                                    return true;
                                } else {
                                    continue;
                                }
                            } else {
                                if (value_1 > value_2) {
                                    return false;
                                } else if (value_1 < value_2) {
                                    return true;
                                } else {
                                    continue;
                                }
                            }
                            break;
                        }
                        default:
                            break;
                    }
                }
                return false;
            };

            std::vector<int> index_vec;
            for (int j = 0; j < index_size; ++j) {
                index_vec.emplace_back(j);
            }

            std::sort(index_vec.begin(), index_vec.end(), compare);

            for (std::size_t j = 0; j < input_values_size; ++j) {
                tensorflow::Feature *out_feature =
                        google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                for (const auto &index: index_vec) {
                    const auto &feature_to_output = feature_inputs[j];
                    switch (feature_to_output->kind_case()) {
                        case (tensorflow::Feature::KindCase::kInt64List): {
                            out_feature->mutable_int64_list()->add_value(feature_to_output->int64_list().value(index));
                            break;
                        }
                        case (tensorflow::Feature::KindCase::kFloatList): {
                            out_feature->mutable_float_list()->add_value(feature_to_output->float_list().value(index));
                            break;
                        }
                        case (tensorflow::Feature::KindCase::kBytesList): {
                            out_feature->mutable_bytes_list()->add_value(feature_to_output->bytes_list().value(index));
                            break;
                        }
                        default:
                            break;
                    }
                }

                output.values[j].ifeatures[i].feature = out_feature;
            }
        }

        LogDebug("------------ compute {} done ------------", output_);
        return true;
    }

    SeqFlattenConfig::SeqFlattenConfig(const std::string &output, const std::vector<std::string> &source,
                                       DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                       const std::vector<std::string> &strategy, const std::string &from_lv1,
                                       const std::string &from_lv2, const std::string &repeated_field)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy),
          from_lv1_(Calc::split_string(from_lv1, ",")), from_lv2_(Calc::split_string(from_lv2, ",")),
          repeated_field_(repeated_field) {
    }

    std::string SeqFlattenConfig::get_config() {
        std::string config_str = "seq_flatten: ";
        config_str.append("from_lv1: [");
        bool comma = false;
        for (const auto &lv1: from_lv1_) {
            if (comma)
                config_str.append(",");
            config_str.append(lv1);
            comma = true;
        }
        config_str.append("];");

        config_str.append("from_lv2: [");
        comma = false;
        for (const auto &lv2: from_lv2_) {
            if (comma)
                config_str.append(",");
            config_str.append(lv2);
            comma = true;
        }
        config_str.append("];");

        config_str.append("repeated_field: ").append(repeated_field_);

        return std::string();
    }

    bool SeqFlattenConfig::compute(const std::vector<const Output *> &input_values, Output &output) {

        const Value *input_value = get_value(input_values, inputs_, 0);
        const std::size_t batch_size = input_value->ifeatures.size();

        // 预分配空间
        output.values.resize(from_lv1_.size() + from_lv2_.size());
        for (auto &value: output.values) {
            value.ifeatures.resize(batch_size);
            for (std::size_t i = 0; i < batch_size; ++i) {
                value.ifeatures[i].feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            }
        }

        tensorflow::Feature *out_feature = nullptr;
        std::vector<InputFeature>::const_iterator inf;

        for (std::size_t i = 0; i < batch_size; ++i) {
            inf = input_value->ifeatures.begin() + i;

            for (const auto &message: inf->messages) {// 遍历每条message
                auto descriptor = message->GetDescriptor();
                auto reflection = message->GetReflection();

                // 获取重复repeated字段长度
                auto repeated_field = descriptor->FindFieldByName(repeated_field_);
                const int repeated_size = reflection->FieldSize(*message, repeated_field);

                for (std::size_t j = 0; j < from_lv1_.size(); ++j) {// 遍历from_lv1_
                    out_feature = const_cast<tensorflow::Feature *>(output.values[j].ifeatures[i].feature);

                    auto lv1_field = descriptor->FindFieldByName(from_lv1_[j]);
                    switch (lv1_field->cpp_type()) {
                        case (google::protobuf::FieldDescriptor::CPPTYPE_INT32): {
                            auto value = reflection->GetInt32(*message, lv1_field);
                            for (int i = 0; i < repeated_size; ++i) {
                                out_feature->mutable_int64_list()->add_value(value);
                            }
                            break;
                        }
                        case (google::protobuf::FieldDescriptor::CPPTYPE_INT64): {
                            auto value = reflection->GetInt64(*message, lv1_field);
                            for (int i = 0; i < repeated_size; ++i) {
                                out_feature->mutable_int64_list()->add_value(value);
                            }
                            break;
                        }
                        case (google::protobuf::FieldDescriptor::CPPTYPE_UINT32): {
                            auto value = reflection->GetUInt32(*message, lv1_field);
                            for (int i = 0; i < repeated_size; ++i) {
                                out_feature->mutable_int64_list()->add_value(value);
                            }
                            break;
                        }
                        case (google::protobuf::FieldDescriptor::CPPTYPE_UINT64): {
                            auto value = reflection->GetUInt64(*message, lv1_field);
                            for (int i = 0; i < repeated_size; ++i) {
                                out_feature->mutable_int64_list()->add_value(value);
                            }
                            break;
                        }
                        case (google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE): {
                            auto value = reflection->GetDouble(*message, lv1_field);
                            for (int i = 0; i < repeated_size; ++i) {
                                out_feature->mutable_float_list()->add_value(value);
                            }
                            break;
                        }
                        case (google::protobuf::FieldDescriptor::CPPTYPE_FLOAT): {
                            auto value = reflection->GetFloat(*message, lv1_field);
                            for (int i = 0; i < repeated_size; ++i) {
                                out_feature->mutable_float_list()->add_value(value);
                            }
                            break;
                        }
                        case (google::protobuf::FieldDescriptor::CPPTYPE_STRING): {
                            auto value = reflection->GetString(*message, lv1_field);
                            for (int i = 0; i < repeated_size; ++i) {
                                out_feature->mutable_bytes_list()->add_value(std::move(value));
                            }
                            break;
                        }
                        default:
                            break;
                    }
                }

                if (repeated_field->cpp_type() != google::protobuf::FieldDescriptor::CPPTYPE_MESSAGE) {
                    THROW_ERROR("repeated_field must be message");
                }

                for (std::size_t j = 0; j < from_lv2_.size(); ++j) {// 遍历from_lv2_
                    out_feature =
                            const_cast<tensorflow::Feature *>(output.values[from_lv1_.size() + j].ifeatures[i].feature);

                    for (int k = 0; k < repeated_size; ++k) {
                        const auto &repeated_message = reflection->GetRepeatedMessage(*message, repeated_field, k);

                        auto repeated_descriptor = repeated_message.GetDescriptor();
                        auto repeated_reflection = repeated_message.GetReflection();

                        auto lv2_field = repeated_descriptor->FindFieldByName(from_lv2_[j]);
                        switch (lv2_field->cpp_type()) {
                            case (google::protobuf::FieldDescriptor::CPPTYPE_INT32): {
                                auto value = repeated_reflection->GetInt32(repeated_message, lv2_field);
                                out_feature->mutable_int64_list()->add_value(value);
                                break;
                            }
                            case (google::protobuf::FieldDescriptor::CPPTYPE_INT64): {
                                auto value = repeated_reflection->GetInt64(repeated_message, lv2_field);
                                out_feature->mutable_int64_list()->add_value(value);
                                break;
                            }
                            case (google::protobuf::FieldDescriptor::CPPTYPE_UINT32): {
                                auto value = repeated_reflection->GetUInt32(repeated_message, lv2_field);
                                out_feature->mutable_int64_list()->add_value(value);
                                break;
                            }
                            case (google::protobuf::FieldDescriptor::CPPTYPE_UINT64): {
                                auto value = repeated_reflection->GetUInt64(repeated_message, lv2_field);
                                out_feature->mutable_int64_list()->add_value(value);
                                break;
                            }
                            case (google::protobuf::FieldDescriptor::CPPTYPE_DOUBLE): {
                                auto value = repeated_reflection->GetDouble(repeated_message, lv2_field);
                                out_feature->mutable_float_list()->add_value(value);
                                break;
                            }
                            case (google::protobuf::FieldDescriptor::CPPTYPE_FLOAT): {
                                auto value = repeated_reflection->GetFloat(repeated_message, lv2_field);
                                out_feature->mutable_float_list()->add_value(value);
                                break;
                            }
                            case (google::protobuf::FieldDescriptor::CPPTYPE_STRING): {
                                auto value = repeated_reflection->GetString(repeated_message, lv2_field);
                                out_feature->mutable_bytes_list()->add_value(std::move(value));
                                break;
                            }
                            default:
                                break;
                        }
                    }
                }
            }
        }
        return true;
    }

    SeqArithmeticConfig::SeqArithmeticConfig(const std::string &output, const std::vector<std::string> &source,
                                             DefaultValue &default_input_value, bool save, bool allow_empty_output,
                                             const std::vector<std::string> &strategy, const std::string &math_type)
        : Config(output, source, default_input_value, save, allow_empty_output, strategy) {
        if (math_type == "+")
            math_type_ = Mathematic::Add;
        else if (math_type == "-")
            math_type_ = Mathematic::Sub;
        else if (math_type == "*")
            math_type_ = Mathematic::Mul;
        else
            THROW_ERROR("unsupport math_type");
    }

    std::string SeqArithmeticConfig::get_config() {
        std::string config_str = "seq_arithmetic: math_type: ";
        switch (math_type_) {
            case Mathematic::Add:
                config_str.append("+");
                break;
            case Mathematic::Sub:
                config_str.append("-");
                break;
            case Mathematic::Mul:
                config_str.append("*");
                break;
            default:
                break;
        }
        return config_str;
    }

    bool SeqArithmeticConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        if (inputs_.size() < 2)
            THROW_ERROR("input size < 2");

        const Value *input_value_0 = get_value(input_values, inputs_, 0);
        const Value *input_value_1 = get_value(input_values, inputs_, 1);

        const std::size_t batch_size = input_value_0->ifeatures.size();
        if (batch_size != input_value_1->ifeatures.size())
            THROW_ERROR("input0's features size != input1's features size");

        output.values.resize(1);
        Value &value = output.values[0];
        value.ifeatures.resize(batch_size);

        const tensorflow::Feature *input_feature_0 = nullptr;
        const tensorflow::Feature *input_feature_1 = nullptr;

        for (std::size_t i = 0; i < batch_size; ++i) {
            input_feature_0 = input_value_0->ifeatures[i].feature;
            input_feature_1 = input_value_1->ifeatures[i].feature;
            if (!input_feature_0 || !input_feature_1)
                THROW_ERROR("input feature is null");

            tensorflow::Feature *out_feature =
                    google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
            value.ifeatures[i].feature = out_feature;
            if (input_feature_0->kind_case() != input_feature_1->kind_case()) {
                THROW_ERROR("input0 kind case = " + std::to_string(input_feature_0->kind_case()) + "input1 kind case " +
                            std::to_string(input_feature_1->kind_case()) + "; not match!");
            }
            switch (input_feature_0->kind_case()) {
                case tensorflow::Feature::KindCase::kInt64List: {
                    if (input_feature_0->int64_list().value_size() != input_feature_1->int64_list().value_size())
                        THROW_ERROR("input0's values size != input1's values size");
                    for (int j = 0; j < input_feature_0->int64_list().value_size(); ++j) {
                        out_feature->mutable_int64_list()->add_value(
                                cacl(input_feature_0->int64_list().value(j), input_feature_1->int64_list().value(j)));
                    }
                    break;
                }
                case tensorflow::Feature::KindCase::kFloatList: {
                    if (input_feature_0->float_list().value_size() != input_feature_1->float_list().value_size())
                        THROW_ERROR("input0's values size != input1's values size");
                    for (int j = 0; j < input_feature_0->float_list().value_size(); ++j) {
                        out_feature->mutable_float_list()->add_value(
                                cacl(input_feature_0->float_list().value(j), input_feature_1->float_list().value(j)));
                    }
                    break;
                }
                case tensorflow::Feature::KindCase::kBytesList:
                case tensorflow::Feature::KindCase::KIND_NOT_SET:
                default:
                    break;
            }
        }

        return true;
    }

    bool SeqFilterConfig::compute(const std::vector<const Output *> &input_values, Output &output) {
        DEBUG_TIMER("SeqFilterConfig::compute");
        LogDebug("------------ compute {} start ------------", output_);

        const Value *appid_value = get_value(input_values, inputs_, 0);
        const Value *eventtime_value = get_value(input_values, inputs_, 1);
        const Value *out_value = get_value(input_values, inputs_, 2);
        int64_t now = get_feature_one_int64(input_values, inputs_, 3);

        if (unlikely(input_values.size() < 4 + filter_dicts_.size())) {
            THROW_ERROR("not enough input filter values! input_values size = [" + std::to_string(input_values.size()) +
                        "]; filters size = [" + std::to_string(filter_dicts_.size()) + "]");
        }
        //取过滤条件pb
        std::vector<const Value *> param_to_filtered;
        param_to_filtered.resize(filter_dicts_.size());
        for (uint32_t j = 0; j < param_to_filtered.size(); j++) {
            param_to_filtered[j] = get_value(input_values, inputs_, 4 + j);
        }

        const InputFeature *inf_appid = nullptr;
        const InputFeature *inf_eventtime = nullptr;
        const InputFeature *inf_value = nullptr;
        std::vector<const InputFeature *> param_to_check_of_this_batch;
        param_to_check_of_this_batch.resize(param_to_filtered.size());

        uint32_t batch_size = std::min(appid_value->ifeatures.size(), eventtime_value->ifeatures.size());

        output.values.resize(3);
        for (uint32_t i = 0; i < 3; i++) {
            Value &value = output.values[i];
            value.ifeatures.resize(batch_size);
        }
        output.values[0].defalut_type = tensorflow::DT_STRING;
        output.values[1].defalut_type = tensorflow::DT_INT64;
        output.values[2].defalut_type = tensorflow::DT_INT64;

        std::vector<tensorflow::Feature *> out_feat(3);
        std::vector<tensorflow::FeatureList *> out_featlist(3);

        for (uint32_t i = 0; i < batch_size; ++i) {
            inf_appid = &appid_value->ifeatures[i];
            inf_eventtime = &eventtime_value->ifeatures[i];
            if (out_value->ifeatures.size() > i) {
                inf_value = &out_value->ifeatures[i];
            } else {
                inf_value = &out_value->ifeatures[0];
            }
            std::vector<FilterDict> source_filter_dicts;
            std::vector<const FilterDict *> full_filter_dicts;
            for (const auto &filter_config: filter_dicts_) {
                if (filter_config.source_index >= 0) {
                    const Value *filter_param_value = get_value(input_values, inputs_, filter_config.source_index);
                    const tensorflow::Feature *filter_param_feature = nullptr;
                    if (filter_param_value->ifeatures.size() > i) {
                        filter_param_feature = filter_param_value->ifeatures[i].feature;
                    } else {
                        filter_param_feature = filter_param_value->ifeatures[0].feature;
                    }
                    if (unlikely(filter_param_feature == nullptr)) {
                        THROW_ERROR("input filter source feature is null! config = [" + output_ +
                                    "]; source index = [" + std::to_string(filter_config.source_index) + "]");
                    }
                    auto source_filter = FeatureToFilterDicts(filter_param_feature, filter_config.kind_case);
                    source_filter.source_index = filter_config.source_index;
                    source_filter_dicts.emplace_back(std::move(source_filter));
                    auto &source_filter_dict = source_filter_dicts[source_filter_dicts.size() - 1];
                    full_filter_dicts.emplace_back(&source_filter_dict);

                } else {
                    full_filter_dicts.emplace_back(&filter_config);
                }
            }
            int32_t appid_count = inf_appid->feature->int64_list().value_size();
            //当前batch待检查的参数
            for (uint32_t j = 0; j < param_to_filtered.size(); j++) {
                if (param_to_filtered[j]->ifeatures.size() > i) {
                    param_to_check_of_this_batch[j] = &param_to_filtered[j]->ifeatures[i];
                } else {
                    param_to_check_of_this_batch[j] = &param_to_filtered[j]->ifeatures[0];
                }
                int32_t filter_param_feature_size = FeatureSize(param_to_check_of_this_batch[j]->feature);
                if (unlikely(appid_count != filter_param_feature_size)) {
                    THROW_ERROR("appid count = [" + std::to_string(appid_count) + "]; filter param feature size = [" +
                                std::to_string(filter_param_feature_size) + "], not match! filter param index = [" +
                                std::to_string(4 + j) + "], batch index = [" + std::to_string(i) + "]");
                }
            }

            std::vector<AppIdWithEventTime> appid_info_vec;
            std::vector<AppIdWithEventTime *> appid_filter_vec_ptr;
            std::vector<AppIdWithEventTime *> appid_info_vec_ptr;
            std::vector<int64_t> appid_feat_value_index;
            std::unordered_map<AppIdWithEventTime *, int64_t> appid_values;
            for (uint32_t j = 0; j < 3; j++) {
                out_feat[j] = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(output.arena);
                output.values[j].ifeatures[i].feature = out_feat[j];
            }
            if (likely(inf_appid->feature && inf_eventtime->feature)) {

                filter_compute_.fill_appid_vec_with_index(*inf_appid->feature, *inf_eventtime->feature, now,
                                                          appid_info_vec, appid_feat_value_index);

                //过滤
                FilterFeature(appid_info_vec, param_to_check_of_this_batch, appid_feat_value_index, inf_value,
                              appid_values, appid_filter_vec_ptr, full_filter_dicts);

                //排序、截断
                top_n_compute_.compute_ptr_vec(appid_filter_vec_ptr, appid_info_vec_ptr);
            }
            for (const auto &elem: appid_info_vec_ptr) {
                out_feat[0]->mutable_int64_list()->add_value(elem->appid);
                out_feat[1]->mutable_int64_list()->add_value(elem->eventtime);
                auto itr = appid_values.find(elem);
                if (itr != appid_values.end()) {
                    out_feat[2]->mutable_int64_list()->add_value(itr->second);
                } else {
                    out_feat[2]->mutable_int64_list()->add_value(0);
                }
            }
        }

        return true;
    }
    void SeqFilterConfig::FilterFeature(std::vector<AppIdWithEventTime> &appid_info_vec,
                                        std::vector<const InputFeature *> &filter_conds_to_check,
                                        std::vector<int64_t> &appid_feat_value_index, const InputFeature *inf_value,
                                        std::unordered_map<AppIdWithEventTime *, int64_t> &appid_values,
                                        std::vector<AppIdWithEventTime *> &appid_filter_vec_ptr,
                                        const std::vector<const FilterDict *> &full_filter_dicts) {
        std::vector<uint32_t> allow_count(appid_feat_value_index.size(), 1);
        appid_filter_vec_ptr.reserve(appid_info_vec.size());
        //遍历过滤后的appid, appid_feat_value_index中的元素为满足过滤条件的appid的index
        for (size_t i = 0; i < appid_feat_value_index.size(); i++) {
            //找到AppIdWithEventTime在防穿越前在原始索引中的位置
            auto appid_index = appid_feat_value_index[i];
            for (size_t j = 0; j < filter_conds_to_check.size(); j++) {
                auto filter_cond_to_check = filter_conds_to_check[j]->feature;
                auto filter_dict = full_filter_dicts[j];
                //通过原始索引位置appid_index找到要被过滤的值
                if (!InFilterDict(filter_dict, filter_cond_to_check, static_cast<int32_t>(appid_index))) {
                    //i为防穿越后的appid_info_vec的索引
                    allow_count[i] = 0;
                    break;
                }
            }
        }
        for (size_t i = 0; i < appid_feat_value_index.size(); i++) {
            //找inf_value的值需要通过防穿越前的原始索引找到
            auto appid_index = appid_feat_value_index[i];
            //通过appid_feat_value_index将appid_info_vec[i]与inf_value对应的值绑定起来
            auto ptr = &(appid_info_vec[i]);
            if (inf_value->feature && inf_value->feature->int64_list().value_size() > appid_index) {
                appid_values[ptr] = inf_value->feature->int64_list().value(appid_index);
            }
        }
        //allow_count使用的是防穿越后的索引,直接把对应的地址填上即可
        for (size_t i = 0; i < allow_count.size(); i++) {
            auto allow = allow_count[i];
            if (allow > 0) {
                appid_filter_vec_ptr.emplace_back(&appid_info_vec[i]);
            }
        }
    }

    bool SeqFilterConfig::InFilterDict(const FilterDict *filter_dict, const tensorflow::Feature *feature_to_check,
                                       int32_t value_index) {
        switch (filter_dict->kind_case) {
            case (tensorflow::Feature::kInt64List): {
                if (feature_to_check->int64_list().value_size() < value_index) {
                    return false;
                }
                auto value = feature_to_check->int64_list().value(value_index);
                return filter_dict->int64_filter.find(value) != filter_dict->int64_filter.end();
                break;
            }
            case (tensorflow::Feature::kBytesList): {
                if (feature_to_check->bytes_list().value_size() < value_index) {
                    return false;
                }
                auto &value = feature_to_check->bytes_list().value(value_index);
                return filter_dict->str_filter.find(value) != filter_dict->str_filter.end();
                break;
            }
            case (tensorflow::Feature::kFloatList): {
                if (feature_to_check->float_list().value_size() < value_index) {
                    return false;
                }
                auto value = feature_to_check->float_list().value(value_index);
                return filter_dict->float_filter.find(value) != filter_dict->float_filter.end();
                break;
            }
            default:
                break;
        }
        return false;
    }

    SeqFilterConfig::FilterDict SeqFilterConfig::FeatureToFilterDicts(const tensorflow::Feature *fea,
                                                                      tensorflow::Feature::KindCase kind_case) {
        FilterDict filter_dict;
        switch (kind_case) {
            case (tensorflow::Feature::kInt64List): {
                filter_dict.kind_case = kind_case;
                for (const auto val: fea->int64_list().value()) {
                    filter_dict.int64_filter.insert(val);
                }
                break;
            }
            case (tensorflow::Feature::kFloatList): {
                filter_dict.kind_case = kind_case;
                for (const auto val: fea->float_list().value()) {
                    filter_dict.float_filter.insert(val);
                }
                break;
            }
            case (tensorflow::Feature::kBytesList): {
                filter_dict.kind_case = kind_case;
                for (const auto &val: fea->bytes_list().value()) {
                    filter_dict.str_filter.insert(val);
                }
                break;
            }
            default:
                break;
        }
        return filter_dict;
    }

}// namespace phx_fe