#include "phx_test.h"

TEST_SUITE("time")
{
    TEST_CASE("time_hour") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="time_hour"
                    source=".fe_request.item_fea.item_info.appid"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727580548000l); // 2024-09-29 11:29:08

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727490578000l); // 2024-09-28 10:29:38

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727361539000l); // 2024-09-26 22:38:59

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1721577341000l); // 2024-07-21 23:55:41

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        REQUIRE_EQ(1, ret.training_samples(0).features(0).signs_size());
        CHECK_EQ(11, ret.training_samples(0).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        REQUIRE_EQ(1, ret.training_samples(1).features(0).signs_size());
        CHECK_EQ(10, ret.training_samples(1).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        REQUIRE_EQ(1, ret.training_samples(2).features(0).signs_size());
        CHECK_EQ(22, ret.training_samples(2).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        REQUIRE_EQ(1, ret.training_samples(3).features(0).signs_size());
        CHECK_EQ(23, ret.training_samples(3).features(0).signs(0));
    }

    TEST_CASE("time_hour_scope") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="time_hour_scope"
                    source=".fe_request.item_fea.item_info.appid"
                    hour_boundary="5,8,11,13,16,19"
                    name_boundary="凌晨,早晨,上午,中午,下午,傍晚,夜晚"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1750883400000l); // 2025-06-26 04:30:00

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1750894200000l); // 2025-06-26 07:30:00

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1750903200000l); // 2025-06-26 10:00:00

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1750910400000l); // 2025-06-26 12:00:00

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1750921200000l); // 2025-06-26 15:00:00

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1750933800000l); // 2025-06-26 18:30:00

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1750939200000l); // 2025-06-26 20:00:00

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(7, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        REQUIRE_EQ(1, ret.training_samples(0).features(0).bytes_list_size());
        CHECK_EQ("凌晨", ret.training_samples(0).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        REQUIRE_EQ(1, ret.training_samples(1).features(0).bytes_list_size());
        CHECK_EQ("早晨", ret.training_samples(1).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        REQUIRE_EQ(1, ret.training_samples(2).features(0).bytes_list_size());
        CHECK_EQ("上午", ret.training_samples(2).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        REQUIRE_EQ(1, ret.training_samples(3).features(0).bytes_list_size());
        CHECK_EQ("中午", ret.training_samples(3).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(4).features_size());
        REQUIRE_EQ(1, ret.training_samples(4).features(0).bytes_list_size());
        CHECK_EQ("下午", ret.training_samples(4).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(5).features_size());
        REQUIRE_EQ(1, ret.training_samples(5).features(0).bytes_list_size());
        CHECK_EQ("傍晚", ret.training_samples(5).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(6).features_size());
        REQUIRE_EQ(1, ret.training_samples(6).features(0).bytes_list_size());
        CHECK_EQ("夜晚", ret.training_samples(6).features(0).bytes_list(0));
    }

    TEST_CASE("time_day") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="time_day"
                    source=".fe_request.item_fea.item_info.appid"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727580548000l); // 2024-09-29 11:29:08

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727490578000l); // 2024-09-28 10:29:38

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727361539000l); // 2024-09-26 22:38:59

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1721577341000l); // 2024-07-21 23:55:41

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        REQUIRE_EQ(1, ret.training_samples(0).features(0).signs_size());
        CHECK_EQ(29, ret.training_samples(0).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        REQUIRE_EQ(1, ret.training_samples(1).features(0).signs_size());
        CHECK_EQ(28, ret.training_samples(1).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        REQUIRE_EQ(1, ret.training_samples(2).features(0).signs_size());
        CHECK_EQ(26, ret.training_samples(2).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        REQUIRE_EQ(1, ret.training_samples(3).features(0).signs_size());
        CHECK_EQ(21, ret.training_samples(3).features(0).signs(0));
    }

    TEST_CASE("time_day_scope") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="time_day_scope"
                    source=".fe_request.item_fea.item_info.appid"
                    day_boundary="11,21"
                    name_boundary="上旬,中旬,下旬"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1725633539000l); // 2024-09-06 22:38:59

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1726497539000l); // 2024-09-16 22:38:59

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1730385539000l); // 2024-10-31 22:38:59

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(3, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        REQUIRE_EQ(1, ret.training_samples(0).features(0).bytes_list_size());
        CHECK_EQ("上旬", ret.training_samples(0).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        REQUIRE_EQ(1, ret.training_samples(1).features(0).bytes_list_size());
        CHECK_EQ("中旬", ret.training_samples(1).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        REQUIRE_EQ(1, ret.training_samples(2).features(0).bytes_list_size());
        CHECK_EQ("下旬", ret.training_samples(2).features(0).bytes_list(0));
    }

    TEST_CASE("time_week") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="time_week"
                    source=".fe_request.item_fea.item_info.appid"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727580548000l); // 2024-09-29 11:29:08 Sunday

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727490578000l); // 2024-09-28 10:29:38 Saturday

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727361539000l); // 2024-09-26 22:38:59 Thursday

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727279741000l); // 2024-09-25 23:55:41 Wednesday

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        REQUIRE_EQ(1, ret.training_samples(0).features(0).signs_size());
        CHECK_EQ(7, ret.training_samples(0).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        REQUIRE_EQ(1, ret.training_samples(1).features(0).signs_size());
        CHECK_EQ(6, ret.training_samples(1).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        REQUIRE_EQ(1, ret.training_samples(2).features(0).signs_size());
        CHECK_EQ(4, ret.training_samples(2).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        REQUIRE_EQ(1, ret.training_samples(3).features(0).signs_size());
        CHECK_EQ(3, ret.training_samples(3).features(0).signs(0));
    }

    TEST_CASE("time_week_scope") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="time_week_scope"
                    source=".fe_request.item_fea.item_info.appid"
                    week_boundary="6"
                    name_boundary="工作日,周末"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727580548000l); // 2024-09-29 11:29:08 Sunday

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727490578000l); // 2024-09-28 10:29:38 Saturday

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727361539000l); // 2024-09-26 22:38:59 Thursday

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727279741000l); // 2024-09-25 23:55:41 Wednesday

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        REQUIRE_EQ(1, ret.training_samples(0).features(0).bytes_list_size());
        CHECK_EQ("周末", ret.training_samples(0).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        REQUIRE_EQ(1, ret.training_samples(1).features(0).bytes_list_size());
        CHECK_EQ("周末", ret.training_samples(1).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        REQUIRE_EQ(1, ret.training_samples(2).features(0).bytes_list_size());
        CHECK_EQ("工作日", ret.training_samples(2).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        REQUIRE_EQ(1, ret.training_samples(3).features(0).bytes_list_size());
        CHECK_EQ("工作日", ret.training_samples(3).features(0).bytes_list(0));
    }

    TEST_CASE("time_month") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="time_month"
                    source=".fe_request.item_fea.item_info.appid"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1708876541000l); // 2024-02-25 23:55:41

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1716863378000l); // 2024-05-28 10:29:38

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1727361539000l); // 2024-09-26 22:38:59

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1721577341000l); // 2024-07-21 23:55:41

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        REQUIRE_EQ(1, ret.training_samples(0).features(0).signs_size());
        CHECK_EQ(2, ret.training_samples(0).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        REQUIRE_EQ(1, ret.training_samples(1).features(0).signs_size());
        CHECK_EQ(5, ret.training_samples(1).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        REQUIRE_EQ(1, ret.training_samples(2).features(0).signs_size());
        CHECK_EQ(9, ret.training_samples(2).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        REQUIRE_EQ(1, ret.training_samples(3).features(0).signs_size());
        CHECK_EQ(7, ret.training_samples(3).features(0).signs(0));
    }

    TEST_CASE("time_month_scope") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="time_month_scope"
                    source=".fe_request.item_fea.item_info.appid"
                    month_boundary="4,7,10"
                    name_boundary="第一季度,第二季度,第三季度,第四季度"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1708876541000l); // 2024-02-25 23:55:41

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1716863378000l); // 2024-05-28 10:29:38

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1732631939000l); // 2024-11-26 22:38:59

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1721577341000l); // 2024-07-21 23:55:41

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        REQUIRE_EQ(1, ret.training_samples(0).features(0).bytes_list_size());
        CHECK_EQ("第一季度", ret.training_samples(0).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        REQUIRE_EQ(1, ret.training_samples(1).features(0).bytes_list_size());
        CHECK_EQ("第二季度", ret.training_samples(1).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        REQUIRE_EQ(1, ret.training_samples(2).features(0).bytes_list_size());
        CHECK_EQ("第四季度", ret.training_samples(2).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        REQUIRE_EQ(1, ret.training_samples(3).features(0).bytes_list_size());
        CHECK_EQ("第三季度", ret.training_samples(3).features(0).bytes_list(0));
    }

    TEST_CASE("time_holiday_scope") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="time_holiday_scope"
                    source=".fe_request.item_fea.item_info.appid"
                    holiday_boundary="2024:1,1,1,1,2,10,2,17,4,4,4,6,5,1,5,5,6,8,6,10,9,15,9,17,10,1,10,7;2025:1,1,1,1,1,28,2,4,4,4,4,6,5,1,5,5,5,31,6,2,10,6,10,8,10,1,10,7"
                    name_boundary="元旦节,春节,清明节,劳动节,端午节,中秋节,国庆节"
                    default_value="非假期"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1707494400000l); // 2024-02-10 00:00:00 春节

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1717948800000l); // 2024-06-10 00:00:00 端午节

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1746028800000l); // 2025-05-01 00:00:00 劳动节

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1759248000000l); // 2025-10-01 00:00:00 国庆节

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1750867200000l); // 2025-06-26 00:00:00 非假期

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(5, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        REQUIRE_EQ(1, ret.training_samples(0).features(0).bytes_list_size());
        CHECK_EQ("春节", ret.training_samples(0).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        REQUIRE_EQ(1, ret.training_samples(1).features(0).bytes_list_size());
        CHECK_EQ("端午节", ret.training_samples(1).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        REQUIRE_EQ(1, ret.training_samples(2).features(0).bytes_list_size());
        CHECK_EQ("劳动节", ret.training_samples(2).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        REQUIRE_EQ(1, ret.training_samples(3).features(0).bytes_list_size());
        CHECK_EQ("国庆节", ret.training_samples(3).features(0).bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(4).features_size());
        REQUIRE_EQ(1, ret.training_samples(4).features(0).bytes_list_size());
        CHECK_EQ("非假期", ret.training_samples(4).features(0).bytes_list(0));
    }
}
