SOURCE="../../bazel-bin/test/utf"
BUILD_OPTIONS="--copt=-O2"
SECONDS=0


bazel build //test:utf ${BUILD_OPTIONS}

# 检查命令的执行结果
if [ $? -eq 0 ]; then
    echo "release编译成功"
    # 替换 可执行文件 到此文件夹
    ./clean.sh
    cp "$SOURCE" "."
    echo "文件 $SOURCE 已复制到 当前文件夹。"
    elapsed_time=$SECONDS
    echo "release编译执行耗时: $elapsed_time 秒"
    ./utf --log_level=info --input_path="json_files/test_seq_val_direct_v2/"
else
    echo "release编译失败 不执行替换 utf"
    elapsed_time=$SECONDS
    echo "release编译执行耗时: $elapsed_time 秒"
fi


# 执行使用 ./utf
# 后可加参数：
#   --log_level=xxx 控制输出级别（ debug info warn err ）
#   --input_path=xxx 控制json文件或文件夹的路径
