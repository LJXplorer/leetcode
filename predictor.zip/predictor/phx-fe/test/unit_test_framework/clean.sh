rm -f utf 
rm -f core.*