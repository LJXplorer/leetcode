#pragma once

#include "phx-fe/config_mgr/xml_config_mgr.h"
#include "phx-fe/src/framework.h"
#include "phx-fe/src/service.h"
#include "phx-fe/test/unit_test_framework/utils/equal_utils.h"
#include "phx-fe/test/unit_test_framework/utils/file_utils.h"
#include "phx-fe/test/unit_test_framework/utils/json_utils.h"
#include "phx-fe/test/unit_test_framework/utils/log_utils.h"
#include "phx-fe/test/unit_test_framework/utils/proto_utils.h"
#include "phx-fe/test/unit_test_framework/utils/exception_utils.h"

#include <json.hpp>
#include <tinyxml2.h>

namespace console_color {
    constexpr auto reset = "\033[0m";
    constexpr auto success = "\033[32m";
    constexpr auto fail = "\033[31m";
    constexpr auto info = "\033[36m";
}
bool ReadJsonFile(const std::string &json_file_path, nlohmann::json &json_data) {
    std::ifstream json_file(json_file_path);
    if (!json_file.is_open()) {
        Error("无法打开文件: ", json_file_path);
        return false;
    }
    try {
        json_file >> json_data;
        Debug("读取的 JSON 内容: ", json_data.dump(4));
    } catch (const nlohmann::json::parse_error &e) {
        Error("JSON 解析错误: ", e.what());
        return false;
    }
    return true;
}

bool InitDictConfig(const nlohmann::json &json_data, long &dicts_handle) {
    dicts_handle = 0L;
    if (!json_data.contains("dict_config")) {
        Warning("未配置字段: dict_config");
        return true;// 非致命错误
    }
    std::string dict_config_str = json_data["dict_config"];
    tinyxml2::XMLDocument dict_config_xml;
    tinyxml2::XMLError err = dict_config_xml.Parse(dict_config_str.c_str());
    if (err != tinyxml2::XML_SUCCESS) {
        Error("dict_config XML 解析失败: ", dict_config_xml.ErrorStr());
        return false;
    }
    std::string dict_version_name;
    if (json_data.contains("dict_version_name")) {
        dict_version_name = json_data["dict_version_name"];
    }
    auto ret = XmlConfigMgr::get_dict_configs(dict_config_xml, dict_version_name);
    Debug("XmlConfigMgr::get_dict_configs ret size = ", ret.size());
    for (const auto &conf: ret) {
        Debug("name = [", conf.name, "]; partition = [", conf.partition, "]; value proto = [", conf.value_proto,
             "], class name = [", conf.class_name, "];path = [", conf.path, "]");
    }
    nlohmann::json json_array = nlohmann::json::array();
    for (const auto &conf: ret) {
        nlohmann::json object;
        object["name"] = conf.name;
        object["path"] = conf.path;
        object["value_proto"] = conf.value_proto;
        object["class_name"] = conf.class_name;
        json_array.emplace_back(object);
    }
    dicts_handle = init_offline_dicts(json_array.dump());
    if (dicts_handle == 0) {
        Error("init handle failed! handle = 0");
        return false;
    }
    return true;
}
bool ParseInputValues(const nlohmann::json &json_data, google::protobuf::Arena &arena,
                      std::vector<Output> &input_values) {
    Debug("ParseInputValues start");
    if (!json_data.contains("input_values")) {
        Error("json文件缺少字段: input_values");
        return false;
    }
    if (!json_data["input_values"].is_array()) {
        Error("json文件中，input_values 不是一个 JSON 数组");
        return false;
    }
    auto input_value_json_list = split_json_list(json_data["input_values"]);
    Debug("拆分得到 ", input_value_json_list.size(), " 个 input_values 元素");
    input_values.reserve(input_value_json_list.size());
    for (const auto &input_value_json: input_value_json_list) {
        input_values.push_back(create_output_from_json(input_value_json, &arena));
    }
    Debug("ParseInputValues success");
    return true;
}

bool ParseExpectedOutput(const nlohmann::json &json_data, google::protobuf::Arena &arena, Output &expected_output) {
    if (!json_data.contains("expected_output")) {
        Error("json文件中，缺少字段: expected_output");
        return false;
    }
    if (!json_data["expected_output"].is_object()) {
        Error("json文件中，expected_output 不是一个 JSON 对象");
        return false;
    }
    expected_output = create_output_from_json(json_data["expected_output"], &arena);
    return true;
}

tinyxml2::XMLElement *ParseFeatureConfigFromXml(const std::string &config_str, tinyxml2::XMLDocument &doc) {
    Debug("ParseFeatureConfigFromXml start");
    tinyxml2::XMLError err = doc.Parse(config_str.c_str());
    if (err != tinyxml2::XML_SUCCESS) {
        Error("XML 解析失败: ", doc.ErrorStr());
        return nullptr;
    }
    tinyxml2::XMLElement *feature = doc.RootElement();
    if (!feature) {
        Error("未找到 XML 根节点");
        return nullptr;
    }
    Debug("ParseFeatureConfigFromXml success");
    return feature;
}

Config *CreateConfigFromJson(const std::string &config_str, AllDicts &dicts) {
    Debug("CreateConfigFromJson start");
    tinyxml2::XMLDocument doc;
    auto *feature = ParseFeatureConfigFromXml(config_str, doc);
    const char *name = feature->Attribute("name");
    const char *type = feature->Attribute("type");
    const char *source_str = feature->Attribute("source");
    Debug("Feature name: ", (name ? name : "null"), ", type: ", (type ? type : "null"),
         ", source: ", (source_str ? source_str : "null"));
    std::string output_str;

    std::vector<std::string> source = Calc::split_string(source_str, ",");
    DefaultValue dv;
    std::vector<std::string> strategy;
    std::string dict_path;
    Config * ret = XmlConfigMgr::create_config(type, feature, name, source, dv, strategy, dicts, dict_path);
    Debug("CreateConfigFromJson end,ret: ",ret);
    return ret;
}

Config *CreateConfigFromXMLElement(tinyxml2::XMLElement *feature, AllDicts &dicts) {
    const char *name = feature->Attribute("name");
    const char *type = feature->Attribute("type");
    const char *source_str = feature->Attribute("source");
    Debug("Feature name: ", (name ? name : "null"), ", type: ", (type ? type : "null"),
          ", source: ", (source_str ? source_str : "null"));
    std::string output_str;
    std::vector<std::string> source = Calc::split_string(source_str, ",");
    DefaultValue dv;
    std::vector<std::string> strategy;
    std::string dict_path;
    return XmlConfigMgr::create_config(type, feature, name, source, dv, strategy, dicts, dict_path);
}

void BuildInputPtrs(std::vector<Output> &input_values, std::vector<const Output *> &input_ptrs) {
    Debug("BuildInputPtrs start");
    input_ptrs.reserve(input_values.size());
    for (auto &val: input_values) {
        input_ptrs.push_back(&val);
    }
    Debug("BuildInputPtrs end, input_ptrs size: ",input_ptrs.size());
}

bool ComputeAndCompare(Config *config_ptr, std::vector<const Output *> &input_ptrs, Output &expected_output) {
    Output compute_output;
    Debug("compute start");
    bool compute_ret = config_ptr->compute(input_ptrs, compute_output);
    if (!compute_ret) {
        Warning("算子计算失败");
        return false;
    }
    Debug("算子输出：", compute_output.to_string());
    auto compare_ret = ut_compare(compute_output, expected_output);
    if (!compare_ret.equal) {
        Warning("算子输出与预期输出不同：", compare_ret.diff_message);
    }
    return compare_ret.equal;
}


struct TestStats {
    int testCasesPassed = 0;
    int testCasesFailed = 0;

    void add_test_case_result(bool passed, bool skipped = false) {
        if (passed) {
            testCasesPassed++;
        } else {
            testCasesFailed++;
        }
    }

    bool overall_success() const {
        return testCasesFailed == 0;
    }
};
void print_test_summary(const TestStats& stats) {
    using namespace console_color;
    PrintBanner(&Info,"test summary");
    // 打印测试用例摘要
    std::cout << info << "\n[FE UT Framework]" << reset << " test cases:  ";
    std::cout << std::setw(3) << (stats.testCasesPassed + stats.testCasesFailed) << " | ";
    std::cout << std::setw(3) << success << stats.testCasesPassed << " passed | " << reset;
    std::cout << std::setw(3) << fail << stats.testCasesFailed << " failed\n" << reset;

    // 打印总体状态
    std::cout << info << "[FE UT Framework]" << reset << " Status: ";
    if (stats.overall_success()) {
        std::cout << success << "SUCCESS!\n" << reset;
    } else {
        std::cout << fail << "FAILURE!\n" << reset;
    }
}