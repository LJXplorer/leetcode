#pragma once
#include <spdlog/spdlog.h>
#include <sstream>
#include <string>

extern std::shared_ptr<spdlog::logger> g_logger;

void set_log_level(const std::string &level_str);

void DebugImpl(const std::string &msg);
void InfoImpl(const std::string &msg);
void WarningImpl(const std::string &msg);
void ErrorImpl(const std::string &msg);

void SuccessImpl(const std::string &msg);

void FailImpl(const std::string &msg);

inline void stream_out(std::ostringstream & /*oss*/) {
}

template<typename T, typename... Args>
void stream_out(std::ostringstream &oss, T &&first, Args &&...rest) {
    oss << std::forward<T>(first);
    stream_out(oss, std::forward<Args>(rest)...);
}

// 流式版本日志函数模板
template<typename... Args>
void Debug(Args &&...args) {
    std::ostringstream oss;
    stream_out(oss, std::forward<Args>(args)...);
    DebugImpl(static_cast<const std::string &>(oss.str()));
}

template<typename... Args>
void Info(Args &&...args) {
    std::ostringstream oss;
    stream_out(oss, std::forward<Args>(args)...);
    InfoImpl(static_cast<const std::string &>(oss.str()));
}

template<typename... Args>
void Warning(Args &&...args) {
    std::ostringstream oss;
    stream_out(oss, std::forward<Args>(args)...);
    WarningImpl(static_cast<const std::string &>(oss.str()));
}

template<typename... Args>
void Error(Args &&...args) {
    std::ostringstream oss;
    stream_out(oss, std::forward<Args>(args)...);
    ErrorImpl(static_cast<const std::string &>(oss.str()));
}

template<typename... Args>
void Success(Args &&...args) {
    std::ostringstream oss;
    stream_out(oss, std::forward<Args>(args)...);
    SuccessImpl(static_cast<const std::string &>(oss.str()));
}

template<typename... Args>
void Fail(Args &&...args) {
    std::ostringstream oss;
    stream_out(oss, std::forward<Args>(args)...);
    FailImpl(static_cast<const std::string &>(oss.str()));
}

template<typename... Args>
void PrintBanner(void (*logFunc)(const std::string &), Args &&...args) {
    constexpr int totalLength = 120;// 可以根据需要调整
    constexpr char borderChar = '=';

    std::ostringstream oss;
    stream_out(oss, std::forward<Args>(args)...);
    std::string message = oss.str();

    // 计算可用宽度（减去两端各一个空格）
    const int availableWidth = totalLength - 2;

    // 处理过长的消息
    if (message.length() > static_cast<size_t>(availableWidth)) {
        message = message.substr(0, availableWidth - 3) + "...";
    }

    // 计算填充
    const int remainingSpace = availableWidth - message.length();
    const int leftPad = remainingSpace / 2;
    const int rightPad = remainingSpace - leftPad;

    // 构造边界线
    const std::string boundary(totalLength, borderChar);

    // 使用现有日志系统输出
    logFunc(" " + std::string(leftPad, borderChar) + message + std::string(rightPad, borderChar) + " ");
}