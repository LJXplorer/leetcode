#pragma once

#include "phx-fe/util/util.h"
#include <string>

struct UTCompareResult {
    bool equal = false;      // 是否相等
    std::string diff_message;// 差异描述，equal为false时有效
    UTCompareResult(bool e, const std::string &msg) : equal(e), diff_message(msg) {
    }
};

UTCompareResult ut_compare(const Output &lhs, const Output &rhs) noexcept;

UTCompareResult ut_compare(const Value &lhs, const Value &rhs) noexcept;

UTCompareResult ut_compare(const InputFeature &lhs, const InputFeature &rhs) noexcept;