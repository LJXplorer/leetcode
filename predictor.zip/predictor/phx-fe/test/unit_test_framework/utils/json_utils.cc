#include "json_utils.h"
#include "log_utils.h"
std::vector<nlohmann::json> split_json_list(const nlohmann::json &json_list) {
    std::vector<nlohmann::json> elements;
    if (!json_list.is_array()) {
        throw std::invalid_argument("输入参数 不是一个 JSON 数组");
    }

    for (const auto &item: json_list) {
        elements.push_back(item);
    }

    return elements;
}

bool simplified_json_to_feature(const nlohmann::json &j, tensorflow::Feature *feature,
                                tensorflow::DataType data_type) noexcept {
    if (!feature)
        return false;

    if (!j.is_array()) {
        std::cerr << "Feature不是一个列表：" << j.dump(4) << std::endl;
        return false;
    }

    if (j.empty()) {
        return true;
    }

    for (const auto &val: j) {
        switch (data_type) {
            case tensorflow::DT_INT64:
                if (!val.is_number_integer()) {
                    std::cerr << "元素类型不匹配：应为 int64" << std::endl;
                    return false;
                }
                feature->mutable_int64_list()->add_value(val.get<int64_t>());
                break;

            case tensorflow::DT_FLOAT:
                if (!val.is_number_float() && !val.is_number_integer()) {
                    // 允许整数转换为float
                    std::cerr << "元素类型不匹配：应为 float" << std::endl;
                    return false;
                }
                feature->mutable_float_list()->add_value(val.get<float>());
                break;

            case tensorflow::DT_STRING:
                if (!val.is_string()) {
                    std::cerr << "元素类型不匹配：应为 string" << std::endl;
                    return false;
                }
                feature->mutable_bytes_list()->add_value(val.get<std::string>());
                break;

            default:
                std::cerr << "在 simplified_json_to_feature 中 不支持的数据类型" << std::endl;
                return false;
        }
    }

    return true;
}

bool simplified_json_to_feature_list(const nlohmann::json &j, tensorflow::FeatureList *feature_list,
                                     tensorflow::DataType data_type) noexcept {
    if (!feature_list)
        return false;

    if (!j.is_array()) {
        Error("FeatureList JSON 不是一个列表");
        return false;
    }

    for (const auto &feature_array: j) {
        tensorflow::Feature *feature = feature_list->add_feature();
        if (!simplified_json_to_feature(feature_array, feature, data_type)) {
            Error("解析 feature_list 中的 feature 失败：", feature_array.dump(4));
            return false;
        }
    }

    return true;
}

Output create_output_from_json(const nlohmann::json &json_obj, google::protobuf::Arena *arena) {
    Output output;
    output.arena = arena;

    if (json_obj.contains("values")) {
        auto values_list = split_json_list(json_obj["values"]);
        for (const auto &val_json: values_list) {
            output.values.push_back(create_value_from_json(val_json, arena));
        }
    } else {
        output.values.clear();
    }

    if (json_obj.contains("allow_empty_output")) {
        output.allow_empty_output = json_obj["allow_empty_output"].get<bool>();
    } else {
        output.allow_empty_output = false;
    }

    if (json_obj.contains("own_values")) {
        output.own_values = json_obj["own_values"].get<bool>();
    } else {
        output.own_values = true;
    }

    return output;
}

Value create_value_from_json(const nlohmann::json &json_obj, google::protobuf::Arena *arena) {
    Value value;

    if (json_obj.contains("ifeatures")) {
        auto ifeatures_list = split_json_list(json_obj["ifeatures"]);
        for (const auto &if_json: ifeatures_list) {
            value.ifeatures.push_back(create_input_feature_from_json(if_json, arena));
        }
    } else {
        Debug("json中未配置 ifeatures：", json_obj);
        value.ifeatures.clear();
    }

    if (json_obj.contains("default_type")) {
        value.defalut_type = static_cast<tensorflow::DataType>(json_obj["default_type"].get<int>());
    } else {
        Debug("json中未配置 default_type", json_obj);
        value.defalut_type = tensorflow::DT_INVALID;
    }

    return value;
}

InputFeature create_input_feature_from_json(const nlohmann::json &json_obj, google::protobuf::Arena *arena) {
    InputFeature input_feature;

    int count = 0;
    if (json_obj.contains("feature"))
        count++;
    if (json_obj.contains("feature_list"))
        count++;
    if (json_obj.contains("messages"))
        count++;
    if (count != 1) {
        throw std::runtime_error("InputFeature中只能配置 feature 或 feature_list 或 messages 中的一个: " +
                                 json_obj.dump(4));
    }

    std::string data_type_str;
    tensorflow::DataType data_type;

    if (json_obj.contains("data_type")) {
        data_type_str = json_obj["data_type"];
        if (data_type_str.empty()) {
            throw std::runtime_error("ifeatures中 data_type 为空" + json_obj.dump(4));
        } else {
            static const std::unordered_map<std::string, tensorflow::DataType> type_map = {
                    {"int", tensorflow::DT_INT64},
                    {"int64", tensorflow::DT_INT64},
                    {"float", tensorflow::DT_FLOAT},
                    {"string", tensorflow::DT_STRING},
                    {"bytes", tensorflow::DT_STRING}};
            auto it = type_map.find(data_type_str);
            if (it != type_map.end()) {
                data_type = it->second;
            } else {
                throw std::runtime_error("ifeatures中不支持的 data_type: " + data_type_str);
            }
        }
    } else {
        throw std::runtime_error("ifeatures中必须配置 data_type： " + json_obj.dump(4));
    }

    if (json_obj.contains("feature") && json_obj["feature"].is_array()) {
        auto *feature_tmp = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(arena);
        bool ret = simplified_json_to_feature(json_obj["feature"], feature_tmp, data_type);
        if (!ret) {
            throw std::runtime_error("feature JsonStringToMessage 解析失败：" + json_obj.dump(4));
        }
        input_feature.feature = feature_tmp;
        input_feature.feature_list = nullptr;
        input_feature.messages.clear();

    } else if (json_obj.contains("feature_list") && json_obj["feature_list"].is_array()) {
        auto *feature_list_tmp = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(arena);
        bool ret = simplified_json_to_feature_list(json_obj["feature_list"], feature_list_tmp, data_type);
        if (!ret) {
            throw std::runtime_error("feature_list JsonStringToMessage 解析失败: " + json_obj.dump(4));
        }
        input_feature.feature_list = feature_list_tmp;
        input_feature.feature = nullptr;
        input_feature.messages.clear();

    } else if (json_obj.contains("messages") && json_obj["messages"].is_array()) {
        for (const auto &msg_json: json_obj["messages"]) {
            // TODO:
            // auto msg = google::protobuf::Arena::CreateMessage<tensorflow::Example>(arena);
            // std::string msg_json_str = msg_json.dump();
            // auto status = google::protobuf::util::JsonStringToMessage(msg_json_str, msg);
            // if (!status.ok()) {
            //     throw std::runtime_error("messages JsonStringToMessage 解析失败: " + std::string(status.message()));
            // }
            // messages.push_back(msg);
        }
        input_feature.feature = nullptr;
        input_feature.feature_list = nullptr;

    } else {
        throw std::runtime_error("InputFeature中必须有格式正确的 feature 或 feature_list 或 messages: " +
                                 json_obj.dump(4));
    }

    return input_feature;
}
