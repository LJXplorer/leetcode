#pragma once

#include "fe_request.pb.h"
#include "user_action.pb.h"
#include "phx-fe/util/util.h"

std::vector<nlohmann::json> split_json_list(const nlohmann::json &json_list);
bool simplified_json_to_feature(const nlohmann::json &j, tensorflow::Feature *feature,
                                tensorflow::DataType data_type) noexcept;
bool simplified_json_to_feature_list(const nlohmann::json &j, tensorflow::FeatureList *feature_list,
                                     tensorflow::DataType data_type) noexcept;
Output create_output_from_json(const nlohmann::json &json_obj, google::protobuf::Arena *arena);
Value create_value_from_json(const nlohmann::json &json_obj, google::protobuf::Arena *arena);
InputFeature create_input_feature_from_json(const nlohmann::json &json_obj, google::protobuf::Arena *arena);


template <typename ProtoMessage>
ProtoMessage* create_proto_from_json(const nlohmann::json &json_obj, google::protobuf::Arena *arena) {
    auto msg = google::protobuf::Arena::CreateMessage<ProtoMessage>(arena);
    std::string msg_json_str = json_obj.dump();
    auto status = google::protobuf::util::JsonStringToMessage(msg_json_str, msg);
    if (!status.ok()) {
        throw std::runtime_error(std::string("JsonStringToMessage 解析失败: ") + std::string(status.message()));
    }
    return msg;
}