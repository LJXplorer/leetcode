#pragma once
#include <string>
#include <vector>

bool is_directory(const std::string &path);
bool is_regular_file(const std::string &path);
bool has_json_extension(const std::string &filename);

void list_json_files_in_directory(const std::string &directory, std::vector<std::string> &json_files);
void list_json_files(const std::string &path, std::vector<std::string> &json_files);
