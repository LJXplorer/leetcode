#include "equal_utils.h"

UTCompareResult ut_compare(const Output &lhs, const Output &rhs) noexcept {
    if (lhs.own_values != rhs.own_values) {
        return {false, "own_values 不同，算子输出：" + std::to_string(lhs.own_values) + ", 预期：" +
                               std::to_string(rhs.own_values)};
    }

    if (lhs.values.size() != rhs.values.size()) {
        return {false, "values size 不同，算子输出：" + std::to_string(lhs.values.size()) + ", 预期：" +
                               std::to_string(rhs.values.size())};
    }

    for (size_t i = 0; i < lhs.values.size(); ++i) {
        auto res = ut_compare(lhs.values[i], rhs.values[i]);
        if (!res.equal) {
            return {false, "values[" + std::to_string(i) + "] 不同: " + res.diff_message};
        }
    }

    return {true, ""};
}

UTCompareResult ut_compare(const Value &lhs, const Value &rhs) noexcept {
    // 如果需要比较 default_type，可以取消注释
    // if (lhs.defalut_type != rhs.defalut_type) {
    //     return {false, "default_type 不同，算子输出：" + std::to_string(lhs.defalut_type) + ", 预期：" + std::to_string(rhs.defalut_type)};
    // }

    if (lhs.ifeatures.size() != rhs.ifeatures.size()) {
        return {false, "ifeatures size 不同，算子输出：" + std::to_string(lhs.ifeatures.size()) + ", 预期：" +
                               std::to_string(rhs.ifeatures.size())};
    }

    for (size_t i = 0; i < lhs.ifeatures.size(); ++i) {
        auto res = ut_compare(lhs.ifeatures[i], rhs.ifeatures[i]);
        if (!res.equal) {
            return {false, "ifeatures[" + std::to_string(i) + "] 不同：" + res.diff_message};
        }
    }

    return {true, ""};
}

UTCompareResult ut_compare(const InputFeature &lhs, const InputFeature &rhs) noexcept {
    // 比较 feature 指针
    if (lhs.feature == nullptr && rhs.feature != nullptr) {
        return {false, "算子输出feature指针为空，预期的非空"};
    }
    if (lhs.feature != nullptr && rhs.feature == nullptr) {
        return {false, "算子输出feature指针非空，预期的为空"};
    }
    if (lhs.feature != nullptr && rhs.feature != nullptr) {
        if (!google::protobuf::util::MessageDifferencer::Equals(*lhs.feature, *rhs.feature)) {
            return {false, "算子输出和预期的feature内容不同：\n算子输出feature: " + lhs.feature->DebugString() +
                                   "\n预期feature: " + rhs.feature->DebugString()};
        }
    }

    // 比较 feature_list 指针
    if (lhs.feature_list == nullptr && rhs.feature_list != nullptr) {
        return {false, "算子输出feature_list指针为空，预期的非空"};
    }
    if (lhs.feature_list != nullptr && rhs.feature_list == nullptr) {
        return {false, "算子输出feature_list指针非空，预期的为空"};
    }
    if (lhs.feature_list != nullptr && rhs.feature_list != nullptr) {
        if (!google::protobuf::util::MessageDifferencer::Equals(*lhs.feature_list, *rhs.feature_list)) {
            return {false,
                    "算子输出和预期的feature_list内容不同: \n算子输出feature_list: " + lhs.feature_list->DebugString() +
                            "\n预期feature_list: " + rhs.feature_list->DebugString()};
        }
    }

    // 比较 messages
    if (lhs.messages.size() != rhs.messages.size()) {
        return {false, "messages size 不同"};
    }
    for (size_t i = 0; i < lhs.messages.size(); ++i) {
        const auto *msg1 = lhs.messages[i];
        const auto *msg2 = rhs.messages[i];

        if (msg1 == nullptr && msg2 != nullptr) {
            return {false, "算子输出messages[" + std::to_string(i) + "]为空，预期的非空"};
        }
        if (msg1 != nullptr && msg2 == nullptr) {
            return {false, "算子输出messages[" + std::to_string(i) + "]非空，预期的为空"};
        }
        if (msg1 != nullptr && msg2 != nullptr) {
            if (!google::protobuf::util::MessageDifferencer::Equals(*msg1, *msg2)) {
                return {false, "算子输出和预期的messages[" + std::to_string(i) +
                                       "]不同: \n算子输出:" + msg1->DebugString() + "\n预期:" + msg2->DebugString()};
            }
        }
    }

    return {true, ""};
}