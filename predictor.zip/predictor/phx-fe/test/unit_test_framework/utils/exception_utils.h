#pragma once

#include <backtrace.h>
#include <exception>
#include <sstream>
#include <string>
inline void print_backtrace() {
    struct backtrace_state *state = backtrace_create_state(NULL,// filename (NULL for current executable)
                                                           0,   // threaded (0 = no)
                                                           NULL,// error callback
                                                           NULL // data for error callback
    );
    backtrace_print(state, 0, stdout);// 打印堆栈
}

class TracedException : public std::exception {
    std::string message_;
    std::string stack_trace_;

    // 获取当前调用栈的字符串表示
    static std::string GetStackTrace() {
        auto error_cb = [](void *, const char *msg, int errnum) {
            fprintf(stderr, "Backtrace error: %s (errno=%d)\n", msg, errnum);
        };

        auto print_cb = [](void *data, uintptr_t pc, const char *filename, int lineno, const char *function) -> int {
            auto *stream = static_cast<std::ostringstream *>(data);
            if (filename && function) {
                *stream << "  " << filename << ":" << lineno << " (" << function << ")\n";
            } else {
                *stream << "  [0x" << std::hex << pc << "]\n";
            }
            return 0;// 返回0继续回溯
        };

        struct backtrace_state *state = backtrace_create_state(nullptr, 0, error_cb, nullptr);

        std::ostringstream stream;
        backtrace_full(state, 0, print_cb, error_cb, &stream);
        return stream.str();
    }

public:
    explicit TracedException(const std::string &message) : message_(message), stack_trace_(GetStackTrace()) {
    }// 构造时立即抓取堆栈

    const char *what() const noexcept override {
        static std::string full_message;
        full_message = message_ + "\nStack Trace:\n" + stack_trace_;
        return full_message.c_str();
    }
};