#include "file_utils.h"
#include "log_utils.h"
#include <dirent.h>
#include <iostream>
#include <sys/stat.h>

bool is_directory(const std::string &path) {
    struct stat statbuf;
    if (stat(path.c_str(), &statbuf) != 0)
        return false;
    return S_ISDIR(statbuf.st_mode);
}

bool is_regular_file(const std::string &path) {
    struct stat statbuf;
    if (stat(path.c_str(), &statbuf) != 0)
        return false;
    return S_ISREG(statbuf.st_mode);
}

bool has_json_extension(const std::string &filename) {
    const std::string ext = ".json";
    if (filename.length() >= ext.length()) {
        return (0 == filename.compare(filename.length() - ext.length(), ext.length(), ext));
    }
    return false;
}

void list_json_files_in_directory(const std::string &directory, std::vector<std::string> &json_files) {
    DIR *dir = opendir(directory.c_str());
    if (!dir) {
        Error("Failed to open directory: ", directory);
        return;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name = entry->d_name;

        if (name == "." || name == "..")
            continue;

        std::string full_path = directory + "/" + name;

        if (is_directory(full_path)) {
            list_json_files_in_directory(full_path, json_files);
        } else {
            if (has_json_extension(name)) {
                json_files.push_back(full_path);
            }
        }
    }

    closedir(dir);
}

void list_json_files(const std::string &path, std::vector<std::string> &json_files) {
    if (is_directory(path)) {
        list_json_files_in_directory(path, json_files);
    } else if (is_regular_file(path)) {
        if (has_json_extension(path)) {
            json_files.push_back(path);
        } else {
            Error("File is not a json file: ", path);
        }
    } else {
        Error("Path is neither a directory nor a regular file: ", path);
    }
}
