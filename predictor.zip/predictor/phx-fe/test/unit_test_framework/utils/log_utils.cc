#include "log_utils.h"
#include <iostream>
#include <memory>
#include <spdlog/common.h>
#include <spdlog/sinks/stdout_color_sinks.h>

std::shared_ptr<spdlog::logger> g_logger = spdlog::stdout_color_mt("console");

void set_log_level(const std::string &level_str) {
    if (level_str == "debug") {
        g_logger->set_level(spdlog::level::debug);
    } else if (level_str == "info") {
        g_logger->set_level(spdlog::level::info);
    } else if (level_str == "warn") {
        g_logger->set_level(spdlog::level::warn);
    } else if (level_str == "err") {
        g_logger->set_level(spdlog::level::err);
    } else {
        std::cerr << "未知日志级别: " << level_str << ", 使用默认 info" << std::endl;
        g_logger->set_level(spdlog::level::info);
    }
}

void DebugImpl(const std::string &msg) {
    g_logger->debug(msg);
}

void InfoImpl(const std::string &msg) {
    g_logger->info(msg);
}

void WarningImpl(const std::string &msg) {
    g_logger->warn(msg);
}

void ErrorImpl(const std::string &msg) {
    g_logger->error(msg);
}

void SuccessImpl(const std::string &msg) {
    // 蓝色 ANSI 码：\033[34m，重置：\033[0m
    g_logger->info(fmt::format("\033[34m[SUCCESS] {}\033[0m", msg));
}

void FailImpl(const std::string &msg) {
    // 橙色 ANSI 码：\033[38;5;208m（256色中的橙色），重置：\033[0m
    g_logger->error(fmt::format("\033[38;5;208m[FAIL] {}\033[0m", msg));
}
