#ifndef USE_UT_FRAMEWORK
#define USE_UT_FRAMEWORK
#endif

#include "phx_unit_test_framework.h"
#include "phx-fe/test/unit_test_framework/utils/json_utils.h"
#include "phx-fe/test/unit_test_framework/utils/log_utils.h"
#include "phx-fe/test/unit_test_framework/utils/proto_utils.h"
#include "phx-fe/util/util.h"
#include <csetjmp>
#include <csignal>
#include <memory>
#include <signal.h>
#include <tinyxml2.h>

TestStats globalStats;

static sigjmp_buf g_test_jump_buffer;

void unblock_signals() {
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set, SIGFPE);
    sigaddset(&set, SIGSEGV);
    sigprocmask(SIG_UNBLOCK, &set, nullptr);
}

void handle_crash(int sig) {
    const char *msg = nullptr;
    switch (sig) {
        case SIGFPE:
            msg = "SIGFPE (div-by-zero/overflow)";
            break;
        case SIGSEGV:
            msg = "SIGSEGV (nullptr/bad memory access)";
            break;
        default:
            msg = "Unknown signal";
            break;
    }
    std::cerr << "[CRASH] Test failed due to: " << msg << "\n";
    siglongjmp(g_test_jump_buffer, 1);// 跳转到 sigsetjmp 处
}

void setup_signal_handlers() {
    signal(SIGFPE, handle_crash);
    signal(SIGSEGV, handle_crash);
}

bool run_unit_test(const std::string &json_file_path) {
    google::protobuf::Arena arena;
    PrintBanner(&Info,"UT开始 处理文件：",json_file_path);

    try {
        // 解析 FE单测 JSON 配置文件 （公共逻辑）
        nlohmann::json json_data;
        if (!ReadJsonFile(json_file_path, json_data))
            return false;

        //构造词典 （公共逻辑）
        long dicts_handle = 0L;
        if (!InitDictConfig(json_data, dicts_handle))
            return false;

        AllDicts dicts;
        dicts.id_123class_dict_ptr.reset(new std::unordered_map<std::string, AllClasses>());
        dicts.id_dict_ptr.reset(new std::unordered_map<std::string, AllClasses>());
        dicts.pack_dict_ptr.reset(new std::unordered_map<std::string, AllClasses>());
        dicts.appname_dict_ptr.reset(new std::unordered_map<std::string, AllClasses>());
        dicts.dicts_handle = dicts_handle;

        //构造UT预期输出 （公共逻辑）
        Output expected_output;
        if (!ParseExpectedOutput(json_data, arena, expected_output))
            return false;

        //拆出 "config_str" （公共逻辑）
        std::string config_str;
        if (json_data.contains("config_str")) {
            config_str = json_data["config_str"];
            Debug("config_str: ", config_str);
        } else {
            Error("缺少字段: config_str");
            return false;
        }

        std::vector<Output> input_values;
        std::vector<const Output *> input_ptrs;
        Config *config_ptr = nullptr;
        phx::FeRequest *fe_request;
        phx::UserAction *user_action;
        std::unordered_map<std::string, Output> cache;

        if (json_data.contains("fe_request")) {
            Info("使用FeRequest和UserAction等对象间接构造算子输入");
            tinyxml2::XMLDocument doc;
            auto *feature = ParseFeatureConfigFromXml(config_str, doc);
            const char *name_str = feature->Attribute("name");

            config_ptr = CreateConfigFromXMLElement(feature, dicts);
            if (!config_ptr) {
                return false;
            }
            config_ptr->output_ = name_str;

            fe_request = create_proto_from_json<phx::FeRequest>(json_data["fe_request"], &arena);
            user_action = create_proto_from_json<phx::UserAction>(json_data["user_action"], &arena);

            Output &output = cache[config_ptr->output_];
            output.arena = &arena;
            output.allow_empty_output = config_ptr->allow_empty_output_;

            Debug("FeRequest: ", message_to_json(*fe_request));
            Debug("UserAction: ", message_to_json(*user_action));

            getInputsResultV2(&arena, *fe_request, *user_action, config_ptr->inputs_, cache, input_ptrs);
            Debug("input_ptrs size: ", input_ptrs.size());
            for (const auto &input_value: input_ptrs) {
                Debug("input_value: ", input_value->to_string());
            }
            Debug("test_by_fe_service end");
        } else {
            Info("直接构造算子输入");
            if (!ParseInputValues(json_data, arena, input_values)) {
                return false;
            }

            Debug("input_values: ");
            for (const auto &i: input_values) {
                Debug(i.to_string());
            }

            // 构造算子
            config_ptr = CreateConfigFromJson(config_str, dicts);
            if (!config_ptr) {
                return false;
            }

            BuildInputPtrs(input_values, input_ptrs);
        }

        Debug("input_ptrs size: ", input_ptrs.size());
        for (const auto &input_value: input_ptrs) {
            Debug("input_value: ", input_value->to_string());
        }

        // 执行计算并比较结果（公共逻辑）
        return ComputeAndCompare(config_ptr, input_ptrs, expected_output);

    } catch (const std::exception &e) {
        Error("捕获异常，std::exception: ", e.what());
        return false;
    } catch (...) {
        Error("捕获未知异常，无法获取详细信息");
        return false;
    }
}

int main(int argc, char **argv) {
    setup_signal_handlers();
    try {
        std::string level = "info";
        // std::string input_path = "test_more_json_file";//批量执行UT
        std::string input_path = "json_files";//批量执行UT
        // std::string input_path = "json_files/test_json_file.json";//单文件执行UT
        for (int i = 1; i < argc; ++i) {
            std::string arg = argv[i];
            const std::string prefix_level = "--log_level=";
            const std::string prefix_input = "--input_path=";

            if (arg.find(prefix_level) == 0) {
                std::cout << "--log_level=" << arg.substr(prefix_level.size()) << std::endl;
                level = arg.substr(prefix_level.size());
            } else if (arg.find(prefix_input) == 0) {
                std::cout << "--input_path=" << arg.substr(prefix_input.size()) << std::endl;
                input_path = arg.substr(prefix_input.size());
            }
        }
        g_logger->set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%^%l%$] %v");
        set_log_level(level);
        PrintBanner(&Debug,"打开Debug 输出模式");
        PrintBanner(&Info,"FE UT框架 启动");
        Info("input_path: ", input_path);
        std::vector<std::string> json_files;
        list_json_files(input_path, json_files);

        for (const auto &file: json_files) {
            PrintBanner(&Info,"待测试文件：", file);
            if (sigsetjmp(g_test_jump_buffer, 1) == 0) {
                bool success = run_unit_test(file);
                if (success) {
                    Success("测试 ", file, " 成功");
                } else {
                    Fail("测试 ", file, " 失败");
                }
                globalStats.add_test_case_result(success);
            } else {
                Fail("测试 ", file, " 崩溃");
                globalStats.add_test_case_result(false);
            }
        }

        print_test_summary(globalStats);

        std::shared_ptr<int> int_shared_ptr = std::make_shared<int>();
        std::shared_ptr<int[]> int_arr_shared_ptr(new int[10]);

        return globalStats.overall_success() ? 0 : 1;
    } catch (const std::exception &e) {
        Error("捕获异常，std::exception: ", e.what());
        return -1;
    } catch (...) {
        Error("捕获未知异常，无法获取详细信息");
        return -1;
    }
}