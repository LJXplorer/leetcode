#include "test.h"

int g_total = 0;
int g_success = 0;

int main() {

  test_base();
  test_seq();
  test_utf8();
  test_time();
  test_gather();
  test_plus();
  
  std::cout << "all test done" << std::endl;
  std::cout << "total:" << g_total << std::endl;
  std::cout << "success:" << g_success << std::endl;

  if (g_success == g_total) {
    std::cout << "ALL SUCCESS" << std::endl;
  } else {
    std::cout << "ERROR" << std::endl;
  }

  return 0;
}