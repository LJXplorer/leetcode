#include "test.h"

//feature
void test_time_hour_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_hour",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeHourConfig* config = dynamic_cast<TimeHourConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727490578 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727361539 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721577341 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(11, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(10, itr00->second.int64_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(22, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(23, itr01->second.int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_LIST_INT64(({11, 10, 22, 23}), tvalues0);

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), tindices0);

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_time_hour_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_hour",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.time"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeHourConfig* config = dynamic_cast<TimeHourConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["time"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1727490578 * 1000);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1727361539 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1721577341 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(11, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(10, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(2, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(22, list.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(23, list.feature(1).int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_LIST_INT64(({11, 10, 22, 23}), tvalues0);

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_time_hour_scope_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_hour_scope",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ],
          "hour_boundary" : [],
          "name_boundary" : ["全天"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeHourScopeConfig* config = dynamic_cast<TimeHourScopeConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727512178 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727357539 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721577341 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721598941 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("全天", itr00->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("全天", itr00->second.bytes_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(3, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("全天", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("全天", itr01->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("全天", itr01->second.bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0, 1, 1, 1, 2}), ({2, 3}), ({"全天", "全天", "全天", "全天", "全天"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

//featurelist
void test_time_hour_scope_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_hour_scope",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.time"
          ],
          "hour_boundary" : [6, 11, 14, 20],
          "name_boundary" : ["凌晨", "早上", "中午", "下午", "夜晚"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 3, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeHourScopeConfig* config = dynamic_cast<TimeHourScopeConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["time"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1727555348 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1727476178 * 1000);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1727328739 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1721552141 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1721660141 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_FEATURE_LIST_STR(({{"凌晨", "早上"}, {"中午", "下午", "夜晚"}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(6, tvalues0.string_val_size());
  TEST_LIST_STRING(({"凌晨", "早上", "", "中午", "下午", "夜晚"}), tvalues0);

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_time_day_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_day",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeDayConfig* config = dynamic_cast<TimeDayConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727490578 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727361539 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721577341 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(29, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(28, itr00->second.int64_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(26, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(21, itr01->second.int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_LIST_INT64(({29, 28, 26, 21}), tvalues0);

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  std::vector<int32_t> indices = {0, 0, 0, 1, 1, 0, 1, 1};
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), tindices0);

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_time_day_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_day",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.time"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeDayConfig* config = dynamic_cast<TimeDayConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["time"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1727490578 * 1000);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1727361539 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1721577341 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_FEATURE_LIST_INT64(({{29, 28}, {26, 21}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_LIST_INT64(({29, 28, 26, 21}), tvalues0);

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_time_day_scope_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_day_scope",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ],
          "day_boundary" : [],
          "name_boundary" : ["整月"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeDayScopeConfig* config = dynamic_cast<TimeDayScopeConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727512178 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727357539 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721577341 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721598941 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("整月", itr00->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("整月", itr00->second.bytes_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(3, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("整月", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("整月", itr01->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("整月", itr01->second.bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(5, tvalues0.string_val_size());
  TEST_LIST_STRING(({"整月", "整月", "整月", "整月", "整月"}), tvalues0);

  TEST_ASSERT_EQUAL(10, tindices0.int64_val_size());
  std::vector<int32_t> indices = {0, 0, 0, 1, 1, 0, 1, 1, 1, 2};
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1, 1, 2}), tindices0);

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_time_day_scope_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_day_scope",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.time"
          ],
          "day_boundary" : [11, 21],
          "name_boundary" : ["上旬", "中旬", "下旬"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 3, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeDayScopeConfig* config = dynamic_cast<TimeDayScopeConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["time"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1725784178 * 1000);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1725629539 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1720713341 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1721598941 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("下旬", list.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("上旬", list.feature(0).bytes_list().value(1));
  TEST_ASSERT_EQUAL(3, list.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("上旬", list.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("中旬", list.feature(1).bytes_list().value(1));
  TEST_EXPECT_EQUAL("下旬", list.feature(1).bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(6, tvalues0.string_val_size());
  TEST_LIST_STRING(({"下旬", "上旬", "", "上旬", "中旬", "下旬"}), tvalues0);

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_time_week_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_week",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeWeekConfig* config = dynamic_cast<TimeWeekConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727490578 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727361539 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721577341 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(7, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(6, itr00->second.int64_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(4, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(7, itr01->second.int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_LIST_INT64(({7, 6, 4, 7}), tvalues0);

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  std::vector<int32_t> indices = {0, 0, 0, 1, 1, 0, 1, 1};
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), tindices0);

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_time_week_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_week",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.time"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeWeekConfig* config = dynamic_cast<TimeWeekConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["time"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1727490578 * 1000);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1727361539 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1721577341 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(7, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(6, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(2, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(4, list.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(7, list.feature(1).int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_LIST_INT64(({7, 6, 4, 7}), tvalues0);

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_time_week_scope_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_week_scope",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ],
          "week_boundary" : [],
          "name_boundary" : ["整周"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeWeekScopeConfig* config = dynamic_cast<TimeWeekScopeConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727512178 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727357539 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721577341 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721598941 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("整周", itr00->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("整周", itr00->second.bytes_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(3, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("整周", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("整周", itr01->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("整周", itr01->second.bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(5, tvalues0.string_val_size());
  TEST_LIST_STRING(({"整周", "整周", "整周", "整周", "整周"}), tvalues0);

  TEST_ASSERT_EQUAL(10, tindices0.int64_val_size());
  std::vector<int32_t> indices = {0, 0, 0, 1, 1, 0, 1, 1, 1, 2};
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1, 1, 2}), tindices0);

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_time_week_scope_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_week_scope",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.time"
          ],
          "week_boundary" : [6],
          "name_boundary" : ["工作日", "周末"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 3, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeWeekScopeConfig* config = dynamic_cast<TimeWeekScopeConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["time"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1727512178 * 1000);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1727357539 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1721577341 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1721944541 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("周末", list.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("周末", list.feature(0).bytes_list().value(1));
  TEST_ASSERT_EQUAL(3, list.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("工作日", list.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("周末", list.feature(1).bytes_list().value(1));
  TEST_EXPECT_EQUAL("工作日", list.feature(1).bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(6, tvalues0.string_val_size());
  TEST_LIST_STRING(({"周末", "周末", "", "工作日", "周末", "工作日"}), tvalues0);

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_time_month_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_month",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeMonthConfig* config = dynamic_cast<TimeMonthConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1706219741 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727490578 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1703561838 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721577341 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(9, itr00->second.int64_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(12, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(7, itr01->second.int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_LIST_INT64(({1, 9, 12, 7}), tvalues0);

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  std::vector<int32_t> indices = {0, 0, 0, 1, 1, 0, 1, 1};
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), tindices0);

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_time_month_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_month",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.time"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeMonthConfig* config = dynamic_cast<TimeMonthConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["time"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1706219741 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1727490578 * 1000);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1703561838 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1721577341 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(9, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(2, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(12, list.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(7, list.feature(1).int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_LIST_INT64(({1, 9, 12, 7}), tvalues0);

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_time_month_scope_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_month_scope",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ],
          "month_boundary" : [],
          "name_boundary" : ["整月"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeMonthScopeConfig* config = dynamic_cast<TimeMonthScopeConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727580548 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727512178 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727357539 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721577341 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1721598941 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("整月", itr00->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("整月", itr00->second.bytes_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(3, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("整月", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("整月", itr01->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("整月", itr01->second.bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(5, tvalues0.string_val_size());
  TEST_LIST_STRING(({"整月", "整月", "整月", "整月", "整月"}), tvalues0);

  TEST_ASSERT_EQUAL(10, tindices0.int64_val_size());
  std::vector<int32_t> indices = {0, 0, 0, 1, 1, 0, 1, 1, 1, 2};
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1, 1, 2}), tindices0);

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_time_month_scope_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_month_scope",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.time"
          ],
          "month_boundary" : [4, 7, 10],
          "name_boundary" : ["P1", "P2", "H1", "H2"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 3, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeMonthScopeConfig* config = dynamic_cast<TimeMonthScopeConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["time"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1706219741 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1727490578 * 1000);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1716730339 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1703561838 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1721577341 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("P1", list.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("H1", list.feature(0).bytes_list().value(1));
  TEST_ASSERT_EQUAL(3, list.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("P2", list.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("H2", list.feature(1).bytes_list().value(1));
  TEST_EXPECT_EQUAL("H1", list.feature(1).bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(6, tvalues0.string_val_size());
  TEST_LIST_STRING(({"P1", "H1", "", "P2", "H2", "H1"}), tvalues0);

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_time_holiday_scope_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_holiday_scope",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ],
          "holiday_boundary" : {
            "2023" : [4, 29, 5, 3,
                      6, 22, 6, 24,
                      9, 30, 10, 6],
            "2024" : [5, 1, 5, 5,
                      6, 8, 6, 10,
                      10, 1, 10, 7]
          },
          "name_boundary" : ["劳动节", "端午节", "国庆节"],
          "default_value" : "非假期"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeHolidayScopeConfig* config = dynamic_cast<TimeHolidayScopeConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1727666948 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1682887702 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1696155118 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1696661302 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1728283702 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("非假期", itr00->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("劳动节", itr00->second.bytes_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(3, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("国庆节", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("非假期", itr01->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("国庆节", itr01->second.bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(5, tvalues0.string_val_size());
  TEST_LIST_STRING(({"非假期", "劳动节", "国庆节", "非假期", "国庆节"}), tvalues0);

  TEST_ASSERT_EQUAL(10, tindices0.int64_val_size());
  std::vector<int32_t> indices = {0, 0, 0, 1, 1, 0, 1, 1, 1, 2};
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1, 1, 2}), tindices0);

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_time_holiday_scope_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "time_holiday_scope",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.time"
          ],
          "holiday_boundary" : {
            "2023" : [4, 29, 5, 3,
                      6, 22, 6, 24,
                      9, 30, 10, 6],
            "2024" : [5, 1, 5, 5,
                      6, 8, 6, 10,
                      10, 1, 10, 7]
          },
          "name_boundary" : ["劳动节", "端午节", "国庆节"],
          "default_value" : "非假期日"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 3, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  TimeHolidayScopeConfig* config = dynamic_cast<TimeHolidayScopeConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["time"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1717831143 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1719026948 * 1000);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)1714865919 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1728287312 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)1683195118 * 1000);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("端午节", list.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("非假期日", list.feature(0).bytes_list().value(1));
  TEST_ASSERT_EQUAL(3, list.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("劳动节", list.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("国庆节", list.feature(1).bytes_list().value(1));
  TEST_EXPECT_EQUAL("非假期日", list.feature(1).bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(6, tvalues0.string_val_size());
  TEST_LIST_STRING(({"端午节", "非假期日", "", "劳动节", "国庆节", "非假期日"}), tvalues0);

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//测试凌晨和夜晚的时间戳，是否与东八区时区匹配
void test_time_morning_night() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f10" : {
          "fe_type" : "time_hour",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ]
      },
      "f11" : {
          "fe_type" : "time_day",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ]
      },
      "f12" : {
          "fe_type" : "time_week",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ]
      },
      "f13" : {
          "fe_type" : "time_month",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ]
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  //2024-08-01 02:55:41 周四
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1722452141 * 1000);
  //2024-07-31 23:48:21 周三
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1722440901 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  //2023-03-01 00:18:17 周三
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1677601097 * 1000);
  //2023-02-28 22:51:31 周二
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)1677595891 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f10");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(23, itr00->second.int64_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f10");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(0, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(22, itr01->second.int64_list().value(1));

  const auto& map02 = batch_ret.batch(0).context().feature();
  auto itr02 = map02.find("f11");
  TEST_ASSERT_BOOL(itr02 != map02.end());

  TEST_ASSERT_EQUAL(2, itr02->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr02->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(31, itr02->second.int64_list().value(1));

  const auto& map03 = batch_ret.batch(1).context().feature();
  auto itr03 = map03.find("f11");
  TEST_ASSERT_BOOL(itr03 != map03.end());

  TEST_ASSERT_EQUAL(2, itr03->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr03->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(28, itr03->second.int64_list().value(1));

  const auto& map04 = batch_ret.batch(0).context().feature();
  auto itr04 = map04.find("f12");
  TEST_ASSERT_BOOL(itr04 != map04.end());

  TEST_ASSERT_EQUAL(2, itr04->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(4, itr04->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(3, itr04->second.int64_list().value(1));

  const auto& map05 = batch_ret.batch(1).context().feature();
  auto itr05 = map05.find("f12");
  TEST_ASSERT_BOOL(itr05 != map05.end());

  TEST_ASSERT_EQUAL(2, itr05->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr05->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(2, itr05->second.int64_list().value(1));
    
  const auto& map06 = batch_ret.batch(0).context().feature();
  auto itr06 = map06.find("f13");
  TEST_ASSERT_BOOL(itr06 != map06.end());

  TEST_ASSERT_EQUAL(2, itr06->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(8, itr06->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(7, itr06->second.int64_list().value(1));

  const auto& map07 = batch_ret.batch(1).context().feature();
  auto itr07 = map07.find("f13");
  TEST_ASSERT_BOOL(itr07 != map07.end());

  TEST_ASSERT_EQUAL(2, itr07->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr07->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(2, itr07->second.int64_list().value(1));
}

void test_time() {
  test_time_hour_1();
  test_time_hour_2();

  test_time_hour_scope_1();
  test_time_hour_scope_2();

  test_time_day_1();
  test_time_day_2();

  test_time_day_scope_1();
  test_time_day_scope_2();

  test_time_week_1();
  test_time_week_2();

  test_time_week_scope_1();
  test_time_week_scope_2();

  test_time_month_1();
  test_time_month_2();

  test_time_month_scope_1();
  test_time_month_scope_2();

  test_time_holiday_scope_1();
  test_time_holiday_scope_2();

  test_time_morning_night();
}