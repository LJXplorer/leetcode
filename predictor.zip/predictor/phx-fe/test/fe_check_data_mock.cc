#include "fe_request.pb.h"
#include "user_action.pb.h"
#include "phx-fe/util/pb_utils.h"

int main() {
    int mock_number = 10;
    for (int i = 0; i < mock_number; i++) {
        phx::UserAction user_action;
        phx::FeRequest fe_request;
        mocker::FillProto(user_action);
        mocker::FillProto(fe_request);
        debug::SavePbToFile("user_actions.txt", user_action, debug::PbFormat::kBase64, std::ios::app);
        debug::SavePbToFile("fe_requests.txt", fe_request, debug::PbFormat::kBase64, std::ios::app);
    }
}