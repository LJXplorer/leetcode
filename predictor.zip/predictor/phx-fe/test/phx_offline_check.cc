
#include "phx-fe/config_mgr/xml_config_mgr.h"
#include "phx-fe/decode/base64.h"
#include "phx-fe/src/service.h"


#include <fstream>
#include <iostream>
#include <string>

std::vector<std::string> ReadBase64FileToLines(const std::string &filename) {
    std::vector<std::string> decoded_lines;
    std::ifstream infile(filename);
    if (!infile) {
        std::cerr << "Cannot open file: [" << filename << "]";
    }

    std::string line;
    while (std::getline(infile, line)) {
        if (!line.empty()) {
            decoded_lines.push_back(base64_decode(line));
        }
    }

    return decoded_lines;
}

int main(int argc, const char *argv[]) {
    if (argc < 6) {
        std::cout << "Usage: " << argv[0] << " <xml_fe_config> <dict_path_prefix> <version> <fe_request> <user_action>"
                  << std::endl;
        return -1;
    }

    const char *fe_config_path = argv[1];
    const char *dict_path_prefix = argv[2];
    const char *version = argv[3];
    const char *fe_request_path = argv[4];
    const char *user_action_path = argv[5];

    std::string fe_config_content = Calc::read_file_to_string(fe_config_path);// 读fe_config的内容
    auto dict_config_plain_tex_vec =
            XmlConfigMgr::get_dict_configs_from_string(fe_config_content, version);// 只处理明文

    nlohmann::json json_array{};
    for (const auto &conf: dict_config_plain_tex_vec) {
        nlohmann::json object{};
        object["name"] = conf.name;
        object["path"] = dict_path_prefix + conf.path;// 词典路径加前缀
        object["value_proto"] = conf.value_proto;
        object["class_name"] = conf.class_name;
        json_array.emplace_back(object);
    }

    long dict_handle = 0;
    try {
        dict_handle = init_offline_dicts(json_array.dump());
    } catch (const std::exception &e) {
        std::cerr << e.what() << std::endl;
    } catch (...) {
        std::cerr << "Parse unknown error" << std::endl;
        return -1;
    }

    google::protobuf::Arena arena;
    phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
    phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
    std::string empty_fe_request;
    fe_request.SerializeToString(&empty_fe_request);
    std::string empty_user_action;
    user_action.SerializeToString(&empty_user_action);

    std::vector<std::string> fe_requests = ReadBase64FileToLines(fe_request_path);
    std::vector<std::string> user_actions = ReadBase64FileToLines(user_action_path);
    if (fe_requests.size() != user_actions.size() && !fe_requests.empty() && !user_actions.empty()) {
        std::cerr << "fe_requests.size :" << fe_requests.size()
                  << " != " << "user_actions.size :" << user_actions.size() << std::endl;
        return 0;
    }

    long config_handle = 0;
    ConfigInfo *ptr = nullptr;

    try {
        ptr = init_xml_offline_by_content_new_sample(fe_config_content.c_str(), dict_handle, version);
        config_handle = reinterpret_cast<long>(ptr);
    } catch (const std::exception &e) {
        std::cerr << e.what() << std::endl;
        std::cout << "Try parse by decode fe_config" << std::endl;
        ptr = init_xml_offline_crypt_by_content_new_sample(fe_config_content.c_str(), dict_handle, version);
        config_handle = reinterpret_cast<long>(ptr);
    } catch (...) {
        std::cerr << "Parse unknown error" << std::endl;
        return -1;
    }

#ifdef FASTFLOW_DEBUG_INFO_ENABLE
    LogCheck(fe_config_content);
#endif

    size_t progress = 0;
    size_t progress_cnt = 0;
    std::string extractor_response_str{};
    if (user_actions.empty()) {
        std::cout << "request count = [" << fe_requests.size() << "]\n";
        for (const auto &fe_request: fe_requests) {
            extractor_response_str =
                    to_extractor_response(fe_request.c_str(), fe_request.length(), empty_user_action.c_str(),
                                          empty_user_action.length(), config_handle);

            phx::ExtractorResponse extractor_response;
            extractor_response.ParseFromString(extractor_response_str);

            for (int i = 0; i < extractor_response.item_extras_bytes_size(); ++i) {
                if (extractor_response.item_extras_bytes(i).feature().signs_size() != 0 ||
                    extractor_response.item_extras_bytes(i).feature().weights_size() != 0) {
                    THROW_ERROR("extractor response failed! item_extras_bytes have int or float data");
                }
            }
            for (int i = 0; i < extractor_response.item_extras_int64_size(); ++i) {
                if (extractor_response.item_extras_int64(i).feature().bytes_list_size() != 0 ||
                    extractor_response.item_extras_int64(i).feature().weights_size() != 0) {
                    THROW_ERROR("extractor response failed! item_extras_int64 have bytes or float data");
                }
            }
            for (int i = 0; i < extractor_response.item_extras_float_size(); ++i) {
                if (extractor_response.item_extras_float(i).feature().signs_size() != 0 ||
                    extractor_response.item_extras_float(i).feature().bytes_list_size() != 0) {
                    THROW_ERROR("extractor response failed! item_extras_float have int or bytes data");
                }
            }

            progress_cnt++;
            size_t percent = progress_cnt * 100 / fe_requests.size();
            if (progress < percent) {
                progress = percent;
                std::cout << "\r" << progress << std::flush;
            }
        }
    } else {
        auto request_size = std::min(user_actions.size(), fe_requests.size());
        std::cout << "request count = [" << request_size << "]\n";
        for (size_t i = 0; i < request_size; i++) {
            extractor_response_str =
                    to_extractor_response(fe_requests[i].c_str(), fe_requests[i].length(), user_actions[i].c_str(),
                                          user_actions[i].length(), config_handle);

            phx::ExtractorResponse extractor_response;
            extractor_response.ParseFromString(extractor_response_str);

            for (int i = 0; i < extractor_response.item_extras_bytes_size(); ++i) {
                if (extractor_response.item_extras_bytes(i).feature().signs_size() != 0 ||
                    extractor_response.item_extras_bytes(i).feature().weights_size() != 0) {
                    THROW_ERROR("extractor response failed! item_extras_bytes have int or float data");
                }
            }
            for (int i = 0; i < extractor_response.item_extras_int64_size(); ++i) {
                if (extractor_response.item_extras_int64(i).feature().bytes_list_size() != 0 ||
                    extractor_response.item_extras_int64(i).feature().weights_size() != 0) {
                    THROW_ERROR("extractor response failed! item_extras_int64 have bytes or float data");
                }
            }
            for (int i = 0; i < extractor_response.item_extras_float_size(); ++i) {
                if (extractor_response.item_extras_float(i).feature().signs_size() != 0 ||
                    extractor_response.item_extras_float(i).feature().bytes_list_size() != 0) {
                    THROW_ERROR("extractor response failed! item_extras_float have int or bytes data");
                }
            }

            progress_cnt++;
            size_t percent = progress_cnt * 100 / fe_requests.size();
            if (progress < percent) {
                progress = percent;
                std::cout << "\r" << progress << std::flush;
            }
        }
    }

    phx::ExtractorResponse extractor_response{};
    extractor_response.ParseFromString(extractor_response_str);

    //debug::pb::SavePbToFile("extractor_response.json", extractor_response);
    release_config(config_handle);
    return 0;
}