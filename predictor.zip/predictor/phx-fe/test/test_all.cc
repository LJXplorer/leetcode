#include "phx-fe/src/service.h"
#include "phx-fe/util/dir.h"

#include <fstream>
#include <string>
#include <iostream>
#include <thread>
#include <google/protobuf/util/json_util.h>

// 遍历文件夹中的request测试算子
void predict_request_from_dir(const std::string& fe_config, const std::string& fe_model_input, const std::string& dict_path,
                              const std::string& fe_request_path) {
  ConfigInfo config_info;

  init_xml_online_by_content_v3(fe_config, fe_model_input, dict_path, config_info);

  std::vector<google::protobuf::Arena*> vec_arena;
  std::vector<qinglong::FeRequest*> vec_request; 
  std::vector<qinglong::PredictRequest*> vec_predict_request;
  std::vector<FeatureExtractorObject> vec_fe_object;
  std::vector<std::string> file_list;
  std::vector<std::string> dir_list;
  Dir::get_sub_path(fe_request_path, file_list, dir_list);

  vec_arena.resize(file_list.size());
  vec_request.resize(file_list.size());
  vec_predict_request.resize(file_list.size());

  for (uint32_t i = 0; i < file_list.size(); i++) {
    vec_arena[i] = new google::protobuf::Arena();
    std::string fe_request_str = Calc::read_file_to_string(file_list[i]);

    vec_request[i] = google::protobuf::Arena::CreateMessage<qinglong::FeRequest>(vec_arena[i]);
    if (Calc::is_right_postfix("json", file_list[i])) {
      google::protobuf::util::JsonStringToMessage(fe_request_str, vec_request[i]);
    } else {
      vec_request[i]->ParseFromString(fe_request_str);
    }
    vec_fe_object.emplace_back(*vec_request[i]);
    vec_predict_request[i] = google::protobuf::Arena::CreateMessage<qinglong::PredictRequest>(vec_arena[i]);
  }

  for (uint32_t i = 0; i < file_list.size(); i++) {
    to_predict_request_v3(config_info, vec_arena[i], vec_fe_object[i], vec_predict_request[i]);
  }

  for (uint32_t i = 0; i < file_list.size(); i++) {
    delete vec_arena[i];
  }
}

int main(int argc, const char* argv[]) {
  // 包含全部算子的xml配置，设置empty策略允许空输出，部分来自SequenceExample中map_feature的数据和提取子message中fileds的数据需要设置默认数据类型
  std::string config_str = R"(
    <config>
        <source name="user_am_clk" value=".user_feature.am_gm_clk_off.am_clk_off.user_sequence" />
        <source name="gm_clk_off_sequence" value=".user_feature.am_gm_clk_off.gm_clk_off.user_sequence" />
        <source name="user_imp_yoyo" value=".user_feature.yoyo_imp_off.yoyo_imp_off" />
        <source name="user_feature_list" value=".user_feature.user_feature_se.feature_lists.feature_list" />
        <source name="item_feature_list" value=".item_feature.item_feature_se.feature_lists.feature_list" />
        <source name="item_se_feature" value=".item_feature.item_feature_se.context.feature" />
        <source name="user_se_feature" value=".user_feature.user_feature_se.context.feature" />
        <source name="first_use_off_sequence" value=".user_feature.g_first_use_off.first_use_off.user_sequence" />
        <source name="user_se_query_pkg_feature" value=".user_feature.af_user_feature.ad_query_feature.query_pkg_rank_feature_group" />
        <source name="user_app_api_conversion_sequence" value=".user_feature.app_conv_off.app_credit_conversion_seq_offline_180d.user_app_api_conversion_seq" />
        <source name="g_use_off_all_sequence" value=".user_feature.global_user_off_all.g_use_off_all.user_sequence" />
        <source name="im_adunit_pkg_stats_info" value=".user_feature.ad_adunit_id_feature.im_adunit_pkg_rank_feature_group.pkg_stats_info" />
        <source name="g_first_open_nl_sequence" value=".user_feature.g_first_open_nl.user_sequence" />

        <source dict_name="appInfoUtf8Dict" value="test/data/item_map.txt" />
        <source dict_name="appInfoMinorDict" value="test/data/app_info_minor_mini" />
        <source dict_name="jiebaHmmModelUtf8Dict" value="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" />
        <source dict_name="jiebaDictUtf8Dict" value="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" />
        <source dict_name="jiebaUserDictUtf8Dict" value="third_party/cppjieba-5.0.3/dict/user.dict.utf8" />
        <source dict_name="set_dict" value="test/data/query_appname.txt" />
        <source dict_name="map_dict" value="test/data/query_appname_value.txt" />

        <features>
            <feature name="f0" type="bucketize" source="user_am_clk.num" boundary="0.09,1.01,2.56" strategy="empty" />
            <feature name="f1" type="hash" source="gm_clk_off_sequence.app_id" bucket_size="1000" concat_with_name="true" strategy="empty" />
            <feature name="f2" type="vocab_list" source="item_feature_list.default" vocabs="NOT_EXIST,1,2,3,4,5,6,7,8,9" strategy="empty" />
            <feature name="f3" type="vocab_set" source=".user_action.item_id.app_id" dict="app0,app1,app2,app3,app4,app5,app6" strategy="empty" />
            <feature name="f4" type="direct" source="item_se_feature.direct" strategy="empty,string" />
            <feature name="f5" type="filter_appid" source="user_am_clk.app_id,user_am_clk.event_time,.request_time" days="1,3,10" max_len="100" strategy="empty" />
            <feature name="f6" type="direct" source="f5:0" strategy="empty" />
            <feature name="f7" type="direct" source="f5:1" strategy="empty" />
            <feature name="f8" type="direct" source="f5:2" strategy="empty" />
            <feature name="f9" type="max_expo_appid" source="user_am_clk.app_id" strategy="empty" />
            <feature name="f10" type="max_123_class" source="user_am_clk.app_id" strategy="empty" />
            <feature name="f11" type="direct" source="f10:0" strategy="empty" />
            <feature name="f12" type="direct" source="f10:1" strategy="empty" />
            <feature name="f13" type="direct" source="f10:2" strategy="empty" />
            <feature name="f14" type="nearest_expo_appid" source="user_am_clk.app_id" strategy="empty,string" />
            <feature name="f15" type="expo_appid_count" source="user_am_clk.app_id,item_se_feature.app_id" strategy="empty" />
            <feature name="f16" type="expo_appid_count_v2" source="user_am_clk.app_id,item_se_feature.app_id" strategy="empty" />
            <feature name="f17" type="direct" source="f16:0" strategy="empty" />
            <feature name="f18" type="direct" source="f16:1" strategy="empty" />
            <feature name="f19" type="expo_123_count" source="user_am_clk.app_id,item_se_feature.app_id" strategy="empty" />
            <feature name="f20" type="direct" source="f19:0" strategy="empty" />
            <feature name="f21" type="direct" source="f19:1" strategy="empty" />
            <feature name="f22" type="direct" source="f19:2" strategy="empty" />
            <feature name="f23" type="expo_123_count_v2" source="user_am_clk.app_id,item_se_feature.app_id" strategy="empty" />
            <feature name="f24" type="direct" source="f23:0" strategy="empty" />
            <feature name="f25" type="direct" source="f23:1" strategy="empty" />
            <feature name="f26" type="direct" source="f23:2" strategy="empty" />
            <feature name="f27" type="direct" source="f23:3" strategy="empty" />
            <feature name="f28" type="direct" source="f23:4" strategy="empty" />
            <feature name="f29" type="direct" source="f23:5" strategy="empty" />
            <feature name="f30" type="nearest_expo_days" source="user_am_clk.app_id,user_am_clk.event_time,.request_time,item_se_feature.app_id" strategy="empty" />
            <feature name="f31" type="appid_cross" source="user_am_clk.app_id,item_se_feature.app_id" bucket_size="100" strategy="empty" />
            <feature name="f32" type="to_feature" source="user_am_clk.num" strategy="empty,int64" />
            <feature name="f33" type="to_batch_feature" source="user_feature_list.batch" strategy="empty" />
            <feature name="f34" type="identity" source="item_se_feature.num" max_value="5" default_value="2" strategy="empty" />
            <feature name="f35" type="string_to_int64" source="item_se_feature.time" default_value="1700000000000" strategy="empty" />
            <feature name="f36" type="appid_to_123_class" source="user_am_clk.app_id" class_type="0" default_value="test_no_data" strategy="empty" />
            <feature name="f37" type="appid_to_123_class" source="user_am_clk.app_id" class_type="1" default_value="test_no_data" strategy="empty" />
            <feature name="f38" type="appid_to_123_class" source="user_am_clk.app_id" class_type="2" default_value="test_no_data" strategy="empty" />
            <feature name="f39" type="trans_type" source="item_se_feature.app_id" data_type="string" default_value="-20" strategy="empty" />
            <feature name="f40" type="trans_type" source="item_se_feature.app_id" data_type="float" default_value="-20" strategy="empty" />
            <feature name="f41" type="trans_type" source="item_se_feature.app_id" data_type="int64" default_value="-20" strategy="empty" />
            <feature name="f42" type="trans_type" source="item_se_feature.num" data_type="string" default_value="-20" strategy="empty" />
            <feature name="f43" type="trans_type" source="item_se_feature.num" data_type="float" default_value="-20" strategy="empty" />
            <feature name="f44" type="trans_type" source="item_se_feature.num" data_type="int64" default_value="-20" strategy="empty" />
            <feature name="f45" type="fully_cross" source="user_am_clk.app_id,item_se_feature.app_id" connector="_" default_value="test_no_date" strategy="empty" />
            <feature name="f46" type="connect" source="user_am_clk.app_id,user_am_clk.num" connector="#" tail="click" strategy="empty" />
            <feature name="f47" type="get_valid_value" source=".callback_req_ts,.request_time" strategy="empty" />
            <feature name="f48" type="int64_offset" source="user_am_clk.num" offset="5" strategy="empty" />
            <feature name="f49" type="int64_difference" source=".request_time,user_am_clk.event_time" strategy="empty" />
            <feature name="f50" type="clip" source="item_se_feature.num" start="1" size="2" strategy="empty,int64" />
            <feature name="f51" type="seq_topn" source="user_am_clk.app_id,user_am_clk.event_time,.request_time" start="60" topn="3" top_type="2" default_value="no_date" strategy="empty" />
            <feature name="f52" type="seq_filter" source="user_am_clk.app_id,user_am_clk.event_time,user_am_clk.use_duration,.request_time,user_am_clk.first_intent_type,user_am_clk.second_intent_type,user_am_clk.third_intent_type" start="86400" day_n="30" clip_size="2" default_value="no_date" filter="100;18,101;20,102" strategy="empty" />
            <feature name="f53" type="direct" source="f52:0" strategy="empty" />
            <feature name="f54" type="direct" source="f52:1" strategy="empty" />
            <feature name="f55" type="direct" source="f52:2" strategy="empty" />
            <feature name="f56" type="time_holiday_scope" source="item_feature_list.time" holiday_boundary="2023:4,29,5,3,6,22,6,24,9,30,10,6;2024:5,1,5,5,6,8,6,10,10,1,10,7" name_boundary="劳动节,端午节,国庆节" default_value="非假期日" strategy="empty" />
            <feature name="f57" type="seq_num_convert" source="user_am_clk.app_id" count_type="1" strategy="empty" />
            <feature name="f58" type="direct" source="f57:0" strategy="empty" />
            <feature name="f59" type="direct" source="f57:1" strategy="empty" />
            <feature name="f60" type="utf8_distance" source="item_se_feature.direct,item_se_feature.app_id" strategy="empty,feature" />
            <feature name="f61" type="vocab_set" source="item_se_feature.app_id" dict="set_dict" strategy="empty" />
            <feature name="f62" type="vocab_map" source="item_se_feature.app_id" dtype="int64" dict="map_dict" strategy="empty" />
            <feature name="f63" type="connect_all_to_string" source="user_am_clk.app_id" first_connector="_" second_connector="&" tail="tail"  strategy="empty" />
            <feature name="f64" type="cross_hash_bits" source="user_se_feature.query,item_feature_list.app_name" clip_size="1" strategy="empty,feature" />
            <feature name="f65" type="get_valid_value" source=".request_time,.callback_req_ts" strategy="empty" />
            <feature name="f66" type="get_valid_value_v2" source=".request_time,.callback_req_ts" invalid="0" strategy="empty" />
            <feature name="f67" type="act_value" source=".request_time,.request_time" activation_value="5" default_value="10" />
            <feature name="f68" type="int64_offset" source="f66" strategy="empty,dont_save" offset="28800000" />
            <feature name="f69" type="int64_difference" source=".request_time,.callback_req_ts" strategy="empty" />
            <feature name="f70" type="clip" source="f39" size="5" strategy="empty,feature,hash" />
            <feature name="f71" type="segment" source="user_se_feature.query" jieba_dict_path="jiebaDictUtf8Dict" hmm_model_path="jiebaHmmModelUtf8Dict" user_dict_path="jiebaUserDictUtf8Dict" strategy="empty,feature,hash" />
            <feature name="f72" type="dict_to_attributes" source="item_se_feature.app_id" dict_type="app_id" connector="\002" default_value="null" strategy="empty,feature" />
            <feature name="f73" type="conditional_filter" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq" filter="query,appid1,appid3;event_type,001" fields="pay_money,event_time" strategy="empty" />
            <feature name="f74" type="direct" source="f73:0" strategy="empty" />
            <feature name="f75" type="direct" source="f73:1" strategy="empty" />
            <feature name="f76" type="seq_topn" source="first_use_off_sequence.app_id,first_use_off_sequence.event_time,f66" start="5" topn="5" topn_type="2" strategy="empty,feature" />
            <feature name="f77" type="seq_topn_v2" source="first_use_off_sequence.app_id,first_use_off_sequence.event_time" start="5" topn="5" topn_type="2" strategy="empty,feature" />
            <feature name="f78" type="seq_topn_v2" source="first_use_off_sequence.app_id,first_use_off_sequence.event_time,first_use_off_sequence.use_duration" start="5" topn="5" topn_type="3" strategy="empty,feature" />
            <feature name="f79" type="seq_appcategory_topn" source="first_use_off_sequence.app_id,first_use_off_sequence.event_time,f66" start="5" topn="5" topn_type="1" strategy="empty" />
            <feature name="f80" type="direct" source="f79:0" strategy="empty" />
            <feature name="f81" type="direct" source="f79:1" strategy="empty" />
            <feature name="f82" type="direct" source="f79:1" strategy="empty" />
            <feature name="f83" type="seq_n" source="first_use_off_sequence.app_id,first_use_off_sequence.event_time,f66" save="true" end="259200" start="5" clip_size="300" strategy="empty,feature,hash" />
            <feature name="f84" type="seq_hit" source="first_use_off_sequence.app_id,first_use_off_sequence.event_time,f66,item_se_feature.app_id" start="5" strategy="empty,feature,hash" />
            <feature name="f85" type="seq_hit_num" source="first_use_off_sequence.app_id,first_use_off_sequence.event_time,f66,item_se_feature.app_id" start="5" max_num="200" strategy="empty,feature,hash" />
            <feature name="f86" type="seq_hit_duration" source="first_use_off_sequence.app_id,first_use_off_sequence.event_time,f66,item_se_feature.app_id" start="5" strategy="empty,feature,hash" />
            <feature name="f87" type="seq_hit_or_not" source="first_use_off_sequence.app_id,item_se_feature.app_id" strategy="feature,empty,hash"/>
            <feature name="f88" type="seq_hit_list" source="user_am_clk.app_id,user_am_clk.event_time,item_se_feature.app_id" strategy="feature,empty"/>
            <feature name="f89" type="direct" source="f88:0" strategy="empty" />
            <feature name="f90" type="direct" source="f88:1" strategy="empty,string" />
            <feature name="f91" type="cross2" source="user_am_clk.app_id,item_se_feature.app_id" strategy="empty" />
            <feature name="f92" type="stat_ctr" source="user_se_query_pkg_feature.query_pkg_1d_sequence.download_num,user_se_query_pkg_feature.query_pkg_1d_sequence.epo_num" min_expo="100" default_value="-1.0" strategy="empty,feature,hash" />
            <feature name="f93" type="stat_ctr_bucket" source=".item_feature.ad_feature_group.ad_creative_feature.creative_beh_offline_day_stat.item_ad_activate_ctr_1d" bucket_type="3" b="1000" a="1" k="2" strategy="empty,feature,hash" />
            <feature name="f94" type="seq_app2category" source="first_use_off_sequence.app_id,first_use_off_sequence.event_time,f66" start="5" dedup="true" clip_size="300" strategy="empty" />
            <feature name="f95" type="direct" source="f94:0" strategy="empty" />
            <feature name="f96" type="direct" source="f94:1" strategy="empty" />
            <feature name="f97" type="direct" source="f94:1" strategy="empty" />
            <feature name="f98" type="seq_filter" source="user_app_api_conversion_sequence.app_id,user_app_api_conversion_sequence.event_time,user_app_api_conversion_sequence.event_time,f66,user_app_api_conversion_sequence.media_id" start="5" filter="1706630718799478784" strategy="empty" />
            <feature name="f99" type="direct" source="f98:0" strategy="empty" />
            <feature name="f100" type="direct" source="f98:1" strategy="empty" />
            <feature name="f101" type="seq_diff" source="user_am_clk.app_id,user_am_clk.event_time,gm_clk_off_sequence.app_id,gm_clk_off_sequence.event_time,f66" start="864000" day_n="30" delta_day="10" strategy="empty" />
            <feature name="f102" type="seq_interest" source="g_use_off_all_sequence.app_id,g_use_off_all_sequence.event_time,f66,g_use_off_all_sequence.use_duration" start="1" end="86400" default_value="test_no_data" strategy="empty" />
            <feature name="f103" type="direct" source="f102:0" strategy="empty" />
            <feature name="f104" type="direct" source="f102:1" strategy="empty" />
            <feature name="f105" type="direct" source="f102:2" strategy="empty" />
            <feature name="f106" type="direct" source="f102:3" strategy="empty" />
            <feature name="f107" type="direct" source="f102:4" strategy="empty" />
            <feature name="f108" type="seq_fresh" source="g_use_off_all_sequence.app_id,g_use_off_all_sequence.event_time,f66,item_se_feature.app_id" start="1" end="2592000" default_value="0" strategy="empty,feature" />
            <feature name="f109" type="appid_to_123_class" source="item_se_feature.app_id" class_type="2" default_value="test_no_data" strategy="empty" />
            <feature name="f110" type="seq_dsp" source="f109,item_se_feature.event_time,f66,item_se_feature.pctr" start="1" end="2592000" default_value="test_no_data" strategy="empty" />
            <feature name="f111" type="direct" source="f110:0" strategy="empty" />
            <feature name="f112" type="direct" source="f110:1" strategy="empty" />
            <feature name="f113" type="seq_num_convert" source="user_app_api_conversion_sequence.app_id" topn_type="0" strategy="empty" />
            <feature name="f114" type="seq_val_direct" source="user_app_api_conversion_sequence.app_id,user_app_api_conversion_sequence.event_time,f66,user_app_api_conversion_sequence.event_time" start="5" day_n="30" strategy="feature" />
            <feature name="f115" type="direct" source="f114:0" strategy="empty" />
            <feature name="f116" type="direct" source="f114:1" strategy="empty" />
            <feature name="f117" type="direct" source="f114:2" strategy="empty,int64" />
            <feature name="f118" type="seq_by_inter" source=".user_feature.ad_context_feature.info_flow_context.info_flow_item.filter_words,.item_feature.item_feature_se.context.feature.app_id" inter_key="id" fields="name" strategy="empty,string" />
            <feature name="f119" type="seq_topn_direct" source="im_adunit_pkg_stats_info" filter_key="drank_1d" fields="package_name" topn="10" reserve="1" strategy="empty,feature,hash,int64" />
            <feature name="f120" type="seq_n_hour" source="g_use_off_all_sequence.app_id,g_use_off_all_sequence.event_time,f66" start="864000" day_n="30" hour="2" />
            <feature name="f121" type="direct" source="f120:0" strategy="empty" />
            <feature name="f122" type="direct" source="f120:1" strategy="empty" />
            <feature name="f123" type="seq_merge" source="first_use_off_sequence,g_first_open_nl_sequence" eventtime_key="event_time" strategy="empty" />
            <feature name="f124" type="direct" source="f123.app_id" strategy="empty" />
            <feature name="f125" type="utf8_distance" source="item_se_feature.app_id,item_se_feature.event_time" strategy="empty" />
            <feature name="f126" type="utf8_is_contains" source="g_use_off_all_sequence.app_id,item_se_feature.app_id" strategy="empty" />
            <feature name="f127" type="utf8_is_equal" source="g_use_off_all_sequence.app_id,item_se_feature.app_id" strategy="empty" />
            <feature name="f128" type="utf8_is_prefix" source="g_use_off_all_sequence.app_id,item_se_feature.app_id" strategy="empty" />
            <feature name="f129" type="utf8_join" source="g_use_off_all_sequence.app_id,item_se_feature.app_id" delimiter="-" strategy="empty" />
            <feature name="f130" type="utf8_public_prefix_length" source="g_use_off_all_sequence.app_id,item_se_feature.app_id" strategy="empty" />
            <feature name="f131" type="utf8_length" source="g_use_off_all_sequence.app_id" strategy="empty" />
            <feature name="f132" type="utf8_preprocess" source="g_use_off_all_sequence.app_id" strategy="empty" />
            <feature name="f133" type="utf8_split" source="g_use_off_all_sequence.app_id" split_width="2" strategy="empty" />
            <feature name="f134" type="utf8_coincide" source="g_use_off_all_sequence.app_id,item_se_feature.app_id" strategy="empty" />
            <feature name="f135" type="utf8_filter" source="g_use_off_all_sequence.app_id" length="1" strategy="empty" />
            <feature name="f136" type="time_hour" source="g_use_off_all_sequence.event_time"  strategy="empty" />
            <feature name="f137" type="time_hour_scope" source="g_use_off_all_sequence.event_time" hour_boundary="6,11,14,20" name_boundary="凌晨,早上,中午,下午,夜晚" strategy="empty" />
            <feature name="f138" type="time_day" source="g_use_off_all_sequence.event_time" strategy="empty" />
            <feature name="f139" type="time_day_scope" source="g_use_off_all_sequence.event_time" day_boundary="11,21" name_boundary="上旬,中旬,下旬" strategy="empty" />
            <feature name="f140" type="time_week" source="g_use_off_all_sequence.event_time" strategy="empty" />
            <feature name="f141" type="time_week_scope" source="g_use_off_all_sequence.event_time" week_boundary="6" name_boundary="工作日,周末" strategy="empty" />
            <feature name="f142" type="time_month" source="g_use_off_all_sequence.event_time" strategy="empty" />
            <feature name="f143" type="time_month_scope" source="g_use_off_all_sequence.event_time" month_boundary="4,7,10" name_boundary="P1,P2,P3,P4" strategy="empty" />
            <feature name="f144" type="time_holiday_scope" source="g_use_off_all_sequence.event_time" holiday_boundary="2023:4,29,5,3,6,22,6,24,9,30,10,6;2024:5,1,5,5,6,8,6,10,10,1,10,7" name_boundary="劳动节,端午节,国庆节" strategy="empty" />
            <feature name="f145" type="cross_by_grams_seg" source=".user_feature.query_feature.query,.item_feature.item_id.app_id" jieba_dict_path="jiebaDictUtf8Dict" hmm_model_path="jiebaHmmModelUtf8Dict" user_dict_path="jiebaUserDictUtf8Dict" length="1" start="0" size="5" dtype="int64" dict="map_dict" strategy="empty" />
            <feature name="f146" type="is_match_str" source="user_am_clk.app_id" default_value="test_no_data" strategy="empty" />
            <feature name="f147" type="seq_day_n_direct" source=".user_feature.game_user_online_feature.game_user_behavior_seq_feature.game_user_click_sequence_30d,.request_time" eventtime_key="event_time" fields="udid,data_source" start="5" day_n="7" clip_size="3" strategy="empty,feature" />
            <feature name="f148" type="direct" source="f147:0" strategy="empty,string" />
            <feature name="f149" type="direct" source="f147:1" strategy="empty,int64" />
            <feature name="f150" type="utf8_get_prefix" source=".item_feature.item_feature_se.context.feature.app_id" max_size="10" strategy="empty" />
            <feature name="f151" type="utf8_get_re_result" source=".item_feature.item_feature_se.context.feature.app_id" strategy="empty" />
        </features>
    </config>

    <item_map path="appInfoUtf8Dict" />
    <app_info path="appInfoMinorDict" />
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f0" shape="1,1,3" type="sequence" />
        <input name="f1" shape="1,2,3" type="sequence" />
        <input name="f2" shape="1,1,3" type="sequence" />
        <input name="f3" shape="1,1,3" type="sequence" />
        <input name="f4" shape="2" type="sparse" />
        <input name="f6" shape="1,1,3" type="sequence" />
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1" type="sparse" />
        <input name="f11" shape="1" type="sparse" />
        <input name="f12" shape="1" type="sparse" />
        <input name="f13" shape="1" type="sparse" />
        <input name="f14" shape="1" type="sparse" />
        <input name="f15" shape="2" type="sparse" />
        <input name="f17" shape="2" type="sparse" />
        <input name="f18" shape="2" type="sparse" />
        <input name="f20" shape="2" type="sparse" />
        <input name="f21" shape="2" type="sparse" />
        <input name="f22" shape="2" type="sparse" />
        <input name="f24" shape="2" type="sparse" />
        <input name="f25" shape="2" type="sparse" />
        <input name="f26" shape="2" type="sparse" />
        <input name="f27" shape="2" type="sparse" />
        <input name="f28" shape="2" type="sparse" />
        <input name="f29" shape="2" type="sparse" />
        <input name="f30" shape="2" type="sparse" />
        <input name="f31" shape="1,1,3" type="sequence" />
        <input name="f32" shape="4" type="sparse" />
        <input name="f33" shape="1" type="sparse" />
        <input name="f34" shape="5" type="sparse" />
        <input name="f35" shape="2" type="sparse" />
        <input name="f36" shape="1,1,3" type="sequence" />
        <input name="f37" shape="1,1,3" type="sequence" />
        <input name="f38" shape="1,1,3" type="sequence" />
        <input name="f39" shape="2" type="sparse" />
        <input name="f40" shape="2" type="sparse" />
        <input name="f41" shape="2" type="sparse" />
        <input name="f42" shape="5" type="sparse" />
        <input name="f43" shape="5" type="sparse" />
        <input name="f44" shape="5" type="sparse" />
        <input name="f45" shape="1" type="sparse" />
        <input name="f46" shape="1,1,3" type="sequence" />
        <input name="f47" shape="1" type="sparse" />
        <input name="f48" shape="1,1,3" type="sequence" />
        <input name="f49" shape="1,1,3" type="sequence" />
        <input name="f50" shape="2" type="sparse" />
        <input name="f51" shape="1,1,3" type="sequence" />
        <input name="f53" shape="1,1,3" type="sequence" />
        <input name="f54" shape="1,1,3" type="sequence" />
        <input name="f55" shape="1,1,3" type="sequence" />
        <input name="f56" shape="1,3,3" type="sequence" />
        <input name="f58" shape="1,1,3" type="sequence" />
        <input name="f59" shape="1,1,3" type="sequence" />
        <input name="f60" shape="1" type="sparse" />
        <input name="f61" shape="1" type="sparse" />
        <input name="f62" shape="1" type="sparse" />
        <input name="f63" shape="1" type="sparse" />
        <input name="f64" shape="1" type="sparse" />
        <input name="f65" shape="1" type="sparse" />
        <input name="f66" shape="1" type="sparse" />
        <input name="f67" shape="1" type="sparse" />
        <input name="f68" shape="1" type="sparse" />
        <input name="f69" shape="1" type="sparse" />
        <input name="f70" shape="1" type="sparse" />
        <input name="f71" shape="1" type="sparse" />
        <input name="f72" shape="1" type="sparse" />
        <input name="f74" shape="1,1,3" type="sequence" />
        <input name="f75" shape="1,1,3" type="sequence" />
        <input name="f76" shape="1" type="sparse" />
        <input name="f77" shape="1" type="sparse" />
        <input name="f78" shape="1" type="sparse" />
        <input name="f80" shape="1,1,3" type="sequence" />
        <input name="f81" shape="1,1,3" type="sequence" />
        <input name="f82" shape="1,1,3" type="sequence" />
        <input name="f83" shape="1" type="sparse" />
        <input name="f84" shape="1" type="sparse" />
        <input name="f85" shape="1" type="sparse" />
        <input name="f86" shape="1" type="sparse" />
        <input name="f87" shape="1" type="sparse" />
        <input name="f89" shape="1" type="sparse" />
        <input name="f90" shape="1" type="sparse" />
        <input name="f91" shape="1,1,3" type="sequence" />
        <input name="f92" shape="1" type="sparse" />
        <input name="f93" shape="1" type="sparse" />
        <input name="f95" shape="1,1,3" type="sequence" />
        <input name="f96" shape="1,1,3" type="sequence" />
        <input name="f97" shape="1,1,3" type="sequence" />
        <input name="f99" shape="1,1,3" type="sequence" />
        <input name="f100" shape="1,1,3" type="sequence" />
        <input name="f101" shape="1,1,3" type="sequence" />
        <input name="f103" shape="1,1,3" type="sequence" />
        <input name="f104" shape="1,1,3" type="sequence" />
        <input name="f105" shape="1,1,3" type="sequence" />
        <input name="f106" shape="1,1,3" type="sequence" />
        <input name="f107" shape="1,1,3" type="sequence" />
        <input name="f108" shape="1" type="sparse" />
        <input name="f111" shape="1" type="sparse" />
        <input name="f112" shape="1" type="sparse" />
        <input name="f113" shape="1,1,3" type="sequence" />
        <input name="f115" shape="1" type="sparse" />
        <input name="f116" shape="1" type="sparse" />
        <input name="f117" shape="1" type="sparse" />
        <input name="f118" shape="1" type="sparse" />
        <input name="f119" shape="1" type="sparse" />
        <input name="f121" shape="1,1,3" type="sequence" />
        <input name="f122" shape="1,1,3" type="sequence" />
        <input name="f124" shape="1,1,3" type="sequence" />
        <input name="f125" shape="1" type="sparse" />
        <input name="f126" shape="1" type="sparse" />
        <input name="f127" shape="1" type="sparse" />
        <input name="f128" shape="1" type="sparse" />
        <input name="f129" shape="1" type="sparse" />
        <input name="f130" shape="1" type="sparse" />
        <input name="f131" shape="1,1,3" type="sequence" />
        <input name="f132" shape="1,1,3" type="sequence" />
        <input name="f133" shape="1,1,3" type="sequence" />
        <input name="f134" shape="1" type="sparse" />
        <input name="f135" shape="1,1,3" type="sequence" />
        <input name="f136" shape="1,1,3" type="sequence" />
        <input name="f137" shape="1,1,3" type="sequence" />
        <input name="f138" shape="1,1,3" type="sequence" />
        <input name="f139" shape="1,1,3" type="sequence" />
        <input name="f140" shape="1,1,3" type="sequence" />
        <input name="f141" shape="1,1,3" type="sequence" />
        <input name="f142" shape="1,1,3" type="sequence" />
        <input name="f143" shape="1,1,3" type="sequence" />
        <input name="f144" shape="1,1,3" type="sequence" />
        <input name="f145" shape="1" type="sparse" />
        <input name="f146" shape="1,1,5" type="sequence" />
        <input name="f148" shape="1" type="sparse" />
        <input name="f149" shape="1" type="sparse" />
        <input name="f150" shape="1" type="sparse" />
        <input name="f151" shape="1" type="sparse" />
    </model_input_config>
  )";

  if (argc < 3) {
    std::cout << "Usage: " << argv[0] << " <dict_path> <fe_request_dir>" << std::endl;
    return -1;
  }

  const char* dict_path = argv[1];
  const char* fe_request_dir = argv[2];

  predict_request_from_dir(config_str, in_str, dict_path, fe_request_dir);

  return 0;
}