#include "phx-fe/src/framework.h"
#include "phx-fe/src/service.h"
#include "phx_test.h"
#include <cstdint>
#include <iostream>

TEST_SUITE("plus") {
    // user特征，repeated==2，输入pb的尾端是基础类型
    TEST_CASE("test_framework_z1") {
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // 用户特征
        phx::InfoFlowItem *info_flow_item =
                fe_request.mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->add_filter_words()->set_id("001");
        info_flow_item->add_filter_words()->set_id("");

        info_flow_item = fe_request.mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->add_filter_words();
        // item特征
        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(666);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(38438);

        // mocker::FillProto(fe_request);
        std::string user_source_input{".fe_request.context.info_flow_context.info_flow_item.filter_words.id"};
        Input user_input{user_source_input, {}, "30001"};
        Output user_output{};
        user_output.arena = &arena;
        phx::UserAction ua{};

        GenerateOutputFromRequest(fe_request, ua, user_input, user_output);

        int batch_index = 0;
        for (const auto &one_batch_value: user_output.values) {

            for (const auto &ifeature: one_batch_value.ifeatures) {
                if (ifeature.feature != nullptr) {
                    std::cout << "batch_index = [" << batch_index << "]; feature = " << ifeature.feature->DebugString()
                              << std::endl;
                } else if (ifeature.feature_list != nullptr) {
                    std::cout << "batch_index = [" << batch_index
                              << "]; feature_list = " << ifeature.feature_list->DebugString() << std::endl;
                } else {
                    std::cout << "batch_index = [" << batch_index << "]; ifeature is empty!" << std::endl;
                }
                batch_index++;
            }
        }
        // 验证values只有1个
        REQUIRE_EQ(user_output.values.size(), 1);
        // 验证ifeatures只有1个
        REQUIRE_EQ(user_output.values[0].ifeatures.size(), 1);
        // 验证feature_list存在
        REQUIRE_NE(user_output.values[0].ifeatures[0].feature_list, nullptr);
        // 验证feature不存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature, nullptr);
        // 验证feature_list的size
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list->feature_size(), 2);
        // 验证数据是否正确
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list->feature(0).bytes_list().value(0), "001");
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list->feature(0).bytes_list().value(1), "");
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list->feature(1).bytes_list().value(0), "");
    }

    TEST_CASE("seq_diff_daily_z1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_daily" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time" start="864000" day_n="30" delta_day="10" status="0" clip_size="2" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_diff_daily" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time" start="864000" day_n="30" delta_day="10" status="1" clip_size="2" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        //防穿越
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 102 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 86 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //活跃
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //长度截断
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 81 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 83 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //时间范围过滤
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);

        pb_use = fe_request.mutable_ad_user_app_seq_update_offline();

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 98 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 82 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10004}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 86 * 86400 * 1000, (int64_t) 83 * 86400 * 1000}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10002}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 84 * 86400 * 1000}), ret.training_samples(0).features(3));
    }

    // user特征，repeated==2，输入pb的尾端是message
    TEST_CASE("test_framework_z2") {
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // 用户特征
        phx::InfoFlowItem *info_flow_item =
                fe_request.mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->add_filter_words()->set_id("001");
        info_flow_item->add_filter_words()->set_id("");

        info_flow_item = fe_request.mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->add_filter_words();
        // item特征
        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(666);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(38438);

        // mocker::FillProto(fe_request);
        std::string user_source_input{".fe_request.context.info_flow_context.info_flow_item.filter_words"};
        Input user_input{user_source_input, {}, "30001"};
        Output user_output{};
        user_output.arena = &arena;
        phx::UserAction ua{};

        GenerateOutputFromRequest(fe_request, ua, user_input, user_output);

        // 验证values只有1个
        REQUIRE_EQ(user_output.values.size(), 1);
        // 验证ifeatures只有1个
        REQUIRE_EQ(user_output.values[0].ifeatures.size(), 1);
        // 验证feature_list不存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list, nullptr);
        // 验证feature不存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature, nullptr);
        // 验证message的size
        REQUIRE_EQ(user_output.values[0].ifeatures[0].messages.size(), 3);
        // 验证数据是否正确
        REQUIRE_EQ(user_output.values[0].ifeatures[0].messages[0],
                   (google::protobuf::Message *) fe_request.mutable_context()
                           ->mutable_info_flow_context()
                           ->mutable_info_flow_item(0)
                           ->mutable_filter_words(0));
        REQUIRE_EQ(user_output.values[0].ifeatures[0].messages[1],
                   (google::protobuf::Message *) fe_request.mutable_context()
                           ->mutable_info_flow_context()
                           ->mutable_info_flow_item(0)
                           ->mutable_filter_words(1));
        REQUIRE_EQ(user_output.values[0].ifeatures[0].messages[2],
                   (google::protobuf::Message *) fe_request.mutable_context()
                           ->mutable_info_flow_context()
                           ->mutable_info_flow_item(1)
                           ->mutable_filter_words(0));
    }

    // user特征，repeated==0，输入pb的尾端是基础类型
    TEST_CASE("test_framework_z3") {
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // 用户特征
        phx::AppInfo *ad_info = fe_request.add_app_fea()->mutable_ad_info();
        ad_info->set_app_id(1);

        ad_info = fe_request.add_app_fea()->mutable_ad_info();

        // mocker::FillProto(fe_request);
        std::string user_source_input{".fe_request.app_fea.ad_info.app_id"};
        Input user_input{user_source_input, {}, "30001"};
        Output user_output{};
        user_output.arena = &arena;
        phx::UserAction ua{};

        GenerateOutputFromRequest(fe_request, ua, user_input, user_output);

        // 验证values只有1个
        REQUIRE_EQ(user_output.values.size(), 1);
        // 验证ifeatures只有1个
        REQUIRE_EQ(user_output.values[0].ifeatures.size(), 2);
        // 验证feature_list不存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list, nullptr);
        // 验证feature存在
        REQUIRE_NE(user_output.values[0].ifeatures[0].feature, nullptr);
        // 验证数据是否正确
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(0), 1);
        REQUIRE_EQ(user_output.values[0].ifeatures[1].feature->int64_list().value(0), 0);
    }

    // user特征，repeated==0，输入pb的尾端是message
    TEST_CASE("test_framework_z4") {
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // 用户特征
        phx::AppInfo *ad_info = fe_request.add_app_fea()->mutable_ad_info();
        ad_info->set_app_id(1);

        ad_info = fe_request.add_app_fea()->mutable_ad_info();

        // mocker::FillProto(fe_request);
        std::string user_source_input{".fe_request.app_fea.ad_info"};
        Input user_input{user_source_input, {}, "30001"};
        Output user_output{};
        user_output.arena = &arena;
        phx::UserAction ua{};

        GenerateOutputFromRequest(fe_request, ua, user_input, user_output);

        // 验证values只有1个
        REQUIRE_EQ(user_output.values.size(), 1);
        // 验证ifeatures只有1个
        REQUIRE_EQ(user_output.values[0].ifeatures.size(), 2);
        // 验证feature_list不存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list, nullptr);
        // 验证feature不存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature, nullptr);
        // 验证数据是否正确
        REQUIRE_EQ(user_output.values[0].ifeatures[0].messages[0],
                   (google::protobuf::Message *) fe_request.mutable_app_fea(0)->mutable_ad_info());
        REQUIRE_EQ(user_output.values[0].ifeatures[1].messages[0],
                   (google::protobuf::Message *) fe_request.mutable_app_fea(1)->mutable_ad_info());
    }

    // user特征，repeated==1，输入pb的尾端是基础类型
    TEST_CASE("test_framework_z5") {
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // 用户特征
        phx::InfoFlowContext *info_flow_context = fe_request.mutable_context()->mutable_info_flow_context();
        info_flow_context->add_info_flow_item()->set_tip("001");
        info_flow_context->add_info_flow_item()->set_tip("");

        // item特征
        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(666);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(38438);

        // mocker::FillProto(fe_request);
        std::string user_source_input{".fe_request.context.info_flow_context.info_flow_item.tip"};
        Input user_input{user_source_input, {}, "30001"};
        Output user_output{};
        user_output.arena = &arena;
        phx::UserAction ua{};

        GenerateOutputFromRequest(fe_request, ua, user_input, user_output);

        // 验证values只有1个
        REQUIRE_EQ(user_output.values.size(), 1);
        // 验证ifeatures只有1个
        REQUIRE_EQ(user_output.values[0].ifeatures.size(), 1);
        // 验证feature_list存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list, nullptr);
        // 验证feature不存在
        REQUIRE_NE(user_output.values[0].ifeatures[0].feature, nullptr);
        // 验证feature_list的size
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature->bytes_list().value_size(), 2);
        // 验证数据是否正确
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature->bytes_list().value(0), "001");
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature->bytes_list().value(1), "");
    }

    // user_action的user特征，repeated==0，输入pb的尾端是基础类型
    TEST_CASE("test_framework_z6") {
        google::protobuf::Arena arena;
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        // 用户特征
        user_action.set_request_id("001");
        user_action.set_media_id(2388564);

        // item特征
        auto *user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_ad_group_id(856654);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_api_lahuo_conversion_rate(3.2654);

        // mocker::FillProto(fe_request);
        std::string user_source_input{".user_action.request_id"};
        Input user_input{user_source_input, {}, "30001"};
        Output user_output{};
        user_output.arena = &arena;
        phx::FeRequest fe_request{};

        GenerateOutputFromRequest(fe_request, user_action, user_input, user_output);

        // 验证values只有1个
        REQUIRE_EQ(user_output.values.size(), 1);
        // 验证ifeatures只有1个
        REQUIRE_EQ(user_output.values[0].ifeatures.size(), 1);
        // 验证feature_list不存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list, nullptr);
        // 验证feature存在
        REQUIRE_NE(user_output.values[0].ifeatures[0].feature, nullptr);
        // 验证feature的size
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature->bytes_list().value_size(), 1);
        // 验证数据是否正确
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature->bytes_list().value(0), "001");
    }

    // user_action的item特征，repeated==0，输入pb的尾端是基础类型
    TEST_CASE("test_framework_z7") {
        google::protobuf::Arena arena;
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        // 用户特征
        user_action.set_request_id("001");
        user_action.set_media_id(2388564);

        // item特征
        auto *user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_ad_group_id(856654);
        user_action_item_info->set_api_lahuo_conversion_rate(6.2654);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_api_lahuo_conversion_rate(3.2654);

        // mocker::FillProto(fe_request);
        std::string user_source_input{".user_action.user_action_item_info.api_lahuo_conversion_rate"};
        Input user_input{user_source_input, {}, "30001"};
        Output user_output{};
        user_output.arena = &arena;
        phx::FeRequest fe_request{};

        GenerateOutputFromRequest(fe_request, user_action, user_input, user_output);

        // 验证values只有1个
        REQUIRE_EQ(user_output.values.size(), 1);
        // 验证ifeatures只有1个
        REQUIRE_EQ(user_output.values[0].ifeatures.size(), 2);
        // 验证feature_list不存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list, nullptr);
        // 验证feature不存在
        REQUIRE_NE(user_output.values[0].ifeatures[0].feature, nullptr);
        // 验证feature个数
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature->float_list().value_size(), 1);
        // 验证数据
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature->float_list().value(0), (float) 6.2654);
        REQUIRE_EQ(user_output.values[0].ifeatures[1].feature->float_list().value(0), (float) 3.2654);
    }

    // user_action的item特征，repeated==1，输入pb的尾端是基础类型，只有1个item赋值
    TEST_CASE("test_framework_z8") {
        google::protobuf::Arena arena;
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        // 用户特征
        user_action.set_request_id("001");
        user_action.set_media_id(2388564);

        // item特征
        auto *user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_ad_group_id(856654);
        user_action_item_info->set_api_lahuo_conversion_rate(6.2654);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_api_lahuo_conversion_rate(3.2654);

        // mocker::FillProto(fe_request);
        std::string user_source_input{".user_action.user_action_item_info.ad_group_id"};
        Input user_input{user_source_input, {}, "30001"};
        Output user_output{};
        user_output.arena = &arena;
        phx::FeRequest fe_request{};

        GenerateOutputFromRequest(fe_request, user_action, user_input, user_output);

        // 验证values只有1个
        REQUIRE_EQ(user_output.values.size(), 1);
        // 验证ifeatures只有1个
        REQUIRE_EQ(user_output.values[0].ifeatures.size(), 2);
        // 验证feature_list不存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list, nullptr);
        // 验证feature不存在
        REQUIRE_NE(user_output.values[0].ifeatures[0].feature, nullptr);
        // 验证feature个数
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value_size(), 1);
        // 验证数据
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(0), (int64_t) 856654);
        REQUIRE_EQ(user_output.values[0].ifeatures[1].feature->int64_list().value(0), (int64_t) 0);
    }

    // user_action的item特征，repeated==1，输入pb的尾端不是基础类型
    TEST_CASE("test_framework_z9") {
        google::protobuf::Arena arena;
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        // 用户特征
        user_action.set_request_id("001");
        user_action.set_media_id(2388564);

        // item特征
        auto *user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_ad_group_id(856654);
        user_action_item_info->set_api_lahuo_conversion_rate(6.2654);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_api_lahuo_conversion_rate(3.2654);

        // mocker::FillProto(fe_request);
        std::string user_source_input{".user_action.user_action_item_info"};
        Input user_input{user_source_input, {}, "30001"};
        Output user_output{};
        user_output.arena = &arena;
        phx::FeRequest fe_request{};

        GenerateOutputFromRequest(fe_request, user_action, user_input, user_output);

        // 验证values只有1个
        REQUIRE_EQ(user_output.values.size(), 1);
        // 验证ifeatures只有1个
        REQUIRE_EQ(user_output.values[0].ifeatures.size(), 2);
        // 验证feature_list不存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature_list, nullptr);
        // 验证feature不存在
        REQUIRE_EQ(user_output.values[0].ifeatures[0].feature, nullptr);
        // 验证数据
        REQUIRE_EQ(user_output.values[0].ifeatures[0].messages[0],
                   (google::protobuf::Message *) user_action.mutable_user_action_item_info(0));
        REQUIRE_EQ(user_output.values[0].ifeatures[1].messages[0],
                   (google::protobuf::Message *) user_action.mutable_user_action_item_info(1));
    }

    // 配置start，防穿越取开区间，两次抽取第二次输入空
    TEST_CASE("test_seq_hit_interval_z1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 100 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 3);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({-1}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({20 * 86400}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({70 * 86400}), ret.training_samples(2).features(0));

        fe_request->clear_ad_user_app_seq_expose_offline();
        const auto fe_request_str2 = fe_request->SerializeAsString();
        const auto ret_str2 = to_training_sample_v2(fe_request_str2.c_str(), fe_request_str2.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret2;
        ret2.ParseFromString(ret_str2);
        CHECK_EQ(ret2.training_samples_size(), 3);

        CHECK_EQ(ret2.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret2.training_samples(0).features(0));

        CHECK_EQ(ret2.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret2.training_samples(1).features(0));

        CHECK_EQ(ret2.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret2.training_samples(2).features(0));
    }

    // 配置start，appid=10000的eventTime有2个，1个触发防穿越被过滤，1个正常输出
    TEST_CASE("test_seq_hit_interval_z2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 99 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 3);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({11 * 86400}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({20 * 86400}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({70 * 86400}), ret.training_samples(2).features(0));
    }

    // 配置default_value
    TEST_CASE("test_seq_hit_interval_z3") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        default_value="666"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 100 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 3);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({666}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({20 * 86400}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({70 * 86400}), ret.training_samples(2).features(0));
    }

    // 配置default_input_int64="1000"，使用默认值填充输入
    // 遗留问题1：item特征未赋值，但是还是会被给予默认值，如何能够控制不赋默认值->6.30暂时遗留
    TEST_CASE("test_seq_hit_interval_z4") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source="E@.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,E@.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,E@.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        default_value="666"
                        default_input_int64="1000"
                        strategy="empty"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();

        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(0);
        ad_user_app_info->set_event_time((int64_t) 99 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 3);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({110 * 86400 - 1}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({20 * 86400}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({70 * 86400}), ret.training_samples(2).features(0));
    }

    // 配置default_value="666"，允许输出为空，输入不为空输出为空
    TEST_CASE("test_seq_hit_interval_z5") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source="E@.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,E@.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,E@.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        default_value="666"
                        strategy="empty"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10003);
        ad_user_app_info->set_event_time((int64_t) 99 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 3);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({666}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({20 * 86400}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({70 * 86400}), ret.training_samples(2).features(0));
    }

    // 输入都被防穿越过滤，结果输出不为空
    TEST_CASE("test_seq_hit_interval_z6") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        default_value="688"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 120 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 130 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 140 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 240 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 300 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 3);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({688}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({688}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({688}), ret.training_samples(2).features(0));
    }

    // 输入的部分字段未赋值
    TEST_CASE("test_seq_hit_interval_z6") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source="E@.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,E@.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,E@.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        default_value="666"
                        
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10003);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 3);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({110 * 86400}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({20 * 86400}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({70 * 86400}), ret.training_samples(2).features(0));
    }

    // 部分appid赋值，其他为空，空的appid对应的输出为默认值
    TEST_CASE("test_seq_hit_interval_z7") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        default_value="-2"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 3);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({(int64_t) -2}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({(int64_t) 1728000}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({(int64_t) -2}), ret.training_samples(2).features(0));
    }

    // 使用not_empty策略，输出为默认值
    // 遗留问题2：报错->6.30修改->已解决
    TEST_CASE("test_seq_hit_sum_z1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_sum"
                        source=".fe_request.req_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,E@.fe_request.item_fea.item_info.appid"
                        start="864000"
                        default_value="688"
                        default_type="int64"
                        strategy="not_empty"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        auto *ad_user_ads_stats_seq_appstore_neg_appid = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid();

        // item
        auto *item_fea = fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(ret.training_samples_size(), 1);
        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({688}), ret.training_samples(0).features(0));
        // 第二次抽取
        const auto ret_str2 = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret2;
        ret2.ParseFromString(ret_str2);

        REQUIRE_EQ(ret2.training_samples_size(), 1);
        CHECK_EQ(ret2.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({688}), ret2.training_samples(0).features(0));
    }

    // float默认值
    TEST_CASE("test_seq_hit_sum_z2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_sum"
                        source=".fe_request.req_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,E@.fe_request.item_fea.item_info.appid"
                        start="864000"
                        default_value="6.88"
                        default_type="float"
                        strategy="not_empty"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        auto *ad_user_ads_stats_seq_appstore_neg_appid = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid();

        // item
        auto *item_fea = fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(ret.training_samples_size(), 1);
        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({6.88}), ret.training_samples(0).features(0));
    }

    // 允许为空，但是配置了default_type，不影响结果为空
    TEST_CASE("test_seq_hit_sum_z3") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_sum"
                        source=".fe_request.req_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,E@.fe_request.item_fea.item_info.appid"
                        start="864000"
                        default_value="6.88"
                        default_type="float"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        auto *ad_user_ads_stats_seq_appstore_neg_appid = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid();

        // item
        auto *item_fea = fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(ret.training_samples_size(), 1);
        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(0).features(0));
    }

    // appid部分为空，其他赋值，两次抽取第二次为空
    TEST_CASE("test_seq_hit_sum_z4") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_sum"
                        source=".fe_request.req_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAdsStatsInfo *user_ads_stats_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time((int64_t) 70 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.2);
        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// start过滤

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(ret.training_samples_size(), 4);
        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({0.2}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({-1}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({-1}), ret.training_samples(2).features(0));

        CHECK_EQ(ret.training_samples(3).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({-1}), ret.training_samples(3).features(0));

        fe_request->clear_ad_user_ads_stats_seq_appstore_neg_appid();
        const auto fe_request_str2 = fe_request->SerializeAsString();
        const auto ret_str2 = to_training_sample_v2(fe_request_str2.c_str(), fe_request_str2.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);
        
        phx::BatchTrainingSample ret2;
        ret2.ParseFromString(ret_str2);
        REQUIRE_EQ(ret2.training_samples_size(), 4);
        CHECK_EQ(ret2.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({}), ret2.training_samples(0).features(0));

        CHECK_EQ(ret2.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({}), ret2.training_samples(1).features(0));

        CHECK_EQ(ret2.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({}), ret2.training_samples(2).features(0));

        CHECK_EQ(ret2.training_samples(3).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({}), ret2.training_samples(3).features(0));

    }

    // 全部被防穿越过滤，结果赋默认值
    TEST_CASE("test_seq_hit_sum_z5") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_sum"
                        source=".fe_request.req_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,E@.fe_request.item_fea.item_info.appid"
                        start="864000"
                        default_value="688"
                        default_type="float"
                        strategy="not_empty"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAdsStatsInfo *user_ads_stats_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time((int64_t) 120 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.2);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(ret.training_samples_size(), 1);
        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({688}), ret.training_samples(0).features(0));
    }

    // 使用不存在的key查询，结果输出默认值
    // 遗留问题3：output_fields="package_name, third_class_id"配置会报错->6.30沟通不属于问题
    // 遗留问题4：字段为repeated时，且为空时，不填充，输出为空列表，没理解什么意思->6.30沟通，开发补充该用例
    TEST_CASE("test_query_dict_z1") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="app_info" value="10820,10821" />
        </versions>
        <config>
            <dict name="app_info"
                path="dict_test_data/appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
             />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
                />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10810"
                    type="query_dict"
                    dict_name="app_info"
                    output_fields="package_name,third_class_id"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    default_int64_value="688"
                    default_float_value="-1.11f"
                    default_string_value="no_value" />
                <feature name = "10820"
                    slot="10820"
                    type="direct_to_feature"
                    source="10810:0"
                    />
                <feature name = "10821"
                    slot="10821"
                    type="direct_to_feature"
                    source="10810:1"
                    />
            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::vector<hidict::DictConfig> hidict_configs{};
        for (const auto &conf: ret) {
            hidict::DictConfig hidict_config{};
            hidict_config.m_path = conf.path;
            hidict_config.m_name = conf.path;
            hidict_config.m_clazz = conf.class_name;
            hidict_configs.emplace_back(hidict_config);
        }
        AdDict::AdDictCollectorInstance::instance().init("zmw", hidict_configs, false);
        hidict_configs.clear();
        for (const auto &conf: ret) {
            hidict::DictConfig hidict_config{};
            hidict_config.m_path = conf.path;
            hidict_config.m_name = conf.name;
            hidict_config.m_clazz = conf.class_name;
            hidict_configs.emplace_back(hidict_config);
        }
        AdDict::AdDictCollector *dict_collector = new AdDict::AdDictCollector();
        long handle = reinterpret_cast<long>(dict_collector);
        if (!hidict_configs.empty()) {
            bool ret = dict_collector->init(std::to_string(handle), hidict_configs, false);
            if (!ret) {
                delete dict_collector;
                handle = 0;
            }
        }

        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(19980604);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(19980605);
        ad_user_app_info->set_count(20);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
        item_fea->mutable_item_info()->set_creative_id(1110);
        item_fea->mutable_item_info()->set_ocpx_sbp(2);
        item_fea->mutable_item_info()->set_data_source(7);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(8);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("236");
        item_fea->mutable_item_info()->set_creative_id(1112);
        item_fea->mutable_item_info()->set_ocpx_sbp(10);
        item_fea->mutable_item_info()->set_data_source(0);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);
        {
            for (const auto i: times(3)) {
                CHECK_EQ(training_sample.training_samples(i).features(0).slot_id(), 10820);
                TEST_FEATURE_STR(({"no_value", "no_value"}), training_sample.training_samples(i).features(0));
            }
        }
        {
            for (const auto i: times(3)) {
                CHECK_EQ(training_sample.training_samples(i).features(1).slot_id(), 10821);
                TEST_FEATURE_INT64(({688, 688}), training_sample.training_samples(i).features(1));
            }
        }
    }

    // 查询重复的field
    // 20250724：由于更换词典模块以及适配新接口，该用例fail，暂时跳过
    TEST_CASE("test_query_dict_z2" * doctest::skip()) {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="app_info" value="10820,10821,10822,10823" />
        </versions>
        <config>
            <dict name="app_info"
                path="dict_test_data/appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
             />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
                />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10810"
                    type="query_dict"
                    dict_name="app_info"
                    output_fields="first_class,first_class,third_class_id,first_class"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    default_int64_value="688"
                    default_float_value="-1.11f"
                    default_string_value="no_value" />
                <feature name = "10820"
                    slot="10820"
                    type="direct_to_feature"
                    source="10810:0"
                    />
                <feature name = "10821"
                    slot="10821"
                    type="direct_to_feature"
                    source="10810:1"
                    />
                <feature name = "10822"
                    slot="10822"
                    type="direct_to_feature"
                    source="10810:2"
                    />
                <feature name = "10823"
                    slot="10823"
                    type="direct_to_feature"
                    source="10810:3"
                    />
            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1113);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1114);
        ad_user_app_info->set_count(20);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
        item_fea->mutable_item_info()->set_creative_id(1110);
        item_fea->mutable_item_info()->set_ocpx_sbp(2);
        item_fea->mutable_item_info()->set_data_source(7);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(8);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("236");
        item_fea->mutable_item_info()->set_creative_id(1112);
        item_fea->mutable_item_info()->set_ocpx_sbp(10);
        item_fea->mutable_item_info()->set_data_source(0);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        {
            for (const auto i: times(3)) {
                CHECK_EQ(training_sample.training_samples(i).features(0).slot_id(), 10820);
                TEST_FEATURE_STR(({"即时通讯", "即时通讯"}), training_sample.training_samples(i).features(0));
            }
        }
        {
            for (const auto i: times(3)) {
                CHECK_EQ(training_sample.training_samples(i).features(1).slot_id(), 10821);
                TEST_FEATURE_STR(({"即时通讯", "即时通讯"}), training_sample.training_samples(i).features(1));
            }
        }
        {
            for (const auto i: times(3)) {
                CHECK_EQ(training_sample.training_samples(i).features(2).slot_id(), 10822);
                // TEST_FEATURE_INT64(({688, 688}), training_sample.training_samples(i).features(2));
                TEST_FEATURE_INT64(({688, 688}), training_sample.training_samples(i).features(2));
            }
        }
        {
            for (const auto i: times(3)) {
                CHECK_EQ(training_sample.training_samples(i).features(3).slot_id(), 10823);
                TEST_FEATURE_STR(({"即时通讯", "即时通讯"}), training_sample.training_samples(i).features(3));
            }
        }
    }

    // 用于mock字典数据的函数
    void mock_appinfo(int count, const std::string &path) {
        mkdir(path.c_str(), 0755);
        std::ofstream outfile(path + "/appinfo.txt", std::ios_base::out);
        for (int i = 0; i < count; i++) {
            phx::AppInfoDict appinfo_dict;
            appinfo_dict.set_app_id(111 * 10 + i);
            appinfo_dict.set_package_name("com.wx.mm");
            appinfo_dict.set_app_name("微信");
            if (i % 3 == 0) {
                appinfo_dict.set_first_class("即时通讯3");
                appinfo_dict.set_second_class("聊天3");
                appinfo_dict.set_third_class("交互3");
            } else if (i % 2 == 0) {
                appinfo_dict.set_first_class("即时通讯2");
                appinfo_dict.set_second_class("聊天2");
                appinfo_dict.set_third_class("交互2");
            } else {
                appinfo_dict.set_first_class("即时通讯");
                appinfo_dict.set_second_class("聊天");
                appinfo_dict.set_third_class("交互");
            }

            appinfo_dict.set_first_class_id(1000);
            appinfo_dict.set_second_class_id(2000);
            appinfo_dict.set_third_class_id(3000);
            appinfo_dict.set_appstore_first_class_id(11000);
            appinfo_dict.set_appstore_second_class_id(12000);
            appinfo_dict.set_appstore_third_class_id(12000);
            for (int t = 0; t < 5; t++) {
                appinfo_dict.add_app_tags()->assign("tag-" + std::to_string(i));
            }
            appinfo_dict.set_dev_name("荣耀");
            appinfo_dict.set_develop_id(333);
            appinfo_dict.set_in_app_product(1333);
            appinfo_dict.set_has_app_checked(1);
            appinfo_dict.set_has_ad(1);
            appinfo_dict.set_version_time_day_elapsed(0.86);
            appinfo_dict.set_stars(4);
            appinfo_dict.set_distribution_shape_five_star("绝世好App");
            std::string data_str;
            appinfo_dict.SerializeToString(&data_str);
            data_str = base64_encode(data_str);
            outfile << std::to_string(appinfo_dict.app_id()) << '\t' << data_str << std::endl;
        }
        outfile.flush();
        outfile.close();
        std::ofstream out_succss(path + "/SUCCESS");
    }

    // topn配置负数，抛出异常
    // 异常信息：ERROR: test case THREW exception: parse_xml_new_sample ./config_mgr/xml_config_mgr.h 459:create failed, config_type:seq_appcategory_topn, name:f12
    TEST_CASE("test_seq_category_top_n_z1" * doctest::skip()) {
        mock_appinfo(4, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_appcategory_topn"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    topn = "-2"
                    default_value="null" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1111);
        user_app_info->set_event_time(5 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1112);
        user_app_info->set_event_time(9 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1113);
        user_app_info->set_event_time(7 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1114);
        user_app_info->set_event_time(20 * 86400 * 1000);
        fe_request.set_req_time(10 * 86400 * 1000);
        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        //没有配置start，start默认为0，比request time小就合法
        //没有配置topn_type，按照event time排序
        //按event_time排序取top2，应该命中1112和1113对应的三级类目
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯", "即时通讯3"}), training_samples.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"聊天", "聊天3"}), training_samples.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"交互", "交互3"}), training_samples.training_samples(0).features(2));
    }

    // 使用不存在的key查字典，输出默认值
    TEST_CASE("test_seq_category_top_n_z2") {
        mock_appinfo(1, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_appcategory_topn"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    topn = "2"
                    default_value="null" 
                    strategy="not_empty" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(19980604);
        user_app_info->set_event_time(5 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(19980605);
        user_app_info->set_event_time(9 * 86400 * 1000);

        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        TEST_SLOT_FEATURE_STR(10001, ({"null"}), training_samples.training_samples(0).features(0))
        TEST_SLOT_FEATURE_STR(10002, ({"null"}), training_samples.training_samples(0).features(1))
        TEST_SLOT_FEATURE_STR(10003, ({"null"}), training_samples.training_samples(0).features(2))
    }

    // 查询到的字典数据不足以填充top的数量，有多少返回多少
    // 20250724：由于更换词典模块以及适配新接口，该用例fail，暂时跳过
    TEST_CASE("test_seq_category_top_n_z3" * doctest::skip()) {
        mock_appinfo(2, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_appcategory_topn"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    topn = "2"
                    default_value="null" 
                    strategy="not_empty" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1110);
        user_app_info->set_event_time(5 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(19980605);
        user_app_info->set_event_time(9 * 86400 * 1000);
        fe_request.set_req_time(10 * 86400 * 1000);

        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯3"}), training_samples.training_samples(0).features(0))
        TEST_SLOT_FEATURE_STR(10002, ({"聊天3"}), training_samples.training_samples(0).features(1))
        TEST_SLOT_FEATURE_STR(10003, ({"交互3"}), training_samples.training_samples(0).features(2))
    }

    // 按时间戳排序不去重
    // 20250724：由于更换词典模块以及适配新接口，该用例fail，暂时跳过
    TEST_CASE("test_seq_category_top_n_z4" * doctest::skip()) {
        mock_appinfo(1, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_appcategory_topn"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    topn = "3"
                    default_value="null" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1110);
        user_app_info->set_event_time(5 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1110);
        user_app_info->set_event_time(5 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1110);
        user_app_info->set_event_time(5 * 86400 * 1000);

        fe_request.set_req_time(10 * 86400 * 1000);
        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯3", "即时通讯3", "即时通讯3"}),
                              training_samples.training_samples(0).features(0))
        TEST_SLOT_FEATURE_STR(10002, ({"聊天3", "聊天3", "聊天3"}), training_samples.training_samples(0).features(1))
        TEST_SLOT_FEATURE_STR(10003, ({"交互3", "交互3", "交互3"}), training_samples.training_samples(0).features(2))
    }

    // 开启去重，不配置截断，输入数据相同，最后输出1个
    // 20250724：由于更换词典模块以及适配新接口，该用例fail，暂时跳过
    TEST_CASE("test_seq_app2category_z1" * doctest::skip()) {
        mock_appinfo(1, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_app2category"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    dedup = "true"
                    start = "86400"
                    default_value="null" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1110);
        user_app_info->set_event_time(5 * 86400 * 1000 - 1);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1110);
        user_app_info->set_event_time(7 * 86400 * 1000);

        fe_request.set_req_time(10 * 86400 * 1000);

        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        std::cout << "seq_app2category_1 training_samples = " << training_samples.DebugString() << std::endl;
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯3"}), training_samples.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"聊天3"}), training_samples.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"交互3"}), training_samples.training_samples(0).features(2));
    }

    // 不开启去重，不配置截断，输入数据相同，最后输出多个
    // 20250724：由于更换词典模块以及适配新接口，该用例fail，暂时跳过
    TEST_CASE("test_seq_app2category_z2" * doctest::skip()) {
        mock_appinfo(1, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_app2category"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    dedup = "false"
                    start = "86400"
                    default_value="null" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1110);
        user_app_info->set_event_time(5 * 86400 * 1000 - 1);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1110);
        user_app_info->set_event_time(7 * 86400 * 1000);

        fe_request.set_req_time(10 * 86400 * 1000);

        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        std::cout << "seq_app2category_1 training_samples = " << training_samples.DebugString() << std::endl;
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯3", "即时通讯3"}), training_samples.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"聊天3", "聊天3"}), training_samples.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"交互3", "交互3"}), training_samples.training_samples(0).features(2));
    }

    // topn_type配置其他值，报异常
    // 异常信息：ERROR: test case THREW exception: parse_xml_new_sample ./config_mgr/xml_config_mgr.h 459:create failed, config_type:seq_topn_v2, name:10814
    TEST_CASE("test_seq_topn_v2_z1" * doctest::skip()) {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_expose" topn="1" topn_type="3" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_topn_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" topn="0" topn_type="6" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time(10);
        user_ads_stats_info->set_num_expose(1);
        user_ads_stats_info->set_dtr(1.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(20);
        user_ads_stats_info->set_num_expose(2);
        user_ads_stats_info->set_dtr(2.1);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10003);
        user_ads_stats_info->set_last_event_time(30);
        user_ads_stats_info->set_num_expose(0);
        user_ads_stats_info->set_dtr(0.6);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10003);
        user_ads_stats_info->set_last_event_time(40);
        user_ads_stats_info->set_num_expose(2);
        user_ads_stats_info->set_dtr(2.7);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({2}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10003, 10002, 10001}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_FLOAT(10816, ({3.3, 2.1, 1.0}), ret.training_samples(0).features(3));
    }

    // topn配置2，val和时间相同，根据输入顺序输出2个
    TEST_CASE("test_seq_topn_v2_z2") {
        std::string config_str = R"(
        <versions>
        <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
        </versions>
        <config>
            <features>
                <feature name="10811" slot="10811" type="seq_topn_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" topn="2" topn_type="3" />
                <feature name="10812" slot="10812" type="direct" source="10811:0" />
                <feature name="10813" slot="10813" type="direct" source="10811:1" />
            </features>
        </config>
      )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_name(10000);
        user_ads_stats_info->set_last_event_time(5 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.1);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time(5 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.1);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(5 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.1);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10001}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, ({0.1, 0.1}), ret.training_samples(0).features(1));
    }

    // val或时间输入空，使用默认值进行比较
    TEST_CASE("test_seq_topn_v2_z3") {
        std::string config_str = R"(
        <versions>
        <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
        </versions>
        <config>
            <features>
                <feature name="10811" slot="10811" type="seq_topn_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" topn="2" topn_type="3" />
                <feature name="10812" slot="10812" type="direct" source="10811:0" />
                <feature name="10813" slot="10813" type="direct" source="10811:1" />
            </features>
        </config>
      )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_name(10000);
        user_ads_stats_info->set_dtr(0.1);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time(5 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.1);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(5 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10000}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, ({0.1, 0.1}), ret.training_samples(0).features(1));
    }

    // 使用默认值，配置not_empty不生效
    // 遗留问题6：报错，未查出问题->已解决
    TEST_CASE("test_seq_diff_daily_z1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811_1" slot="10811" type="seq_diff_daily" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" />
                    <feature name="10812_1" slot="10812" type="direct" source="10811_1:0" />
                    <feature name="10813_1" slot="10813" type="direct" source="10811_1:1" />
                    <feature name="10814_1" slot="10811" type="seq_diff_daily" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" status="1" />
                    <feature name="10815_1" slot="10815" type="direct" source="10814_1:0" />
                    <feature name="10816_1" slot="10816" type="direct" source="10814_1:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_bid((int64_t) 90 * 86400 * 1000 + 1000);
        item_fea->mutable_item_info()->set_creative_id(10001);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 90 * 86400 * 1000 + 3600 * 12);

        // 活跃数据
        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea->mutable_item_info()->set_bid((int64_t) 85 * 86400 * 1000 + 1000);
        item_fea->mutable_item_info()->set_creative_id(10002);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 85 * 86400 * 1000);

        // 防穿越过滤
        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);
        item_fea->mutable_item_info()->set_bid((int64_t) 110 * 86400 * 1000);
        item_fea->mutable_item_info()->set_creative_id(10003);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 87 * 86400 * 1000 + 5 * 3600 * 1000);

        // 不活跃数据
        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10004);
        item_fea->mutable_item_info()->set_bid((int64_t) 100 * 86400 * 1000);
        item_fea->mutable_item_info()->set_creative_id(10004);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 102 * 86400 * 1000);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        CHECK_EQ(ret.training_samples_size(), 4);
        CHECK_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10001}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 90 * 86400 * 1000 + 1000}), ret.training_samples(0).features(3));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({10002}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 85 * 86400 * 1000 + 1000}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(1).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(1).features(3));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(2).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(2).features(3));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({10004}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 100 * 86400 * 1000}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(3).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(3).features(3));
    }

    // 输入传空，配置not_empty无影响，输出为空
    // 20250724：由于更换词典模块以及适配新接口，该用例fail，暂时跳过
    TEST_CASE("test_segment_z1" * doctest::skip()) {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="jieba" value="20001" />
            </versions>
            <config>
                <dict name="jieba"
                    path="dict_test_data/jieba_dict"
                    partition=""
                    value_proto=""
                    class_name="JieBaDict"
                 />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="20001"
                        type="segment"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id"
                        slot="20001"
                        dict_name="jieba" 
                         />
                </features>
            </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        CHECK_NE(handle, 0l);

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        // fe_request.mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id(
        //     "令狐冲是云计算行业的专家");
        auto item_fea = fe_request.add_item_fea();
        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        user_action.set_adunit_id(17088784918);
        user_action.set_algo_id("mock_algo_id");
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(700001);
        item_info->set_creative_id(60000001);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        TEST_FEATURE_STR(({}), training_sample.training_samples(0).features(0));
    }

    // 输入为空，输出为空；输入为空，输出为默认值
    TEST_CASE("test_seq_n_z1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_n" source="E@.fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,E@.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time" />
                    <feature name="10813" slot="10813" type="seq_n" source="E@.fe_request.ad_user_app_seq_use_offline.user_app_info.count,E@.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.req_time" default_value="988" strategy="not_empty"/>
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({988}), ret.training_samples(0).features(1));
    }

    // 结果过滤重复，clip_size传负数相当于不截断
    TEST_CASE("test_seq_n_z2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_n" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time" clip_size="-100" />
                    <feature name="10813" slot="10813" type="seq_n" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.req_time" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 11 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 11 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 9 * 86404 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 9 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10812, ({104435568}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({104435568}), ret.training_samples(0).features(1));
    }

    // 使用repeated的item特征，类型强制转换
    TEST_CASE("test_versions_z1") {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811"
                    labels="cvr_label_1,cvr_label_2"
                    weights="cvr_weights_1,cvr_weights_2"
                    extras_int64="ad_group_id"
                    extras_float="cvr_weights_1"
                    extras_bytes="req_id,rta_id"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            source=".fe_request.context.info_flow_context.info_flow_item.filter_words.id" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    source=".fe_request.context.info_flow_context.info_flow_item.filter_words.id" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        source=".fe_request.context.info_flow_context.info_flow_item.filter_words.id"
                    />
                <feature name="rta_id"
                    type="direct_to_feature" 
                        source="item_info.rta_id"
                    />
                <feature name="ad_group_id"
                    type="direct_to_feature" 
                        source=".fe_request.context.info_flow_context.info_flow_item.filter_words.id"
                    />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::InfoFlowItem *info_flow_item =
                fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->add_filter_words()->set_id("001");

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);

        fe_request->set_req_id("reqid0001");

        // extras_bytes
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features(0).signs_size(), 2);
        CHECK(ret.training_samples(0).features(0).signs(0) == 10001);
        CHECK(ret.training_samples(0).features(0).signs(1) == 10002);

        CHECK(ret.training_samples(0).labels().labels_size() == 2);
        CHECK(ret.training_samples(0).labels().labels(0) == 0);
        CHECK(ret.training_samples(0).labels().labels(1) == 0.12f);

        CHECK(ret.training_samples(0).weights().weights_size() == 2);
        CHECK(ret.training_samples(0).weights().weights(0) == 0);
        CHECK(ret.training_samples(0).weights().weights(1) == 0.14f);
        CHECK(ret.training_samples(0).extra().extra_int64_size() == 1);
        CHECK(ret.training_samples(0).extra().extra_int64(0) == 0);
        CHECK(ret.training_samples(0).extra().extra_float_size() == 1);
        CHECK(ret.training_samples(0).extra().extra_float(0) == 0);
        CHECK(ret.training_samples(0).extra().extra_bytes_size() == 2);
        CHECK(ret.training_samples(0).extra().extra_bytes(0) == "001");
        CHECK(ret.training_samples(0).extra().extra_bytes(1) == "rta_id_124");

        CHECK(ret.training_samples(1).features(0).signs_size() == 2);
        CHECK(ret.training_samples(1).features(0).signs(0) == 10001);
        CHECK(ret.training_samples(1).features(0).signs(1) == 10002);
        CHECK(ret.training_samples(1).labels().labels_size() == 2);
        CHECK(ret.training_samples(1).labels().labels(0) == 0);
        CHECK(ret.training_samples(1).labels().labels(1) == 0.22f);
        CHECK(ret.training_samples(1).weights().weights_size() == 2);
        CHECK(ret.training_samples(1).weights().weights(0) == 0);
        CHECK(ret.training_samples(1).weights().weights(1) == 0.24f);
        CHECK(ret.training_samples(1).extra().extra_int64_size() == 1);
        CHECK(ret.training_samples(1).extra().extra_int64(0) == 0);
        CHECK(ret.training_samples(1).extra().extra_float_size() == 1);
        CHECK(ret.training_samples(1).extra().extra_float(0) == 0);
        CHECK(ret.training_samples(1).extra().extra_bytes_size() == 2);
        CHECK(ret.training_samples(1).extra().extra_bytes(0) == "001");
        CHECK(ret.training_samples(1).extra().extra_bytes(1) == "rta_id_235");

        // std::cout << ret.DebugString() << std::endl;
    }

    // 输入的pb里包含非repeated字段，且该字段位于首部，不影响结果
    TEST_CASE("test_seq_coalesce_z1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_coalesce" source=".fe_request.req_id,.fe_request.ad_user_app_seq_all_first_use_offline.user_app_info,.fe_request.ad_user_app_seq_install_list_offline.user_app_info,.fe_request.ad_user_app_seq_install_list_realtime.user_app_info" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.count" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        fe_request.set_req_id("388");
        auto *realtime = fe_request.mutable_ad_user_app_seq_install_list_realtime();

        auto *user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(60);
        user_app_info->set_count(100);
        user_app_info->set_app_id(10001);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(120);
        user_app_info->set_count(200);
        user_app_info->set_app_id(10002);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(180);
        user_app_info->set_count(300);
        user_app_info->set_app_id(10003);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10002, 10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 120, 180}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 200, 300}), ret.training_samples(0).features(2));
    }

    // 输入的pb里包含非repeated字段，且该字段位于尾部，不影响结果
    TEST_CASE("test_seq_coalesce_z2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_coalesce" source=".fe_request.ad_user_app_seq_all_first_use_offline.user_app_info,.fe_request.ad_user_app_seq_install_list_offline.user_app_info,.fe_request.ad_user_app_seq_install_list_realtime.user_app_info,.fe_request.req_id" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.count" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        fe_request.set_req_id("388");
        auto *realtime = fe_request.mutable_ad_user_app_seq_install_list_realtime();

        auto *user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(60);
        user_app_info->set_count(100);
        user_app_info->set_app_id(10001);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(120);
        user_app_info->set_count(200);
        user_app_info->set_app_id(10002);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(180);
        user_app_info->set_count(300);
        user_app_info->set_app_id(10003);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10002, 10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 120, 180}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 200, 300}), ret.training_samples(0).features(2));
    }

    // start配置的值大于end
    // 遗留问题8：应该报错->7.2已解决
    // 报错信息：ERROR: test case THREW exception: parse_xml_new_sample ./config_mgr/xml_config_mgr.h 520:create failed, config_type:seq_pb_clip, name:10811
    TEST_CASE("test_seq_pb_clip_z1" * doctest::skip()) {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_pb_clip" source=".fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" eventtime_key="event_time" start_day="8" end_day = "6" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                </features>
            </config>
          )";
        auto config_handle =
                reinterpret_cast<long>(init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr"));
        {
            google::protobuf::Arena arena{};
            auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
            auto fe_request = *fe_ptr;

            fe_request.set_req_time(15_calendar_day);
            fe_request.add_item_fea();

            auto *user_app_conv_seq =
                    fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10001);
            user_app_conv_seq->set_event_time(10_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10002);
            user_app_conv_seq->set_event_time(11_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10003);
            user_app_conv_seq->set_event_time(13_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10005);
            user_app_conv_seq->set_event_time(16_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(9_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(8_calendar_day);

            auto fe_str = fe_request.SerializeAsString();
            auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
            auto ua_str = user_action->SerializeAsString();
            auto batch_training_sample_str =
                    to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);

            phx::BatchTrainingSample batch_training_sample;
            batch_training_sample.ParseFromString(batch_training_sample_str);

            auto user_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();

            TEST_SLOT_FEATURE_INT64(10812, ({}), batch_training_sample.training_samples(0).features(0));
            TEST_SLOT_FEATURE_INT64(10813, ({}), batch_training_sample.training_samples(0).features(1));
        }
    }

    // start配置的值等于end
    TEST_CASE("test_seq_pb_clip_z2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_pb_clip" source=".fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" eventtime_key="event_time" start_day="6" end_day = "6" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                </features>
            </config>
          )";
        auto config_handle =
                reinterpret_cast<long>(init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr"));
        {
            google::protobuf::Arena arena{};
            auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
            auto fe_request = *fe_ptr;

            fe_request.set_req_time(15_calendar_day);
            fe_request.add_item_fea();

            auto *user_app_conv_seq =
                    fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10001);
            user_app_conv_seq->set_event_time(10_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10002);
            user_app_conv_seq->set_event_time(11_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10003);
            user_app_conv_seq->set_event_time(15_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10005);
            user_app_conv_seq->set_event_time(10_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(9_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(8_calendar_day);

            auto fe_str = fe_request.SerializeAsString();
            auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
            auto ua_str = user_action->SerializeAsString();
            auto batch_training_sample_str =
                    to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);

            phx::BatchTrainingSample batch_training_sample;
            batch_training_sample.ParseFromString(batch_training_sample_str);

            auto user_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();

            TEST_SLOT_FEATURE_INT64(10812, ({10006}), batch_training_sample.training_samples(0).features(0));
            TEST_SLOT_FEATURE_INT64(10813, ({user_seq->ad_user_app_conv_seq(4).event_time()}),
                                    batch_training_sample.training_samples(0).features(1));
        }
    }

    // start配置的值等于end，且为负数
    TEST_CASE("test_seq_pb_clip_z3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_pb_clip" source=".fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" eventtime_key="event_time" start_day="-8" end_day = "-8" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                </features>
            </config>
          )";
        auto config_handle =
                reinterpret_cast<long>(init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr"));
        {
            google::protobuf::Arena arena{};
            auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
            auto fe_request = *fe_ptr;

            fe_request.set_req_time(15_calendar_day);
            fe_request.add_item_fea();

            auto *user_app_conv_seq =
                    fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10001);
            user_app_conv_seq->set_event_time(10_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10002);
            user_app_conv_seq->set_event_time(11_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10003);
            user_app_conv_seq->set_event_time(15_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10005);
            user_app_conv_seq->set_event_time(10_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(23_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(8_calendar_day);

            auto fe_str = fe_request.SerializeAsString();
            auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
            auto ua_str = user_action->SerializeAsString();
            auto batch_training_sample_str =
                    to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);

            phx::BatchTrainingSample batch_training_sample;
            batch_training_sample.ParseFromString(batch_training_sample_str);

            auto user_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();

            TEST_SLOT_FEATURE_INT64(10812, ({10006}), batch_training_sample.training_samples(0).features(0));
            TEST_SLOT_FEATURE_INT64(10813, ({user_seq->ad_user_app_conv_seq(4).event_time()}),
                                    batch_training_sample.training_samples(0).features(1));
        }
    }

    // 输入为空，配置默认输入
    TEST_CASE("test_seq_pb_clip_z4") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_pb_clip" source=".fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" eventtime_key="event_time" start_day="0" end_day = "1000000" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" default_input_int64="666" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" default_input_int64="444" />
                </features>
            </config>
          )";
        auto config_handle =
                reinterpret_cast<long>(init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr"));
        {
            google::protobuf::Arena arena{};
            auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
            auto fe_request = *fe_ptr;

            fe_request.set_req_time(15_calendar_day);
            fe_request.add_item_fea();

            auto *user_app_conv_seq =
                    fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10002);
            user_app_conv_seq->set_event_time(110_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10003);
            user_app_conv_seq->set_event_time(150_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10005);
            user_app_conv_seq->set_event_time(100_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(230_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(80_calendar_day);

            auto fe_str = fe_request.SerializeAsString();
            auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
            auto ua_str = user_action->SerializeAsString();
            auto batch_training_sample_str =
                    to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);

            phx::BatchTrainingSample batch_training_sample;
            batch_training_sample.ParseFromString(batch_training_sample_str);

            auto user_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();

            TEST_SLOT_FEATURE_INT64(10812, ({666}), batch_training_sample.training_samples(0).features(0));
            TEST_SLOT_FEATURE_INT64(10813, ({444}), batch_training_sample.training_samples(0).features(1));
        }
    }

    // 输入为空，但是非法值配置的不是默认值，最后会输出默认值
    TEST_CASE("test_seq_priority_merge_z1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_priority_merge" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr_over_all,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr_over_avg" illegal_float="1.1" />
                    <feature name="10813" slot="10813" type="seq_priority_merge" source=".fe_request.ad_user_dmp_feature.user_dmp_feature.mkt_name_short_name,.fe_request.ad_user_dmp_feature.user_dmp_feature.last_magicui_version,.fe_request.ad_user_dmp_feature.user_dmp_feature.device_name" illegal_string="xxx" />
                    <feature name="10814" slot="10814" type="seq_priority_merge" source=".user_action.user_action_item_info.deep_conv_type,.user_action.user_action_item_info.conv_type,.user_action.user_action_item_info.conv_goal" illegal_int="5" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ad_user = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *stats_info = ad_user->add_user_ads_stats_info();

        stats_info = ad_user->add_user_ads_stats_info();

        auto *dmp_feature = fe_request.mutable_ad_user_dmp_feature()->mutable_user_dmp_feature();

        auto *user_action_item_info = user_action.add_user_action_item_info();

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);

        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_FLOAT(10812, ({0.0, 0.0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10813, ({""}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({0}), ret.training_samples(0).features(2));
    }

    // 使用empty策略，系数配置负数，min_expo使用默认值，应该报错
    // 遗留问题：除0会报错
    // 报错信息：ERROR: test case THREW exception: parse_xml_new_sample ./config_mgr/xml_config_mgr.h 520:create failed, config_type:stat_smooth_ctr, name:31406
    TEST_CASE("test_stat_smooth_ctr_z1" * doctest::skip()) {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                 />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />
                <source name="item_info"
                    value=".fe_request.item_fea.item_info" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="stat_smooth_ctr"
                        source="item_info.ocpx_sbp,item_info.data_source"
                        default_value="-1.1"
                        strategy="empty"
                        alpha="-1"
                        beta="-10.0"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;

        auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        auto &fe_request = *fe_ptr;
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1110);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1111);
        ad_user_app_info->set_count(20);

        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20001);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20002);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
        item_fea->mutable_item_info()->set_creative_id(1110);
        item_fea->mutable_item_info()->set_ocpx_sbp(1);
        item_fea->mutable_item_info()->set_data_source(7);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(8);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(11);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("236");
        item_fea->mutable_item_info()->set_creative_id(1112);
        item_fea->mutable_item_info()->set_ocpx_sbp(10);
        item_fea->mutable_item_info()->set_data_source(0);
        auto fe_str = fe_ptr->SerializeAsString();

        auto user_action_ptr = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action_ptr->add_user_action_item_info();
        user_action_ptr->add_user_action_item_info();
        user_action_ptr->add_user_action_item_info();
        auto user_action_str = user_action_ptr->SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        // phx::BatchTrainingSample training_sample;
        // training_sample.ParseFromString(batch_training_sample_str);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);
        TEST_SLOT_FEATURE_FLOAT(31406, ({(float) 0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(31406, ({(float) 2 / -2}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(0).features(3));
    }

    // min_expo配置1以下的正数报错
    TEST_CASE("test_stat_smooth_ctr_z2" * doctest::skip()) {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                 />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />
                <source name="item_info"
                    value=".fe_request.item_fea.item_info" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="stat_smooth_ctr"
                        source="item_info.ocpx_sbp,item_info.data_source"
                        default_value="-1.1"
                        min_expo="0.1"
                        strategy="empty"
                        alpha="-1"
                        beta="-10.0"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;

        auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        auto &fe_request = *fe_ptr;
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1110);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1111);
        ad_user_app_info->set_count(20);

        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20001);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20002);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
        item_fea->mutable_item_info()->set_creative_id(1110);
        item_fea->mutable_item_info()->set_ocpx_sbp(1);
        item_fea->mutable_item_info()->set_data_source(7);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(8);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(11);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("236");
        item_fea->mutable_item_info()->set_creative_id(1112);
        item_fea->mutable_item_info()->set_ocpx_sbp(10);
        item_fea->mutable_item_info()->set_data_source(0);
        auto fe_str = fe_ptr->SerializeAsString();

        auto user_action_ptr = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action_ptr->add_user_action_item_info();
        user_action_ptr->add_user_action_item_info();
        user_action_ptr->add_user_action_item_info();
        auto user_action_str = user_action_ptr->SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        // phx::BatchTrainingSample training_sample;
        // training_sample.ParseFromString(batch_training_sample_str);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);
        TEST_SLOT_FEATURE_FLOAT(31406, ({(float) 0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(31406, ({(float) 2 / -2}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(0).features(3));
    }

    // min_expo配置0报错
    TEST_CASE("test_stat_smooth_ctr_z3" * doctest::skip()) {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                 />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />
                <source name="item_info"
                    value=".fe_request.item_fea.item_info" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="stat_smooth_ctr"
                        source="item_info.ocpx_sbp,item_info.data_source"
                        default_value="-1.1"
                        min_expo="0"
                        strategy="empty"
                        alpha="-1"
                        beta="-10.0"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;

        auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        auto &fe_request = *fe_ptr;
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1110);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1111);
        ad_user_app_info->set_count(20);

        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20001);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20002);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
        item_fea->mutable_item_info()->set_creative_id(1110);
        item_fea->mutable_item_info()->set_ocpx_sbp(1);
        item_fea->mutable_item_info()->set_data_source(7);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(8);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(11);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("236");
        item_fea->mutable_item_info()->set_creative_id(1112);
        item_fea->mutable_item_info()->set_ocpx_sbp(10);
        item_fea->mutable_item_info()->set_data_source(0);
        auto fe_str = fe_ptr->SerializeAsString();

        auto user_action_ptr = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action_ptr->add_user_action_item_info();
        user_action_ptr->add_user_action_item_info();
        user_action_ptr->add_user_action_item_info();
        auto user_action_str = user_action_ptr->SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        // phx::BatchTrainingSample training_sample;
        // training_sample.ParseFromString(batch_training_sample_str);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);
        TEST_SLOT_FEATURE_FLOAT(31406, ({(float) 0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(31406, ({(float) 2 / -2}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(0).features(3));
    }

    // min_expo配置负数报错
    TEST_CASE("test_stat_smooth_ctr_z4" * doctest::skip()) {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                 />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />
                <source name="item_info"
                    value=".fe_request.item_fea.item_info" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="stat_smooth_ctr"
                        source="item_info.ocpx_sbp,item_info.data_source"
                        default_value="-1.1"
                        min_expo="-9"
                        strategy="empty"
                        alpha="-1"
                        beta="-10.0"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;

        auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        auto &fe_request = *fe_ptr;
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1110);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1111);
        ad_user_app_info->set_count(20);

        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20001);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20002);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
        item_fea->mutable_item_info()->set_creative_id(1110);
        item_fea->mutable_item_info()->set_ocpx_sbp(1);
        item_fea->mutable_item_info()->set_data_source(7);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(8);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(11);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("236");
        item_fea->mutable_item_info()->set_creative_id(1112);
        item_fea->mutable_item_info()->set_ocpx_sbp(10);
        item_fea->mutable_item_info()->set_data_source(0);
        auto fe_str = fe_ptr->SerializeAsString();

        auto user_action_ptr = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action_ptr->add_user_action_item_info();
        user_action_ptr->add_user_action_item_info();
        user_action_ptr->add_user_action_item_info();
        auto user_action_str = user_action_ptr->SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        // phx::BatchTrainingSample training_sample;
        // training_sample.ParseFromString(batch_training_sample_str);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);
        TEST_SLOT_FEATURE_FLOAT(31406, ({(float) 0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(31406, ({(float) 2 / -2}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(0).features(3));
    }

    // 配置默认输入值，但是类型与source不一致不生效，使用默认值填充
    TEST_CASE("test_combine_z1") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="combine"
                        source=".fe_request.ad_user_seq_download_offline.user_behavior_info.session_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.count"
                        default_input_int64="1000"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        pb_item_fea->mutable_item_info()->set_rta_id("2000");
        pb_item_fea->mutable_item_info()->set_conv_type(18);

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        pb_item_fea->mutable_item_info()->set_rta_id("2001");
        pb_item_fea->mutable_item_info()->set_conv_type(9);

        auto ad_user_seq = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();

        ad_user_seq = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        ad_user_seq->set_session_id("test_seesion_id_2");
        ad_user_seq = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        ad_user_seq->set_session_id("test_seesion_id_3");

        auto ad_user_app_seq_expose_offline = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_seq_expose_offline->set_count(100);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        TEST_FEATURE_STR(({"", "test_seesion_id_2", "test_seesion_id_3"}), ret.training_samples(0).features(0));
        TEST_FEATURE_STR(({"", "test_seesion_id_2", "test_seesion_id_3"}), ret.training_samples(1).features(0));
    }

    // 配置默认输入值，使用默认输入填充
    TEST_CASE("test_combine_z2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="combine"
                        source=".fe_request.ad_user_seq_download_offline.user_behavior_info.session_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.count"
                        default_input_str="1000"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        pb_item_fea->mutable_item_info()->set_rta_id("2000");
        pb_item_fea->mutable_item_info()->set_conv_type(18);

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        pb_item_fea->mutable_item_info()->set_rta_id("2001");
        pb_item_fea->mutable_item_info()->set_conv_type(9);

        auto ad_user_seq = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();

        ad_user_seq = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        ad_user_seq->set_session_id("test_seesion_id_2");
        ad_user_seq = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        ad_user_seq->set_session_id("test_seesion_id_3");

        auto ad_user_app_seq_expose_offline = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_seq_expose_offline->set_count(100);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        TEST_FEATURE_STR(({"1000", "test_seesion_id_2", "test_seesion_id_3"}), ret.training_samples(0).features(0));
        TEST_FEATURE_STR(({"1000", "test_seesion_id_2", "test_seesion_id_3"}), ret.training_samples(1).features(0));
    }

    // 使用pb为repeated的user特征，输入为空，输出为空
    TEST_CASE("test_seq_cross_hash_bits_z1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_cross_hash_bits" source=".fe_request.ad_user_dmp_feature.user_dmp_feature.device_name,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time" clip_size="3" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);

        auto *user_dmp_feature = fe_request.mutable_ad_user_dmp_feature()->mutable_user_dmp_feature();

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);
        std::vector<int64_t> hash_10812;
        int64_t hash_ret_1;
        int64_t hash_ret_2;

        murmur_hash("", hash_ret_1);
        murmur_hash(5 * 86400 * 1000, hash_ret_2);
        hash_10812.emplace_back(hash_ret_1 ^ hash_ret_2);

        murmur_hash(104436666, hash_ret_1);
        murmur_hash(11 * 86400 * 1000, hash_ret_2);
        hash_10812.emplace_back(hash_ret_1 ^ hash_ret_2);

        murmur_hash(900778570, hash_ret_1);
        murmur_hash(9 * 86404 * 1000, hash_ret_2);
        hash_10812.emplace_back(hash_ret_1 ^ hash_ret_2);

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
    }

    // 输入为空字符串，正常输出
    TEST_CASE("test_seq_cross_hash_bits_z1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_cross_hash_bits" source=".fe_request.ad_user_dmp_feature.user_dmp_feature.device_name,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time" clip_size="3" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);

        auto *user_dmp_feature = fe_request.mutable_ad_user_dmp_feature()->mutable_user_dmp_feature();
        user_dmp_feature->set_device_name("");

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 11 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 9 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86401 * 1000);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);
        std::vector<int64_t> hash_10812;
        int64_t hash_ret_1;
        int64_t hash_ret_2;

        murmur_hash("", hash_ret_1);
        murmur_hash(0, hash_ret_2);
        hash_10812.emplace_back(hash_ret_1 ^ hash_ret_2);

        TEST_SLOT_FEATURE_INT64(10812, (hash_10812), ret.training_samples(0).features(0));
    }

    // 配置input默认值，查询不到词典的pb
    TEST_CASE("test_query_stats_dict_z1") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="ad_stat_info" value="10820,10821" />
        </versions>
        <config>
            <dict name="ad_stat_info"
                  path="dict_test_data/adstatinfo"
                  partition="{pt_d-1}"
                  value_proto="phx.AdStatDict"
                  class_name="AdStatDict"
            />
            <source name="item_info" value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10820_10821"
                         type="query_stats_dict"
                         slot="10820_10821"
                         dict_name="ad_stat_info"
                         output_fields="adgroup_stats_14d.num_click,app_stats_14d.num_click"
                         source="item_info.rta_id"
                         keys="${source[0]},demo"
                         types="first_type_id,adunit_id"
                         default_int64_value="1700000000000"
                         default_float_value="-1.11f"
                         default_string_value="null" />
                <feature name = "10820"
                         slot="10820"
                         type="direct_to_feature"
                         source="10820_10821:0" />
                <feature name = "10821"
                         slot="10821"
                         type="direct_to_feature"
                         source="10820_10821:1" />
            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_ptr->add_item_fea();
        mocker::FillProto(*fe_ptr);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        TEST_SLOT_FEATURE_INT64(10820, ({1700000000000}), training_sample.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10821, ({1700000000000}), training_sample.training_samples(0).features(1));
    }

    // topn=0取全部数据
    TEST_CASE("test_seq_topn_direct_z1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" filter_key="app_id" fields="request_id,event_time,ad_group_id" topn="0" reserve="1" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"0", "0", "1", "2"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 240, 120, 360}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 300, 200, 400}), ret.training_samples(0).features(2));
    }

    // reserve=0从大到小排序
    TEST_CASE("test_seq_topn_direct_z2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" filter_key="app_id" fields="request_id,event_time,ad_group_id" topn="100" reserve="0" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"2", "1", "0", "0"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({360, 120, 60, 240}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({400, 200, 100, 300}), ret.training_samples(0).features(2));
    }

    // topn=100取全部数据
    TEST_CASE("test_seq_topn_direct_z3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" filter_key="app_id" fields="request_id,event_time,ad_group_id" topn="100" reserve="1" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"0", "0", "1", "2"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 240, 120, 360}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 300, 200, 400}), ret.training_samples(0).features(2));
    }

    // reserve未配置取默认值0
    TEST_CASE("test_seq_topn_direct_z4") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" filter_key="app_id" fields="request_id,event_time,ad_group_id" topn="100" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"2", "1", "0", "0"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({360, 120, 60, 240}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({400, 200, 100, 300}), ret.training_samples(0).features(2));
    }

    // 取topn存在相同值全部输出
    // 遗留问题8：存在相同值时不会全部输出，老算子有这样的逻辑
    TEST_CASE("test_seq_topn_direct_z5") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" filter_key="app_id" fields="request_id,event_time,ad_group_id" topn="2" reserve="1" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"0", "1"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 120}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 200}), ret.training_samples(0).features(2));
    }

    // filter_key配置的特征未传值，配置default_input_int64使用默认值作为输入
    // 遗留问题9：默认输入值未生效
    TEST_CASE("test_seq_topn_direct_z6") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" 
                    filter_key="app_id" 
                    fields="request_id,event_time,ad_group_id" 
                    topn="2" 
                    reserve="0" 
                    default_input_int64="10000" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"2", "0"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({360, 10000}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({400, 100}), ret.training_samples(0).features(2));
    }

    // filter_key配置的特征未传值，使用类型默认值作为输入
    TEST_CASE("test_seq_topn_direct_z7") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" 
                    filter_key="app_id" 
                    fields="request_id,event_time,ad_group_id" 
                    topn="2" 
                    reserve="0" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"0", "0"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({0, 240}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 300}), ret.training_samples(0).features(2));
    }

    // 只配置lower_bound；配置lower_bound和upper_bound相等
    TEST_CASE("test_seq_val_direct_v2_z1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814,10823,10824,10825" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" lower_bound="3.0" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                    <feature name="10822" slot="10822" type="seq_val_direct_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" lower_bound="1.0" upper_bound="1.0" />
                    <feature name="10823" slot="10823" type="direct" source="10822:0" />
                    <feature name="10824" slot="10824" type="direct" source="10822:1" />
                    <feature name="10825" slot="10825" type="direct" source="10822:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        fe_request.set_event_time(1000000);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time(995000);
        user_ads_stats_info->set_dtr(1.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(993000);
        user_ads_stats_info->set_dtr(3.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10003);
        user_ads_stats_info->set_last_event_time(991000);
        user_ads_stats_info->set_dtr(2.0);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 6);

        TEST_SLOT_FEATURE_INT64(10812, ({10002}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({993000}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({3.0}), ret.training_samples(0).features(2));

        TEST_SLOT_FEATURE_INT64(10823, ({10001}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10824, ({995000}), ret.training_samples(0).features(4));
        TEST_SLOT_FEATURE_FLOAT(10825, ({1.0}), ret.training_samples(0).features(5));
    }

    // 配置lower_bound大于upper_bound，报错
    // 报错信息：ERROR: test case THREW exception: SeqValDirectV2Config config/phx_config_seq.cc 841:upper_bound_ is less than lower_bound_
    TEST_CASE("test_seq_val_direct_v2_z2" * doctest::skip()) {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814,10816,10817,10819,10820,10821,10823,10824" />
            </versions>
            <config>
                <features>
                    <feature name="10822" slot="10822" type="seq_val_direct_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" lower_bound="2.0" upper_bound="1.0" />
                    <feature name="10823" slot="10823" type="direct" source="10822:0" />
                    <feature name="10824" slot="10824" type="direct" source="10822:1" />
                    <feature name="10825" slot="10825" type="direct" source="10822:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        fe_request.set_event_time(1000000);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time(995000);
        user_ads_stats_info->set_dtr(1.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(993000);
        user_ads_stats_info->set_dtr(3.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10003);
        user_ads_stats_info->set_last_event_time(991000);
        user_ads_stats_info->set_dtr(2.0);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 10);

        TEST_SLOT_FEATURE_INT64(10823, ({10001}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10824, ({995000}), ret.training_samples(0).features(4));
        TEST_SLOT_FEATURE_FLOAT(10825, ({1.0}), ret.training_samples(0).features(5));
    }

    // 有聚合，输入为空，输出为空
    // 遗留问题10：空的定义是啥->已解决
    TEST_CASE("test_seq_statistics_z1") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.event_time"
                        math_type="avg,min,max"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                    <feature name="10815"
                        slot="10815"
                        type="direct"
                        source="10811:3"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(4, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(0).features(3));
    }

    // 无聚合，输入为空，输出为空
    TEST_CASE("test_seq_statistics_z2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                        math_type="avg,min,max"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();
        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10812, {}, ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, {}, ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, {}, ret.training_samples(0).features(2));
    }

    // 无聚合，只启用两种计算类型
    TEST_CASE("test_seq_statistics_z3") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                        math_type="max,min"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info()->set_dtr(1.2f);
        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info()->set_dtr(2.3f);
        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info()->set_dtr(3.4f);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(2, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10812, {3.4f}, ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, {1.2f}, ret.training_samples(0).features(1));
    }

    // 有聚合，只启用两种计算类型
    TEST_CASE("test_seq_statistics_z4") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.event_time"
                        math_type="max,min"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(2);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(4);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(4);
        user_behavior_info->set_event_time(200);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(6);
        user_behavior_info->set_event_time(200);
        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(8);
        user_behavior_info->set_event_time(200);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({4, 8}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({1, 4}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 200}), ret.training_samples(0).features(2));
    }

    // 使用不存在的计算类型，报错
    // 报错信息：ERROR: test case THREW exception: SeqStatisticsConfig config/phx_config_seq.cc 3742:UNKNOWN MATH_TYPEmin6
    TEST_CASE("test_seq_statistics_z5" * doctest::skip()) {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                        math_type="max,min6"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info()->set_dtr(1.2f);
        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info()->set_dtr(2.3f);
        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info()->set_dtr(3.4f);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(2, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10812, {3.4f}, ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, {1.2f}, ret.training_samples(0).features(1));
    }

    // 有聚合，输入为相同值
    TEST_CASE("test_seq_statistics_z6") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.event_time"
                        math_type="max,min,avg"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                    <feature name="10815"
                        slot="10815"
                        type="direct"
                        source="10811:3"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(0);
        user_behavior_info->set_event_time(200);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(0);
        user_behavior_info->set_event_time(200);
        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(0);
        user_behavior_info->set_event_time(200);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(4, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({1, 0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({1, 0}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({1, 0}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10815, ({100, 200}), ret.training_samples(0).features(3));
    }

    // 无聚合，输入包含负数
    TEST_CASE("test_seq_statistics_z7") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id"
                        math_type="max,min,avg"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(-1);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({1}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({-1}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({0.333333}), ret.training_samples(0).features(2));
    }

    // 无聚合，使用item特征
    TEST_CASE("test_seq_statistics_z8") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.item_fea.item_info.rta_url_id"
                        math_type="max,min,avg"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        auto *item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_rta_url_id(1001);
        item_info->set_rta_url_id(1003);
        fe_request->add_item_fea()->mutable_item_info()->set_rta_url_id(1002);

        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(-1);
        user_behavior_info->set_event_time(100);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(2, ret.training_samples_size());
        TEST_SLOT_FEATURE_INT64(10812, ({1003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({1003}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({1003}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10812, ({1002}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({1002}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({1002}), ret.training_samples(1).features(2));
    }

    // 有聚合，item特征
    TEST_CASE("test_seq_statistics_z9") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.item_fea.item_info.rta_url_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.event_time"
                        math_type="max,min,avg"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                    <feature name="10815"
                        slot="10815"
                        type="direct"
                        source="10811:3"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        auto *item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_rta_url_id(1001);
        item_info->set_rta_url_id(1003);

        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        TEST_SLOT_FEATURE_INT64(10812, ({1003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({1003}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({1003}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10815, ({100}), ret.training_samples(0).features(3));
    }

    // 有聚合，item特征，user和item数量不一致报错
    // 报错：ERROR: test case THREW exception: compute config/phx_config_seq.cc 3879:aggregation's size not equal num's size
    TEST_CASE("test_seq_statistics_z10" * doctest::skip()) {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.item_fea.item_info.rta_url_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.event_time"
                        math_type="max,min,avg"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                    <feature name="10815"
                        slot="10815"
                        type="direct"
                        source="10811:3"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        auto *item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_rta_url_id(1001);
        item_info->set_rta_url_id(1003);

        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);
        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        TEST_SLOT_FEATURE_INT64(10812, ({1003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({1003}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({1003}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10815, ({100}), ret.training_samples(0).features(3));
    }

    // sort_cols使用超出边界的值，报错
    // 报错信息：ERROR: test case THREW exception: SeqSortConfig config/phx_config_seq.cc 3992:col >= inputs_size
    TEST_CASE("test_seq_sort_z1" * doctest::skip()) {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_sort"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_download_success,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time"
                        sort_cols="2,3,0"
                        sort_orders="desc,asc,desc"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto user_ads_stats_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.3f);
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(3.4f);
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.2f);
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(3000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.3f);
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10812, ({2.3f, 3.4f, 2.3f, 1.2f}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({200L, 300L, 300L, 200L}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({4000L, 4000L, 4000L, 3000L}), ret.training_samples(0).features(2));
    }

    // sort_orders使用非正确的值，报错
    // 报错信息：ERROR: test case THREW exception: SeqSortConfig config/phx_config_seq.cc 3989:unknown order
    TEST_CASE("test_seq_sort_z2" * doctest::skip()) {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_sort"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_download_success,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time"
                        sort_cols="2,1,0"
                        sort_orders="desc,asc,desc66"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto user_ads_stats_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.3f);
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(3.4f);
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.2f);
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(3000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.3f);
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10812, ({2.3f, 3.4f, 2.3f, 1.2f}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({200L, 300L, 300L, 200L}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({4000L, 4000L, 4000L, 3000L}), ret.training_samples(0).features(2));
    }

    // sort_cols使用相同列多次排序，报错
    // 报错信息：ERROR: test case THREW exception: SeqSortConfig config/phx_config_seq.cc 3995:duplicate columns
    TEST_CASE("test_seq_sort_z3" * doctest::skip()) {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_sort"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_download_success,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time"
                        sort_cols="2,2,1"
                        sort_orders="desc,asc,desc"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto user_ads_stats_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.3f);
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(3.4f);
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.2f);
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(3000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.3f);
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10812, ({2.3f, 3.4f, 2.3f, 1.2f}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({200L, 300L, 300L, 200L}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({4000L, 4000L, 4000L, 3000L}), ret.training_samples(0).features(2));
    }

    // sort_orders配置数量大于实际输入数量，报错
    // 报错信息：ERROR: test case THREW exception: SeqSortConfig config/phx_config_seq.cc 3974:sort_cols's size not equal sort_orders's size
    TEST_CASE("test_seq_sort_z4" * doctest::skip()) {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_sort"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_download_success,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time"
                        sort_cols="2,2,1"
                        sort_orders="desc,asc,desc,asc"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto user_ads_stats_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.3f);
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(3.4f);
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.2f);
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(3000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.3f);
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10812, ({2.3f, 3.4f, 2.3f, 1.2f}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({200L, 300L, 300L, 200L}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({4000L, 4000L, 4000L, 3000L}), ret.training_samples(0).features(2));
    }

    // 第一层repeated为空，输出为空
    TEST_CASE("test_seq_flatten_z1") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_flatten"
                        source=".fe_request.ad_user_auction_win_seq_1h_realtime.ad_user_auction_win_adunit_seq_1h_realtime"
                        from_lv1="adunit_id,callback_time"
                        from_lv2="app_id"
                        repeated_field="user_behavior_info"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto ad_user_auction_win_adunit_seq_1h_realtime = fe_request->mutable_ad_user_auction_win_seq_1h_realtime();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(0).features(2));
    }

    // 第二层repeated为空，输出为空
    TEST_CASE("test_seq_flatten_z2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_flatten"
                        source=".fe_request.ad_user_auction_win_seq_1h_realtime.ad_user_auction_win_adunit_seq_1h_realtime"
                        from_lv1="adunit_id,callback_time"
                        from_lv2="app_id"
                        repeated_field="user_behavior_info"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto ad_user_auction_win_adunit_seq_1h_realtime = fe_request->mutable_ad_user_auction_win_seq_1h_realtime()
                                                                  ->add_ad_user_auction_win_adunit_seq_1h_realtime();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(0).features(2));
    }

    // 第一层repeated为空，输出为空
    TEST_CASE("test_seq_flatten_z2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_flatten"
                        source=".fe_request.ad_user_auction_win_seq_1h_realtime.ad_user_auction_win_adunit_seq_1h_realtime"
                        from_lv1="adunit_id,callback_time"
                        from_lv2="app_id"
                        repeated_field="user_behavior_info"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto ad_user_auction_win_adunit_seq_1h_realtime = fe_request->mutable_ad_user_auction_win_seq_1h_realtime()
                                                                  ->add_ad_user_auction_win_adunit_seq_1h_realtime();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(0).features(2));
    }

    // 输入部分为空
    TEST_CASE("test_seq_flatten_z3") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_flatten"
                        source=".fe_request.ad_user_auction_win_seq_1h_realtime.ad_user_auction_win_adunit_seq_1h_realtime"
                        from_lv1="adunit_id,callback_time"
                        from_lv2="app_id"
                        repeated_field="user_behavior_info"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto ad_user_auction_win_adunit_seq_1h_realtime = fe_request->mutable_ad_user_auction_win_seq_1h_realtime()
                                                                  ->add_ad_user_auction_win_adunit_seq_1h_realtime();

        ad_user_auction_win_adunit_seq_1h_realtime->set_adunit_id(12345);
        ad_user_auction_win_adunit_seq_1h_realtime->set_callback_time(1738704554000);

        ad_user_auction_win_adunit_seq_1h_realtime->add_user_behavior_info();
        ad_user_auction_win_adunit_seq_1h_realtime->add_user_behavior_info()->set_app_id(654);
        ad_user_auction_win_adunit_seq_1h_realtime->add_user_behavior_info()->set_app_id(321);

        ad_user_auction_win_adunit_seq_1h_realtime = fe_request->mutable_ad_user_auction_win_seq_1h_realtime()
                                                             ->add_ad_user_auction_win_adunit_seq_1h_realtime();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({12345L, 12345L, 12345L}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({1738704554000L, 1738704554000L, 1738704554000L}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({0L, 654L, 321L}), ret.training_samples(0).features(2));
    }

    // 使用seq_statistics算子，测试model_config新在线抽取，attr="item"
    TEST_CASE("test_select_model_config_z1") {
        const std::string fe_config = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.item_fea.item_info.rta_url_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.event_time"
                        math_type="max,min,avg"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        attr="item"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        attr="item"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        attr="item"
                        source="10811:2"
                        />
                    <feature name="10815"
                        slot="10815"
                        type="direct"
                        attr="item"
                        source="10811:3"
                        />
                </features>
            </config>
        )";

        std::string model_input_config = R"(
            input_tensors:
                - input_part:
                    tensor_name: "gate_embs"
                    type: "sparse"
                    slots:  ['10813','10814']
                    embedding_size: 62
                    combine_method: "sum"
                    save_ratio: 1
                - input_part:
                    tensor_name: "dnn_embs"
                    type: "sparse"
                    slots:  ['10812', '10815']
                    embedding_size: 62
                    combine_method: "sum"
                    save_ratio: 1
                )";
        auto model_input_fe_config =
                init_xml_online_by_decypt_content_new_sample(fe_config, model_input_config, nullptr);
        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        auto *item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_rta_url_id(1001);
        item_info->set_rta_url_id(1003);

        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        phx::ExtractorResponse *extractor_response =
                google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(&arena);

        toExtractorResponse(&arena, *fe_request, user_action, *model_input_fe_config, *extractor_response, false);
        phx::ExtractorResponse ret = *extractor_response;

        CHECK_EQ(1, ret.item_cnt());
        TEST_BATCH_SLOT_FEATURES_INT64(0, 10812, ({{1003}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(1, 10813, ({{1003}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_FLOAT(2, 10814, ({{1003}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(3, 10815, ({{100}}), ret.item_features());
    }

    // 使用seq_flatten算子，测试model_config在部分输入为空下的在线抽取，attr="user"，model_config只获取部分输出
    TEST_CASE("test_select_model_config_z2") {
        const std::string fe_config = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_flatten"
                        source=".fe_request.ad_user_auction_win_seq_1h_realtime.ad_user_auction_win_adunit_seq_1h_realtime"
                        from_lv1="adunit_id,callback_time"
                        from_lv2="app_id"
                        repeated_field="user_behavior_info"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        attr="user"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        attr="user"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        attr="user"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        std::string model_input_config = R"(
            input_tensors:
                - input_part:
                    tensor_name: "gate_embs"
                    type: "sparse"
                    slots:  ['10812']
                    embedding_size: 62
                    combine_method: "sum"
                    save_ratio: 1
                - input_part:
                    tensor_name: "dnn_embs"
                    type: "sparse"
                    slots:  ['10813']
                    embedding_size: 62
                    combine_method: "sum"
                    save_ratio: 1
                )";
        auto model_input_fe_config =
                init_xml_online_by_decypt_content_new_sample(fe_config, model_input_config, nullptr);
        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto ad_user_auction_win_adunit_seq_1h_realtime = fe_request->mutable_ad_user_auction_win_seq_1h_realtime()
                                                                  ->add_ad_user_auction_win_adunit_seq_1h_realtime();

        ad_user_auction_win_adunit_seq_1h_realtime->set_adunit_id(12345);
        ad_user_auction_win_adunit_seq_1h_realtime->set_callback_time(1738704554000);

        ad_user_auction_win_adunit_seq_1h_realtime->add_user_behavior_info();
        ad_user_auction_win_adunit_seq_1h_realtime->add_user_behavior_info()->set_app_id(654);
        ad_user_auction_win_adunit_seq_1h_realtime->add_user_behavior_info()->set_app_id(321);

        ad_user_auction_win_adunit_seq_1h_realtime = fe_request->mutable_ad_user_auction_win_seq_1h_realtime()
                                                             ->add_ad_user_auction_win_adunit_seq_1h_realtime();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        phx::ExtractorResponse *extractor_response =
                google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(&arena);

        toExtractorResponse(&arena, *fe_request, user_action, *model_input_fe_config, *extractor_response, false);
        phx::ExtractorResponse ret = *extractor_response;

        CHECK_EQ(1, ret.item_cnt());
        TEST_SLOT_FEATURE_INT64(10812, ({12345L, 12345L, 12345L}), ret.user_features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({1738704554000L, 1738704554000L, 1738704554000L}), ret.user_features(1));
    }

    // 使用seq_flatten算子，测试model_config在输入为空下的在线抽取，attr="user"，model_config只获取部分输出
    TEST_CASE("test_select_model_config_z3") {
        const std::string fe_config = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_flatten"
                        source=".fe_request.ad_user_auction_win_seq_1h_realtime.ad_user_auction_win_adunit_seq_1h_realtime"
                        from_lv1="adunit_id,callback_time"
                        from_lv2="app_id"
                        repeated_field="user_behavior_info"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        attr="user"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        attr="user"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        attr="user"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        std::string model_input_config = R"(
            input_tensors:
                - input_part:
                    tensor_name: "gate_embs"
                    type: "sparse"
                    slots:  ['10812']
                    embedding_size: 62
                    combine_method: "sum"
                    save_ratio: 1
                - input_part:
                    tensor_name: "dnn_embs"
                    type: "sparse"
                    slots:  ['10813']
                    embedding_size: 62
                    combine_method: "sum"
                    save_ratio: 1
                )";
        auto model_input_fe_config =
                init_xml_online_by_decypt_content_new_sample(fe_config, model_input_config, nullptr);
        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto ad_user_auction_win_adunit_seq_1h_realtime = fe_request->mutable_ad_user_auction_win_seq_1h_realtime()
                                                                  ->add_ad_user_auction_win_adunit_seq_1h_realtime();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        phx::ExtractorResponse *extractor_response =
                google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(&arena);

        toExtractorResponse(&arena, *fe_request, user_action, *model_input_fe_config, *extractor_response, false);
        phx::ExtractorResponse ret = *extractor_response;

        CHECK_EQ(1, ret.item_cnt());
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.user_features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.user_features(1));
    }

    // 使用seq_flatten算子，测试model_config获取fe_config中不存在的feature时是否报错
    // 报错信息：ERROR: test case THREW exception: SelectModelInputConfig src/framework.cc 1668:config not find, model input config slot id = :10818
    TEST_CASE("test_select_model_config_z4" * doctest::skip()) {
        const std::string fe_config = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_flatten"
                        source=".fe_request.ad_user_auction_win_seq_1h_realtime.ad_user_auction_win_adunit_seq_1h_realtime"
                        from_lv1="adunit_id,callback_time"
                        from_lv2="app_id"
                        repeated_field="user_behavior_info"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        attr="user"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        attr="user"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        attr="user"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        std::string model_input_config = R"(
            input_tensors:
                - input_part:
                    tensor_name: "gate_embs"
                    type: "sparse"
                    slots:  ['10812']
                    embedding_size: 62
                    combine_method: "sum"
                    save_ratio: 1
                - input_part:
                    tensor_name: "dnn_embs"
                    type: "sparse"
                    slots:  ['10818']
                    embedding_size: 62
                    combine_method: "sum"
                    save_ratio: 1
                )";
        auto model_input_fe_config =
                init_xml_online_by_decypt_content_new_sample(fe_config, model_input_config, nullptr);
        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto ad_user_auction_win_adunit_seq_1h_realtime = fe_request->mutable_ad_user_auction_win_seq_1h_realtime()
                                                                  ->add_ad_user_auction_win_adunit_seq_1h_realtime();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        phx::ExtractorResponse *extractor_response =
                google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(&arena);

        toExtractorResponse(&arena, *fe_request, user_action, *model_input_fe_config, *extractor_response, false);
        phx::ExtractorResponse ret = *extractor_response;

        CHECK_EQ(1, ret.item_cnt());
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.user_features(0));
        TEST_SLOT_FEATURE_INT64(10818, ({}), ret.user_features(1));
    }

    // user和item的attr赋值错误，报错
    // ERROR: test case THREW exception: toExtractorResponse src/framework.cc 1217:config attr_type is item or cross, but real is user, name:10811
    TEST_CASE("test_to_extractor_response_z1" * doctest::skip()) {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811,10812,10813,10814,10815,10816"
                    labels="cvr_label_1,cvr_label_2,ad_group_id"
                    weights="cvr_weights_1,cvr_weights_2,cvr_weights_3"
                    item_extras_int64="ad_group_id"
                    item_extras_float="cvr_weights_1,cvr_label_2"
                    item_extras_bytes="rta_id,req_id"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    attr="item"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812"
                    slot="10812"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                    />
                <feature name="10813"
                    slot="10813"
                    type="direct_to_feature" 
                    attr="user"
                        source="item_info.creative_id"
                    />
                <feature name="10814"
                    slot="10814"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.conv_type"
                    />
                <feature name="10815"
                    slot="10815"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="10816"
                    slot="10816"
                    attr="user"
                    type="seq_hit_sum"
                    source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,item_info.appid"
                    start="0"
                    default_value="-2"
                    />

                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            attr="item"
                            source=".user_action.user_action_item_info.sdk_lahuo_conversion_rate" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_lahuo_conversion_rate" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="cvr_weights_3" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_register_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        attr="user"
                        source=".fe_request.req_id"
                    />
                <feature name="rta_id"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="ad_group_id"
                    type="direct_to_feature" 
                    attr="item"
                        source=".user_action.user_action_item_info.ad_group_id"
                    />
                <feature name="query"
                    type="direct_to_feature" 
                    attr="user"
                    source=".user_action.query"
                />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // req_time
        fe_request->set_req_time((int64_t) 500);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(100);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(200);

        fe_request->set_req_id("reqid0001");

        // item_info
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea->mutable_item_info()->set_creative_id(10);
        item_fea->mutable_item_info()->set_conv_type(20);
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");
        item_fea->mutable_item_info()->set_creative_id(11);
        item_fea->mutable_item_info()->set_conv_type(21);
        item_fea->mutable_item_info()->set_appid(10002);

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action.set_query("test_query_1");
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info->set_api_register_conversion_rate(0.15);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        item_info->set_api_register_conversion_rate(0.25);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_extractor_response(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({10001, 10002}), ret.user_features(0));
        TEST_SLOT_FEATURE_INT64(10812, ({100, 200}), ret.user_features(1));
        TEST_BATCH_SLOT_FEATURES_INT64(0, 10813, ({{10}, {11}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(1, 10814, ({{20}, {21}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_STR(2, 10815, ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(3, 10816, ({{100}, {200}}), ret.item_features());

        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_label_1", ({{0.11}, {0.21}}), ret.labels());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_label_2", ({{0.12}, {0.22}}), ret.labels());
        TEST_BATCH_EXTRA_FEATURES_INT64(2, "ad_group_id", ({{20001}, {20002}}), ret.labels());

        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_weights_1", ({{0.13}, {0.23}}), ret.weights());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_weights_2", ({{0.14}, {0.24}}), ret.weights());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(2, "cvr_weights_3", ({{0.15}, {0.25}}), ret.weights());

        TEST_BATCH_EXTRA_FEATURES_INT64(0, "ad_group_id", ({{20001}, {20002}}), ret.item_extras_int64());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_weights_1", ({{0.13}, {0.23}}), ret.item_extras_float());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_label_2", ({{0.12}, {0.22}}), ret.item_extras_float());
        TEST_BATCH_EXTRA_FEATURES_STR(0, "rta_id", ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_extras_bytes());
        TEST_BATCH_EXTRA_FEATURES_STR(1, "req_id", ({{"reqid0001"}, {"reqid0001"}}), ret.item_extras_bytes());

        CHECK_EQ(0, ret.user_extras_int64_size());
        CHECK_EQ(0, ret.user_extras_float_size());
        CHECK_EQ(0, ret.user_extras_bytes_size());
        CHECK_EQ(2, ret.item_cnt());
    }

    // 使用seq_sort算子，测试粗排样本，测试user_action使用空对象不影响在线抽取
    // 遗留问题11：fill_extra_feature src/framework.cc 2751:config attr_type is item or cross, but real is user, name:10813_label->0721已解决
    TEST_CASE("test_to_extractor_response_z2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812"
            labels="10813_label"
            weights="10814_weight"
            />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_sort"
                        source=".fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.appid,.fe_request.prerank_item_fea.prerank_item_info.appid"
                        sort_cols="0,1,2"
                        sort_orders="desc,asc,desc"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        attr="item"
                        source="10811:0"
                        />
                    <feature name="10813_label"
                        slot="10813"
                        type="trans_type"
                        attr="item"
                        source="10811:1"
                        data_type="float"
                        />
                    <feature name="10814_weight"
                        slot="10814"
                        type="trans_type"
                        attr="item"
                        source="10811:2"
                        data_type="float"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        auto *item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_appid(200);
        item_info->set_bid(4000);
        item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_appid(300);
        item_info->set_bid(4000);
        item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_appid(200);
        item_info->set_bid(3000);
        item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_appid(300);
        item_info->set_bid(4000);
        fe_request->add_prerank_item_fea()->mutable_prerank_item_info()->set_appid(100);
        fe_request->add_prerank_item_fea()->mutable_prerank_item_info()->set_appid(101);
        fe_request->add_prerank_item_fea()->mutable_prerank_item_info()->set_appid(101);
        fe_request->add_prerank_item_fea()->mutable_prerank_item_info()->set_appid(100);

        auto user_ads_stats_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(3000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action.mutable_user_action_item_info();
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_extractor_response_ltr(fe_request_str.c_str(), fe_request_str.size(),
                                                       user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(4, ret.item_cnt());

        TEST_BATCH_SLOT_FEATURES_INT64(0, 10812, ({{4000}, {4000}, {3000}, {4000}}), ret.item_features());

        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "10813_label", ({{200}, {300}, {200}, {300}}), ret.labels());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "10814_weight", ({{100}, {101}, {101}, {100}}), ret.weights());
    }

    // 精排样本配置user_extra报错
    // 报错信息：ERROR: test case THREW exception: toExtractorResponse src/framework.cc 1020:failed, non-LTR samples do not need user_extras configs
    TEST_CASE("test_to_extractor_response_z3" * doctest::skip()) {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811,10812,10813,10814,10815,10816"
                    labels="cvr_label_1,cvr_label_2"
                    weights="cvr_weights_1,cvr_weights_2,cvr_weights_3"
                    user_extras_int64="media_id"
                    user_extras_float="dtr"
                    user_extras_bytes="oaid"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812"
                    slot="10812"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                    />
                <feature name="10813"
                    slot="10813"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.creative_id"
                    />
                <feature name="10814"
                    slot="10814"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.conv_type"
                    />
                <feature name="10815"
                    slot="10815"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="10816"
                    slot="10816"
                    attr="cross"
                    type="seq_hit_sum"
                    source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,item_info.appid"
                    start="0"
                    default_value="-2"
                    />

                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            attr="item"
                            source=".user_action.user_action_item_info.sdk_lahuo_conversion_rate" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_lahuo_conversion_rate" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="cvr_weights_3" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_register_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        attr="user"
                        source=".fe_request.req_id"
                    />
                <feature name="dtr"
                    type="direct_to_feature" 
                    attr="user"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                    />
                <feature name="oaid"
                    type="direct_to_feature" 
                    attr="user"
                        source=".user_action.oaid"
                    />
                <feature name="media_id"
                    type="direct_to_feature" 
                    attr="user"
                    source=".user_action.media_id"
                />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // req_time
        fe_request->set_req_time((int64_t) 500);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(100);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(200);

        fe_request->set_req_id("reqid0001");

        // item_info
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea->mutable_item_info()->set_creative_id(10);
        item_fea->mutable_item_info()->set_conv_type(20);
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");
        item_fea->mutable_item_info()->set_creative_id(11);
        item_fea->mutable_item_info()->set_conv_type(21);
        item_fea->mutable_item_info()->set_appid(10002);

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action.set_query("test_query_1");
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info->set_api_register_conversion_rate(0.15);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        item_info->set_api_register_conversion_rate(0.25);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_extractor_response(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({10001, 10002}), ret.user_features(0));
        TEST_SLOT_FEATURE_INT64(10812, ({100, 200}), ret.user_features(1));
        TEST_BATCH_SLOT_FEATURES_INT64(0, 10813, ({{10}, {11}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(1, 10814, ({{20}, {21}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_STR(2, 10815, ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(3, 10816, ({{100}, {200}}), ret.item_features());

        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_label_1", ({{0.11}, {0.21}}), ret.labels());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_label_2", ({{0.12}, {0.22}}), ret.labels());
        TEST_BATCH_EXTRA_FEATURES_INT64(2, "ad_group_id", ({{20001}, {20002}}), ret.labels());

        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_weights_1", ({{0.13}, {0.23}}), ret.weights());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_weights_2", ({{0.14}, {0.24}}), ret.weights());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(2, "cvr_weights_3", ({{0.15}, {0.25}}), ret.weights());

        TEST_BATCH_EXTRA_FEATURES_INT64(0, "ad_group_id", ({{20001}, {20002}}), ret.item_extras_int64());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_weights_1", ({{0.13}, {0.23}}), ret.item_extras_float());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_label_2", ({{0.12}, {0.22}}), ret.item_extras_float());
        TEST_BATCH_EXTRA_FEATURES_STR(0, "rta_id", ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_extras_bytes());
        TEST_BATCH_EXTRA_FEATURES_STR(1, "req_id", ({{"reqid0001"}, {"reqid0001"}}), ret.item_extras_bytes());

        CHECK_EQ(0, ret.user_extras_int64_size());
        CHECK_EQ(0, ret.user_extras_float_size());
        CHECK_EQ(0, ret.user_extras_bytes_size());
        CHECK_EQ(2, ret.item_cnt());
    }

    // 精排样本配置item_extra类型填错，报错
    // 遗留问题12：与预期不符->20250721与童纵对齐，这里不报错
    TEST_CASE("test_to_extractor_response_z4") {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811,10812,10813,10814,10815,10816"
                    labels="cvr_label_1,cvr_label_2"
                    weights="cvr_weights_1,cvr_weights_2,cvr_weights_3"
                    item_extras_int64="cvr_weights_1"
                    item_extras_float="package_name"
                    item_extras_bytes="ad_group_id"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812"
                    slot="10812"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                    />
                <feature name="10813"
                    slot="10813"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.creative_id"
                    />
                <feature name="10814"
                    slot="10814"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.conv_type"
                    />
                <feature name="10815"
                    slot="10815"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="10816"
                    slot="10816"
                    attr="cross"
                    type="seq_hit_sum"
                    source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,item_info.appid"
                    start="0"
                    default_value="-2"
                    />

                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            attr="item"
                            source=".user_action.user_action_item_info.sdk_lahuo_conversion_rate" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_lahuo_conversion_rate" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="cvr_weights_3" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_register_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        attr="user"
                        source=".fe_request.req_id"
                    />
                <feature name="dtr"
                    type="direct_to_feature" 
                    attr="user"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                    />
                <feature name="package_name"
                    type="direct_to_feature" 
                    attr="item"
                        source=".user_action.user_action_item_info.package_name"
                    />
                <feature name="ad_group_id"
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.ad_group_id"
                />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // req_time
        fe_request->set_req_time((int64_t) 500);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(100);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(200);

        fe_request->set_req_id("reqid0001");

        // item_info
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea->mutable_item_info()->set_creative_id(10);
        item_fea->mutable_item_info()->set_conv_type(20);
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");
        item_fea->mutable_item_info()->set_creative_id(11);
        item_fea->mutable_item_info()->set_conv_type(21);
        item_fea->mutable_item_info()->set_appid(10002);

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action.set_query("test_query_1");
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info->set_api_register_conversion_rate(0.15);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        item_info->set_api_register_conversion_rate(0.25);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_extractor_response(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(0, ret.user_extras_int64_size());
        CHECK_EQ(0, ret.user_extras_float_size());
        CHECK_EQ(0, ret.user_extras_bytes_size());
        CHECK_EQ(2, ret.item_cnt());
    }

    // 非LTR样本，user特征配进item_extra里，会复制batch遍作为item特征
    TEST_CASE("test_to_extractor_response_z5") {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811,10812,10813,10814,10815,10816"
                    labels="cvr_label_1,cvr_label_2"
                    weights="cvr_weights_1,cvr_weights_2,cvr_weights_3"
                    item_extras_int64="media_id"
                    item_extras_float="dtr"
                    item_extras_bytes="oaid"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812"
                    slot="10812"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                    />
                <feature name="10813"
                    slot="10813"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.creative_id"
                    />
                <feature name="10814"
                    slot="10814"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.conv_type"
                    />
                <feature name="10815"
                    slot="10815"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="10816"
                    slot="10816"
                    attr="cross"
                    type="seq_hit_sum"
                    source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,item_info.appid"
                    start="0"
                    default_value="-2"
                    />

                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            attr="item"
                            source=".user_action.user_action_item_info.sdk_lahuo_conversion_rate" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_lahuo_conversion_rate" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="cvr_weights_3" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_register_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        attr="user"
                        source=".fe_request.req_id"
                    />
                <feature name="dtr"
                    type="direct_to_feature" 
                    attr="user"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                    />
                <feature name="oaid"
                    type="direct_to_feature" 
                    attr="user"
                        source=".user_action.oaid"
                    />
                <feature name="media_id"
                    type="direct_to_feature" 
                    attr="user"
                    source=".user_action.media_id"
                />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // req_time
        fe_request->set_req_time((int64_t) 500);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(100);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(200);

        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info()->set_dtr(0.1);
        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info()->set_dtr(0.2);

        fe_request->set_req_id("reqid0001");

        // item_info
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea->mutable_item_info()->set_creative_id(10);
        item_fea->mutable_item_info()->set_conv_type(20);
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");
        item_fea->mutable_item_info()->set_creative_id(11);
        item_fea->mutable_item_info()->set_conv_type(21);
        item_fea->mutable_item_info()->set_appid(10002);

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action.set_oaid("001");
        user_action.set_media_id(688);
        user_action.set_query("test_query_1");
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info->set_api_register_conversion_rate(0.15);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        item_info->set_api_register_conversion_rate(0.25);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_extractor_response(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(0, ret.user_extras_int64_size());
        CHECK_EQ(0, ret.user_extras_float_size());
        CHECK_EQ(0, ret.user_extras_bytes_size());
        CHECK_EQ(2, ret.item_cnt());
        CHECK_EQ(2, ret.item_extras_bytes_size());
        CHECK_EQ(2, ret.item_extras_int64_size());
        CHECK_EQ(2, ret.item_extras_float_size());

        TEST_BATCH_EXTRA_FEATURES_INT64(0, "media_id", ({{688}, {688}}), ret.item_extras_int64());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "dtr", ({{0.1, 0.2}, {0.1, 0.2}}), ret.item_extras_float());
        TEST_BATCH_EXTRA_FEATURES_STR(0, "oaid", ({{"001"}, {"001"}}), ret.item_extras_bytes());
    }

    // 精排和粗排样本，都不允许user_extra中配置item特征，由于精排样本不允许使用user_extra，这里只测试粗排样本
    // 报错信息：ERROR: test case THREW exception: fill_extra_feature src/framework.cc 2623:expect user feature, but config attr_type is item/cross: cvr_weights_1
    TEST_CASE("test_to_extractor_response_z6" * doctest::skip()) {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811,10812,10813,10814,10815,10816"
                    user_extras_int64="cvr_weights_1"
                    user_extras_float="ad_group_id"
                    user_extras_bytes="rta_id"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812"
                    slot="10812"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                    />
                <feature name="10813"
                    slot="10813"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.creative_id"
                    />
                <feature name="10814"
                    slot="10814"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.conv_type"
                    />
                <feature name="10815"
                    slot="10815"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="10816"
                    slot="10816"
                    attr="cross"
                    type="seq_hit_sum"
                    source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,item_info.appid"
                    start="0"
                    default_value="-2"
                    />

                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            attr="item"
                            source=".user_action.user_action_item_info.sdk_lahuo_conversion_rate" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_lahuo_conversion_rate" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="cvr_weights_3" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_register_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        attr="user"
                        source=".fe_request.req_id"
                    />
                <feature name="dtr"
                    type="direct_to_feature" 
                    attr="user"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                    />
                <feature name="rta_id"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="ad_group_id"
                    type="direct_to_feature" 
                    attr="item"
                        source=".user_action.user_action_item_info.ad_group_id"
                    />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // req_time
        fe_request->set_req_time((int64_t) 500);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(100);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(200);

        fe_request->set_req_id("reqid0001");

        // 用于计算batch_size
        fe_request->add_prerank_item_fea();
        fe_request->add_prerank_item_fea();

        // item_info
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea->mutable_item_info()->set_creative_id(10);
        item_fea->mutable_item_info()->set_conv_type(20);
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");
        item_fea->mutable_item_info()->set_creative_id(11);
        item_fea->mutable_item_info()->set_conv_type(21);
        item_fea->mutable_item_info()->set_appid(10002);

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action.set_query("test_query_1");
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info->set_api_register_conversion_rate(0.15);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        item_info->set_api_register_conversion_rate(0.25);

        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_extractor_response_ltr(fe_request_str.c_str(), fe_request_str.size(),
                                                       user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(0, ret.user_extras_int64_size());
        CHECK_EQ(0, ret.user_extras_float_size());
        CHECK_EQ(0, ret.user_extras_bytes_size());
        CHECK_EQ(2, ret.item_cnt());
        CHECK_EQ(2, ret.item_extras_bytes_size());
        CHECK_EQ(2, ret.item_extras_int64_size());
        CHECK_EQ(2, ret.item_extras_float_size());

        TEST_BATCH_EXTRA_FEATURES_INT64(0, "media_id", ({{688}, {688}}), ret.item_extras_int64());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "dtr", ({{0.1, 0.2}, {0.1, 0.2}}), ret.item_extras_float());
        TEST_BATCH_EXTRA_FEATURES_STR(0, "oaid", ({{"001"}, {"001"}}), ret.item_extras_bytes());
    }

    // 输入全部为空，输出为空
    TEST_CASE("test_seq_arithmetic_z1") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_arithmetic"
                        attr="user"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.event_time"
                        math_type="-"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        // auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        // user_behavior_info->set_app_id(179797980);
        // user_behavior_info->set_event_time(179797970);

        // user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        // user_behavior_info->set_app_id(179797992);
        // user_behavior_info->set_event_time(179797972);

        // user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        // user_behavior_info->set_app_id(179797988);
        // user_behavior_info->set_event_time(179797977);
        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();

        const auto ret_str = to_extractor_response(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);
        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({}), ret.user_features(0));
        CHECK_EQ(1, ret.item_cnt());
    }

    // 输入中一个序列为空另一个序列不为空，报错长度不一致
    // 报错信息：ERROR: test case THREW exception: compute phx-fe/config/phx_config_seq.cc 4419:input0 kind case = 0input1 kind case 3; not match!
    TEST_CASE("test_seq_arithmetic_z2" * doctest::skip()) {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_arithmetic"
                        attr="user"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name"
                        math_type="*"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        // auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        // user_behavior_info->set_app_id(179797980);
        // user_behavior_info->set_event_time(179797970);

        // user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        // user_behavior_info->set_app_id(179797992);
        // user_behavior_info->set_event_time(179797972);

        // user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        // user_behavior_info->set_app_id(179797988);
        // user_behavior_info->set_event_time(179797977);
        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime();
        auto *user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_name(8);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();

        const auto ret_str = to_extractor_response(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);
        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({}), ret.user_features(0));
        CHECK_EQ(1, ret.item_cnt());
    }

    // 两个item特征，使用乘法，其中一个序列没赋值会使用默认值进行计算
    TEST_CASE("test_seq_arithmetic_z3") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_arithmetic"
                        attr="item"
                        source=".fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.appid"
                        math_type="*"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        auto item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_creative_id(10001);
        item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_appid(10001);
        item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_creative_id(2);
        item_info->set_appid(10001);
        // auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        // user_behavior_info->set_app_id(179797980);
        // user_behavior_info->set_event_time(179797970);

        // user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        // user_behavior_info->set_app_id(179797992);
        // user_behavior_info->set_event_time(179797972);

        // user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        // user_behavior_info->set_app_id(179797988);
        // user_behavior_info->set_event_time(179797977);
        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime();
        auto *user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_name(8);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();

        const auto ret_str = to_extractor_response(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);
        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(3, ret.item_cnt());
        TEST_BATCH_SLOT_FEATURES_INT64(0, 10811, ({{0}, {0}, {20002}}), ret.item_features())
    }

    // 序列使用加法，int和float类型进行计算，类型不一致报错
    // 报错信息：ERROR: test case THREW exception: compute phx-fe/config/phx_config_seq.cc 4419:input0 kind case = 3input1 kind case 2; not match!
    TEST_CASE("test_seq_arithmetic_z4" * doctest::skip()) {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_arithmetic"
                        attr="user"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                        math_type="+"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();
        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(10001);
        user_behavior_info->set_event_time(179797970);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(10002);
        user_behavior_info->set_event_time(179797972);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(10003);
        user_behavior_info->set_event_time(179797977);

        auto *user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.8);
        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.8);
        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.0);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();

        const auto ret_str = to_extractor_response(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);
        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(1, ret.item_cnt());
        // TEST_BATCH_SLOT_FEATURES_FLOAT(0, 10811, ({{10001.8}, {10003.8}, {10003.0}}), ret.user_features())
        TEST_SLOT_FEATURE_FLOAT(10811, ({10001.8, 10003.8, 10003.0}), ret.user_features(0))
    }

    // 序列使用加法，user序列长度不一致报错
    // 报错信息：ERROR: test case THREW exception: compute phx-fe/config/phx_config_seq.cc 4424:input0's values size != input1's values size
    TEST_CASE("test_seq_arithmetic_z5" * doctest::skip()) {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_arithmetic"
                        attr="user"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name"
                        math_type="+"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();
        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(10001);
        user_behavior_info->set_event_time(179797970);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(10002);
        user_behavior_info->set_event_time(179797972);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(10003);
        user_behavior_info->set_event_time(179797977);

        auto *user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_name(8);
        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_name(1);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();

        const auto ret_str = to_extractor_response(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);
        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        // CHECK_EQ(1, ret.item_cnt());
        // TEST_BATCH_SLOT_FEATURES_FLOAT(0, 10811, ({{10001.8}, {10003.8}, {10003.0}}), ret.user_features())
        // TEST_SLOT_FEATURE_INT64(10811, ({10009, 10003, 10003}), ret.user_features(0))
    }

    // day_n=1，start=864000，由于防穿越日期大于day_n，导致输出为空
    TEST_CASE("test_seq_filter_z1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.context.adunit_id" 
                    clip_size="3"
                    start = "864000"
                    day_n = "1"
                    filters = "int64_filter:864000001,864000000" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000 + 1);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 11 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 11 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86401 * 1000 + 1);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({}), ret.user_features(0));
        TEST_FEATURE_INT64(({}), ret.user_features(1));
        TEST_FEATURE_INT64(({}), ret.user_features(2));
    }

    // 使用float过滤配置，结果按照eventTime从大到小排序
    TEST_CASE("test_seq_filter_z2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.context.adunit_id" 
                    clip_size="3"
                    start = "86400"
                    day_n = "10"
                    filters = "float_filter:0.6,0.2" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000 + 1);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();
        auto user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.2);
        user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.6);
        user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.6);
        user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.6);
        user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(99.9);
        user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.0);

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 6 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 6 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86401 * 1000 + 1);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({104436666, 104435568}), ret.user_features(0));
        TEST_FEATURE_INT64(({(int64_t) 6 * 86400 * 1000, (int64_t) 5 * 86400 * 1000}), ret.user_features(1));
        TEST_FEATURE_INT64(({104435568, 104435568}), ret.user_features(2));
    }

    // 使用str过滤配置，结果按照eventTime从大到小排序
    TEST_CASE("test_seq_filter_z3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_app_seq_ad_app_payment_offline.ad_user_app_pay_seq.request_id,.fe_request.context.adunit_id" 
                    clip_size="3"
                    start = "86400"
                    day_n = "10"
                    filters = "str_filter:0.6,0.2" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000 + 1);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();
        auto ad_user_app_pay_seq = fe_request.mutable_ad_user_app_seq_ad_app_payment_offline()->add_ad_user_app_pay_seq();
        ad_user_app_pay_seq->set_request_id("0.6");
        ad_user_app_pay_seq = fe_request.mutable_ad_user_app_seq_ad_app_payment_offline()->add_ad_user_app_pay_seq();
        ad_user_app_pay_seq->set_request_id("0.2");
        ad_user_app_pay_seq = fe_request.mutable_ad_user_app_seq_ad_app_payment_offline()->add_ad_user_app_pay_seq();
        ad_user_app_pay_seq->set_request_id("88");
        ad_user_app_pay_seq = fe_request.mutable_ad_user_app_seq_ad_app_payment_offline()->add_ad_user_app_pay_seq();
        ad_user_app_pay_seq->set_request_id("9");
        ad_user_app_pay_seq = fe_request.mutable_ad_user_app_seq_ad_app_payment_offline()->add_ad_user_app_pay_seq();
        ad_user_app_pay_seq->set_request_id("001");
        ad_user_app_pay_seq = fe_request.mutable_ad_user_app_seq_ad_app_payment_offline()->add_ad_user_app_pay_seq();
        ad_user_app_pay_seq->set_request_id("p");

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 6 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 6 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86401 * 1000 + 1);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({104436666, 104435568}), ret.user_features(0));
        TEST_FEATURE_INT64(({(int64_t) 6 * 86400 * 1000, (int64_t) 5 * 86400 * 1000}), ret.user_features(1));
        TEST_FEATURE_INT64(({104435568, 104435568}), ret.user_features(2));
    }

    // float类型的source被错误配置为int64_filter，报错
    // 报错信息：ERROR: test case THREW exception: CHECK failed: (index) < (current_size_): 
    TEST_CASE("test_seq_filter_z4" * doctest::skip()) {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.context.adunit_id" 
                    clip_size="3"
                    start = "86400"
                    day_n = "10"
                    filters = "int64_filter:0.6,0.2" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000 + 1);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();
        auto user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.2);
        user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.6);
        user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.6);
        user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.6);
        user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(99.9);
        user_ads_stats_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.0);

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 6 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 6 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86401 * 1000 + 1);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({104436666, 104435568}), ret.user_features(0));
        TEST_FEATURE_INT64(({(int64_t) 6 * 86400 * 1000, (int64_t) 5 * 86400 * 1000}), ret.user_features(1));
        TEST_FEATURE_INT64(({104435568, 104435568}), ret.user_features(2));
    }

    // 使用超出边界的source值作为filter配置，报错
    // 报错信息：ERROR: test case THREW exception: get_value ./phx-fe/config/config.h 102:input size:6,6,index:100,name:10812
    TEST_CASE("test_seq_filter_z5" * doctest::skip()) {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.context.adunit_id" 
                    clip_size="3"
                    start = "86400"
                    day_n = "10"
                    filters = "int64_filter:${source[100]}" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000 + 1);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 6 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 6 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86401 * 1000 + 1);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({104436666, 104435568}), ret.user_features(0));
        TEST_FEATURE_INT64(({(int64_t) 6 * 86400 * 1000, (int64_t) 5 * 86400 * 1000}), ret.user_features(1));
        TEST_FEATURE_INT64(({104435568, 104435568}), ret.user_features(2));
    }

    // 配置多个过滤条件，同时使用值和source作为filter，过滤两个序列，配置clip_size=2
    TEST_CASE("test_seq_filter_z6") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.last_event_time,.fe_request.context.adunit_id" 
                    clip_size="2"
                    start = "86400"
                    day_n = "10"
                    filters = "int64_filter:${source[6]};int64_filter:864000001,864000000" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000 + 1);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 7 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);
        pb_info->set_last_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 7 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);
        pb_info->set_last_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 5 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 11 * 86400 * 1000 + 1);
        pb_info->set_last_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 8 * 86401 * 1000 + 1);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);
        pb_info->set_last_event_time((int64_t) 11 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);
        pb_info->set_last_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);
        pb_info->set_last_event_time((int64_t) 10 * 86400 * 1000 + 1);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({104435568, 104436666}), ret.user_features(0));
        TEST_FEATURE_INT64(({(int64_t) 7 * 86400 * 1000, (int64_t) 7 * 86400 * 1000}), ret.user_features(1));
        TEST_FEATURE_INT64(({104435568, 104435568}), ret.user_features(2));
    }

    // 参数使用默认值
    TEST_CASE("test_seq_filter_z7") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.context.adunit_id" 
                    filters = "int64_filter:${source[5]}" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000 + 1);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 7 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 15 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 8 * 86401 * 1000 + 1);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({104435568, 900778570}), ret.user_features(0));
        TEST_FEATURE_INT64(({(int64_t) 7 * 86400 * 1000, (int64_t) 1 * 86404 * 1000}), ret.user_features(1));
        TEST_FEATURE_INT64(({104435568, 900778570}), ret.user_features(2));
    }

    // 输出的备选值部分字段未传值，会使用默认值
    TEST_CASE("test_seq_filter_z8") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.context.adunit_id" 
                    filters = "int64_filter:${source[5]}" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000 + 1);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(104435568);
        // pb_info->set_event_time((int64_t) 7 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 15 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 1 * 86404 * 1000);
        // pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 8 * 86401 * 1000 + 1);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({900778570, 104435568}), ret.user_features(0));
        TEST_FEATURE_INT64(({(int64_t) 1 * 86404 * 1000, (int64_t) 0}), ret.user_features(1));
        TEST_FEATURE_INT64(({0, 104435568}), ret.user_features(2));
    }
}