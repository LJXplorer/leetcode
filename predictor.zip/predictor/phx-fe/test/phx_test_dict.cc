#include "common/comm/debug_utils.h"
#include "phx-fe/src/service.h"
#include "phx-fe/util/mock_utils.h"
#include "phx_test.h"

TEST_SUITE("phx-dict") {

#if 1
    TEST_CASE("query_dict") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="app_info" value="10810,10811,10812,10813,10820,10821" />
        </versions>
        <config>
            <dict name="app_info"
                path="phx-fe/dict_test_data/appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
             />
            <dict name="ad_info"
                path="phx-fe/dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
                />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10810"
                    type="query_dict"
                    slot="10810"
                    dict_name="app_info"
                    output_fields="package_name"
                    source="item_info.creative_id"
                    default_int64_value="1700000000000"
                    default_float_value="-1.11f"
                    default_string_value="null" />
                <feature name="10820_10821"
                    type="query_dict"
                    dict_name="app_info"
                    output_fields="first_class,third_class_id"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    default_int64_value="1700000000000"
                    default_float_value="-1.11f"
                    default_string_value="null" />
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812"
                    slot="10812"
                    type="direct_to_feature"
                    source=".user_action.user_action_item_info.creative_id"
                    />
                <feature name="10813"
                    slot="10813"
                    type="direct_to_feature"
                    source=".user_action.algo_id"
                    />
                <feature name = "10820"
                    slot="10820"
                    type="direct_to_feature"
                    source="10820_10821:0"
                    />
                <feature name = "10821"
                    slot="10821"
                    type="direct_to_feature"
                    source="10820_10821:1"
                    />

            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1113);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1114);
        ad_user_app_info->set_count(20);

        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20001);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20002);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20003);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
        item_fea->mutable_item_info()->set_creative_id(1110);
        item_fea->mutable_item_info()->set_ocpx_sbp(2);
        item_fea->mutable_item_info()->set_data_source(7);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(8);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("236");
        item_fea->mutable_item_info()->set_creative_id(1112);
        item_fea->mutable_item_info()->set_ocpx_sbp(10);
        item_fea->mutable_item_info()->set_data_source(0);
        mocker::FillProto(fe_request);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        user_action.set_adunit_id(17088784918);
        user_action.set_algo_id("mock_algo_id");
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(700001);
        item_info->set_creative_id(60000001);

        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(700002);
        item_info->set_creative_id(60000002);

        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(700003);
        item_info->set_creative_id(60000003);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);
        std::cout << "batch training sample = " << training_sample.DebugString();
        // 10810,测试item的appid查询
        {
            for (int i = 0; i < 3; i++) {
                CHECK_EQ(training_sample.training_samples(i).features(0).slot_id(), 10810);
                TEST_FEATURE_STR(({"com.wx.mm"}), training_sample.training_samples(i).features(0));
            }
        }
        // 10811,测试user特征
        {
            for (int i = 0; i < 3; i++) {
                CHECK_EQ(training_sample.training_samples(i).features(1).slot_id(), 10811);
                TEST_FEATURE_INT64(({1113, 1114}), training_sample.training_samples(i).features(1));
            }
        }

        // 10812,测试user action的item特征
        {
            CHECK_EQ(training_sample.training_samples(0).features(2).slot_id(), 10812);
            TEST_FEATURE_INT64(({60000001}), training_sample.training_samples(0).features(2));

            CHECK_EQ(training_sample.training_samples(1).features(2).slot_id(), 10812);
            TEST_FEATURE_INT64(({60000002}), training_sample.training_samples(1).features(2));

            CHECK_EQ(training_sample.training_samples(2).features(2).slot_id(), 10812);
            TEST_FEATURE_INT64(({60000003}), training_sample.training_samples(2).features(2));
        }

        // 10820,测试user特征的appid查询
        {
            for (const auto i: times(3)) {
                CHECK_EQ(training_sample.training_samples(i).features(4).slot_id(), 10820);
                TEST_FEATURE_STR(({"即时通讯", "即时通讯"}), training_sample.training_samples(i).features(4));
            }
        }

        // 10821,测试user特征的appid查询为空
        {
            for (const auto i: times(3)) {
                CHECK_EQ(training_sample.training_samples(i).features(5).slot_id(), 10821);
                TEST_FEATURE_INT64(({1700000000000, 1700000000000}), training_sample.training_samples(i).features(5))
                CHECK_EQ(training_sample.training_samples(i).features(5).signs_size(), 2);
                CHECK_EQ(training_sample.training_samples(i).features(5).weights_size(), 0);
                CHECK_EQ(training_sample.training_samples(i).features(5).bytes_list_size(), 0);
            }
        }
    }
#else
    TEST_CASE("query_dict_prerank") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="app_info_3" value="10810" />
        </versions>
        <config>
            <dict name="app_info_3"
                  path="phx-fe/dict_test_data/appinfo"
                  partition="{pt_d-1}"
                  value_proto="phx.AppInfoDict"
                  class_name="AppinfoDict"
            />
            <source name="item_info"
                value=".fe_request.prerank_item_fea.prerank_item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10810"
                    type="query_dict"
                    slot="10810"
                    dict_name="app_info_3"
                    output_fields="package_name"
                    source="item_info.creative_id"
                    default_int64_value="1700000000000"
                    default_float_value="-1.11f"
                    default_string_value="null"
                    attr="item" />

            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1113);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1114);
        ad_user_app_info->set_count(20);

        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20001);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20002);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20003);

        auto *item_fea = fe_request.add_prerank_item_fea();
        item_fea->mutable_prerank_item_info()->set_creative_id(1110);

        item_fea = fe_request.add_prerank_item_fea();
        item_fea->mutable_prerank_item_info()->set_creative_id(1111);

        item_fea = fe_request.add_prerank_item_fea();
        item_fea->mutable_prerank_item_info()->set_creative_id(1112);

        mocker::FillProto(fe_request);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        user_action.set_adunit_id(17088784918);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_ltr_training_sample_v2(
                fe_str.c_str(), fe_str.size(), user_action_str.c_str(), user_action_str.size(), config_handle);
        phx::LTRTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);
        std::cout << "LTR training sample = " << training_sample.DebugString();
    }
#endif

    TEST_CASE("adunit_dict") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="adunit_info" value="10810" />
        </versions>
        <config>
            <dict name="adunit_info"
                path="phx-fe/dict_test_data/adunitinfo"
                partition="{pt_d}"
                value_proto="phx.AdunitInfoDict"
                class_name="AdunitDict"
             />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10810"
                    type="query_dict"
                    slot="10810"
                    dict_name="adunit_info"
                    output_fields="media_id"
                    source="item_info.creative_id"
                    default_int64_value="1700000000000"
                    default_float_value="-1.11f"
                    default_string_value="null" />
            </features>
        </config>
    )";

        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_ptr->add_item_fea()->mutable_item_info()->set_creative_id(122455);
        mocker::FillProto(*fe_ptr);
        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction *user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action->SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(1, training_sample.training_samples_size());
        REQUIRE_EQ(1, training_sample.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10810, ({2223}), training_sample.training_samples(0).features(0));
    }

    TEST_CASE("query_dict_package_name_2_app_id") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="package_name_2_app_id" value="10810" />
        </versions>
        <config>
            <dict name="package_name_2_app_id"
                path="phx-fe/dict_test_data/packagename2appid"
                partition="{pt_d-1}"
                value_proto="phx.PackageName2AppIdInfoDict"
                class_name="PackageName2AppIdInfoDict"
             />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10810"
                    type="query_dict"
                    slot="10810"
                    dict_name="package_name_2_app_id"
                    output_fields="app_id"
                    source=".user_action.user_action_item_info.package_name"
                    default_int64_value="1700000000000"
                    default_float_value="-1.11f"
                    default_string_value="null" />
            </features>
        </config>
    )";

        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_ptr->add_item_fea();
        mocker::FillProto(*fe_ptr);
        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction *user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action->add_user_action_item_info()->set_package_name("pkg_1");

        auto user_action_str = user_action->SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(1, training_sample.training_samples_size());
        REQUIRE_EQ(1, training_sample.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10810, ({1000}), training_sample.training_samples(0).features(0));
    }

    TEST_CASE("query_dict_default_value") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="app_info_2" value="10810" />
        </versions>
        <config>
            <dict name="app_info_2"
                path="phx-fe/dict_test_data/appinfoempty"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
             />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10810"
                    type="query_dict"
                    slot="10810"
                    dict_name="app_info_2"
                    output_fields="package_name"
                    source="item_info.creative_id"
                    default_int64_value="-999999999"
                    default_float_value="-9.9999999f"
                    default_string_value="-999999999" />
            </features>
        </config>
    )";

        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("124");
        mocker::FillProto(*fe_request);
        auto fe_str = fe_request->SerializeAsString();

        phx::UserAction *user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action->SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        std::cout << training_sample.DebugString() << std::endl;

        REQUIRE_EQ(1, training_sample.training_samples_size());
        REQUIRE_EQ(1, training_sample.training_samples(0).features_size());
        TEST_SLOT_FEATURE_STR(10810, ({"-999999999"}), training_sample.training_samples(0).features(0));
    }

    TEST_CASE("query_dict_default_value_2") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="package_name_2_app_id_2" value="10810" />
        </versions>
        <config>
            <dict name="package_name_2_app_id_2"
                path="phx-fe/dict_test_data/packagename2appidempty"
                partition="{pt_d-1}"
                value_proto="phx.PackageName2AppIdInfoDict"
                class_name="PackageName2AppIdInfoDict"
             />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10810"
                    type="query_dict"
                    slot="10810"
                    dict_name="package_name_2_app_id_2"
                    output_fields="app_id"
                    source=".user_action.user_action_item_info.package_name"
                    default_int64_value="-999999999"
                    default_float_value="-9.9999999f"
                    default_string_value="-999999999" />
            </features>
        </config>
    )";

        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_ptr->add_item_fea();
        mocker::FillProto(*fe_ptr);
        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction *user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action->add_user_action_item_info()->set_package_name("pkg_1");

        auto user_action_str = user_action->SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(1, training_sample.training_samples_size());
        REQUIRE_EQ(1, training_sample.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10810, ({-999999999}), training_sample.training_samples(0).features(0));
    }

#if 1
    TEST_CASE("segment_1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="jieba" value="20001" />
            </versions>
            <config>
                <dict name="jieba"
                    path="phx-fe/dict_test_data/jieba_dict"
                    partition=""
                    value_proto=""
                    class_name="JieBaDict"
                 />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="20001"
                        type="segment"
                        source=".fe_request.item_fea.item_info.rta_id"
                        slot="20001"
                        dict_name="jieba" />
                </features>
            </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        CHECK_NE(handle, 0l);

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        auto item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("他来到了网易杭研大厦");
        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("我来自北京邮电大学。");
        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("我来自北京邮电大学。。。学号123456，用AK47");
        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        user_action.set_adunit_id(17088784918);
        user_action.set_algo_id("mock_algo_id");
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(700001);
        item_info->set_creative_id(60000001);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);
        std::cout << "batch training sample = " << debug::printer::ToString(training_sample);

        TEST_FEATURE_STR(({"他", "来到", "了", "网易", "杭研", "大厦"}),
                         training_sample.training_samples(0).features(0));
        TEST_FEATURE_STR(({"我", "来自", "北京邮电大学", "。"}), training_sample.training_samples(1).features(0));
        TEST_FEATURE_STR(({"我", "来自", "北京邮电大学", "。", "。", "。", "学号", "123456", "，", "用", "AK47"}),
                         training_sample.training_samples(2).features(0));
    }
#else
    TEST_CASE("segment_2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="jieba" value="20001" />
            </versions>
            <config>
                <dict name="jieba"
                    path="phx-fe/dict_test_data/jieba_dict"
                    partition=""
                    value_proto=""
                    class_name="JieBaDict"
                 />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="20001"
                        type="segment"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id"
                        slot="20001"
                        dict_name="jieba" />
                </features>
            </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        CHECK_NE(handle, 0l);

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        auto item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("他来到了网易杭研大厦");
        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("我来自北京邮电大学。");
        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("我来自北京邮电大学。。。学号123456，用AK47");

        fe_request.mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id(
                "令狐冲是云计算行业的专家");
        fe_request.mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id(
                "我是拖拉机学院手扶拖拉机专业的");
        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        user_action.set_adunit_id(17088784918);
        user_action.set_algo_id("mock_algo_id");
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(700001);
        item_info->set_creative_id(60000001);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);
        for (const auto &str: training_sample.training_samples(0).features(0).bytes_list()) {
            std::cout << str << ",";
        }
        std::cout << "\n";
        TEST_FEATURE_STR(({"令狐冲", "是", "云计算", "行业", "的", "专家", "我", "是", "拖拉机", "学院", "手扶拖拉机",
                           "专业", "的"}),
                         training_sample.training_samples(0).features(0));
    }
#endif

    TEST_CASE("query_stats_dict") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="ad_stat_info" value="10810,10820,10821" />
        </versions>
        <config>
            <dict name="ad_stat_info"
                  path="phx-fe/dict_test_data/adstatinfo"
                  partition="{pt_d-1}"
                  value_proto="phx.AdStatDict"
                  class_name="AdStatDict"
            />
            <source name="item_info" value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10810"
                         type="query_stats_dict"
                         slot="10810"
                         dict_name="ad_stat_info"
                         output_fields="first_intent_type_cross_adunit_stats_14d.ratio_download"
                         source="item_info.rta_id"
                         keys="${source[0]}"
                         types="creative_id"
                         default_int64_value="1700000000000"
                         default_float_value="-1.11f"
                         default_string_value="null" />
                <feature name="10820_10821"
                         type="query_stats_dict"
                         slot="10820_10821"
                         dict_name="ad_stat_info"
                         output_fields="adgroup_stats_14d.num_click,app_stats_14d.num_click"
                         source="item_info.rta_id"
                         keys="${source[0]},demo"
                         types="first_type_id,adunit_id"
                         default_int64_value="1700000000000"
                         default_float_value="-1.11f"
                         default_string_value="null" />
                <feature name = "10820"
                         slot="10820"
                         type="direct_to_feature"
                         source="10820_10821:0" />
                <feature name = "10821"
                         slot="10821"
                         type="direct_to_feature"
                         source="10820_10821:1" />
            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_ptr->add_item_fea()->mutable_item_info()->set_rta_id("abc");
        fe_ptr->add_item_fea()->mutable_item_info()->set_rta_id("ghi");
        mocker::FillProto(*fe_ptr);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        CHECK_EQ(training_sample.training_samples(0).features(0).slot_id(), 10810);
        CHECK(doctest::Approx(0).epsilon(0.001) == training_sample.training_samples(0).features(0).weights(0));

        CHECK_EQ(training_sample.training_samples(0).features(1).slot_id(), 10820);
        TEST_FEATURE_INT64(({1700000000000}), training_sample.training_samples(0).features(1));

        CHECK_EQ(training_sample.training_samples(0).features(2).slot_id(), 10821);
        TEST_FEATURE_INT64(({1700000000000}), training_sample.training_samples(0).features(2));

        CHECK_EQ(training_sample.training_samples(1).features(0).slot_id(), 10810);
        CHECK(doctest::Approx(-1.11).epsilon(0.001) == training_sample.training_samples(1).features(0).weights(0));

        CHECK_EQ(training_sample.training_samples(1).features(1).slot_id(), 10820);
        TEST_FEATURE_INT64(({2002}), training_sample.training_samples(1).features(1));

        CHECK_EQ(training_sample.training_samples(1).features(2).slot_id(), 10821);
        TEST_FEATURE_INT64(({3002}), training_sample.training_samples(1).features(2));
    }

#if 0
    TEST_CASE("query_stats_dict_2") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="ad_query_cross_app_info" value="10810,10820,10821" />
        </versions>
        <config>
            <dict name="ad_query_cross_app_info"
                  path="phx-fe/dict_test_data/ad_query_app_cross_stat"
                  partition="{pt_d-1}"
                  value_proto="phx.AdQueryCrossAppInfoDict"
                  class_name="AdQueryCrossAppInfoDict"
            />
            <source name="item_info" value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10810"
                         type="query_stats_dict"
                         slot="10810"
                         dict_name="ad_query_cross_app_info"
                         output_fields="query_appid_info.expose_num"
                         source="item_info.rta_id"
                         keys="${source[0]}"
                         types="creative_id"
                         default_int64_value="1700000000000"
                         default_float_value="-1.11f"
                         default_string_value="null" />
                <feature name="10820_10821"
                         type="query_stats_dict"
                         slot="10820_10821"
                         dict_name="ad_query_cross_app_info"
                         output_fields="query_appid_info.expose_num,query_appid_info.ecpm"
                         source="item_info.rta_id"
                         keys="${source[0]},demo"
                         types="first_type_id,adunit_id"
                         default_int64_value="1700000000000"
                         default_float_value="-1.11f"
                         default_string_value="null" />
                <feature name = "10820"
                         slot="10820"
                         type="direct_to_feature"
                         source="10820_10821:0" />
                <feature name = "10821"
                         slot="10821"
                         type="direct_to_feature"
                         source="10820_10821:1" />
            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_ptr->add_item_fea()->mutable_item_info()->set_rta_id("abc");
        fe_ptr->add_item_fea()->mutable_item_info()->set_rta_id("ghi");
        mocker::FillProto(*fe_ptr);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(2, training_sample.training_samples_size());
        REQUIRE_EQ(3, training_sample.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10810, {10}, training_sample.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10820, {1700000000000}, training_sample.training_samples(0).features(1));
        CHECK_EQ(10821, training_sample.training_samples(0).features(2).slot_id());
        CHECK(doctest::Approx(-1.11f).epsilon(0.001) == training_sample.training_samples(0).features(2).weights(0));

        REQUIRE_EQ(3, training_sample.training_samples(1).features_size());
        TEST_SLOT_FEATURE_INT64(10810, {1700000000000}, training_sample.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10820, {12}, training_sample.training_samples(1).features(1));
        CHECK_EQ(10821, training_sample.training_samples(1).features(2).slot_id());
        CHECK(doctest::Approx(8.154).epsilon(0.001) == training_sample.training_samples(1).features(2).weights(0));
    }
#elif 0
    TEST_CASE("query_stats_dict_3") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="ad_query_cross_app_info" value="10820,10821" />
        </versions>
        <config>
            <dict name="ad_query_cross_app_info"
                  path="phx-fe/dict_test_data/ad_query_app_cross_stat"
                  partition="{pt_d-1}"
                  value_proto="phx.AdQueryCrossAppInfoDict"
                  class_name="AdQueryCrossAppInfoDict"
            />
            <source name="item_info" value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10820_10821"
                         type="query_stats_dict"
                         slot="10820_10821"
                         dict_name="ad_query_cross_app_info"
                         output_fields="query_appid_info.expose_num,query_appid_info.ecpm"
                         source="item_info.rta_id"
                         keys="${source[0]},4"
                         types="app_id,advertiser_id"
                         default_int64_value="1700000000000"
                         default_float_value="-1.11f"
                         default_string_value="null" />
                <feature name = "10820"
                         slot="10820"
                         type="direct_to_feature"
                         source="10820_10821:0" />
                <feature name = "10821"
                         slot="10821"
                         type="direct_to_feature"
                         source="10820_10821:1" />
            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_ptr->add_item_fea()->mutable_item_info()->set_rta_id("abc");
        fe_ptr->add_item_fea()->mutable_item_info()->set_rta_id("ghi");
        mocker::FillProto(*fe_ptr);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(2, training_sample.training_samples_size());
        REQUIRE_EQ(2, training_sample.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10820, {1700000000000}, training_sample.training_samples(0).features(0));
        CHECK_EQ(10821, training_sample.training_samples(0).features(1).slot_id());
        CHECK(doctest::Approx(-1.11f).epsilon(0.001) == training_sample.training_samples(0).features(1).weights(0));

        REQUIRE_EQ(2, training_sample.training_samples(1).features_size());
        TEST_SLOT_FEATURE_INT64(10820, {12}, training_sample.training_samples(1).features(0));
        CHECK_EQ(10821, training_sample.training_samples(1).features(1).slot_id());
        CHECK(doctest::Approx(8.154).epsilon(0.001) == training_sample.training_samples(1).features(1).weights(0));
    }
#elif 0
    // 创意交叉广告位类型
    TEST_CASE("query_stats_dict_4") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="ad_query_cross_app_info" value="10820,10821" />
        </versions>
        <config>
            <dict name="ad_query_cross_app_info"
                  path="phx-fe/dict_test_data/ad_query_app_cross_stat"
                  partition="{pt_d-1}"
                  value_proto="phx.AdQueryCrossAppInfoDict"
                  class_name="AdQueryCrossAppInfoDict"
            />
            <source name="item_info" value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10820_10821"
                         type="query_stats_dict"
                         slot="10820_10821"
                         dict_name="ad_query_cross_app_info"
                         output_fields="query_appid_info.expose_num,query_appid_info.ecpm"
                         source="item_info.rta_id"
                         keys="${source[0]},4"
                         types="creative_id,ad_unit_type"
                         default_int64_value="1700000000000"
                         default_float_value="-1.11f"
                         default_string_value="null" />
                <feature name = "10820"
                         slot="10820"
                         type="direct_to_feature"
                         source="10820_10821:0" />
                <feature name = "10821"
                         slot="10821"
                         type="direct_to_feature"
                         source="10820_10821:1" />
            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_ptr->add_item_fea()->mutable_item_info()->set_rta_id("abc");
        fe_ptr->add_item_fea()->mutable_item_info()->set_rta_id("ghi");
        mocker::FillProto(*fe_ptr);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(2, training_sample.training_samples_size());
        REQUIRE_EQ(2, training_sample.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10820, {1700000000000}, training_sample.training_samples(0).features(0));
        CHECK_EQ(10821, training_sample.training_samples(0).features(1).slot_id());
        CHECK(doctest::Approx(-1.11f).epsilon(0.001) == training_sample.training_samples(0).features(1).weights(0));

        REQUIRE_EQ(2, training_sample.training_samples(1).features_size());
        TEST_SLOT_FEATURE_INT64(10820, {12}, training_sample.training_samples(1).features(0));
        CHECK_EQ(10821, training_sample.training_samples(1).features(1).slot_id());
        CHECK(doctest::Approx(8.154).epsilon(0.001) == training_sample.training_samples(1).features(1).weights(0));
    }
#elif 1
    // app交叉广告位类型交叉运行平台维度
    TEST_CASE("query_stats_dict_5") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="ad_query_cross_app_info" value="10820,10821" />
        </versions>
        <config>
            <dict name="ad_query_cross_app_info"
                  path="phx-fe/dict_test_data/ad_query_app_cross_stat"
                  partition="{pt_d-1}"
                  value_proto="phx.AdQueryCrossAppInfoDict"
                  class_name="AdQueryCrossAppInfoDict"
            />
            <source name="item_info" value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10820_10821"
                         type="query_stats_dict"
                         slot="10820_10821"
                         dict_name="ad_query_cross_app_info"
                         output_fields="query_appid_info.expose_num,query_appid_info.ecpm"
                         source="item_info.rta_id,.user_action.request_id,.fe_request.req_id"
                         keys="${source[0]},${source[1]},${source[2]}"
                         types="app_id,ad_unit_type,ads_run_plt"
                         default_int64_value="1700000000000"
                         default_float_value="-1.11f"
                         default_string_value="null" />
                <feature name = "10820"
                         slot="10820"
                         type="direct_to_feature"
                         source="10820_10821:0" />
                <feature name = "10821"
                         slot="10821"
                         type="direct_to_feature"
                         source="10820_10821:1" />
            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_ptr->add_item_fea()->mutable_item_info()->set_rta_id("def");
        fe_ptr->set_req_id("7");
        mocker::FillProto(*fe_ptr);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action.set_request_id("4");
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(1, training_sample.training_samples_size());
        REQUIRE_EQ(2, training_sample.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10820, {13}, training_sample.training_samples(0).features(0));
        CHECK_EQ(10821, training_sample.training_samples(0).features(1).slot_id());
        CHECK(doctest::Approx(10.872).epsilon(0.001) == training_sample.training_samples(0).features(1).weights(0));
    }
#endif

    TEST_CASE("query_stats_dict_6") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="ad_query_stats" value="10820,10821" />
        </versions>
        <config>
            <dict name="ad_query_stats"
                  path="phx-fe/dict_test_data/ad_query_stats"
                  partition="{pt_d-1}"
                  value_proto="phx.AdQueryStatsInfoDict"
                  class_name="AdQueryStatsInfoDict"
            />
            <source name="item_info" value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10820_10821"
                         type="query_stats_dict"
                         slot="10820_10821"
                         dict_name="ad_query_stats"
                         output_fields="expose_num,ecpm"
                         source="item_info.rta_id,.fe_request.req_id"
                         keys="${source[0]},${source[1]}"
                         types="query,app_id"
                         default_int64_value="1700000000000"
                         default_float_value="-1.11f"
                         default_string_value="null" />
                <feature name = "10820"
                         slot="10820"
                         type="direct_to_feature"
                         source="10820_10821:0" />
                <feature name = "10821"
                         slot="10821"
                         type="direct_to_feature"
                         source="10820_10821:1" />
            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_ptr->add_item_fea()->mutable_item_info()->set_rta_id("qq音乐");
        fe_ptr->set_req_id("2762484");
        mocker::FillProto(*fe_ptr);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        std::cout << training_sample.DebugString() << std::endl;

        REQUIRE_EQ(1, training_sample.training_samples_size());
        REQUIRE_EQ(2, training_sample.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10820, {2811}, training_sample.training_samples(0).features(0));
        CHECK_EQ(10821, training_sample.training_samples(0).features(1).slot_id());
        CHECK(doctest::Approx(-1.11).epsilon(0.001) == training_sample.training_samples(0).features(1).weights(0));
    }

    TEST_CASE("game_stats_dict") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="game_stats_dict" value="10820,10821" />
        </versions>
        <config>
            <dict name="game_stats_dict"
                  path="phx-fe/dict_test_data/gamestatsdict"
                  partition="{pt_d-1}"
                  value_proto="phx.GameStatsDict"
                  class_name="GameStatsDict"
            />
            <source name="item_info" value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="query_stats_game_stats_dict"
                         type="query_stats_dict"
                         dict_name="game_stats_dict"
                         output_fields="cate2_apk_gamecenter_delivery_stats_30d.num_click,iap_app_gamecenter_payment_stasts_360d.num_payment"
                         source="item_info.rta_id"
                         keys="${source[0]},300"
                         types="first_type_id,adunit_id"
                         default_int64_value="1700000000000"
                         default_float_value="-1.11f"
                         default_string_value="null" />
                <feature name = "query_stats_game_stats_dict_num_download"
                         slot="10820"
                         type="direct_to_feature"
                         source="query_stats_game_stats_dict:0" />
                <feature name = "query_stats_game_stats_dict_num_payment"
                         slot="10821"
                         type="direct_to_feature"
                         source="query_stats_game_stats_dict:1" />
            </features>
        </config>
    )";

        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        auto *item_fea = fe_ptr->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("fghij");
        mocker::FillProto(*fe_ptr);
        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction *user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action->SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(1, training_sample.training_samples_size());
        REQUIRE_EQ(2, training_sample.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10820, ({240}), training_sample.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10821, ({15}), training_sample.training_samples(0).features(1));
    }
}

TEST_SUITE("query_custom_dict") {
    TEST_CASE("plaintext_kv_dict") {

        system("rm -r .tmp");
        system("mkdir .tmp");
        system("touch SUCCESS");
        system("touch _SUCCESS");
        system("mv SUCCESS _SUCCESS .tmp/");

        std::string task_info_content = R"(table_name,count,version
dm_aiad_jz.dm_ai_ad_jz_apprec_ad_stat_inc_d,387057,20250910/0000
)";
        std::ofstream task_info_file("./.tmp/_TASK_INFO");
        if (task_info_file.is_open()) {
            task_info_file.write(task_info_content.c_str(), task_info_content.size());
        } else {
            std::cout << "open task_info file failed.\n";
        }
        task_info_file.close();

        std::string dict_content{};
        dict_content.append("search_dtr_u_10001\tint64\t200,12,-90\n");
        dict_content.append("search_dtr_u_10002\tstring\talpha,beta,-90\n");
        std::string dict_file_path = "./.tmp/plaintext_kv_dict.txt";
        std::ofstream tmp_plaintext_kv_dict_file(dict_file_path);
        if (!tmp_plaintext_kv_dict_file.is_open()) {
            std::cout << "open file failed.\n";
        } else {
            tmp_plaintext_kv_dict_file.write(dict_content.c_str(), dict_content.size());
        }
        tmp_plaintext_kv_dict_file.close();

        AdDict::AdDictCollector dict_collector{};
        hidict::DictConfig dict_config{};
        dict_config.m_path = "./.tmp";
        dict_config.m_clazz = "PlaintextKvDict";
        dict_config.m_name = "plaintext_kv_dict";
        std::vector<hidict::DictConfig> configs;
        configs.emplace_back(std::move(dict_config));
        bool ret = dict_collector.init("plaintext_kv_dict_collector", configs, true);
        if (!ret) {
            std::cout << "init dict collector failed.\n";
        }
        auto *value = dict_collector.get_value<AdDict::PlaintextKvDict>("plaintext_kv_dict", "search_dtr_u_10001");
        if (value == nullptr) {
            std::cout << "get value is nullptr.\n";
        } else {
            std::cout << "value = " << value->DebugString() << "\n";
        }
        CHECK_EQ(200l, value->int64_list().value(0));
        CHECK_EQ(12l, value->int64_list().value(1));
        CHECK_EQ(-90l, value->int64_list().value(2));
    }

    TEST_CASE("query_custom_dict") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="plaintext_kv_dict" value="10820" />
        </versions>
        <config>
            <dict name="plaintext_kv_dict"
                  path=".tmp"
                  partition="{pt_d-1}"
                  value_proto="phx.PlaintextKvDict"
                  class_name="PlaintextKvDict"
            />
            <source name="item_info" value=".fe_request.item_fea.item_info" />
            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10820"
                         type="query_custom_dict"
                         slot="10820"
                         dict_name="plaintext_kv_dict"
                         source="item_info.rta_id"
                         prefix="search_dtr"
                         key_type="adunit_id"
                         default_int64_value="1700000000000" />
            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::cout << "ret size = " << ret.size() << "\n";
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_ptr->add_item_fea()->mutable_item_info()->set_rta_id("10001");
        mocker::FillProto(*fe_ptr);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction *user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action->SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(1, training_sample.training_samples_size());
        REQUIRE_EQ(1, training_sample.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10820, ({200l, 12l, -90l}), training_sample.training_samples(0).features(0));

        fe_ptr->mutable_item_fea(0)->mutable_item_info()->set_rta_id("10002");
        fe_str = fe_ptr->SerializeAsString();

        // 类型不一致抛异常
        CHECK_THROWS_AS((to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                               user_action_str.size(), config_handle)),
                        std::runtime_error);
    }
}
