#include "test.h"
#include "phx-fe/util/util.h"

void test_input() {
  FUNC_TEST_START();
  std::map<std::string, DefaultValue> default_value_map;

  Input in1(".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id", default_value_map, "");
  TEST_ASSERT_EQUAL(5, in1.name_parts.size());
  TEST_EXPECT_EQUAL("user_feature", in1.name_parts[0]);
  TEST_EXPECT_EQUAL("am_gm_clk_off", in1.name_parts[1]);
  TEST_EXPECT_EQUAL("am_clk_off", in1.name_parts[2]);
  TEST_EXPECT_EQUAL("user_sequence", in1.name_parts[3]);
  TEST_EXPECT_EQUAL("app_id", in1.name_parts[4]);
  TEST_EXPECT_EQUAL(0, in1.idx);

  Input in2(".request_time", default_value_map, "");
  TEST_ASSERT_EQUAL(1, in2.name_parts.size());
  TEST_EXPECT_EQUAL("request_time", in2.name_parts[0]);
  TEST_EXPECT_EQUAL(0, in2.idx);

  Input in3("f12:2", default_value_map, "");
  TEST_ASSERT_EQUAL(1, in3.name_parts.size());
  TEST_EXPECT_EQUAL("f12", in3.name_parts[0]);
  TEST_EXPECT_EQUAL(2, in3.idx);

  FUNC_TEST_END();
}

void test_input_repeated_count() {
  FUNC_TEST_START();
  std::map<std::string, DefaultValue> default_value_map;

  Input in1(".user_feature.user_feature_se.context.feature.int64_list.value", default_value_map, "");
  TEST_EXPECT_EQUAL(0, in1.repeated_count);

  Input in2(".user_feature.user_feature_se.feature_lists.feature_list.feature.int64_list.value", default_value_map, "");
  TEST_EXPECT_EQUAL(0, in2.repeated_count);
  
  Input in3(".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value", default_value_map, "");
  TEST_EXPECT_EQUAL(2, in3.repeated_count);
  
  Input in4(".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id", default_value_map, "");
  TEST_EXPECT_EQUAL(1, in4.repeated_count);
  
  Input in5(".user_feature.am_gm_clk_off.am_clk_off.version", default_value_map, "");
  TEST_EXPECT_EQUAL(0, in5.repeated_count);

  FUNC_TEST_END();
}

void test_parse_model_input0() {
  FUNC_TEST_START();

  std::string str = R"({
    "model_input_test": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1,3, 5] , 
            "model_input_type" : "dense"
        }
    }
  })";

  std::vector<std::shared_ptr<ModelInputConfig>> vec;

  try {
    ModelInputMgr::parse_model_input_config_from_string(str, vec);
  } catch (...) {

  }

  TEST_ASSERT_EQUAL(0, vec.size());

  FUNC_TEST_END();
}

void test_parse_model_input1() {
  FUNC_TEST_START();

  std::string str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1,3, 5] , 
            "model_input_type" : "dense"
        }
    }
  })";

  std::vector<std::shared_ptr<ModelInputConfig>> vec;
  ModelInputMgr::parse_model_input_config_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  TEST_EXPECT_EQUAL(DATATYPE_INT64, vec[0]->dtype);
  TEST_EXPECT_EQUAL(INPUT_DENSE, vec[0]->input_type);
  TEST_EXPECT_EQUAL("f13", vec[0]->input_name);

  TEST_ASSERT_EQUAL(3, vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(3, vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, vec[0]->shape[2]);

  FUNC_TEST_END();
}

void test_map() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "bucketize", 
            "source": [".item_feature.item_feature_se.context.feature.item"], 
            "boundary" : [0.09, 1.01, 2.56]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  BucketizedConfig* conf = dynamic_cast<BucketizedConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_ASSERT_EQUAL(3, conf->boundaries_.size());
  TEST_EXPECT_EQUAL(0.09, conf->boundaries_[0]);
  TEST_EXPECT_EQUAL(1.01, conf->boundaries_[1]);
  TEST_EXPECT_EQUAL(2.56, conf->boundaries_[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* sq = item->mutable_item_feature_se();
  tensorflow::Features* fs = sq->mutable_context();
  auto& input_map = *fs->mutable_feature();
  tensorflow::Feature& input_f = input_map["item"];
  input_f.mutable_float_list()->add_value(0);
  input_f.mutable_float_list()->add_value(1);
  input_f.mutable_float_list()->add_value(2);
  input_f.mutable_float_list()->add_value(4);

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map = ret.batch(0).context().feature();
  auto itr = map.find("f0");

  TEST_ASSERT_BOOL(itr != map.end());

  const auto& f = itr->second;
  TEST_ASSERT_EQUAL(4, f.int64_list().value_size());
  TEST_EXPECT_EQUAL(0, f.int64_list().value(0));
  TEST_EXPECT_EQUAL(1, f.int64_list().value(1));
  TEST_EXPECT_EQUAL(2, f.int64_list().value(2));
  TEST_EXPECT_EQUAL(3, f.int64_list().value(3));

  FUNC_TEST_END();
}

//填充feature
void test_map_and_default_value1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "bucketize", 
            "source": [".item_feature.item_feature_se.context.feature.item"], 
            "boundary" : [0.09, 1.01, 2.56]
        }
    },
    "default_values": {
        ".item_feature.item_feature_se.context.feature.item": {
            "dtype": "float",
            "values": [0, 1, 2, 4] 
        }
    }    
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  BucketizedConfig* conf = dynamic_cast<BucketizedConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_ASSERT_EQUAL(3, conf->boundaries_.size());
  TEST_EXPECT_EQUAL(0.09, conf->boundaries_[0]);
  TEST_EXPECT_EQUAL(1.01, conf->boundaries_[1]);
  TEST_EXPECT_EQUAL(2.56, conf->boundaries_[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map = ret.batch(0).context().feature();
  auto itr = map.find("f0");

  TEST_ASSERT_BOOL(itr != map.end());

  const auto& f = itr->second;
  TEST_ASSERT_EQUAL(4, f.int64_list().value_size());
  TEST_EXPECT_EQUAL(0, f.int64_list().value(0));
  TEST_EXPECT_EQUAL(1, f.int64_list().value(1));
  TEST_EXPECT_EQUAL(2, f.int64_list().value(2));
  TEST_EXPECT_EQUAL(3, f.int64_list().value(3));

  FUNC_TEST_END();
}

//填充featurelist
void test_map_and_default_value2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f13": {
          "fe_type" : "vocab_list", 
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.list"
          ], 
          "vocabs" : ["NOT_EXIST", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
      }
    },
    "default_values": {
        ".item_feature.item_feature_se.feature_lists.feature_list.list": {
            "dtype": "string",
            "values": ["9", "81"] 
        }
    }    
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  VocabListConfig* config = dynamic_cast<VocabListConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);
  TEST_ASSERT_EQUAL(10, config->vocab_map_.size());
  TEST_EXPECT_EQUAL(0, config->vocab_map_["NOT_EXIST"]);
  TEST_EXPECT_EQUAL(1, config->vocab_map_["1"]);
  TEST_EXPECT_EQUAL(2, config->vocab_map_["2"]);
  TEST_EXPECT_EQUAL(3, config->vocab_map_["3"]);
  TEST_EXPECT_EQUAL(4, config->vocab_map_["4"]);
  TEST_EXPECT_EQUAL(5, config->vocab_map_["5"]);
  TEST_EXPECT_EQUAL(6, config->vocab_map_["6"]);
  TEST_EXPECT_EQUAL(7, config->vocab_map_["7"]);
  TEST_EXPECT_EQUAL(8, config->vocab_map_["8"]);
  TEST_EXPECT_EQUAL(9, config->vocab_map_["9"]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // item
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f13");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list0 = itr0->second;
  TEST_ASSERT_EQUAL(2, list0.feature_size());
  TEST_ASSERT_EQUAL(1, list0.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(9, list0.feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list0.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(0, list0.feature(1).int64_list().value(0));

  FUNC_TEST_END();
}

void test_bucketized() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f1": {
            "fe_type" : "bucketize", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num"], 
            "boundary" : [0.09, 1.01, 2.56]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  BucketizedConfig* conf = dynamic_cast<BucketizedConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_ASSERT_EQUAL(3, conf->boundaries_.size());
  TEST_EXPECT_EQUAL(0.09, conf->boundaries_[0]);
  TEST_EXPECT_EQUAL(1.01, conf->boundaries_[1]);
  TEST_EXPECT_EQUAL(2.56, conf->boundaries_[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_num(0);
  pb_use->add_user_sequence()->set_num(1);
  pb_use->add_user_sequence()->set_num(2);
  pb_use->add_user_sequence()->set_num(3);

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map = ret.batch(0).feature_lists().feature_list();
  auto itr = map.find("f1");

  TEST_ASSERT_BOOL(itr != map.end());

  const auto& list = itr->second;
  TEST_ASSERT_EQUAL(4, list.feature_size());
  TEST_ASSERT_EQUAL(1, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(0, list.feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, list.feature(1).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list.feature(2).int64_list().value_size());
  TEST_EXPECT_EQUAL(2, list.feature(2).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list.feature(3).int64_list().value_size());
  TEST_EXPECT_EQUAL(3, list.feature(3).int64_list().value(0));

  FUNC_TEST_END();
}

//feature
void test_bucketized_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f1": {
            "fe_type" : "bucketize", 
            "source": [".item_feature.item_feature_se.context.feature.num_one_star"], 
            "boundary" : [5.0, 11.0, 34.0, 87.0]
        }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f1": {
            "dtype" : "int64",
            "shape" : [4] , 
            "model_input_type" : "dense"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  BucketizedConfig* conf = dynamic_cast<BucketizedConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_ASSERT_EQUAL(4, conf->boundaries_.size());
  TEST_EXPECT_BOOL(std::abs(conf->boundaries_[0] - 5.0) < 1e-5);
  TEST_EXPECT_BOOL(std::abs(conf->boundaries_[1] - 11.0) < 1e-5);
  TEST_EXPECT_BOOL(std::abs(conf->boundaries_[2] - 34.0) < 1e-5);
  TEST_EXPECT_BOOL(std::abs(conf->boundaries_[3] - 87.0) < 1e-5);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_INT64, in_vec[0]->dtype);
  TEST_EXPECT_EQUAL("f1", in_vec[0]->input_name);
  TEST_ASSERT_EQUAL(1, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(4, in_vec[0]->shape[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num_one_star"].mutable_float_list()->add_value(4.0);
  (*(item->mutable_context()->mutable_feature()))["num_one_star"].mutable_float_list()->add_value(8.0);
  (*(item->mutable_context()->mutable_feature()))["num_one_star"].mutable_float_list()->add_value(22.0);
  (*(item->mutable_context()->mutable_feature()))["num_one_star"].mutable_float_list()->add_value(82.0);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();
  TEST_EXPECT_EQUAL(1, map.size());

  auto itr = map.find("f1");
  TEST_ASSERT_BOOL(itr != map.end());

  auto& tproto = itr->second;

  TEST_ASSERT_EQUAL(4, tproto.int64_val_size());
  TEST_EXPECT_EQUAL(0, tproto.int64_val(0));
  TEST_EXPECT_EQUAL(1, tproto.int64_val(1));
  TEST_EXPECT_EQUAL(2, tproto.int64_val(2));
  TEST_EXPECT_EQUAL(3, tproto.int64_val(3));

  FUNC_TEST_END();
}

//两层repeated
void test_bucketized_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f1": {
            "fe_type" : "bucketize", 
            "source": [".item_feature.item_feature_se.feature_lists.feature_list.list"], 
            "boundary" : [0.09, 1.01, 2.56]
        }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f1": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  BucketizedConfig* conf = dynamic_cast<BucketizedConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_ASSERT_EQUAL(3, conf->boundaries_.size());
  TEST_EXPECT_BOOL(std::abs(conf->boundaries_[0] - 0.09) < 1e-5);
  TEST_EXPECT_BOOL(std::abs(conf->boundaries_[1] - 1.01) < 1e-5);
  TEST_EXPECT_BOOL(std::abs(conf->boundaries_[2] - 2.56) < 1e-5);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(3, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  auto& map01 = *request.add_item_feature()->mutable_item_feature_se()->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = map01["list"];
  tensorflow::Feature* feat = list.add_feature();
  feat->mutable_float_list()->add_value(0.00);  
  feat->mutable_float_list()->add_value(2.88);

  feat = list.add_feature();
  feat->mutable_float_list()->add_value(0.74);
  feat->mutable_float_list()->add_value(3.14);

  auto& map02 = *request.add_item_feature()->mutable_item_feature_se()->mutable_feature_lists()->mutable_feature_list();
  feat = map02["list"].add_feature();
  feat->mutable_float_list()->add_value(1.28);
  feat->mutable_float_list()->add_value(2.15);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f1");
  auto itr_len = map.find("f1_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(12, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(3, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(2));

  TEST_EXPECT_EQUAL(1, tvalues.int64_val(3));
  TEST_EXPECT_EQUAL(3, tvalues.int64_val(4));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(5));

  TEST_EXPECT_EQUAL(2, tvalues.int64_val(6));
  TEST_EXPECT_EQUAL(2, tvalues.int64_val(7));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(8));

  TEST_EXPECT_EQUAL(0, tvalues.int64_val(9));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(10));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(11));

  TEST_ASSERT_EQUAL(2, tlen.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen.int_val(0));
  TEST_EXPECT_EQUAL(1, tlen.int_val(1));

  FUNC_TEST_END();
}

// 两层repteted
void test_hash() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0":{ 
            "fe_type" : "hash", 
            "source": [
                ".user_feature.yoyo_imp_off.yoyo_recommend_expo_appid_seq_7d.value"
            ],
            "bucket_size" : 1000
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  HashBucketConfig* conf = dynamic_cast<HashBucketConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_EXPECT_EQUAL(1000, conf->bucket_size_);
  TEST_EXPECT_EQUAL(true, conf->concat_with_name_);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::DwsAiYoyoRecommendExpoOfflineEventIncD* pb_yoyo = pb_ufv2->mutable_yoyo_imp_off();
  qinglong::StringArray* pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("name123");
  pb_str->add_value("name456");
  pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("name789");

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map = ret.batch(0).feature_lists().feature_list();
  auto itr = map.find("f0");

  TEST_ASSERT_BOOL(itr != map.end());

  const auto& list = itr->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(828, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(503, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(422, list.feature(1).int64_list().value(0));

  FUNC_TEST_END();
}

// source路径无repeated的默认值
void test_hash_bucket_and_default_value1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "hash", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.version"], 
            "bucket_size" : 100,
            "concat_with_name" : false
        }
    },
    "default_values": {
        ".user_feature.am_gm_clk_off.am_clk_off.version": {
            "dtype": "string",
            "values": ["name123", "name456", "name789"] 
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  HashBucketConfig* conf = dynamic_cast<HashBucketConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_EXPECT_EQUAL(100, conf->bucket_size_);
  TEST_EXPECT_EQUAL(false, conf->concat_with_name_);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map = ret.batch(0).context().feature();
  auto itr = map.find("f0");

  TEST_ASSERT_BOOL(itr != map.end());

  const auto& f = itr->second;
  TEST_ASSERT_EQUAL(3, f.int64_list().value_size());
  TEST_EXPECT_EQUAL(73, f.int64_list().value(0));
  TEST_EXPECT_EQUAL(57, f.int64_list().value(1));
  TEST_EXPECT_EQUAL(16, f.int64_list().value(2));

  FUNC_TEST_END();
}

// source路径 一层repeated的默认值
void test_hash_bucket_and_default_value2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "hash", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.query"], 
            "bucket_size" : 100,
            "concat_with_name" : false
        }
    },
    "default_values": {
        ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.query": {
            "dtype": "string",
            "values": ["name123", "name456", "name789"] 
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  HashBucketConfig* conf = dynamic_cast<HashBucketConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_EXPECT_EQUAL(100, conf->bucket_size_);
  TEST_EXPECT_EQUAL(false, conf->concat_with_name_);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map = ret.batch(0).feature_lists().feature_list();
  auto itr = map.find("f0");

  TEST_ASSERT_BOOL(itr != map.end());

  const auto& list = itr->second;
  TEST_ASSERT_EQUAL(3, list.feature_size());
  TEST_ASSERT_EQUAL(1, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(73, list.feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(57, list.feature(1).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list.feature(2).int64_list().value_size());
  TEST_EXPECT_EQUAL(16, list.feature(2).int64_list().value(0));

  FUNC_TEST_END();
}

// source路径 
void test_hash_bucket_and_default_value3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "hash", 
            "source": [".item_feature.item_id.item_id"], 
            "bucket_size" : 100,
            "concat_with_name" : false
        }
    },
    "default_values": {
        ".item_feature.item_id.item_id": {
            "dtype": "string",
            "values": ["name123", "name456", "name789"] 
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  HashBucketConfig* conf = dynamic_cast<HashBucketConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_EXPECT_EQUAL(100, conf->bucket_size_);
  TEST_EXPECT_EQUAL(false, conf->concat_with_name_);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map = ret.batch(0).context().feature();
  auto itr = map.find("f0");

  TEST_ASSERT_BOOL(itr != map.end());

  const auto& f = itr->second;
  TEST_ASSERT_EQUAL(3, f.int64_list().value_size());
  TEST_EXPECT_EQUAL(73, f.int64_list().value(0));
  TEST_EXPECT_EQUAL(57, f.int64_list().value(1));
  TEST_EXPECT_EQUAL(16, f.int64_list().value(2));

  FUNC_TEST_END();
}

void test_hash_bucket_and_concat_with_name() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "hash", 
            "source": [".item_feature.item_id.item_id"], 
            "bucket_size" : 100,
            "concat_with_name" : true
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  HashBucketConfig* conf = dynamic_cast<HashBucketConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_EXPECT_EQUAL(100, conf->bucket_size_);
  TEST_EXPECT_EQUAL(true, conf->concat_with_name_);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user

  // item
  request.add_item_feature()->mutable_item_id()->set_item_id("name123");
  request.add_item_feature()->mutable_item_id()->set_item_id("name456");
  request.add_item_feature()->mutable_item_id()->set_item_id("name789");

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(3, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(2).has_context());

  const auto& map00 = ret.batch(0).context().feature();
  auto itr00 = map00.find("f0");

  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& f00 = itr00->second;
  TEST_ASSERT_EQUAL(1, f00.int64_list().value_size());
  TEST_EXPECT_EQUAL(57, f00.int64_list().value(0));

  const auto& map01 = ret.batch(1).context().feature();
  auto itr01 = map01.find("f0");

  TEST_ASSERT_BOOL(itr01 != map01.end());

  const auto& f01 = itr01->second;
  TEST_ASSERT_EQUAL(1, f01.int64_list().value_size());
  TEST_EXPECT_EQUAL(16, f01.int64_list().value(0));

  const auto& map02 = ret.batch(2).context().feature();
  auto itr02 = map02.find("f0");

  TEST_ASSERT_BOOL(itr02 != map02.end());

  const auto& f02 = itr02->second;
  TEST_ASSERT_EQUAL(1, f02.int64_list().value_size());
  TEST_EXPECT_EQUAL(0, f02.int64_list().value(0));
  FUNC_TEST_END();
}

void test_expo_123_count() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "expo_123_count", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
                      ".item_feature.item_id.app_id"]
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "104435568,母婴,健康育儿,母婴健康;900778570,工具,生活工具,日历;104430325,社交,聊天交友,匿名/陌生人;900834783,默认值,默认值,默认值;220738225,默认值,默认值,默认值;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Expo123CountConfig* conf = dynamic_cast<Expo123CountConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("104435568");
  pb_use->add_user_sequence()->set_app_id("104435568");
  pb_use->add_user_sequence()->set_app_id("900778570");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("104435568");
  request.add_item_feature()->mutable_item_id()->set_app_id("900778570");

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(2, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr00 = map0.find("f13");
  auto itr01 = map0.find("f14");
  auto itr02 = map0.find("f15");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr02 != map0.end());

  TEST_ASSERT_EQUAL(1, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr00->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr01->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr02->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr02->second.int64_list().value(0));
  
  const auto& map1 = ret.batch(1).context().feature();
  auto itr10 = map1.find("f13");
  auto itr11 = map1.find("f14");
  auto itr12 = map1.find("f15");

  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());
  TEST_ASSERT_BOOL(itr12 != map1.end());

  TEST_ASSERT_EQUAL(1, itr10->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr10->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr11->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr11->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr12->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr12->second.int64_list().value(0));

  FUNC_TEST_END();
}

// 两层repeated
void test_expo_123_count_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "expo_123_count", 
          "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
                      ".item_feature.item_feature_se.feature_lists.feature_list.list"]
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f14": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f15": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Expo123CountConfig* conf = dynamic_cast<Expo123CountConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_INT64, in_vec[0]->dtype);
  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(3, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::StringArray* pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900744462");
  pb_seq->add_value("900778570");
  pb_seq->add_value("104418979");

  pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900242957");
  pb_seq->add_value("900242957");
  pb_seq->add_value("900242957");

  // item
  auto& map1 = *request.add_item_feature()->mutable_item_feature_se()->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = map1["list"];
  tensorflow::Feature* feat = list.add_feature();
  feat->mutable_bytes_list()->add_value("104418979");
  feat->mutable_bytes_list()->add_value("900744462");
  feat->mutable_bytes_list()->add_value("900242957");

  feat = list.add_feature();
  feat->mutable_bytes_list()->add_value("104418979");
  feat->mutable_bytes_list()->add_value("900242957");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr01 = map.find("f13");
  auto itr_len01 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr01 != map.end());
  TEST_ASSERT_BOOL(itr_len01 != map.end());

  auto& tvalues01 = itr01->second;
  auto& tlen01 = itr_len01->second;

  TEST_ASSERT_EQUAL(6, tvalues01.int64_val_size());
  TEST_EXPECT_EQUAL(6, tvalues01.int64_val(0));
  TEST_EXPECT_EQUAL(6, tvalues01.int64_val(1));
  TEST_EXPECT_EQUAL(6, tvalues01.int64_val(2));

  TEST_EXPECT_EQUAL(6, tvalues01.int64_val(3));
  TEST_EXPECT_EQUAL(6, tvalues01.int64_val(4));
  TEST_EXPECT_EQUAL(0, tvalues01.int64_val(5));

  TEST_ASSERT_EQUAL(1, tlen01.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen01.int_val(0));

  auto itr02 = map.find("f14");
  auto itr_len02 = map.find("f14_length");

  TEST_ASSERT_BOOL(itr02 != map.end());
  TEST_ASSERT_BOOL(itr_len02 != map.end());

  auto& tvalues02 = itr02->second;
  auto& tlen02 = itr_len02->second;

  TEST_ASSERT_EQUAL(6, tvalues02.int64_val_size());
  TEST_EXPECT_EQUAL(2, tvalues02.int64_val(0));
  TEST_EXPECT_EQUAL(2, tvalues02.int64_val(1));
  TEST_EXPECT_EQUAL(4, tvalues02.int64_val(2));

  TEST_EXPECT_EQUAL(2, tvalues02.int64_val(3));
  TEST_EXPECT_EQUAL(4, tvalues02.int64_val(4));
  TEST_EXPECT_EQUAL(0, tvalues02.int64_val(5));

  TEST_ASSERT_EQUAL(1, tlen02.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen02.int_val(0));

  auto itr03 = map.find("f15");
  auto itr_len03 = map.find("f15_length");

  TEST_ASSERT_BOOL(itr03 != map.end());
  TEST_ASSERT_BOOL(itr_len03 != map.end());

  auto& tvalues03 = itr03->second;
  auto& tlen03 = itr_len03->second;

  TEST_ASSERT_EQUAL(6, tvalues03.int64_val_size());
  TEST_EXPECT_EQUAL(1, tvalues03.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues03.int64_val(1));
  TEST_EXPECT_EQUAL(3, tvalues03.int64_val(2));

  TEST_EXPECT_EQUAL(1, tvalues03.int64_val(3));
  TEST_EXPECT_EQUAL(3, tvalues03.int64_val(4));
  TEST_EXPECT_EQUAL(0, tvalues03.int64_val(5));

  TEST_ASSERT_EQUAL(1, tlen03.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen03.int_val(0));
  
  FUNC_TEST_END();
}

//输入1 一层repeated
void test_expo_123_countv2_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "expo_123_count_v2", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
                      ".item_feature.item_id.app_id"]
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      },
      "f16" : {
          "fe_type" : "direct", 
          "source": ["f12:3"]
      },
      "f17" : {
          "fe_type" : "direct", 
          "source": ["f12:4"]
      },
      "f18" : {
          "fe_type" : "direct", 
          "source": ["f12:5"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(7, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Expo123CountV2Config* conf = dynamic_cast<Expo123CountV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("900744462");
  pb_use->add_user_sequence()->set_app_id("900778570");
  pb_use->add_user_sequence()->set_app_id("104418979");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("900744462");
  request.add_item_feature()->mutable_item_id()->set_app_id("900242957");

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(2, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr00 = map0.find("f13");
  auto itr01 = map0.find("f14");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_EQUAL(1, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr01->second.int64_list().value(0));

  auto itr02 = map0.find("f15");
  auto itr03 = map0.find("f16");
  TEST_ASSERT_BOOL(itr02 != map0.end());
  TEST_ASSERT_BOOL(itr03 != map0.end());

  TEST_ASSERT_EQUAL(1, itr02->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr02->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr03->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr03->second.int64_list().value(0));

  auto itr04 = map0.find("f17");
  auto itr05 = map0.find("f18");
  TEST_ASSERT_BOOL(itr04 != map0.end());
  TEST_ASSERT_BOOL(itr05 != map0.end());

  TEST_ASSERT_EQUAL(1, itr04->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr04->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr05->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr05->second.int64_list().value(0));
  
  const auto& map1 = ret.batch(1).context().feature();
  auto itr10 = map1.find("f13");
  auto itr11 = map1.find("f14");
  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());

  TEST_ASSERT_EQUAL(1, itr10->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr10->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr11->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr11->second.int64_list().value(0));

  auto itr12 = map1.find("f15");
  auto itr13 = map1.find("f16");
  TEST_ASSERT_BOOL(itr12 != map1.end());
  TEST_ASSERT_BOOL(itr13 != map1.end());

  TEST_ASSERT_EQUAL(1, itr12->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr12->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr13->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr13->second.int64_list().value(0));

  auto itr14 = map1.find("f17");
  auto itr15 = map1.find("f18");
  TEST_ASSERT_BOOL(itr14 != map1.end());
  TEST_ASSERT_BOOL(itr15 != map1.end());

  TEST_ASSERT_EQUAL(1, itr14->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(0, itr14->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr14->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(0, itr14->second.int64_list().value(0));

  FUNC_TEST_END();
}

//输入1 两层repeated
void test_expo_123_countv2_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "expo_123_count_v2", 
          "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
                      ".item_feature.item_id.app_id"]
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      },
      "f16" : {
          "fe_type" : "direct", 
          "source": ["f12:3"]
      },
      "f17" : {
          "fe_type" : "direct", 
          "source": ["f12:4"]
      },
      "f18" : {
          "fe_type" : "direct", 
          "source": ["f12:5"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(7, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Expo123CountV2Config* conf = dynamic_cast<Expo123CountV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::StringArray* pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900744462");
  pb_seq->add_value("900778570");
  pb_seq->add_value("104418979"); 

  pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900242957");
  pb_seq->add_value("900242957");
  pb_seq->add_value("900242957");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("900744462");
  request.add_item_feature()->mutable_item_id()->set_app_id("900242957");

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(2, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr00 = map0.find("f13");
  auto itr01 = map0.find("f14");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr01 != map0.end());

  TEST_ASSERT_EQUAL(1, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(6, itr01->second.int64_list().value(0));

  auto itr02 = map0.find("f15");
  auto itr03 = map0.find("f16");
  TEST_ASSERT_BOOL(itr02 != map0.end());
  TEST_ASSERT_BOOL(itr03 != map0.end());
  
  TEST_ASSERT_EQUAL(1, itr02->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr02->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr03->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr03->second.int64_list().value(0));

  auto itr04 = map0.find("f17");
  auto itr05 = map0.find("f18");
  TEST_ASSERT_BOOL(itr04 != map0.end());
  TEST_ASSERT_BOOL(itr05 != map0.end());

  TEST_ASSERT_EQUAL(1, itr04->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr04->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr05->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr05->second.int64_list().value(0));
  
  const auto& map1 = ret.batch(1).context().feature();
  auto itr10 = map1.find("f13");
  auto itr11 = map1.find("f14");
  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());

  TEST_ASSERT_EQUAL(1, itr10->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr10->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr11->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(6, itr11->second.int64_list().value(0));

  auto itr12 = map1.find("f15");
  auto itr13 = map1.find("f16");
  TEST_ASSERT_BOOL(itr12 != map1.end());
  TEST_ASSERT_BOOL(itr13 != map1.end());

  TEST_ASSERT_EQUAL(1, itr12->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr12->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr13->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(4, itr13->second.int64_list().value(0));

  auto itr14 = map1.find("f17");
  auto itr15 = map1.find("f18");
  TEST_ASSERT_BOOL(itr14 != map1.end());
  TEST_ASSERT_BOOL(itr15 != map1.end());

  TEST_ASSERT_EQUAL(1, itr14->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr14->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr15->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr15->second.int64_list().value(0));

  FUNC_TEST_END();
}

/* 
  输入1 两层repeated
  输入2 两层repeated
*/
void test_expo_123_countv2_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "expo_123_count_v2", 
          "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
                      ".item_feature.item_feature_se.feature_lists.feature_list.list"]
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      },
      "f16" : {
          "fe_type" : "direct", 
          "source": ["f12:3"]
      },
      "f17" : {
          "fe_type" : "direct", 
          "source": ["f12:4"]
      },
      "f18" : {
          "fe_type" : "direct", 
          "source": ["f12:5"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(7, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Expo123CountV2Config* conf = dynamic_cast<Expo123CountV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::StringArray* pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900744462");
  pb_seq->add_value("900778570");
  pb_seq->add_value("104418979");

  pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900242957");
  pb_seq->add_value("900242957");
  pb_seq->add_value("900242957");

  // item
  auto& map = *request.add_item_feature()->mutable_item_feature_se()->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = map["list"];
  tensorflow::Feature* feat = list.add_feature();
  feat->mutable_bytes_list()->add_value("104418979");
  feat->mutable_bytes_list()->add_value("900744462");
  feat->mutable_bytes_list()->add_value("900242957");

  feat = list.add_feature();
  feat->mutable_bytes_list()->add_value("104418979");
  feat->mutable_bytes_list()->add_value("900242957");
  feat->mutable_bytes_list()->add_value("666");

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr00 = map0.find("f13");
  auto itr01 = map0.find("f14");
  auto itr02 = map0.find("f15");
  auto itr03 = map0.find("f16");
  auto itr04 = map0.find("f17");
  auto itr05 = map0.find("f18");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr02 != map0.end());
  TEST_ASSERT_BOOL(itr03 != map0.end());
  TEST_ASSERT_BOOL(itr04 != map0.end());
  TEST_ASSERT_BOOL(itr05 != map0.end());

  TEST_ASSERT_EQUAL(2, itr00->second.feature_size());
  TEST_ASSERT_EQUAL(2, itr01->second.feature_size());
  TEST_ASSERT_EQUAL(2, itr02->second.feature_size());
  TEST_ASSERT_EQUAL(2, itr03->second.feature_size());
  TEST_ASSERT_EQUAL(2, itr04->second.feature_size());
  TEST_ASSERT_EQUAL(2, itr05->second.feature_size());

  // bool
  TEST_ASSERT_EQUAL(3, itr00->second.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr00->second.feature(0).int64_list().value(1));
  TEST_EXPECT_EQUAL(1, itr00->second.feature(0).int64_list().value(2));

  TEST_ASSERT_EQUAL(3, itr00->second.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr00->second.feature(1).int64_list().value(1));
  TEST_EXPECT_EQUAL(0, itr00->second.feature(1).int64_list().value(2));

  TEST_ASSERT_EQUAL(3, itr02->second.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr02->second.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr02->second.feature(0).int64_list().value(1));
  TEST_EXPECT_EQUAL(1, itr02->second.feature(0).int64_list().value(2));

  TEST_ASSERT_EQUAL(3, itr02->second.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr02->second.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr02->second.feature(1).int64_list().value(1));
  TEST_EXPECT_EQUAL(0, itr02->second.feature(1).int64_list().value(2));
  
  TEST_ASSERT_EQUAL(3, itr04->second.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr04->second.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr04->second.feature(0).int64_list().value(1));
  TEST_EXPECT_EQUAL(1, itr04->second.feature(0).int64_list().value(2));

  TEST_ASSERT_EQUAL(3, itr04->second.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr04->second.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr04->second.feature(1).int64_list().value(1));
  TEST_EXPECT_EQUAL(0, itr04->second.feature(1).int64_list().value(2));
  
  // int
  TEST_ASSERT_EQUAL(3, itr01->second.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(6, itr01->second.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(6, itr01->second.feature(0).int64_list().value(1));
  TEST_EXPECT_EQUAL(6, itr01->second.feature(0).int64_list().value(2));

  TEST_ASSERT_EQUAL(3, itr01->second.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(6, itr01->second.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(6, itr01->second.feature(1).int64_list().value(1));
  TEST_EXPECT_EQUAL(0, itr01->second.feature(1).int64_list().value(2));

  TEST_ASSERT_EQUAL(3, itr03->second.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr03->second.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(2, itr03->second.feature(0).int64_list().value(1));
  TEST_EXPECT_EQUAL(4, itr03->second.feature(0).int64_list().value(2));

  TEST_ASSERT_EQUAL(3, itr03->second.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr03->second.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(4, itr03->second.feature(1).int64_list().value(1));
  TEST_EXPECT_EQUAL(0, itr03->second.feature(1).int64_list().value(2));
  
  TEST_ASSERT_EQUAL(3, itr05->second.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr05->second.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr05->second.feature(0).int64_list().value(1));
  TEST_EXPECT_EQUAL(3, itr05->second.feature(0).int64_list().value(2));

  TEST_ASSERT_EQUAL(3, itr05->second.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr05->second.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(3, itr05->second.feature(1).int64_list().value(1));
  TEST_EXPECT_EQUAL(0, itr05->second.feature(1).int64_list().value(2));
  FUNC_TEST_END();
}

void test_filter_appid() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "filter_appid", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time"
          ], 
          "days" : [1, 3, 10],
          "max_len" :100, 
          "save": false
      },
      "f10" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f11" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      },
      "f12" : {
          "fe_type" : "direct", 
          "source": ["f6:2"]
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  FilterAppIdConfig* conf = dynamic_cast<FilterAppIdConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104435568"); // diff 5
  pb_info->set_event_time(5 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666"); // diff 1
  pb_info->set_event_time(9 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570"); // diff 7
  pb_info->set_event_time(3 * 86400 * 1000);

  // item
  request.add_item_feature();
  //item不能为空

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f10");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list = itr0->second;
  TEST_ASSERT_EQUAL(1, list.feature_size());
  TEST_ASSERT_EQUAL(1, list.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("NOT_EXIST", list.feature(0).bytes_list().value(0));

  const auto& map1 = ret.batch(0).feature_lists().feature_list();
  auto itr1 = map1.find("f11");

  TEST_ASSERT_BOOL(itr1 != map1.end());

  const auto& list1 = itr1->second;
  TEST_ASSERT_EQUAL(1, list1.feature_size());
  TEST_ASSERT_EQUAL(1, list1.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("104436666", list1.feature(0).bytes_list().value(0));

  const auto& map2 = ret.batch(0).feature_lists().feature_list();
  auto itr2 = map2.find("f12");

  TEST_ASSERT_BOOL(itr2 != map1.end());

  const auto& list2 = itr2->second;
  TEST_ASSERT_EQUAL(3, list2.feature_size());
  TEST_ASSERT_EQUAL(1, list2.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("900778570", list2.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list2.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("104435568", list2.feature(1).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list2.feature(2).bytes_list().value_size());
  TEST_EXPECT_EQUAL("104436666", list2.feature(2).bytes_list().value(0));

  FUNC_TEST_END();
}

void test_filter_appid_max_len() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "filter_appid", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time"
          ], 
          "days" : [1, 6, 10],
          "max_len" :2, 
          "save": false
      },
      "f10" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f11" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      },
      "f12" : {
          "fe_type" : "direct", 
          "source": ["f6:2"]
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  FilterAppIdConfig* conf = dynamic_cast<FilterAppIdConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104435568"); // diff 5
  pb_info->set_event_time(5 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666"); // diff 1
  pb_info->set_event_time(9 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570"); // diff 7
  pb_info->set_event_time(3 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570"); // diff 3
  pb_info->set_event_time(7 * 86400 * 1000);

  // item
  request.add_item_feature();
  //item不能为空

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f10");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list = itr0->second;
  TEST_ASSERT_EQUAL(1, list.feature_size());
  TEST_ASSERT_EQUAL(1, list.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("NOT_EXIST", list.feature(0).bytes_list().value(0));

  const auto& map1 = ret.batch(0).feature_lists().feature_list();
  auto itr1 = map1.find("f11");

  TEST_ASSERT_BOOL(itr1 != map1.end());

  const auto& list1 = itr1->second;
  TEST_ASSERT_EQUAL(2, list1.feature_size());
  TEST_ASSERT_EQUAL(1, list1.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("900778570", list1.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list1.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("104436666", list1.feature(1).bytes_list().value(0));

  const auto& map2 = ret.batch(0).feature_lists().feature_list();
  auto itr2 = map2.find("f12");

  TEST_ASSERT_BOOL(itr2 != map1.end());

  const auto& list2 = itr2->second;
  TEST_ASSERT_EQUAL(2, list2.feature_size());
  TEST_ASSERT_EQUAL(1, list2.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("900778570", list2.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list2.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("104436666", list2.feature(1).bytes_list().value(0));

  FUNC_TEST_END();
}

//feature
void test_filter_appid_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "filter_appid", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time"
          ], 
          "days" : [1, 3, 10],
          "max_len" :3, 
          "save": false
      },
      "f10" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f11" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      },
      "f12" : {
          "fe_type" : "direct", 
          "source": ["f6:2"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f10": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f11": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f12": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  FilterAppIdConfig* conf = dynamic_cast<FilterAppIdConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436666");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value(5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value(9 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value(3 * 86400 * 1000);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f10_values");
  auto itr_indices = map.find("f10_indices");
  auto itr_dense_shape = map.find("f10_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(1, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("NOT_EXIST", tvalues.string_val(0));

  TEST_ASSERT_EQUAL(2, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(1));

  auto itr_values_2 = map.find("f11_values");
  auto itr_indices_2 = map.find("f11_indices");
  auto itr_dense_shape_2 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values_2 != map.end());
  TEST_ASSERT_BOOL(itr_indices_2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape_2 != map.end());

  auto& tvalues_2 = itr_values_2->second;
  auto& tindices_2 = itr_indices_2->second;
  auto& tdense_shape_2 = itr_dense_shape_2->second;

  TEST_ASSERT_EQUAL(1, tvalues_2.string_val_size());
  TEST_EXPECT_EQUAL("104436666", tvalues_2.string_val(0));

  TEST_ASSERT_EQUAL(2, tindices_2.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices_2.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices_2.int64_val(1));

  TEST_ASSERT_EQUAL(2, tdense_shape_2.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape_2.int64_val(0));
  TEST_EXPECT_EQUAL(1, tdense_shape_2.int64_val(1));

  auto itr_values_3 = map.find("f12_values");
  auto itr_indices_3 = map.find("f12_indices");
  auto itr_dense_shape_3 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values_3 != map.end());
  TEST_ASSERT_BOOL(itr_indices_3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape_3 != map.end());

  auto& tvalues_3 = itr_values_3->second;
  auto& tindices_3 = itr_indices_3->second;
  auto& tdense_shape_3 = itr_dense_shape_3->second;

  TEST_ASSERT_EQUAL(3, tvalues_3.string_val_size());
  TEST_EXPECT_EQUAL("900778570", tvalues_3.string_val(0));
  TEST_EXPECT_EQUAL("104435568", tvalues_3.string_val(1));
  TEST_EXPECT_EQUAL("104436666", tvalues_3.string_val(2));

  TEST_ASSERT_EQUAL(6, tindices_3.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices_3.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices_3.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices_3.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices_3.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices_3.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices_3.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape_3.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape_3.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape_3.int64_val(1));

  FUNC_TEST_END();
}

// batch_size大小2 item 是feature bytes_list的大小1
void test_appid_cross() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "appid_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.context.feature.item"],
          "bucket_size" : 100
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("900778570");
  pb_use->add_user_sequence()->set_app_id("104436666");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("123");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("456");

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(2, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f15");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list00 = itr0->second;
  TEST_ASSERT_EQUAL(2, list00.feature_size());
  TEST_ASSERT_EQUAL(1, list00.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(30, list00.feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(42, list00.feature(1).int64_list().value(0));

  const auto& map1 = ret.batch(1).feature_lists().feature_list();
  auto itr1 = map1.find("f15");

  TEST_ASSERT_BOOL(itr1 != map1.end());

  const auto& list01 = itr1->second;
  TEST_ASSERT_EQUAL(2, list01.feature_size());
  TEST_ASSERT_EQUAL(1, list01.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(3, list01.feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list01.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(89, list01.feature(1).int64_list().value(0));

  FUNC_TEST_END();
}

// batch_size大小1 item 是feature bytes_list的大小2 只读取feature的第一个value
void test_appid_cross_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "appid_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.context.feature.item"],
          "bucket_size" : 100
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("900778570");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::Feature& input_f = (*(item->mutable_context()->mutable_feature()))["item"];
  input_f.mutable_bytes_list()->add_value("123");
  input_f.mutable_bytes_list()->add_value("456");

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());
  
  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f15");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list = itr0->second;
  TEST_ASSERT_EQUAL(1, list.feature_size());
  TEST_ASSERT_EQUAL(1, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(30, list.feature(0).int64_list().value(0));

  FUNC_TEST_END();
}

// item 是feature list
void test_appid_cross_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "appid_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"],
          "bucket_size" : 100
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("900778570");
  pb_use->add_user_sequence()->set_app_id("104436666");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("456");

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());
  
  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f15");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list = itr0->second;
  TEST_ASSERT_EQUAL(4, list.feature_size());
  TEST_ASSERT_EQUAL(1, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(30, list.feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(42, list.feature(1).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list.feature(2).int64_list().value_size());
  TEST_EXPECT_EQUAL(3, list.feature(2).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list.feature(3).int64_list().value_size());
  TEST_EXPECT_EQUAL(89, list.feature(3).int64_list().value(0));

  FUNC_TEST_END();
}

void test_to_feature() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "to_feature", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num"]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_num(0);
  pb_use->add_user_sequence()->set_num(1);
  pb_use->add_user_sequence()->set_num(2);
  pb_use->add_user_sequence()->set_num(3);

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map = ret.batch(0).context().feature();
  auto itr = map.find("f0");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(3 == itr->second.kind_case());
  TEST_ASSERT_EQUAL(4, itr->second.int64_list().value_size());
  TEST_ASSERT_EQUAL(0, itr->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr->second.int64_list().value(1));
  TEST_ASSERT_EQUAL(2, itr->second.int64_list().value(2));
  TEST_ASSERT_EQUAL(3, itr->second.int64_list().value(3));

  FUNC_TEST_END();
}

//feature
void test_to_feature_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "to_feature", 
            "source": [".item_feature.item_id.app_id"]
        }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "dense"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype);
  TEST_EXPECT_EQUAL("f0", in_vec[0]->input_name);
  TEST_ASSERT_EQUAL(1, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("104435568");
  request.add_item_feature()->mutable_item_id()->set_app_id("900778570");
  request.add_item_feature()->mutable_item_id()->set_app_id("104430325");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();
  TEST_EXPECT_EQUAL(1, map.size());

  auto itr = map.find("f0");
  TEST_ASSERT_BOOL(itr != map.end());

  auto& tproto = itr->second;

  TEST_ASSERT_EQUAL(3, tproto.string_val_size());
  TEST_EXPECT_EQUAL("104435568", tproto.string_val(0));
  TEST_EXPECT_EQUAL("900778570", tproto.string_val(1));
  TEST_EXPECT_EQUAL("104430325", tproto.string_val(2));

  FUNC_TEST_END();
}

// 两层repeated featurelist
void test_to_feature_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "to_feature", 
            "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value"]
        }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [2] , 
            "model_input_type" : "dense"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype);
  TEST_EXPECT_EQUAL("f0", in_vec[0]->input_name);
  TEST_ASSERT_EQUAL(1, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[0]);

  // user 只读取vec[0]
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::StringArray* pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900744462");
  pb_seq->add_value("104418979");

  pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900242957");

  // item
  request.add_item_feature();
  request.add_item_feature();

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();
  TEST_EXPECT_EQUAL(1, map.size());

  auto itr = map.find("f0");
  TEST_ASSERT_BOOL(itr != map.end());

  auto& tproto = itr->second;

  TEST_ASSERT_EQUAL(4, tproto.string_val_size());
  TEST_EXPECT_EQUAL("900744462", tproto.string_val(0));
  TEST_EXPECT_EQUAL("900242957", tproto.string_val(1));
  TEST_EXPECT_EQUAL("900744462", tproto.string_val(2));
  TEST_EXPECT_EQUAL("900242957", tproto.string_val(3));

  FUNC_TEST_END();
}

void test_vocab_list_not_find(){
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13": {
          "fe_type" : "vocab_list", 
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.list"
          ], 
          "vocabs" : ["NOT_EXIST", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  VocabListConfig* config = dynamic_cast<VocabListConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);
  TEST_ASSERT_EQUAL(10, config->vocab_map_.size());
  TEST_EXPECT_EQUAL(0, config->vocab_map_["NOT_EXIST"]);
  TEST_EXPECT_EQUAL(1, config->vocab_map_["1"]);
  TEST_EXPECT_EQUAL(2, config->vocab_map_["2"]);
  TEST_EXPECT_EQUAL(3, config->vocab_map_["3"]);
  TEST_EXPECT_EQUAL(4, config->vocab_map_["4"]);
  TEST_EXPECT_EQUAL(5, config->vocab_map_["5"]);
  TEST_EXPECT_EQUAL(6, config->vocab_map_["6"]);
  TEST_EXPECT_EQUAL(7, config->vocab_map_["7"]);
  TEST_EXPECT_EQUAL(8, config->vocab_map_["8"]);
  TEST_EXPECT_EQUAL(9, config->vocab_map_["9"]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // item
  auto& map = *request.add_item_feature()->mutable_item_feature_se()->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = map["list"];
  tensorflow::Feature* fe = list.add_feature();
  fe->mutable_bytes_list()->add_value("9");
  fe->mutable_bytes_list()->add_value("81");

  fe = list.add_feature();
  fe->mutable_bytes_list()->add_value("81");

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f13");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list0 = itr0->second;
  TEST_ASSERT_EQUAL(2, list0.feature_size());
  TEST_ASSERT_EQUAL(2, list0.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(9, list0.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(0, list0.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list0.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(0, list0.feature(1).int64_list().value(0));

  FUNC_TEST_END();
}

//dtype int64
void test_predict_dense_0() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13": {
          "fe_type" : "vocab_list", 
          "source": [
              ".item_feature.item_feature_se.context.feature.item"
          ], 
          "vocabs" : ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "dense"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  VocabListConfig* config = dynamic_cast<VocabListConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);
  TEST_ASSERT_EQUAL(10, config->vocab_map_.size());
  TEST_EXPECT_EQUAL(0, config->vocab_map_["0"]);
  TEST_EXPECT_EQUAL(1, config->vocab_map_["1"]);
  TEST_EXPECT_EQUAL(2, config->vocab_map_["2"]);
  TEST_EXPECT_EQUAL(3, config->vocab_map_["3"]);
  TEST_EXPECT_EQUAL(4, config->vocab_map_["4"]);
  TEST_EXPECT_EQUAL(5, config->vocab_map_["5"]);
  TEST_EXPECT_EQUAL(6, config->vocab_map_["6"]);
  TEST_EXPECT_EQUAL(7, config->vocab_map_["7"]);
  TEST_EXPECT_EQUAL(8, config->vocab_map_["8"]);
  TEST_EXPECT_EQUAL(9, config->vocab_map_["9"]);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_INT64, in_vec[0]->dtype);
  TEST_EXPECT_EQUAL("f13", in_vec[0]->input_name);
  TEST_ASSERT_EQUAL(1, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("5");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();
  TEST_EXPECT_EQUAL(1, map.size());

  auto itr = map.find("f13");
  TEST_ASSERT_BOOL(itr != map.end());

  auto& tproto = itr->second;

  TEST_ASSERT_EQUAL(1, tproto.int64_val_size());
  TEST_EXPECT_EQUAL(5, tproto.int64_val(0));

  FUNC_TEST_END();
}

//dtype int32
void test_predict_dense_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "vocab_list", 
          "source": [
              ".item_feature.item_feature_se.context.feature.item"
          ], 
          "vocabs" : ["0", "1", "2", "3", "4", "5"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int32",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "dense"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  VocabListConfig* config = dynamic_cast<VocabListConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);
  TEST_ASSERT_EQUAL(6, config->vocab_map_.size());
  TEST_EXPECT_EQUAL(0, config->vocab_map_["0"]);
  TEST_EXPECT_EQUAL(1, config->vocab_map_["1"]);
  TEST_EXPECT_EQUAL(2, config->vocab_map_["2"]);
  TEST_EXPECT_EQUAL(3, config->vocab_map_["3"]);
  TEST_EXPECT_EQUAL(4, config->vocab_map_["4"]);
  TEST_EXPECT_EQUAL(5, config->vocab_map_["5"]);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_INT32, in_vec[0]->dtype);
  TEST_EXPECT_EQUAL("f6", in_vec[0]->input_name);
  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(3, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("1");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("2");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("4");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();
  TEST_EXPECT_EQUAL(1, map.size());

  auto itr = map.find("f6");
  TEST_ASSERT_BOOL(itr != map.end());

  auto& tproto = itr->second;

  TEST_ASSERT_EQUAL(3, tproto.int_val_size());
  TEST_EXPECT_EQUAL(1, tproto.int_val(0));
  TEST_EXPECT_EQUAL(2, tproto.int_val(1));
  TEST_EXPECT_EQUAL(4, tproto.int_val(2));

  FUNC_TEST_END();
}

//dtype float
void test_predict_dense_2() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  qinglong::PredictRequest ret;
  Output value;
  value.values.resize(1);
  value.values[0].ifeatures.resize(2);

  tensorflow::Feature* out_feature = nullptr;
  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_float_list()->add_value(1);
  out_feature->mutable_float_list()->add_value(2);
  value.values[0].ifeatures[0].feature = out_feature;

  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_float_list()->add_value(11);
  out_feature->mutable_float_list()->add_value(12);
  value.values[0].ifeatures[1].feature = out_feature;

  insertDenseTensor(tensorflow::DT_FLOAT, 2, {2}, "test0", value, ret);

  auto& map = ret.inputs();
  TEST_EXPECT_EQUAL(1, map.size());

  auto itr = map.find("test0");
  TEST_ASSERT_BOOL(itr != map.end());

  auto& tproto = itr->second;

  TEST_ASSERT_EQUAL(4, tproto.float_val_size());
  TEST_EXPECT_EQUAL(1, tproto.float_val(0));
  TEST_EXPECT_EQUAL(2, tproto.float_val(1));
  TEST_EXPECT_EQUAL(11, tproto.float_val(2));
  TEST_EXPECT_EQUAL(12, tproto.float_val(3));

  FUNC_TEST_END();
}

// //dtype string
void test_predict_dense_3() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  qinglong::PredictRequest ret;
  Output value;
  value.values.resize(1);
  value.values[0].ifeatures.resize(2);

  tensorflow::Feature* out_feature = nullptr;
  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_bytes_list()->add_value("01");
  out_feature->mutable_bytes_list()->add_value("02");
  value.values[0].ifeatures[0].feature = out_feature;

  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_bytes_list()->add_value("11");
  out_feature->mutable_bytes_list()->add_value("12");
  value.values[0].ifeatures[1].feature = out_feature;

  insertDenseTensor(tensorflow::DT_STRING, 2, {2}, "test0", value, ret);

  auto& map = ret.inputs();
  TEST_EXPECT_EQUAL(1, map.size());

  auto itr = map.find("test0");
  TEST_ASSERT_BOOL(itr != map.end());

  auto& tproto = itr->second;

  TEST_ASSERT_EQUAL(4, tproto.string_val_size());
  TEST_EXPECT_EQUAL("01", tproto.string_val(0));
  TEST_EXPECT_EQUAL("02", tproto.string_val(1));
  TEST_EXPECT_EQUAL("11", tproto.string_val(2));
  TEST_EXPECT_EQUAL("12", tproto.string_val(3));

  FUNC_TEST_END();
}

//dtype int64
void test_predict_sparse_0() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13": {
          "fe_type" : "vocab_list", 
          "source": [
              ".item_feature.item_feature_se.context.feature.item"
          ], 
          "vocabs" : ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  VocabListConfig* config = dynamic_cast<VocabListConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("5");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("7");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f13_values");
  auto itr_indices = map.find("f13_indices");
  auto itr_dense_shape = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(2, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(5, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(7, tvalues.int64_val(1));

  TEST_ASSERT_EQUAL(4, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape.int64_val(1));
  
  FUNC_TEST_END();
}

// //dtype int32
void test_predict_sparse_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13": {
          "fe_type" : "vocab_list", 
          "source": [
              ".item_feature.item_feature_se.context.feature.item"
          ], 
          "vocabs" : ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int32",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  VocabListConfig* config = dynamic_cast<VocabListConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("3");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("5");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("7");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("9");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f13_values");
  auto itr_indices = map.find("f13_indices");
  auto itr_dense_shape = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(4, tvalues.int_val_size());
  TEST_EXPECT_EQUAL(3, tvalues.int_val(0));
  TEST_EXPECT_EQUAL(5, tvalues.int_val(1));
  TEST_EXPECT_EQUAL(7, tvalues.int_val(2));
  TEST_EXPECT_EQUAL(9, tvalues.int_val(3));

  TEST_ASSERT_EQUAL(8, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(5));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(6));
  TEST_EXPECT_EQUAL(3, tindices.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(4, tdense_shape.int64_val(1));
  
  FUNC_TEST_END();
}

// //dtype float
void test_predict_sparse_2() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  qinglong::PredictRequest ret;
  Output value;
  value.values.resize(1);
  value.values[0].ifeatures.resize(2);

  tensorflow::Feature* out_feature = nullptr;
  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_float_list()->add_value(1);
  out_feature->mutable_float_list()->add_value(2);
  value.values[0].ifeatures[0].feature = out_feature;

  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_float_list()->add_value(11);
  out_feature->mutable_float_list()->add_value(12);
  value.values[0].ifeatures[1].feature = out_feature;

  insertSparseTensor(tensorflow::DT_FLOAT, 2, {1}, "test0", value, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("test0_values");
  auto itr_indices = map.find("test0_indices");
  auto itr_dense_shape = map.find("test0_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(4, tvalues.float_val_size());
  TEST_EXPECT_EQUAL(1, tvalues.float_val(0));
  TEST_EXPECT_EQUAL(2, tvalues.float_val(1));
  TEST_EXPECT_EQUAL(11, tvalues.float_val(2));
  TEST_EXPECT_EQUAL(12, tvalues.float_val(3));

  TEST_ASSERT_EQUAL(8, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(6));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape.int64_val(1));

  FUNC_TEST_END();
}

// //dtype string
void test_predict_sparse_3() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  qinglong::PredictRequest ret;
  Output value;
  value.values.resize(1);
  value.values[0].ifeatures.resize(2);

  tensorflow::Feature* out_feature = nullptr;
  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_bytes_list()->add_value("01");
  out_feature->mutable_bytes_list()->add_value("02");
  value.values[0].ifeatures[0].feature = out_feature;

  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_bytes_list()->add_value("11");
  out_feature->mutable_bytes_list()->add_value("12");
  value.values[0].ifeatures[1].feature = out_feature;

  insertSparseTensor(tensorflow::DT_STRING, 2, {1}, "test0", value, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("test0_values");
  auto itr_indices = map.find("test0_indices");
  auto itr_dense_shape = map.find("test0_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(4, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("01", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("02", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("11", tvalues.string_val(2));
  TEST_EXPECT_EQUAL("12", tvalues.string_val(3));

  TEST_ASSERT_EQUAL(8, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(6));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape.int64_val(1));

  FUNC_TEST_END();
}

void test_predict_sequence_0() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  qinglong::PredictRequest ret;
  Output value;
  value.values.resize(1);
  value.values[0].ifeatures.resize(2);

  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;
  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  value.values[0].ifeatures[0].feature_list = out_featurelist;

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("01");
  out_feature->mutable_bytes_list()->add_value("02");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("11");
  out_feature->mutable_bytes_list()->add_value("12");
  out_feature->mutable_bytes_list()->add_value("13");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("21");
  out_feature->mutable_bytes_list()->add_value("22");
  out_feature->mutable_bytes_list()->add_value("23");
  out_feature->mutable_bytes_list()->add_value("24");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("31");

  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  value.values[0].ifeatures[1].feature_list = out_featurelist;
  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("a01");
  out_feature->mutable_bytes_list()->add_value("a02");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("a11");
  out_feature->mutable_bytes_list()->add_value("a12");
  out_feature->mutable_bytes_list()->add_value("a13");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("a21");
  out_feature->mutable_bytes_list()->add_value("a22");

  insertSequenceTensor(tensorflow::DT_STRING, 2, {-1, 3}, "test0", true, value, ret);

  auto& map = ret.inputs();

  auto itr = map.find("test0");
  auto itr_len = map.find("test0_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  // 2（2个batch 即2个hfeature） * 4（最大的feature size） * 3（每个feature中读取的数据个数，shape[1]大小）
  TEST_ASSERT_EQUAL(24, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("01", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("02", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("", tvalues.string_val(2));

  TEST_EXPECT_EQUAL("11", tvalues.string_val(3));
  TEST_EXPECT_EQUAL("12", tvalues.string_val(4));
  TEST_EXPECT_EQUAL("13", tvalues.string_val(5));

  TEST_EXPECT_EQUAL("21", tvalues.string_val(6));
  TEST_EXPECT_EQUAL("22", tvalues.string_val(7));
  TEST_EXPECT_EQUAL("23", tvalues.string_val(8));

  TEST_EXPECT_EQUAL("31", tvalues.string_val(9));
  TEST_EXPECT_EQUAL("", tvalues.string_val(10));
  TEST_EXPECT_EQUAL("", tvalues.string_val(11));

  TEST_EXPECT_EQUAL("a01", tvalues.string_val(12));
  TEST_EXPECT_EQUAL("a02", tvalues.string_val(13));
  TEST_EXPECT_EQUAL("", tvalues.string_val(14));

  TEST_EXPECT_EQUAL("a11", tvalues.string_val(15));
  TEST_EXPECT_EQUAL("a12", tvalues.string_val(16));
  TEST_EXPECT_EQUAL("a13", tvalues.string_val(17));

  TEST_EXPECT_EQUAL("a21", tvalues.string_val(18));
  TEST_EXPECT_EQUAL("a22", tvalues.string_val(19));
  TEST_EXPECT_EQUAL("", tvalues.string_val(20));

  TEST_EXPECT_EQUAL("", tvalues.string_val(21));
  TEST_EXPECT_EQUAL("", tvalues.string_val(22));
  TEST_EXPECT_EQUAL("", tvalues.string_val(23));

  TEST_ASSERT_EQUAL(2, tlen.int_val_size());
  TEST_EXPECT_EQUAL(4, tlen.int_val(0));
  TEST_EXPECT_EQUAL(3, tlen.int_val(1));
  
  FUNC_TEST_END();
}

void test_predict_sequence_1() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  qinglong::PredictRequest ret;
  Output value;
  value.values.resize(1);
  value.values[0].ifeatures.resize(2);

  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;
  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  value.values[0].ifeatures[0].feature_list = out_featurelist;
  
  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value(1);
  out_feature->mutable_int64_list()->add_value(2);

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value(11);
  out_feature->mutable_int64_list()->add_value(12);
  out_feature->mutable_int64_list()->add_value(13);

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value(21);
  out_feature->mutable_int64_list()->add_value(22);
  out_feature->mutable_int64_list()->add_value(23);
  out_feature->mutable_int64_list()->add_value(24);

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value(31);

  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  value.values[0].ifeatures[1].feature_list = out_featurelist;

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value(101);
  out_feature->mutable_int64_list()->add_value(102);

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value(111);
  out_feature->mutable_int64_list()->add_value(112);
  out_feature->mutable_int64_list()->add_value(113);

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value(121);
  out_feature->mutable_int64_list()->add_value(122);

  insertSequenceTensor(tensorflow::DT_INT32, 2, {-1, 3}, "test0", true, value, ret);

  auto& map = ret.inputs();

  auto itr = map.find("test0");
  auto itr_len = map.find("test0_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  // 2（2个batch 即2个hfeature） * 4（最大的feature size） * 3
  TEST_ASSERT_EQUAL(24, tvalues.int_val_size());
  TEST_EXPECT_EQUAL(1, tvalues.int_val(0));
  TEST_EXPECT_EQUAL(2, tvalues.int_val(1));
  TEST_EXPECT_EQUAL(0, tvalues.int_val(2));

  TEST_EXPECT_EQUAL(11, tvalues.int_val(3));
  TEST_EXPECT_EQUAL(12, tvalues.int_val(4));
  TEST_EXPECT_EQUAL(13, tvalues.int_val(5));

  TEST_EXPECT_EQUAL(21, tvalues.int_val(6));
  TEST_EXPECT_EQUAL(22, tvalues.int_val(7));
  TEST_EXPECT_EQUAL(23, tvalues.int_val(8));

  TEST_EXPECT_EQUAL(31, tvalues.int_val(9));
  TEST_EXPECT_EQUAL(0, tvalues.int_val(10));
  TEST_EXPECT_EQUAL(0, tvalues.int_val(11));

  TEST_EXPECT_EQUAL(101, tvalues.int_val(12));
  TEST_EXPECT_EQUAL(102, tvalues.int_val(13));
  TEST_EXPECT_EQUAL(0, tvalues.int_val(14));

  TEST_EXPECT_EQUAL(111, tvalues.int_val(15));
  TEST_EXPECT_EQUAL(112, tvalues.int_val(16));
  TEST_EXPECT_EQUAL(113, tvalues.int_val(17));

  TEST_EXPECT_EQUAL(121, tvalues.int_val(18));
  TEST_EXPECT_EQUAL(122, tvalues.int_val(19));
  TEST_EXPECT_EQUAL(0, tvalues.int_val(20));

  TEST_EXPECT_EQUAL(0, tvalues.int_val(21));
  TEST_EXPECT_EQUAL(0, tvalues.int_val(22));
  TEST_EXPECT_EQUAL(0, tvalues.int_val(23));

  TEST_ASSERT_EQUAL(2, tlen.int_val_size());
  TEST_EXPECT_EQUAL(4, tlen.int_val(0));
  TEST_EXPECT_EQUAL(3, tlen.int_val(1));
  
  FUNC_TEST_END();
}

void test_predict_sequence_2() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  qinglong::PredictRequest ret;
  Output value;
  value.values.resize(1);
  value.values[0].ifeatures.resize(1);

  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;
  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  value.values[0].ifeatures[0].feature_list = out_featurelist;

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("01");
  out_feature->mutable_bytes_list()->add_value("02");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("11");
  out_feature->mutable_bytes_list()->add_value("12");
  out_feature->mutable_bytes_list()->add_value("13");
  out_feature->mutable_bytes_list()->add_value("14");

  insertSequenceTensor(tensorflow::DT_STRING, 2, {-1, 3}, "test0", true, value, ret);

  auto& map = ret.inputs();

  auto itr = map.find("test0");
  auto itr_len = map.find("test0_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(12, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("01", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("02", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("", tvalues.string_val(2));

  TEST_EXPECT_EQUAL("11", tvalues.string_val(3));
  TEST_EXPECT_EQUAL("12", tvalues.string_val(4));
  TEST_EXPECT_EQUAL("13", tvalues.string_val(5));

  TEST_EXPECT_EQUAL("01", tvalues.string_val(6));
  TEST_EXPECT_EQUAL("02", tvalues.string_val(7));
  TEST_EXPECT_EQUAL("", tvalues.string_val(8));

  TEST_EXPECT_EQUAL("11", tvalues.string_val(9));
  TEST_EXPECT_EQUAL("12", tvalues.string_val(10));
  TEST_EXPECT_EQUAL("13", tvalues.string_val(11));

  TEST_ASSERT_EQUAL(2, tlen.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen.int_val(0));
  TEST_EXPECT_EQUAL(2, tlen.int_val(1));
  
  FUNC_TEST_END();
}

void test_predict_sequence_3() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  qinglong::PredictRequest ret;
  Output value;
  value.values.resize(1);
  value.values[0].ifeatures.resize(1);

  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;
  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  value.values[0].ifeatures[0].feature_list = out_featurelist;

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_float_list()->add_value(1);
  out_feature->mutable_float_list()->add_value(2);

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_float_list()->add_value(11);
  out_feature->mutable_float_list()->add_value(12);
  out_feature->mutable_float_list()->add_value(13);
  out_feature->mutable_float_list()->add_value(14);

  insertSequenceTensor(tensorflow::DT_FLOAT, 2, {-1, 3}, "test0", true, value, ret);

  auto& map = ret.inputs();

  auto itr = map.find("test0");
  auto itr_len = map.find("test0_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(12, tvalues.float_val_size());
  TEST_EXPECT_EQUAL(1, tvalues.float_val(0));
  TEST_EXPECT_EQUAL(2, tvalues.float_val(1));
  TEST_EXPECT_EQUAL(0, tvalues.float_val(2));

  TEST_EXPECT_EQUAL(11, tvalues.float_val(3));
  TEST_EXPECT_EQUAL(12, tvalues.float_val(4));
  TEST_EXPECT_EQUAL(13, tvalues.float_val(5));

  TEST_EXPECT_EQUAL(1, tvalues.float_val(6));
  TEST_EXPECT_EQUAL(2, tvalues.float_val(7));
  TEST_EXPECT_EQUAL(0, tvalues.float_val(8));

  TEST_EXPECT_EQUAL(11, tvalues.float_val(9));
  TEST_EXPECT_EQUAL(12, tvalues.float_val(10));
  TEST_EXPECT_EQUAL(13, tvalues.float_val(11));

  TEST_ASSERT_EQUAL(2, tlen.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen.int_val(0));
  TEST_EXPECT_EQUAL(2, tlen.int_val(1));
  
  FUNC_TEST_END();
}

void test_nearest_expo_days() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  std::vector<const Output*> input_values;
  Output output;
  output.arena = &arena;

  input_values.resize(4);
  Output input1;
  Output input2;
  Output input3;
  Output input4;

  input_values[0] = &input1;
  input_values[1] = &input2;
  input_values[2] = &input3;
  input_values[3] = &input4;

  // appid
  input1.values.resize(1);
  input1.values[0].ifeatures.resize(1);

  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;
  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  input1.values[0].ifeatures[0].feature_list = out_featurelist;

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid0");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid1");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid2");

  // time
  input2.values.resize(1);
  input2.values[0].ifeatures.resize(1);

  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  input2.values[0].ifeatures[0].feature_list = out_featurelist;

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000);

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);

  // now
  input3.values.resize(1);
  input3.values[0].ifeatures.resize(1);

  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000);
  input3.values[0].ifeatures[0].feature = out_feature;

  // item
  input4.values.resize(1);
  input4.values[0].ifeatures.resize(3);

  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_bytes_list()->add_value("appid0");
  input4.values[0].ifeatures[0].feature = out_feature;

  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_bytes_list()->add_value("appid1");
  input4.values[0].ifeatures[1].feature = out_feature;

  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_bytes_list()->add_value("appid2");
  input4.values[0].ifeatures[2].feature = out_feature;

  std::map<std::string, DefaultValue> default_value_map;

  std::vector<std::string> source;
  source.push_back(".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id");
  source.push_back(".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time");
  source.push_back(".request_time");
  source.push_back(".item_feature.item_feature_se.context.feature.item");

  NearestExpoDaysConfig* config = new NearestExpoDaysConfig("test_nearest_expo_days", source, default_value_map, true, false, std::vector<std::string>{});

  LogDebug("start compute");

  config->compute(input_values, output);

  LogDebug("done compute");

  TEST_ASSERT_EQUAL(1, output.values.size());
  TEST_ASSERT_EQUAL(3, output.values[0].ifeatures.size());
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures[0].feature->int64_list().value_size());
  TEST_EXPECT_EQUAL(0, output.values[0].ifeatures[0].feature->int64_list().value(0));
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures[1].feature->int64_list().value_size());
  TEST_EXPECT_EQUAL(4, output.values[0].ifeatures[1].feature->int64_list().value(0));
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures[2].feature->int64_list().value_size());
  TEST_EXPECT_EQUAL(9, output.values[0].ifeatures[2].feature->int64_list().value(0));
  
  FUNC_TEST_END();
}

//featurelist
void test_nearest_expo_days_2() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  std::vector<const Output*> input_values;
  Output output;
  output.arena = &arena;

  input_values.resize(4);
  Output input1;
  Output input2;
  Output input3;
  Output input4;

  input_values[0] = &input1;
  input_values[1] = &input2;
  input_values[2] = &input3;
  input_values[3] = &input4;

  // appid
  input1.values.resize(1);
  input1.values[0].ifeatures.resize(1);

  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;
  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  input1.values[0].ifeatures[0].feature_list = out_featurelist;

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid0");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid1");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid2");

  // time
  input2.values.resize(1);
  input2.values[0].ifeatures.resize(1);

  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  input2.values[0].ifeatures[0].feature_list = out_featurelist;

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000);

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);

  // now
  input3.values.resize(1);
  input3.values[0].ifeatures.resize(1);

  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  out_feature->mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000);
  input3.values[0].ifeatures[0].feature = out_feature;

  // item
  input4.values.resize(1);
  input4.values[0].ifeatures.resize(1);

  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  input4.values[0].ifeatures[0].feature_list = out_featurelist;

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid0");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid1");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid2");

  std::map<std::string, DefaultValue> default_value_map;

  std::vector<std::string> source;
  source.push_back(".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id");
  source.push_back(".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time");
  source.push_back(".request_time");
  source.push_back(".item_feature.item_feature_se.context.feature.item");

  NearestExpoDaysConfig* config = new NearestExpoDaysConfig("test_nearest_expo_days", source, default_value_map, true, false, std::vector<std::string>{});

  LogDebug("start compute");

  config->compute(input_values, output);

  LogDebug("done compute");

  TEST_ASSERT_EQUAL(1, output.values.size());
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures.size());
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures[0].feature_list->feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(0, output.values[0].ifeatures[0].feature_list->feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures[0].feature_list->feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(4, output.values[0].ifeatures[0].feature_list->feature(1).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures[0].feature_list->feature(2).int64_list().value_size());
  TEST_EXPECT_EQUAL(9, output.values[0].ifeatures[0].feature_list->feature(2).int64_list().value(0));
  
  FUNC_TEST_END();
}

//featurelist
void test_nearest_expo_days_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "nearest_expo_days", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  NearestExpoDaysConfig* conf = dynamic_cast<NearestExpoDaysConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)100 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)0 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f6");
  auto itr_len = map.find("f6_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(4, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(4, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(9, tvalues.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen.int_val(0));
  
  FUNC_TEST_END();
}

//feature
void test_nearest_expo_days_4() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "nearest_expo_days", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ]
      }
    }
  })";

   std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  NearestExpoDaysConfig* conf = dynamic_cast<NearestExpoDaysConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)100 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid2");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f6_values");
  auto itr_indices = map.find("f6_indices");
  auto itr_dense_shape = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(3, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(4, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(9, tvalues.int64_val(2));

  TEST_ASSERT_EQUAL(6, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape.int64_val(1));

  FUNC_TEST_END();
}

void test_identity() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "identity", 
          "source": [".item_feature.item_feature_se.context.feature.item"], 
          "max_value" : 5,
          "default_value" : 2
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  IdentityConfig* conf = dynamic_cast<IdentityConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_EXPECT_EQUAL(5, conf->max_value_);
  TEST_EXPECT_EQUAL(2, conf->default_value_);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_int64_list()->add_value(1);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_int64_list()->add_value(3);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_int64_list()->add_value(5);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_int64_list()->add_value(7);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_int64_list()->add_value(-1);

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  
  const auto& map0 = ret.batch(0).context().feature();
  auto itr0 = map0.find("f15");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& feat = itr0->second;
  TEST_ASSERT_EQUAL(5, feat.int64_list().value_size());

  TEST_EXPECT_EQUAL(1, feat.int64_list().value(0));
  TEST_EXPECT_EQUAL(3, feat.int64_list().value(1));
  TEST_EXPECT_EQUAL(5, feat.int64_list().value(2));
  TEST_EXPECT_EQUAL(2, feat.int64_list().value(3));
  TEST_EXPECT_EQUAL(2, feat.int64_list().value(4));

  FUNC_TEST_END();
}

//featurelist
void test_identity_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "identity", 
          "source": [".item_feature.item_feature_se.feature_lists.feature_list.list"], 
          "max_value" : 5,
          "default_value" : 2
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  IdentityConfig* conf = dynamic_cast<IdentityConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_EXPECT_EQUAL(5, conf->max_value_);
  TEST_EXPECT_EQUAL(2, conf->default_value_);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_feature_lists()->mutable_feature_list()))["list"].add_feature()->mutable_int64_list()->add_value(1);
  (*(item->mutable_feature_lists()->mutable_feature_list()))["list"].add_feature()->mutable_int64_list()->add_value(3);
  (*(item->mutable_feature_lists()->mutable_feature_list()))["list"].add_feature()->mutable_int64_list()->add_value(5);
  (*(item->mutable_feature_lists()->mutable_feature_list()))["list"].add_feature()->mutable_int64_list()->add_value(7);
  (*(item->mutable_feature_lists()->mutable_feature_list()))["list"].add_feature()->mutable_int64_list()->add_value(-1);

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());
  
  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f15");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list = itr0->second;
  TEST_ASSERT_EQUAL(5, list.feature_size());
  TEST_EXPECT_EQUAL(1, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(3, list.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(5, list.feature(2).int64_list().value(0));
  TEST_EXPECT_EQUAL(2, list.feature(3).int64_list().value(0));
  TEST_EXPECT_EQUAL(2, list.feature(4).int64_list().value(0));

  FUNC_TEST_END();
}

void test_direct_list() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "expo_123_count", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
                      ".item_feature.item_id.app_id"]
      }
    },
    "item_map": "104435568,母婴,健康育儿,母婴健康",
    "direct_list" : {
      "k1" : ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
      "k2" : ".item_feature.item_id.app_id"
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[1]);
  TEST_ASSERT_BOOL(nullptr != vec[2]);

  ToBatchFeatureConfig* conf = dynamic_cast<ToBatchFeatureConfig*>(vec[1].get());
  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_EXPECT_EQUAL("k1", conf->output_);
  TEST_EXPECT_EQUAL(1, conf->inputs_.size());
  TEST_EXPECT_EQUAL(".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id", conf->inputs_[0].name);

  DirectConfig* conf2 = dynamic_cast<DirectConfig*>(vec[2].get());
  TEST_ASSERT_BOOL(nullptr != conf2);
  TEST_EXPECT_EQUAL("k2", conf2->output_);
  TEST_EXPECT_EQUAL(1, conf2->inputs_.size());
  TEST_EXPECT_EQUAL(".item_feature.item_id.app_id", conf2->inputs_[0].name);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("104435568");
  pb_use->add_user_sequence()->set_app_id("900778570");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("104435568");
  request.add_item_feature()->mutable_item_id()->set_app_id("900778570");

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(2, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());

  const auto& feat_map0 = ret.batch(0).context().feature();
  auto itr01 = feat_map0.find("k1");
  auto itr02 = feat_map0.find("k2");

  TEST_ASSERT_BOOL(itr01 != feat_map0.end());
  TEST_ASSERT_BOOL(itr02 != feat_map0.end());

  TEST_ASSERT_EQUAL(1, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("104435568", itr02->second.bytes_list().value(0));

  TEST_ASSERT_EQUAL(1, itr02->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("104435568", itr02->second.bytes_list().value(0));
  
  const auto& feat_map1 = ret.batch(1).context().feature();
  auto itr11 = feat_map1.find("k1");
  auto itr12 = feat_map1.find("k2");

  TEST_ASSERT_BOOL(itr11 != feat_map1.end());
  TEST_ASSERT_BOOL(itr12 != feat_map1.end());

  TEST_ASSERT_EQUAL(1, itr11->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("900778570", itr12->second.bytes_list().value(0));

  TEST_ASSERT_EQUAL(1, itr12->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("900778570", itr12->second.bytes_list().value(0));

  FUNC_TEST_END();
}

// 两层repetead
void test_direct_list_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0":{ 
            "fe_type" : "hash", 
            "source": [
                ".user_feature.yoyo_imp_off.yoyo_recommend_expo_appid_seq_7d.value"
            ],
            "bucket_size" : 1000
        }
    },    
    "direct_list" : {
      "k1" : ".user_feature.yoyo_imp_off.yoyo_recommend_expo_appid_seq_7d.value"
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[1]);

  ToBatchFeatureConfig* conf = dynamic_cast<ToBatchFeatureConfig*>(vec[1].get());
  TEST_ASSERT_BOOL(nullptr != conf);
  TEST_EXPECT_EQUAL("k1", conf->output_);
  TEST_EXPECT_EQUAL(1, conf->inputs_.size());
  TEST_EXPECT_EQUAL(".user_feature.yoyo_imp_off.yoyo_recommend_expo_appid_seq_7d.value", conf->inputs_[0].name);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::DwsAiYoyoRecommendExpoOfflineEventIncD* pb_yoyo = pb_ufv2->mutable_yoyo_imp_off();
  qinglong::StringArray* pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("name123");
  pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("name456");
  pb_str->add_value("name789");

  /* 
    toSequenceExample函数根据item size确定输出batch，item size应等于fe_list中featur个数
  */
  request.add_item_feature();
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(2, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());

  const auto& feat_map0 = ret.batch(0).context().feature();
  auto itr01 = feat_map0.find("k1");
  TEST_ASSERT_BOOL(itr01 != feat_map0.end());

  TEST_ASSERT_EQUAL(1, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("name123", itr01->second.bytes_list().value(0));
  
  const auto& feat_map1 = ret.batch(1).context().feature();
  auto itr11 = feat_map1.find("k1");
  TEST_ASSERT_BOOL(itr11 != feat_map1.end());

  TEST_ASSERT_EQUAL(2, itr11->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("name456", itr11->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("name789", itr11->second.bytes_list().value(1));

  FUNC_TEST_END();
}

void test_item_to_class() {
  FUNC_TEST_START();

  std::string str = "1,2,3,4;5,6,7,8; 9,9,9;11,12,13,14,15;21,22,23,24";
  std::unordered_map<std::string, AllClasses> dict;
  Item2Class::init_from_string(str, dict);

  TEST_EXPECT_EQUAL(4, dict.size());
  TEST_EXPECT_EQUAL("2", dict["1"].three_class[0]);
  TEST_EXPECT_EQUAL("3", dict["1"].three_class[1]);
  TEST_EXPECT_EQUAL("4", dict["1"].three_class[2]);

  TEST_EXPECT_EQUAL("6", dict["5"].three_class[0]);
  TEST_EXPECT_EQUAL("7", dict["5"].three_class[1]);
  TEST_EXPECT_EQUAL("8", dict["5"].three_class[2]);

  TEST_EXPECT_EQUAL("12", dict["11"].three_class[0]);
  TEST_EXPECT_EQUAL("13", dict["11"].three_class[1]);
  TEST_EXPECT_EQUAL("14", dict["11"].three_class[2]);

  TEST_EXPECT_EQUAL("22", dict["21"].three_class[0]);
  TEST_EXPECT_EQUAL("23", dict["21"].three_class[1]);
  TEST_EXPECT_EQUAL("24", dict["21"].three_class[2]);

  FUNC_TEST_END();
}

void test_to_batch_feature() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "to_batch_feature", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num"]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_num(0);
  pb_use->add_user_sequence()->set_num(1);
  pb_use->add_user_sequence()->set_num(2);
  pb_use->add_user_sequence()->set_num(3);

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();
  request.add_item_feature();
  request.add_item_feature();
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(4, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(2).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(3).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr0 = map0.find("f0");
  TEST_ASSERT_BOOL(itr0 != map0.end());
  TEST_ASSERT_EQUAL(1, itr0->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(0, itr0->second.int64_list().value(0));

  const auto& map1 = ret.batch(1).context().feature();
  auto itr1 = map1.find("f0");
  TEST_ASSERT_BOOL(itr1 != map1.end());
  TEST_ASSERT_EQUAL(1, itr1->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr1->second.int64_list().value(0));

  const auto& map2 = ret.batch(2).context().feature();
  auto itr2 = map2.find("f0");
  TEST_ASSERT_BOOL(itr2 != map2.end());
  TEST_ASSERT_EQUAL(1, itr2->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr2->second.int64_list().value(0));

  const auto& map3 = ret.batch(3).context().feature();
  auto itr3 = map3.find("f0");
  TEST_ASSERT_BOOL(itr3 != map3.end());
  TEST_ASSERT_EQUAL(1, itr3->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr3->second.int64_list().value(0));

  FUNC_TEST_END();
}

// 两层repeated featurelist
void test_to_batch_feature_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "to_batch_feature", 
            "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value"]
        }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::StringArray* pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900744462");
  pb_seq->add_value("104418979");
  pb_seq->add_value("104435568");
  
  pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900242957");

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();
  request.add_item_feature();

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f0_values");
  auto itr_indices = map.find("f0_indices");
  auto itr_dense_shape = map.find("f0_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(4, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("900744462", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("104418979", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("104435568", tvalues.string_val(2));
  TEST_EXPECT_EQUAL("900242957", tvalues.string_val(3));

  TEST_ASSERT_EQUAL(8, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(6));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape.int64_val(1));
  
  FUNC_TEST_END();
}

void test_max_expo_appid() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "max_expo_appid", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("104435568");
  pb_use->add_user_sequence()->set_app_id("104435568");
  pb_use->add_user_sequence()->set_app_id("900778570");

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr0 = map0.find("f0");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  TEST_ASSERT_EQUAL(1, itr0->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("104435568", itr0->second.bytes_list().value(0));

  FUNC_TEST_END();
}

// 两次repeated
void test_max_expo_appid_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0":{ 
            "fe_type" : "max_expo_appid", 
            "source": [".user_feature.yoyo_imp_off.yoyo_recommend_expo_appid_seq_7d.value"]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::DwsAiYoyoRecommendExpoOfflineEventIncD* pb_yoyo = pb_ufv2->mutable_yoyo_imp_off();
  qinglong::StringArray* pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("104435568");
  pb_str->add_value("104435568");
  pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("900778570");

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr0 = map0.find("f0");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  TEST_ASSERT_EQUAL(1, itr0->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("104435568", itr0->second.bytes_list().value(0));

  FUNC_TEST_END();
}

// feature
void test_max_expo_appid_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0":{ 
            "fe_type" : "max_expo_appid", 
            "source": [".item_feature.item_feature_se.context.feature.item"]
        }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "dense"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype);
  TEST_EXPECT_EQUAL("f0", in_vec[0]->input_name);
  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(3, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("900778570");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();
  TEST_EXPECT_EQUAL(1, map.size());

  auto itr = map.find("f0");
  TEST_ASSERT_BOOL(itr != map.end());

  auto& tproto = itr->second;

  TEST_ASSERT_EQUAL(1, tproto.string_val_size());
  TEST_EXPECT_EQUAL("104435568", tproto.string_val(0));

  FUNC_TEST_END();
}

void test_nearest_expo_appid() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "nearest_expo_appid", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("104435568");
  pb_use->add_user_sequence()->set_app_id("104435568");
  pb_use->add_user_sequence()->set_app_id("900778570");

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr0 = map0.find("f0");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  TEST_ASSERT_EQUAL(1, itr0->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("900778570", itr0->second.bytes_list().value(0));

  FUNC_TEST_END();
}

// 两层repeated
void test_nearest_expo_appid_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "nearest_expo_appid", 
            "source": [".user_feature.yoyo_imp_off.yoyo_recommend_expo_appid_seq_7d.value"]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::DwsAiYoyoRecommendExpoOfflineEventIncD* pb_yoyo = pb_ufv2->mutable_yoyo_imp_off();
  qinglong::StringArray* pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("name123");
  pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("name456");
  pb_str->add_value("name789");

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map = ret.batch(0).context().feature();
  auto itr = map.find("f0");

  TEST_ASSERT_BOOL(itr != map.end());

  TEST_ASSERT_EQUAL(2, itr->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("name456", itr->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("name789", itr->second.bytes_list().value(1));

  FUNC_TEST_END();
}

//feature
void test_nearest_expo_appid_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "nearest_expo_appid", 
            "source": [".item_feature.item_feature_se.context.feature.item"]
        }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype);
  TEST_EXPECT_EQUAL("f0", in_vec[0]->input_name);
  TEST_ASSERT_EQUAL(1, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("name123");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("name456");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("name789");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f0_values");
  auto itr_indices = map.find("f0_indices");
  auto itr_dense_shape = map.find("f0_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(3, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("name123", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("name456", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("name789", tvalues.string_val(2));

  TEST_ASSERT_EQUAL(6, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape.int64_val(1));
  
  FUNC_TEST_END();
}

void test_expo_appid_count() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "expo_appid_count", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
                      ".item_feature.item_id.app_id"]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ExpoAppidCountConfig* conf = dynamic_cast<ExpoAppidCountConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("104435568");
  pb_use->add_user_sequence()->set_app_id("104435568");
  pb_use->add_user_sequence()->set_app_id("900778570");
  pb_use->add_user_sequence()->set_app_id("104430325");
  pb_use->add_user_sequence()->set_app_id("104430325");
  pb_use->add_user_sequence()->set_app_id("104430325");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("104435568");
  request.add_item_feature()->mutable_item_id()->set_app_id("900778570");
  request.add_item_feature()->mutable_item_id()->set_app_id("104430325");

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(3, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(2).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr0 = map0.find("f0");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  TEST_ASSERT_EQUAL(1, itr0->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr0->second.int64_list().value(0));

  const auto& map1 = ret.batch(1).context().feature();
  auto itr1 = map1.find("f0");

  TEST_ASSERT_BOOL(itr1 != map0.end());

  TEST_ASSERT_EQUAL(1, itr1->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr1->second.int64_list().value(0));

  const auto& map2 = ret.batch(2).context().feature();
  auto itr2 = map2.find("f0");

  TEST_ASSERT_BOOL(itr2 != map0.end());

  TEST_ASSERT_EQUAL(1, itr2->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr2->second.int64_list().value(0));

  FUNC_TEST_END();
}

//两层repeated 
void test_expo_appid_count_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "expo_appid_count", 
            "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
                      ".item_feature.item_feature_se.feature_lists.feature_list.list"]
        }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ExpoAppidCountConfig* conf = dynamic_cast<ExpoAppidCountConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(3, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::StringArray* pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("104435568");
  pb_seq->add_value("104435568");
  pb_seq->add_value("900778570");
  pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("104430325");
  pb_seq->add_value("104430325");
  pb_seq->add_value("104430325");

  // item
  auto& map1 = *request.add_item_feature()->mutable_item_feature_se()->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = map1["list"];
  tensorflow::Feature* feat = list.add_feature();
  feat->mutable_bytes_list()->add_value("104435568");
  feat->mutable_bytes_list()->add_value("900778570");
  feat->mutable_bytes_list()->add_value("104430325");

  feat = list.add_feature();
  feat->mutable_bytes_list()->add_value("104435568");
  feat->mutable_bytes_list()->add_value("900778570");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f0");
  auto itr_len = map.find("f0_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(6, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(2, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(3, tvalues.int64_val(2));

  TEST_EXPECT_EQUAL(2, tvalues.int64_val(3));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(4));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(5));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen.int_val(0));
  
  FUNC_TEST_END();
}

// 输入1 一层repeated
void test_expo_appid_count_v2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "expo_appid_count_v2", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
                      ".item_feature.item_id.app_id"]
        },
        "f1": {
          "fe_type" : "direct", 
          "source": ["f0:0"]
        },
        "f2": {
          "fe_type" : "direct", 
          "source": ["f0:1"]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ExpoAppidCountV2Config* conf = dynamic_cast<ExpoAppidCountV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("104435568");
  pb_use->add_user_sequence()->set_app_id("104435568");
  pb_use->add_user_sequence()->set_app_id("900778570");
  pb_use->add_user_sequence()->set_app_id("104430325");
  pb_use->add_user_sequence()->set_app_id("104430325");
  pb_use->add_user_sequence()->set_app_id("104430325");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("104435568");
  request.add_item_feature()->mutable_item_id()->set_app_id("900778570");
  request.add_item_feature()->mutable_item_id()->set_app_id("104430325");

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(3, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(2).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr00 = map0.find("f1");
  auto itr01 = map0.find("f2");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_EQUAL(1, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.int64_list().value(0));

  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_EQUAL(1, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr01->second.int64_list().value(0));

  const auto& map1 = ret.batch(1).context().feature();
  auto itr10 = map1.find("f1");
  auto itr11 = map1.find("f2");

  TEST_ASSERT_BOOL(itr10 != map0.end());
  TEST_ASSERT_EQUAL(1, itr10->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr10->second.int64_list().value(0));

  TEST_ASSERT_BOOL(itr11 != map0.end());
  TEST_ASSERT_EQUAL(1, itr11->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr11->second.int64_list().value(0));

  const auto& map2 = ret.batch(2).context().feature();
  auto itr20 = map2.find("f1");
  auto itr21 = map2.find("f2");

  TEST_ASSERT_BOOL(itr20 != map0.end());
  TEST_ASSERT_EQUAL(1, itr20->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr20->second.int64_list().value(0));

  TEST_ASSERT_BOOL(itr21 != map0.end());
  TEST_ASSERT_EQUAL(1, itr21->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr21->second.int64_list().value(0));

  FUNC_TEST_END();
}

// 输入1 两层repeated
void test_expo_appid_count_v2_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "expo_appid_count_v2", 
            "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
                      ".item_feature.item_id.app_id"]
        },
        "f1": {
          "fe_type" : "direct", 
          "source": ["f0:0"]
        },
        "f2": {
          "fe_type" : "direct", 
          "source": ["f0:1"]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ExpoAppidCountV2Config* conf = dynamic_cast<ExpoAppidCountV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::StringArray* pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("104435568");
  pb_seq->add_value("104435568");
  pb_seq->add_value("900778570");
  pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("104430325");
  pb_seq->add_value("104430325");
  pb_seq->add_value("104430325");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("104435568");
  request.add_item_feature()->mutable_item_id()->set_app_id("900778570");
  request.add_item_feature()->mutable_item_id()->set_app_id("104430325");

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(3, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(2).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr00 = map0.find("f1");
  auto itr01 = map0.find("f2");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_EQUAL(1, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.int64_list().value(0));

  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_EQUAL(1, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr01->second.int64_list().value(0));

  const auto& map1 = ret.batch(1).context().feature();
  auto itr10 = map1.find("f1");
  auto itr11 = map1.find("f2");

  TEST_ASSERT_BOOL(itr10 != map0.end());
  TEST_ASSERT_EQUAL(1, itr10->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr10->second.int64_list().value(0));

  TEST_ASSERT_BOOL(itr11 != map0.end());
  TEST_ASSERT_EQUAL(1, itr11->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr11->second.int64_list().value(0));

  const auto& map2 = ret.batch(2).context().feature();
  auto itr20 = map2.find("f1");
  auto itr21 = map2.find("f2");

  TEST_ASSERT_BOOL(itr20 != map0.end());
  TEST_ASSERT_EQUAL(1, itr20->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr20->second.int64_list().value(0));

  TEST_ASSERT_BOOL(itr21 != map0.end());
  TEST_ASSERT_EQUAL(1, itr21->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr21->second.int64_list().value(0));

  FUNC_TEST_END();
}

/* 
  输入1 两层repeated
  输入2 两层repeated
*/
void test_expo_appid_count_v2_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "expo_appid_count_v2", 
            "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
                      ".item_feature.item_feature_se.feature_lists.feature_list.list"]
        },
        "f1": {
          "fe_type" : "direct", 
          "source": ["f0:0"]
        },
        "f2": {
          "fe_type" : "direct", 
          "source": ["f0:1"]
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ExpoAppidCountV2Config* conf = dynamic_cast<ExpoAppidCountV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::StringArray* pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("104435568");
  pb_seq->add_value("104435568");
  pb_seq->add_value("900778570");
  pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("104430325");
  pb_seq->add_value("104430325");
  pb_seq->add_value("104430325");

  // item
  auto& map = *request.add_item_feature()->mutable_item_feature_se()->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = map["list"];
  tensorflow::Feature* feat = list.add_feature();
  feat->mutable_bytes_list()->add_value("104435568");
  feat->mutable_bytes_list()->add_value("900778570");
  feat->mutable_bytes_list()->add_value("104430325");

  feat = list.add_feature();
  feat->mutable_bytes_list()->add_value("104435568");
  feat->mutable_bytes_list()->add_value("900778570");
  feat->mutable_bytes_list()->add_value("666");

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr00 = map0.find("f1");
  auto itr01 = map0.find("f2");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr01 != map0.end());

  TEST_ASSERT_EQUAL(2, itr00->second.feature_size());
  TEST_ASSERT_EQUAL(2, itr01->second.feature_size());

  // bool
  TEST_ASSERT_EQUAL(3, itr00->second.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr00->second.feature(0).int64_list().value(1));
  TEST_EXPECT_EQUAL(1, itr00->second.feature(0).int64_list().value(2));

  TEST_ASSERT_EQUAL(3, itr00->second.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr00->second.feature(1).int64_list().value(1));
  TEST_EXPECT_EQUAL(0, itr00->second.feature(1).int64_list().value(2));

  // int
  TEST_ASSERT_EQUAL(3, itr01->second.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr01->second.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr01->second.feature(0).int64_list().value(1));
  TEST_EXPECT_EQUAL(3, itr01->second.feature(0).int64_list().value(2));

  TEST_ASSERT_EQUAL(3, itr01->second.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr01->second.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr01->second.feature(1).int64_list().value(1));
  TEST_EXPECT_EQUAL(0, itr01->second.feature(1).int64_list().value(2));

  FUNC_TEST_END();
}

void test_max_123_class() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "max_123_class", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
                      ".item_feature.item_id.app_id"]
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "900874118,工具,生活工具,其他;900242957,工具,生活工具,家居控制;104430258,工具,生活工具,视频监控;900802099,工具,娱乐工具,运势测算"
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Max123ClassConfig* conf = dynamic_cast<Max123ClassConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("900874118");
  pb_use->add_user_sequence()->set_app_id("900242957");
  pb_use->add_user_sequence()->set_app_id("104430258");
  pb_use->add_user_sequence()->set_app_id("900802099");
  pb_use->add_user_sequence()->set_app_id("900802099");

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr00 = map0.find("f13");
  auto itr01 = map0.find("f14");
  auto itr02 = map0.find("f15");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr02 != map0.end());

  TEST_ASSERT_EQUAL(1, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("工具", itr00->second.bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("生活工具", itr01->second.bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, itr02->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("运势测算", itr02->second.bytes_list().value(0));
  
  FUNC_TEST_END();
}

// 两层repeated 
void test_max_123_class_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : { 
          "fe_type" : "max_123_class", 
          "source": [".user_feature.yoyo_imp_off.yoyo_recommend_expo_appid_seq_7d.value"]
      }, 
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "900874118,工具,生活工具,其他;900242957,工具,生活工具,家居控制;104430258,工具,生活工具,视频监控;900802099,工具,娱乐工具,运势测算"
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Max123ClassConfig* conf = dynamic_cast<Max123ClassConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::DwsAiYoyoRecommendExpoOfflineEventIncD* pb_yoyo = pb_ufv2->mutable_yoyo_imp_off();
  qinglong::StringArray* pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("900874118");
  pb_str->add_value("900242957");
  pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("104430258");
  pb_str->add_value("900802099");
  pb_str->add_value("900802099");

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr00 = map0.find("f13");
  auto itr01 = map0.find("f14");
  auto itr02 = map0.find("f15");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr02 != map0.end());

  TEST_ASSERT_EQUAL(1, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("工具", itr00->second.bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("生活工具", itr01->second.bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, itr02->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("运势测算", itr02->second.bytes_list().value(0));
  
  FUNC_TEST_END();
}

// feature
void test_max_123_class_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : { 
          "fe_type" : "max_123_class", 
          "source": [".item_feature.item_feature_se.context.feature.item"]
      }, 
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "900874118,工具,生活工具,其他;900242957,工具,生活工具,家居控制;104430258,工具,生活工具,视频监控;900802099,工具,娱乐工具,运势测算"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "dense"
        },
        "f14": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "dense"
        },
        "f15": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "dense"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Max123ClassConfig* conf = dynamic_cast<Max123ClassConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype);
  TEST_EXPECT_EQUAL("f13", in_vec[0]->input_name);
  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(3, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("900874118");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("900242957");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("900802099");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("900802099");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("104430258");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();
  TEST_EXPECT_EQUAL(3, map.size());

  auto itr00 = map.find("f13");
  TEST_ASSERT_BOOL(itr00 != map.end());

  auto& tproto_00 = itr00->second;

  TEST_ASSERT_EQUAL(2, tproto_00.string_val_size());
  TEST_EXPECT_EQUAL("工具", tproto_00.string_val(0));
  TEST_EXPECT_EQUAL("工具", tproto_00.string_val(1));

  auto itr01 = map.find("f14");
  TEST_ASSERT_BOOL(itr01 != map.end());

  auto& tproto_01 = itr01->second;

  TEST_ASSERT_EQUAL(2, tproto_01.string_val_size());
  TEST_EXPECT_EQUAL("生活工具", tproto_01.string_val(0));
  TEST_EXPECT_EQUAL("生活工具", tproto_01.string_val(1));

  auto itr02 = map.find("f15");
  TEST_ASSERT_BOOL(itr02 != map.end());

  auto& tproto_02 = itr02->second;

  TEST_ASSERT_EQUAL(2, tproto_02.string_val_size());
  TEST_EXPECT_EQUAL("运势测算", tproto_02.string_val(0));
  TEST_EXPECT_EQUAL("运势测算", tproto_02.string_val(1));

  FUNC_TEST_END();
}

// direct采用深度复制，并且不修改数据源，对相同source多次执行direct，每次都能拿到符合预期的数值
void test_direct_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "direct", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"]
      },
      "f11" : {
          "fe_type" : "direct", 
          "source": ["f15:0"]
      },
      "f12" : {
          "fe_type" : "direct", 
          "source": ["f15:0"]
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DirectConfig* conf = dynamic_cast<DirectConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("900778570");
  pb_use->add_user_sequence()->set_app_id("104436666");

   /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr00 = map0.find("f15");

  TEST_ASSERT_BOOL(itr00 != map0.end());

  const auto& list00 = itr00->second;
  TEST_ASSERT_EQUAL(2, list00.feature_size());
  TEST_ASSERT_EQUAL(1, list00.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("900778570", list00.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("104436666", list00.feature(1).bytes_list().value(0));

  auto itr01 = map0.find("f11");

  TEST_ASSERT_BOOL(itr01 != map0.end());

  const auto& list01 = itr01->second;
  TEST_ASSERT_EQUAL(2, list01.feature_size());
  TEST_ASSERT_EQUAL(1, list01.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("900778570", list01.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list01.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("104436666", list01.feature(1).bytes_list().value(0));

  auto itr02 = map0.find("f12");

  TEST_ASSERT_BOOL(itr02 != map0.end());

  const auto& list02 = itr02->second;
  TEST_ASSERT_EQUAL(2, list02.feature_size());
  TEST_ASSERT_EQUAL(1, list02.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("900778570", list02.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list02.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("104436666", list02.feature(1).bytes_list().value(0));

  FUNC_TEST_END();
}

//computer后 数据源修改，direct内数据不变
void test_direct_2() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  std::vector<const Output*> input_values;
  Output output;
  output.arena = &arena;

  input_values.resize(1);
  Output input1;

  input_values[0] = &input1;
  input1.values.resize(1);
  input1.values[0].ifeatures.resize(1);

  // appid  
  tensorflow::Feature* out_feature = nullptr;
  tensorflow::FeatureList* out_featurelist = nullptr;
  out_featurelist = google::protobuf::Arena::CreateMessage<tensorflow::FeatureList>(&arena);
  input1.values[0].ifeatures[0].feature_list = out_featurelist;

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid0");

  std::vector<std::string> source;
  source.push_back(".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id");
  std::map<std::string, DefaultValue> default_value_map;

  DirectConfig* config = new DirectConfig("test_direct_2", source, default_value_map, true, false, std::vector<std::string>{}, false);

  LogDebug("start compute");

  config->compute(input_values, output);

  LogDebug("done compute");

  TEST_ASSERT_EQUAL(1, output.values.size());
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures.size());
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures[0].feature_list->feature_size());
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures[0].feature_list->feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("appid0", output.values[0].ifeatures[0].feature_list->feature(0).bytes_list().value(0));

  // 修改源数据
  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid1");

  out_feature = out_featurelist->add_feature();
  out_feature->mutable_bytes_list()->add_value("appid1");

  // dirct后的数据不受影响
  TEST_ASSERT_EQUAL(1, output.values.size());
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures.size());
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures[0].feature_list->feature_size());
  TEST_ASSERT_EQUAL(1, output.values[0].ifeatures[0].feature_list->feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("appid0", output.values[0].ifeatures[0].feature_list->feature(0).bytes_list().value(0));

  FUNC_TEST_END();
}

//feature
void test_direct_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "direct", 
          "source": [".item_feature.item_feature_se.context.feature.appid"]
      },
      "f11" : {
          "fe_type" : "direct", 
          "source": ["f15:0"]
      },
      "f12" : {
          "fe_type" : "direct", 
          "source": ["f15:0"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [2] , 
            "model_input_type" : "dense"
        },
        "f12": {
            "dtype" : "string",
            "shape" : [2] , 
            "model_input_type" : "dense"
        },
        "f11": {
            "dtype" : "string",
            "shape" : [2] , 
            "model_input_type" : "dense"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DirectConfig* conf = dynamic_cast<DirectConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype);
  TEST_EXPECT_EQUAL("f11", in_vec[0]->input_name);
  TEST_EXPECT_EQUAL("f12", in_vec[1]->input_name);
  TEST_EXPECT_EQUAL("f15", in_vec[2]->input_name);
  TEST_ASSERT_EQUAL(1, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::Feature& input_f = (*(item->mutable_context()->mutable_feature()))["appid"];
  input_f.mutable_bytes_list()->add_value("900778570");
  input_f.mutable_bytes_list()->add_value("104436666");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();
  TEST_EXPECT_EQUAL(3, map.size());

  auto itr00 = map.find("f15");
  TEST_ASSERT_BOOL(itr00 != map.end());

  auto& tproto_00 = itr00->second;

  TEST_ASSERT_EQUAL(2, tproto_00.string_val_size());
  TEST_EXPECT_EQUAL("900778570", tproto_00.string_val(0));
  TEST_EXPECT_EQUAL("104436666", tproto_00.string_val(1));

  auto itr01 = map.find("f11");
  TEST_ASSERT_BOOL(itr01 != map.end());

  auto& tproto_01 = itr01->second;

  TEST_ASSERT_EQUAL(2, tproto_01.string_val_size());
  TEST_EXPECT_EQUAL("900778570", tproto_01.string_val(0));
  TEST_EXPECT_EQUAL("104436666", tproto_01.string_val(1));

  auto itr02 = map.find("f12");
  TEST_ASSERT_BOOL(itr02 != map.end());

  auto& tproto_02 = itr02->second;

  TEST_ASSERT_EQUAL(2, tproto_02.string_val_size());
  TEST_EXPECT_EQUAL("900778570", tproto_02.string_val(0));
  TEST_EXPECT_EQUAL("104436666", tproto_02.string_val(1));

  FUNC_TEST_END();
}

//设置auto_type，且model_config类型和pb类型不同
void test_direct_4() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "direct", 
          "source": [".item_feature.item_feature_se.context.feature.appid"],
          "auto_type" : true
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "int64",
            "shape" : [2] , 
            "model_input_type" : "dense"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DirectConfig* conf = dynamic_cast<DirectConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_INT64, in_vec[0]->dtype);
  TEST_EXPECT_EQUAL("f15", in_vec[0]->input_name);
  TEST_ASSERT_EQUAL(1, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::Feature& input_f = (*(item->mutable_context()->mutable_feature()))["appid"];
  input_f.mutable_bytes_list()->add_value("900778570");
  input_f.mutable_bytes_list()->add_value("104436666");

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);

  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();
  TEST_EXPECT_EQUAL(1, map.size());

  auto itr00 = map.find("f15");
  TEST_ASSERT_BOOL(itr00 != map.end());

  auto& tproto_00 = itr00->second;

  TEST_ASSERT_EQUAL(2, tproto_00.string_val_size());
  TEST_EXPECT_EQUAL("900778570", tproto_00.string_val(0));
  TEST_EXPECT_EQUAL("104436666", tproto_00.string_val(1));

  FUNC_TEST_END();
}

void test_useraction() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13": {
          "fe_type" : "vocab_list", 
          "source": [
              ".user_action.item_id.app_id"
          ], 
          "vocabs" : ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  VocabListConfig* config = dynamic_cast<VocabListConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // user_action
  qinglong::UserAction* user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("3");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("5");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("7");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("9");

  //item不为0
  request.add_item_feature();

  qinglong::BatchSequenceExample ba_ret;
  toSequenceExample(&arena, request, vec, ba_ret);

  TEST_ASSERT_EQUAL(1, ba_ret.batch_size());
  TEST_ASSERT_EQUAL(true, ba_ret.batch(0).has_feature_lists());

  const auto& map0 = ba_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map0.find("f13");
  TEST_ASSERT_BOOL(itr00 != map0.end());

  TEST_ASSERT_EQUAL(4, itr00->second.feature_size());

  TEST_ASSERT_EQUAL(1, itr00->second.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr00->second.feature(0).int64_list().value(0));

  TEST_ASSERT_EQUAL(1, itr00->second.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(5, itr00->second.feature(1).int64_list().value(0));

  TEST_ASSERT_EQUAL(1, itr00->second.feature(2).int64_list().value_size());
  TEST_EXPECT_EQUAL(7, itr00->second.feature(2).int64_list().value(0));

  TEST_ASSERT_EQUAL(1, itr00->second.feature(3).int64_list().value_size());
  TEST_EXPECT_EQUAL(9, itr00->second.feature(3).int64_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr01 = map.find("f13");
  auto itr_len01 = map.find("f13_length");

  auto& tvalues01 = itr01->second;
  auto& tlen01 = itr_len01->second;

  TEST_ASSERT_EQUAL(4, tvalues01.int64_val_size());
  TEST_EXPECT_EQUAL(3, tvalues01.int64_val(0));
  TEST_EXPECT_EQUAL(5, tvalues01.int64_val(1));
  TEST_EXPECT_EQUAL(7, tvalues01.int64_val(2));
  TEST_EXPECT_EQUAL(9, tvalues01.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen01.int_val_size());
  TEST_EXPECT_EQUAL(4, tlen01.int_val(0));
  
  FUNC_TEST_END();
}

//检测空feature输入，输出空sparse
void sparse_empty_shape(const google::protobuf::Map<std::basic_string<char>, tensorflow::TensorProto>& map, const std::string output_values, const std::string output_indices) {
  auto itr_value = map.find(output_values);
  auto itr_indices = map.find(output_indices);

  TEST_ASSERT_BOOL(itr_value != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());

  auto& tvalues = itr_value->second;
  auto& tindices = itr_indices->second;

  TEST_ASSERT_EQUAL(1, tvalues.tensor_shape().dim_size());
  TEST_EXPECT_EQUAL(0, tvalues.tensor_shape().dim(0).size());

  TEST_ASSERT_EQUAL(0, tindices.int64_val_size());
}

//检测空request离线处理后生成空feature
void feature_empty_test(const google::protobuf::Map<std::basic_string<char>, tensorflow::Feature>& map, const std::string output_name){
  auto itr = map.find(output_name);

  TEST_ASSERT_BOOL(itr != map.end());

  TEST_EXPECT_EQUAL(0, itr->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL(0, itr->second.float_list().value_size());
  TEST_EXPECT_EQUAL(0, itr->second.int64_list().value_size());
}

void test_empty_feature() {
  FUNC_TEST_START();
  
  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_topn",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ],
        "empty" : true,
        "start" : 60,
        "topn": 3,
        "type": 2, 
        "default_value": "life is life!"
      },
      "f1": {
        "fe_type" : "seq_appcategory_topn",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ],
        "empty" : true,
        "start" : 60,
        "topn": 3,
        "type": 2, 
        "default_value": "life is life!"
      },
      "f2" : {
          "fe_type" : "direct", 
          "source": ["f1:0"],
          "empty" : true
      },
      "f3" : {
          "fe_type" : "direct", 
          "source": ["f1:1"],
          "empty" : true
      },
      "f4" : {
          "fe_type" : "direct", 
          "source": ["f1:2"],
          "empty" : true
      },
      "f5": {
        "fe_type" : "seq_n",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ],
        "save" : true,
        "empty" : true,
        "end" : 86401,
        "start" : 60,
        "clip_size": 3
      },
      "f6": {
        "fe_type" : "seq_hit", 
        "source": [
            ".item_feature.item_feature_se.context.feature.appid",
            ".item_feature.item_feature_se.context.feature.time",
            ".request_time",
            ".item_feature.item_feature_se.context.feature.item"
        ],
        "empty" : true,
        "start" : 864000
      },
      "f7": {
          "fe_type" : "seq_hit_value", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "empty" : true,
          "start" : 864000
      },
      "f8": {
          "fe_type" : "seq_hit_num", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "empty" : true,
          "start" : 864000,
          "max_num" : 2
      },
      "f9": {
          "fe_type" : "seq_hit_duration", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "empty" : true,
          "start" : 864000
      },
      "f10" : {
          "fe_type" : "stat_ctr", 
          "source": [
              ".item_feature.item_feature_se.context.feature.click",
              ".item_feature.item_feature_se.context.feature.expo"],
          "min_expo" : 100,
          "empty" : true,
          "default_value" : 0
      },
      "f11" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": ["f10:0"],
          "size" : 26.2,
          "empty" : true,
          "bucket_type" : 1
      },
      "f12" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": ["f10:0"],
          "size" : 6.7,
          "empty" : true,
          "bucket_type" : 2
      },
      "f13" : {
          "fe_type" : "seq_app2category", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time"
          ],
          "start" : 840000,
          "empty" : true,
          "dedup" : true,
          "clip_size" : 3,
          "default_value" : "NOT_EXIST"
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f13:0"],
          "empty" : true
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f13:1"],
          "empty" : true
      },
      "f16" : {
          "fe_type" : "direct", 
          "source": ["f13:2"],
          "empty" : true
      },
      "f17": {
          "fe_type" : "hash", 
          "source": [".user_feature.user_feature_se.context.feature.value"], 
          "bucket_size" : 100,
          "empty" : true,
          "concat_with_name" : false
      },
      "f18": {
          "fe_type" : "filter_appid", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time"
          ], 
          "days" : [1, 3, 10],
          "max_len" :3, 
          "empty" : true,
          "save": false
      },
      "f19" : {
          "fe_type" : "direct", 
          "source": ["f18:0"],
          "empty" : true
      },
      "f20" : {
          "fe_type" : "direct", 
          "source": ["f18:1"],
          "empty" : true
      },
      "f21" : {
          "fe_type" : "direct", 
          "source": ["f18:2"],
          "empty" : true
      },
      "f22":{ 
          "fe_type" : "max_expo_appid", 
          "source": [".item_feature.item_feature_se.context.feature.item"],
          "empty" : true
      },
      "f23": {
          "fe_type" : "nearest_expo_appid", 
          "source": [".item_feature.item_feature_se.context.feature.item"],
          "empty" : true
      },
      "f24": {
          "fe_type" : "expo_appid_count", 
          "source": [".user_feature.user_feature_se.context.feature.value",
                     ".item_feature.item_feature_se.context.feature.item"],
          "empty" : true
      },
      "f25": {
          "fe_type" : "expo_appid_count_v2", 
          "source": [".user_feature.user_feature_se.context.feature.value",
                    ".item_feature.item_feature_se.context.feature.item"],
          "empty" : true
      },
      "f26": {
          "fe_type" : "direct", 
          "source": ["f25:0"],
          "empty" : true
      },
      "f27": {
          "fe_type" : "direct", 
          "source": ["f25:1"],
          "empty" : true
      },
      "f28": {
        "fe_type" : "nearest_expo_days", 
        "source": [
            ".item_feature.item_feature_se.context.feature.appid",
            ".item_feature.item_feature_se.context.feature.time",
            ".request_time",
            ".item_feature.item_feature_se.context.feature.item"
        ],
        "empty" : true
      },
      "f29" : {
          "fe_type" : "max_123_class", 
          "source": [".item_feature.item_feature_se.context.feature.item"],
          "empty" : true
      },
      "f30" : {
          "fe_type" : "direct", 
          "source": ["f29:0"],
          "empty" : true
      },
      "f31" : {
          "fe_type" : "direct", 
          "source": ["f29:1"],
          "empty" : true
      },
      "f32" : {
          "fe_type" : "direct", 
          "source": ["f29:2"],
          "empty" : true
      },
      "f33" : {
          "fe_type" : "expo_123_count", 
          "source": [".user_feature.user_feature_se.context.feature.value",
                      ".item_feature.item_feature_se.context.feature.item"],
          "empty" : true
      },
      "f34" : {
          "fe_type" : "direct", 
          "source": ["f33:0"],
          "empty" : true
      },
      "f35" : {
          "fe_type" : "direct", 
          "source": ["f33:1"],
          "empty" : true
      },
      "f36" : {
          "fe_type" : "direct", 
          "source": ["f33:2"],
          "empty" : true
      },
      "f37" : {
          "fe_type" : "expo_123_count_v2", 
          "source": [".user_feature.user_feature_se.context.feature.value",
                      ".item_feature.item_feature_se.context.feature.item"],
          "empty" : true
      },
      "f38" : {
          "fe_type" : "direct", 
          "source": ["f37:0"],
          "empty" : true
      },
      "f39" : {
          "fe_type" : "direct", 
          "source": ["f37:1"],
          "empty" : true
      },
      "f40" : {
          "fe_type" : "direct", 
          "source": ["f37:2"],
          "empty" : true
      },
      "f41" : {
          "fe_type" : "direct", 
          "source": ["f37:3"],
          "empty" : true
      },
      "f42" : {
          "fe_type" : "direct", 
          "source": ["f37:4"],
          "empty" : true
      },
      "f43" : {
          "fe_type" : "direct", 
          "source": ["f37:5"],
          "empty" : true
      },
      "f44": {
          "fe_type" : "to_feature", 
          "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value"],
          "empty" : true
      },
      "f45": {
          "fe_type" : "to_batch_feature", 
          "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value"],
          "empty" : true
      },
      "f46": {
          "fe_type" : "bucketize", 
          "source": [".item_feature.item_feature_se.context.feature.num_one_star"], 
          "boundary" : [5.0, 11.0, 34.0, 87.0],
          "empty" : true
      },
      "f47": {
          "fe_type" : "vocab_list", 
          "source": [
              ".item_feature.item_feature_se.context.feature.item"
          ], 
          "vocabs" : ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
          "empty" : true
      },
      "f48" : {
          "fe_type" : "identity", 
          "source": [".item_feature.item_feature_se.context.feature.item"], 
          "max_value" : 5,
          "default_value" : 2,
          "empty" : true
      }
    },
    "item_map": "104435568,母婴,健康育儿,母婴健康;900778570,工具,生活工具,日历;104430325,社交,聊天交友,匿名/陌生人;900834783,默认值,默认值,默认值;220738225,默认值,默认值,默认值;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
      "f0": {
          "dtype" : "string",
          "shape" : [1] ,
          "model_input_type" : "sparse"
      },
      "f2": {
          "dtype" : "string",
          "shape" : [1] ,
          "model_input_type" : "sparse"
      },
      "f3": {
          "dtype" : "string",
          "shape" : [1] ,
          "model_input_type" : "sparse"
      },
      "f4": {
          "dtype" : "string",
          "shape" : [1] ,
          "model_input_type" : "sparse"
      },
      "f5": {
          "dtype" : "string",
          "shape" : [1] ,
          "model_input_type" : "sparse"
      },
      "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
      },
      "f7": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
      },
      "f8": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
      },
      "f9": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
      },
      "f10": {
          "dtype" : "float",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f11": {
          "dtype" : "float",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f12": {
          "dtype" : "float",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f14": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f15": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f16": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f17": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f19": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f20": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f21": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f22": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f23": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f24": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f26": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f27": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f28": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f30": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f31": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f32": {
          "dtype" : "string",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f34": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f35": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f36": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f38": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f39": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f40": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f41": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f42": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f43": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f44": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f45": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f46": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f47": {
          "dtype" : "int32",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      },
      "f48": {
          "dtype" : "int64",
          "shape" : [1] , 
          "model_input_type" : "sparse"
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(49, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);
  
  // item
  request.add_item_feature();
  
  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();

  feature_empty_test(map0, "f0");
  feature_empty_test(map0, "f2");
  feature_empty_test(map0, "f3");
  feature_empty_test(map0, "f4");
  feature_empty_test(map0, "f5");
  feature_empty_test(map0, "f6");
  feature_empty_test(map0, "f7");
  feature_empty_test(map0, "f8");
  feature_empty_test(map0, "f9");
  feature_empty_test(map0, "f10");
  feature_empty_test(map0, "f11");
  feature_empty_test(map0, "f12");
  feature_empty_test(map0, "f14");
  feature_empty_test(map0, "f15");
  feature_empty_test(map0, "f16");
  feature_empty_test(map0, "f17");
  feature_empty_test(map0, "f19");
  feature_empty_test(map0, "f20");
  feature_empty_test(map0, "f21");
  feature_empty_test(map0, "f22");
  feature_empty_test(map0, "f23");
  feature_empty_test(map0, "f24");
  feature_empty_test(map0, "f26");
  feature_empty_test(map0, "f27");
  feature_empty_test(map0, "f28");
  feature_empty_test(map0, "f30");
  feature_empty_test(map0, "f31");
  feature_empty_test(map0, "f32");
  feature_empty_test(map0, "f34");
  feature_empty_test(map0, "f35");
  feature_empty_test(map0, "f36");
  feature_empty_test(map0, "f38");
  feature_empty_test(map0, "f39");
  feature_empty_test(map0, "f40");
  feature_empty_test(map0, "f41");
  feature_empty_test(map0, "f42");
  feature_empty_test(map0, "f43");
  feature_empty_test(map0, "f44");
  feature_empty_test(map0, "f45");
  feature_empty_test(map0, "f46");
  feature_empty_test(map0, "f47");
  feature_empty_test(map0, "f48");

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  sparse_empty_shape(map, "f0_values", "f0_indices");
  sparse_empty_shape(map, "f2_values", "f2_indices");
  sparse_empty_shape(map, "f3_values", "f3_indices");
  sparse_empty_shape(map, "f4_values", "f4_indices");
  sparse_empty_shape(map, "f5_values", "f5_indices");
  sparse_empty_shape(map, "f6_values", "f6_indices");
  sparse_empty_shape(map, "f7_values", "f7_indices");
  sparse_empty_shape(map, "f8_values", "f8_indices");
  sparse_empty_shape(map, "f9_values", "f9_indices");
  sparse_empty_shape(map, "f10_values", "f10_indices");
  sparse_empty_shape(map, "f11_values", "f11_indices");
  sparse_empty_shape(map, "f12_values", "f12_indices");
  sparse_empty_shape(map, "f14_values", "f14_indices");
  sparse_empty_shape(map, "f15_values", "f15_indices");
  sparse_empty_shape(map, "f16_values", "f16_indices");
  sparse_empty_shape(map, "f17_values", "f17_indices");
  sparse_empty_shape(map, "f19_values", "f19_indices");
  sparse_empty_shape(map, "f20_values", "f20_indices");
  sparse_empty_shape(map, "f21_values", "f21_indices");
  sparse_empty_shape(map, "f22_values", "f22_indices");
  sparse_empty_shape(map, "f23_values", "f23_indices");
  sparse_empty_shape(map, "f24_values", "f24_indices");
  sparse_empty_shape(map, "f26_values", "f26_indices");
  sparse_empty_shape(map, "f27_values", "f27_indices");
  sparse_empty_shape(map, "f28_values", "f28_indices");
  sparse_empty_shape(map, "f30_values", "f30_indices");
  sparse_empty_shape(map, "f31_values", "f31_indices");
  sparse_empty_shape(map, "f32_values", "f32_indices");
  sparse_empty_shape(map, "f34_values", "f34_indices");
  sparse_empty_shape(map, "f35_values", "f35_indices");
  sparse_empty_shape(map, "f36_values", "f36_indices");
  sparse_empty_shape(map, "f38_values", "f38_indices");
  sparse_empty_shape(map, "f39_values", "f39_indices");
  sparse_empty_shape(map, "f40_values", "f40_indices");
  sparse_empty_shape(map, "f41_values", "f41_indices");
  sparse_empty_shape(map, "f42_values", "f42_indices");
  sparse_empty_shape(map, "f43_values", "f43_indices");
  sparse_empty_shape(map, "f44_values", "f44_indices");
  sparse_empty_shape(map, "f45_values", "f45_indices");
  sparse_empty_shape(map, "f46_values", "f46_indices");
  sparse_empty_shape(map, "f47_values", "f47_indices");
  sparse_empty_shape(map, "f48_values", "f48_indices");

  FUNC_TEST_END();
}

//检车离线处理后felist中fe个数为0
void batch_empty_felist(const google::protobuf::Map<std::basic_string<char>, tensorflow::FeatureList>& map, const std::string& output) {
  auto itr = map.find(output);

  TEST_ASSERT_BOOL(itr != map.end());

  const auto& list = itr->second;
  TEST_EXPECT_EQUAL(0, list.feature_size());
}

//检测sequence模型数据为空
void sequence_empty_shape(const google::protobuf::Map<std::basic_string<char>, tensorflow::TensorProto>& map, 
                          const std::string& output, const std::string& output_length,
                          uint64_t batch_size, int64_t shape_dim) {
  auto itr = map.find(output);
  auto itr_len = map.find(output_length);

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(3, tvalues.tensor_shape().dim_size());
  TEST_EXPECT_EQUAL(batch_size, tvalues.tensor_shape().dim(0).size());
  TEST_EXPECT_EQUAL(0, tvalues.tensor_shape().dim(1).size());
  TEST_EXPECT_EQUAL(shape_dim, tvalues.tensor_shape().dim(2).size());

  TEST_ASSERT_EQUAL(batch_size, tlen.int_val_size());
  for (uint64_t i = 0; i < batch_size; i++) {
    TEST_EXPECT_EQUAL(0, tlen.int_val(i));
  }
}

//测试json中empty为true，数据为felist的输出
void test_empty_felist() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f1": {
            "fe_type" : "bucketize", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num"], 
            "boundary" : [0.09, 1.01, 2.56],
            "empty" : true
        },
        "f2": {
            "fe_type" : "hash", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.query"], 
            "bucket_size" : 100,
            "concat_with_name" : false,
            "empty" : true
        },
      "f3": {
          "fe_type" : "vocab_list", 
          "source": [".user_action.item_id.app_id"], 
          "vocabs" : ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
          "empty" : true
      },
      "f4" : {
          "fe_type" : "direct", 
          "source": ["f3:0"],
          "empty" : true
      },
      "f5": {
          "fe_type" : "filter_appid", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time"
          ], 
          "days" : [1],
          "max_len" :100, 
          "empty" : true
      },
      "f6": {
          "fe_type" : "expo_appid_count", 
          "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
                    ".item_feature.item_feature_se.feature_lists.feature_list.list"],
          "empty" : true
      },
      "f7": {
          "fe_type" : "expo_appid_count_v2", 
          "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
                    ".item_feature.item_feature_se.feature_lists.feature_list.list"],
          "empty" : true
      },
      "f8": {
        "fe_type" : "direct", 
        "source": ["f7:0"],
        "empty" : true
      },
      "f9": {
        "fe_type" : "direct", 
        "source": ["f7:1"],
        "empty" : true
      },
      "f10" : {
          "fe_type" : "expo_123_count", 
          "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
                      ".item_feature.item_feature_se.feature_lists.feature_list.list"],
          "empty" : true
      },
      "f11" : {
          "fe_type" : "direct", 
          "source": ["f10:0"],
          "empty" : true
      },
      "f12" : {
          "fe_type" : "direct", 
          "source": ["f10:1"],
          "empty" : true
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f10:2"],
          "empty" : true
      },
      "f14" : {
          "fe_type" : "expo_123_count_v2", 
          "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
                      ".item_feature.item_feature_se.feature_lists.feature_list.list"],
          "empty" : true
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f14:0"],
          "empty" : true
      },
      "f16" : {
          "fe_type" : "direct", 
          "source": ["f14:1"],
          "empty" : true
      },
      "f17" : {
          "fe_type" : "direct", 
          "source": ["f14:2"],
          "empty" : true
      },
      "f18" : {
          "fe_type" : "direct", 
          "source": ["f14:3"],
          "empty" : true
      },
      "f19" : {
          "fe_type" : "direct", 
          "source": ["f14:4"],
          "empty" : true
      },
      "f20" : {
          "fe_type" : "direct", 
          "source": ["f14:5"],
          "empty" : true
      },
      "f21": {
          "fe_type" : "nearest_expo_days", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "empty" : true
      },
      "f22" : {
          "fe_type" : "appid_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.context.feature.item"],
          "bucket_size" : 100,
          "empty" : true
      },
      "f23" : {
          "fe_type" : "identity", 
          "source": [".item_feature.item_feature_se.feature_lists.feature_list.list"], 
          "max_value" : 5,
          "default_value" : 2,
          "empty" : true
      },
      "f24": {
        "fe_type" : "seq_topn",
        "source": [
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
          ".request_time"
        ],
        "start" : 60,
        "topn": 3,
        "type": 2, 
        "default_value": "life is life!",
        "empty" : true
      },
      "f25": {
        "fe_type" : "seq_appcategory_topn",
        "source": [
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
          ".request_time"
        ],
        "start" : 60,
        "topn": 3,
        "type": 2, 
        "default_value": "life is life!",
        "empty" : true
      },
      "f26" : {
          "fe_type" : "direct", 
          "source": ["f25:0"],
          "empty" : true
      },
      "f27" : {
          "fe_type" : "direct", 
          "source": ["f25:1"],
          "empty" : true
      },
      "f28" : {
          "fe_type" : "direct", 
          "source": ["f25:2"],
          "empty" : true
      },
      "f29": {
        "fe_type" : "seq_n",
        "source": [
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
          ".request_time"
        ],
        "save" : true,
        "end" : 86401,
        "start" : 60,
        "clip_size": 3,
        "default_value": "life is life!",
        "empty" : true
      },
      "f30": {
          "fe_type" : "seq_hit", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000,
          "empty" : true
      },
      "f31": {
          "fe_type" : "seq_hit_num", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000,
          "max_num" : 2,
          "empty" : true
      },
      "f32": {
          "fe_type" : "seq_hit_value", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000,
          "empty" : true
      },
      "f33": {
          "fe_type" : "seq_hit_duration", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000,
          "empty" : true
      },
      "f34" : {
          "fe_type" : "cross2", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"],
          "fea1_clip" : 2,
          "fea2_clip" : 2,
          "clip_size" : 3,
          "empty" : true
      },
      "f35" : {
          "fe_type" : "stat_ctr", 
          "source": [
              ".user_action.click",
              ".user_action.impression"],
          "min_expo" : 100,
          "default_value" : 0,
          "empty" : true
      },
      "f36" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": ["f35:0"],
          "size" : 26.2,
          "bucket_type" : 1,
          "empty" : true
      },
      "f37" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": ["f35:0"],
          "size" : 6.7,
          "bucket_type" : 2,
          "empty" : true
      },
      "f38" : {
          "fe_type" : "seq_app2category", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time"
          ],
          "start" : 840000,
          "dedup" : false,
          "clip_size" : 3,
          "empty" : true
      },
      "f39" : {
          "fe_type" : "direct", 
          "source": ["f38:0"],
          "empty" : true
      },
      "f40" : {
          "fe_type" : "direct", 
          "source": ["f38:1"],
          "empty" : true
      },
      "f41" : {
          "fe_type" : "direct", 
          "source": ["f38:2"],
          "empty" : true
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f1": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f2": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f3": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f4": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f5": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f6": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f9": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f11": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f12": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f15": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f16": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f17": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f18": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f19": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f20": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f21": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f22": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f23": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f24": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f26": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f27": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f28": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f29": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f30": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f31": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f32": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f33": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f34": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f35": {
            "dtype" : "float",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f36": {
            "dtype" : "float",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f37": {
            "dtype" : "float",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f39": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f40": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f41": {
            "dtype" : "string",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& batch_map = batch_ret.batch(0).feature_lists().feature_list();

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  const std::string before = "f";
  const std::string after = "_length";

  for (uint64_t i = 1; i < 42; i++) {
    //多个value无法直接提取
    if (7 != i && 10 != i && 14 != i && 25 != i && 38 != i) {
      std::cout << "f" << i << ":" << std::endl;
      batch_empty_felist(batch_map, before + std::to_string(i));
      sequence_empty_shape(map, before + std::to_string(i), before + std::to_string(i) + after, 1, 3);
    }
  }

  FUNC_TEST_END();
}

void test_throw() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  qinglong::FeRequest request1;
  qinglong::BatchSequenceExample batch_ret;

  std::vector<std::string> source;
  source.push_back("E@.user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id");
  std::map<std::string, DefaultValue> default_value_map;

  std::shared_ptr<ToFeatureConfig> config(new ToFeatureConfig("test_throw", source, default_value_map, true, false, std::vector<std::string>{}));
  std::vector<std::shared_ptr<Config>> vec;
  vec.emplace_back(config);

  // item不为空
  request1.add_item_feature();

  bool flag = false;

  try {
    //allow_empty_output_为false，数据为空，框架抛出异常
    toSequenceExample(&arena, request1, vec, batch_ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  std::string str = R"({
    "extract_features" : {
        "f1": {
            "fe_type" : "bucketize", 
            "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.throw"], 
            "boundary" : [0.09, 1.01, 2.56]
        }
    }
  })";

  vec.clear();
  flag = false;
  
  try {
    JsonConfigMgr::parse_from_string(str, vec); 
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  std::string str2 = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "hash", 
            "source": [".item_feature.item_id.item_id"], 
            "bucket_size" : 100,
            "concat_with_name" : false
        }
    }
  })";

  vec.clear();
  JsonConfigMgr::parse_from_string(str2, vec);
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  flag = false;

  try {
    toSequenceExample(&arena, request, vec, ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  std::string str3 = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "appid_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.context.feature.item"],
          "bucket_size" : 100
      }
    }
  })";

  vec.clear();
  JsonConfigMgr::parse_from_string(str3, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  flag = false;

  try {
    toSequenceExample(&arena, request, vec, ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("900778570");
  pb_use->add_user_sequence()->set_app_id("104436666");

  // item
  request.add_item_feature();

  flag = false;
  
  try {
    toSequenceExample(&arena, request, vec, ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  std::string str4 = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "expo_123_count", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
                      ".item_feature.item_id.app_id"]
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:null"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:-2"]
      }
    },
    "item_map": "104435568,母婴,健康育儿,母婴健康;900778570,工具,生活工具,日历;104430325,社交,聊天交友,匿名/陌生人;900834783,默认值,默认值,默认值;220738225,默认值,默认值,默认值;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  vec.clear();
  flag = false;

  try {
    JsonConfigMgr::parse_from_string(str4, vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  
  TEST_EXPECT_EQUAL(true, flag);

  std::string str5 = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f14:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f13:0"]
      }
    }
  })";

  vec.clear();
  flag = false;

  try {
    JsonConfigMgr::parse_from_string(str5, vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  
  TEST_EXPECT_EQUAL(true, flag);

  std::string str6 = R"(
    <config>
        <features>
            <feature name="f3" type="vocab_set" source=".user_action.item_id.app_id" dict="app0,app1,app2,app3,app4,app5,app6" />
            <feature name="f3" type="direct" source=".item_feature.item_feature_se.context.feature.direct" />
        </features>
    </config>
  )";

  vec.clear();
  flag = false;

  try {
    XmlConfigMgr::parse_from_string(str6, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }

  TEST_EXPECT_EQUAL(true, flag);

  std::string request_str;
  int32_t size = request.ByteSizeLong();
  request_str.resize(size);
  request.SerializeToArray(&request_str[0], size);
  flag = false;

  try {
    to_sequence_example(request_str.c_str(), request_str.length());
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }

  TEST_EXPECT_EQUAL(true, flag);

  std::string appinfo_config_str = R"(
    <config>
        <features>
            <feature name="f10" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="0" default_value="test_no_data" dict_type="appinfo" />
        </features>
    </config>

    <app_info>test/data/666</app_info>
  )";

  vec.clear();
  flag = false;

  try {
    XmlConfigMgr::parse_from_string(appinfo_config_str, "/home/featureextractor/", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }

  TEST_EXPECT_EQUAL(true, flag);

  std::string item_map_config_str = R"(
    <config>
        <features>
            <feature name="f10" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="0" default_value="test_no_data" dict_type="item_map" />
        </features>
    </config>

    <item_map>test/data/666</item_map>
  )";

  vec.clear();
  flag = false;

  try {
    XmlConfigMgr::parse_from_string(appinfo_config_str, "/home/featureextractor/", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }

  TEST_EXPECT_EQUAL(true, flag);

  FUNC_TEST_END();
}

void test_throw_online(){
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  qinglong::PredictRequest ret;
  Output value;
  value.values.resize(1);
  value.values[0].ifeatures.resize(2);

  bool flag = false;
  try {
    insertDenseTensor(tensorflow::DT_STRING, 2, {2}, "throw", value, ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  flag = false;
  try {
    insertSparseTensor(tensorflow::DT_STRING, 3, {2}, "throw", value, ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  flag = false;
  try {
    insertSparseTensor(tensorflow::DT_STRING, 2, {2}, "throw", value, ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  flag = false;
  try {
    insertSequenceTensor(tensorflow::DT_FLOAT, 2, {-1}, "throw", true, value, ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  tensorflow::Feature* out_feature = nullptr;
  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  value.values[0].ifeatures[0].feature = out_feature;
  out_feature->mutable_float_list()->add_value(1);

  out_feature = google::protobuf::Arena::CreateMessage<tensorflow::Feature>(&arena);
  value.values[0].ifeatures[1].feature = out_feature;
  out_feature->mutable_float_list()->add_value(1);
  
  flag = false;
  try {
    insertDenseTensor(tensorflow::DT_FLOAT, 2, {2}, "throw", value, ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  //insertSparseTensor函数修改feature内数据为空，返回空sparse

  // flag = false;
  // try {
  //   insertSparseTensor(tensorflow::DT_STRING, 2, {2}, "throw", value, ret);
  // } catch (const std::runtime_error& e) {
  //   std::cout << e.what() << std::endl;
  //   flag = true;
  // }
  // TEST_EXPECT_EQUAL(true, flag);

  flag = false;
  try {
    insertSequenceTensor(tensorflow::DT_FLOAT, 2, {-1,2}, "throw", true, value, ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  FUNC_TEST_END();
}

//feature
void test_string_to_int64_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "string_to_int64",
          "source": [
              ".item_feature.item_feature_se.context.feature.time"
          ],
          "default_value" : 1700000000000
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  StringToInt64Config* config = dynamic_cast<StringToInt64Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_bytes_list()->add_value("1727580548000");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_bytes_list()->add_value("");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_bytes_list()->add_value("a172736153900");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_bytes_list()->add_value("1721577341000");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL((int64_t)1727580548000, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL((int64_t)1700000000000, itr00->second.int64_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL((int64_t)1700000000000, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL((int64_t)1721577341000, itr01->second.int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_LIST_INT64(({1727580548000, 1700000000000, 1700000000000, 1721577341000}), tvalues0);

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  std::vector<int32_t> indices = {0, 0, 0, 1, 1, 0, 1, 1};
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), tindices0);

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_string_to_int64_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "string_to_int64",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.time"
          ],
          "default_value" : 1700000000000
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  StringToInt64Config* config = dynamic_cast<StringToInt64Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["time"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("test");
  fate->mutable_bytes_list()->add_value("1727490578000");
  fate = feat_list.add_feature();

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(1700000000000, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(1727490578000, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(1700000000000, list.feature(1).int64_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_LIST_INT64(({1700000000000, 1727490578000, 1700000000000, 0}), tvalues0);

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

void test_appid_to_123_class_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f10": {
          "fe_type" : "appid_to_123_class", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"],
          "class_type" : 0,
          "default_value" : "test_no_data"
      },
      "f11": {
          "fe_type" : "appid_to_123_class", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"],
          "class_type" : 1,
          "default_value" : "test_no_data"
      },
      "f12": {
          "fe_type" : "appid_to_123_class", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"],
          "class_type" : 2,
          "default_value" : "test_no_data"
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f10": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f11": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f12": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  AppidTo123ClassConfig* conf = dynamic_cast<AppidTo123ClassConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104418979");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900785693");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f10");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"工具"}, {"工具"}, {"办公"}}), itr00->second);

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"娱乐工具"}, {"娱乐工具"}, {"办公软件"}}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"变声器"}, {"娱乐测试"}, {"日程管理"}}), itr02->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f10");
  auto itr_len0 = map.find("f10_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"工具", "", "工具", "", "办公", ""}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f11");
  auto itr_len1 = map.find("f11_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"娱乐工具", "", "娱乐工具", "", "办公软件", ""}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  auto itr2 = map.find("f12");
  auto itr_len2 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"变声器", "", "娱乐测试", "", "日程管理", ""}), itr2->second);
  TEST_LIST_INT32(({3}), itr_len2->second);

  FUNC_TEST_END();
}

void test_appid_to_123_class_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f10": {
          "fe_type" : "appid_to_123_class", 
          "source": ["E@.item_feature.item_feature_se.context.feature.appid"],
          "class_type" : 0,
          "default_value" : "test_no_data"
      },
      "f11": {
          "fe_type" : "appid_to_123_class", 
          "source": ["E@.item_feature.item_feature_se.context.feature.appid"],
          "class_type" : 1,
          "default_value" : "test_no_data"
      },
      "f12": {
          "fe_type" : "appid_to_123_class", 
          "source": ["E@.item_feature.item_feature_se.context.feature.appid"],
          "class_type" : 2,
          "default_value" : "test_no_data"
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f10": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f11": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f12": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  AppidTo123ClassConfig* conf = dynamic_cast<AppidTo123ClassConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104418979");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900744462");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900785693");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("111");

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(3, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(2).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();
  const auto& map02 = batch_ret.batch(2).context().feature();
  
  auto itr00 = map00.find("f10");
  auto itr10 = map01.find("f10");
  auto itr20 = map02.find("f10");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_ASSERT_BOOL(itr20 != map02.end());

  TEST_FEATURE_STR(({"工具", "工具", "办公"}), itr00->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr10->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr20->second);

  auto itr01 = map00.find("f11");
  auto itr11 = map01.find("f11");
  auto itr21 = map02.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_ASSERT_BOOL(itr21 != map02.end());

  TEST_FEATURE_STR(({"娱乐工具", "娱乐工具", "办公软件"}), itr01->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr11->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr21->second);

  auto itr02 = map00.find("f12");
  auto itr12 = map01.find("f12");
  auto itr22 = map02.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());
  TEST_ASSERT_BOOL(itr22 != map02.end());

  TEST_FEATURE_STR(({"变声器", "娱乐测试", "日程管理"}), itr02->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr12->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr22->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f10_values");
  auto itr_indices0 = map.find("f10_indices");
  auto itr_dense_shape0 = map.find("f10_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0, 2, 0}), ({3, 3}), ({"工具", "工具", "办公", "test_no_data", "test_no_data"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f11_values");
  auto itr_indices1 = map.find("f11_indices");
  auto itr_dense_shape1 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0, 2, 0}), ({3, 3}), ({"娱乐工具", "娱乐工具", "办公软件", "test_no_data", "test_no_data"}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f12_values");
  auto itr_indices2 = map.find("f12_indices");
  auto itr_dense_shape2 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0, 2, 0}), ({3, 3}), ({"变声器", "娱乐测试", "日程管理", "test_no_data", "test_no_data"}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  FUNC_TEST_END();
}

// 如果未设置默认值，且允许输出空，输出为空
void test_appid_to_123_class_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="appid_to_123_class" source=".item_feature.item_feature_se.context.feature.appid" class_type="0" strategy="empty" />
            <feature name="f11" type="appid_to_123_class" source=".item_feature.item_feature_se.context.feature.appid" class_type="1" strategy="empty" />
            <feature name="f12" type="appid_to_123_class" source=".item_feature.item_feature_se.context.feature.appid" class_type="2" strategy="empty" />
        </features>
    </config>

    <item_map path="test/data/item_map.txt" />
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  AppidTo123ClassConfig* conf = dynamic_cast<AppidTo123ClassConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("111");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f10");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({}), itr00->second);

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_STR(({}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_STR(({}), itr02->second);

  FUNC_TEST_END();
}

void test_is_match_str_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="is_match_str" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" default_value="test_no_data" />
        </features>
    </config>

    <app_info path="test/data/app_info_minor_mini" />
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f10" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  IsMatchStrConfig* conf = dynamic_cast<IsMatchStrConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("自由落体模拟器");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("通讯录同步助手");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f10");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"自由落体模拟器"}, {"test_no_data"}, {"通讯录同步助手"}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f10");
  auto itr_len0 = map.find("f10_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"自由落体模拟器", "test_no_data", "通讯录同步助手"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  FUNC_TEST_END();
}

void test_is_match_str_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="is_match_str" source="E@.item_feature.item_feature_se.context.feature.appid" default_value="test_no_data" />
        </features>
    </config>

    <app_info path="test/data/app_info_minor_mini" />
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f10" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  IsMatchStrConfig* conf = dynamic_cast<IsMatchStrConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("自由落体模拟器");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900744462");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("通讯录同步助手");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("111");

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(3, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(2).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();
  const auto& map02 = batch_ret.batch(2).context().feature();
  
  auto itr00 = map00.find("f10");
  auto itr10 = map01.find("f10");
  auto itr20 = map02.find("f10");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_ASSERT_BOOL(itr20 != map02.end());

  TEST_FEATURE_STR(({"自由落体模拟器", "test_no_data", "通讯录同步助手"}), itr00->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr10->second);
  TEST_FEATURE_STR(({}), itr20->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f10_values");
  auto itr_indices0 = map.find("f10_indices");
  auto itr_dense_shape0 = map.find("f10_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({3, 3}), ({"自由落体模拟器", "test_no_data", "通讯录同步助手", "test_no_data"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

//feature
void test_trans_type_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "trans_type",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid"
          ],
          "data_type" : "string",
          "default_value" : "-20"
      },
      "f14" : {
          "fe_type" : "trans_type",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid"
          ],
          "data_type" : "float",
          "default_value" : "-20"
      },
      "f15" : {
          "fe_type" : "trans_type",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid"
          ],
          "data_type" : "int64",
          "default_value" : "-20"
      },
      "f16" : {
          "fe_type" : "trans_type",
          "source": [
              ".item_feature.item_feature_se.context.feature.num"
          ],
          "data_type" : "string",
          "default_value" : "-20"
      },
      "f17" : {
          "fe_type" : "trans_type",
          "source": [
              ".item_feature.item_feature_se.context.feature.num"
          ],
          "data_type" : "float",
          "default_value" : "-20"
      },
        "f18" : {
          "fe_type" : "trans_type",
          "source": [
              ".item_feature.item_feature_se.context.feature.num"
          ],
          "data_type" : "int64",
          "default_value" : "-20"
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(6, vec.size());

  TransTypeConfig* config = dynamic_cast<TransTypeConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("133");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("a");
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(222);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"133", "a"}), itr00->second);

  auto itr01 = map00.find("f14");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_FLOAT(({133, -20}), itr01->second);

  auto itr02 = map00.find("f15");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_INT64(({133, -20}), itr02->second);

  auto itr03 = map00.find("f16");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_STR(({"222"}), itr03->second);

  auto itr04 = map00.find("f17");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_FLOAT(({222}), itr04->second);

  auto itr05 = map00.find("f18");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_INT64(({222}), itr05->second);

  FUNC_TEST_END();
}

//featurelist
void test_trans_type_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "trans_type",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.float"
          ],
          "data_type" : "string",
          "default_value" : "-20"
      },
      "f14" : {
          "fe_type" : "trans_type",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.float"
          ],
          "data_type" : "float",
          "default_value" : "-20"
      },
      "f15" : {
          "fe_type" : "trans_type",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.float"
          ],
          "data_type" : "int64",
          "default_value" : "-20"
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TransTypeConfig* config = dynamic_cast<TransTypeConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["float"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(22.2);
  fate->mutable_float_list()->add_value(11.1);
  fate = feat_list.add_feature();

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"22.200001", "11.100000"}, {"-20"}}), itr00->second);

  auto itr01 = map00.find("f14");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_FLOAT(({{22.2, 11.1}, {-20}}), itr01->second);

  auto itr02 = map00.find("f15");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{22, 11}, {-20}}), itr02->second);

  FUNC_TEST_END();
}

void test_fully_cross_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "fully_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.context.feature.item"]
      },
      "f16" : {
          "fe_type" : "fully_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.context.feature.num"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f16": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  FullyCrossConfig* conf = dynamic_cast<FullyCrossConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("001");
  pb_use->add_user_sequence()->set_app_id("002");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(123);
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("456");
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(456);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"001_123", "002_123"}), itr00->second);
  TEST_FEATURE_STR(({"001_456", "002_456"}), itr10->second);

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_STR(({"001_123", "002_123"}), itr01->second);
  TEST_FEATURE_STR(({"001_456", "002_456"}), itr11->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({"001_123", "002_123", "001_456", "002_456"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f16_values");
  auto itr_indices1 = map.find("f16_indices");
  auto itr_dense_shape1 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({"001_123", "002_123", "001_456", "002_456"}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_fully_cross_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "fully_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"],
          "connector" : "#",
          "default_value" : "test_no_date"
      },
      "f16" : {
          "fe_type" : "fully_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num",
              ".item_feature.item_feature_se.feature_lists.feature_list.float"],
          "connector" : "#",
          "default_value" : "test_no_date"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f16": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  FullyCrossConfig* conf = dynamic_cast<FullyCrossConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype)

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_num(1);
  pb_use->add_user_sequence()->set_num(2);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("456");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("789");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["float"];
  fate = feat_list2.add_feature();
  fate->mutable_float_list()->add_value(123.0);
  fate->mutable_float_list()->add_value(456.0);
  fate = feat_list2.add_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());

  TEST_FEATURE_LIST_STR(({{"1#123", "2#123", "1#456", "2#456"}, {"1#789", "2#789"}}), itr00->second);

  auto itr01 = map0.find("f16");
  TEST_ASSERT_BOOL(itr01 != map0.end());

  TEST_FEATURE_LIST_STR(({{"1#123.000000", "2#123.000000", "1#456.000000", "2#456.000000"}, {"test_no_date"}}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"1#123", "2#123", "1#789", "2#789"}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f16");
  auto itr_len1 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"1#123.000000", "2#123.000000", "test_no_date", ""}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  FUNC_TEST_END();
}

void test_fully_cross_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "fully_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"],
          "connector" : "#",
          "default_value" : "test_no_date"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  FullyCrossConfig* conf = dynamic_cast<FullyCrossConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype)

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::StringArray* pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("000");

  pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("010");
  pb_seq->add_value("011");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("456");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());

  TEST_FEATURE_LIST_STR(({{"000#123", "010#123", "011#123"}, {"000#456", "010#456", "011#456"}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"000#123", "010#123", "000#456", "010#456"}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  FUNC_TEST_END();
}

// 多个item，第一个pb为空，和items中第一个item为空
void test_fully_cross_4() {
  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="fully_cross" source="E@.item_feature.item_feature_se.context.feature.empty,E@.item_feature.item_feature_se.context.feature.num" default_value="test_no_date" />
            <feature name="f16" type="fully_cross" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,E@.item_feature.item_feature_se.context.feature.num" default_value="test_no_date" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
        <input name="f16" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  FullyCrossConfig* conf = dynamic_cast<FullyCrossConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("001");
  pb_use->add_user_sequence()->set_app_id("002");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(456);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"test_no_date"}), itr00->second);
  TEST_FEATURE_STR(({"test_no_date"}), itr10->second);

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_STR(({"test_no_date"}), itr01->second);
  TEST_FEATURE_STR(({"001_456", "002_456"}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), ({"test_no_date", "test_no_date"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f16_values");
  auto itr_indices1 = map.find("f16_indices");
  auto itr_dense_shape1 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0, 1, 1}), ({2, 2}), ({"test_no_date", "001_456", "002_456"}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_connect_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "connect", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration"],
          "connector" : "#",
          "tail" : "game"
      },
      "f16" : {
          "fe_type" : "connect", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_type"],
          "connector" : "#",
          "tail" : "market"
      },
      "f17" : {
          "fe_type" : "connect", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_type",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration"],
          "tail" : "market"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f16": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f17": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("001");
  pb_info->set_use_duration(1000);
  pb_info->set_event_type("安装");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("002");
  pb_info->set_use_duration(2000);
  pb_info->set_event_type("卸载");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("003");
  pb_info->set_use_duration(3000);
  pb_info->set_event_type("安装");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("004");
  pb_info->set_use_duration(4000);
  pb_info->set_event_type("点击");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"001#1000#game"}, {"002#2000#game"}, {"003#3000#game"}, {"004#4000#game"}}), itr00->second);

  auto itr01 = map00.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"001#安装#market"}, {"002#卸载#market"}, {"003#安装#market"}, {"004#点击#market"}}), itr01->second);

  auto itr02 = map00.find("f17");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"001_安装_1000_market"}, {"002_卸载_2000_market"}, {"003_安装_3000_market"}, {"004_点击_4000_market"}}), itr02->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"001#1000#game", "002#2000#game", "003#3000#game", "004#4000#game"}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f16");
  auto itr_len1 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"001#安装#market", "002#卸载#market", "003#安装#market", "004#点击#market"}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  FUNC_TEST_END();
}

void test_connect_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "connect", 
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.float",
              ".item_feature.item_feature_se.feature_lists.feature_list.float"]
      },
      "f16" : {
          "fe_type" : "connect", 
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.float",
              ".item_feature.item_feature_se.feature_lists.feature_list.num"]
      },
      "f17" : {
          "fe_type" : "connect", 
          "connector" : "001",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.float",
              ".item_feature.item_feature_se.feature_lists.feature_list.float",
              ".item_feature.item_feature_se.feature_lists.feature_list.num",
              ".item_feature.item_feature_se.feature_lists.feature_list.num"]  
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f16": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f17": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        } 
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype)

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["num"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("456");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("567");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["float"];
  fate = feat_list2.add_feature();
  fate->mutable_float_list()->add_value(12.0);
  fate->mutable_float_list()->add_value(34.0);
  fate = feat_list2.add_feature();
  fate->mutable_float_list()->add_value(56.0);
  fate = feat_list2.add_feature();
  fate->mutable_float_list()->add_value(78.0);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_STR(({{"12.000000_12.000000", "34.000000_34.000000"}, {"56.000000_56.000000"}, {"78.000000_78.000000"}}), itr00->second);

  auto itr01 = map0.find("f17");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_FEATURE_LIST_STR(({{"12.00000000112.000000001123001123", "34.00000000134.000000001456001456"}, {"56.00000000156.000000001123001123"}, {"78.00000000178.000000001567001567"}}), itr01->second);


  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();
  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"12.000000_12.000000", "56.000000_56.000000", "78.000000_78.000000"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f16");
  auto itr_len1 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"12.000000_123", "56.000000_123", "78.000000_567"}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  auto itr2 = map.find("f17");
  auto itr_len2 = map.find("f17_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"12.00000000112.000000001123001123", "56.00000000156.000000001123001123", "78.00000000178.000000001567001567"}), itr2->second);
  TEST_LIST_INT32(({3}), itr_len2->second);

  FUNC_TEST_END();
}

void test_connect_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f16" : {
          "fe_type" : "connect", 
          "source": [
              ".item_feature.item_feature_se.context.feature.app_id",
              ".item_feature.item_feature_se.context.feature.num"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f16": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);
  TEST_ASSERT_EQUAL(1, in_vec.size());

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(123);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("456");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("789");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("321");
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(321);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("654");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_STR(({"123_123"}), itr01->second);
  TEST_FEATURE_STR(({"321_321"}), itr11->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();
  
  auto itr_values1 = map.find("f16_values");
  auto itr_indices1 = map.find("f16_indices");
  auto itr_dense_shape1 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), ({"123_123", "321_321"}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_connect_4() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "connect", 
          "source": [
              ".item_feature.item_feature_se.context.feature.app_id",
              ".user_feature.user_id.oaid"],
          "tail" : "test"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  pb_ufv2->mutable_user_id()->set_oaid("000");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("456");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("789");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("321");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("654");

  try {
    toSequenceExample(&arena, request, vec, batch_ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
  }

  FUNC_TEST_END();
}

void test_connect_5() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f16" : {
          "fe_type" : "connect", 
          "source": [
              ".item_feature.item_feature_se.context.feature.app_id",
              ".item_feature.item_feature_se.feature_lists.feature_list.num"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f16": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);
  
  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["num"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("456");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("567");

  // item
  // item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("456");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("789");


  try {
    toSequenceExample(&arena, request, vec, batch_ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
  }

  try {
    toPredictRequest(&arena, request, vec, in_vec, ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
  }

  FUNC_TEST_END();
}

void test_connect_6() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f16" : {
          "fe_type" : "connect", 
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.num",
              ".item_feature.item_feature_se.feature_lists.feature_list.float"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f16": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["num"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("456");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("567");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["float"];
  fate = feat_list2.add_feature();
  fate->mutable_float_list()->add_value(12.0);
  fate->mutable_float_list()->add_value(34.0);
  fate = feat_list2.add_feature();
  fate->mutable_float_list()->add_value(56.0);


  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map0.find("f16");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_STR(({{"123_12.000000", "456_34.000000"},{"123_56.000000"}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();
  auto itr1 = map.find("f16");
  auto itr_len1 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"123_12.000000", "123_56.000000"}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  FUNC_TEST_END();
}

void test_connect_7() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "connect", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration"],
          "connector" : "\\001",
          "tail" : "game"
      },
      "f16" : {
          "fe_type" : "connect", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_type"],
          "connector" : "\\031",
          "tail" : "market"
      },
      "f17" : {
          "connector": "#",
          "fe_type" : "connect", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_type",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration"],
          "tail" : "market"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f16": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f17": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("001");
  pb_info->set_use_duration(1000);
  pb_info->set_event_type("安装");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("002");
  pb_info->set_use_duration(2000);
  pb_info->set_event_type("卸载");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("003");
  pb_info->set_use_duration(3000);
  pb_info->set_event_type("安装");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("004");
  pb_info->set_use_duration(4000);
  pb_info->set_event_type("点击");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  char inv_char = 1;
  std::string invisible_char = std::string(1,inv_char);
  std::string str1;
  std::string str2;
  std::string str3;
  std::string str4;
  str1.append("001").append(invisible_char).append("1000").append(invisible_char).append("game");
  str2.append("002").append(invisible_char).append("2000").append(invisible_char).append("game");
  str3.append("003").append(invisible_char).append("3000").append(invisible_char).append("game");
  str4.append("004").append(invisible_char).append("4000").append(invisible_char).append("game");
  std::cout << "str1：" << str1 << ",str2:" << str2 << ",str3:" << str3 << ",str4:" << str4 << std::endl;
  TEST_FEATURE_LIST_STR(({{str1}, {str2}, {str3}, {str4}}), itr00->second);

  auto itr01 = map00.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  inv_char = 31;
  invisible_char = std::string(1,inv_char);
  std::string str11;
  std::string str12;
  std::string str13;
  std::string str14;
  str11.append("001").append(invisible_char).append("安装").append(invisible_char).append("market");
  str12.append("002").append(invisible_char).append("卸载").append(invisible_char).append("market");
  str13.append("003").append(invisible_char).append("安装").append(invisible_char).append("market");
  str14.append("004").append(invisible_char).append("点击").append(invisible_char).append("market");
   std::cout << "str11：" << str11 << ",str12:" << str12 << ",str13:" << str13 << ",str14:" << str14 << std::endl;
  TEST_FEATURE_LIST_STR(({{str11}, {str12}, {str13}, {str14}}), itr01->second);

  auto itr02 = map00.find("f17");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"001#安装#1000#market"}, {"002#卸载#2000#market"}, {"003#安装#3000#market"}, {"004#点击#4000#market"}}), itr02->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({str1, str2, str3, str4}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f16");
  auto itr_len1 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({str11, str12, str13, str14}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  FUNC_TEST_END();
}

void test_connect_all_to_string_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="connect_all_to_string" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" first_connector="_" second_connector="&" tail="tail" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectAllToStringConfig* conf = dynamic_cast<ConnectAllToStringConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("app01");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("app02");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("app03");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("app04");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"app01_app02_app03_app04&tail"}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({1, 1}), ({"app01_app02_app03_app04&tail"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}

void test_connect_all_to_string_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="connect_all_to_string" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_type,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration" first_connector="_" second_connector="&" tail="tail" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectAllToStringConfig* conf = dynamic_cast<ConnectAllToStringConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("app01");
  pb_info->set_use_duration(1000);
  pb_info->set_event_type("安装");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("app02");
  pb_info->set_use_duration(2000);
  pb_info->set_event_type("卸载");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("app03");
  pb_info->set_use_duration(3000);
  pb_info->set_event_type("安装");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("app04");
  pb_info->set_use_duration(4000);
  pb_info->set_event_type("点击");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"app01_app02_app03_app04&安装_卸载_安装_点击&1000_2000_3000_4000&tail"}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({1, 1}), ({"app01_app02_app03_app04&安装_卸载_安装_点击&1000_2000_3000_4000&tail"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}

void test_connect_all_to_string_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="connect_all_to_string" source=".item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.feature_lists.feature_list.float,.request_time" first_connector="_" second_connector="&" tail="tail" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectAllToStringConfig* conf = dynamic_cast<ConnectAllToStringConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time(1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid01");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid02");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid03");

  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["float"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(12.0);
  fate->mutable_float_list()->add_value(34.0);
  fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(56.0);
  fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(78.0);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid04");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid05");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"appid01_appid02_appid03&12.000000_34.000000_56.000000_78.000000&1000&tail"}), itr00->second);
  TEST_FEATURE_STR(({"appid04_appid05&1000&tail"}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), 
                         ({"appid01_appid02_appid03&12.000000_34.000000_56.000000_78.000000&1000&tail",
                           "appid04_appid05&1000&tail"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}

// 存在空字符串数据
void test_connect_all_to_string_4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="connect_all_to_string" source=".item_feature.item_feature_se.context.feature.app_id,.item_feature.item_feature_se.context.feature.empty_string,E@.item_feature.item_feature_se.feature_lists.feature_list.float,.request_time" first_connector="_" second_connector="&" tail="tail" />
        </features>
    </config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectAllToStringConfig* conf = dynamic_cast<ConnectAllToStringConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time(1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid01");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid02");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid03");

  (*(item->mutable_context()->mutable_feature()))["empty_string"].mutable_bytes_list()->add_value("");

  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["float"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(12.0);
  fate->mutable_float_list()->add_value(34.0);
  fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(56.0);
  fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(78.0);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"appid01_appid02_appid03&&12.000000_34.000000_56.000000_78.000000&1000&tail"}), itr00->second);

  FUNC_TEST_END();
}

void test_cross_hash_bits_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "cross_hash_bits", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.context.feature.num"],
          "clip_size" : 2
      },
      "f16" : {
          "fe_type" : "cross_hash_bits", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num",
              ".item_feature.item_feature_se.context.feature.num"],
          "clip_size" : 2
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f16": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  CrossHashBitsConfig* conf = dynamic_cast<CrossHashBitsConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_num(111);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666");
  pb_info->set_num(222);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_num(333);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(123);
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(456);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({2691775485725007818, 3829262424187394606}), itr00->second);
  TEST_FEATURE_INT64(({55067832212840154, 1206117589933513534}), itr10->second);

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({2499017310282721954, 4338371674481846514}), itr01->second);
  TEST_FEATURE_INT64(({519870455995345842, 1849930930865433058}), itr11->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({2691775485725007818, 3829262424187394606, 55067832212840154, 1206117589933513534}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f16_values");
  auto itr_indices1 = map.find("f16_indices");
  auto itr_dense_shape1 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({2499017310282721954, 4338371674481846514, 519870455995345842, 1849930930865433058}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_cross_hash_bits_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "cross_hash_bits", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.feature_lists.feature_list.appid"],
          "clip_size" : 5
      },
      "f16" : {
          "fe_type" : "cross_hash_bits", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num",
              ".item_feature.item_feature_se.feature_lists.feature_list.appid"],
          "clip_size" : 5
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f16": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  CrossHashBitsConfig* conf = dynamic_cast<CrossHashBitsConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_num(111);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666");
  pb_info->set_num(222);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_num(333);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("456");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_INT64(({{6146480532973042287}, {840296171985362863}, {4986594274901016459}, {2005802239876160075}, {2090086206363131265}}), itr00->second);

  auto itr01 = map0.find("f16");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_FEATURE_LIST_INT64(({{5961076990239592199}, {890591639461210823}, {5486311222528904535}, {1352963820282964119}, {4567660145637024191}}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({6146480532973042287, 840296171985362863, 4986594274901016459, 2005802239876160075, 2090086206363131265}), itr0->second);
  TEST_LIST_INT32(({5}), itr_len0->second);

  auto itr1 = map.find("f16");
  auto itr_len1 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({5961076990239592199, 890591639461210823, 5486311222528904535, 1352963820282964119, 4567660145637024191}), itr1->second);
  TEST_LIST_INT32(({5}), itr_len1->second);

  FUNC_TEST_END();
}

void test_cross_hash_bits_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "cross_hash_bits", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num",
              ".item_feature.item_feature_se.context.feature.num"],
          "clip_size" : 5
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  CrossHashBitsConfig* conf = dynamic_cast<CrossHashBitsConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_num(111);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666");
  pb_info->set_num(222);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_num(333);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(123);
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(456);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({4422935619238696218, 23651149676253626, 7410037692539553898, 3251091966073213182, 1165122718538208350}), itr00->second);
  TEST_FEATURE_INT64(({8525345273414162235, 5432878543123420059, 3306995475053169227, 7363176704625775327, 6564603559352473215}), itr10->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4}), ({2, 5}),
                            ({4422935619238696218, 23651149676253626, 7410037692539553898, 3251091966073213182, 1165122718538208350,
                              8525345273414162235, 5432878543123420059, 3306995475053169227, 7363176704625775327, 6564603559352473215}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_cross_hash_bits_4() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "cross_hash_bits", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num",
              ".item_feature.item_feature_se.feature_lists.feature_list.appid"],
          "clip_size" : 7
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  CrossHashBitsConfig* conf = dynamic_cast<CrossHashBitsConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_num(111);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666");
  pb_info->set_num(222);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("456");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_INT64(({{6723317219275955792}, {6955231573025494481}, {6952273014468336368}, {6751063347822236017},
                            {5562327120802962356}, {8141008581136388149}, {8071630380301934356}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({6723317219275955792, 6955231573025494481, 6952273014468336368, 6751063347822236017,
                    5562327120802962356, 8141008581136388149, 8071630380301934356}), itr0->second);
  TEST_LIST_INT32(({7}), itr_len0->second);

  FUNC_TEST_END();
}

void test_cross_hash_bits_v2_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_hash_bits_v2" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.context.feature.num" clip_size="2" />
            <feature name="f16" type="cross_hash_bits_v2" source=".item_feature.item_feature_se.context.feature.id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.context.feature.num" clip_size="2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
        <input name="f16" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  CrossHashBitsV2Config* conf = dynamic_cast<CrossHashBitsV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(123);
  (*(item->mutable_context()->mutable_feature()))["id"].mutable_bytes_list()->add_value("123");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(456);
  (*(item->mutable_context()->mutable_feature()))["id"].mutable_bytes_list()->add_value("456");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({2691775485725007818, 3829262424187394606}), itr00->second);
  TEST_FEATURE_INT64(({55067832212840154, 1206117589933513534}), itr10->second);

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({6633412928844399244, 9002732187733985604}), itr01->second);
  TEST_FEATURE_INT64(({8668603522544071245, 6391641590584932741}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({2691775485725007818, 3829262424187394606, 55067832212840154, 1206117589933513534}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f16_values");
  auto itr_indices1 = map.find("f16_indices");
  auto itr_dense_shape1 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({6633412928844399244, 9002732187733985604, 8668603522544071245, 6391641590584932741}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_cross_hash_bits_v2_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_hash_bits_v2" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" clip_size="4" />
            <feature name="f16" type="cross_hash_bits_v2" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.num,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" clip_size="2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,1,5" type="sequence" />
        <input name="f16" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  CrossHashBitsV2Config* conf = dynamic_cast<CrossHashBitsV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_num(111);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666");
  pb_info->set_num(222);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("456");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["num"];
  feat_list2.add_feature()->mutable_int64_list()->add_value(123);

  item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list3 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("789");

  auto& feat_list4 = (*(item->mutable_feature_lists()->mutable_feature_list()))["num"];
  feat_list4.add_feature()->mutable_int64_list()->add_value(123);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map1 = batch_ret.batch(1).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  auto itr10 = map1.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_FEATURE_LIST_INT64(({{3057389275540287158}, {5765965892392839158}, {8398083869497232246}, {1072183258297336374}}), itr00->second);
  TEST_FEATURE_LIST_INT64(({{3057389275540287158}, {5765965892392839158}, {7422239560827605878}, {2120003247388629558}}), itr10->second);

  auto itr01 = map0.find("f16");
  auto itr11 = map1.find("f16");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());
  TEST_FEATURE_LIST_INT64(({{6519439472812264211}, {2311304963552150099}}), itr01->second);
  TEST_FEATURE_LIST_INT64(({{6519439472812264211}, {2311304963552150099}}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({3057389275540287158, 5765965892392839158, 8398083869497232246, 1072183258297336374,
                    3057389275540287158, 5765965892392839158, 7422239560827605878, 2120003247388629558}), itr0->second);
  TEST_LIST_INT32(({4, 4}), itr_len0->second);

  auto itr1 = map.find("f16");
  auto itr_len1 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({6519439472812264211, 2311304963552150099, 6519439472812264211, 2311304963552150099}), itr1->second);
  TEST_LIST_INT32(({2, 2}), itr_len1->second);

  FUNC_TEST_END();
}

void test_get_valid_value_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "get_valid_value", 
          "source": [".request_time",
                      ".callback_req_ts"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  GetValidValueConfig* conf = dynamic_cast<GetValidValueConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // time
  request.set_request_time(100);
  request.set_callback_req_ts(20);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_INT64(({100}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({100}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  qinglong::FeRequest request2;
  qinglong::BatchSequenceExample batch_ret2;

  // time
  request2.set_request_time(-1);
  request2.set_callback_req_ts(20);

  // item不为空
  request2.add_item_feature();

  toSequenceExample(&arena, request2, vec, batch_ret2);

  TEST_ASSERT_EQUAL(1, batch_ret2.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(0).has_context());
  const auto& map01 = batch_ret2.batch(0).context().feature();

  auto itr01 = map01.find("f15");
  TEST_ASSERT_BOOL(itr01 != map01.end());
  TEST_FEATURE_INT64(({20}), itr01->second);

  qinglong::FeRequest request3;
  qinglong::BatchSequenceExample batch_ret3;

  // time
  request3.set_callback_req_ts(30);

  // item不为空
  request3.add_item_feature();
  request3.add_item_feature();

  toSequenceExample(&arena, request3, vec, batch_ret3);

  TEST_ASSERT_EQUAL(2, batch_ret3.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret3.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret3.batch(1).has_context());
  const auto& map02 = batch_ret3.batch(0).context().feature();
  const auto& map03 = batch_ret3.batch(1).context().feature();

  auto itr02 = map02.find("f15");
  TEST_ASSERT_BOOL(itr02 != map02.end());
  TEST_FEATURE_INT64(({30}), itr02->second);

  auto itr03 = map03.find("f15");
  TEST_ASSERT_BOOL(itr03 != map03.end());
  TEST_FEATURE_INT64(({30}), itr03->second);

  FUNC_TEST_END();
}

void test_get_valid_value_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "get_valid_value", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
                      ".user_feature.user_feature_se.feature_lists.feature_list.event_time"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  GetValidValueConfig* conf = dynamic_cast<GetValidValueConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(86400);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(-1);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(-100);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(800);

  tensorflow::SequenceExample* user_se = pb_ufv2->mutable_user_feature_se();
  auto& map01 = *user_se->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = map01["event_time"];
  tensorflow::Feature* feat = list.add_feature();
  feat->mutable_int64_list()->add_value(10);
  feat->mutable_int64_list()->add_value(20);

  feat = list.add_feature();
  feat->mutable_int64_list()->add_value(30);

  feat = list.add_feature();

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_INT64(({{86400}, {30}, {-1}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({86400, 0, 30, 0, -1, 0}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  FUNC_TEST_END();
}

void test_get_valid_value_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "get_valid_value", 
          "source": [".item_feature.game_item_offline_feature.game_item_statistic_feature.iclick_int_v1",
                      ".item_feature.item_feature_se.context.feature.num"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  GetValidValueConfig* conf = dynamic_cast<GetValidValueConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_iclick_int_v1(100);

  tensorflow::SequenceExample* item_se = item->mutable_item_feature_se();
  (*(item_se->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(10);
  (*(item_se->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(20);

  item = request.add_item_feature();
  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_iclick_int_v1(-1);

  item_se = item->mutable_item_feature_se();
  (*(item_se->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(30);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr01 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_FEATURE_INT64(({100}), itr00->second);
  TEST_FEATURE_INT64(({30}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({100, 30}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_get_valid_value_v2_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="get_valid_value_v2" source=".request_time,.callback_req_ts" invalid="-1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  GetValidValueV2Config* conf = dynamic_cast<GetValidValueV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // time
  request.set_request_time(100);
  request.set_callback_req_ts(20);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_INT64(({100}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({100}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  qinglong::FeRequest request2;
  qinglong::BatchSequenceExample batch_ret2;

  // time
  request2.set_request_time(-1);
  request2.set_callback_req_ts(20);

  // item不为空
  request2.add_item_feature();

  toSequenceExample(&arena, request2, vec, batch_ret2);

  TEST_ASSERT_EQUAL(1, batch_ret2.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(0).has_context());
  const auto& map01 = batch_ret2.batch(0).context().feature();

  auto itr01 = map01.find("f15");
  TEST_ASSERT_BOOL(itr01 != map01.end());
  TEST_FEATURE_INT64(({20}), itr01->second);

  qinglong::FeRequest request3;
  qinglong::BatchSequenceExample batch_ret3;

  // time
  request3.set_callback_req_ts(30);

  // item不为空
  request3.add_item_feature();
  request3.add_item_feature();

  toSequenceExample(&arena, request3, vec, batch_ret3);

  TEST_ASSERT_EQUAL(2, batch_ret3.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret3.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret3.batch(1).has_context());
  const auto& map02 = batch_ret3.batch(0).context().feature();
  const auto& map03 = batch_ret3.batch(1).context().feature();

  auto itr02 = map02.find("f15");
  TEST_ASSERT_BOOL(itr02 != map02.end());
  TEST_FEATURE_INT64(({0}), itr02->second);

  auto itr03 = map03.find("f15");
  TEST_ASSERT_BOOL(itr03 != map03.end());
  TEST_FEATURE_INT64(({0}), itr03->second);

  FUNC_TEST_END();
}

void test_get_valid_value_v2_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="get_valid_value_v2" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.user_feature.user_feature_se.feature_lists.feature_list.event_time" invalid="-1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,2,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  GetValidValueV2Config* conf = dynamic_cast<GetValidValueV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(86400);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(-1);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(-100);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(800);

  tensorflow::SequenceExample* user_se = pb_ufv2->mutable_user_feature_se();
  auto& map01 = *user_se->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = map01["event_time"];
  tensorflow::Feature* feat = list.add_feature();
  feat->mutable_int64_list()->add_value(10);
  feat->mutable_int64_list()->add_value(20);

  feat = list.add_feature();
  feat->mutable_int64_list()->add_value(30);

  feat = list.add_feature();

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_INT64(({{86400}, {30}, {-100}, {800}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({86400, 0, 30, 0, -100, 0, 800, 0}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  FUNC_TEST_END();
}

void test_get_valid_value_v2_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="get_valid_value_v2" source=".item_feature.game_item_offline_feature.game_item_statistic_feature.ictr_dou_v1,E@.item_feature.item_feature_se.context.feature.num" invalid="-1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  GetValidValueV2Config* conf = dynamic_cast<GetValidValueV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_ictr_dou_v1(100);

  tensorflow::SequenceExample* item_se = item->mutable_item_feature_se();
  (*(item_se->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(10);
  (*(item_se->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(20);

  item = request.add_item_feature();
  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_ictr_dou_v1(-1);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr01 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_FEATURE_FLOAT(({100}), itr00->second);
  TEST_FEATURE_FLOAT(({}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0}), ({2, 1}), ({100}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_act_value_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="act_value" source=".request_time,.request_time" activation_value="5" default_value="10" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  ActValueConfig* conf = dynamic_cast<ActValueConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // time
  request.set_request_time(100);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_INT64(({100}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({100}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  qinglong::FeRequest request2;
  qinglong::BatchSequenceExample batch_ret2;

  // time
  request2.set_request_time(-1);

  // item不为空
  request2.add_item_feature();

  toSequenceExample(&arena, request2, vec, batch_ret2);

  TEST_ASSERT_EQUAL(1, batch_ret2.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(0).has_context());
  const auto& map01 = batch_ret2.batch(0).context().feature();

  auto itr01 = map01.find("f15");
  TEST_ASSERT_BOOL(itr01 != map01.end());
  TEST_FEATURE_INT64(({10}), itr01->second);

  qinglong::FeRequest request3;
  qinglong::BatchSequenceExample batch_ret3;

  // time
  request3.set_request_time(5);

  // item不为空
  request3.add_item_feature();
  request3.add_item_feature();

  toSequenceExample(&arena, request3, vec, batch_ret3);

  TEST_ASSERT_EQUAL(2, batch_ret3.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret3.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret3.batch(1).has_context());
  const auto& map02 = batch_ret3.batch(0).context().feature();
  const auto& map03 = batch_ret3.batch(1).context().feature();

  auto itr02 = map02.find("f15");
  TEST_ASSERT_BOOL(itr02 != map02.end());
  TEST_FEATURE_INT64(({5}), itr02->second);

  auto itr03 = map03.find("f15");
  TEST_ASSERT_BOOL(itr03 != map03.end());
  TEST_FEATURE_INT64(({5}), itr03->second);

  FUNC_TEST_END();
}

void test_act_value_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="act_value" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.user_feature.user_feature_se.feature_lists.feature_list.event_time" activation_value="300" default_value="1200" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  ActValueConfig* conf = dynamic_cast<ActValueConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(86400);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(-1);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(-100);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time(800);

  tensorflow::SequenceExample* user_se = pb_ufv2->mutable_user_feature_se();
  auto& map01 = *user_se->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = map01["event_time"];
  tensorflow::Feature* feat = list.add_feature();
  feat->mutable_int64_list()->add_value(10);
  feat->mutable_int64_list()->add_value(20);

  feat = list.add_feature();
  feat->mutable_int64_list()->add_value(30);

  feat = list.add_feature();

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_INT64(({{10}, {1200}, {}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({10, 1200, 0}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  FUNC_TEST_END();
}

void test_act_value_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="act_value" source=".item_feature.game_item_offline_feature.game_item_statistic_feature.ictr_dou_v1,E@.item_feature.item_feature_se.context.feature.num" activation_value="10" default_value="10" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  ActValueConfig* conf = dynamic_cast<ActValueConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_ictr_dou_v1(100);

  tensorflow::SequenceExample* item_se = item->mutable_item_feature_se();
  (*(item_se->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(10);
  (*(item_se->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(20);

  item = request.add_item_feature();
  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_ictr_dou_v1(-1);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr01 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_FEATURE_FLOAT(({10}), itr00->second);
  TEST_FEATURE_FLOAT(({}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0}), ({2, 1}), ({10}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

//feature
void test_int64_offset_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "int64_offset", 
          "source": [".item_feature.item_feature_se.context.feature.num"], 
          "offset" : 5
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Int64OffsetConfig* conf = dynamic_cast<Int64OffsetConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);
  TEST_ASSERT_EQUAL(1, in_vec.size());

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(1);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(3);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(5);
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(7);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(-1);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({6, 8, 10}), itr00->second);
  TEST_FEATURE_INT64(({12, 4}), itr10->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}), ({6, 8, 10, 12, 4}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

//featurelist
void test_int64_offset_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "int64_offset", 
          "source": [".item_feature.item_feature_se.feature_lists.feature_list.list"], 
          "offset" : 5
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Int64OffsetConfig* conf = dynamic_cast<Int64OffsetConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);
  TEST_ASSERT_EQUAL(1, in_vec.size());

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["list"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value(1);
  fate->mutable_int64_list()->add_value(3);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value(5);
  fate->mutable_int64_list()->add_value(7);
  fate->mutable_int64_list()->add_value(-1);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_INT64(({{6, 8}, {10, 12, 4}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({6, 8, 10, 12}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  FUNC_TEST_END();
}

//featurelist
void test_int64_difference_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "int64_difference", 
          "source": [
              ".request_time",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Int64DifferenceConfig* conf = dynamic_cast<Int64DifferenceConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)10 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)5 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)8 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)7 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)6 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)5 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{432000000}, {172800000}, {259200000}, {345600000}, {432000000}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f6");
  auto itr_len0 = map.find("f6_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({432000000, 172800000, 259200000, 345600000, 432000000}), itr0->second);
  TEST_LIST_INT32(({5}), itr_len0->second);

  FUNC_TEST_END();
}

//feature
void test_int64_difference_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "int64_difference", 
          "source": [
              ".request_time",
              ".item_feature.item_feature_se.context.feature.time"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  Int64DifferenceConfig* conf = dynamic_cast<Int64DifferenceConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)15 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)11 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)10 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)7 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_INT64(({864000000, 345600000, 518400000, 518400000, 432000000, 691200000}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5}), ({1, 6}), ({864000000, 345600000, 518400000, 518400000, 432000000, 691200000}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_vocab_set_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13": {
          "fe_type" : "vocab_set", 
          "source": [
              ".user_action.item_id.app_id"
          ], 
          "dict" : ["app0", "app1", "app2", "app3", "app4", "app5", "app6"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  VocabSetConfig* config = dynamic_cast<VocabSetConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // user_action
  qinglong::UserAction* user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app0");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app5");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app2");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app9");

  //item不为0
  request.add_item_feature();

  qinglong::BatchSequenceExample ba_ret;
  toSequenceExample(&arena, request, vec, ba_ret);

  TEST_ASSERT_EQUAL(1, ba_ret.batch_size());
  TEST_ASSERT_EQUAL(true, ba_ret.batch(0).has_feature_lists());

  const auto& map0 = ba_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f13");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_STR(({{"app0"}, {"app5"}, {"app2"}, {""}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"app0", "app5", "app2", ""}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);
  
  FUNC_TEST_END();
}

void test_vocab_set_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f15": {
          "fe_type" : "vocab_set", 
          "source": [
              ".item_feature.item_feature_se.context.feature.app_id"
          ], 
          "dict" : ["app0", "app1", "app2", "app3", "app4", "app5"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  VocabSetConfig* config = dynamic_cast<VocabSetConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app3");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app5");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app1_1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app9");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"app3", "app5"}), itr00->second);
  TEST_FEATURE_STR(({"", ""}), itr10->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({"app3", "app5", "", ""}),
                         itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

// 读文件
void test_vocab_set_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="vocab_set" source=".item_feature.item_feature_se.context.feature.app_id" dict="test/data/query_appname.txt" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  VocabSetConfig* config = dynamic_cast<VocabSetConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("1号店_1号会员店");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("3a云游戏_3a云游");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app1_1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app9");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"1号店_1号会员店", "3a云游戏_3a云游"}), itr00->second);
  TEST_FEATURE_STR(({"", ""}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({"1号店_1号会员店", "3a云游戏_3a云游", "", ""}),
                         itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_vocab_map_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="vocab_map" source=".user_action.item_id.app_id" dtype="int64" dict="app0:0,app1:1,app2:2,app3:3,app4:4,app5:5,app6:6" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  VocabMapConfig<int64_t>* config = dynamic_cast<VocabMapConfig<int64_t>*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // user_action
  qinglong::UserAction* user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app0");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app5");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app2");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app9");

  //item不为0
  request.add_item_feature();

  qinglong::BatchSequenceExample ba_ret;
  toSequenceExample(&arena, request, vec, ba_ret);

  TEST_ASSERT_EQUAL(1, ba_ret.batch_size());
  TEST_ASSERT_EQUAL(true, ba_ret.batch(0).has_feature_lists());

  const auto& map0 = ba_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_INT64(({{0}, {5}, {2}, {-1}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({0, 5, 2, -1}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);
  
  FUNC_TEST_END();
}

void test_vocab_map_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="vocab_map" source=".item_feature.item_feature_se.context.feature.app_id" dtype="float" dict="app0:0.0,app1:1.0,app2:2.0,app3:3.0,app4:4.0,app5:5.0,app6:6.0" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  VocabMapConfig<float>* config = dynamic_cast<VocabMapConfig<float>*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app3");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app5");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app1_1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app9");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_FLOAT(({3.0, 5.0}), itr00->second);
  TEST_FEATURE_FLOAT(({-1.0, -1.0}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({3.0, 5.0, -1.0, -1.0}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_vocab_map_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="vocab_map" source=".item_feature.item_feature_se.context.feature.app_id" dtype="string" dict="app0:0,app1:1,app2:2,app3:3,app4:4,app5:5,app6:6" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  VocabMapConfig<std::string>* config = dynamic_cast<VocabMapConfig<std::string>*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app3");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app5");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app1_1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app9");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"3", "5"}), itr00->second);
  TEST_FEATURE_STR(({"", ""}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({"3", "5", "", ""}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

// 读文件
void test_vocab_map_4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="vocab_map" source=".item_feature.item_feature_se.context.feature.app_id" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  VocabMapConfig<int64_t>* config = dynamic_cast<VocabMapConfig<int64_t>*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("导航_高德地图");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("魔塔_魔塔经典");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app1_1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app9");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({2, 4}), itr00->second);
  TEST_FEATURE_INT64(({-1, -1}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({2, 4, -1, -1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

// featurelist
void test_segment_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="segment" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,3,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SegmentConfig* conf = dynamic_cast<SegmentConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("他来到了网易杭研大厦");
  pb_use->add_user_sequence()->set_app_id("我来自北京邮电大学。");
  pb_use->add_user_sequence()->set_app_id("我来自北京邮电大学。。。学号123456，用AK47");

  //item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map0.find("f15");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_STR(({{"他", "来到", "了", "网易", "杭研", "大厦"}, {"我", "来自", "北京邮电大学", "。"},
                          {"我", "来自", "北京邮电大学", "。", "。", "。", "学号", "123456", "，", "用", "AK47"}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map1 = ret.inputs();
  auto itr0 = map1.find("f15");
  auto itr_len0 = map1.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map1.end());
  TEST_ASSERT_BOOL(itr_len0 != map1.end());
  TEST_LIST_STRING(({"他", "来到", "了","我", "来自", "北京邮电大学", "我", "来自", "北京邮电大学"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  FUNC_TEST_END();
}

//feature
void test_segment_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="segment" source=".item_feature.item_feature_se.context.feature.app_id" jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SegmentConfig* conf = dynamic_cast<SegmentConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("令狐冲是云计算行业的专家");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("我是拖拉机学院手扶拖拉机专业的");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("小明硕士毕业于中国科学院计算所");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("后在日本京都大学深造");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"令狐冲", "是", "云计算", "行业", "的", "专家", "我", "是", "拖拉机", "学院", "手扶拖拉机", "专业", "的"}), itr00->second);
  TEST_FEATURE_STR(({"小明", "硕士", "毕业", "于", "中国科学院", "计算所", "后", "在", "日本京都大学", "深造"}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 8, 0, 9, 0, 10, 0, 11, 0, 12,
                           1, 0, 1, 1, 1, 2, 1, 3, 1, 4, 1, 5, 1, 6, 1, 7, 1, 8, 1, 9}), ({2, 13}), 
                         ({"令狐冲", "是", "云计算", "行业", "的", "专家", "我", "是", "拖拉机", "学院", "手扶拖拉机", "专业", "的",
                           "小明", "硕士", "毕业", "于", "中国科学院", "计算所", "后", "在", "日本京都大学", "深造"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

// app_id、\002连接符、有默认值、不允许为空
void test_dict_to_attributes_v2_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes_v2" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" dict_type="app_id" connector="\002" default_value="test_no_data" />
            <feature name="f11" type="direct" source="f10:0" />
            <feature name="f12" type="direct" source="f10:1" />
            <feature name="f13" type="direct" source="f10:2" />
            <feature name="f14" type="direct" source="f10:3" />
            <feature name="f15" type="direct" source="f10:4" />
            <feature name="f16" type="direct" source="f10:5" />
            <feature name="f17" type="direct" source="f10:6" />
            <feature name="f18" type="direct" source="f10:7" />
            <feature name="f19" type="direct" source="f10:8" />
            <feature name="f20" type="direct" source="f10:9" />
            <feature name="f21" type="direct" source="f10:10" />
            <feature name="f22" type="direct" source="f10:11" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini_extra</app_info>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f11" shape="1,1,5" type="sequence" />
        <input name="f12" shape="1,1,5" type="sequence" />
        <input name="f13" shape="1,1,5" type="sequence" />
        <input name="f14" shape="1,1,5" type="sequence" />
        <input name="f15" shape="1,1,5" type="sequence" />
        <input name="f16" shape="1,1,5" type="sequence" />
        <input name="f17" shape="1,1,5" type="sequence" />
        <input name="f18" shape="1,1,5" type="sequence" />
        <input name="f19" shape="1,1,5" type="sequence" />
        <input name="f20" shape="1,1,5" type="sequence" />
        <input name="f21" shape="1,1,5" type="sequence" />
        <input name="f22" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(13, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesV2Config* conf = dynamic_cast<DictToAttributesV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900804778");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("927940154");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900770955");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"900804778"}, {"927940154"}, {"900770955"}}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"com.dada.contact"}, {"uni.UNIEEAB47A"}, {"com.bj12345.goldqnet"}}), itr02->second);

  auto itr03 = map00.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_STR(({{"通讯录同步助手"}, {"太享生活"}, {"金培网"}}), itr03->second);

  auto itr04 = map00.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_LIST_STR(({{"应用"}, {"应用"}, {"应用"}}), itr04->second);

  auto itr05 = map00.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_LIST_STR(({{"系统工具"}, {"购物比价"}, {"教育"}}), itr05->second);

  auto itr06 = map00.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_FEATURE_LIST_STR(({{"安全优化"}, {"商城"}, {"学习"}}), itr06->second);

  auto itr07 = map00.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_FEATURE_LIST_STR(({{"实用工具工具"}, {"默认值"}, {"教育学习"}}), itr07->second);

  auto itr08 = map00.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_FEATURE_LIST_STR(({{"武汉哒哒软件科技有限公司"}, {"默认值"}, {"山东金培教育科技有限公司"}}), itr08->second);

  auto itr09 = map00.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_FEATURE_LIST_STR(({{"109999831236"}, {"默认值"}, {"106632998718"}}), itr09->second);

  auto itr010 = map00.find("f20");
  TEST_ASSERT_BOOL(itr010 != map00.end());
  TEST_FEATURE_LIST_STR(({{"扩展1"}, {"扩展2"}, {"test_no_data"}}), itr010->second);

  auto itr011 = map00.find("f21");
  TEST_ASSERT_BOOL(itr011 != map00.end());
  TEST_FEATURE_LIST_STR(({{"默认值"}, {"默认值"}, {"test_no_data"}}), itr011->second);

  auto itr012 = map00.find("f22");
  TEST_ASSERT_BOOL(itr012 != map00.end());
  TEST_FEATURE_LIST_STR(({{"123"}, {"test_no_data"}, {"test_no_data"}}), itr012->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr1 = map.find("f11");
  auto itr_len1 = map.find("f11_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"900804778", "927940154", "900770955"}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  auto itr2 = map.find("f12");
  auto itr_len2 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"com.dada.contact", "uni.UNIEEAB47A", "com.bj12345.goldqnet"}), itr2->second);
  TEST_LIST_INT32(({3}), itr_len2->second);

  auto itr3 = map.find("f13");
  auto itr_len3 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_STRING(({"通讯录同步助手", "太享生活", "金培网"}), itr3->second);
  TEST_LIST_INT32(({3}), itr_len3->second);

  auto itr4 = map.find("f14");
  auto itr_len4 = map.find("f14_length");
  TEST_ASSERT_BOOL(itr4 != map.end());
  TEST_ASSERT_BOOL(itr_len4 != map.end());
  TEST_LIST_STRING(({"应用", "应用", "应用"}), itr4->second);
  TEST_LIST_INT32(({3}), itr_len4->second);

  auto itr5 = map.find("f15");
  auto itr_len5 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr5 != map.end());
  TEST_ASSERT_BOOL(itr_len5 != map.end());
  TEST_LIST_STRING(({"系统工具", "购物比价", "教育"}), itr5->second);
  TEST_LIST_INT32(({3}), itr_len5->second);

  auto itr6 = map.find("f16");
  auto itr_len6 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr6 != map.end());
  TEST_ASSERT_BOOL(itr_len6 != map.end());
  TEST_LIST_STRING(({"安全优化", "商城", "学习"}), itr6->second);
  TEST_LIST_INT32(({3}), itr_len6->second);

  auto itr7 = map.find("f17");
  auto itr_len7 = map.find("f17_length");
  TEST_ASSERT_BOOL(itr7 != map.end());
  TEST_ASSERT_BOOL(itr_len7 != map.end());
  TEST_LIST_STRING(({"实用工具工具", "默认值", "教育学习"}), itr7->second);
  TEST_LIST_INT32(({3}), itr_len7->second);

  auto itr8 = map.find("f18");
  auto itr_len8 = map.find("f18_length");
  TEST_ASSERT_BOOL(itr8 != map.end());
  TEST_ASSERT_BOOL(itr_len8 != map.end());
  TEST_LIST_STRING(({"武汉哒哒软件科技有限公司", "默认值", "山东金培教育科技有限公司"}), itr8->second);
  TEST_LIST_INT32(({3}), itr_len8->second);

  auto itr9 = map.find("f19");
  auto itr_len9 = map.find("f19_length");
  TEST_ASSERT_BOOL(itr9 != map.end());
  TEST_ASSERT_BOOL(itr_len9 != map.end());
  TEST_LIST_STRING(({"109999831236", "默认值", "106632998718"}), itr9->second);
  TEST_LIST_INT32(({3}), itr_len9->second);

  auto itr10 = map.find("f20");
  auto itr_len10 = map.find("f20_length");
  TEST_ASSERT_BOOL(itr10 != map.end());
  TEST_ASSERT_BOOL(itr_len10 != map.end());
  TEST_LIST_STRING(({"扩展1", "扩展2", "test_no_data"}), itr10->second);
  TEST_LIST_INT32(({3}), itr_len10->second);

  auto itr11 = map.find("f21");
  auto itr_len11 = map.find("f21_length");
  TEST_ASSERT_BOOL(itr11 != map.end());
  TEST_ASSERT_BOOL(itr_len11 != map.end());
  TEST_LIST_STRING(({"默认值", "默认值", "test_no_data"}), itr11->second);
  TEST_LIST_INT32(({3}), itr_len11->second);

  auto itr12 = map.find("f22");
  auto itr_len12 = map.find("f22_length");
  TEST_ASSERT_BOOL(itr12 != map.end());
  TEST_ASSERT_BOOL(itr_len12 != map.end());
  TEST_LIST_STRING(({"123", "test_no_data", "test_no_data"}), itr12->second);
  TEST_LIST_INT32(({3}), itr_len12->second);

  FUNC_TEST_END();
}

// package_name、逗号连接符、有默认值
void test_dict_to_attributes_v2_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes_v2" source=".item_feature.item_feature_se.context.feature.package_name" dict_type="package_name" connector="," default_value="test_no_data" />
            <feature name="f11" type="direct" source="f10:0" />
            <feature name="f12" type="direct" source="f10:1" />
            <feature name="f13" type="direct" source="f10:2" />
            <feature name="f14" type="direct" source="f10:3" />
            <feature name="f15" type="direct" source="f10:4" />
            <feature name="f16" type="direct" source="f10:5" />
            <feature name="f17" type="direct" source="f10:6" />
            <feature name="f18" type="direct" source="f10:7" />
            <feature name="f19" type="direct" source="f10:8" />
            <feature name="f20" type="direct" source="f10:9" />
            <feature name="f21" type="direct" source="f10:10" />
            <feature name="f22" type="direct" source="f10:11" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini_extra</app_info>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f11" shape="1" type="sparse" />
        <input name="f12" shape="1" type="sparse" />
        <input name="f13" shape="1" type="sparse" />
        <input name="f14" shape="1" type="sparse" />
        <input name="f15" shape="1" type="sparse" />
        <input name="f16" shape="1" type="sparse" />
        <input name="f17" shape="1" type="sparse" />
        <input name="f18" shape="1" type="sparse" />
        <input name="f19" shape="1" type="sparse" />
        <input name="f20" shape="1" type="sparse" />
        <input name="f21" shape="1" type="sparse" />
        <input name="f22" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(13, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesV2Config* conf = dynamic_cast<DictToAttributesV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.network.xf18142");
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.tzyz.meng.honor");
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.PeacockStudio.KongfuPunchLite");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("111");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr001 = map00.find("f11");
  auto itr101 = map01.find("f11");
  TEST_ASSERT_BOOL(itr001 != map00.end());
  TEST_ASSERT_BOOL(itr101 != map01.end());

  TEST_FEATURE_STR(({"925089172", "104422431", "922331498"}), itr001->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr101->second);

  auto itr002 = map00.find("f12");
  auto itr102 = map01.find("f12");
  TEST_ASSERT_BOOL(itr002 != map00.end());
  TEST_ASSERT_BOOL(itr102 != map01.end());

  TEST_FEATURE_STR(({"com.network.xf18142", "com.tzyz.meng.honor", "com.PeacockStudio.KongfuPunchLite"}), itr002->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr102->second);

  auto itr003 = map00.find("f13");
  auto itr103 = map01.find("f13");
  TEST_ASSERT_BOOL(itr003 != map00.end());
  TEST_ASSERT_BOOL(itr103 != map01.end());

  TEST_FEATURE_STR(({"旋风加速器", "无尽梦回", "功夫之拳2"}), itr003->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr103->second);

  auto itr004 = map00.find("f14");
  auto itr104 = map01.find("f14");
  TEST_ASSERT_BOOL(itr004 != map00.end());
  TEST_ASSERT_BOOL(itr104 != map01.end());

  TEST_FEATURE_STR(({"应用", "游戏", "游戏"}), itr004->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr104->second);

  auto itr005 = map00.find("f15");
  auto itr105 = map01.find("f15");
  TEST_ASSERT_BOOL(itr005 != map00.end());
  TEST_ASSERT_BOOL(itr105 != map01.end());

  TEST_FEATURE_STR(({"生活", "角色扮演", "动作射击"}), itr005->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr105->second);

  auto itr006 = map00.find("f16");
  auto itr106 = map01.find("f16");
  TEST_ASSERT_BOOL(itr006 != map00.end());
  TEST_ASSERT_BOOL(itr106 != map01.end());

  TEST_FEATURE_STR(({"生活-其他", "角色扮演-其他", "格斗"}), itr006->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr106->second);

  auto itr007 = map00.find("f17");
  auto itr107 = map01.find("f17");
  TEST_ASSERT_BOOL(itr007 != map00.end());
  TEST_ASSERT_BOOL(itr107 != map01.end());

  TEST_FEATURE_STR(({"默认值", "默认值", "经典,破解,格斗,李小龙"}), itr007->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr107->second);

  auto itr008 = map00.find("f18");
  auto itr108 = map01.find("f18");
  TEST_ASSERT_BOOL(itr008 != map00.end());
  TEST_ASSERT_BOOL(itr108 != map01.end());

  TEST_FEATURE_STR(({"默认值", "杭州弹指宇宙科技有限公司", "默认值"}), itr008->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr108->second);

  auto itr009 = map00.find("f19");
  auto itr109 = map01.find("f19");
  TEST_ASSERT_BOOL(itr009 != map00.end());
  TEST_ASSERT_BOOL(itr109 != map01.end());

  TEST_FEATURE_STR(({"默认值", "109999814778", "默认值"}), itr009->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr109->second);

  auto itr010 = map00.find("f20");
  auto itr110 = map01.find("f20");
  TEST_ASSERT_BOOL(itr010 != map00.end());
  TEST_ASSERT_BOOL(itr110 != map01.end());

  TEST_FEATURE_STR(({"test1", "默认值", "test3"}), itr010->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr110->second);

  auto itr011 = map00.find("f21");
  auto itr111 = map01.find("f21");
  TEST_ASSERT_BOOL(itr011 != map00.end());
  TEST_ASSERT_BOOL(itr111 != map01.end());

  TEST_FEATURE_STR(({"a,b,c", "test_no_data", "默认值"}), itr011->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr111->second);

  auto itr012 = map00.find("f22");
  auto itr112 = map01.find("f22");
  TEST_ASSERT_BOOL(itr012 != map00.end());
  TEST_ASSERT_BOOL(itr112 != map01.end());

  TEST_FEATURE_STR(({"test_no_data", "test_no_data", "扩展3"}), itr012->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr112->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values1 = map.find("f11_values");
  auto itr_indices1 = map.find("f11_indices");
  auto itr_dense_shape1 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"925089172", "104422431", "922331498", "test_no_data"}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f12_values");
  auto itr_indices2 = map.find("f12_indices");
  auto itr_dense_shape2 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"com.network.xf18142", "com.tzyz.meng.honor", "com.PeacockStudio.KongfuPunchLite", "test_no_data"}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f13_values");
  auto itr_indices3 = map.find("f13_indices");
  auto itr_dense_shape3 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"旋风加速器", "无尽梦回", "功夫之拳2", "test_no_data"}),
                        itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  auto itr_values4 = map.find("f14_values");
  auto itr_indices4 = map.find("f14_indices");
  auto itr_dense_shape4 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values4 != map.end());
  TEST_ASSERT_BOOL(itr_indices4 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape4 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"应用", "游戏", "游戏", "test_no_data"}),
                        itr_indices4->second, itr_dense_shape4->second, itr_values4->second);

  auto itr_values5 = map.find("f15_values");
  auto itr_indices5 = map.find("f15_indices");
  auto itr_dense_shape5 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values5 != map.end());
  TEST_ASSERT_BOOL(itr_indices5 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape5 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"生活", "角色扮演", "动作射击", "test_no_data"}),
                        itr_indices5->second, itr_dense_shape5->second, itr_values5->second);

  auto itr_values6 = map.find("f16_values");
  auto itr_indices6 = map.find("f16_indices");
  auto itr_dense_shape6 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values6 != map.end());
  TEST_ASSERT_BOOL(itr_indices6 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape6 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"生活-其他", "角色扮演-其他", "格斗", "test_no_data"}),
                        itr_indices6->second, itr_dense_shape6->second, itr_values6->second);

  auto itr_values7 = map.find("f17_values");
  auto itr_indices7 = map.find("f17_indices");
  auto itr_dense_shape7 = map.find("f17_dense_shape");
  TEST_ASSERT_BOOL(itr_values7 != map.end());
  TEST_ASSERT_BOOL(itr_indices7 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape7 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"默认值", "默认值", "经典,破解,格斗,李小龙", "test_no_data"}),
                        itr_indices7->second, itr_dense_shape7->second, itr_values7->second);

  auto itr_values8 = map.find("f18_values");
  auto itr_indices8 = map.find("f18_indices");
  auto itr_dense_shape8 = map.find("f18_dense_shape");
  TEST_ASSERT_BOOL(itr_values8 != map.end());
  TEST_ASSERT_BOOL(itr_indices8 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape8 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"默认值", "杭州弹指宇宙科技有限公司", "默认值", "test_no_data"}),
                        itr_indices8->second, itr_dense_shape8->second, itr_values8->second);

  auto itr_values9 = map.find("f19_values");
  auto itr_indices9 = map.find("f19_indices");
  auto itr_dense_shape9 = map.find("f19_dense_shape");
  TEST_ASSERT_BOOL(itr_values9 != map.end());
  TEST_ASSERT_BOOL(itr_indices9 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape9 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"默认值", "109999814778", "默认值", "test_no_data"}),
                        itr_indices9->second, itr_dense_shape9->second, itr_values9->second);

  
  auto itr_values10 = map.find("f20_values");
  auto itr_indices10 = map.find("f20_indices");
  auto itr_dense_shape10 = map.find("f20_dense_shape");
  TEST_ASSERT_BOOL(itr_values10 != map.end());
  TEST_ASSERT_BOOL(itr_indices10 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape10 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"test1", "默认值", "test3", "test_no_data"}),
                        itr_indices10->second, itr_dense_shape10->second, itr_values10->second);

  auto itr_values11 = map.find("f21_values");
  auto itr_indices11 = map.find("f21_indices");
  auto itr_dense_shape11 = map.find("f21_dense_shape");
  TEST_ASSERT_BOOL(itr_values11 != map.end());
  TEST_ASSERT_BOOL(itr_indices11 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape11 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"a,b,c", "test_no_data", "默认值", "test_no_data"}),
                        itr_indices11->second, itr_dense_shape11->second, itr_values11->second);

  auto itr_values12 = map.find("f22_values");
  auto itr_indices12 = map.find("f22_indices");
  auto itr_dense_shape12 = map.find("f22_dense_shape");
  TEST_ASSERT_BOOL(itr_values12 != map.end());
  TEST_ASSERT_BOOL(itr_indices12 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape12 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"test_no_data", "test_no_data", "扩展3", "test_no_data"}),
                        itr_indices12->second, itr_dense_shape12->second, itr_values12->second);
  FUNC_TEST_END();
}

// 查询不到对应的信息时，并且未配置默认值，返回空
void test_dict_to_attributes_v2_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes_v2" source=".item_feature.item_feature_se.context.feature.package_name" dict_type="package_name" connector="," strategy="empty" />
            <feature name="f11" type="direct" source="f10:0" strategy="empty" />
            <feature name="f12" type="direct" source="f10:1" strategy="empty" />
            <feature name="f13" type="direct" source="f10:2" strategy="empty" />
            <feature name="f14" type="direct" source="f10:3" strategy="empty" />
            <feature name="f15" type="direct" source="f10:4" strategy="empty" />
            <feature name="f16" type="direct" source="f10:5" strategy="empty" />
            <feature name="f17" type="direct" source="f10:6" strategy="empty" />
            <feature name="f18" type="direct" source="f10:7" strategy="empty" />
            <feature name="f19" type="direct" source="f10:8" strategy="empty" />
            <feature name="f20" type="direct" source="f10:9" strategy="empty" />
            <feature name="f21" type="direct" source="f10:10" strategy="empty" />
            <feature name="f22" type="direct" source="f10:11" strategy="empty" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini_extra</app_info>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(13, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesV2Config* conf = dynamic_cast<DictToAttributesV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("111");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_STR(({}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_STR(({}), itr02->second);

  auto itr03 = map00.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_STR(({}), itr03->second);

  auto itr04 = map00.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_STR(({}), itr04->second);

  auto itr05 = map00.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_STR(({}), itr05->second);

  auto itr06 = map00.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_FEATURE_STR(({}), itr06->second);

  auto itr07 = map00.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_FEATURE_STR(({}), itr07->second);

  auto itr08 = map00.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_FEATURE_STR(({}), itr08->second);

  auto itr09 = map00.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_FEATURE_STR(({}), itr09->second);

  auto itr10 = map00.find("f20");
  TEST_ASSERT_BOOL(itr10 != map00.end());
  TEST_FEATURE_STR(({}), itr10->second);

  auto itr11 = map00.find("f21");
  TEST_ASSERT_BOOL(itr11 != map00.end());
  TEST_FEATURE_STR(({}), itr11->second);

  auto itr12 = map00.find("f22");
  TEST_ASSERT_BOOL(itr12 != map00.end());
  TEST_FEATURE_STR(({}), itr12->second);

  FUNC_TEST_END();
}

// 无连接符不拼接，按多值输出
void test_dict_to_attributes_v2_4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes_v2" source=".item_feature.item_feature_se.context.feature.package_name" dict_type="package_name" strategy="empty" />
            <feature name="f11" type="direct" source="f10:0" strategy="empty" />
            <feature name="f12" type="direct" source="f10:1" strategy="empty" />
            <feature name="f13" type="direct" source="f10:2" strategy="empty" />
            <feature name="f14" type="direct" source="f10:3" strategy="empty" />
            <feature name="f15" type="direct" source="f10:4" strategy="empty" />
            <feature name="f16" type="direct" source="f10:5" strategy="empty" />
            <feature name="f17" type="direct" source="f10:6" strategy="empty" />
            <feature name="f18" type="direct" source="f10:7" strategy="empty" />
            <feature name="f19" type="direct" source="f10:8" strategy="empty" />
            <feature name="f20" type="direct" source="f10:9" strategy="empty" />
            <feature name="f21" type="direct" source="f10:10" strategy="empty" />
            <feature name="f22" type="direct" source="f10:11" strategy="empty" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini_extra</app_info>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(13, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesV2Config* conf = dynamic_cast<DictToAttributesV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.network.xf18142");
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.tzyz.meng.honor");
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.PeacockStudio.KongfuPunchLite");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_STR(({"925089172", "104422431", "922331498"}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_STR(({"com.network.xf18142", "com.tzyz.meng.honor", "com.PeacockStudio.KongfuPunchLite"}), itr02->second);

  auto itr03 = map00.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_STR(({"旋风加速器", "无尽梦回", "功夫之拳2"}), itr03->second);

  auto itr04 = map00.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_STR(({"应用", "游戏", "游戏"}), itr04->second);

  auto itr05 = map00.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_STR(({"生活", "角色扮演", "动作射击"}), itr05->second);

  auto itr06 = map00.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_FEATURE_STR(({"生活-其他", "角色扮演-其他", "格斗"}), itr06->second);

  auto itr07 = map00.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_FEATURE_STR(({"默认值", "默认值", "经典", "破解", "格斗", "李小龙"}), itr07->second);

  auto itr08 = map00.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_FEATURE_STR(({"默认值", "杭州弹指宇宙科技有限公司", "默认值"}), itr08->second);

  auto itr09 = map00.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_FEATURE_STR(({"默认值", "109999814778", "默认值"}), itr09->second);

  auto itr10 = map00.find("f20");
  TEST_ASSERT_BOOL(itr10 != map00.end());
  TEST_FEATURE_STR(({"test1", "默认值", "test3"}), itr10->second);

  auto itr11 = map00.find("f21");
  TEST_ASSERT_BOOL(itr11 != map00.end());
  TEST_FEATURE_STR(({"a", "b", "c", "默认值"}), itr11->second);

  auto itr12 = map00.find("f22");
  TEST_ASSERT_BOOL(itr12 != map00.end());
  TEST_FEATURE_STR(({"扩展3"}), itr12->second);

  FUNC_TEST_END();
}

void test_dict_to_attributes_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" dict_type="app_id" connector="\002" default_value="test_no_data" />
            <feature name="f11" type="direct" source="f10:0" />
            <feature name="f12" type="direct" source="f10:1" />
            <feature name="f13" type="direct" source="f10:2" />
            <feature name="f14" type="direct" source="f10:3" />
            <feature name="f15" type="direct" source="f10:4" />
            <feature name="f16" type="direct" source="f10:5" />
            <feature name="f17" type="direct" source="f10:6" />
            <feature name="f18" type="direct" source="f10:7" />
            <feature name="f19" type="direct" source="f10:8" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini</app_info>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f11" shape="1,1,5" type="sequence" />
        <input name="f12" shape="1,1,5" type="sequence" />
        <input name="f13" shape="1,1,5" type="sequence" />
        <input name="f14" shape="1,1,5" type="sequence" />
        <input name="f15" shape="1,1,5" type="sequence" />
        <input name="f16" shape="1,1,5" type="sequence" />
        <input name="f17" shape="1,1,5" type="sequence" />
        <input name="f18" shape="1,1,5" type="sequence" />
        <input name="f19" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(10, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesConfig* conf = dynamic_cast<DictToAttributesConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900804778");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("927940154");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900770955");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"900804778"}, {"927940154"}, {"900770955"}}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"com.dada.contact"}, {"uni.UNIEEAB47A"}, {"com.bj12345.goldqnet"}}), itr02->second);

  auto itr03 = map00.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_STR(({{"通讯录同步助手"}, {"太享生活"}, {"金培网"}}), itr03->second);

  auto itr04 = map00.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_LIST_STR(({{"应用"}, {"应用"}, {"应用"}}), itr04->second);

  auto itr05 = map00.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_LIST_STR(({{"系统工具"}, {"购物比价"}, {"教育"}}), itr05->second);

  auto itr06 = map00.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_FEATURE_LIST_STR(({{"安全优化"}, {"商城"}, {"学习"}}), itr06->second);

  auto itr07 = map00.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_FEATURE_LIST_STR(({{"实用工具工具"}, {"默认值"}, {"教育学习"}}), itr07->second);

  auto itr08 = map00.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_FEATURE_LIST_STR(({{"武汉哒哒软件科技有限公司"}, {"默认值"}, {"山东金培教育科技有限公司"}}), itr08->second);

  auto itr09 = map00.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_FEATURE_LIST_STR(({{"109999831236"}, {"默认值"}, {"106632998718"}}), itr09->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr1 = map.find("f11");
  auto itr_len1 = map.find("f11_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"900804778", "927940154", "900770955"}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  auto itr2 = map.find("f12");
  auto itr_len2 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"com.dada.contact", "uni.UNIEEAB47A", "com.bj12345.goldqnet"}), itr2->second);
  TEST_LIST_INT32(({3}), itr_len2->second);

  auto itr3 = map.find("f13");
  auto itr_len3 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_STRING(({"通讯录同步助手", "太享生活", "金培网"}), itr3->second);
  TEST_LIST_INT32(({3}), itr_len3->second);

  auto itr4 = map.find("f14");
  auto itr_len4 = map.find("f14_length");
  TEST_ASSERT_BOOL(itr4 != map.end());
  TEST_ASSERT_BOOL(itr_len4 != map.end());
  TEST_LIST_STRING(({"应用", "应用", "应用"}), itr4->second);
  TEST_LIST_INT32(({3}), itr_len4->second);

  auto itr5 = map.find("f15");
  auto itr_len5 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr5 != map.end());
  TEST_ASSERT_BOOL(itr_len5 != map.end());
  TEST_LIST_STRING(({"系统工具", "购物比价", "教育"}), itr5->second);
  TEST_LIST_INT32(({3}), itr_len5->second);

  auto itr6 = map.find("f16");
  auto itr_len6 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr6 != map.end());
  TEST_ASSERT_BOOL(itr_len6 != map.end());
  TEST_LIST_STRING(({"安全优化", "商城", "学习"}), itr6->second);
  TEST_LIST_INT32(({3}), itr_len6->second);

  auto itr7 = map.find("f17");
  auto itr_len7 = map.find("f17_length");
  TEST_ASSERT_BOOL(itr7 != map.end());
  TEST_ASSERT_BOOL(itr_len7 != map.end());
  TEST_LIST_STRING(({"实用工具工具", "默认值", "教育学习"}), itr7->second);
  TEST_LIST_INT32(({3}), itr_len7->second);

  auto itr8 = map.find("f18");
  auto itr_len8 = map.find("f18_length");
  TEST_ASSERT_BOOL(itr8 != map.end());
  TEST_ASSERT_BOOL(itr_len8 != map.end());
  TEST_LIST_STRING(({"武汉哒哒软件科技有限公司", "默认值", "山东金培教育科技有限公司"}), itr8->second);
  TEST_LIST_INT32(({3}), itr_len8->second);

  auto itr9 = map.find("f19");
  auto itr_len9 = map.find("f19_length");
  TEST_ASSERT_BOOL(itr9 != map.end());
  TEST_ASSERT_BOOL(itr_len9 != map.end());
  TEST_LIST_STRING(({"109999831236", "默认值", "106632998718"}), itr9->second);
  TEST_LIST_INT32(({3}), itr_len9->second);

  FUNC_TEST_END();
}

void test_dict_to_attributes_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes" source=".item_feature.item_feature_se.context.feature.package_name" dict_type="package_name" connector="," default_value="test_no_data" />
            <feature name="f11" type="direct" source="f10:0" />
            <feature name="f12" type="direct" source="f10:1" />
            <feature name="f13" type="direct" source="f10:2" />
            <feature name="f14" type="direct" source="f10:3" />
            <feature name="f15" type="direct" source="f10:4" />
            <feature name="f16" type="direct" source="f10:5" />
            <feature name="f17" type="direct" source="f10:6" />
            <feature name="f18" type="direct" source="f10:7" />
            <feature name="f19" type="direct" source="f10:8" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini</app_info>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f11" shape="1" type="sparse" />
        <input name="f12" shape="1" type="sparse" />
        <input name="f13" shape="1" type="sparse" />
        <input name="f14" shape="1" type="sparse" />
        <input name="f15" shape="1" type="sparse" />
        <input name="f16" shape="1" type="sparse" />
        <input name="f17" shape="1" type="sparse" />
        <input name="f18" shape="1" type="sparse" />
        <input name="f19" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(10, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesConfig* conf = dynamic_cast<DictToAttributesConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.network.xf18142");
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.tzyz.meng.honor");
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.PeacockStudio.KongfuPunchLite");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("111");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr01 = map00.find("f11");
  auto itr11 = map01.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_STR(({"925089172", "104422431", "922331498"}), itr01->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr11->second);

  auto itr02 = map00.find("f12");
  auto itr12 = map01.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_STR(({"com.network.xf18142", "com.tzyz.meng.honor", "com.PeacockStudio.KongfuPunchLite"}), itr02->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr12->second);

  auto itr03 = map00.find("f13");
  auto itr13 = map01.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());

  TEST_FEATURE_STR(({"旋风加速器", "无尽梦回", "功夫之拳2"}), itr03->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr13->second);

  auto itr04 = map00.find("f14");
  auto itr14 = map01.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_ASSERT_BOOL(itr14 != map01.end());

  TEST_FEATURE_STR(({"应用", "游戏", "游戏"}), itr04->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr14->second);

  auto itr05 = map00.find("f15");
  auto itr15 = map01.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_ASSERT_BOOL(itr15 != map01.end());

  TEST_FEATURE_STR(({"生活", "角色扮演", "动作射击"}), itr05->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr15->second);

  auto itr06 = map00.find("f16");
  auto itr16 = map01.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_ASSERT_BOOL(itr16 != map01.end());

  TEST_FEATURE_STR(({"生活-其他", "角色扮演-其他", "格斗"}), itr06->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr16->second);

  auto itr07 = map00.find("f17");
  auto itr17 = map01.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_ASSERT_BOOL(itr17 != map01.end());

  TEST_FEATURE_STR(({"默认值", "默认值", "经典,破解,格斗,李小龙"}), itr07->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr17->second);

  auto itr08 = map00.find("f18");
  auto itr18 = map01.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_ASSERT_BOOL(itr18 != map01.end());

  TEST_FEATURE_STR(({"默认值", "杭州弹指宇宙科技有限公司", "默认值"}), itr08->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr18->second);

  auto itr09 = map00.find("f19");
  auto itr19 = map01.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_ASSERT_BOOL(itr19 != map01.end());

  TEST_FEATURE_STR(({"默认值", "109999814778", "默认值"}), itr09->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr19->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values1 = map.find("f11_values");
  auto itr_indices1 = map.find("f11_indices");
  auto itr_dense_shape1 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"925089172", "104422431", "922331498", "test_no_data"}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f12_values");
  auto itr_indices2 = map.find("f12_indices");
  auto itr_dense_shape2 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"com.network.xf18142", "com.tzyz.meng.honor", "com.PeacockStudio.KongfuPunchLite", "test_no_data"}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f13_values");
  auto itr_indices3 = map.find("f13_indices");
  auto itr_dense_shape3 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"旋风加速器", "无尽梦回", "功夫之拳2", "test_no_data"}),
                        itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  auto itr_values4 = map.find("f14_values");
  auto itr_indices4 = map.find("f14_indices");
  auto itr_dense_shape4 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values4 != map.end());
  TEST_ASSERT_BOOL(itr_indices4 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape4 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"应用", "游戏", "游戏", "test_no_data"}),
                        itr_indices4->second, itr_dense_shape4->second, itr_values4->second);

  auto itr_values5 = map.find("f15_values");
  auto itr_indices5 = map.find("f15_indices");
  auto itr_dense_shape5 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values5 != map.end());
  TEST_ASSERT_BOOL(itr_indices5 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape5 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"生活", "角色扮演", "动作射击", "test_no_data"}),
                        itr_indices5->second, itr_dense_shape5->second, itr_values5->second);

  auto itr_values6 = map.find("f16_values");
  auto itr_indices6 = map.find("f16_indices");
  auto itr_dense_shape6 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values6 != map.end());
  TEST_ASSERT_BOOL(itr_indices6 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape6 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"生活-其他", "角色扮演-其他", "格斗", "test_no_data"}),
                        itr_indices6->second, itr_dense_shape6->second, itr_values6->second);

  auto itr_values7 = map.find("f17_values");
  auto itr_indices7 = map.find("f17_indices");
  auto itr_dense_shape7 = map.find("f17_dense_shape");
  TEST_ASSERT_BOOL(itr_values7 != map.end());
  TEST_ASSERT_BOOL(itr_indices7 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape7 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"默认值", "默认值", "经典,破解,格斗,李小龙", "test_no_data"}),
                        itr_indices7->second, itr_dense_shape7->second, itr_values7->second);

  auto itr_values8 = map.find("f18_values");
  auto itr_indices8 = map.find("f18_indices");
  auto itr_dense_shape8 = map.find("f18_dense_shape");
  TEST_ASSERT_BOOL(itr_values8 != map.end());
  TEST_ASSERT_BOOL(itr_indices8 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape8 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"默认值", "杭州弹指宇宙科技有限公司", "默认值", "test_no_data"}),
                        itr_indices8->second, itr_dense_shape8->second, itr_values8->second);

  auto itr_values9 = map.find("f19_values");
  auto itr_indices9 = map.find("f19_indices");
  auto itr_dense_shape9 = map.find("f19_dense_shape");
  TEST_ASSERT_BOOL(itr_values9 != map.end());
  TEST_ASSERT_BOOL(itr_indices9 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape9 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"默认值", "109999814778", "默认值", "test_no_data"}),
                        itr_indices9->second, itr_dense_shape9->second, itr_values9->second);

  FUNC_TEST_END();
}

// 查询不到对应的信息时，并且未配置默认值，返回空
void test_dict_to_attributes_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes" source=".item_feature.item_feature_se.context.feature.package_name" dict_type="package_name" connector="," strategy="empty" />
            <feature name="f11" type="direct" source="f10:0" strategy="empty" />
            <feature name="f12" type="direct" source="f10:1" strategy="empty" />
            <feature name="f13" type="direct" source="f10:2" strategy="empty" />
            <feature name="f14" type="direct" source="f10:3" strategy="empty" />
            <feature name="f15" type="direct" source="f10:4" strategy="empty" />
            <feature name="f16" type="direct" source="f10:5" strategy="empty" />
            <feature name="f17" type="direct" source="f10:6" strategy="empty" />
            <feature name="f18" type="direct" source="f10:7" strategy="empty" />
            <feature name="f19" type="direct" source="f10:8" strategy="empty" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini</app_info>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(10, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesConfig* conf = dynamic_cast<DictToAttributesConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("111");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_STR(({}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_STR(({}), itr02->second);

  auto itr03 = map00.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_STR(({}), itr03->second);

  auto itr04 = map00.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_STR(({}), itr04->second);

  auto itr05 = map00.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_STR(({}), itr05->second);

  auto itr06 = map00.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_FEATURE_STR(({}), itr06->second);

  auto itr07 = map00.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_FEATURE_STR(({}), itr07->second);

  auto itr08 = map00.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_FEATURE_STR(({}), itr08->second);

  auto itr09 = map00.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_FEATURE_STR(({}), itr09->second);

  FUNC_TEST_END();
}

//user一层repeated且在source字段尾部
void test_conditional_filter_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="conditional_filter" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq" filter="query,appid1,appid3;event_type,001" fields="pay_money,event_time" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConditionalFilterConfig* conf = dynamic_cast<ConditionalFilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(10);
  pb_info->set_event_time(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(20);
  pb_info->set_event_time(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(30);
  pb_info->set_event_time(300);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(40);
  pb_info->set_event_time(400);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("003");
  pb_info->set_pay_money(50);
  pb_info->set_event_time(500);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{10}, {30}, {40}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{100}, {300}, {400}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({10, 30, 40}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({100, 300, 400}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

//user一层repeated且在source中间
void test_conditional_filter_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="conditional_filter" source=".user_action.conv_ascribe_type.sdk_conversion" filter="event_time,200" fields="label,flag" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConditionalFilterConfig* conf = dynamic_cast<ConditionalFilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserAction* pb_action = request.add_user_action();
  qinglong::ConvInfo* pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(20);
  pb_info->set_flag(2);
  pb_info->set_event_time("200");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(10);
  pb_info->set_flag(1);
  pb_info->set_event_time("100");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(40);
  pb_info->set_flag(4);
  pb_info->set_event_time("400");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(30);
  pb_info->set_flag(3);
  pb_info->set_event_time("200");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{20}, {30}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{2}, {3}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({20, 30}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({2, 3}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  FUNC_TEST_END();
}

void test_conditional_filter_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="conditional_filter" source=".item_feature.game_item_query_offline_feature.gamecenter_item_query_interact_feature" filter="app_package,app01" fields="query,qam_udtr15d_2" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConditionalFilterConfig* conf = dynamic_cast<ConditionalFilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  qinglong::GameCenterItemQueryInteractFeature* interact = item->mutable_game_item_query_offline_feature()->mutable_gamecenter_item_query_interact_feature();
  interact->set_qam_udtr15d_2(0.57);
  interact->set_query("app01");
  interact->set_app_package("app01");
  
  item = request.add_item_feature();
  interact = item->mutable_game_item_query_offline_feature()->mutable_gamecenter_item_query_interact_feature();
  interact->set_qam_udtr15d_2(0.33);
  interact->set_query("app03");
  interact->set_app_package("app03");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"app01"}), itr00->second);
  TEST_FEATURE_STR(({}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_FLOAT(({0.57}), itr01->second);
  TEST_FEATURE_FLOAT(({}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({2, 1}), ({"app01"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f8_values");
  auto itr_indices1 = map.find("f8_indices");
  auto itr_dense_shape1 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0}), ({2, 1}), ({0.57}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

//user一层repeated且在source字段尾部
void test_message_filter_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq,.request_time" str_filter="query,hit,appid1,appid3;event_type,hit,001" int_filter="pay_money,hit,100,200,300" eventtime_key="event_time" clip_h="720" start_ms="864000000" />
            <feature name="f7" type="direct" source="f6.pay_money" />
            <feature name="f8" type="direct" source="f6.query" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterConfig* conf = dynamic_cast<MessageFilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  
  //pay_money过滤
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(10);
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);

  //query过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(20);
  pb_info->set_event_time((int64_t)85 * 86400 * 1000);

  //时间范围过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(30);
  pb_info->set_event_time((int64_t)60 * 86400 * 1000);

  //防穿越过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(40);
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);

  //event_type过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("003");
  pb_info->set_pay_money(50);
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(200);
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(100);
  pb_info->set_event_time((int64_t)85 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{200}, {100}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid3"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({200, 100}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"appid1", "appid3"}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  FUNC_TEST_END();
}

//user一层repeated且在source中间
void test_message_filter_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter" source=".user_action.conv_ascribe_type.sdk_conversion" str_filter="event_time,miss,200" int_filter="flag,hit,1,2,3;label,miss,10" />
            <feature name="f7" type="direct" source="f6.label" />
            <feature name="f8" type="direct" source="f6.flag" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterConfig* conf = dynamic_cast<MessageFilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserAction* pb_action = request.add_user_action();
  qinglong::ConvInfo* pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();

  //event_time过滤
  pb_info->set_label(20);
  pb_info->set_flag(2);
  pb_info->set_event_time("200");

  //label过滤
  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(10);
  pb_info->set_flag(1);
  pb_info->set_event_time("100");

  //flag过滤
  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(40);
  pb_info->set_flag(4);
  pb_info->set_event_time("400");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(30);
  pb_info->set_flag(3);
  pb_info->set_event_time("100");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(50);
  pb_info->set_flag(1);
  pb_info->set_event_time("300");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(20);
  pb_info->set_flag(2);
  pb_info->set_event_time("500");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{30}, {50}, {20}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{3}, {1}, {2}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({30, 50, 20}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({3, 1, 2}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

//user两层repeated且在source中间
void test_message_filter_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f5" type="message_filter" source=".user_feature.ad_context_feature.info_flow_context.info_flow_item" str_filter="label,miss,200;tip,hit,1,2,3" />
            <feature name="f6" type="message_filter" source="f5.filter_words" str_filter="id,hit,0,1,2" />
            <feature name="f7" type="direct" source="f6.id" />
            <feature name="f8" type="direct" source="f6.name" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterConfig* conf = dynamic_cast<MessageFilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::InfoFlowContext* pb_info = pb_ufv2->mutable_ad_context_feature()->mutable_info_flow_context();
  qinglong::InfoFlowItem* pb_item = pb_info->add_info_flow_item();

  //label过滤
  pb_item->set_label("200");
  pb_item->set_tip("1");

  qinglong::FilterWords* pb_word = pb_item->add_filter_words();
  pb_word->set_id("0");
  pb_word->set_name("appid0");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("1");
  pb_word->set_name("appid1");

  //tip过滤
  pb_item = pb_info->add_info_flow_item();
  pb_item->set_label("100");
  pb_item->set_tip("0");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("0");
  pb_word->set_name("appid2");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("1");
  pb_word->set_name("appid3");

  pb_item = pb_info->add_info_flow_item();
  pb_item->set_label("100");
  pb_item->set_tip("1");

  //id过滤
  pb_word = pb_item->add_filter_words();
  pb_word->set_id("3");
  pb_word->set_name("appid4");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("1");
  pb_word->set_name("appid5");
  
  pb_item = pb_info->add_info_flow_item();
  pb_item->set_label("100");
  pb_item->set_tip("2");

  //id过滤
  pb_word = pb_item->add_filter_words();
  pb_word->set_id("6");
  pb_word->set_name("appid6");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("2");
  pb_word->set_name("appid7");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("0");
  pb_word->set_name("appid8");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"1"}, {"2"}, {"0"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid5"}, {"appid7"}, {"appid8"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"1", "2", "0"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"appid5", "appid7", "appid8"}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

//user一层repeated且在source字段尾部
void test_message_filter_v2_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter_v2" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq,.item_feature.item_feature_se.context.feature.query,.item_feature.item_feature_se.context.feature.event_type,.item_feature.item_feature_se.context.feature.pay_money" filter="str,query,hit;str,event_type,hit;int,pay_money,hit" />
            <feature name="f7" type="direct" source="f6.pay_money" />
            <feature name="f8" type="direct" source="f6.query" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterV2Config* conf = dynamic_cast<MessageFilterV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(10);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(20);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("003");
  pb_info->set_pay_money(50);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(100);

  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* sq = item->mutable_item_feature_se();
  tensorflow::Features* fs = sq->mutable_context();
  auto& input_map = *fs->mutable_feature();
  tensorflow::Feature& input_q = input_map["query"];
  input_q.mutable_bytes_list()->add_value("appid1");
  tensorflow::Feature& input_t = input_map["event_type"];
  input_t.mutable_bytes_list()->add_value("001");
  tensorflow::Feature& input_p = input_map["pay_money"];
  input_p.mutable_int64_list()->add_value(100);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{100}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({100}), itr0->second);
  TEST_LIST_INT32(({1}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"appid1"}), itr1->second);
  TEST_LIST_INT32(({1}), itr_len1->second);

  FUNC_TEST_END();
}

//user一层repeated且在source中间
void test_message_filter_v2_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter_v2" source=".user_action.conv_ascribe_type.sdk_conversion,.item_feature.item_feature_se.context.feature.event_time,.item_feature.item_feature_se.context.feature.flag,.item_feature.item_feature_se.context.feature.label" filter="str,event_time,miss;int,flag,hit;int,label,miss" />
            <feature name="f7" type="direct" source="f6.label" />
            <feature name="f8" type="direct" source="f6.flag" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterV2Config* conf = dynamic_cast<MessageFilterV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserAction* pb_action = request.add_user_action();
  qinglong::ConvInfo* pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();

  pb_info->set_label(20);
  pb_info->set_flag(2);
  pb_info->set_event_time("200");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(10);
  pb_info->set_flag(1);
  pb_info->set_event_time("100");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(50);
  pb_info->set_flag(1);
  pb_info->set_event_time("300");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(20);
  pb_info->set_flag(1);
  pb_info->set_event_time("500");

  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* sq = item->mutable_item_feature_se();
  tensorflow::Features* fs = sq->mutable_context();
  auto& input_map = *fs->mutable_feature();
  tensorflow::Feature& input_q = input_map["event_time"];
  input_q.mutable_bytes_list()->add_value("300");
  tensorflow::Feature& input_t = input_map["flag"];
  input_t.mutable_int64_list()->add_value(1);
  tensorflow::Feature& input_p = input_map["label"];
  input_p.mutable_int64_list()->add_value(20);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{10}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{1}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({10}), itr0->second);
  TEST_LIST_INT32(({1}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({1}), itr1->second);
  TEST_LIST_INT32(({1}), itr_len1->second);

  FUNC_TEST_END();
}

void test_message_filter_v2_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter_v2" source=".item_feature.feature_group_meta,.item_feature.item_feature_se.context.feature.version" filter="str,version,hit" />
            <feature name="f7" type="direct" source="f6.featuregroup" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterV2Config* conf = dynamic_cast<MessageFilterV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  qinglong::ItemFeature* item = request.add_item_feature();

  qinglong::FeatureGroupMeta* meta = item->add_feature_group_meta();
  meta->set_featuregroup("1");
  meta->set_version("1");

  meta = item->add_feature_group_meta();
  meta->set_featuregroup("2");
  meta->set_version("2");

  tensorflow::SequenceExample* sq = item->mutable_item_feature_se();
  tensorflow::Features* fs = sq->mutable_context();
  auto& input_map = *fs->mutable_feature();
  tensorflow::Feature& input_1 = input_map["version"];
  input_1.mutable_bytes_list()->add_value("1");

  item = request.add_item_feature();

  meta = item->add_feature_group_meta();
  meta->set_featuregroup("1");
  meta->set_version("1");

  meta = item->add_feature_group_meta();
  meta->set_featuregroup("2");
  meta->set_version("2");

  sq = item->mutable_item_feature_se();
  fs = sq->mutable_context();
  auto& input_map2 = *fs->mutable_feature();
  tensorflow::Feature& input_2 = input_map2["version"];
  input_2.mutable_bytes_list()->add_value("2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map01 = batch_ret.batch(1).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"1"}}), itr00->second);

  auto itr01 = map01.find("f7");
  TEST_ASSERT_BOOL(itr01 != map01.end());
  TEST_FEATURE_LIST_STR(({{"2"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"1", "2"}), itr0->second);
  TEST_LIST_INT32(({1, 1}), itr_len0->second);

  FUNC_TEST_END();
}

//pb获取值失败使用默认值
void test_message_filter_v2_4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter_v2" source=".item_feature.feature_group_meta,E@.item_feature.item_feature_se.context.feature.version" filter="str,version,hit,1" />
            <feature name="f7" type="direct" source="f6.featuregroup" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterV2Config* conf = dynamic_cast<MessageFilterV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  qinglong::ItemFeature* item = request.add_item_feature();

  qinglong::FeatureGroupMeta* meta = item->add_feature_group_meta();
  meta->set_featuregroup("1");
  meta->set_version("1");

  meta = item->add_feature_group_meta();
  meta->set_featuregroup("2");
  meta->set_version("2");

  item = request.add_item_feature();

  meta = item->add_feature_group_meta();
  meta->set_featuregroup("1");
  meta->set_version("1");

  meta = item->add_feature_group_meta();
  meta->set_featuregroup("2");
  meta->set_version("2");

  tensorflow::SequenceExample* sq = item->mutable_item_feature_se();
  tensorflow::Features* fs = sq->mutable_context();
  auto& input_map2 = *fs->mutable_feature();
  tensorflow::Feature& input_2 = input_map2["version"];
  input_2.mutable_bytes_list()->add_value("2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map01 = batch_ret.batch(1).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"1"}}), itr00->second);

  auto itr01 = map01.find("f7");
  TEST_ASSERT_BOOL(itr01 != map01.end());
  TEST_FEATURE_LIST_STR(({{"2"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"1", "2"}), itr0->second);
  TEST_LIST_INT32(({1, 1}), itr_len0->second);

  FUNC_TEST_END();
}

// 时间戳过滤
void test_message_filter_v2_5() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter_v2" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq,.item_feature.item_feature_se.context.feature.query,.request_time" filter="str,query,hit,1" eventtime_key="event_time" clip_h="720" start_ms="864000000" />
            <feature name="f7" type="direct" source="f6.event_type" />
            <feature name="f8" type="message_filter_v2" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq,.item_feature.item_feature_se.context.feature.string,.request_time" filter="str,query,hit,1" eventtime_key="event_time" clip_h="720" start_ms="864000000" />
            <feature name="f9" type="direct" source="f8.event_type" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterV2Config* conf = dynamic_cast<MessageFilterV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);

  //query过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_event_type("002");
  pb_info->set_event_time((int64_t)85 * 86400 * 1000);

  //时间范围过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_event_type("003");
  pb_info->set_event_time((int64_t)60 * 86400 * 1000);

  //防穿越过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("004");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("005");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_event_type("006");
  pb_info->set_event_time((int64_t)85 * 86400 * 1000);

  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* sq = item->mutable_item_feature_se();
  tensorflow::Features* fs = sq->mutable_context();
  auto& input_map = *fs->mutable_feature();
  tensorflow::Feature& input_1 = input_map["query"];
  input_1.mutable_bytes_list()->add_value("appid1");

  tensorflow::Feature& input_2 = input_map["string"];
  input_2.mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"001"}, {"005"}}), itr00->second);

  auto itr01 = map00.find("f9");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"006"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"001", "005"}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f9");
  auto itr_len1 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"006"}), itr1->second);
  TEST_LIST_INT32(({1}), itr_len1->second);

  FUNC_TEST_END();
}

// pb值正常命中
void test_message_filter_select_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_select" source=".user_action,.user_action.download_start" select_option="int;1,item_id;2,conv_ascribe_type" />
            <feature name="f7" type="message_select" source=".user_action,.user_action.media_id" select_option="str;1,item_id;2,conv_ascribe_type" />
            <feature name="f8" type="direct" source="f6.sdk_conversion.flag" />
            <feature name="f9" type="direct" source="f7.item_id" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageSelectConfig<int64_t>* conf = dynamic_cast<MessageSelectConfig<int64_t>*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserAction* pb_action = request.add_user_action();
  pb_action->set_download_start(2);
  pb_action->set_media_id("1");
  qinglong::ConvInfo* pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  qinglong::ItemId* item = pb_action->mutable_item_id();
  item->set_item_id("10");
  pb_info->set_flag(2);

  pb_action = request.add_user_action();
  pb_action->set_download_start(2);
  pb_action->set_media_id("1");
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  item = pb_action->mutable_item_id();
  item->set_item_id("20");
  pb_info->set_flag(1);

  //不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{2}, {1}}), itr00->second);

  auto itr01 = map00.find("f9");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"10"}, {"20"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f8");
  auto itr_len0 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({2, 1}), itr0->second);  
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f9");
  auto itr_len1 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"10", "20"}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  FUNC_TEST_END();
}

// pb值未命中，输出空
void test_message_filter_select_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_select" source=".user_action,.user_action.download_start" select_option="int;1,item_id;2,conv_ascribe_type" default_value="2" />
            <feature name="f7" type="message_select" source=".user_action,.user_action.media_id" select_option="str;1,item_id;2,conv_ascribe_type" default_value="1" />
            <feature name="f8" type="direct" source="f6.sdk_conversion.flag" strategy="empty" />
            <feature name="f9" type="direct" source="f7.item_id" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageSelectConfig<int64_t>* conf = dynamic_cast<MessageSelectConfig<int64_t>*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserAction* pb_action = request.add_user_action();
  pb_action->set_download_start(0);
  pb_action->set_media_id("0");
  qinglong::ConvInfo* pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  qinglong::ItemId* item = pb_action->mutable_item_id();
  item->set_item_id("10");

  pb_info->set_flag(2);

  pb_action = request.add_user_action();
  pb_action->set_download_start(0);
  pb_action->set_media_id("0");
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  item = pb_action->mutable_item_id();
  item->set_item_id("20");
  pb_info->set_flag(1);

  //不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({}), itr00->second);

  auto itr01 = map00.find("f9");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f8");
  auto itr_len0 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({}), itr0->second);  
  TEST_LIST_INT32(({0}), itr_len0->second);

  auto itr1 = map.find("f9");
  auto itr_len1 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({}), itr1->second);
  TEST_LIST_INT32(({0}), itr_len1->second);

  FUNC_TEST_END();
}

// pb值获取失败，使用默认值
void test_message_filter_select_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_select" source=".user_action,E@.item_feature.item_feature_se.context.feature.empty" select_option="int;1,item_id;2,conv_ascribe_type" default_value="2" />
            <feature name="f7" type="message_select" source=".user_action,E@.item_feature.item_feature_se.context.feature.empty" select_option="str;1,item_id;2,conv_ascribe_type" default_value="1" />
            <feature name="f8" type="direct" source="f6.sdk_conversion.flag" />
            <feature name="f9" type="direct" source="f7.item_id" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageSelectConfig<int64_t>* conf = dynamic_cast<MessageSelectConfig<int64_t>*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserAction* pb_action = request.add_user_action();
  pb_action->set_download_start(2);
  pb_action->set_media_id("1");
  qinglong::ConvInfo* pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  qinglong::ItemId* item = pb_action->mutable_item_id();
  item->set_item_id("10");
  pb_info->set_flag(2);

  pb_action = request.add_user_action();
  pb_action->set_download_start(2);
  pb_action->set_media_id("1");
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  item = pb_action->mutable_item_id();
  item->set_item_id("20");
  pb_info->set_flag(1);

  //不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{2}, {1}}), itr00->second);

  auto itr01 = map00.find("f9");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"10"}, {"20"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f8");
  auto itr_len0 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({2, 1}), itr0->second);  
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f9");
  auto itr_len1 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"10", "20"}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  FUNC_TEST_END();
}

void test_strategy() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f1" : {
          "fe_type" : "direct", 
          "source": [".item_feature.item_feature_se.context.feature.appid"],
          "strategy" : ["feature"]
      },
      "f2": {
          "fe_type" : "direct", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num"],
          "strategy" : ["feature", "auto_type"]
      },
      "f3": {
          "fe_type" : "direct", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num"],
          "strategy" : ["feature", "hash", "auto_type"]
      },
      "f4" : {
          "fe_type" : "direct", 
          "source": [".item_feature.item_feature_se.context.feature.appid"],
          "strategy" : ["hash", "auto_type"]
      },
      "f5": {
          "fe_type" : "direct", 
          "source": [".item_feature.item_feature_se.context.feature.empty"],
          "strategy" : ["empty"]
      },
      "f6": {
          "fe_type" : "direct", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num"],
          "strategy" : ["hash", "auto_type"]
      },
      "f7": {
          "fe_type" : "direct", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num"],
          "strategy" : ["dont_save"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f2": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f3": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f4": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f6": {
            "dtype" : "float",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(7, vec.size());

  TEST_ASSERT_BOOL(nullptr != vec[0]);
  DirectConfig* conf1 = dynamic_cast<DirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf1);

  TEST_ASSERT_BOOL(nullptr != vec[1]);
  DirectConfig* conf2 = dynamic_cast<DirectConfig*>(vec[1].get());
  TEST_ASSERT_BOOL(nullptr != conf2);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);
  TEST_ASSERT_EQUAL(4, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_num(0);
  pb_use->add_user_sequence()->set_num(1);
  pb_use->add_user_sequence()->set_num(2);
  pb_use->add_user_sequence()->set_num(3);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::Feature& input_f = (*(item->mutable_context()->mutable_feature()))["appid"];
  input_f.mutable_bytes_list()->add_value("900778570");
  input_f.mutable_bytes_list()->add_value("104436666");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map = batch_ret.batch(0).context().feature();

  auto itr01 = map.find("f1");
  TEST_ASSERT_BOOL(itr01 != map.end());
  TEST_FEATURE_STR(({"900778570", "104436666"}), itr01->second);

  auto itr02 = map.find("f2");
  TEST_ASSERT_BOOL(itr02 != map.end());
  TEST_FEATURE_INT64(({0, 1, 2, 3}), itr02->second);

  auto itr03 = map.find("f3");
  TEST_ASSERT_BOOL(itr03 != map.end());
  TEST_FEATURE_INT64(({3042990692995248735, 6333283390351972457, 6238308942721332819, 4266776588970077092}), itr03->second);

  auto itr04 = map.find("f4");
  TEST_ASSERT_BOOL(itr04 != map.end());
  TEST_FEATURE_INT64(({4332178348574154799, 3756374228245537501}), itr04->second);

  auto itr05 = map.find("f5");
  TEST_ASSERT_BOOL(itr05 != map.end());
    
  TEST_EXPECT_EQUAL(0, itr05->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL(0, itr05->second.float_list().value_size());
  TEST_EXPECT_EQUAL(0, itr05->second.int64_list().value_size());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr06 = map0.find("f6");
  TEST_ASSERT_BOOL(itr06 != map0.end());

  TEST_FEATURE_LIST_INT64(({{3042990692995248735}, {6333283390351972457}, {6238308942721332819}, {4266776588970077092}}), itr06->second);

  auto itr07 = map0.find("f7");
  TEST_ASSERT_BOOL(itr07 == map0.end());

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);

  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map1 = ret.inputs();

  auto itr_values0 = map1.find("f2_values");
  auto itr_indices0 = map1.find("f2_indices");
  auto itr_dense_shape0 = map1.find("f2_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map1.end());
  TEST_ASSERT_BOOL(itr_indices0 != map1.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map1.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 0, 3}), ({1, 4}), ({0, 1, 2, 3}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map1.find("f3_values");
  auto itr_indices1 = map1.find("f3_indices");
  auto itr_dense_shape1 = map1.find("f3_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map1.end());
  TEST_ASSERT_BOOL(itr_indices1 != map1.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map1.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 0, 3}), ({1, 4}), ({3042990692995248735, 6333283390351972457, 6238308942721332819, 4266776588970077092}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map1.find("f4_values");
  auto itr_indices2 = map1.find("f4_indices");
  auto itr_dense_shape2 = map1.find("f4_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map1.end());
  TEST_ASSERT_BOOL(itr_indices2 != map1.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map1.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1}), ({1, 2}), ({4332178348574154799, 3756374228245537501}),
                            itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr0 = map1.find("f6");
  auto itr_len0 = map1.find("f6_length");
  TEST_ASSERT_BOOL(itr0 != map1.end());
  TEST_ASSERT_BOOL(itr_len0 != map1.end());
  TEST_LIST_INT64(({3042990692995248735, 6333283390351972457, 6238308942721332819, 4266776588970077092}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  FUNC_TEST_END();
}

void test_hash_slot() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" />
            <feature name="f3" type="direct" source=".item_feature.item_feature_se.context.feature.appid" strategy="hash" />
        </features>
    </config>
  )";

  std::string config_str2 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" slot="12345" />
            <feature name="f2" type="direct" source=".item_feature.item_feature_se.context.feature.appid" strategy="hash" slot="21543" />
        </features>
    </config>
    <hash_slot flag="true" />
  )";

  std::string config_str3 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" slot="10000" share_slot="12345" />
            <feature name="f2" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" slot="6666" />
            <feature name="f3" type="direct" source=".item_feature.item_feature_se.context.feature.appid" strategy="hash" slot="21543" share_slot="12345" />
            <feature name="f4" type="direct" source=".item_feature.item_feature_se.context.feature.appid" strategy="hash" slot="18327" />
        </features>
    </config>
    <hash_slot flag="true" />
  )";

  std::string config_str4 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" slot="65535" />
        </features>
    </config>
    <hash_slot flag="true" />
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_BOOL(nullptr != vec[0]);
  DirectConfig* conf1 = dynamic_cast<DirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf1);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_num(0);
  pb_use->add_user_sequence()->set_num(1);
  pb_use->add_user_sequence()->set_num(2);
  pb_use->add_user_sequence()->set_num(3);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::Feature& input_f = (*(item->mutable_context()->mutable_feature()))["appid"];
  input_f.mutable_bytes_list()->add_value("900778570");
  input_f.mutable_bytes_list()->add_value("104436666");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map = batch_ret.batch(0).context().feature();
  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map0.find("f1");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_FEATURE_LIST_INT64(({{3042990692995248735}, {6333283390351972457}, {6238308942721332819}, {4266776588970077092}}), itr01->second);

  auto itr02 = map.find("f3");
  TEST_ASSERT_BOOL(itr02 != map.end());
  TEST_FEATURE_INT64(({4332178348574154799, 3756374228245537501}), itr02->second);

  vec.clear();
  XmlConfigMgr::parse_from_string(config_str2, "", "", vec);
  qinglong::BatchSequenceExample batch_ret2;

  toSequenceExample(&arena, request, vec, batch_ret2);

  TEST_ASSERT_EQUAL(1, batch_ret2.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(0).has_feature_lists());

  const auto& map1 = batch_ret2.batch(0).context().feature();
  const auto& map01 = batch_ret2.batch(0).feature_lists().feature_list();

  auto itr03 = map01.find("f1");
  TEST_ASSERT_BOOL(itr03 != map01.end());
  TEST_FEATURE_LIST_INT64(({{3475054782246105695}, {3474905001855260777}, {3475069096352822867}, {3474987479483001764}}), itr03->second);

  auto itr04 = map1.find("f2");
  TEST_ASSERT_BOOL(itr04 != map1.end());
  TEST_FEATURE_INT64(({6064093880274821167, 6063906087319495389}), itr04->second);

  vec.clear();
  XmlConfigMgr::parse_from_string(config_str3, "", "", vec);
  qinglong::BatchSequenceExample batch_ret3;

  toSequenceExample(&arena, request, vec, batch_ret3);

  TEST_ASSERT_EQUAL(1, batch_ret3.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret3.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret3.batch(0).has_feature_lists());

  const auto& map2 = batch_ret3.batch(0).context().feature();
  const auto& map02 = batch_ret3.batch(0).feature_lists().feature_list();

  auto itr05 = map02.find("f1");
  TEST_ASSERT_BOOL(itr05 != map02.end());
  TEST_FEATURE_LIST_INT64(({{3475054782246105695}, {3474905001855260777}, {3475069096352822867}, {3474987479483001764}}), itr05->second);

  auto itr06 = map02.find("f2");
  TEST_ASSERT_BOOL(itr06 != map02.end());
  TEST_FEATURE_LIST_INT64(({{1876558389506290271}, {1876408609115445353}, {1876572703613007443}, {1876491086743186340}}), itr06->second);

  auto itr07 = map2.find("f3");
  TEST_ASSERT_BOOL(itr07 != map2.end());
  TEST_FEATURE_INT64(({3475087044490207279, 3474899251534881501}), itr07->second);

  auto itr08 = map2.find("f4");
  TEST_ASSERT_BOOL(itr08 != map2.end());
  TEST_FEATURE_INT64(({5158870355173351471, 5158682562218025693}), itr08->second);

  vec.clear();
  XmlConfigMgr::parse_from_string(config_str4, "", "", vec);
  qinglong::BatchSequenceExample batch_ret4;

  toSequenceExample(&arena, request, vec, batch_ret4);

  TEST_ASSERT_EQUAL(1, batch_ret4.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret4.batch(0).has_feature_lists());

  const auto& map03 = batch_ret4.batch(0).feature_lists().feature_list();

  auto itr09 = map03.find("f1");
  TEST_ASSERT_BOOL(itr09 != map03.end());
  TEST_FEATURE_LIST_INT64(({{-35280223653281}, {-185060614498199}, {-20966116936109}, {-102582986757212}}), itr09->second);

  bool flag = false;
  vec.clear();

  std::string config_str5 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" />
        </features>
    </config>
    <hash_slot flag="true" />
  )";

  try {
    XmlConfigMgr::parse_from_string(config_str5, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  flag = false;
  vec.clear();

  std::string config_str6 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" slot="888888" />
        </features>
    </config>
    <hash_slot flag="true" />
  )";

  try {
    XmlConfigMgr::parse_from_string(config_str6, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  std::string config_str7 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" slot="ff5"/>
        </features>
    </config>
    <hash_slot flag="true" />
 )";

  flag = false;
  vec.clear();

  try {
    XmlConfigMgr::parse_from_string(config_str7, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  std::string config_str8 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" slot="12345" share_slot="ff5" />
        </features>
    </config>
    <hash_slot flag="true" />
 )";

  flag = false;
  vec.clear();

  try {
    XmlConfigMgr::parse_from_string(config_str8, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  std::string config_str9 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" slot="12345" />
            <feature name="f2" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" slot="12345" />
        </features>
    </config>
    <hash_slot flag="true" />
 )";

  flag = false;
  vec.clear();

  try {
    XmlConfigMgr::parse_from_string(config_str9, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  std::string config_str10 = R"(
    <config>
        <features>
            <feature name="f15" type="cross_hash_bits" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.context.feature.num" clip_size="2" />
        </features>
    </config>
    <hash_slot flag="true" />
 )";

  flag = false;
  vec.clear();

  try {
    XmlConfigMgr::parse_from_string(config_str10, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  std::string config_str11 = R"(
    <config>
        <features>
            <feature name="f15" type="cross_hash_bits_v2" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.context.feature.num" clip_size="2" />
        </features>
    </config>
    <hash_slot flag="true" />
 )";

  flag = false;
  vec.clear();

  try {
    XmlConfigMgr::parse_from_string(config_str11, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  FUNC_TEST_END();
}

void test_hash_slot_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_hash_bits" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.context.feature.num" clip_size="2" />
            <feature name="f16" type="cross_hash_bits" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num,.item_feature.item_feature_se.context.feature.num" clip_size="2" />
        </features>
    </config>
  )";

  std::string config_str2 = R"(
    <config>
        <features>
            <feature name="f15" type="cross_hash_bits" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.context.feature.num" clip_size="2" slot="10000" />
            <feature name="f16" type="cross_hash_bits" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num,.item_feature.item_feature_se.context.feature.num" clip_size="2" slot="11000" />
        </features>
    </config>
    <hash_slot flag="true" />
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  CrossHashBitsConfig* conf = dynamic_cast<CrossHashBitsConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_num(111);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666");
  pb_info->set_num(222);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_num(333);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(123);
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(456);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({2691775485725007818, 3829262424187394606}), itr00->second);
  TEST_FEATURE_INT64(({55067832212840154, 1206117589933513534}), itr10->second);

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({2499017310282721954, 4338371674481846514}), itr01->second);
  TEST_FEATURE_INT64(({519870455995345842, 1849930930865433058}), itr11->second);

  vec.clear();
  XmlConfigMgr::parse_from_string(config_str2, "", "", vec);
  qinglong::BatchSequenceExample batch_ret2;

  toSequenceExample(&arena, request, vec, batch_ret2);

  TEST_ASSERT_EQUAL(2, batch_ret2.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(1).has_context());

  const auto& map02 = batch_ret2.batch(0).context().feature();
  const auto& map03 = batch_ret2.batch(1).context().feature();

  auto itr02 = map02.find("f15");
  auto itr12 = map03.find("f15");
  TEST_ASSERT_BOOL(itr02 != map02.end());
  TEST_ASSERT_BOOL(itr12 != map03.end());

  TEST_FEATURE_INT64(({2814780050547564490, 2814826608122190382}), itr02->second);
  TEST_FEATURE_INT64(({2814929978860822234, 2815028556811623230}), itr12->second);

  auto itr03 = map02.find("f16");
  auto itr13 = map03.find("f16");
  TEST_ASSERT_BOOL(itr03 != map02.end());
  TEST_ASSERT_BOOL(itr13 != map03.end());

  TEST_FEATURE_INT64(({3096307210862733986, 3096504077234432242}), itr03->second);
  TEST_FEATURE_INT64(({3096492392804690866, 3096302127740217826}), itr13->second);

  FUNC_TEST_END();
}

void test_hash_slot_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_hash_bits_v2" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.context.feature.num" clip_size="2" />
            <feature name="f16" type="cross_hash_bits_v2" source=".item_feature.item_feature_se.context.feature.id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.context.feature.num" clip_size="2" />
        </features>
    </config>
  )";

  std::string config_str2 = R"(
    <config>
        <features>
            <feature name="f15" type="cross_hash_bits_v2" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.context.feature.num" clip_size="2" slot="10000" />
            <feature name="f16" type="cross_hash_bits_v2" source=".item_feature.item_feature_se.context.feature.id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.context.feature.num" clip_size="2" slot="10111" />
        </features>
    </config>
    <hash_slot flag="true" />
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  CrossHashBitsV2Config* conf = dynamic_cast<CrossHashBitsV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(123);
  (*(item->mutable_context()->mutable_feature()))["id"].mutable_bytes_list()->add_value("123");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(456);
  (*(item->mutable_context()->mutable_feature()))["id"].mutable_bytes_list()->add_value("456");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({2691775485725007818, 3829262424187394606}), itr00->second);
  TEST_FEATURE_INT64(({55067832212840154, 1206117589933513534}), itr10->second);

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({6633412928844399244, 9002732187733985604}), itr01->second);
  TEST_FEATURE_INT64(({8668603522544071245, 6391641590584932741}), itr11->second);

  vec.clear();
  XmlConfigMgr::parse_from_string(config_str2, "", "", vec);
  qinglong::BatchSequenceExample batch_ret2;

  toSequenceExample(&arena, request, vec, batch_ret2);

  TEST_ASSERT_EQUAL(2, batch_ret2.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(1).has_context());

  const auto& map02 = batch_ret2.batch(0).context().feature();
  const auto& map03 = batch_ret2.batch(1).context().feature();

  auto itr02 = map02.find("f15");
  auto itr12 = map03.find("f15");
  TEST_ASSERT_BOOL(itr02 != map02.end());
  TEST_ASSERT_BOOL(itr12 != map03.end());

  TEST_FEATURE_INT64(({2814780050547564490, 2814826608122190382}), itr02->second);
  TEST_FEATURE_INT64(({2814929978860822234, 2815028556811623230}), itr12->second);

  auto itr03 = map02.find("f16");
  auto itr13 = map03.find("f16");
  TEST_ASSERT_BOOL(itr03 != map02.end());
  TEST_ASSERT_BOOL(itr13 != map03.end());

  TEST_FEATURE_INT64(({2846167117202522764, 2846030022141806916}), itr03->second);
  TEST_FEATURE_INT64(({2846012154307441229, 2846182783937509765}), itr13->second);

  FUNC_TEST_END();
}

void test_default_type() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="direct" source="E@.item_feature.item_feature_se.context.feature.float" strategy="empty,float" />
            <feature name="f7" type="direct" source="E@.item_feature.item_feature_se.context.feature.int64" strategy="empty,int64" />
            <feature name="f8" type="direct" source="E@.item_feature.item_feature_se.context.feature.string" strategy="empty,string" />
            <feature name="f9" type="direct" source="E@.item_feature.item_feature_se.context.feature.int32" strategy="empty,int32" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1" type="sparse" />
        <input name="f7" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  DirectConfig* config = dynamic_cast<DirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["float"];
  (*(item->mutable_context()->mutable_feature()))["int64"];
  (*(item->mutable_context()->mutable_feature()))["string"];
  (*(item->mutable_context()->mutable_feature()))["int32"];

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_FLOAT(({}), itr00->second);

  auto itr01 = map00.find("f7");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_FLOAT(({}), itr01->second);

  auto itr02 = map00.find("f8");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_STR(({}), itr02->second);

  auto itr03 = map00.find("f9");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_INT64(({}), itr03->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());
  TEST_SPARSE_TENSOR_FLOAT(({}), ({1, 0}), ({}), itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  TEST_EXPECT_EQUAL(tensorflow::DT_FLOAT, itr_values0->second.dtype());

  auto itr_values1 = map.find("f7_values");
  auto itr_indices1 = map.find("f7_indices");
  auto itr_dense_shape1 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());
  TEST_SPARSE_TENSOR_INT64(({}), ({1, 0}), ({}), itr_indices1->second, itr_dense_shape1->second, itr_values1->second);
  TEST_EXPECT_EQUAL(tensorflow::DT_INT64, itr_values1->second.dtype());

  auto itr_values3 = map.find("f8_values");
  auto itr_indices3 = map.find("f8_indices");
  auto itr_dense_shape3 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());
  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}), itr_indices3->second, itr_dense_shape3->second, itr_values3->second);
  TEST_EXPECT_EQUAL(tensorflow::DT_STRING, itr_values3->second.dtype());

  auto itr_values4 = map.find("f9_values");
  auto itr_indices4 = map.find("f9_indices");
  auto itr_dense_shape4 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values4 != map.end());
  TEST_ASSERT_BOOL(itr_indices4 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape4 != map.end());
  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}), itr_indices4->second, itr_dense_shape4->second, itr_values4->second);
  TEST_EXPECT_EQUAL(tensorflow::DT_INT32, itr_values4->second.dtype());

  FUNC_TEST_END();
}

//测试pb中double类型数据及默认值，正确读取到feature中
void test_double_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "direct", 
          "source": [".item_feature.game_item_offline_feature.game_item_statistic_feature.ictr_dou_v1"]
      }
    },
    "default_values": {
        ".item_feature.game_item_offline_feature.game_item_statistic_feature.ictr_dou_v1": {
            "dtype": "float",
            "values": 5.18
        }
    }  
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DirectConfig* conf = dynamic_cast<DirectConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_ictr_dou_v1(double(3.24));
  item = request.add_item_feature();
  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_ictr_dou_v1(double(1.71));
  item = request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(3, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(2).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr00 = map0.find("f15");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_EQUAL(1, itr00->second.float_list().value_size());
  TEST_EXPECT_EQUAL(3.24, itr00->second.float_list().value(0));

  const auto& map1 = ret.batch(1).context().feature();
  auto itr01 = map1.find("f15");

  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_EQUAL(1, itr01->second.float_list().value_size());
  TEST_EXPECT_EQUAL(1.71, itr01->second.float_list().value(0));

  const auto& map2 = ret.batch(2).context().feature();
  auto itr02 = map2.find("f15");

  TEST_ASSERT_BOOL(itr02 != map0.end());
  TEST_ASSERT_EQUAL(1, itr02->second.float_list().value_size());
  TEST_EXPECT_EQUAL(5.18, itr02->second.float_list().value(0));

  FUNC_TEST_END();
}

//测试pb中double类型数据及默认值，正确读取到featurelist中
void test_double_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "direct", 
          "source": [".user_action.pctr"]
      }
    },
    "default_values": {
        ".user_action.pctr": {
            "dtype": "float",
            "values": 5.18
        }
    }  
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DirectConfig* conf = dynamic_cast<DirectConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user_action
  qinglong::UserAction* user_action = request.add_user_action();
  user_action->set_pctr(double(3.24));
  user_action = request.add_user_action();
  user_action->set_pctr(double(5.24));
  user_action = request.add_user_action();
  user_action->set_pctr(double(4.24));
  user_action = request.add_user_action();

  //item不为0
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr00 = map0.find("f15");

  TEST_ASSERT_BOOL(itr00 != map0.end());

  TEST_ASSERT_EQUAL(4, itr00->second.feature_size());

  TEST_ASSERT_EQUAL(1, itr00->second.feature(0).float_list().value_size());
  TEST_EXPECT_EQUAL(3.24, itr00->second.feature(0).float_list().value(0));

  TEST_ASSERT_EQUAL(1, itr00->second.feature(1).float_list().value_size());
  TEST_EXPECT_EQUAL(5.24, itr00->second.feature(1).float_list().value(0));

  TEST_ASSERT_EQUAL(1, itr00->second.feature(2).float_list().value_size());
  TEST_EXPECT_EQUAL(4.24, itr00->second.feature(2).float_list().value(0));

  TEST_ASSERT_EQUAL(1, itr00->second.feature(3).float_list().value_size());
  TEST_EXPECT_EQUAL(5.18, itr00->second.feature(3).float_list().value(0));

  FUNC_TEST_END();
}

void test_select_config() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "expo_123_count", 
          "source": [".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
                      ".item_feature.item_feature_se.feature_lists.feature_list.list"]
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      },
      "f6": {
          "fe_type" : "vocab_list", 
          "source": [
              ".item_feature.item_feature_se.context.feature.item"
          ], 
          "vocabs" : ["0", "1", "2", "3", "4", "5"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f14": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        },
        "f15": {
            "dtype" : "int64",
            "shape" : [1, 3, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> all_vec;
  JsonConfigMgr::parse_from_string(str, all_vec);

  TEST_ASSERT_EQUAL(5, all_vec.size());

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_INT64, in_vec[0]->dtype);
  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(3, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  std::vector<std::shared_ptr<Config>> vec;
  selectConfigUsingModelInput(all_vec, in_vec, vec);

  TEST_ASSERT_EQUAL(4, vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::StringArray* pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900744462");
  pb_seq->add_value("900778570");
  pb_seq->add_value("104418979");

  pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("900242957");
  pb_seq->add_value("900242957");
  pb_seq->add_value("900242957");

  // item
  auto& map1 = *request.add_item_feature()->mutable_item_feature_se()->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = map1["list"];
  tensorflow::Feature* feat = list.add_feature();
  feat->mutable_bytes_list()->add_value("104418979");
  feat->mutable_bytes_list()->add_value("900744462");
  feat->mutable_bytes_list()->add_value("900242957");

  feat = list.add_feature();
  feat->mutable_bytes_list()->add_value("104418979");
  feat->mutable_bytes_list()->add_value("900242957");

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr01 = map.find("f13");
  auto itr_len01 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr01 != map.end());
  TEST_ASSERT_BOOL(itr_len01 != map.end());

  auto& tvalues01 = itr01->second;
  auto& tlen01 = itr_len01->second;

  TEST_ASSERT_EQUAL(6, tvalues01.int64_val_size());
  TEST_EXPECT_EQUAL(6, tvalues01.int64_val(0));
  TEST_EXPECT_EQUAL(6, tvalues01.int64_val(1));
  TEST_EXPECT_EQUAL(6, tvalues01.int64_val(2));

  TEST_EXPECT_EQUAL(6, tvalues01.int64_val(3));
  TEST_EXPECT_EQUAL(6, tvalues01.int64_val(4));
  TEST_EXPECT_EQUAL(0, tvalues01.int64_val(5));

  TEST_ASSERT_EQUAL(1, tlen01.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen01.int_val(0));

  auto itr02 = map.find("f14");
  auto itr_len02 = map.find("f14_length");

  TEST_ASSERT_BOOL(itr02 != map.end());
  TEST_ASSERT_BOOL(itr_len02 != map.end());

  auto& tvalues02 = itr02->second;
  auto& tlen02 = itr_len02->second;

  TEST_ASSERT_EQUAL(6, tvalues02.int64_val_size());
  TEST_EXPECT_EQUAL(2, tvalues02.int64_val(0));
  TEST_EXPECT_EQUAL(2, tvalues02.int64_val(1));
  TEST_EXPECT_EQUAL(4, tvalues02.int64_val(2));

  TEST_EXPECT_EQUAL(2, tvalues02.int64_val(3));
  TEST_EXPECT_EQUAL(4, tvalues02.int64_val(4));
  TEST_EXPECT_EQUAL(0, tvalues02.int64_val(5));

  TEST_ASSERT_EQUAL(1, tlen02.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen02.int_val(0));

  auto itr03 = map.find("f15");
  auto itr_len03 = map.find("f15_length");

  TEST_ASSERT_BOOL(itr03 != map.end());
  TEST_ASSERT_BOOL(itr_len03 != map.end());

  auto& tvalues03 = itr03->second;
  auto& tlen03 = itr_len03->second;

  TEST_ASSERT_EQUAL(6, tvalues03.int64_val_size());
  TEST_EXPECT_EQUAL(1, tvalues03.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues03.int64_val(1));
  TEST_EXPECT_EQUAL(3, tvalues03.int64_val(2));

  TEST_EXPECT_EQUAL(1, tvalues03.int64_val(3));
  TEST_EXPECT_EQUAL(3, tvalues03.int64_val(4));
  TEST_EXPECT_EQUAL(0, tvalues03.int64_val(5));

  TEST_ASSERT_EQUAL(1, tlen03.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen03.int_val(0));

  FUNC_TEST_END();  
}

void test_direct_to_feature() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f1" : {
          "fe_type" : "direct_to_feature", 
          "source": [".item_feature.item_feature_se.context.feature.appid"]
      },
      "f2": {
          "fe_type" : "direct_to_feature", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num"]
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(2, vec.size());

  TEST_ASSERT_BOOL(nullptr != vec[0]);
  DirectConfig* conf1 = dynamic_cast<DirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf1);

  TEST_ASSERT_BOOL(nullptr != vec[1]);
  ToFeatureConfig* conf2 = dynamic_cast<ToFeatureConfig*>(vec[1].get());
  TEST_ASSERT_BOOL(nullptr != conf2);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_num(0);
  pb_use->add_user_sequence()->set_num(1);
  pb_use->add_user_sequence()->set_num(2);
  pb_use->add_user_sequence()->set_num(3);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::Feature& input_f = (*(item->mutable_context()->mutable_feature()))["appid"];
  input_f.mutable_bytes_list()->add_value("900778570");
  input_f.mutable_bytes_list()->add_value("104436666");

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map = ret.batch(0).context().feature();

  auto itr01 = map.find("f1");

  TEST_ASSERT_BOOL(itr01 != map.end());
  TEST_ASSERT_EQUAL(2, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("900778570", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("104436666", itr01->second.bytes_list().value(1));

  auto itr02 = map.find("f2");

  TEST_ASSERT_BOOL(itr02 != map.end());
  TEST_ASSERT_EQUAL(4, itr02->second.int64_list().value_size());
  TEST_ASSERT_EQUAL(0, itr02->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr02->second.int64_list().value(1));
  TEST_ASSERT_EQUAL(2, itr02->second.int64_list().value(2));
  TEST_ASSERT_EQUAL(3, itr02->second.int64_list().value(3));

  FUNC_TEST_END();
}

void test_direct_to_feature_v2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="direct_to_feature_v2" source="E@.item_feature.item_feature_se.context.feature.num" data_type="int64" default_value="-1" />
            <feature name="f16" type="direct_to_feature_v2" source="E@.item_feature.item_feature_se.context.feature.query" data_type="string" default_value="NOT_EXIST" />
            <feature name="f17" type="direct_to_feature_v2" source="E@.item_feature.item_feature_se.context.feature.query" data_type="string" default_value="NOT_EXIST" strategy="empty" />
            <feature name="f18" type="direct_to_feature_v2" source="E@.item_feature.item_feature_se.context.feature.num" data_type="float" default_value="-1" />
            <feature name="f19" type="direct_to_feature_v2" source="E@.item_feature.item_feature_se.context.feature.query" data_type="float" default_value="-1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
        <input name="f16" shape="1" type="sparse" />
        <input name="f17" shape="1" type="sparse" />
        <input name="f18" shape="1" type="sparse" />
        <input name="f19" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(5, vec.size());
  DirectToFeatureV2Config* config = dynamic_cast<DirectToFeatureV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(5, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::Feature& input_f = (*(item->mutable_context()->mutable_feature()))["num"];
  input_f.mutable_int64_list()->add_value(3);

  tensorflow::Feature& input_q = (*(item->mutable_context()->mutable_feature()))["query"];
  input_q.mutable_bytes_list()->add_value("app");

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({3}), itr00->second);
  TEST_FEATURE_INT64(({-1}), itr10->second);

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_STR(({"app"}), itr01->second);
  TEST_FEATURE_STR(({"NOT_EXIST"}), itr11->second);

  auto itr02 = map00.find("f17");
  auto itr12 = map01.find("f17");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_STR(({"app"}), itr02->second);
  TEST_FEATURE_STR(({}), itr12->second);

  auto itr03 = map00.find("f18");
  auto itr13 = map01.find("f18");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());

  TEST_FEATURE_FLOAT(({3}), itr03->second);
  TEST_FEATURE_FLOAT(({-1}), itr13->second);

  auto itr04 = map00.find("f19");
  auto itr14 = map01.find("f19");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_ASSERT_BOOL(itr14 != map01.end());

  TEST_FEATURE_FLOAT(({-1}), itr04->second);
  TEST_FEATURE_FLOAT(({-1}), itr14->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({3, -1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f16_values");
  auto itr_indices1 = map.find("f16_indices");
  auto itr_dense_shape1 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), ({"app", "NOT_EXIST"}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f17_values");
  auto itr_indices2 = map.find("f17_indices");
  auto itr_dense_shape2 = map.find("f17_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({2, 1}), ({"app"}),
                            itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f18_values");
  auto itr_indices3 = map.find("f18_indices");
  auto itr_dense_shape3 = map.find("f18_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0}), ({2, 1}), ({3, -1}),
                            itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  auto itr_values4 = map.find("f19_values");
  auto itr_indices4 = map.find("f19_indices");
  auto itr_dense_shape4 = map.find("f19_dense_shape");
  TEST_ASSERT_BOOL(itr_values4 != map.end());
  TEST_ASSERT_BOOL(itr_indices4 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape4 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0}), ({2, 1}), ({-1, -1}),
                            itr_indices4->second, itr_dense_shape4->second, itr_values4->second);

  FUNC_TEST_END();
}

void display_tensor_proto(const std::string& title, const tensorflow::TensorProto& proto) {
  std::cout << title << " dtype:" << proto.dtype() << std::endl;

  switch(proto.dtype()) {
    case tensorflow::DT_FLOAT: {
        for (auto& d : proto.float_val()) {
          std::cout << d << std::endl;
        }
        break;
      }
      case tensorflow::DT_INT32: {
        for (auto& d : proto.int_val()) {
          std::cout << d << std::endl;
        }
        break;
      }
      case tensorflow::DT_INT64: {
        for (auto& d : proto.int64_val()) {
          std::cout << d << std::endl;
        }
        break;
      }
      case tensorflow::DT_STRING: {
        for (auto& d : proto.string_val()) {
          std::cout << d << std::endl;
        }
        break;
      }
      default: {
        std::cout << "unknown" << std::endl;
        break;
      }
  }
}

void test_decode_config() {
  FUNC_TEST_START();
  std::string config_base64_path = "/home/featureextractor/test/data/fe_config_base64.json";
  std::string config_base64_decode_path = "/home/featureextractor/test/data/fe_config_base64_decode.json";

  std::string config_base64_str = Calc::read_file_to_string(config_base64_path);
  std::string config_base64_decode_str = Calc::read_file_to_string(config_base64_decode_path);

  TEST_EXPECT_EQUAL(config_base64_decode_str, Decode::decode_file(config_base64_path));
  TEST_EXPECT_EQUAL(config_base64_decode_str, Decode::decode_string(config_base64_str));

  FUNC_TEST_END();
}

void test_merge() {
  FUNC_TEST_START();

  std::string str1 = R"({
    "extract_features" : {
    "f6": {
          "fe_type" : "nearest_expo_days", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ]
      },
    "f13": {
          "fe_type" : "vocab_list", 
          "source": [
              ".item_feature.item_feature_se.context.feature.item"
          ], 
          "vocabs" : ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
      },
    "f15" : {
          "fe_type" : "appid_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.context.feature.item"],
          "bucket_size" : 100
      }
    }
  })";

  std::string str2 = R"({
    "extract_features" : {
    "f6": {
          "fe_type" : "nearest_expo_days", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ]
      }
    }
  })";

  std::string str3 = R"({
    "extract_features" : {
    "f15" : {
          "fe_type" : "appid_cross", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.context.feature.item"],
          "bucket_size" : 100
      },
    "f13": {
          "fe_type" : "vocab_list", 
          "source": [
              ".item_feature.item_feature_se.context.feature.item"
          ], 
          "vocabs" : ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec1;
  std::vector<std::shared_ptr<Config>> vec2;
  std::vector<std::shared_ptr<Config>> vec3;
  JsonConfigMgr::parse_from_string(str1, vec1);
  JsonConfigMgr::parse_from_string(str2, vec2);
  JsonConfigMgr::parse_from_string(str3, vec3);

  TEST_ASSERT_EQUAL(3, vec1.size());
  TEST_ASSERT_EQUAL(1, vec2.size());
  TEST_ASSERT_EQUAL(2, vec3.size());

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret1;
  qinglong::BatchSequenceExample ret2;
  qinglong::BatchSequenceExample ret3;

  // 请求时间
  request.set_request_time((int64_t)100 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("900778570");
  pb_use->add_user_sequence()->set_app_id("104436666");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec1, ret1);
  toSequenceExample(&arena, request, vec2, ret2);
  toSequenceExample(&arena, request, vec3, ret3);

  TEST_ASSERT_EQUAL(1, ret1.batch_size());
  TEST_ASSERT_EQUAL(ret1.batch_size(), ret2.batch_size());
  TEST_ASSERT_EQUAL(ret1.batch_size(), ret3.batch_size());
  std::cout << "ret1.batch(0).context().feature().size():" << ret1.batch(0).context().feature().size() << std::endl;
  std::cout << "ret2.batch(0).context().feature().size():" << ret2.batch(0).context().feature().size() << std::endl;
  std::cout << "ret3.batch(0).context().feature().size():" << ret3.batch(0).context().feature().size() << std::endl;

  std::cout << "ret1.batch(0).feature_lists().feature_list().size():" << ret1.batch(0).feature_lists().feature_list().size() << std::endl;
  std::cout << "ret2.batch(0).feature_lists().feature_list().size():" << ret2.batch(0).feature_lists().feature_list().size() << std::endl;
  std::cout << "ret3.batch(0).feature_lists().feature_list().size():" << ret3.batch(0).feature_lists().feature_list().size() << std::endl;
  TEST_EXPECT_EQUAL(ret1.batch(0).feature_lists().feature_list().size(), ret2.batch(0).feature_lists().feature_list().size() + ret3.batch(0).feature_lists().feature_list().size());

  auto& map1 = ret1.batch(0).context().feature();
  auto itr1_f6 = map1.find("f6");
  TEST_ASSERT_BOOL(itr1_f6 != map1.end());
  auto itr1_f13 = map1.find("f13");
  TEST_ASSERT_BOOL(itr1_f13 != map1.end());

  auto& map2 = ret2.batch(0).context().feature();
  auto itr2_f6 = map2.find("f6");
  TEST_ASSERT_BOOL(itr2_f6 != map2.end());

  bool com = google::protobuf::util::MessageDifferencer::Equals(itr1_f6->second, itr2_f6->second);
  TEST_EXPECT_BOOL(com);

  auto& map3 = ret3.batch(0).context().feature();
  auto itr3_f13 = map3.find("f13");
  TEST_ASSERT_BOOL(itr3_f13 != map3.end());

  com = google::protobuf::util::MessageDifferencer::Equals(itr1_f13->second, itr3_f13->second);
  TEST_EXPECT_BOOL(com);

  TEST_EXPECT_BOOL(google::protobuf::util::MessageDifferencer::Equals(ret1.batch(0).feature_lists(), ret3.batch(0).feature_lists()));

  FUNC_TEST_END();
}

void test_xml() {
  FUNC_TEST_START();

  std::string xml_str = R"(
    <config>
        <source name="user_am_clk" value=".user_feature.am_gm_clk_off.am_clk_off.user_sequence" />
        <source name="user_yoyo" value=".user_feature.yoyo_imp_off.yoyo_recommend_expo_appid_seq_7d" />
        <source name="user_feature_list" value=".user_feature.user_feature_se.feature_lists.feature_list" />
        <source name="item_feature_list" value=".item_feature.item_feature_se.feature_lists.feature_list" />
        <source name="item_feature_con" value=".item_feature.item_feature_se.context.feature" />

        <features>
            <feature name="f0" type="bucketize" source="user_am_clk.num" boundary="0.09,1.01,2.56" />
            <feature name="f1" type="hash" source="user_yoyo.value" bucket_size="1000" concat_with_name="true" />
            <feature name="f2" type="vocab_list" source="item_feature_list.default" vocabs="NOT_EXIST,1,2,3,4,5,6,7,8,9" />
            <feature name="f3" type="vocab_set" source=".user_action.item_id.app_id" dict="app0,app1,app2,app3,app4,app5,app6" />
            <feature name="f4" type="direct" source="item_feature_con.direct" />
            <feature name="f5" type="filter_appid" source="user_am_clk.app_id,user_am_clk.event_time,.request_time" days="1,3,10" max_len="100" />
            <feature name="f6" type="direct" source="f5:0" />
            <feature name="f7" type="direct" source="f5:1" />
            <feature name="f8" type="direct" source="f5:2" />
            <feature name="f9" type="max_expo_appid" source="user_am_clk.app_id" />
            <feature name="f10" type="max_123_class" source="user_am_clk.app_id" />
            <feature name="f11" type="direct" source="f10:0" />
            <feature name="f12" type="direct" source="f10:1" />
            <feature name="f13" type="direct" source="f10:2" />
            <feature name="f14" type="nearest_expo_appid" source="user_am_clk.app_id" />
            <feature name="f15" type="expo_appid_count" source="user_am_clk.app_id,item_feature_con.app_id" />
            <feature name="f16" type="expo_appid_count_v2" source="user_am_clk.app_id,item_feature_con.app_id" />
            <feature name="f17" type="direct" source="f16:0" />
            <feature name="f18" type="direct" source="f16:1" />
            <feature name="f19" type="expo_123_count" source="user_am_clk.app_id,item_feature_con.app_id" />
            <feature name="f20" type="direct" source="f19:0" />
            <feature name="f21" type="direct" source="f19:1" />
            <feature name="f22" type="direct" source="f19:2" />
            <feature name="f23" type="expo_123_count_v2" source="user_am_clk.app_id,item_feature_con.app_id" />
            <feature name="f24" type="direct" source="f23:0" />
            <feature name="f25" type="direct" source="f23:1" />
            <feature name="f26" type="direct" source="f23:2" />
            <feature name="f27" type="direct" source="f23:3" />
            <feature name="f28" type="direct" source="f23:4" />
            <feature name="f29" type="direct" source="f23:5" />
            <feature name="f30" type="nearest_expo_days" source="user_am_clk.app_id,user_am_clk.event_time,.request_time,item_feature_con.app_id" />
            <feature name="f31" type="appid_cross" source="user_am_clk.app_id,item_feature_con.app_id" bucket_size="100" />
            <feature name="f32" type="to_feature" source="user_am_clk.num" />
            <feature name="f33" type="to_batch_feature" source="user_feature_list.batch" />
            <feature name="f34" type="identity" source="item_feature_con.num" max_value="5" default_value="2" />
            <feature name="f35" type="string_to_int64" source="item_feature_con.time" default_value="1700000000000" />
            <feature name="f36" type="appid_to_123_class" source="user_am_clk.app_id" class_type="0" default_value="test_no_data" />
            <feature name="f37" type="appid_to_123_class" source="user_am_clk.app_id" class_type="1" default_value="test_no_data" />
            <feature name="f38" type="appid_to_123_class" source="user_am_clk.app_id" class_type="2" default_value="test_no_data" />
            <feature name="f39" type="trans_type" source="item_feature_con.app_id" data_type="string" default_value="-20" />
            <feature name="f40" type="trans_type" source="item_feature_con.app_id" data_type="float" default_value="-20" />
            <feature name="f41" type="trans_type" source="item_feature_con.app_id" data_type="int64" default_value="-20" />
            <feature name="f42" type="trans_type" source="item_feature_con.num" data_type="string" default_value="-20" />
            <feature name="f43" type="trans_type" source="item_feature_con.num" data_type="float" default_value="-20" />
            <feature name="f44" type="trans_type" source="item_feature_con.num" data_type="int64" default_value="-20" />
            <feature name="f45" type="fully_cross" source="user_am_clk.app_id,item_feature_con.app_id" connector="_" default_value="test_no_date" />
            <feature name="f46" type="connect" source="user_am_clk.app_id,user_am_clk.num" connector="#" tail="click" />
            <feature name="f47" type="get_valid_value" source=".callback_req_ts,.request_time" />
            <feature name="f48" type="int64_offset" source="user_am_clk.num" offset="5" />
            <feature name="f49" type="int64_difference" source=".request_time,user_am_clk.event_time" />
            <feature name="f50" type="clip" source="item_feature_con.num" start="1" size="2" />
            <feature name="f51" type="seq_topn" source="user_am_clk.app_id,user_am_clk.event_time,.request_time" start="60" topn="3" top_type="2" default_value="no_date" />
            <feature name="f52" type="seq_filter" source="user_am_clk.app_id,user_am_clk.event_time,user_am_clk.use_duration,.request_time,user_am_clk.first_intent_type,user_am_clk.second_intent_type,user_am_clk.third_intent_type" start="86400" day_n="30" clip_size="2" default_value="no_date" filter="100;18,101;20,102" />
            <feature name="f53" type="direct" source="f52:0" />
            <feature name="f54" type="direct" source="f52:1" />
            <feature name="f55" type="direct" source="f52:2" />
            <feature name="f56" type="time_holiday_scope" source="item_feature_list.time" holiday_boundary="2023:4,29,5,3,6,22,6,24,9,30,10,6;2024:5,1,5,5,6,8,6,10,10,1,10,7" name_boundary="劳动节,端午节,国庆节" default_value="非假期日" />
            <feature name="f57" type="seq_num_convert" source="user_am_clk.app_id" count_type="1" />
            <feature name="f58" type="direct" source="f57:0" />
            <feature name="f59" type="direct" source="f57:1" />
            <feature name="f60" type="utf8_distance" source="item_feature_con.direct,item_feature_con.app_id" strategy="empty,feature" />
        </features>

        <default_values>
            <default_value source="item_feature_list.default" dtype="string" values="9,81" />
        </default_values>
    </config>

    <item_map>104435568,母婴,健康育儿,母婴健康;900778570,工具,生活工具,日历;104430325,社交,聊天交友,匿名/陌生人;900834783,默认值,默认值,默认值;220738225,默认值,默认值,默认值;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店</item_map>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f0" shape="1,1,3" type="sequence" />
        <input name="f1" shape="1,2,3" type="sequence" />
        <input name="f2" shape="1,1,3" type="sequence" />
        <input name="f3" shape="1,1,3" type="sequence" />
        <input name="f4" shape="2" type="dense" />
        <input name="f6" shape="1,1,3" type="sequence" />
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1" type="dense" />
        <input name="f11" shape="1" type="dense" />
        <input name="f12" shape="1" type="dense" />
        <input name="f13" shape="1" type="dense" />
        <input name="f14" shape="1" type="dense" />
        <input name="f15" shape="2" type="dense" />
        <input name="f17" shape="2" type="dense" />
        <input name="f18" shape="2" type="dense" />
        <input name="f20" shape="2" type="dense" />
        <input name="f21" shape="2" type="dense" />
        <input name="f22" shape="2" type="dense" />
        <input name="f24" shape="2" type="dense" />
        <input name="f25" shape="2" type="dense" />
        <input name="f26" shape="2" type="dense" />
        <input name="f27" shape="2" type="dense" />
        <input name="f28" shape="2" type="dense" />
        <input name="f29" shape="2" type="dense" />
        <input name="f30" shape="2" type="dense" />
        <input name="f31" shape="1,1,3" type="sequence" />
        <input name="f32" shape="4" type="dense" />
        <input name="f33" shape="1" type="dense" />
        <input name="f34" shape="5" type="dense" />
        <input name="f35" shape="2" type="dense" />
        <input name="f36" shape="1,1,3" type="sequence" />
        <input name="f37" shape="1,1,3" type="sequence" />
        <input name="f38" shape="1,1,3" type="sequence" />
        <input name="f39" shape="2" type="dense" />
        <input name="f40" shape="2" type="dense" />
        <input name="f41" shape="2" type="dense" />
        <input name="f42" shape="5" type="dense" />
        <input name="f43" shape="5" type="dense" />
        <input name="f44" shape="5" type="dense" />
        <input name="f45" shape="1" type="sparse" />
        <input name="f46" shape="1,1,3" type="sequence" />
        <input name="f47" shape="1" type="sparse" />
        <input name="f48" shape="1,1,3" type="sequence" />
        <input name="f49" shape="1,1,3" type="sequence" />
        <input name="f50" shape="2" type="dense" />
        <input name="f51" shape="1,1,3" type="sequence" />
        <input name="f53" shape="1,1,3" type="sequence" />
        <input name="f54" shape="1,1,3" type="sequence" />
        <input name="f55" shape="1,1,3" type="sequence" />
        <input name="f56" shape="1,3,3" type="sequence" />
        <input name="f58" shape="1,1,3" type="sequence" />
        <input name="f59" shape="1,1,3" type="sequence" />
        <input name="f60" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(xml_str, "", "", vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  // 请求时间
  request.set_request_time((int64_t)100 * 86400 * 1000);

  // user clk
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();

  pb_info->set_num(0);
  pb_info->set_app_id("104435568"); // diff 5
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info->set_use_duration(10);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("102");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_num(1);
  pb_info->set_app_id("104430325"); // diff 1
  pb_info->set_event_time((int64_t)99 * 86400 * 1000);
  pb_info->set_use_duration(10);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("102");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_num(2);
  pb_info->set_app_id("900778570"); // diff 7
  pb_info->set_event_time((int64_t)93 * 86400 * 1000);
  pb_info->set_use_duration(10);
  pb_info->set_first_intent_type("5");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("102");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_num(3);
  pb_info->set_app_id("900778570"); // diff 7
  pb_info->set_event_time((int64_t)20 * 86400 * 1000);
  pb_info->set_use_duration(10);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("102");

  // user yoyo
  qinglong::DwsAiYoyoRecommendExpoOfflineEventIncD* pb_yoyo = pb_ufv2->mutable_yoyo_imp_off();
  qinglong::StringArray* pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("name123");
  pb_str->add_value("name456");
  pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("name789");
  // user action
  qinglong::UserAction* user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app0");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app5");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app2");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app9");
  //user context
  tensorflow::SequenceExample* user_feature_se = request.mutable_user_feature()->mutable_user_feature_se();
  auto& user_list_map = *user_feature_se->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = user_list_map["batch"];
  tensorflow::Feature* feat = list.add_feature();
  feat->mutable_int64_list()->add_value(10);

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* item_se = item->mutable_item_feature_se();
  tensorflow::Feature& input_f = (*(item_se->mutable_context()->mutable_feature()))["direct"];
  input_f.mutable_bytes_list()->add_value("direct0");
  input_f.mutable_bytes_list()->add_value("direct1");
  tensorflow::Feature& input_f2 = (*(item_se->mutable_context()->mutable_feature()))["app_id"];
  input_f2.mutable_bytes_list()->add_value("900778570");
  input_f2.mutable_bytes_list()->add_value("104435568");
  tensorflow::Feature& input_f3 = (*(item_se->mutable_context()->mutable_feature()))["num"];
  input_f3.mutable_int64_list()->add_value(1);
  input_f3.mutable_int64_list()->add_value(3);
  input_f3.mutable_int64_list()->add_value(5);
  input_f3.mutable_int64_list()->add_value(7);
  input_f3.mutable_int64_list()->add_value(-1);
  tensorflow::Feature& input_f4 = (*(item_se->mutable_context()->mutable_feature()))["time"];
  input_f4.mutable_bytes_list()->add_value("1727580548000");
  input_f4.mutable_bytes_list()->add_value("");

  auto& feat_list = (*(item_se->mutable_feature_lists()->mutable_feature_list()))["time"];
  feat = feat_list.add_feature();
  feat->mutable_int64_list()->add_value((int64_t)1717831143 * 1000);
  feat->mutable_int64_list()->add_value((int64_t)1719026948 * 1000);
  feat = feat_list.add_feature();
  feat->mutable_int64_list()->add_value((int64_t)1714865919 * 1000);
  feat->mutable_int64_list()->add_value((int64_t)1728287312 * 1000);
  feat->mutable_int64_list()->add_value((int64_t)1683195118 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).context().feature();
  const auto& list_map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = list_map0.find("f0");
  TEST_ASSERT_BOOL(itr00 != list_map0.end());
  TEST_FEATURE_LIST_INT64(({{0}, {1}, {2}, {3}}), itr00->second);

  auto itr01 = list_map0.find("f1");
  TEST_ASSERT_BOOL(itr01 != list_map0.end());
  TEST_FEATURE_LIST_INT64(({{828, 503}, {422}}), itr01->second);

  auto itr02 = list_map0.find("f2");
  TEST_ASSERT_BOOL(itr02 != list_map0.end());
  TEST_FEATURE_LIST_INT64(({{9}, {0}}), itr02->second);

  auto itr03 = list_map0.find("f3");
  TEST_ASSERT_BOOL(itr03 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"app0"}, {"app5"}, {"app2"}, {""}}), itr03->second);

  auto itr04 = map0.find("f4");
  TEST_ASSERT_BOOL(itr04 != map0.end());
  TEST_FEATURE_STR(({"direct0", "direct1"}), itr04->second);

  auto itr06 = list_map0.find("f6");
  TEST_ASSERT_BOOL(itr06 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"NOT_EXIST"}}), itr06->second);

  auto itr07 = list_map0.find("f7");
  TEST_ASSERT_BOOL(itr07 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"104430325"}}), itr07->second);

  auto itr08 = list_map0.find("f8");
  TEST_ASSERT_BOOL(itr08 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"900778570"}, {"104435568"}, {"104430325"}}), itr08->second);

  auto itr09 = map0.find("f9");
  TEST_ASSERT_BOOL(itr09 != map0.end());
  TEST_FEATURE_STR(({"900778570"}), itr09->second);

  auto itr11 = map0.find("f11");
  TEST_ASSERT_BOOL(itr11 != map0.end());
  TEST_FEATURE_STR(({"工具"}), itr11->second);

  auto itr12 = map0.find("f12");
  TEST_ASSERT_BOOL(itr12 != map0.end());
  TEST_FEATURE_STR(({"生活工具"}), itr12->second);

  auto itr13 = map0.find("f13");
  TEST_ASSERT_BOOL(itr13 != map0.end());
  TEST_FEATURE_STR(({"日历"}), itr13->second);

  auto itr14 = map0.find("f14");
  TEST_ASSERT_BOOL(itr14 != map0.end());
  TEST_FEATURE_STR(({"900778570"}), itr14->second);

  auto itr15 = map0.find("f15");
  TEST_ASSERT_BOOL(itr15 != map0.end());
  TEST_FEATURE_INT64(({2, 1}), itr15->second);

  auto itr17 = map0.find("f17");
  TEST_ASSERT_BOOL(itr17 != map0.end());
  TEST_FEATURE_INT64(({1, 1}), itr17->second);

  auto itr18 = map0.find("f18");
  TEST_ASSERT_BOOL(itr18 != map0.end());
  TEST_FEATURE_INT64(({2, 1}), itr18->second);

  auto itr20 = map0.find("f20");
  TEST_ASSERT_BOOL(itr20 != map0.end());
  TEST_FEATURE_INT64(({2, 1}), itr20->second);

  auto itr21 = map0.find("f21");
  TEST_ASSERT_BOOL(itr21 != map0.end());
  TEST_FEATURE_INT64(({2, 1}), itr21->second);

  auto itr22 = map0.find("f22");
  TEST_ASSERT_BOOL(itr22 != map0.end());
  TEST_FEATURE_INT64(({2, 1}), itr22->second);

  auto itr24 = map0.find("f24");
  TEST_ASSERT_BOOL(itr24 != map0.end());
  TEST_FEATURE_INT64(({1, 1}), itr24->second);

  auto itr25 = map0.find("f25");
  TEST_ASSERT_BOOL(itr25 != map0.end());
  TEST_FEATURE_INT64(({2, 1}), itr25->second);

  auto itr26 = map0.find("f26");
  TEST_ASSERT_BOOL(itr26 != map0.end());
  TEST_FEATURE_INT64(({1, 1}), itr26->second);

  auto itr27 = map0.find("f27");
  TEST_ASSERT_BOOL(itr27 != map0.end());
  TEST_FEATURE_INT64(({2, 1}), itr27->second);

  auto itr28 = map0.find("f28");
  TEST_ASSERT_BOOL(itr28 != map0.end());
  TEST_FEATURE_INT64(({1, 1}), itr28->second);

  auto itr29 = map0.find("f29");
  TEST_ASSERT_BOOL(itr29 != map0.end());
  TEST_FEATURE_INT64(({2, 1}), itr29->second);

  auto itr30 = map0.find("f30");
  TEST_ASSERT_BOOL(itr30 != map0.end());
  TEST_FEATURE_INT64(({4, 3}), itr30->second);

  auto itr31 = list_map0.find("f31");
  TEST_ASSERT_BOOL(itr31 != list_map0.end());
  TEST_FEATURE_LIST_INT64(({{4}, {48}, {88}, {88}}), itr31->second);

  auto itr32 = map0.find("f32");
  TEST_ASSERT_BOOL(itr32 != map0.end());
  TEST_FEATURE_INT64(({0, 1, 2, 3}), itr32->second);

  auto itr33 = map0.find("f33");
  TEST_ASSERT_BOOL(itr33 != map0.end());
  TEST_FEATURE_INT64(({10}), itr33->second);

  auto itr34 = map0.find("f34");
  TEST_ASSERT_BOOL(itr34 != map0.end());
  TEST_FEATURE_INT64(({1, 3, 5, 2, 2}), itr34->second);

  auto itr35 = map0.find("f35");
  TEST_ASSERT_BOOL(itr35 != map0.end());
  TEST_FEATURE_INT64(({(int64_t)1727580548000, (int64_t)1700000000000}), itr35->second);

  auto itr36 = list_map0.find("f36");
  TEST_ASSERT_BOOL(itr36 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"母婴"}, {"社交"}, {"工具"}, {"工具"}}), itr36->second);

  auto itr37 = list_map0.find("f37");
  TEST_ASSERT_BOOL(itr37 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"健康育儿"}, {"聊天交友"}, {"生活工具"}, {"生活工具"}}), itr37->second);

  auto itr38 = list_map0.find("f38");
  TEST_ASSERT_BOOL(itr38 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"母婴健康"}, {"匿名/陌生人"}, {"日历"}, {"日历"}}), itr38->second);

  auto itr39 = map0.find("f39");
  TEST_ASSERT_BOOL(itr39 != map0.end());
  TEST_FEATURE_STR(({"900778570", "104435568"}), itr39->second);

  auto itr40 = map0.find("f40");
  TEST_ASSERT_BOOL(itr40 != map0.end());
  TEST_FEATURE_FLOAT(({(float)900778570, (float)104435568}), itr40->second);

  auto itr41 = map0.find("f41");
  TEST_ASSERT_BOOL(itr41 != map0.end());
  TEST_FEATURE_INT64(({900778570, 104435568}), itr41->second);

  auto itr42 = map0.find("f42");
  TEST_ASSERT_BOOL(itr42 != map0.end());
  TEST_FEATURE_STR(({"1", "3", "5", "7", "-1"}), itr42->second);

  auto itr43 = map0.find("f43");
  TEST_ASSERT_BOOL(itr43 != map0.end());
  TEST_FEATURE_FLOAT(({1, 3, 5, 7, -1}), itr43->second);

  auto itr44 = map0.find("f44");
  TEST_ASSERT_BOOL(itr44 != map0.end());
  TEST_FEATURE_INT64(({1, 3, 5, 7, -1}), itr44->second);

  auto itr45 = map0.find("f45");
  TEST_ASSERT_BOOL(itr45 != map0.end());
  TEST_FEATURE_STR(({"104435568_900778570", "104430325_900778570", "900778570_900778570", "900778570_900778570",
                      "104435568_104435568", "104430325_104435568", "900778570_104435568", "900778570_104435568"}), itr45->second);

  auto itr46 = list_map0.find("f46");
  TEST_ASSERT_BOOL(itr46 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"104435568#0#click"}, {"104430325#1#click"}, {"900778570#2#click"}, {"900778570#3#click"}}), itr46->second);

  auto itr47 = map0.find("f47");
  TEST_ASSERT_BOOL(itr47 != map0.end());
  TEST_FEATURE_INT64(({8640000000}), itr47->second);

  auto itr48 = list_map0.find("f48");
  TEST_ASSERT_BOOL(itr48 != list_map0.end());
  TEST_FEATURE_LIST_INT64(({{5}, {6}, {7}, {8}}), itr48->second);

  auto itr49 = list_map0.find("f49");
  TEST_ASSERT_BOOL(itr49 != list_map0.end());
  TEST_FEATURE_LIST_INT64(({{432000000}, {86400000}, {604800000}, {6912000000}}), itr49->second);

  auto itr50 = map0.find("f50");
  TEST_ASSERT_BOOL(itr50 != map0.end());
  TEST_FEATURE_INT64(({3, 5}), itr50->second);

  auto itr51 = list_map0.find("f51");
  TEST_ASSERT_BOOL(itr51 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"104430325"}, {"104435568"}, {"900778570"}}), itr51->second);

  auto itr53 = list_map0.find("f53");
  TEST_ASSERT_BOOL(itr53 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"104435568"}}), itr53->second);

  auto itr54 = list_map0.find("f54");
  TEST_ASSERT_BOOL(itr54 != list_map0.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)95 * 86400 * 1000}}), itr54->second);

  auto itr55 = list_map0.find("f55");
  TEST_ASSERT_BOOL(itr55 != list_map0.end());
  TEST_FEATURE_LIST_INT64(({{10}}), itr55->second);

  auto itr56 = list_map0.find("f56");
  TEST_ASSERT_BOOL(itr56 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"端午节", "非假期日"}, {"劳动节", "国庆节", "非假期日"}}), itr56->second);

  auto itr58 = list_map0.find("f58");
  TEST_ASSERT_BOOL(itr58 != list_map0.end());
  TEST_FEATURE_LIST_STR(({{"104430325"}, {"104435568"}, {"900778570"}}), itr58->second);

  auto itr59 = list_map0.find("f59");
  TEST_ASSERT_BOOL(itr59 != list_map0.end());
  TEST_FEATURE_LIST_INT64(({{25}, {25}, {50}}), itr59->second);

  auto itr60 = map0.find("f60");
  TEST_ASSERT_BOOL(itr60 != map0.end());
  TEST_FEATURE_INT64(({8, 9}), itr60->second);

  std::vector<std::shared_ptr<Config>> need_vec;

  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto pre_itr00 = map.find("f0");
  auto itr_len00 = map.find("f0_length");
  TEST_ASSERT_BOOL(pre_itr00 != map.end());
  TEST_ASSERT_BOOL(itr_len00 != map.end());
  TEST_LIST_INT64(({0, 1, 2, 3}), pre_itr00->second);
  TEST_LIST_INT32(({4}), itr_len00->second);

  auto pre_itr01 = map.find("f1");
  auto itr_len01 = map.find("f1_length");
  TEST_ASSERT_BOOL(pre_itr01 != map.end());
  TEST_ASSERT_BOOL(itr_len01 != map.end());
  TEST_LIST_INT64(({828, 503, 422, 0}), pre_itr01->second);
  TEST_LIST_INT32(({2}), itr_len01->second);

  auto pre_itr02 = map.find("f2");
  auto itr_len02 = map.find("f2_length");
  TEST_ASSERT_BOOL(pre_itr02 != map.end());
  TEST_ASSERT_BOOL(itr_len02 != map.end());
  TEST_LIST_INT64(({9, 0}), pre_itr02->second);
  TEST_LIST_INT32(({2}), itr_len02->second);

  auto pre_itr03 = map.find("f3");
  auto itr_len03 = map.find("f3_length");
  TEST_ASSERT_BOOL(pre_itr03 != map.end());
  TEST_ASSERT_BOOL(itr_len03 != map.end());
  TEST_LIST_STRING(({"app0", "app5", "app2", ""}), pre_itr03->second);
  TEST_LIST_INT32(({4}), itr_len03->second);

  auto pre_itr04 = map.find("f4");
  TEST_ASSERT_BOOL(pre_itr04 != map.end());
  TEST_ASSERT_EQUAL(2, pre_itr04->second.string_val_size());
  TEST_LIST_STRING(({"direct0", "direct1"}), pre_itr04->second);

  auto pre_itr06 = map.find("f6");
  auto itr_len06 = map.find("f6_length");
  TEST_ASSERT_BOOL(pre_itr06 != map.end());
  TEST_ASSERT_BOOL(itr_len06 != map.end());
  TEST_LIST_STRING(({"NOT_EXIST"}), pre_itr06->second);
  TEST_LIST_INT32(({1}), itr_len06->second);

  auto pre_itr07 = map.find("f7");
  auto itr_len07 = map.find("f7_length");
  TEST_ASSERT_BOOL(pre_itr07 != map.end());
  TEST_ASSERT_BOOL(itr_len07 != map.end());
  TEST_LIST_STRING(({"104430325"}), pre_itr07->second);
  TEST_LIST_INT32(({1}), itr_len07->second);

  auto pre_itr08 = map.find("f8");
  auto itr_len08 = map.find("f8_length");
  TEST_ASSERT_BOOL(pre_itr08 != map.end());
  TEST_ASSERT_BOOL(itr_len08 != map.end());
  TEST_LIST_STRING(({"900778570", "104435568", "104430325"}), pre_itr08->second);
  TEST_LIST_INT32(({3}), itr_len08->second);

  auto pre_itr09 = map.find("f9");
  TEST_ASSERT_BOOL(pre_itr09 != map.end());
  TEST_LIST_STRING(({"900778570"}), pre_itr09->second);

  auto pre_itr11 = map.find("f11");
  TEST_ASSERT_BOOL(pre_itr11 != map.end());
  TEST_LIST_STRING(({"工具"}), pre_itr11->second);

  auto pre_itr12 = map.find("f12");
  TEST_ASSERT_BOOL(pre_itr12 != map.end());
  TEST_LIST_STRING(({"生活工具"}), pre_itr12->second);

  auto pre_itr13 = map.find("f13");
  TEST_ASSERT_BOOL(pre_itr13 != map.end());
  TEST_LIST_STRING(({"日历"}), pre_itr13->second);

  auto pre_itr14 = map.find("f14");
  TEST_ASSERT_BOOL(pre_itr14 != map.end());
  TEST_LIST_STRING(({"900778570"}), pre_itr14->second);

  auto pre_itr15 = map.find("f15");
  TEST_ASSERT_BOOL(pre_itr15 != map.end());
  TEST_LIST_INT64(({2, 1}), pre_itr15->second);

  auto pre_itr17 = map.find("f17");
  TEST_ASSERT_BOOL(pre_itr17 != map.end());
  TEST_LIST_INT64(({1, 1}), pre_itr17->second);

  auto pre_itr18 = map.find("f18");
  TEST_ASSERT_BOOL(pre_itr18 != map.end());
  TEST_LIST_INT64(({2, 1}), pre_itr18->second);

  auto pre_itr20 = map.find("f20");
  TEST_ASSERT_BOOL(pre_itr20 != map.end());
  TEST_LIST_INT64(({2, 1}), pre_itr20->second);

  auto pre_itr21 = map.find("f21");
  TEST_ASSERT_BOOL(pre_itr21 != map.end());
  TEST_LIST_INT64(({2, 1}), pre_itr21->second);

  auto pre_itr22 = map.find("f22");
  TEST_ASSERT_BOOL(pre_itr22 != map.end());
  TEST_LIST_INT64(({2, 1}), pre_itr22->second);

  auto pre_itr24 = map.find("f24");
  TEST_ASSERT_BOOL(pre_itr24 != map.end());
  TEST_LIST_INT64(({1, 1}), pre_itr24->second);

  auto pre_itr25 = map.find("f25");
  TEST_ASSERT_BOOL(pre_itr25 != map.end());
  TEST_LIST_INT64(({2, 1}), pre_itr25->second);

  auto pre_itr26 = map.find("f26");
  TEST_ASSERT_BOOL(pre_itr26 != map.end());
  TEST_LIST_INT64(({1, 1}), pre_itr26->second);

  auto pre_itr27 = map.find("f27");
  TEST_ASSERT_BOOL(pre_itr27 != map.end());
  TEST_LIST_INT64(({2, 1}), pre_itr27->second);

  auto pre_itr28 = map.find("f28");
  TEST_ASSERT_BOOL(pre_itr28 != map.end());
  TEST_LIST_INT64(({1, 1}), pre_itr28->second);

  auto pre_itr29 = map.find("f29");
  TEST_ASSERT_BOOL(pre_itr29 != map.end());
  TEST_LIST_INT64(({2, 1}), pre_itr29->second);

  auto pre_itr30 = map.find("f30");
  TEST_ASSERT_BOOL(pre_itr30 != map.end());
  TEST_LIST_INT64(({4, 3}), pre_itr30->second);

  auto pre_itr31 = map.find("f31");
  auto itr_len31 = map.find("f31_length");
  TEST_ASSERT_BOOL(pre_itr31 != map.end());
  TEST_ASSERT_BOOL(itr_len31 != map.end());
  TEST_LIST_INT64(({4, 48, 88, 88}), pre_itr31->second);
  TEST_LIST_INT32(({4}), itr_len31->second);

  auto pre_itr32 = map.find("f32");
  TEST_ASSERT_BOOL(pre_itr32 != map.end());
  TEST_LIST_INT64(({0, 1, 2, 3}), pre_itr32->second);

  auto pre_itr33 = map.find("f33");
  TEST_ASSERT_BOOL(pre_itr33 != map.end());
  TEST_LIST_INT64(({10}), pre_itr33->second);

  auto pre_itr34 = map.find("f34");
  TEST_ASSERT_BOOL(pre_itr34 != map.end());
  TEST_LIST_INT64(({1, 3, 5, 2, 2}), pre_itr34->second);

  auto pre_itr35 = map.find("f35");
  TEST_ASSERT_BOOL(pre_itr35 != map.end());
  TEST_LIST_INT64(({(int64_t)1727580548000, (int64_t)1700000000000}), pre_itr35->second);

  auto pre_itr36 = map.find("f36");
  auto itr_len36 = map.find("f36_length");
  TEST_ASSERT_BOOL(pre_itr36 != map.end());
  TEST_ASSERT_BOOL(itr_len36 != map.end());
  TEST_LIST_STRING(({"母婴", "社交", "工具", "工具"}), pre_itr36->second);
  TEST_LIST_INT32(({4}), itr_len36->second);

  auto pre_itr37 = map.find("f37");
  auto itr_len37 = map.find("f37_length");
  TEST_ASSERT_BOOL(pre_itr37 != map.end());
  TEST_ASSERT_BOOL(itr_len37 != map.end());
  TEST_LIST_STRING(({"健康育儿", "聊天交友", "生活工具", "生活工具"}), pre_itr37->second);
  TEST_LIST_INT32(({4}), itr_len37->second);

  auto pre_itr38 = map.find("f38");
  auto itr_len38 = map.find("f38_length");
  TEST_ASSERT_BOOL(pre_itr38 != map.end());
  TEST_ASSERT_BOOL(itr_len38 != map.end());
  TEST_LIST_STRING(({"母婴健康", "匿名/陌生人", "日历", "日历"}), pre_itr38->second);
  TEST_LIST_INT32(({4}), itr_len38->second);

  auto pre_itr39 = map.find("f39");
  TEST_ASSERT_BOOL(pre_itr39 != map.end());
  TEST_LIST_STRING(({"900778570", "104435568"}), pre_itr39->second);

  auto pre_itr40 = map.find("f40");
  TEST_ASSERT_BOOL(pre_itr40 != map.end());
  TEST_LIST_FLOAT(({(float)900778570, (float)104435568}), pre_itr40->second);

  auto pre_itr41 = map.find("f41");
  TEST_ASSERT_BOOL(pre_itr41 != map.end());
  TEST_LIST_INT64(({900778570, 104435568}), pre_itr41->second);

  auto pre_itr42 = map.find("f42");
  TEST_ASSERT_BOOL(pre_itr42 != map.end());
  TEST_LIST_STRING(({"1", "3", "5", "7", "-1"}), pre_itr42->second);

  auto pre_itr43 = map.find("f43");
  TEST_ASSERT_BOOL(pre_itr43 != map.end());
  TEST_LIST_FLOAT(({1, 3, 5, 7, -1}), pre_itr43->second);

  auto pre_itr44 = map.find("f44");
  TEST_ASSERT_BOOL(pre_itr44 != map.end());
  TEST_LIST_INT64(({1, 3, 5, 7, -1}), pre_itr44->second);

  auto itr_values45 = map.find("f45_values");
  auto itr_indices45 = map.find("f45_indices");
  auto itr_dense_shape45 = map.find("f45_dense_shape");
  TEST_ASSERT_BOOL(itr_values45 != map.end());
  TEST_ASSERT_BOOL(itr_indices45 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape45 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0,5 ,0,6,0,7}), ({1, 8}), ({"104435568_900778570", "104430325_900778570", "900778570_900778570",
                          "900778570_900778570", "104435568_104435568", "104430325_104435568", "900778570_104435568", "900778570_104435568"}),
                        itr_indices45->second, itr_dense_shape45->second, itr_values45->second);

  auto pre_itr46 = map.find("f46");
  auto itr_len46 = map.find("f46_length");
  TEST_ASSERT_BOOL(pre_itr46 != map.end());
  TEST_ASSERT_BOOL(itr_len46 != map.end());
  TEST_LIST_STRING(({"104435568#0#click", "104430325#1#click", "900778570#2#click", "900778570#3#click"}), pre_itr46->second);
  TEST_LIST_INT32(({4}), itr_len46->second);

  auto itr_values47 = map.find("f47_values");
  auto itr_indices47 = map.find("f47_indices");
  auto itr_dense_shape47 = map.find("f47_dense_shape");
  TEST_ASSERT_BOOL(itr_values47 != map.end());
  TEST_ASSERT_BOOL(itr_indices47 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape47 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({8640000000}),
                            itr_indices47->second, itr_dense_shape47->second, itr_values47->second);

  auto pre_itr48 = map.find("f48");
  auto itr_len48 = map.find("f48_length");
  TEST_ASSERT_BOOL(pre_itr48 != map.end());
  TEST_ASSERT_BOOL(itr_len48 != map.end());
  TEST_LIST_INT64(({5, 6, 7, 8}), pre_itr48->second);
  TEST_LIST_INT32(({4}), itr_len48->second);

  auto pre_itr49 = map.find("f49");
  auto itr_len49 = map.find("f49_length");
  TEST_ASSERT_BOOL(pre_itr49 != map.end());
  TEST_ASSERT_BOOL(itr_len49 != map.end());
  TEST_LIST_INT64(({432000000, 86400000, 604800000, 6912000000}), pre_itr49->second);
  TEST_LIST_INT32(({4}), itr_len49->second);

  auto pre_itr50 = map.find("f50");
  TEST_ASSERT_BOOL(pre_itr50 != map.end());
  TEST_LIST_INT64(({3, 5}), pre_itr50->second);

  auto pre_itr51 = map.find("f51");
  auto itr_len51 = map.find("f51_length");
  TEST_ASSERT_BOOL(pre_itr51 != map.end());
  TEST_ASSERT_BOOL(itr_len51 != map.end());
  TEST_LIST_STRING(({"104430325", "104435568", "900778570"}), pre_itr51->second);
  TEST_LIST_INT32(({3}), itr_len51->second);

  auto pre_itr53 = map.find("f53");
  auto itr_len53 = map.find("f53_length");
  TEST_ASSERT_BOOL(pre_itr53 != map.end());
  TEST_ASSERT_BOOL(itr_len53 != map.end());
  TEST_LIST_STRING(({"104435568"}), pre_itr53->second);
  TEST_LIST_INT32(({1}), itr_len53->second);

  auto pre_itr54 = map.find("f54");
  auto itr_len54 = map.find("f54_length");
  TEST_ASSERT_BOOL(pre_itr54 != map.end());
  TEST_ASSERT_BOOL(itr_len54 != map.end());
  TEST_LIST_INT64(({(int64_t)95 * 86400 * 1000}), pre_itr54->second);
  TEST_LIST_INT32(({1}), itr_len54->second);

  auto pre_itr55 = map.find("f55");
  auto itr_len55 = map.find("f55_length");
  TEST_ASSERT_BOOL(pre_itr55 != map.end());
  TEST_ASSERT_BOOL(itr_len55 != map.end());
  TEST_LIST_INT64(({10}), pre_itr55->second);
  TEST_LIST_INT32(({1}), itr_len55->second);

  auto pre_itr56 = map.find("f56");
  auto itr_len56 = map.find("f56_length");
  TEST_ASSERT_BOOL(pre_itr56 != map.end());
  TEST_ASSERT_BOOL(itr_len56 != map.end());
  TEST_LIST_STRING(({"端午节", "非假期日", "", "劳动节", "国庆节", "非假期日"}), pre_itr56->second);
  TEST_LIST_INT32(({2}), itr_len56->second); 

  auto pre_itr58 = map.find("f58");
  auto itr_len58 = map.find("f58_length");
  TEST_ASSERT_BOOL(pre_itr58 != map.end());
  TEST_ASSERT_BOOL(itr_len58 != map.end());
  TEST_LIST_STRING(({"104430325", "104435568", "900778570"}), pre_itr58->second);
  TEST_LIST_INT32(({3}), itr_len58->second);

  auto pre_itr59 = map.find("f59");
  auto itr_len59 = map.find("f59_length");
  TEST_ASSERT_BOOL(pre_itr59 != map.end());
  TEST_ASSERT_BOOL(itr_len59 != map.end());
  TEST_LIST_INT64(({25 ,25, 50}), pre_itr59->second);
  TEST_LIST_INT32(({3}), itr_len59->second); 

  auto itr_values60 = map.find("f60_values");
  auto itr_indices60 = map.find("f60_indices");
  auto itr_dense_shape60 = map.find("f60_dense_shape");
  TEST_ASSERT_BOOL(itr_values60 != map.end());
  TEST_ASSERT_BOOL(itr_indices60 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape60 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1}), ({1, 2}), ({8, 9}),
                            itr_indices60->second, itr_dense_shape60->second, itr_values60->second);

  FUNC_TEST_END();  
}

// 检测gettext方法获得xml内容是否支持自动去除空白字符
void test_xml_item_map() {
  FUNC_TEST_START();

  std::string xml_str = R"(
    <config>
        <source name="user_am_clk" value=".user_feature.am_gm_clk_off.am_clk_off.user_sequence" />
        <source name="item_feature_con" value=".item_feature.item_feature_se.context.feature" />

        <features>
            <feature name="f19" type="expo_123_count" source="user_am_clk.app_id,item_feature_con.app_id" />
            <feature name="f20" type="direct" source="f19:0" />
            <feature name="f21" type="direct" source="f19:1" />
            <feature name="f22" type="direct" source="f19:2" />
        </features>
    </config>

    <item_map>
        104435568,母婴,健康育儿,母婴健康;900778570,工具,生活工具,日历;104430325,社交,聊天交友,匿名/陌生人;900834783,默认值,默认值,默认值;220738225,默认值,默认值,默认值;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店
    </item_map>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f20" shape="2" type="dense" />
        <input name="f21" shape="2" type="dense" />
        <input name="f22" shape="2" type="dense" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(xml_str, "", "", vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  // user clk
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();

  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104435568");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104430325");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* item_se = item->mutable_item_feature_se();
  tensorflow::Feature& input = (*(item_se->mutable_context()->mutable_feature()))["app_id"];
  input.mutable_bytes_list()->add_value("900778570");
  input.mutable_bytes_list()->add_value("104435568");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map0 = batch_ret.batch(0).context().feature();

  auto itr20 = map0.find("f20");
  TEST_ASSERT_BOOL(itr20 != map0.end());
  TEST_FEATURE_INT64(({2, 1}), itr20->second);

  auto itr21 = map0.find("f21");
  TEST_ASSERT_BOOL(itr21 != map0.end());
  TEST_FEATURE_INT64(({2, 1}), itr21->second);

  auto itr22 = map0.find("f22");
  TEST_ASSERT_BOOL(itr22 != map0.end());
  TEST_FEATURE_INT64(({2, 1}), itr22->second);

  std::vector<std::shared_ptr<Config>> need_vec;

  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto pre_itr20 = map.find("f20");
  TEST_ASSERT_BOOL(pre_itr20 != map.end());
  TEST_LIST_INT64(({2, 1}), pre_itr20->second);

  auto pre_itr21 = map.find("f21");
  TEST_ASSERT_BOOL(pre_itr21 != map.end());
  TEST_LIST_INT64(({2, 1}), pre_itr21->second);

  auto pre_itr22 = map.find("f22");
  TEST_ASSERT_BOOL(pre_itr22 != map.end());
  TEST_LIST_INT64(({2, 1}), pre_itr22->second);

  FUNC_TEST_END();  
}

void test_item_map_xml() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="0" default_value="test_no_data" />
            <feature name="f11" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="1" default_value="test_no_data" />
            <feature name="f12" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="2" default_value="test_no_data" />
        </features>
    </config>

    <item_map>test/data/item_map.txt</item_map>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f10" shape="1,2,5" type="sequence" />
        <input name="f11" shape="1,2,5" type="sequence" />
        <input name="f12" shape="1,2,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  AppidTo123ClassConfig* conf = dynamic_cast<AppidTo123ClassConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104418979");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900785693");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f10");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"工具"}, {"工具"}, {"办公"}}), itr00->second);

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"娱乐工具"}, {"娱乐工具"}, {"办公软件"}}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"变声器"}, {"娱乐测试"}, {"日程管理"}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f10");
  auto itr_len0 = map.find("f10_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"工具", "", "工具", "", "办公", ""}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f11");
  auto itr_len1 = map.find("f11_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"娱乐工具", "", "娱乐工具", "", "办公软件", ""}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  auto itr2 = map.find("f12");
  auto itr_len2 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"变声器", "", "娱乐测试", "", "日程管理", ""}), itr2->second);
  TEST_LIST_INT32(({3}), itr_len2->second);

  FUNC_TEST_END();
}

void test_app_info_xml() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="0" default_value="test_no_data" dict_type="appinfo" />
            <feature name="f11" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="1" default_value="test_no_data" dict_type="appinfo" />
            <feature name="f12" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="2" default_value="test_no_data" dict_type="appinfo" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini</app_info>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f10" shape="1,2,5" type="sequence" />
        <input name="f11" shape="1,2,5" type="sequence" />
        <input name="f12" shape="1,2,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  AppidTo123ClassConfig* conf = dynamic_cast<AppidTo123ClassConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("922413282");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("922743748");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("922533292");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f10");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"游戏"}, {"应用"}, {"应用"}}), itr00->second);

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"经营策略"}, {"系统工具"}, {"系统工具"}}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"养成"}, {"系统软件"}, {"系统软件"}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f10");
  auto itr_len0 = map.find("f10_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"游戏", "", "应用", "", "应用", ""}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f11");
  auto itr_len1 = map.find("f11_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"经营策略", "", "系统工具", "", "系统工具", ""}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  auto itr2 = map.find("f12");
  auto itr_len2 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"养成", "", "系统软件", "", "系统软件", ""}), itr2->second);
  TEST_LIST_INT32(({3}), itr_len2->second);

  FUNC_TEST_END();
}

// item_map和app_info相互独立
void test_item_map_and_app_info() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f9" type="dict_to_attributes" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" dict_type="app_id" connector="\002" default_value="test_no_data" />
            <feature name="f10" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="0" default_value="test_no_data" />
            <feature name="f20" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="0" default_value="test_no_data" dict_type="appinfo" />
            <feature name="f11" type="direct" source="f9:0" />
            <feature name="f12" type="direct" source="f9:1" />
            <feature name="f13" type="direct" source="f9:2" />
            <feature name="f14" type="direct" source="f9:3" />
            <feature name="f15" type="direct" source="f9:4" />
            <feature name="f16" type="direct" source="f9:5" />
            <feature name="f17" type="direct" source="f9:6" />
            <feature name="f18" type="direct" source="f9:7" />
            <feature name="f19" type="direct" source="f9:8" />
        </features>
    </config>

    <item_map path="test/data/item_map.txt" />
    <app_info path="test/data/app_info_minor_mini" />
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f10" shape="1,1,5" type="sequence" />
        <input name="f11" shape="1,1,5" type="sequence" />
        <input name="f12" shape="1,1,5" type="sequence" />
        <input name="f13" shape="1,1,5" type="sequence" />
        <input name="f14" shape="1,1,5" type="sequence" />
        <input name="f15" shape="1,1,5" type="sequence" />
        <input name="f16" shape="1,1,5" type="sequence" />
        <input name="f17" shape="1,1,5" type="sequence" />
        <input name="f18" shape="1,1,5" type="sequence" />
        <input name="f19" shape="1,1,5" type="sequence" />
        <input name="f20" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(12, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  DictToAttributesConfig* conf = dynamic_cast<DictToAttributesConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  TEST_ASSERT_BOOL(nullptr != vec[1]);
  AppidTo123ClassConfig* conf2 = dynamic_cast<AppidTo123ClassConfig*>(vec[1].get());
  TEST_ASSERT_BOOL(nullptr != conf2);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("922743748");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("922533292");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f10");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"工具"}, {"test_no_data"}, {"test_no_data"}}), itr00->second);

  auto itr20 = map00.find("f20");
  TEST_ASSERT_BOOL(itr20 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"应用"}, {"应用"}}), itr20->second);

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"922743748"}, {"922533292"}}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"com.android.cm.d1667295087633173127"}, {"com.android.cts.assist.wit"}}), itr02->second);

  auto itr03 = map00.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"安卓系统软件"}, {"安卓系统软件"}}), itr03->second);

  auto itr04 = map00.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"应用"}, {"应用"}}), itr04->second);

  auto itr05 = map00.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"系统工具"}, {"系统工具"}}), itr05->second);

  auto itr06 = map00.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"系统软件"}, {"系统软件"}}), itr06->second);

  auto itr07 = map00.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"默认值"}, {"默认值"}}), itr07->second);

  auto itr08 = map00.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"默认值"}, {"默认值"}}), itr08->second);

  auto itr09 = map00.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"默认值"}, {"默认值"}}), itr09->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f10");
  auto itr_len0 = map.find("f10_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"工具", "test_no_data", "test_no_data"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr020 = map.find("f20");
  auto itr_len20 = map.find("f20_length");
  TEST_ASSERT_BOOL(itr020 != map.end());
  TEST_ASSERT_BOOL(itr_len20 != map.end());
  TEST_LIST_STRING(({"test_no_data", "应用", "应用"}), itr020->second);
  TEST_LIST_INT32(({3}), itr_len20->second);

  auto itr1 = map.find("f11");
  auto itr_len1 = map.find("f11_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"test_no_data", "922743748", "922533292"}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  auto itr2 = map.find("f12");
  auto itr_len2 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"test_no_data", "com.android.cm.d1667295087633173127", "com.android.cts.assist.wit"}), itr2->second);
  TEST_LIST_INT32(({3}), itr_len2->second);

  auto itr3 = map.find("f13");
  auto itr_len3 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_STRING(({"test_no_data", "安卓系统软件", "安卓系统软件"}), itr3->second);
  TEST_LIST_INT32(({3}), itr_len3->second);

  auto itr4 = map.find("f14");
  auto itr_len4 = map.find("f14_length");
  TEST_ASSERT_BOOL(itr4 != map.end());
  TEST_ASSERT_BOOL(itr_len4 != map.end());
  TEST_LIST_STRING(({"test_no_data", "应用", "应用"}), itr4->second);
  TEST_LIST_INT32(({3}), itr_len4->second);

  auto itr5 = map.find("f15");
  auto itr_len5 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr5 != map.end());
  TEST_ASSERT_BOOL(itr_len5 != map.end());
  TEST_LIST_STRING(({"test_no_data", "系统工具", "系统工具"}), itr5->second);
  TEST_LIST_INT32(({3}), itr_len5->second);

  auto itr6 = map.find("f16");
  auto itr_len6 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr6 != map.end());
  TEST_ASSERT_BOOL(itr_len6 != map.end());
  TEST_LIST_STRING(({"test_no_data", "系统软件", "系统软件"}), itr6->second);
  TEST_LIST_INT32(({3}), itr_len6->second);

  auto itr7 = map.find("f17");
  auto itr_len7 = map.find("f17_length");
  TEST_ASSERT_BOOL(itr7 != map.end());
  TEST_ASSERT_BOOL(itr_len7 != map.end());
  TEST_LIST_STRING(({"test_no_data", "默认值", "默认值"}), itr7->second);
  TEST_LIST_INT32(({3}), itr_len7->second);

  auto itr8 = map.find("f18");
  auto itr_len8 = map.find("f18_length");
  TEST_ASSERT_BOOL(itr8 != map.end());
  TEST_ASSERT_BOOL(itr_len8 != map.end());
  TEST_LIST_STRING(({"test_no_data", "默认值", "默认值"}), itr8->second);
  TEST_LIST_INT32(({3}), itr_len8->second);

  auto itr9 = map.find("f19");
  auto itr_len9 = map.find("f19_length");
  TEST_ASSERT_BOOL(itr9 != map.end());
  TEST_ASSERT_BOOL(itr_len9 != map.end());
  TEST_LIST_STRING(({"test_no_data", "默认值", "默认值"}), itr9->second);
  TEST_LIST_INT32(({3}), itr_len9->second);

  FUNC_TEST_END();
}

void test_versions() {
  FUNC_TEST_START();

  std::string xml_str = R"(
    <config>
        <source name="user_am_clk" value=".user_feature.am_gm_clk_off.am_clk_off.user_sequence" />
        <source name="user_yoyo" value=".user_feature.yoyo_imp_off.yoyo_recommend_expo_appid_seq_7d" />
        <source name="user_feature_list" value=".user_feature.user_feature_se.feature_lists.feature_list" />
        <source name="item_feature_list" value=".item_feature.item_feature_se.feature_lists.feature_list" />
        <source name="item_feature_con" value=".item_feature.item_feature_se.context.feature" />

        <features>
            <feature name="f0" type="bucketize" source="user_am_clk.num" boundary="0.09,1.01,2.56" />
            <feature name="f1" type="hash" source="user_yoyo.value" bucket_size="1000" concat_with_name="true" />
            <feature name="f2" type="vocab_list" source="item_feature_list.default" vocabs="NOT_EXIST,1,2,3,4,5,6,7,8,9" />
            <feature name="f3" type="vocab_set" source=".user_action.item_id.app_id" dict="app0,app1,app2,app3,app4,app5,app6" />
            <feature name="f4" type="direct" source="item_feature_con.direct" />
            <feature name="f5" type="filter_appid" source="user_am_clk.app_id,user_am_clk.event_time,.request_time" days="1,3,10" max_len="100" />
            <feature name="f6" type="direct" source="f5:0" />
            <feature name="f7" type="direct" source="f5:1" />
            <feature name="f8" type="direct" source="f5:2" />
            <feature name="f9" type="max_expo_appid" source="user_am_clk.app_id" />
            <feature name="f10" type="max_123_class" source="user_am_clk.app_id" />
            <feature name="f11" type="direct" source="f10:0" />
            <feature name="f12" type="direct" source="f10:1" />
            <feature name="f13" type="direct" source="f10:2" />
            <feature name="f14" type="nearest_expo_appid" source="user_am_clk.app_id" />
            <feature name="f15" type="expo_appid_count" source="user_am_clk.app_id,item_feature_con.app_id" />
            <feature name="f16" type="expo_appid_count_v2" source="user_am_clk.app_id,item_feature_con.app_id" />
            <feature name="f17" type="direct" source="f16:0" />
            <feature name="f18" type="direct" source="f16:1" />
            <feature name="f19" type="expo_123_count" source="user_am_clk.app_id,item_feature_con.app_id" />
            <feature name="f20" type="direct" source="f19:0" />
            <feature name="f21" type="direct" source="f19:1" />
            <feature name="f22" type="direct" source="f19:2" />
            <feature name="f23" type="expo_123_count_v2" source="user_am_clk.app_id,item_feature_con.app_id" />
            <feature name="f24" type="direct" source="f23:0" />
            <feature name="f25" type="direct" source="f23:1" />
            <feature name="f26" type="direct" source="f23:2" />
            <feature name="f27" type="direct" source="f23:3" />
            <feature name="f28" type="direct" source="f23:4" />
            <feature name="f29" type="direct" source="f23:5" />
            <feature name="f30" type="direct" source="f2:0" />
        </features>

        <default_values>
            <default_value source="item_feature_list.default" dtype="string" values="9,81" />
        </default_values>
    </config>

    <versions>
      <version name="test_version" value="f3,f6,f12,f15,f22,f30" />
    </versions>

    <item_map>104435568,母婴,健康育儿,母婴健康;900778570,工具,生活工具,日历;104430325,社交,聊天交友,匿名/陌生人;900834783,默认值,默认值,默认值;220738225,默认值,默认值,默认值;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店</item_map>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(xml_str, "", "test_version", vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // 请求时间
  request.set_request_time((int64_t)100 * 86400 * 1000);

  // user clk
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();

  pb_info->set_num(0);
  pb_info->set_app_id("104435568"); // diff 5
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info->set_use_duration(10);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("102");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_num(1);
  pb_info->set_app_id("104430325"); // diff 1
  pb_info->set_event_time((int64_t)99 * 86400 * 1000);
  pb_info->set_use_duration(10);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("102");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_num(2);
  pb_info->set_app_id("900778570"); // diff 7
  pb_info->set_event_time((int64_t)93 * 86400 * 1000);
  pb_info->set_use_duration(10);
  pb_info->set_first_intent_type("5");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("102");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_num(3);
  pb_info->set_app_id("900778570"); // diff 7
  pb_info->set_event_time((int64_t)20 * 86400 * 1000);
  pb_info->set_use_duration(10);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("102");

  // user yoyo
  qinglong::DwsAiYoyoRecommendExpoOfflineEventIncD* pb_yoyo = pb_ufv2->mutable_yoyo_imp_off();
  qinglong::StringArray* pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("name123");
  pb_str->add_value("name456");
  pb_str = pb_yoyo->add_yoyo_recommend_expo_appid_seq_7d();
  pb_str->add_value("name789");
  // user action
  qinglong::UserAction* user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app0");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app5");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app2");
  user_action = request.add_user_action();
  user_action->mutable_item_id()->set_app_id("app9");
  //user context
  tensorflow::SequenceExample* user_feature_se = request.mutable_user_feature()->mutable_user_feature_se();
  auto& user_list_map = *user_feature_se->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list = user_list_map["batch"];
  tensorflow::Feature* feat = list.add_feature();
  feat->mutable_int64_list()->add_value(10);

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* item_se = item->mutable_item_feature_se();
  tensorflow::Feature& input_f = (*(item_se->mutable_context()->mutable_feature()))["direct"];
  input_f.mutable_bytes_list()->add_value("direct0");
  input_f.mutable_bytes_list()->add_value("direct1");
  tensorflow::Feature& input_f2 = (*(item_se->mutable_context()->mutable_feature()))["app_id"];
  input_f2.mutable_bytes_list()->add_value("900778570");
  input_f2.mutable_bytes_list()->add_value("104435568");
  tensorflow::Feature& input_f3 = (*(item_se->mutable_context()->mutable_feature()))["num"];
  input_f3.mutable_int64_list()->add_value(1);
  input_f3.mutable_int64_list()->add_value(3);
  input_f3.mutable_int64_list()->add_value(5);
  input_f3.mutable_int64_list()->add_value(7);
  input_f3.mutable_int64_list()->add_value(-1);
  tensorflow::Feature& input_f4 = (*(item_se->mutable_context()->mutable_feature()))["time"];
  input_f4.mutable_bytes_list()->add_value("1727580548000");
  input_f4.mutable_bytes_list()->add_value("");

  auto& feat_list = (*(item_se->mutable_feature_lists()->mutable_feature_list()))["time"];
  feat = feat_list.add_feature();
  feat->mutable_int64_list()->add_value((int64_t)1717831143 * 1000);
  feat->mutable_int64_list()->add_value((int64_t)1719026948 * 1000);
  feat = feat_list.add_feature();
  feat->mutable_int64_list()->add_value((int64_t)1714865919 * 1000);
  feat->mutable_int64_list()->add_value((int64_t)1728287312 * 1000);
  feat->mutable_int64_list()->add_value((int64_t)1683195118 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).context().feature();
  const auto& list_map0 = batch_ret.batch(0).feature_lists().feature_list();

  for (uint32_t i = 0; i < 31; i++) {
    auto itr = map0.find("f" + std::to_string(i));
    if (i != 12 && i != 15 && i != 22) {
      TEST_EXPECT_BOOL(itr == map0.end());
    } else {
      TEST_EXPECT_BOOL(itr != map0.end());
    }
  }

  for (uint32_t i = 0; i < 31; i++) {
    auto itr = list_map0.find("f" + std::to_string(i));
    if (i != 2 && i != 3 && i != 6 && i != 30) {
      TEST_EXPECT_BOOL(itr == list_map0.end());
    } else {
      TEST_EXPECT_BOOL(itr != list_map0.end());
    }
  }

  FUNC_TEST_END();
}

void test_macro_replace() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <source dict_name="set_dict" value="test/data/query_appname.txt" />
        <source dict_name="map_dict" value="test/data/query_appname_value.txt" />
        <source dict_name="jieba_dict" value="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" />
        <source dict_name="hmm_dict" value="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" />
        <source dict_name="user_dict" value="third_party/cppjieba-5.0.3/dict/user.dict.utf8" />
        <source dict_name="item_map_dict" value="test/data/item_map.txt" />
        <source dict_name="appinfo_dict" value="test/data/app_info_minor_mini" />

        <features>
            <feature name="f21" type="vocab_set" source=".item_feature.item_feature_se.context.feature.app_id" dict="set_dict" />
            <feature name="f22" type="vocab_map" source=".item_feature.item_feature_se.context.feature.app_id" dtype="int64" dict="map_dict" />
            <feature name="f23" type="segment" source=".item_feature.item_feature_se.context.feature.app_id" jieba_dict_path="jieba_dict" hmm_model_path="hmm_dict" user_dict_path="user_dict" />
            <feature name="f9" type="dict_to_attributes" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" dict_type="app_id" connector="\002" default_value="test_no_data" />
            <feature name="f10" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="0" default_value="test_no_data" dict_type="appinfo" />
            <feature name="f20" type="appid_to_123_class" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" class_type="0" default_value="test_no_data" />
            <feature name="f11" type="direct" source="f9:0" />
            <feature name="f12" type="direct" source="f9:1" />
            <feature name="f13" type="direct" source="f9:2" />
            <feature name="f14" type="direct" source="f9:3" />
            <feature name="f15" type="direct" source="f9:4" />
            <feature name="f16" type="direct" source="f9:5" />
            <feature name="f17" type="direct" source="f9:6" />
            <feature name="f18" type="direct" source="f9:7" />
            <feature name="f19" type="direct" source="f9:8" />
        </features>
    </config>

    <item_map path="item_map_dict" />
    <app_info path="appinfo_dict" />
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("922743748");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("922533292");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("导航_高德地图");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("1号店_1号会员店");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr21 = map00.find("f21");
  TEST_ASSERT_BOOL(itr21 != map00.end());
  TEST_FEATURE_STR(({"导航_高德地图", "1号店_1号会员店"}), itr21->second);

  auto itr22 = map00.find("f22");
  TEST_ASSERT_BOOL(itr22 != map00.end());
  TEST_FEATURE_INT64(({2, -1}), itr22->second);

  auto itr23 = map00.find("f23");
  TEST_ASSERT_BOOL(itr23 != map00.end());
  TEST_FEATURE_STR(({"导航", "_", "高德", "地图", "1", "号店", "_", "1", "号", "会员", "店"}), itr23->second);

  const auto& map01 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map01.find("f10");
  TEST_ASSERT_BOOL(itr00 != map01.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"应用"}, {"应用"}}), itr00->second);

  auto itr20 = map01.find("f20");
  TEST_ASSERT_BOOL(itr20 != map01.end());
  TEST_FEATURE_LIST_STR(({{"工具"}, {"test_no_data"}, {"test_no_data"}}), itr20->second);

  auto itr01 = map01.find("f11");
  TEST_ASSERT_BOOL(itr01 != map01.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"922743748"}, {"922533292"}}), itr01->second);

  auto itr02 = map01.find("f12");
  TEST_ASSERT_BOOL(itr02 != map01.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"com.android.cm.d1667295087633173127"}, {"com.android.cts.assist.wit"}}), itr02->second);

  auto itr03 = map01.find("f13");
  TEST_ASSERT_BOOL(itr03 != map01.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"安卓系统软件"}, {"安卓系统软件"}}), itr03->second);

  auto itr04 = map01.find("f14");
  TEST_ASSERT_BOOL(itr04 != map01.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"应用"}, {"应用"}}), itr04->second);

  auto itr05 = map01.find("f15");
  TEST_ASSERT_BOOL(itr05 != map01.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"系统工具"}, {"系统工具"}}), itr05->second);

  auto itr06 = map01.find("f16");
  TEST_ASSERT_BOOL(itr06 != map01.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"系统软件"}, {"系统软件"}}), itr06->second);

  auto itr07 = map01.find("f17");
  TEST_ASSERT_BOOL(itr07 != map01.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"默认值"}, {"默认值"}}), itr07->second);

  auto itr08 = map01.find("f18");
  TEST_ASSERT_BOOL(itr08 != map01.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"默认值"}, {"默认值"}}), itr08->second);

  auto itr09 = map01.find("f19");
  TEST_ASSERT_BOOL(itr09 != map01.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}, {"默认值"}, {"默认值"}}), itr09->second);

  FUNC_TEST_END();
}

void test_all() {
  FUNC_TEST_START();
  static const std::string test_dir = "/home/featureextractor/test/data/";

  std::string fe_request_str = Calc::read_file_to_string(test_dir + "ferequest_v2.pb");

  TEST_EXPECT_EQUAL(462574, fe_request_str.size());

  std::string model_input_path = test_dir + "model_input_config_v2.json";
  uint64_t model_input_handle = init_online_model_input_v2(model_input_path.c_str());
  std::string fe_config_path = test_dir + "fe_config_v2.json";
  uint64_t handle = init_online_v2(model_input_handle, fe_config_path.c_str());

  TEST_ASSERT_BOOL(model_input_handle > 0);
  TEST_ASSERT_BOOL(handle > 0);

  std::string pb_result_str = to_predict_request_v2(handle, model_input_handle, fe_request_str.c_str(), fe_request_str.length());

  free_handle_v2(handle);
  free_model_input_handle_v2(model_input_handle);

  TEST_EXPECT_EQUAL(53990, pb_result_str.size());

  #if 0
  //创建文件
  std::ofstream result_write_file(test_dir + "result_v2.pb", std::ios::out | std::ios::binary );
  TEST_ASSERT_BOOL(result_write_file.is_open());

  result_write_file.write(pb_result_str.c_str(), pb_result_str.length());

  //关闭文件
  result_write_file.close();
  #endif

  std::string pre_str = Calc::read_file_to_string(test_dir + "result_v2.pb");

  google::protobuf::Arena arena;
  qinglong::PredictRequest* pb_result = google::protobuf::Arena::CreateMessage<qinglong::PredictRequest>(&arena);
  qinglong::PredictRequest* pb_pre = google::protobuf::Arena::CreateMessage<qinglong::PredictRequest>(&arena);
 
  TEST_ASSERT_BOOL(pb_result->ParseFromString(pb_result_str));
  TEST_ASSERT_BOOL(pb_pre->ParseFromString(pre_str));

  bool com = google::protobuf::util::MessageDifferencer::Equals(*pb_result, *pb_pre);
  TEST_EXPECT_BOOL(com);

  if (!com) {
    auto& pre_map = pb_pre->inputs();
    auto& ret_map = pb_result->inputs();
    for (auto pre_itr = pre_map.begin(); pre_itr != pre_map.end(); ++pre_itr) {
      const tensorflow::TensorProto& pre_value = pre_itr->second;

      auto ret_itr = ret_map.find(pre_itr->first);

      if (ret_itr == ret_map.end()) {
        continue;
      }

      com = google::protobuf::util::MessageDifferencer::Equals(pre_value, ret_itr->second);

      if (!com) {
        std::cout << "diff key:" << pre_itr->first << std::endl;
        display_tensor_proto("pre " + pre_itr->first, pre_value);
        display_tensor_proto("ret " + pre_itr->first, ret_itr->second);
      }
    }
  }

  pb_pre->set_version(123);
  TEST_EXPECT_BOOL(!google::protobuf::util::MessageDifferencer::Equals(*pb_result, *pb_pre));

  FUNC_TEST_END();
}

void test_feature_md5_1() {
  FUNC_TEST_START();

  google::protobuf::Arena arena;
  qinglong::FeRequest& fe_request = *(google::protobuf::Arena::CreateMessage<qinglong::FeRequest>(&arena));
  qinglong::BatchSequenceExample& batch_se = *(google::protobuf::Arena::CreateMessage<qinglong::BatchSequenceExample>(&arena));

  fe_request.set_request_time(time(0) * 1000);
  tensorflow::SequenceExample& user_feature_se = *(fe_request.mutable_user_feature()->mutable_user_feature_se());
  auto user_context_map = user_feature_se.mutable_context()->mutable_feature();

  (*user_context_map)["user_pkg_expo_1d"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["days_since_first_active_date"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["second_intent_type_use_15d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["second_intent_type_click_3d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["active_city"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["third_intent_type_click_3d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["third_intent_type_use_15d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["second_intent_type_click_15d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["third_intent_type_click_15d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["permanent_county"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["permanent_city_grade"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["prod_color"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["user_pkg_dl_7d"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["first_intent_type_click_7d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["second_intent_type_use_7d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["last_province"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["prefer_top_app"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["have_children"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["permanent_city"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["first_intent_type_use_15d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["last_county"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["carrier_name"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["user_pkg_dl_3d"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["second_intent_type_click_1d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["prefer_app_secondary_type"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["interest_label"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["second_intent_type_click_7d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["age"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["category_name"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["third_intent_type_use_3d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["first_intent_type_click_1d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["permanent_province"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["second_intent_type_use_1d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["second_intent_type_use_3d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["user_pkg_dl_1d"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["first_intent_type_use_1d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["first_intent_type_use_3d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["user_pkg_expo_7d"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["gender"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["user_pkg_dl_15d"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["active_province"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["third_intent_type_use_7d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["third_intent_type_use_1d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["marry_status"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["first_intent_type_click_3d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["devicename"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["user_pkg_expo_15d"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["active_county"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["first_intent_type_use_7d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["job"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["user_pkg_expo_3d"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["userinstalledpkgname"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["third_intent_type_click_7d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["third_intent_type_click_1d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["first_intent_type_click_15d_new"].mutable_int64_list()->add_value(1000);
  (*user_context_map)["product_series"].mutable_int64_list()->add_value(1000);

  fe_request.mutable_user_feature()->mutable_yoyo_imp_off()->add_yoyo_recommend_expo_appid_seq_7d()->add_value("123");
  fe_request.mutable_user_feature()->mutable_yoyo_imp_off()->add_yoyo_recommend_expo_appid_seq_7d()->add_value("456");
  fe_request.add_user_action()->set_download(2);

  const int item_batch_size = 40;
  for (int i = 0; i < item_batch_size; i++) {
    auto* item = fe_request.add_item_feature()->mutable_item_feature_se();
    auto item_context_map = item->mutable_context()->mutable_feature();

    (*item_context_map)["ad_dtr_1d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_15d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_download_success_click_1d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_1d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["num_three_star"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_nfr_15d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_7d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_30d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_15d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_dtr_15d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_expo_15d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_15d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["has_app_checked"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_dtr_3d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["app_id"].mutable_bytes_list()->add_value("900846598");
    (*item_context_map)["pkg_ad_nfr_30d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_1d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_15d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["num_release_countries"].mutable_int64_list()->add_value(100);
    (*item_context_map)["default_language"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_7d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_15d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_3d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_3d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_download_success_click_30d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["version_time"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_30d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_expo_7d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_expo_15d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_3d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_21d_package_name_pt_h_workday_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_7d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_7d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_download_success_click_3d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_30d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_30d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_3d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_7d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_3d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_7d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_7d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_7d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_dtr_1d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_15d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_download_success_click_15d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_3d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_download_success_click_3d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_dtr_1d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_expo_7d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["num_four_star"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_3d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_dtr_7d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_15d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_15d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_7d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["app_name"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_15d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_7d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_15d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_30d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_7d_package_name_pt_h_workday_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_7d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_negative_15d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_dtr_1d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_15d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_1d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_negative_7d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_dtr_30d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_download_success_click_1d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_download_success_click_1d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_dtr_7d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_30d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_7d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_7d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_1d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_15d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_download_success_click_30d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_7d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_3d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_3d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_7d_package_name_pt_h_workday_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_7d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_dtr_3d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["in_app_product"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_30d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_expo_30d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_15d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_nfr_1d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_3d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_download_success_click_7d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_expo_3d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_1d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_expo_7d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["age_limit"].mutable_int64_list()->add_value(100);
    (*item_context_map)["stars"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_dtr_15d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["product_type"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_30d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["package_name"].mutable_int64_list()->add_value(100);
    (*item_context_map)["developer"].mutable_int64_list()->add_value(100);
    (*item_context_map)["adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_30d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["app_name_app_list"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_21d_package_name_pt_h_workday_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_negative_1d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_1d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_3d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_1d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_15d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_download_success_click_7d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_7d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_1d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_15d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_7d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_7d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_1d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_dtr_15d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_3d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_download_success_click_15d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["media_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_3d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_expo_30d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_1d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_dtr_1d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["app_name_intent_type_third_category"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_nfr_7d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_expo_1d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_15d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["app_name_intent_type_first_category"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_download_success_click_1d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_21d_package_name_pt_h_workday_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_15d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_1d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_download_success_click_30d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_dtr_30d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_15d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_expo_1d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_1d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_3d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_expo_15d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_dtr_30d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_1d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_1d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_1d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_expo_1d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_dtr_3d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_expo_7d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_1d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_3d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_1d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_dtr_7d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_14d_package_name_pt_h_workday_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["app_name_first_third_intent_type"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_3d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_download_success_click_3d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_expo_1d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_download_success_click_30d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_15d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_7d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_1d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_expo_3d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["app_name_first_second_intent_type"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_1d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["percentage_five_star"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_30d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_nfr_3d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_download_success_click_15d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["version_time_day_elapsed"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_7d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_download_success_click_15d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["app_name_query_term_list"].mutable_int64_list()->add_value(100);
    (*item_context_map)["num_two_star"].mutable_int64_list()->add_value(100);
    (*item_context_map)["percentage_two_star"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_1d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_14d_package_name_pt_h_workday_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_7d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_15d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_3d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_30d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_14d_package_name_pt_h_workday_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_expo_30d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_download_success_click_3d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_3d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_3d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["release_countries"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_expo_3d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_3d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_negative_30d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_15d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_dtr_15d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["app_name_first_first_intent_type"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_success_7d__third_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_dtr_30d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["percentage_three_star"].mutable_int64_list()->add_value(100);
    (*item_context_map)["third_intent_type_ad_dtr_7d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_3d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_expo_15d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["percentage_four_star"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_negative_3d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_7d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["distribution_shape_five_star"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_7d_package_name_pt_h_workday_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_download_success_click_7d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_download_success_click_7d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["app_name_intent_type_second_category"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_3d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_1d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_30d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["num_five_star"].mutable_int64_list()->add_value(100);
    (*item_context_map)["first_intent_type_ad_dtr_3d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["pkg_ad_expo_3d_new"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_7d__first_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_15d_package_name_last_province"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_15d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_3d_package_name_pt_h_adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_1d__package_name__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_dtr_3d__second_intent_type__adunit_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_expo_1d_package_name_active_city"].mutable_int64_list()->add_value(100);
    (*item_context_map)["ad_download_15d_package_name_gender"].mutable_int64_list()->add_value(100);
    (*item_context_map)["second_intent_type_ad_expo_30d"].mutable_int64_list()->add_value(100);
    (*item_context_map)["num_one_star"].mutable_int64_list()->add_value(100);
    (*item_context_map)["apk_id"].mutable_int64_list()->add_value(100);
    (*item_context_map)["percentage_one_star"].mutable_int64_list()->add_value(100);
  }

  std::string config_path = "/home/featureextractor/test/data/fe_config_v2.json";

  uint64_t handle = init_offline_v2(config_path.c_str());

  FeatureExtractorObject fe_object(fe_request);
  ConfigInfo* config_handle = reinterpret_cast<ConfigInfo*>(handle);
  toSequenceExample(&arena, fe_object, *config_handle, batch_se);

  TEST_ASSERT_EQUAL(true, batch_se.batch(0).has_context());

  const auto& map = batch_se.batch(0).context().feature();
  auto itr = map.find("fe_config_md5");
  TEST_ASSERT_BOOL(itr != map.end());
  TEST_FEATURE_STR(({"1671ad5a03a35b0c585bb76b34310316"}), itr->second);

  free_handle_v2(handle);

  FUNC_TEST_END();
}

void test_feature_md5_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "direct", 
          "source": [".item_feature.game_item_offline_feature.game_item_statistic_feature.ictr_dou_v1"]
      }
    },
    "default_values": {
        ".item_feature.game_item_offline_feature.game_item_statistic_feature.ictr_dou_v1": {
            "dtype": "float",
            "values": 5.18
        }
    }  
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest& request = *(google::protobuf::Arena::CreateMessage<qinglong::FeRequest>(&arena));
  qinglong::BatchSequenceExample& batch_se = *(google::protobuf::Arena::CreateMessage<qinglong::BatchSequenceExample>(&arena));

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_ictr_dou_v1(double(3.24));
  item = request.add_item_feature();
  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_ictr_dou_v1(double(1.71));
  item = request.add_item_feature();

  uint64_t handle = init_offline_by_content_v2(str.c_str());
  FeatureExtractorObject fe_object(request);
  ConfigInfo* config_handle = reinterpret_cast<ConfigInfo*>(handle);
  toSequenceExample(&arena, fe_object, *config_handle, batch_se);

  TEST_ASSERT_EQUAL(true, batch_se.batch(0).has_context());

  const auto& map = batch_se.batch(0).context().feature();
  auto itr = map.find("fe_config_md5");
  TEST_ASSERT_BOOL(itr != map.end());
  TEST_FEATURE_STR(({"bce6353322f391ba283d30de1d38ec76"}), itr->second);

  free_handle_v2(handle);

  FUNC_TEST_END();
}

// featurelist
void test_clip_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "clip", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"],
          "start": 0,
          "size": -1
      },

      "f16" : {
          "fe_type" : "clip", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"],
          "start": 8,
          "size": -1
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
      "f15": {
        "dtype" : "string",
        "shape" : [1, 1, 5] , 
        "model_input_type" : "sequence"
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ClipConfig* conf = dynamic_cast<ClipConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("900778570");
  pb_use->add_user_sequence()->set_app_id("104436666");
  pb_use->add_user_sequence()->set_app_id("823855929");

   /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr00 = map0.find("f15");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_STR(({{"900778570"}, {"104436666"}, {"823855929"}}), itr00->second);

  auto itr01 = map0.find("f16");

  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_FEATURE_LIST_STR(({{}, {}, {}}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map1 = pre_ret.inputs();
  auto itr0 = map1.find("f15");
  auto itr_len0 = map1.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map1.end());
  TEST_ASSERT_BOOL(itr_len0 != map1.end());
  TEST_LIST_STRING(({"900778570", "104436666", "823855929"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  FUNC_TEST_END();
}

//feature
void test_clip_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
        "f0": {
            "fe_type" : "clip", 
            "source": [".item_feature.item_feature_se.context.feature.item"],
            "start": 1,
            "size": 8
        }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ClipConfig* conf = dynamic_cast<ClipConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);


  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid3");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid4");

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map = ret.batch(0).context().feature();
  auto itr = map.find("f0");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_FEATURE_STR(({"appid1", "appid2", "appid3", "appid4"}), itr->second);

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map1 = pre_ret.inputs();

  auto itr_values = map1.find("f0_values");
  auto itr_indices = map1.find("f0_indices");
  auto itr_dense_shape = map1.find("f0_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map1.end());
  TEST_ASSERT_BOOL(itr_indices != map1.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map1.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 0, 3}), ({1, 4}), ({"appid1", "appid2", "appid3", "appid4"}),
                            itr_indices->second, itr_dense_shape->second, itr_values->second);

  FUNC_TEST_END();
}

void test_exists() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="exists" source="E@.item_feature.item_feature_se.context.feature.app_id" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  ExistsConfig* config = dynamic_cast<ExistsConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app3");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app5");
  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({1}), itr00->second);
  TEST_FEATURE_INT64(({0}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0,}), ({2, 1}), ({1, 0}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_len_diff() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="len_diff" source=".item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.query" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  LenDiffConfig* config = dynamic_cast<LenDiffConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app2");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app3");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app5");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app5");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app3");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app5");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app1");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({2}), itr00->second);
  TEST_FEATURE_INT64(({-2}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0,}), ({2, 1}), ({2, -2}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_len_ratio() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="len_ratio" source=".item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.query" ratio_type="1" default_value="-1" />
            <feature name="f16" type="len_ratio" source=".item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.query" ratio_type="2" default_value="-1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
        <input name="f16" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  LenRatioConfig* config = dynamic_cast<LenRatioConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app2");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app3");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app5");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app5");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_FLOAT(({2}), itr00->second);
  TEST_FEATURE_FLOAT(({2}), itr10->second);

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_FLOAT(({3}), itr01->second);
  TEST_FEATURE_FLOAT(({-1}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0,}), ({2, 1}), ({2, 2}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f16_values");
  auto itr_indices1 = map.find("f16_indices");
  auto itr_dense_shape1 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0,}), ({2, 1}), ({3, -1}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_single_sequence_example() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "get_valid_value", 
          "source": [".request_time",
                      ".callback_req_ts"]
      }
    }
  })";

  // batch为1
  qinglong::FeRequest request;

  request.set_request_time(100);
  request.set_callback_req_ts(20);

  request.add_item_feature();

  std::string fe_request_str;
  init_offline_by_content(str.c_str());
  request.SerializeToString(&fe_request_str);
  std::string result_str = to_single_sequence_example(fe_request_str.c_str(), fe_request_str.length());

  tensorflow::SequenceExample result;
  result.ParseFromString(result_str);

  TEST_ASSERT_EQUAL(true, result.has_context());

  const auto& map = result.context().feature();
  auto itr = map.find("fe_config_md5");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_FEATURE_STR(({"077426a91f0000c40084c18688b3bcd7"}), itr->second);

  auto itr00 = map.find("f15");
  TEST_ASSERT_BOOL(itr00 != map.end());
  TEST_FEATURE_INT64(({100}), itr00->second);

  // batch为2
  qinglong::FeRequest request2;

  request2.set_request_time(-1);
  request2.set_callback_req_ts(20);

  request2.add_item_feature();
  request2.add_item_feature();

  std::string request_str2;
  request2.SerializeToString(&request_str2);

  bool flag = false;
  try {
    to_single_sequence_example(request_str2.c_str(), request_str2.length());
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  FUNC_TEST_END();
}

void test_calc_stats_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="calc_stats" source="E@.item_feature.item_feature_se.context.feature.float" data_type="float" default_value="0.2" />
            <feature name="f11" type="direct" source="f10:0" strategy="empty" />
            <feature name="f12" type="direct" source="f10:1" strategy="empty" />
            <feature name="f13" type="direct" source="f10:2" strategy="empty" />
            <feature name="f14" type="direct" source="f10:3" strategy="empty" />
            <feature name="f20" type="calc_stats" source="E@.item_feature.item_feature_se.context.feature.num" data_type="int64" />
            <feature name="f21" type="direct" source="f20:0" strategy="empty" />
            <feature name="f22" type="direct" source="f20:1" strategy="empty" />
            <feature name="f23" type="direct" source="f20:2" strategy="empty" />
            <feature name="f24" type="direct" source="f20:3" strategy="empty" />
            <feature name="f30" type="calc_stats" source="E@.item_feature.item_feature_se.context.feature.app_id" data_type="string" />
            <feature name="f31" type="direct" source="f30:0" strategy="empty" />
            <feature name="f32" type="direct" source="f30:1" strategy="empty" />
            <feature name="f33" type="direct" source="f30:2" strategy="empty" />
            <feature name="f34" type="direct" source="f30:3" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
      <input name="f11" shape="1" type="sparse" />
      <input name="f12" shape="1" type="sparse" />
      <input name="f13" shape="1" type="sparse" />
      <input name="f14" shape="1" type="sparse" />
      <input name="f21" shape="1" type="sparse" />
      <input name="f22" shape="1" type="sparse" />
      <input name="f23" shape="1" type="sparse" />
      <input name="f24" shape="1" type="sparse" />
      <input name="f31" shape="1" type="sparse" />
      <input name="f32" shape="1" type="sparse" dtype="float" />
      <input name="f33" shape="1" type="sparse" dtype="int64" />
      <input name="f34" shape="1" type="sparse" dtype="int64" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(15, vec.size());
  CalcStatsConfig* config = dynamic_cast<CalcStatsConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(12, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(0.8);
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(2.1);
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(0.4);

  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(3);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(7);

  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app");

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f11");
  auto itr10 = map01.find("f11");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({3}), itr00->second);
  TEST_FEATURE_INT64(({0}), itr10->second);

  auto itr01 = map00.find("f12");
  auto itr11 = map01.find("f12");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_FLOAT(({1.1}), itr01->second);
  TEST_FEATURE_FLOAT(({0.2}), itr11->second);

  auto itr02 = map00.find("f13");
  auto itr12 = map01.find("f13");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_FLOAT(({2.1}), itr02->second);
  TEST_FEATURE_FLOAT(({0.2}), itr12->second);

  auto itr03 = map00.find("f14");
  auto itr13 = map01.find("f14");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());

  TEST_FEATURE_FLOAT(({3.3}), itr03->second);
  TEST_FEATURE_FLOAT(({0.2}), itr13->second);

  auto itr04 = map00.find("f21");
  auto itr14 = map01.find("f21");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_ASSERT_BOOL(itr14 != map01.end());

  TEST_FEATURE_INT64(({2}), itr04->second);
  TEST_FEATURE_INT64(({0}), itr14->second);

  auto itr05 = map00.find("f22");
  auto itr15 = map01.find("f22");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_ASSERT_BOOL(itr15 != map01.end());

  TEST_FEATURE_FLOAT(({5}), itr05->second);
  TEST_FEATURE_FLOAT(({0}), itr15->second);

  auto itr06 = map00.find("f23");
  auto itr16 = map01.find("f23");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_ASSERT_BOOL(itr16 != map01.end());

  TEST_FEATURE_INT64(({7}), itr06->second);
  TEST_FEATURE_INT64(({0}), itr16->second);

  auto itr07 = map00.find("f24");
  auto itr17 = map01.find("f24");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_ASSERT_BOOL(itr17 != map01.end());

  TEST_FEATURE_INT64(({10}), itr07->second);
  TEST_FEATURE_INT64(({0}), itr17->second);

  auto itr08 = map00.find("f31");
  auto itr18 = map01.find("f31");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_ASSERT_BOOL(itr18 != map01.end());

  TEST_FEATURE_INT64(({1}), itr08->second);
  TEST_FEATURE_INT64(({0}), itr18->second);

  auto itr09 = map00.find("f32");
  auto itr19 = map01.find("f32");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_ASSERT_BOOL(itr19 != map01.end());

  TEST_FEATURE_FLOAT(({}), itr09->second);
  TEST_FEATURE_FLOAT(({}), itr19->second);

  auto itr010 = map00.find("f33");
  auto itr20 = map01.find("f33");
  TEST_ASSERT_BOOL(itr010 != map00.end());
  TEST_ASSERT_BOOL(itr20 != map01.end());

  TEST_FEATURE_INT64(({}), itr010->second);
  TEST_FEATURE_INT64(({}), itr20->second);

  auto itr011 = map00.find("f34");
  auto itr21 = map01.find("f34");
  TEST_ASSERT_BOOL(itr011 != map00.end());
  TEST_ASSERT_BOOL(itr21 != map01.end());

  TEST_FEATURE_INT64(({}), itr011->second);
  TEST_FEATURE_INT64(({}), itr21->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f11_values");
  auto itr_indices0 = map.find("f11_indices");
  auto itr_dense_shape0 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({3, 0}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f12_values");
  auto itr_indices1 = map.find("f12_indices");
  auto itr_dense_shape1 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0}), ({2, 1}), ({1.1, 0.2}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f13_values");
  auto itr_indices2 = map.find("f13_indices");
  auto itr_dense_shape2 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0}), ({2, 1}), ({2.1, 0.2}),
                            itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f14_values");
  auto itr_indices3 = map.find("f14_indices");
  auto itr_dense_shape3 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0}), ({2, 1}), ({3.3, 0.2}),
                            itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  auto itr_values4 = map.find("f21_values");
  auto itr_indices4 = map.find("f21_indices");
  auto itr_dense_shape4 = map.find("f21_dense_shape");
  TEST_ASSERT_BOOL(itr_values4 != map.end());
  TEST_ASSERT_BOOL(itr_indices4 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape4 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({2, 0}),
                            itr_indices4->second, itr_dense_shape4->second, itr_values4->second);

  auto itr_values5 = map.find("f22_values");
  auto itr_indices5 = map.find("f22_indices");
  auto itr_dense_shape5 = map.find("f22_dense_shape");
  TEST_ASSERT_BOOL(itr_values5 != map.end());
  TEST_ASSERT_BOOL(itr_indices5 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape5 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0}), ({2, 1}), ({5, 0}),
                            itr_indices5->second, itr_dense_shape5->second, itr_values5->second);

  auto itr_values6 = map.find("f23_values");
  auto itr_indices6 = map.find("f23_indices");
  auto itr_dense_shape6 = map.find("f23_dense_shape");
  TEST_ASSERT_BOOL(itr_values6 != map.end());
  TEST_ASSERT_BOOL(itr_indices6 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape6 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({7, 0}),
                            itr_indices6->second, itr_dense_shape6->second, itr_values6->second);

  auto itr_values7 = map.find("f24_values");
  auto itr_indices7 = map.find("f24_indices");
  auto itr_dense_shape7 = map.find("f24_dense_shape");
  TEST_ASSERT_BOOL(itr_values7 != map.end());
  TEST_ASSERT_BOOL(itr_indices7 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape7 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({10, 0}),
                            itr_indices7->second, itr_dense_shape7->second, itr_values7->second);

  auto itr_values8 = map.find("f31_values");
  auto itr_indices8 = map.find("f31_indices");
  auto itr_dense_shape8 = map.find("f31_dense_shape");
  TEST_ASSERT_BOOL(itr_values8 != map.end());
  TEST_ASSERT_BOOL(itr_indices8 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape8 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({1, 0}),
                            itr_indices8->second, itr_dense_shape8->second, itr_values8->second);

  auto itr_values9 = map.find("f32_values");
  auto itr_indices9 = map.find("f32_indices");
  auto itr_dense_shape9 = map.find("f32_dense_shape");
  TEST_ASSERT_BOOL(itr_values9 != map.end());
  TEST_ASSERT_BOOL(itr_indices9 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape9 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({}), ({2, 0}), ({}),
                            itr_indices9->second, itr_dense_shape9->second, itr_values9->second);

  auto itr_values10 = map.find("f33_values");
  auto itr_indices10 = map.find("f33_indices");
  auto itr_dense_shape10 = map.find("f33_dense_shape");
  TEST_ASSERT_BOOL(itr_values10 != map.end());
  TEST_ASSERT_BOOL(itr_indices10 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape10 != map.end());

  TEST_SPARSE_TENSOR_INT64(({}), ({2, 0}), ({}),
                            itr_indices10->second, itr_dense_shape10->second, itr_values10->second);

  auto itr_values11 = map.find("f34_values");
  auto itr_indices11 = map.find("f34_indices");
  auto itr_dense_shape11 = map.find("f34_dense_shape");
  TEST_ASSERT_BOOL(itr_values11 != map.end());
  TEST_ASSERT_BOOL(itr_indices11 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape11 != map.end());

  TEST_SPARSE_TENSOR_INT64(({}), ({2, 0}), ({}),
                            itr_indices11->second, itr_dense_shape11->second, itr_values11->second);

  FUNC_TEST_END();
}

void test_calc_stats_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="calc_stats" source="E@.item_feature.item_feature_se.feature_lists.feature_list.float" data_type="float" strategy="empty" />
            <feature name="f11" type="direct" source="f10:0" strategy="empty" />
            <feature name="f12" type="direct" source="f10:1" strategy="empty" />
            <feature name="f13" type="direct" source="f10:2" strategy="empty" />
            <feature name="f14" type="direct" source="f10:3" strategy="empty" />
            <feature name="f20" type="calc_stats" source="E@.item_feature.item_feature_se.feature_lists.feature_list.num" data_type="int64" strategy="empty" />
            <feature name="f21" type="direct" source="f20:0" strategy="empty" />
            <feature name="f22" type="direct" source="f20:1" strategy="empty" />
            <feature name="f23" type="direct" source="f20:2" strategy="empty" />
            <feature name="f24" type="direct" source="f20:3" strategy="empty" />
            <feature name="f30" type="calc_stats" source="E@.item_feature.item_feature_se.feature_lists.feature_list.app_id" data_type="string" strategy="empty" />
            <feature name="f31" type="direct" source="f30:0" strategy="empty" />
            <feature name="f32" type="direct" source="f30:1" strategy="empty" />
            <feature name="f33" type="direct" source="f30:2" strategy="empty" />
            <feature name="f34" type="direct" source="f30:3" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
      <input name="f11" shape="1" type="sparse" />
      <input name="f12" shape="1" type="sparse" />
      <input name="f13" shape="1" type="sparse" />
      <input name="f14" shape="1" type="sparse" />
      <input name="f21" shape="1" type="sparse" />
      <input name="f22" shape="1" type="sparse" />
      <input name="f23" shape="1" type="sparse" />
      <input name="f24" shape="1" type="sparse" />
      <input name="f31" shape="1" type="sparse" />
      <input name="f32" shape="1" type="sparse" dtype="float" />
      <input name="f33" shape="1" type="sparse" dtype="int64" />
      <input name="f34" shape="1" type="sparse" dtype="int64" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(15, vec.size());
  CalcStatsConfig* config = dynamic_cast<CalcStatsConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(12, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto &item_feature_list_map = *(item->mutable_feature_lists()->mutable_feature_list());
  auto feature = item_feature_list_map["float"].add_feature();
  feature->mutable_float_list()->add_value(0.8);
  feature->mutable_float_list()->add_value(1.1);
  (item_feature_list_map["float"].add_feature())->mutable_float_list()->add_value(2.1);
  (item_feature_list_map["float"].add_feature())->mutable_float_list()->add_value(0.4);

  (item_feature_list_map["num"].add_feature())->mutable_int64_list()->add_value(3);

  (item_feature_list_map["app_id"].add_feature())->mutable_bytes_list()->add_value("app");
  (item_feature_list_map["app_id"].add_feature())->mutable_bytes_list()->add_value("app");

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f11");
  auto itr10 = map01.find("f11");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({4}), itr00->second);
  TEST_FEATURE_INT64(({0}), itr10->second);

  auto itr01 = map00.find("f12");
  auto itr11 = map01.find("f12");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_FLOAT(({1.1}), itr01->second);
  TEST_FEATURE_FLOAT(({}), itr11->second);

  auto itr02 = map00.find("f13");
  auto itr12 = map01.find("f13");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_FLOAT(({2.1}), itr02->second);
  TEST_FEATURE_FLOAT(({}), itr12->second);

  auto itr03 = map00.find("f14");
  auto itr13 = map01.find("f14");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());

  TEST_FEATURE_FLOAT(({4.4}), itr03->second);
  TEST_FEATURE_FLOAT(({}), itr13->second);

  auto itr04 = map00.find("f21");
  auto itr14 = map01.find("f21");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_ASSERT_BOOL(itr14 != map01.end());

  TEST_FEATURE_INT64(({1}), itr04->second);
  TEST_FEATURE_INT64(({0}), itr14->second);

  auto itr05 = map00.find("f22");
  auto itr15 = map01.find("f22");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_ASSERT_BOOL(itr15 != map01.end());

  TEST_FEATURE_FLOAT(({3}), itr05->second);
  TEST_FEATURE_FLOAT(({}), itr15->second);

  auto itr06 = map00.find("f23");
  auto itr16 = map01.find("f23");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_ASSERT_BOOL(itr16 != map01.end());

  TEST_FEATURE_INT64(({3}), itr06->second);
  TEST_FEATURE_INT64(({}), itr16->second);

  auto itr07 = map00.find("f24");
  auto itr17 = map01.find("f24");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_ASSERT_BOOL(itr17 != map01.end());

  TEST_FEATURE_INT64(({3}), itr07->second);
  TEST_FEATURE_INT64(({}), itr17->second);

  auto itr08 = map00.find("f31");
  auto itr18 = map01.find("f31");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_ASSERT_BOOL(itr18 != map01.end());

  TEST_FEATURE_INT64(({2}), itr08->second);
  TEST_FEATURE_INT64(({0}), itr18->second);

  auto itr09 = map00.find("f32");
  auto itr19 = map01.find("f32");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_ASSERT_BOOL(itr19 != map01.end());

  TEST_FEATURE_FLOAT(({}), itr09->second);
  TEST_FEATURE_FLOAT(({}), itr19->second);

  auto itr010 = map00.find("f33");
  auto itr20 = map01.find("f33");
  TEST_ASSERT_BOOL(itr010 != map00.end());
  TEST_ASSERT_BOOL(itr20 != map01.end());

  TEST_FEATURE_INT64(({}), itr010->second);
  TEST_FEATURE_INT64(({}), itr20->second);

  auto itr011 = map00.find("f34");
  auto itr21 = map01.find("f34");
  TEST_ASSERT_BOOL(itr011 != map00.end());
  TEST_ASSERT_BOOL(itr21 != map01.end());

  TEST_FEATURE_INT64(({}), itr011->second);
  TEST_FEATURE_INT64(({}), itr21->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f11_values");
  auto itr_indices0 = map.find("f11_indices");
  auto itr_dense_shape0 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({4, 0}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f12_values");
  auto itr_indices1 = map.find("f12_indices");
  auto itr_dense_shape1 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0}), ({2, 1}), ({1.1}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f13_values");
  auto itr_indices2 = map.find("f13_indices");
  auto itr_dense_shape2 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0}), ({2, 1}), ({2.1}),
                            itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f14_values");
  auto itr_indices3 = map.find("f14_indices");
  auto itr_dense_shape3 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0}), ({2, 1}), ({4.4}),
                            itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  auto itr_values4 = map.find("f21_values");
  auto itr_indices4 = map.find("f21_indices");
  auto itr_dense_shape4 = map.find("f21_dense_shape");
  TEST_ASSERT_BOOL(itr_values4 != map.end());
  TEST_ASSERT_BOOL(itr_indices4 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape4 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({1, 0}),
                            itr_indices4->second, itr_dense_shape4->second, itr_values4->second);

  auto itr_values5 = map.find("f22_values");
  auto itr_indices5 = map.find("f22_indices");
  auto itr_dense_shape5 = map.find("f22_dense_shape");
  TEST_ASSERT_BOOL(itr_values5 != map.end());
  TEST_ASSERT_BOOL(itr_indices5 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape5 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0}), ({2, 1}), ({3}),
                            itr_indices5->second, itr_dense_shape5->second, itr_values5->second);

  auto itr_values6 = map.find("f23_values");
  auto itr_indices6 = map.find("f23_indices");
  auto itr_dense_shape6 = map.find("f23_dense_shape");
  TEST_ASSERT_BOOL(itr_values6 != map.end());
  TEST_ASSERT_BOOL(itr_indices6 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape6 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({2, 1}), ({3}),
                            itr_indices6->second, itr_dense_shape6->second, itr_values6->second);

  auto itr_values7 = map.find("f24_values");
  auto itr_indices7 = map.find("f24_indices");
  auto itr_dense_shape7 = map.find("f24_dense_shape");
  TEST_ASSERT_BOOL(itr_values7 != map.end());
  TEST_ASSERT_BOOL(itr_indices7 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape7 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({2, 1}), ({3}),
                            itr_indices7->second, itr_dense_shape7->second, itr_values7->second);

  auto itr_values8 = map.find("f31_values");
  auto itr_indices8 = map.find("f31_indices");
  auto itr_dense_shape8 = map.find("f31_dense_shape");
  TEST_ASSERT_BOOL(itr_values8 != map.end());
  TEST_ASSERT_BOOL(itr_indices8 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape8 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({2, 0}),
                            itr_indices8->second, itr_dense_shape8->second, itr_values8->second);

  auto itr_values9 = map.find("f32_values");
  auto itr_indices9 = map.find("f32_indices");
  auto itr_dense_shape9 = map.find("f32_dense_shape");
  TEST_ASSERT_BOOL(itr_values9 != map.end());
  TEST_ASSERT_BOOL(itr_indices9 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape9 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({}), ({2, 0}), ({}),
                            itr_indices9->second, itr_dense_shape9->second, itr_values9->second);

  auto itr_values10 = map.find("f33_values");
  auto itr_indices10 = map.find("f33_indices");
  auto itr_dense_shape10 = map.find("f33_dense_shape");
  TEST_ASSERT_BOOL(itr_values10 != map.end());
  TEST_ASSERT_BOOL(itr_indices10 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape10 != map.end());

  TEST_SPARSE_TENSOR_INT64(({}), ({2, 0}), ({}),
                            itr_indices10->second, itr_dense_shape10->second, itr_values10->second);

  auto itr_values11 = map.find("f34_values");
  auto itr_indices11 = map.find("f34_indices");
  auto itr_dense_shape11 = map.find("f34_dense_shape");
  TEST_ASSERT_BOOL(itr_values11 != map.end());
  TEST_ASSERT_BOOL(itr_indices11 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape11 != map.end());

  TEST_SPARSE_TENSOR_INT64(({}), ({2, 0}), ({}),
                            itr_indices11->second, itr_dense_shape11->second, itr_values11->second);

  FUNC_TEST_END();
}

void test_single_sequence_example_with_param() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "get_valid_value", 
          "source": [".request_time",
                      ".callback_req_ts"]
      }
    }
  })";

  init_offline_by_content(str.c_str());

  // batch为1
  qinglong::FeRequest request;
  request.set_request_time(100);
  request.set_callback_req_ts(20);
  request.add_item_feature();
  std::string fe_request_str;
  request.SerializeToString(&fe_request_str);

  tensorflow::SequenceExample seq_param;
  (*(seq_param.mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");
  (*(seq_param.mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid1");
  (*(seq_param.mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid2");
  std::string sequence_param_str;
  seq_param.SerializeToString(&sequence_param_str);
  
  std::string result_str = to_single_sequence_example_with_param(fe_request_str.c_str(), fe_request_str.length(),
                                                                 sequence_param_str.c_str(), sequence_param_str.length());

  tensorflow::SequenceExample result;
  result.ParseFromString(result_str);
  TEST_ASSERT_EQUAL(true, result.has_context());
  const auto& map = result.context().feature();
  auto itr = map.find("fe_config_md5");
  TEST_ASSERT_BOOL(itr != map.end());
  TEST_FEATURE_STR(({"077426a91f0000c40084c18688b3bcd7"}), itr->second);
  auto itr00 = map.find("f15");
  TEST_ASSERT_BOOL(itr00 != map.end()); 
  TEST_FEATURE_INT64(({100}), itr00->second);
  
  auto itr_item = map.find("item");
  auto feat = itr_item->second;
  uint32_t size = feat.bytes_list().value_size();
  std::cout<<"f15 item  feature size:" << size <<std::endl; 
  std::cout<<"f15 item feature values:"<< std::endl; 
  for (uint32_t j = 0; j < size; j++) { 
    std::cout<<"no"<< j <<": "; 
    std::cout<< feat.bytes_list().value(j) << std::endl;  
  }  
  TEST_FEATURE_STR(({"appid0", "appid1", "appid2"}), itr_item->second);
  
  // 空请求参数
  qinglong::FeRequest request2;
  request2.set_request_time(-1);
  request2.set_callback_req_ts(20);
  request2.add_item_feature();
  std::string request_str2;
  request2.SerializeToString(&request_str2);

  std::string sequence_param_str2;
  tensorflow::SequenceExample seq_param2;
  seq_param2.SerializeToString(&sequence_param_str2); 

  std::string result_str2 = to_single_sequence_example_with_param(request_str2.c_str(), request_str2.length(),
                                                                  sequence_param_str2.c_str(), sequence_param_str2.length());

  tensorflow::SequenceExample result2;
  result2.ParseFromString(result_str2);
  TEST_ASSERT_EQUAL(true, result2.has_context());
  const auto& map2 = result2.context().feature();
  auto itr20 = map2.find("fe_config_md5");
  TEST_ASSERT_BOOL(itr20 != map.end());
  TEST_FEATURE_STR(({"077426a91f0000c40084c18688b3bcd7"}), itr20->second);
 
  auto itr21 = map.find("f15");
  TEST_ASSERT_BOOL(itr21 != map.end()); 

  auto feat2 = itr21->second;
  uint32_t size2 = feat2.int64_list().value_size();
  std::cout<<"test2 f15 size:" << size2 <<std::endl; 
  std::cout<<"test2 f15 values:"<< std::endl; 
  for (uint32_t j = 0; j < size2; j++) { 
    std::cout<<"no"<< j <<": "; 
    std::cout<< feat2.int64_list().value(j) << std::endl;  
  }   
  TEST_FEATURE_INT64(({100}), itr21->second);

  //错误请求参数
  std::string sequence_param_str3 = "1234";
  try {
    std::string result_str3 = to_single_sequence_example_with_param(request_str2.c_str(), request_str2.length(),
                                                                    sequence_param_str3.c_str(), sequence_param_str3.length());
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
  }

  FUNC_TEST_END();
}

void test_repetition_list_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
          <config>
              <features>
                  <feature name="f11" type="repetition_list" source=".item_feature.item_feature_se.feature_lists.feature_list.query_word1,.item_feature.item_feature_se.feature_lists.feature_list.query_word2" strategy="empty" />
                  <feature name="f12" type="direct" source="f11" strategy="empty" />
  
            </features>
          </config>
      )";
  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "",
                                  vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  RepetitionListConfig *conf =
      dynamic_cast<RepetitionListConfig *>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::FeRequest request;
  tensorflow::SequenceExample *item =
      request.add_item_feature()->mutable_item_feature_se();
  auto &item_feature_list_map =
      *(item->mutable_feature_lists()->mutable_feature_list());
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("天");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("天");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("天");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("气");

  (item_feature_list_map["query_word2"].add_feature())
      ->mutable_bytes_list()
      ->add_value("天");
  (item_feature_list_map["query_word2"].add_feature())
      ->mutable_bytes_list()
      ->add_value("气");
  float expected_value =
      (3 * 1 + 1 * 1) / (std::sqrt((std::pow(3, 2) + std::pow(1, 1))) *
                         std::sqrt(std::pow(1, 1) + std::pow(1, 1)));

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto &map00 = batch_ret.batch(0).context().feature();

  auto itr01 = map00.find("f12");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_EQUAL(itr01->second.float_list().value(0), expected_value);

  config_str = R"(
        <config>
            <features>
                <feature name="f11" type="repetition_list" source=".item_feature.item_feature_se.context.feature.query_word1,.item_feature.item_feature_se.context.feature.query_word2" strategy="empty" />
                <feature name="f12" type="direct" source="f11" strategy="empty" />

          </features>
        </config>
    )";
  request.Clear();
  batch_ret.Clear();
  vec.clear();
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);
  item = request.add_item_feature()->mutable_item_feature_se();
  auto &item_feature_map = *(item->mutable_context()->mutable_feature());
  item_feature_map["query_word1"].mutable_bytes_list()->add_value("天");
  item_feature_map["query_word1"].mutable_bytes_list()->add_value("天");
  item_feature_map["query_word1"].mutable_bytes_list()->add_value("天");
  item_feature_map["query_word1"].mutable_bytes_list()->add_value("气");

  item_feature_map["query_word2"].mutable_bytes_list()->add_value("天");
  item_feature_map["query_word2"].mutable_bytes_list()->add_value("气");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto &map01 = batch_ret.batch(0).context().feature();

  auto itr02 = map01.find("f12");
  TEST_ASSERT_BOOL(itr02 != map01.end());
  TEST_ASSERT_EQUAL(itr02->second.float_list().value(0), expected_value);

  FUNC_TEST_END();
}

void test_repetition_list_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
            <config>
                <features>
                    <feature name="f11" type="repetition_list" source=".item_feature.item_feature_se.feature_lists.feature_list.query_word1,.item_feature.item_feature_se.feature_lists.feature_list.query_word2" strategy="empty" />
                    <feature name="f12" type="direct" source="f11" strategy="empty" />
    
              </features>
            </config>
        )";

  std::string in_str = R"(
        <model_input_config>
            <input name="f12" shape="1" type="dense" />
        </model_input_config>
      )";

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<Config>> vec;
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  std::vector<std::shared_ptr<Config>> need_vec;

  
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());

  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);



  RepetitionListConfig *conf =
      dynamic_cast<RepetitionListConfig *>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  tensorflow::SequenceExample *item =
      request.add_item_feature()->mutable_item_feature_se();
  auto &item_feature_list_map =
      *(item->mutable_feature_lists()->mutable_feature_list());
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("荣耀");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("王者");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("天");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("气");

  (item_feature_list_map["query_word2"].add_feature())
      ->mutable_bytes_list()
      ->add_value("天");
  (item_feature_list_map["query_word2"].add_feature())
      ->mutable_bytes_list()
      ->add_value("气");
  float expected_value =
      (1 * 1 + 1 * 1) / (std::sqrt((std::pow(1, 1) + std::pow(1, 1)) + std::pow(1, 1) + std::pow(1, 1)) *
                         std::sqrt(std::pow(1, 1) + std::pow(1, 1)));

  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto &map = ret.inputs();

  auto itr0 = map.find("f12");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_LIST_FLOAT(({expected_value}), itr0->second);

  FUNC_TEST_END();
}

void test_base() {
  test_repetition_list_2();
  test_repetition_list_1();
  test_input();
  test_input_repeated_count();
  test_parse_model_input0();
  test_parse_model_input1();

  test_map();
  test_map_and_default_value1();
  test_map_and_default_value2();

  test_bucketized();
  test_bucketized_2();
  test_bucketized_3();

  test_hash();
  test_hash_bucket_and_default_value1();
  test_hash_bucket_and_default_value2();
  test_hash_bucket_and_default_value3();
  test_hash_bucket_and_concat_with_name();

  test_expo_123_count();
  test_expo_123_count_2();

  test_expo_123_countv2_1();
  test_expo_123_countv2_2();
  test_expo_123_countv2_3();

  test_filter_appid();
  test_filter_appid_max_len();
  test_filter_appid_2();

  test_appid_cross();
  test_appid_cross_2();
  test_appid_cross_3();

  test_to_feature();
  test_to_feature_2();
  test_to_feature_3();

  test_vocab_list_not_find();

  test_predict_dense_0();
  test_predict_dense_1();
  test_predict_dense_2();
  test_predict_dense_3();

  test_predict_sparse_0();
  test_predict_sparse_1();
  test_predict_sparse_2();
  test_predict_sparse_3();

  test_predict_sequence_0();
  test_predict_sequence_1();
  test_predict_sequence_2();
  test_predict_sequence_3();

  test_nearest_expo_days();
  test_nearest_expo_days_2();
  test_nearest_expo_days_3();
  test_nearest_expo_days_4();

  test_identity();
  test_identity_2();

  test_direct_list();
  test_direct_list_2();

  test_item_to_class();

  test_to_batch_feature();
  test_to_batch_feature_2();

  test_max_expo_appid();
  test_max_expo_appid_2();
  test_max_expo_appid_3();

  test_nearest_expo_appid();
  test_nearest_expo_appid_2();
  test_nearest_expo_appid_3();

  test_expo_appid_count();
  test_expo_appid_count_2();

  test_expo_appid_count_v2();
  test_expo_appid_count_v2_2();
  test_expo_appid_count_v2_3();

  test_max_123_class();
  test_max_123_class_2();
  test_max_123_class_3();

  test_direct_1();
  //test_direct_2();
  test_direct_3();
  test_direct_4();

  test_useraction();

  test_empty_feature();
  test_empty_felist();

  test_string_to_int64_1();
  test_string_to_int64_2();

  test_appid_to_123_class_1();
  test_appid_to_123_class_2();
  test_appid_to_123_class_3();

  test_is_match_str_1();
  test_is_match_str_2();

  test_trans_type_1();
  test_trans_type_2();

  test_fully_cross_1();
  test_fully_cross_2();
  test_fully_cross_3();
  test_fully_cross_4();

  test_connect_1();
  test_connect_2();
  test_connect_3();
  test_connect_4();
  test_connect_5();
  test_connect_6();
  test_connect_7();

  test_connect_all_to_string_1();
  test_connect_all_to_string_2();
  test_connect_all_to_string_3();
  test_connect_all_to_string_4();

  test_cross_hash_bits_1();
  test_cross_hash_bits_2();
  test_cross_hash_bits_3();
  test_cross_hash_bits_4();

  test_cross_hash_bits_v2_1();
  test_cross_hash_bits_v2_2();

  test_get_valid_value_1();
  test_get_valid_value_2();
  test_get_valid_value_3();

  test_get_valid_value_v2_1();
  test_get_valid_value_v2_2();
  test_get_valid_value_v2_3();

  test_act_value_1();
  test_act_value_2();
  test_act_value_3();

  test_int64_offset_1();
  test_int64_offset_2();

  test_int64_difference_1();
  test_int64_difference_2();

  test_clip_1();
  test_clip_2();

  test_exists();
  test_len_diff();
  test_len_ratio();

  test_calc_stats_1();
  test_calc_stats_2();

  test_vocab_set_1();
  test_vocab_set_2();
  test_vocab_set_3();

  test_vocab_map_1();
  test_vocab_map_2();
  test_vocab_map_3();
  test_vocab_map_4();

  test_segment_1();
  test_segment_2();

  test_dict_to_attributes_v2_1();
  test_dict_to_attributes_v2_2();
  test_dict_to_attributes_v2_3();
  test_dict_to_attributes_v2_4();

  test_dict_to_attributes_1();
  test_dict_to_attributes_2();
  test_dict_to_attributes_3();

  test_conditional_filter_1();
  test_conditional_filter_2();
  test_conditional_filter_3();

  test_message_filter_1();
  test_message_filter_2();
  test_message_filter_3();

  test_message_filter_v2_1();
  test_message_filter_v2_2();
  test_message_filter_v2_3();
  test_message_filter_v2_4();
  test_message_filter_v2_5();

  test_message_filter_select_1();
  test_message_filter_select_2();
  test_message_filter_select_3();

  test_strategy();
  test_hash_slot();
  test_hash_slot_2();
  test_hash_slot_3();
  test_default_type();

  test_throw();
  test_throw_online();

  test_double_1();
  test_double_2();

  test_select_config();

  test_direct_to_feature();
  test_direct_to_feature_v2();

  test_feature_md5_1();
  test_feature_md5_2();

  test_decode_config();

  test_xml();
  test_xml_item_map();
  test_item_map_xml();
  test_app_info_xml();
  test_item_map_and_app_info();
  test_versions();
  test_macro_replace();

  test_single_sequence_example();
  test_single_sequence_example_with_param(); 

  test_merge();
  test_all();
}