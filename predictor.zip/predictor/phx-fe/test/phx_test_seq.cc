#include "phx-fe/src/service.h"
#include "phx_test.h"
#include <fstream>
#include <iostream>
// seq类算子
TEST_SUITE("seq") {
    TEST_CASE("SeqTopNCompute_test_1") {
        int64_t reserve = 0;
        int64_t clip_size = 10;
        phx_fe::SortType type = phx_fe::SortType::ByTimestamp;
        phx_fe::SeqTopNCompute top_n_compute_1(type, clip_size, reserve);

        std::vector<phx_fe::ClassNameWithEventTime> class_info_vec;
        std::vector<phx_fe::ClassNameWithEventTime *> sorted_class_info_vec_ptr;
        std::vector<std::string> names = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        for (uint32_t i = 0; i < names.size(); i++) {
            class_info_vec.emplace_back(&names[i], ((i + 1) * 23) % 21);
            class_info_vec.emplace_back(&names[i], ((i + 1) * 17) % 21);
            class_info_vec.emplace_back(&names[i], ((i + 1) * 13) % 21);
        }

        /* 1  1   1   2  2   2  3  3  3   4  4  4   5   5  5  6   6   6   7   7   7  8   8   8   9   9  9   10  10  10
           2  17  13  4  13  5  6  9  18  8  5  10  10  1  2  12  18  15  14  14  7  16  10  20  18  6  12  20   2  4 */

        std::vector<std::string> out_str_1 = {"10", "8", "9", "3", "6", "1", "8", "6", "7", "7"};
        std::vector<int64_t> out_int_1 = {20, 20, 18, 18, 18, 17, 16, 15, 14, 14};
        std::vector<phx_fe::ClassNameWithEventTime> temp_1(class_info_vec);

        top_n_compute_1.compute_vec(temp_1, &sorted_class_info_vec_ptr);
        CHECK_EQ(10, sorted_class_info_vec_ptr.size());
        for (uint32_t i = 0; i < sorted_class_info_vec_ptr.size(); i++) {
            CHECK_EQ(*(sorted_class_info_vec_ptr[i]->class_name), out_str_1[i]);
            CHECK_EQ(sorted_class_info_vec_ptr[i]->event_time, out_int_1[i]);
        }

        reserve = 1;
        phx_fe::SeqTopNCompute top_n_compute_2(type, clip_size, reserve);
        sorted_class_info_vec_ptr.clear();
        std::vector<phx_fe::ClassNameWithEventTime> temp_2(class_info_vec);
        std::vector<std::string> out_str_2 = {"5", "10", "1", "5", "10", "2", "2", "4", "3", "9"};
        std::vector<int64_t> out_int_2 = {1, 2, 2, 2, 4, 4, 5, 5, 6, 6};

        top_n_compute_2.compute_vec(temp_2, &sorted_class_info_vec_ptr);
        CHECK_EQ(10, sorted_class_info_vec_ptr.size());
        for (uint32_t i = 0; i < sorted_class_info_vec_ptr.size(); i++) {
            CHECK_EQ(*(sorted_class_info_vec_ptr[i]->class_name), out_str_2[i]);
            CHECK_EQ(sorted_class_info_vec_ptr[i]->event_time, out_int_2[i]);
        }

        for (uint32_t i = 0; i < names.size(); i++) {
            uint32_t num = i % 4;
            for (uint32_t j = 0; j < num; j++) {
                class_info_vec.emplace_back(&names[i], ((i + 1) * (j + 1) * 17) % 21);
            }
        }

        /* 2   3   3  4  4   4   6   7   7  8   8   8  10
           13  9  18  5  10  15  18  14  7  10  20  9  2*/

        reserve = 0;
        type = phx_fe::SortType::ByCount;
        phx_fe::SeqTopNCompute top_n_compute_3(type, clip_size, reserve);
        sorted_class_info_vec_ptr.clear();
        std::vector<phx_fe::ClassNameWithEventTime> temp_3(class_info_vec);
        std::vector<std::string> out_str_3 = {"8", "4", "3", "7", "10", "6", "2", "9", "1", "5"};
        std::vector<int64_t> out_int_3 = {20, 15, 18, 14, 20, 18, 13, 18, 17, 10};

        top_n_compute_3.compute_vec(temp_3, &sorted_class_info_vec_ptr);
        CHECK_EQ(10, sorted_class_info_vec_ptr.size());
        for (uint32_t i = 0; i < sorted_class_info_vec_ptr.size(); i++) {
            CHECK_EQ(*(sorted_class_info_vec_ptr[i]->class_name), out_str_3[i]);
            CHECK_EQ(sorted_class_info_vec_ptr[i]->event_time, out_int_3[i]);
        }

        reserve = 1;
        phx_fe::SeqTopNCompute top_n_compute_4(type, clip_size, reserve);
        sorted_class_info_vec_ptr.clear();
        std::vector<phx_fe::ClassNameWithEventTime> temp_4(class_info_vec);
        std::vector<std::string> out_str_4 = {"9", "1", "5", "10", "6", "2", "3", "7", "8", "4"};
        std::vector<int64_t> out_int_4 = {18, 17, 10, 20, 18, 13, 18, 14, 20, 15};

        top_n_compute_4.compute_vec(temp_4, &sorted_class_info_vec_ptr);
        CHECK_EQ(10, sorted_class_info_vec_ptr.size());
        for (uint32_t i = 0; i < sorted_class_info_vec_ptr.size(); i++) {
            CHECK_EQ(*(sorted_class_info_vec_ptr[i]->class_name), out_str_4[i]);
            CHECK_EQ(sorted_class_info_vec_ptr[i]->event_time, out_int_4[i]);
        }
    }

    TEST_CASE("SeqTopNCompute_test_2") {
        int64_t reserve = 0;
        int64_t clip_size = 10;
        phx_fe::SortType type = phx_fe::SortType::ByTimestamp;
        phx_fe::SeqTopNCompute top_n_compute_1(type, clip_size, reserve);

        std::vector<phx_fe::AppIdWithEventTime> class_info_vec;
        std::vector<phx_fe::AppIdWithEventTime *> sorted_class_info_vec_ptr;
        std::vector<int64_t> names = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        for (uint32_t i = 0; i < names.size(); i++) {
            class_info_vec.emplace_back(names[i], ((i + 1) * 23) % 21);
            class_info_vec.emplace_back(names[i], ((i + 1) * 17) % 21);
            class_info_vec.emplace_back(names[i], ((i + 1) * 13) % 21);
        }

        /* 1  1   1   2  2   2  3  3  3   4  4  4   5   5  5  6   6   6   7   7   7  8   8   8   9   9  9   10  10  10
           2  17  13  4  13  5  6  9  18  8  5  10  10  1  2  12  18  15  14  14  7  16  10  20  18  6  12  20   2  4 */

        std::vector<int64_t> out_str_1 = {10, 8, 9, 3, 6, 1, 8, 6, 7, 7};
        std::vector<int64_t> out_int_1 = {20, 20, 18, 18, 18, 17, 16, 15, 14, 14};
        std::vector<phx_fe::AppIdWithEventTime> temp_1(class_info_vec);

        top_n_compute_1.compute_vec(temp_1, sorted_class_info_vec_ptr);
        CHECK_EQ(10, sorted_class_info_vec_ptr.size());
        for (uint32_t i = 0; i < sorted_class_info_vec_ptr.size(); i++) {
            CHECK_EQ(sorted_class_info_vec_ptr[i]->appid, out_str_1[i]);
            CHECK_EQ(sorted_class_info_vec_ptr[i]->eventtime, out_int_1[i]);
        }

        std::vector<phx_fe::AppIdWithEventTime *> class_info_vec_ptr;
        sorted_class_info_vec_ptr.clear();
        for (uint32_t i = 0; i < class_info_vec.size(); i++) {
            class_info_vec_ptr.emplace_back(&class_info_vec[i]);
        }
        top_n_compute_1.compute_ptr_vec(class_info_vec_ptr, sorted_class_info_vec_ptr);
        CHECK_EQ(10, sorted_class_info_vec_ptr.size());
        for (uint32_t i = 0; i < sorted_class_info_vec_ptr.size(); i++) {
            CHECK_EQ(sorted_class_info_vec_ptr[i]->appid, out_str_1[i]);
            CHECK_EQ(sorted_class_info_vec_ptr[i]->eventtime, out_int_1[i]);
        }

        reserve = 1;
        phx_fe::SeqTopNCompute top_n_compute_2(type, clip_size, reserve);
        sorted_class_info_vec_ptr.clear();
        std::vector<phx_fe::AppIdWithEventTime> temp_2(class_info_vec);
        std::vector<int64_t> out_str_2 = {5, 10, 1, 5, 10, 2, 2, 4, 3, 9};
        std::vector<int64_t> out_int_2 = {1, 2, 2, 2, 4, 4, 5, 5, 6, 6};

        top_n_compute_2.compute_vec(temp_2, sorted_class_info_vec_ptr);
        CHECK_EQ(10, sorted_class_info_vec_ptr.size());
        for (uint32_t i = 0; i < sorted_class_info_vec_ptr.size(); i++) {
            CHECK_EQ(sorted_class_info_vec_ptr[i]->appid, out_str_2[i]);
            CHECK_EQ(sorted_class_info_vec_ptr[i]->eventtime, out_int_2[i]);
        }

        class_info_vec_ptr.clear();
        sorted_class_info_vec_ptr.clear();
        for (uint32_t i = 0; i < class_info_vec.size(); i++) {
            class_info_vec_ptr.emplace_back(&class_info_vec[i]);
        }
        top_n_compute_2.compute_ptr_vec(class_info_vec_ptr, sorted_class_info_vec_ptr);
        CHECK_EQ(10, sorted_class_info_vec_ptr.size());
        for (uint32_t i = 0; i < sorted_class_info_vec_ptr.size(); i++) {
            CHECK_EQ(sorted_class_info_vec_ptr[i]->appid, out_str_2[i]);
            CHECK_EQ(sorted_class_info_vec_ptr[i]->eventtime, out_int_2[i]);
        }

        for (uint32_t i = 0; i < names.size(); i++) {
            uint32_t num = i % 4;
            for (uint32_t j = 0; j < num; j++) {
                class_info_vec.emplace_back(names[i], ((i + 1) * (j + 1) * 17) % 21);
            }
        }

        /* 2   3   3  4  4   4   6   7   7  8   8   8  10
           13  9  18  5  10  15  18  14  7  10  20  9  2*/

        reserve = 0;
        type = phx_fe::SortType::ByCount;
        phx_fe::SeqTopNCompute top_n_compute_3(type, clip_size, reserve);
        std::vector<std::pair<int64_t, int64_t>> out_vec;
        std::vector<phx_fe::AppIdWithEventTime> temp_3(class_info_vec);
        std::unordered_map<phx_fe::AppIdWithEventTime *, int64_t> appid_values;
        std::vector<int64_t> out_str_3 = {8, 4, 3, 7, 10, 6, 2, 9, 1, 5};
        std::vector<int64_t> out_int_3 = {6, 6, 5, 5, 4, 4, 4, 3, 3, 3};

        top_n_compute_3.compute_vec_with_value<int64_t>(temp_3, appid_values, out_vec);
        CHECK_EQ(10, out_vec.size());
        for (uint32_t i = 0; i < out_vec.size(); i++) {
            CHECK_EQ(out_vec[i].first, out_str_3[i]);
            CHECK_EQ(out_vec[i].second, out_int_3[i]);
        }

        reserve = 1;
        phx_fe::SeqTopNCompute top_n_compute_4(type, clip_size, reserve);
        out_vec.clear();
        std::vector<phx_fe::AppIdWithEventTime> temp_4(class_info_vec);
        std::vector<int64_t> out_str_4 = {9, 1, 5, 10, 6, 2, 3, 7, 8, 4};
        std::vector<int64_t> out_int_4 = {3, 3, 3, 4, 4, 4, 5, 5, 6, 6};

        top_n_compute_4.compute_vec_with_value<int64_t>(temp_4, appid_values, out_vec);
        CHECK_EQ(10, out_vec.size());
        for (uint32_t i = 0; i < out_vec.size(); i++) {
            CHECK_EQ(out_vec[i].first, out_str_4[i]);
            CHECK_EQ(out_vec[i].second, out_int_4[i]);
        }

        reserve = 0;
        type = phx_fe::SortType::ByValue;
        phx_fe::SeqTopNCompute top_n_compute_5(type, clip_size, reserve);
        out_vec.clear();
        std::vector<phx_fe::AppIdWithEventTime> temp_5(class_info_vec);
        std::vector<int64_t> out_str_5 = {4, 7, 8, 3, 2, 9, 5, 10, 6, 1};
        std::vector<int64_t> out_int_5 = {20, 20, 18, 14, 14, 12, 11, 7, 7, 3};
        for (uint32_t i = 0; i < temp_5.size(); i++) {
            appid_values[&temp_5[i]] = i % 7;
        }
        top_n_compute_5.compute_vec_with_value<int64_t>(temp_5, appid_values, out_vec);
        CHECK_EQ(10, out_vec.size());
        for (uint32_t i = 0; i < out_vec.size(); i++) {
            CHECK_EQ(out_vec[i].first, out_str_5[i]);
            CHECK_EQ(out_vec[i].second, out_int_5[i]);
        }

        reserve = 1;
        phx_fe::SeqTopNCompute top_n_compute_6(type, clip_size, reserve);
        out_vec.clear();
        std::vector<phx_fe::AppIdWithEventTime> temp_6(class_info_vec);
        std::vector<int64_t> out_str_6 = {1, 10, 6, 5, 9, 3, 2, 8, 4, 7};
        std::vector<int64_t> out_int_6 = {3, 7, 7, 11, 12, 14, 14, 18, 20, 20};
        appid_values.clear();
        for (uint32_t i = 0; i < temp_6.size(); i++) {
            appid_values[&temp_6[i]] = i % 7;
        }
        top_n_compute_6.compute_vec_with_value<int64_t>(temp_6, appid_values, out_vec);
        CHECK_EQ(10, out_vec.size());
        for (uint32_t i = 0; i < out_vec.size(); i++) {
            CHECK_EQ(out_vec[i].first, out_str_6[i]);
            CHECK_EQ(out_vec[i].second, out_int_6[i]);
        }
    }

    TEST_CASE("SeqTopNCompute_test_3") {
        int64_t reserve = 0;
        int64_t clip_size = 10;
        std::vector<tensorflow::Feature> message_vec(10);
        std::vector<std::pair<int64_t, const google::protobuf::Message *>> vec;
        for (uint32_t i = 0; i < message_vec.size(); i++) {
            message_vec[i].mutable_bytes_list()->add_value(std::to_string(i + 1));
            vec.emplace_back(i % 3, &message_vec[i]);
        }
        phx_fe::SortType type = phx_fe::SortType::ByTimestamp;
        phx_fe::SeqTopNCompute top_n_compute_1(type, clip_size, reserve);

        /* 1  2   3   4  5   6  7  8  9  10  
           0  1   2   0  1   2  0  1  2  0  */

        std::vector<const google::protobuf::Message *> topn_vec;
        std::vector<std::string> out_str_1 = {"3", "6", "9", "2", "5", "8", "1", "4", "7", "10"};

        top_n_compute_1.compute_vec(vec, topn_vec);
        CHECK_EQ(10, topn_vec.size());
        for (uint32_t i = 0; i < topn_vec.size(); i++) {
            const google::protobuf::Message *m = topn_vec[i];
            auto desc = m->GetDescriptor();
            auto ref = m->GetReflection();
            auto field = desc->FindFieldByName("bytes_list");
            m = &(ref->GetMessage(*m, field));

            desc = m->GetDescriptor();
            ref = m->GetReflection();
            field = desc->FindFieldByName("value");
            std::string name = ref->GetRepeatedString(*m, field, 0);

            CHECK_EQ(name, out_str_1[i]);
        }

        reserve = 1;
        phx_fe::SeqTopNCompute top_n_compute_2(type, clip_size, reserve);
        topn_vec.clear();
        vec.clear();
        for (uint32_t i = 0; i < message_vec.size(); i++) {
            vec.emplace_back(i % 3, &message_vec[i]);
        }
        std::vector<std::string> out_str_2 = {"1", "4", "7", "10", "2", "5", "8", "3", "6", "9"};

        top_n_compute_2.compute_vec(vec, topn_vec);
        CHECK_EQ(10, topn_vec.size());
        for (uint32_t i = 0; i < topn_vec.size(); i++) {
            const google::protobuf::Message *m = topn_vec[i];
            auto desc = m->GetDescriptor();
            auto ref = m->GetReflection();
            auto field = desc->FindFieldByName("bytes_list");
            m = &(ref->GetMessage(*m, field));

            desc = m->GetDescriptor();
            ref = m->GetReflection();
            field = desc->FindFieldByName("value");
            std::string name = ref->GetRepeatedString(*m, field, 0);

            CHECK_EQ(name, out_str_2[i]);
        }
    }

    TEST_CASE("seq_diff_daily_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816,10818,10819,10821,10822,10824,10825,10827,10828" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_daily" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time" start="864000" day_n="30" delta_day="10" status="0" clip_size="2" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_diff_daily" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time" start="864000" day_n="30" delta_day="10" status="1" clip_size="2" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                    <feature name="10817" slot="10817" type="seq_diff_daily" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.req_time" day_n="30" delta_day="10" status="0" clip_size="2" />
                    <feature name="10818" slot="10818" type="direct" source="10817:0" />
                    <feature name="10819" slot="10819" type="direct" source="10817:1" />
                    <feature name="10820" slot="10820" type="seq_diff_daily" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.req_time" day_n="30" delta_day="10" status="1" clip_size="2" />
                    <feature name="10821" slot="10821" type="direct" source="10820:0" />
                    <feature name="10822" slot="10822" type="direct" source="10820:1" />
                    <feature name="10823" slot="10823" type="seq_diff_daily" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time" delta_day="10" status="0" clip_size="3" />
                    <feature name="10824" slot="10824" type="direct" source="10823:0" />
                    <feature name="10825" slot="10825" type="direct" source="10823:1" />
                    <feature name="10826" slot="10826" type="seq_diff_daily" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time" delta_day="10" status="1" clip_size="3" />
                    <feature name="10827" slot="10827" type="direct" source="10826:0" />
                    <feature name="10828" slot="10828" type="direct" source="10826:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 100 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        //防穿越
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 102 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 86 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //活跃
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //长度截断
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 81 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 83 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //时间范围过滤
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);

        pb_use = fe_request.mutable_ad_user_app_seq_update_offline();

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 98 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 82 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 12);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10004}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 86 * 86400 * 1000, (int64_t) 83 * 86400 * 1000}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10002}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 84 * 86400 * 1000}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10818, ({10001, 10004}), ret.training_samples(0).features(4));
        TEST_SLOT_FEATURE_INT64(10819, ({(int64_t) 86 * 86400 * 1000, (int64_t) 83 * 86400 * 1000}),
                                ret.training_samples(0).features(5));
        TEST_SLOT_FEATURE_INT64(10821, ({10002}), ret.training_samples(0).features(6));
        TEST_SLOT_FEATURE_INT64(10822, ({(int64_t) 84 * 86400 * 1000}), ret.training_samples(0).features(7));
        TEST_SLOT_FEATURE_INT64(10824, ({10001, 10004, 10003}), ret.training_samples(0).features(8));
        TEST_SLOT_FEATURE_INT64(
                10825, ({(int64_t) 86 * 86400 * 1000, (int64_t) 83 * 86400 * 1000, (int64_t) 81 * 86400 * 1000}),
                ret.training_samples(0).features(9));
        TEST_SLOT_FEATURE_INT64(10827, ({10000, 10002, 10005}), ret.training_samples(0).features(10));
        TEST_SLOT_FEATURE_INT64(
                10828, ({(int64_t) 102 * 86400 * 1000, (int64_t) 84 * 86400 * 1000, (int64_t) 78 * 86400 * 1000}),
                ret.training_samples(0).features(11));
    }

    TEST_CASE("seq_diff_daily_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_daily" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="0" clip_size="3" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_diff_daily" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="1" clip_size="3" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_bid((int64_t) 90 * 86400 * 1000);
        item_fea->mutable_item_info()->set_creative_id(10001);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 85 * 86400 * 1000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea->mutable_item_info()->set_bid((int64_t) 85 * 86400 * 1000);
        item_fea->mutable_item_info()->set_creative_id(10002);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 90 * 86400 * 1000);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 2);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10001}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 90 * 86400 * 1000}), ret.training_samples(0).features(3));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({10002}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 85 * 86400 * 1000}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(1).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(1).features(3));
    }

    TEST_CASE("seq_diff_daily_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_daily" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="0" status="0" clip_size="3" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_diff_daily" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="0" status="1" clip_size="3" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_bid((int64_t) 90 * 86400 * 1000 - 8 * 3600 * 1000);
        item_fea->mutable_item_info()->set_creative_id(10001);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 90 * 86400 * 1000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea->mutable_item_info()->set_bid((int64_t) 85 * 86400 * 1000 + 12 * 3600 * 1000);
        item_fea->mutable_item_info()->set_creative_id(10002);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 85 * 86400 * 1000 - 3 * 3600 * 1000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);
        item_fea->mutable_item_info()->set_bid((int64_t) 87 * 86400 * 1000 + 16 * 3600 * 1000);
        item_fea->mutable_item_info()->set_creative_id(10003);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 87 * 86400 * 1000 + 5 * 3600 * 1000);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        CHECK_EQ(ret.training_samples_size(), 3);
        CHECK_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10001}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 90 * 86400 * 1000 - 8 * 3600 * 1000}),
                                ret.training_samples(0).features(3));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({10002}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 85 * 86400 * 1000 + 12 * 3600 * 1000}),
                                ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(1).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(1).features(3));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({10003}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 87 * 86400 * 1000 + 16 * 3600 * 1000}),
                                ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(2).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(2).features(3));
    }

    TEST_CASE("seq_diff_v2_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time" start="864000" day_n="30" delta_day="10" status="0" clip_size="2" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_diff_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time" start="864000" day_n="30" delta_day="10" status="1" clip_size="2" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        //防穿越
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 102 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 86 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //活跃
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //长度截断
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 81 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 83 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //时间范围过滤
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);

        pb_use = fe_request.mutable_ad_user_app_seq_update_offline();

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 98 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 82 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10004}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 86 * 86400 * 1000, (int64_t) 83 * 86400 * 1000}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10002}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 84 * 86400 * 1000}), ret.training_samples(0).features(3));
    }

    TEST_CASE("seq_diff_v2_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_v2" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="0" clip_size="3" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_diff_v2" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="1" clip_size="3" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_bid((int64_t) 90 * 86400 * 1000);
        item_fea->mutable_item_info()->set_creative_id(10001);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 85 * 86400 * 1000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea->mutable_item_info()->set_bid((int64_t) 85 * 86400 * 1000);
        item_fea->mutable_item_info()->set_creative_id(10002);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 90 * 86400 * 1000);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 2);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10001}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 90 * 86400 * 1000}), ret.training_samples(0).features(3));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({10002}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 85 * 86400 * 1000}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(1).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(1).features(3));
    }

    TEST_CASE("seq_diff_v2_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816,10818,10819,10821,10822" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.req_time" day_n="30" delta_day="10" status="0" clip_size="2" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_diff_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.req_time" day_n="30" delta_day="10" status="1" clip_size="2" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                    <feature name="10817" slot="10817" type="seq_diff_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.req_time" delta_day="10" status="0" clip_size="2" />
                    <feature name="10818" slot="10818" type="direct" source="10817:0" />
                    <feature name="10819" slot="10819" type="direct" source="10817:1" />
                    <feature name="10820" slot="10820" type="seq_diff_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_update_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.req_time" delta_day="10" status="1" clip_size="2" />
                    <feature name="10821" slot="10821" type="direct" source="10820:0" />
                    <feature name="10822" slot="10822" type="direct" source="10820:1" />

                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 100 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        //防穿越
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 102 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 86 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //活跃
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //长度截断
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 81 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 83 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        //时间范围过滤
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);

        pb_use = fe_request.mutable_ad_user_app_seq_update_offline();

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 98 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000);
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 82 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 8);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10004}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 86 * 86400 * 1000, (int64_t) 83 * 86400 * 1000}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10002}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 84 * 86400 * 1000}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10818, ({10001, 10004}), ret.training_samples(0).features(4));
        TEST_SLOT_FEATURE_INT64(10819, ({(int64_t) 86 * 86400 * 1000, (int64_t) 83 * 86400 * 1000}),
                                ret.training_samples(0).features(5));
        TEST_SLOT_FEATURE_INT64(10821, ({10002, 10005}), ret.training_samples(0).features(6));
        TEST_SLOT_FEATURE_INT64(10822, ({(int64_t) 84 * 86400 * 1000, (int64_t) 78 * 86400 * 1000}),
                                ret.training_samples(0).features(7));
    }

    TEST_CASE("seq_val_direct_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.duration" start="864000" day_n="30" upper_bound="86400000" clip_size="2" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        //start过滤
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info->set_duration((int64_t) 1 * 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);
        pb_info->set_duration((int64_t) 2 * 3600 * 1000);

        //upper_bound过滤
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000);
        pb_info->set_duration((int64_t) 100 * 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000);
        pb_info->set_duration((int64_t) 4 * 3600 * 1000);

        //clip_size截断
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000);
        pb_info->set_duration((int64_t) 5 * 3600 * 1000);

        //day_n过滤
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);
        pb_info->set_duration((int64_t) 6 * 3600 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 84 * 86400 * 1000, (int64_t) 95 * 86400 * 1000}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({(int64_t) 2 * 3600 * 1000, (int64_t) 4 * 3600 * 1000}),
                                ret.training_samples(0).features(2));
    }

    TEST_CASE("seq_val_direct_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814,10816,10817" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".fe_request.ad_user_query_seq_offline.user_query_seq.adunit_id,.fe_request.ad_user_query_seq_offline.user_query_seq.event_time,.fe_request.event_time,.fe_request.ad_user_query_seq_offline.user_query_seq.query" start="864000" day_n="30" clip_size="5" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                    <feature name="10815" slot="10815" type="seq_val_direct" source=".fe_request.ad_user_query_seq_offline.user_query_seq.adunit_id,.fe_request.ad_user_query_seq_offline.user_query_seq.event_time,.fe_request.event_time" start="864000" day_n="30" clip_size="5" />
                    <feature name="10816" slot="10816" type="direct" source="10811:0" />
                    <feature name="10817" slot="10817" type="direct" source="10811:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserQuerySeq *pb_use = fe_request.mutable_ad_user_query_seq_offline();
        ::phx::AdUserQueryInfo *pb_info = pb_use->add_user_query_seq();

        //start过滤
        pb_info->set_adunit_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info->set_query("游戏中心");

        pb_info = pb_use->add_user_query_seq();
        pb_info->set_adunit_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);
        pb_info->set_query("应用市场");

        pb_info = pb_use->add_user_query_seq();
        pb_info->set_adunit_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000);
        pb_info->set_query("游戏中心");

        pb_info = pb_use->add_user_query_seq();
        pb_info->set_adunit_id(10003);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000);
        pb_info->set_query("应用市场");

        pb_info = pb_use->add_user_query_seq();
        pb_info->set_adunit_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000);
        pb_info->set_query("应用市场");

        //day_n过滤
        pb_info = pb_use->add_user_query_seq();
        pb_info->set_adunit_id(10005);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);
        pb_info->set_query("应用市场");

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 5);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10002, 10003, 10004}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813,
                                ({(int64_t) 84 * 86400 * 1000, (int64_t) 92 * 86400 * 1000, (int64_t) 95 * 86400 * 1000,
                                  (int64_t) 99 * 86400 * 1000}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(10814, ({"应用市场", "游戏中心", "应用市场", "应用市场"}),
                              ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({10001, 10002, 10003, 10004}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10817,
                                ({(int64_t) 84 * 86400 * 1000, (int64_t) 92 * 86400 * 1000, (int64_t) 95 * 86400 * 1000,
                                  (int64_t) 99 * 86400 * 1000}),
                                ret.training_samples(0).features(4));
    }

    TEST_CASE("seq_val_direct_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".user_action.user_action_item_info.creative_id,.user_action.user_action_item_info.ad_group_id,.fe_request.event_time,.user_action.user_action_item_info.pctr" start="864000" day_n="30" clip_size="2" upper_bound="1.00" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        auto *user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_creative_id(10000);
        user_action_item_info->set_ad_group_id((int64_t) 82 * 86400 * 1000);
        user_action_item_info->set_pctr(0.43);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_creative_id(10001);
        user_action_item_info->set_ad_group_id((int64_t) 90 * 86400 * 1000);
        user_action_item_info->set_pctr(0.28);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_creative_id(10002);
        user_action_item_info->set_ad_group_id((int64_t) 105 * 86400 * 1000);
        user_action_item_info->set_pctr(0.34);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_creative_id(10003);
        user_action_item_info->set_ad_group_id((int64_t) 85 * 86400 * 1000);
        user_action_item_info->set_pctr(1.28);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_creative_id(10004);
        user_action_item_info->set_ad_group_id((int64_t) 95 * 86400 * 1000);
        user_action_item_info->set_pctr(0.19);

        // item 和 user_action的size相同
        fe_request.add_item_fea();
        fe_request.add_item_fea();
        fe_request.add_item_fea();
        fe_request.add_item_fea();
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 5);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 82 * 86400 * 1000}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({0.43}), ret.training_samples(0).features(2));

        TEST_SLOT_FEATURE_INT64(10812, ({10001}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 90 * 86400 * 1000}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({0.28}), ret.training_samples(1).features(2));

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({}), ret.training_samples(2).features(2));

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({}), ret.training_samples(3).features(2));

        TEST_SLOT_FEATURE_INT64(10812, ({10004}), ret.training_samples(4).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 95 * 86400 * 1000}), ret.training_samples(4).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({0.19}), ret.training_samples(4).features(2));
    }

    TEST_CASE("seq_val_direct_4") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814,10816,10817,10819,10820,10821,10823,10824" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" start="5" day_n="-1" clip_size="-1" upper_bound="-1" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                    <feature name="10815" slot="10815" type="seq_val_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time" start="0" day_n="-1" clip_size="-1" upper_bound="-1" />
                    <feature name="10816" slot="10816" type="direct" source="10815:0" />
                    <feature name="10817" slot="10817" type="direct" source="10815:1" />
                    <feature name="10818" slot="10818" type="seq_val_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" start="5" day_n="-1" clip_size="-1" upper_bound="2.0" />
                    <feature name="10819" slot="10819" type="direct" source="10818:0" />
                    <feature name="10820" slot="10820" type="direct" source="10818:1" />
                    <feature name="10821" slot="10821" type="direct" source="10818:2" />
                    <feature name="10822" slot="10822" type="seq_val_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time" start="5" day_n="-1" clip_size="-1" upper_bound="2.0" />
                    <feature name="10823" slot="10823" type="direct" source="10822:0" />
                    <feature name="10824" slot="10824" type="direct" source="10822:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        fe_request.set_event_time(1000000);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time(995000);
        user_ads_stats_info->set_dtr(1.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(993000);
        user_ads_stats_info->set_dtr(3.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10003);
        user_ads_stats_info->set_last_event_time(991000);
        user_ads_stats_info->set_dtr(2.0);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 10);

        TEST_SLOT_FEATURE_INT64(10812, ({10002, 10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({993000, 991000}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({3.0, 2.0}), ret.training_samples(0).features(2));

        TEST_SLOT_FEATURE_INT64(10816, ({10001, 10002, 10003}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10817, ({995000, 993000, 991000}), ret.training_samples(0).features(4));

        TEST_SLOT_FEATURE_INT64(10819, ({10003}), ret.training_samples(0).features(5));
        TEST_SLOT_FEATURE_INT64(10820, ({991000}), ret.training_samples(0).features(6));
        TEST_SLOT_FEATURE_FLOAT(10821, ({2.0}), ret.training_samples(0).features(7));

        TEST_SLOT_FEATURE_INT64(10823, ({10002, 10003}), ret.training_samples(0).features(8));
        TEST_SLOT_FEATURE_INT64(10824, ({993000, 991000}), ret.training_samples(0).features(9));
    }

    TEST_CASE("seq_val_direct_5") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814,10819,10820,10821" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" start="5" day_n="-1" clip_size="1" upper_bound="1.5" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                    <feature name="10818" slot="10818" type="seq_val_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_expose,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" start="5" day_n="-1" clip_size="2" upper_bound="-1.0" />
                    <feature name="10819" slot="10819" type="direct" source="10818:0" />
                    <feature name="10820" slot="10820" type="direct" source="10818:1" />
                    <feature name="10821" slot="10821" type="direct" source="10818:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        fe_request.set_event_time(1000000);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time(995000);
        user_ads_stats_info->set_num_expose(995000);
        user_ads_stats_info->set_dtr(1.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(993000);
        user_ads_stats_info->set_num_expose(993000);
        user_ads_stats_info->set_dtr(3.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10003);
        user_ads_stats_info->set_last_event_time(991000);
        user_ads_stats_info->set_num_expose(991000);
        user_ads_stats_info->set_dtr(2.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10004);
        user_ads_stats_info->set_last_event_time(990000);
        user_ads_stats_info->set_num_expose(994000);
        user_ads_stats_info->set_dtr(2.0);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 6);

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({}), ret.training_samples(0).features(2));

        TEST_SLOT_FEATURE_INT64(10819, ({10002, 10003}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10820, ({993000, 991000}), ret.training_samples(0).features(4));
        TEST_SLOT_FEATURE_FLOAT(10821, ({3.0, 2.0}), ret.training_samples(0).features(5));
    }

    TEST_CASE("seq_val_direct_6") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814,10819,10820,10821,10823,10824,10825" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.app_id,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.event_time,.fe_request.event_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.request_id" start="5" day_n="-1" clip_size="-1" upper_bound="-1.0" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                    <feature name="10818" slot="10818" type="seq_val_direct" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.app_id,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.ad_group_id,.fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.request_id" start="5" day_n="1" clip_size="-1" upper_bound="-1.0" />
                    <feature name="10819" slot="10819" type="direct" source="10818:0" />
                    <feature name="10820" slot="10820" type="direct" source="10818:1" />
                    <feature name="10821" slot="10821" type="direct" source="10818:2" />
                    <feature name="10822" slot="10822" type="seq_val_direct" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.app_id,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.creative_id,.fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.request_id" start="5" day_n="1" clip_size="1" upper_bound="1.5" />
                    <feature name="10823" slot="10823" type="direct" source="10822:0" />
                    <feature name="10824" slot="10824" type="direct" source="10822:1" />
                    <feature name="10825" slot="10825" type="direct" source="10822:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        fe_request.set_event_time(1000000);
        fe_request.set_req_time(86407000);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(995000);
        user_app_conv_seq->set_ad_group_id(10000);
        user_app_conv_seq->set_creative_id(10000);
        user_app_conv_seq->set_request_id("a");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(993000);
        user_app_conv_seq->set_ad_group_id(7000);
        user_app_conv_seq->set_creative_id(86402000);
        user_app_conv_seq->set_request_id("b");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10003);
        user_app_conv_seq->set_event_time(991000);
        user_app_conv_seq->set_ad_group_id(2000);
        user_app_conv_seq->set_creative_id(7000);
        user_app_conv_seq->set_request_id("c");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10004);
        user_app_conv_seq->set_event_time(994000);
        user_app_conv_seq->set_ad_group_id(3000);
        user_app_conv_seq->set_creative_id(20000);
        user_app_conv_seq->set_request_id("d");

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 9);

        TEST_SLOT_FEATURE_INT64(10812, ({10002, 10003, 10004}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({993000, 991000, 994000}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(10814, ({"b", "c", "d"}), ret.training_samples(0).features(2));

        TEST_SLOT_FEATURE_INT64(10819, ({10001}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10820, ({10000}), ret.training_samples(0).features(4));
        TEST_SLOT_FEATURE_STR(10821, ({"a"}), ret.training_samples(0).features(5));

        TEST_SLOT_FEATURE_INT64(10823, ({10001}), ret.training_samples(0).features(6));
        TEST_SLOT_FEATURE_INT64(10824, ({10000}), ret.training_samples(0).features(7));
        TEST_SLOT_FEATURE_STR(10825, ({"a"}), ret.training_samples(0).features(8));
    }

    TEST_CASE("seq_val_direct_7") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814,10819,10820,10821,10823,10824,10825" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" start="5" day_n="1" clip_size="1" upper_bound="1.5" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                    <feature name="10818" slot="10818" type="seq_val_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr_over_all" start="5" day_n="1" clip_size="1" upper_bound="1.5" />
                    <feature name="10819" slot="10819" type="direct" source="10818:0" />
                    <feature name="10820" slot="10820" type="direct" source="10818:1" />
                    <feature name="10821" slot="10821" type="direct" source="10818:2" />
                    <feature name="10822" slot="10822" type="seq_val_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_expose,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_download_success" start="5" day_n="1" clip_size="1" upper_bound="1.5" />
                    <feature name="10823" slot="10823" type="direct" source="10822:0" />
                    <feature name="10824" slot="10824" type="direct" source="10822:1" />
                    <feature name="10825" slot="10825" type="direct" source="10822:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        fe_request.set_event_time(86407000);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time(10000);
        user_ads_stats_info->set_num_expose(20000);
        user_ads_stats_info->set_dtr(1.5);
        user_ads_stats_info->set_dtr_over_all(1.0);
        user_ads_stats_info->set_num_download_success(1);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(86402000);
        user_ads_stats_info->set_num_expose(86402000);
        user_ads_stats_info->set_dtr(1.0);
        user_ads_stats_info->set_dtr_over_all(1.0);
        user_ads_stats_info->set_num_download_success(1);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10003);
        user_ads_stats_info->set_last_event_time(7000);
        user_ads_stats_info->set_num_expose(7000);
        user_ads_stats_info->set_dtr(3.0);
        user_ads_stats_info->set_dtr_over_all(3.0);
        user_ads_stats_info->set_num_download_success(3);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10004);
        user_ads_stats_info->set_last_event_time(20000);
        user_ads_stats_info->set_num_expose(20000);
        user_ads_stats_info->set_dtr(1.6);
        user_ads_stats_info->set_dtr_over_all(2.0);
        user_ads_stats_info->set_num_download_success(0);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 9);

        TEST_SLOT_FEATURE_INT64(10812, ({10001}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({10000}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({1.5}), ret.training_samples(0).features(2));

        TEST_SLOT_FEATURE_INT64(10819, ({10001}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10820, ({10000}), ret.training_samples(0).features(4));
        TEST_SLOT_FEATURE_FLOAT(10821, ({1.0}), ret.training_samples(0).features(5));

        TEST_SLOT_FEATURE_INT64(10823, ({10001}), ret.training_samples(0).features(6));
        TEST_SLOT_FEATURE_INT64(10824, ({20000}), ret.training_samples(0).features(7));
        TEST_SLOT_FEATURE_INT64(10825, ({1}), ret.training_samples(0).features(8));
    }

    TEST_CASE("seq_val_direct_8") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.duration" start="864000" hour_n="330" upper_bound="86400000" clip_size="2" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        //start过滤
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info->set_duration((int64_t) 1 * 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 97 * 86400 * 1000);
        pb_info->set_duration((int64_t) 2 * 3600 * 1000);

        //upper_bound过滤
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000);
        pb_info->set_duration((int64_t) 100 * 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 97 * 86400 * 1000 - 17 * 3600 * 1000);
        pb_info->set_duration((int64_t) 4 * 3600 * 1000);

        //clip_size截断
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000);
        pb_info->set_duration((int64_t) 5 * 3600 * 1000);

        //hour_n过滤
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);
        pb_info->set_duration((int64_t) 6 * 3600 * 1000);

        //hour_n过滤
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 110 * 86400 * 1000 - 332 * 3600 * 1000);
        pb_info->set_duration((int64_t) 6 * 3600 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 97 * 86400 * 1000, (int64_t) 97 * 86400 * 1000 - 17 * 3600 * 1000}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({(int64_t) 2 * 3600 * 1000, (int64_t) 4 * 3600 * 1000}),
                                ret.training_samples(0).features(2));
    }

    TEST_CASE("seq_val_direct_9") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.duration" start="864000" second_n="1188000" upper_bound="86400000" clip_size="2" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        //start过滤
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info->set_duration((int64_t) 1 * 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 97 * 86400 * 1000);
        pb_info->set_duration((int64_t) 2 * 3600 * 1000);

        //upper_bound过滤
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000);
        pb_info->set_duration((int64_t) 100 * 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 97 * 86400 * 1000 - 17 * 3600 * 1000);
        pb_info->set_duration((int64_t) 4 * 3600 * 1000);

        //clip_size截断
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000);
        pb_info->set_duration((int64_t) 5 * 3600 * 1000);

        //hour_n过滤
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);
        pb_info->set_duration((int64_t) 6 * 3600 * 1000);

        //hour_n过滤
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 110 * 86400 * 1000 - 332 * 3600 * 1000);
        pb_info->set_duration((int64_t) 6 * 3600 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 97 * 86400 * 1000, (int64_t) 97 * 86400 * 1000 - 17 * 3600 * 1000}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({(int64_t) 2 * 3600 * 1000, (int64_t) 4 * 3600 * 1000}),
                                ret.training_samples(0).features(2));
    }

    TEST_CASE("seq_val_direct_v2_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct_v2" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.duration"
                    start="864000"
                    day_n="30"
                    upper_bound="86400000"
                    lower_bound="14400000"
                    clip_size="2" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        //start过滤
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info->set_duration((int64_t) 1 * 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);
        pb_info->set_duration((int64_t) 2 * 3600 * 1000);

        //upper_bound过滤
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000);
        pb_info->set_duration((int64_t) 100 * 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000);
        pb_info->set_duration((int64_t) 4 * 3600 * 1000);

        //clip_size截断
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000);
        pb_info->set_duration((int64_t) 5 * 3600 * 1000);

        //day_n过滤
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);
        pb_info->set_duration((int64_t) 6 * 3600 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10003, 10004}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 95 * 86400 * 1000, (int64_t) 99 * 86400 * 1000}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({(int64_t) 4 * 3600 * 1000, (int64_t) 5 * 3600 * 1000}),
                                ret.training_samples(0).features(2));
    }

    TEST_CASE("seq_val_direct_v2_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814,10816,10817" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct_v2" source=".fe_request.ad_user_query_seq_offline.user_query_seq.adunit_id,.fe_request.ad_user_query_seq_offline.user_query_seq.event_time,.fe_request.event_time,.fe_request.ad_user_query_seq_offline.user_query_seq.query" start="864000" day_n="30" clip_size="5" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                    <feature name="10815" slot="10815" type="seq_val_direct_v2" source=".fe_request.ad_user_query_seq_offline.user_query_seq.adunit_id,.fe_request.ad_user_query_seq_offline.user_query_seq.event_time,.fe_request.event_time" start="864000" day_n="30" clip_size="5" />
                    <feature name="10816" slot="10816" type="direct" source="10815:0" />
                    <feature name="10817" slot="10817" type="direct" source="10815:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserQuerySeq *pb_use = fe_request.mutable_ad_user_query_seq_offline();
        ::phx::AdUserQueryInfo *pb_info = pb_use->add_user_query_seq();

        //start过滤
        pb_info->set_adunit_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info->set_query("游戏中心");

        pb_info = pb_use->add_user_query_seq();
        pb_info->set_adunit_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);
        pb_info->set_query("应用市场");

        pb_info = pb_use->add_user_query_seq();
        pb_info->set_adunit_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000);
        pb_info->set_query("游戏中心");

        pb_info = pb_use->add_user_query_seq();
        pb_info->set_adunit_id(10003);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000);
        pb_info->set_query("应用市场");

        pb_info = pb_use->add_user_query_seq();
        pb_info->set_adunit_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000);
        pb_info->set_query("应用市场");

        //day_n过滤
        pb_info = pb_use->add_user_query_seq();
        pb_info->set_adunit_id(10005);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);
        pb_info->set_query("应用市场");

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 5);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10002, 10003, 10004}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813,
                                ({(int64_t) 84 * 86400 * 1000, (int64_t) 92 * 86400 * 1000, (int64_t) 95 * 86400 * 1000,
                                  (int64_t) 99 * 86400 * 1000}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(10814, ({"应用市场", "游戏中心", "应用市场", "应用市场"}),
                              ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({10001, 10002, 10003, 10004}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10817,
                                ({(int64_t) 84 * 86400 * 1000, (int64_t) 92 * 86400 * 1000, (int64_t) 95 * 86400 * 1000,
                                  (int64_t) 99 * 86400 * 1000}),
                                ret.training_samples(0).features(4));
    }

    TEST_CASE("seq_val_direct_v2_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct_v2" source=".user_action.user_action_item_info.creative_id,.user_action.user_action_item_info.ad_group_id,.fe_request.event_time,.user_action.user_action_item_info.pctr" start="864000" day_n="30" clip_size="2" upper_bound="1.00" lower_bound="0.20" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        auto *user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_creative_id(10000);
        user_action_item_info->set_ad_group_id((int64_t) 82 * 86400 * 1000);
        user_action_item_info->set_pctr(0.43);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_creative_id(10001);
        user_action_item_info->set_ad_group_id((int64_t) 90 * 86400 * 1000);
        user_action_item_info->set_pctr(0.28);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_creative_id(10002);
        user_action_item_info->set_ad_group_id((int64_t) 105 * 86400 * 1000);
        user_action_item_info->set_pctr(0.34);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_creative_id(10003);
        user_action_item_info->set_ad_group_id((int64_t) 85 * 86400 * 1000);
        user_action_item_info->set_pctr(1.28);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_creative_id(10004);
        user_action_item_info->set_ad_group_id((int64_t) 95 * 86400 * 1000);
        user_action_item_info->set_pctr(0.19);

        // item 和 user_action的size相同
        fe_request.add_item_fea();
        fe_request.add_item_fea();
        fe_request.add_item_fea();
        fe_request.add_item_fea();
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(ret.training_samples_size(), 5);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 82 * 86400 * 1000}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({0.43}), ret.training_samples(0).features(2));

        TEST_SLOT_FEATURE_INT64(10812, ({10001}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 90 * 86400 * 1000}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({0.28}), ret.training_samples(1).features(2));

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({}), ret.training_samples(2).features(2));

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({}), ret.training_samples(3).features(2));

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(4).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(4).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({}), ret.training_samples(4).features(2));
    }

    TEST_CASE("seq_val_direct_v2_4") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814,10816,10817,10819,10820,10821,10823,10824" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" start="5" day_n="-1" clip_size="-1" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                    <feature name="10815" slot="10815" type="seq_val_direct_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time" start="0" day_n="-1" clip_size="-1" />
                    <feature name="10816" slot="10816" type="direct" source="10815:0" />
                    <feature name="10817" slot="10817" type="direct" source="10815:1" />
                    <feature name="10818" slot="10818" type="seq_val_direct_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" start="5" day_n="-1" clip_size="-1" upper_bound="2.0" />
                    <feature name="10819" slot="10819" type="direct" source="10818:0" />
                    <feature name="10820" slot="10820" type="direct" source="10818:1" />
                    <feature name="10821" slot="10821" type="direct" source="10818:2" />
                    <feature name="10822" slot="10822" type="seq_val_direct_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.event_time" start="5" day_n="-1" clip_size="-1" upper_bound="2.0" />
                    <feature name="10823" slot="10823" type="direct" source="10822:0" />
                    <feature name="10824" slot="10824" type="direct" source="10822:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        fe_request.set_event_time(1000000);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time(995000);
        user_ads_stats_info->set_dtr(1.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(993000);
        user_ads_stats_info->set_dtr(3.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10003);
        user_ads_stats_info->set_last_event_time(991000);
        user_ads_stats_info->set_dtr(2.0);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromString(batch_training_sample_str);

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 10);

        TEST_SLOT_FEATURE_INT64(10812, ({10002, 10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({993000, 991000}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({3.0, 2.0}), ret.training_samples(0).features(2));

        TEST_SLOT_FEATURE_INT64(10816, ({10001, 10002, 10003}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10817, ({995000, 993000, 991000}), ret.training_samples(0).features(4));

        TEST_SLOT_FEATURE_INT64(10819, ({10003}), ret.training_samples(0).features(5));
        TEST_SLOT_FEATURE_INT64(10820, ({991000}), ret.training_samples(0).features(6));
        TEST_SLOT_FEATURE_FLOAT(10821, ({2.0}), ret.training_samples(0).features(7));

        TEST_SLOT_FEATURE_INT64(10823, ({10002, 10003}), ret.training_samples(0).features(8));
        TEST_SLOT_FEATURE_INT64(10824, ({993000, 991000}), ret.training_samples(0).features(9));
    }

    TEST_CASE("test_seq_by_inter_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_by_inter" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.item_fea.item_info.appid" inter_key="app_id" fields="request_id,event_time,ad_group_id" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 4);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({"2"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({360}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({400}), ret.training_samples(0).features(2));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"1"}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({120}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({200}), ret.training_samples(1).features(2));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"0", "0"}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 240}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 300}), ret.training_samples(2).features(2));

        REQUIRE_EQ(ret.training_samples(3).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(3).features(2));
    }

    TEST_CASE("test_seq_by_inter_2") {
        //user一层repeated且在source中间,inter_key存在未设置的
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_by_inter" source=".fe_request.prerank_item_fea.prerank_item_info,.fe_request.item_fea.item_info.appid" inter_key="creative_id" fields="final_ecpm,position" />
                    <feature name="10813" slot="10813" type="direct" source="10811:0" />
                    <feature name="10814" slot="10814" type="direct" source="10811:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *afe = fe_request.add_prerank_item_fea();
        afe->mutable_prerank_item_info()->set_creative_id(10000);
        afe->mutable_prerank_item_info()->set_final_ecpm(0);
        afe->mutable_prerank_item_info()->set_position(0);

        afe = fe_request.add_prerank_item_fea();
        afe->mutable_prerank_item_info()->set_creative_id(10001);
        afe->mutable_prerank_item_info()->set_final_ecpm(0);
        afe->mutable_prerank_item_info()->set_position(1);

        afe = fe_request.add_prerank_item_fea();
        afe->mutable_prerank_item_info()->set_creative_id(10002);
        afe->mutable_prerank_item_info()->set_final_ecpm(1);
        afe->mutable_prerank_item_info()->set_position(0);

        afe = fe_request.add_prerank_item_fea();
        afe->mutable_prerank_item_info()->set_final_ecpm(1);
        afe->mutable_prerank_item_info()->set_position(1);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 4);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10813, ({0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10814, ({0}), ret.training_samples(0).features(1));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10813, ({0}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10814, ({1}), ret.training_samples(1).features(1));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10813, ({1}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10814, ({0}), ret.training_samples(2).features(1));

        REQUIRE_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(3).features(1));
    }

    TEST_CASE("test_seq_merge_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_merge" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.ad_user_seq_conv_sdk_conversion_realtime.ad_user_app_conv_seq" eventtime_key="event_time" />
                    <feature name="10812" slot="10812" type="direct" source="10811.request_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.pay_money" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_pay_money(100);
        user_app_conv_seq->set_request_id("appid0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_pay_money(200);
        user_app_conv_seq->set_request_id("appid1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_pay_money(300);
        user_app_conv_seq->set_request_id("appid2");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_pay_money(400);
        user_app_conv_seq->set_request_id("appid3");

        ads = fe_request.mutable_ad_user_seq_conv_sdk_conversion_realtime();
        user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_pay_money(200);
        user_app_conv_seq->set_request_id("appid4");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(420);
        user_app_conv_seq->set_pay_money(100);
        user_app_conv_seq->set_request_id("appid5");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(540);
        user_app_conv_seq->set_pay_money(300);
        user_app_conv_seq->set_request_id("appid6");

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({"appid6", "appid5", "appid3", "appid2", "appid1", "appid0"}),
                              ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({540, 420, 360, 240, 120, 60}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({300, 100, 400, 300, 200, 100}), ret.training_samples(0).features(2));
    }

    TEST_CASE("test_seq_merge_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10810" type="seq_merge" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.ad_user_seq_conv_sdk_conversion_realtime.ad_user_app_conv_seq" eventtime_key="event_time" />
                    <feature name="10811" type="seq_by_inter" source="10810,.fe_request.item_fea.item_info.appid" inter_key="app_id" fields="request_id,event_time,pay_money" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_pay_money(100);
        user_app_conv_seq->set_request_id("appid0");
        user_app_conv_seq->set_app_id(10000);

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_pay_money(200);
        user_app_conv_seq->set_request_id("appid1");
        user_app_conv_seq->set_app_id(10001);

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_pay_money(300);
        user_app_conv_seq->set_request_id("appid2");
        user_app_conv_seq->set_app_id(10002);

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_pay_money(400);
        user_app_conv_seq->set_request_id("appid3");
        user_app_conv_seq->set_app_id(10003);

        ads = fe_request.mutable_ad_user_seq_conv_sdk_conversion_realtime();
        user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_pay_money(200);
        user_app_conv_seq->set_request_id("appid4");
        user_app_conv_seq->set_app_id(10004);

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(420);
        user_app_conv_seq->set_pay_money(100);
        user_app_conv_seq->set_request_id("appid5");
        user_app_conv_seq->set_app_id(10005);

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(540);
        user_app_conv_seq->set_pay_money(300);
        user_app_conv_seq->set_request_id("appid6");
        user_app_conv_seq->set_app_id(10006);

        fe_request.add_item_fea()->mutable_item_info()->set_appid(10002);
        fe_request.add_item_fea()->mutable_item_info()->set_appid(10001);
        fe_request.add_item_fea()->mutable_item_info()->set_appid(10000);
        fe_request.add_item_fea()->mutable_item_info()->set_appid(10003);
        fe_request.add_item_fea()->mutable_item_info()->set_appid(10004);
        fe_request.add_item_fea()->mutable_item_info()->set_appid(10006);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 6);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({"appid2"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({240}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({300}), ret.training_samples(0).features(2));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"appid1"}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({120}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({200}), ret.training_samples(1).features(2));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"appid0"}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100}), ret.training_samples(2).features(2));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"appid3"}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({360}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({400}), ret.training_samples(3).features(2));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({}), ret.training_samples(4).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(4).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(4).features(2));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"appid6"}), ret.training_samples(5).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({540}), ret.training_samples(5).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({300}), ret.training_samples(5).features(2));
    }

    TEST_CASE("test_seq_merge_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_merge" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.ad_user_seq_conv_sdk_conversion_realtime.ad_user_app_conv_seq" eventtime_key="event_time" />
                    <feature name="10812" slot="10812" type="direct" source="10811.request_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.pay_money" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_pay_money(100);
        user_app_conv_seq->set_request_id("appid0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_pay_money(200);
        user_app_conv_seq->set_request_id("appid1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_pay_money(300);
        user_app_conv_seq->set_request_id("appid2");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_pay_money(400);
        user_app_conv_seq->set_request_id("appid3");

        ads = fe_request.mutable_ad_user_seq_conv_sdk_conversion_realtime();
        user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({"appid3", "appid2", "appid1", "appid0"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({360, 240, 120, 60}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({400, 300, 200, 100}), ret.training_samples(0).features(2));
    }

    TEST_CASE("test_seq_merge_4") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_merge" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.ad_user_seq_conv_sdk_conversion_realtime.ad_user_app_conv_seq" eventtime_key="event_time" />
                    <feature name="10812" slot="10812" type="direct" source="10811.request_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.pay_money" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();

        ads = fe_request.mutable_ad_user_seq_conv_sdk_conversion_realtime();

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(0).features(2));
    }

    TEST_CASE("seq_hit_interval_1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 3);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({-1}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({20 * 86400}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({50 * 86400}), ret.training_samples(2).features(0));

        // std::cout << ret.DebugString() << std::endl;
    }

    TEST_CASE("seq_hit_interval_2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time(105 * 86400 * 1000L + 1000L);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(70 * 86400 * 1000L);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(90 * 86400 * 1000L);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(40 * 86400 * 1000L);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(60 * 86400 * 1000L);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 3);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({5 * 86400 - 1}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({20 * 86400}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({50 * 86400}), ret.training_samples(2).features(0));
    }

    TEST_CASE("seq_hit_interval_3") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        default_value="-2"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 3);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(2).features(0));
    }

    TEST_CASE("seq_hit_interval_4") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        default_value="-2"
                        default_input_int64="10000"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // req_time
        fe_request->set_req_time((int64_t) 11000);

        // item
        auto *item_fea = fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({1}), ret.training_samples(0).features(0));
    }

    TEST_CASE("seq_hit_interval_1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({-1}), ret.training_samples(0).features(0));

        // std::cout << ret.DebugString() << std::endl;
    }

    TEST_CASE("seq_hit_sum_1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_sum"
                        source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.duration,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        default_value="-2"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);
        ad_user_app_info->set_duration((int64_t) 105);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info->set_duration((int64_t) 70);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info->set_duration((int64_t) 90);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info->set_duration((int64_t) 40);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        ad_user_app_info->set_duration((int64_t) 60);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越过滤

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({160}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({100}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({-2}), ret.training_samples(2).features(0));

        CHECK_EQ(ret.training_samples(3).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({-2}), ret.training_samples(3).features(0));

        // std::cout << ret.DebugString() << std::endl;
    }

    TEST_CASE("seq_hit_sum_2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_sum"
                        source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.duration,.fe_request.item_fea.item_info.appid"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);
        ad_user_app_info->set_duration((int64_t) 105);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info->set_duration((int64_t) 70);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info->set_duration((int64_t) 90);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info->set_duration((int64_t) 40);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        ad_user_app_info->set_duration((int64_t) 60);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({160}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({100}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({-1}), ret.training_samples(2).features(0));

        CHECK_EQ(ret.training_samples(3).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({105}), ret.training_samples(3).features(0));

        // std::cout << ret.DebugString() << std::endl;
    }

    TEST_CASE("seq_hit_sum_3") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_sum"
                        source=".fe_request.req_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAdsStatsInfo *user_ads_stats_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10000);
        user_ads_stats_info->set_last_event_time((int64_t) 105 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.1);
        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time((int64_t) 70 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.2);
        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time((int64_t) 90 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.3);
        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time((int64_t) 40 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.4);
        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time((int64_t) 60 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.5);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// start过滤

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(ret.training_samples_size(), 4);
        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({0.5f}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({0.9f}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({-1.0f}), ret.training_samples(2).features(0));

        CHECK_EQ(ret.training_samples(3).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({-1.0f}), ret.training_samples(3).features(0));
    }

    // empty
    TEST_CASE("seq_hit_sum_5") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_sum"
                        source=".fe_request.req_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// start过滤

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(ret.training_samples_size(), 4);
        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({}), ret.training_samples(2).features(0));

        CHECK_EQ(ret.training_samples(3).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({}), ret.training_samples(3).features(0));
    }

    // not empty
    TEST_CASE("seq_hit_sum_6") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_sum"
                        source=".fe_request.req_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        strategy="not_empty"
                        default_value="-2"
                        default_type="float"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// start过滤

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(ret.training_samples_size(), 4);
        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({-2.0f}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({-2.0f}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({-2.0f}), ret.training_samples(2).features(0));

        CHECK_EQ(ret.training_samples(3).features_size(), 1);
        TEST_SLOT_FEATURE_FLOAT(31406, ({-2.0f}), ret.training_samples(3).features(0));
    }

    TEST_CASE("seq_hit_sum_7") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_sum"
                        source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.duration,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        default_value="-2"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);// 防穿越过滤
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);
        ad_user_app_info->set_duration((int64_t) 105);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越过滤

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({-2}), ret.training_samples(0).features(0));
    }

    TEST_CASE("stat_ctr") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="stat_ctr"
                    source=".user_action.user_action_item_info.click,.user_action.user_action_item_info.download"
                    min_expo="100"
                    default_value="0"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        int click_0 = 380, click_1 = 549, click_2 = 1348, click_3 = 0;
        int download = 10000;

        auto user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_0);
        user_action_item_info->set_download(download);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_1);
        user_action_item_info->set_download(download);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_2);
        user_action_item_info->set_download(download);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_3);
        user_action_item_info->set_download(download);

        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        for (int i = 0; i < 4; ++i)
            fe_request->add_item_fea();
        auto fe_request_str = fe_request->SerializeAsString();

        auto user_action_str = user_action->SerializeAsString();

        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features().Get(0);
        REQUIRE_EQ(1, f1.weights().size());
        CHECK(f1.weights().Get(0) == doctest::Approx(static_cast<double>(click_0) / download)
                                             .epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f2 = ret.training_samples(1).features().Get(0);
        REQUIRE_EQ(1, f2.weights().size());
        CHECK(f2.weights().Get(0) == doctest::Approx(static_cast<double>(click_1) / download)
                                             .epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        const phx::Feature &f3 = ret.training_samples(2).features().Get(0);
        REQUIRE_EQ(1, f3.weights().size());
        CHECK(f3.weights().Get(0) == doctest::Approx(static_cast<double>(click_2) / download)
                                             .epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        const phx::Feature &f4 = ret.training_samples(3).features().Get(0);
        REQUIRE_EQ(1, f4.weights().size());
        CHECK(f4.weights().Get(0) == doctest::Approx(static_cast<double>(click_3) / download)
                                             .epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰
    }

    TEST_CASE("stat_ctr_bucket int(size * score)") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="stat_ctr_bucket"
                    source=".user_action.user_action_item_info.click"
                    size="26.2"
                    bucket_type="1"
                    default_value="0"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        int click_0 = 380, click_1 = 549, click_2 = 1348, click_3 = 0;
        double size = 26.2;

        auto user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_0);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_1);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_2);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_3);

        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        for (int i = 0; i < 4; ++i)
            fe_request->add_item_fea();
        auto fe_request_str = fe_request->SerializeAsString();

        auto user_action_str = user_action->SerializeAsString();

        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features().Get(0);
        REQUIRE_EQ(1, f1.signs().size());
        CHECK_EQ(static_cast<int64_t>(size * click_0), f1.signs().Get(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f2 = ret.training_samples(1).features().Get(0);
        REQUIRE_EQ(1, f2.signs().size());
        CHECK_EQ(static_cast<int64_t>(size * click_1), f2.signs().Get(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        const phx::Feature &f3 = ret.training_samples(2).features().Get(0);
        REQUIRE_EQ(1, f3.signs().size());
        CHECK_EQ(static_cast<int64_t>(size * click_2), f3.signs().Get(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        const phx::Feature &f4 = ret.training_samples(3).features().Get(0);
        REQUIRE_EQ(1, f4.signs().size());
        CHECK_EQ(static_cast<int64_t>(size * click_3), f4.signs().Get(0));
    }

    TEST_CASE("stat_ctr_bucket log2(size + score)") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="stat_ctr_bucket"
                    source=".user_action.user_action_item_info.click"
                    size="6.7"
                    bucket_type="2"
                    default_value="0"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        int click_0 = 380, click_1 = 549, click_2 = 1348, click_3 = 0;
        double size = 6.7;

        auto user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_0);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_1);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_2);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_3);

        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        for (int i = 0; i < 4; ++i)
            fe_request->add_item_fea();
        auto fe_request_str = fe_request->SerializeAsString();

        auto user_action_str = user_action->SerializeAsString();

        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features().Get(0);
        REQUIRE_EQ(1, f1.weights().size());
        CHECK(f1.weights().Get(0) ==
              doctest::Approx(std::log2(size + click_0)).epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f2 = ret.training_samples(1).features().Get(0);
        REQUIRE_EQ(1, f2.weights().size());
        CHECK(f2.weights().Get(0) ==
              doctest::Approx(std::log2(size + click_1)).epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        const phx::Feature &f3 = ret.training_samples(2).features().Get(0);
        REQUIRE_EQ(1, f3.weights().size());
        CHECK(f3.weights().Get(0) ==
              doctest::Approx(std::log2(size + click_2)).epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        const phx::Feature &f4 = ret.training_samples(3).features().Get(0);
        REQUIRE_EQ(1, f4.weights().size());
        CHECK(f4.weights().Get(0) ==
              doctest::Approx(std::log2(size + click_3)).epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰
    }

    TEST_CASE("stat_ctr_bucket int(k * log2(a +  b * score))") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="stat_ctr_bucket"
                    source=".user_action.user_action_item_info.click"
                    bucket_type="3"
                    b="6"
                    a="1"
                    k="2"
                    default_value="0"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        int click_0 = 380, click_1 = 549, click_2 = 1348, click_3 = 0;
        int a = 1, b = 6, k = 2;

        auto user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_0);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_1);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_2);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_3);

        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        for (int i = 0; i < 4; ++i)
            fe_request->add_item_fea();
        auto fe_request_str = fe_request->SerializeAsString();

        auto user_action_str = user_action->SerializeAsString();

        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features().Get(0);
        REQUIRE_EQ(1, f1.signs().size());
        CHECK_EQ(static_cast<int64_t>(k * std::log2(a + b * click_0)), f1.signs().Get(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f2 = ret.training_samples(1).features().Get(0);
        REQUIRE_EQ(1, f2.signs().size());
        CHECK_EQ(static_cast<int64_t>(k * std::log2(a + b * click_1)), f2.signs().Get(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        const phx::Feature &f3 = ret.training_samples(2).features().Get(0);
        REQUIRE_EQ(1, f3.signs().size());
        CHECK_EQ(static_cast<int64_t>(k * std::log2(a + b * click_2)), f3.signs().Get(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        const phx::Feature &f4 = ret.training_samples(3).features().Get(0);
        REQUIRE_EQ(1, f4.signs().size());
        CHECK_EQ(static_cast<int64_t>(k * std::log2(a + b * click_3)), f4.signs().Get(0));
    }

    TEST_CASE("stat_ctr_bucket log2(a + b * score)") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="stat_ctr_bucket"
                    source=".user_action.user_action_item_info.click"
                    bucket_type="4"
                    a="3"
                    b="1000"
                    default_value="0"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        int click_0 = 380, click_1 = 549, click_2 = 1348, click_3 = 0;
        int a = 3, b = 1000;

        auto user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_0);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_1);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_2);

        user_action_item_info = user_action->add_user_action_item_info();
        user_action_item_info->set_click(click_3);

        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        for (int i = 0; i < 4; ++i)
            fe_request->add_item_fea();
        auto fe_request_str = fe_request->SerializeAsString();

        auto user_action_str = user_action->SerializeAsString();

        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features().Get(0);
        REQUIRE_EQ(1, f1.weights().size());
        CHECK(f1.weights().Get(0) ==
              doctest::Approx(std::log2(a + b * click_0)).epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f2 = ret.training_samples(1).features().Get(0);
        REQUIRE_EQ(1, f2.weights().size());
        CHECK(f2.weights().Get(0) ==
              doctest::Approx(std::log2(a + b * click_1)).epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        const phx::Feature &f3 = ret.training_samples(2).features().Get(0);
        REQUIRE_EQ(1, f3.weights().size());
        CHECK(f3.weights().Get(0) ==
              doctest::Approx(std::log2(a + b * click_2)).epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        const phx::Feature &f4 = ret.training_samples(3).features().Get(0);
        REQUIRE_EQ(1, f4.weights().size());
        CHECK(f4.weights().Get(0) ==
              doctest::Approx(std::log2(a + b * click_3)).epsilon(0.001));// 浮点数的比较不能直接使用CHECK_EQ, 容差为1‰
    }

    void mock_appinfo(int count, const std::string &path) {
        mkdir(path.c_str(), 0755);
        std::ofstream outfile(path + "/appinfo.txt", std::ios_base::out);
        for (int i = 0; i < count; i++) {
            phx::AppInfoDict appinfo_dict;
            appinfo_dict.set_app_id(111 * 10 + i);
            appinfo_dict.set_package_name("com.wx.mm");
            appinfo_dict.set_app_name("微信");
            if (i % 3 == 0) {
                appinfo_dict.set_first_class("即时通讯3");
                appinfo_dict.set_second_class("聊天3");
                appinfo_dict.set_third_class("交互3");
            } else if (i % 4 == 0) {
                appinfo_dict.set_first_class("即时通讯4");
                appinfo_dict.set_second_class("聊天4");
                appinfo_dict.set_third_class("交互4");
            } else {
                appinfo_dict.set_first_class("即时通讯");
                appinfo_dict.set_second_class("聊天");
                appinfo_dict.set_third_class("交互");
            }

            appinfo_dict.set_first_class_id(1000);
            appinfo_dict.set_second_class_id(2000);
            appinfo_dict.set_third_class_id(3000);
            appinfo_dict.set_appstore_first_class_id(11000);
            appinfo_dict.set_appstore_second_class_id(12000);
            appinfo_dict.set_appstore_third_class_id(12000);
            for (int t = 0; t < 5; t++) {
                appinfo_dict.add_app_tags()->assign("tag-" + std::to_string(i));
            }
            appinfo_dict.set_dev_name("荣耀");
            appinfo_dict.set_develop_id(333);
            appinfo_dict.set_in_app_product(1333);
            appinfo_dict.set_has_app_checked(1);
            appinfo_dict.set_has_ad(1);
            appinfo_dict.set_version_time_day_elapsed(0.86);
            appinfo_dict.set_stars(4);
            appinfo_dict.set_distribution_shape_five_star("绝世好App");
            std::string data_str;
            appinfo_dict.SerializeToString(&data_str);
            data_str = base64_encode(data_str);
            outfile << std::to_string(appinfo_dict.app_id()) << '\t' << data_str << std::endl;
        }
        outfile.flush();
        outfile.close();
        std::ofstream out_succss(path + "/SUCCESS");
    }

    TEST_CASE("seq_category_top_n_1") {
        mock_appinfo(12, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_appcategory_topn"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    topn = "2"
                    default_value="null" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1111);
        user_app_info->set_event_time(5 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1112);
        user_app_info->set_event_time(9 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1113);
        user_app_info->set_event_time(7 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1114);
        user_app_info->set_event_time(20 * 86400 * 1000);
        fe_request.set_req_time(10 * 86400 * 1000);
        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        //没有配置start，start默认为0，比request time小就合法
        //没有配置topn_type，按照event time排序
        //按event_time排序取top2，应该命中1112和1113对应的三级类目
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯", "即时通讯3"}), training_samples.training_samples(0).features(0))
        TEST_SLOT_FEATURE_STR(10002, ({"聊天", "聊天3"}), training_samples.training_samples(0).features(1))
        TEST_SLOT_FEATURE_STR(10003, ({"交互", "交互3"}), training_samples.training_samples(0).features(2))
    }

    TEST_CASE("seq_category_top_n_2") {
        mock_appinfo(12, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_appcategory_topn"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    topn = "3"
                    topn_type = "2"
                    default_value="null" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1111);
        user_app_info->set_event_time(5 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1112);
        user_app_info->set_event_time(9 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1113);
        user_app_info->set_event_time(7 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1116);
        user_app_info->set_event_time(20 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1119);
        user_app_info->set_event_time(15 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1114);
        user_app_info->set_event_time(8 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1118);
        user_app_info->set_event_time(8 * 86400 * 1000);

        fe_request.set_req_time(10 * 86400 * 1000);

        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        //没有配置start，start默认为0，比request time小就合法
        //topn_type为2，按照count排序
        //按event_time排序取top3，应该命中被4整除的id(count = 2, event_time_max = 8)和普通id(count = 2, event_time_max = 9),被3整除的id为被防穿越过滤到剩一个
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯", "即时通讯4", "即时通讯3"}),
                              training_samples.training_samples(0).features(0))
        TEST_SLOT_FEATURE_STR(10002, ({"聊天", "聊天4", "聊天3"}), training_samples.training_samples(0).features(1))
        TEST_SLOT_FEATURE_STR(10003, ({"交互", "交互4", "交互3"}), training_samples.training_samples(0).features(2))
    }

    TEST_CASE("seq_category_top_n_3") {
        mock_appinfo(12, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_appcategory_topn"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    topn = "2"
                    topn_type = "2"
                    default_value="null" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        //测试不命中词典的情况
        user_app_info->set_app_id(1111000);
        user_app_info->set_event_time(5 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1112);
        user_app_info->set_event_time(9 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1113);
        user_app_info->set_event_time(7 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1116);
        user_app_info->set_event_time(20 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1119);
        user_app_info->set_event_time(15 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1114);
        user_app_info->set_event_time(8 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1118);
        user_app_info->set_event_time(8 * 86400 * 1000);

        fe_request.set_req_time(10 * 86400 * 1000);

        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        //没有配置start，start默认为0，比request time小就合法
        //topn_type为2，按照count排序
        //1111000已被过滤，所以普通id count-1，变成1
        //按event_time排序取top3，应该命中被4整除的id(count = 2, event_time_max = 8)和普通id(count = 1, event_time_max = 9),被3整除的id为被防穿越过滤到剩一个
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯4", "即时通讯"}), training_samples.training_samples(0).features(0))
        TEST_SLOT_FEATURE_STR(10002, ({"聊天4", "聊天"}), training_samples.training_samples(0).features(1))
        TEST_SLOT_FEATURE_STR(10003, ({"交互4", "交互"}), training_samples.training_samples(0).features(2))
    }

    TEST_CASE("seq_app2category_1") {
        mock_appinfo(12, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_app2category"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    dedup = "false"
                    start = "86400"
                    clip_size = "4"
                    default_value="null" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        //测试不命中词典的情况
        user_app_info->set_app_id(1111000);
        user_app_info->set_event_time(5 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1112);
        user_app_info->set_event_time(9 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1113);
        user_app_info->set_event_time(7 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1116);
        user_app_info->set_event_time(20 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1119);
        user_app_info->set_event_time(15 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1114);
        user_app_info->set_event_time(8 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1118);
        user_app_info->set_event_time(8 * 86400 * 1000);

        fe_request.set_req_time(10 * 86400 * 1000);

        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯4", "即时通讯4", "即时通讯3"}),
                              training_samples.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"聊天4", "聊天4", "聊天3"}), training_samples.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"交互4", "交互4", "交互3"}), training_samples.training_samples(0).features(2));
    }

    TEST_CASE("seq_app2category_2") {
        mock_appinfo(12, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_app2category"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    dedup = "false"
                    start = "86400"
                    clip_size = "3"
                    default_value="null" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        //测试不命中词典的情况
        user_app_info->set_app_id(1111000);
        user_app_info->set_event_time(5 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1112);
        user_app_info->set_event_time(9 * 86400 * 1000 - 1);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1113);
        user_app_info->set_event_time(7 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1116);
        user_app_info->set_event_time(20 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1119);
        user_app_info->set_event_time(15 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1114);
        user_app_info->set_event_time(8 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1118);
        user_app_info->set_event_time(8 * 86400 * 1000);

        fe_request.set_req_time(10 * 86400 * 1000);

        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯", "即时通讯4", "即时通讯4"}),
                              training_samples.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"聊天", "聊天4", "聊天4"}), training_samples.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"交互", "交互4", "交互4"}), training_samples.training_samples(0).features(2));
    }

    TEST_CASE("seq_app2category_3") {
        mock_appinfo(12, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_app2category"
                    dict_name="app_info"
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.req_time"
                    dedup = "true"
                    start = "86400"
                    clip_size = "2"
                    default_value="null" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        fe_request.add_item_fea();

        auto *user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        //测试不命中词典的情况
        user_app_info->set_app_id(1111000);
        user_app_info->set_event_time(5 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1112);
        user_app_info->set_event_time(9 * 86400 * 1000 - 1);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1113);
        user_app_info->set_event_time(7 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1116);
        user_app_info->set_event_time(20 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1119);
        user_app_info->set_event_time(15 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1114);
        user_app_info->set_event_time(8 * 86400 * 1000);

        user_app_info = fe_request.mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(1118);
        user_app_info->set_event_time(8 * 86400 * 1000);

        fe_request.set_req_time(10 * 86400 * 1000);

        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯", "即时通讯4"}), training_samples.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"聊天", "聊天4"}), training_samples.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"交互", "交互4"}), training_samples.training_samples(0).features(2));
    }

    TEST_CASE("seq_app2category_4") {
        mock_appinfo(12, "./appinfo");

        std::string xml_content_string = R"(
        <versions>
            <version name="union_ctr" dict="app_info" value="10001,10002,10003" />
        </versions>
        <config>
            <dict name="app_info"
                path="./appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
            />
            <dict name="ad_info"
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx.AdInfoDict"
                class_name="AdinfoDict"
            />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="f12"
                    type="seq_app2category"
                    dict_name="app_info"
                    source="item_info.appid,item_info.bid,.fe_request.req_time"
                    dedup = "true"
                    start = "86400"
                    clip_size = "2"
                    default_value="null" 
                    strategy="not_empty" />
                <feature name="10001"
                    slot="10001"
                    type="direct"
                    source="f12:0" />
                <feature name="10002"
                    slot="10002"
                    type="direct"
                    source="f12:1" />
                <feature name="10003"
                    slot="10003"
                    type="direct"
                    source="f12:2" />
            </features>
        </config>
        )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        for (const auto &conf: ret) {
            std::cout << "name = [" << conf.name << "]; partition = [" << conf.partition << "]; value proto = ["
                      << conf.value_proto << "], class name = [" << conf.class_name << "];path = [" << conf.path
                      << "]\n";
        }

        nlohmann::json json_array{};
        for (const auto &conf: ret) {
            nlohmann::json object{};
            object["name"] = conf.name;
            object["path"] = conf.path;
            object["value_proto"] = conf.value_proto;
            object["class_name"] = conf.class_name;
            json_array.emplace_back(object);
        }
        auto dicts_json_array = json_array.dump();

        long handle = init_offline_dicts(dicts_json_array);
        if (handle == 0) {
            std::cout << "init dict failed!" << std::endl;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(1111000);
        item_fea->mutable_item_info()->set_bid((int64_t) 5 * 86400 * 1000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(1112);
        item_fea->mutable_item_info()->set_bid((int64_t) 9 * 86400 * 1000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(1113);
        item_fea->mutable_item_info()->set_bid((int64_t) 7 * 86400 * 1000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(1116);
        item_fea->mutable_item_info()->set_bid((int64_t) 20 * 86400 * 1000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(1119);
        item_fea->mutable_item_info()->set_bid((int64_t) 15 * 86400 * 1000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(1114);
        item_fea->mutable_item_info()->set_bid((int64_t) 8 * 86400 * 1000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(1118);
        item_fea->mutable_item_info()->set_bid((int64_t) 8 * 86400 * 1000);

        fe_request.set_req_time(10 * 86400 * 1000);

        auto fe_str = fe_request.SerializeAsString();
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto ua_str = user_action->SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);
        phx::BatchTrainingSample training_samples{};
        training_samples.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(training_samples.training_samples_size(), 7);

        REQUIRE_EQ(training_samples.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10001, ({"null"}), training_samples.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"null"}), training_samples.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"null"}), training_samples.training_samples(0).features(2));

        REQUIRE_EQ(training_samples.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10001, ({"null"}), training_samples.training_samples(1).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"null"}), training_samples.training_samples(1).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"null"}), training_samples.training_samples(1).features(2));

        REQUIRE_EQ(training_samples.training_samples(2).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯3"}), training_samples.training_samples(2).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"聊天3"}), training_samples.training_samples(2).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"交互3"}), training_samples.training_samples(2).features(2));

        REQUIRE_EQ(training_samples.training_samples(3).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10001, ({"null"}), training_samples.training_samples(3).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"null"}), training_samples.training_samples(3).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"null"}), training_samples.training_samples(3).features(2));

        REQUIRE_EQ(training_samples.training_samples(4).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10001, ({"null"}), training_samples.training_samples(4).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"null"}), training_samples.training_samples(4).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"null"}), training_samples.training_samples(4).features(2));

        REQUIRE_EQ(training_samples.training_samples(5).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯4"}), training_samples.training_samples(5).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"聊天4"}), training_samples.training_samples(5).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"交互4"}), training_samples.training_samples(5).features(2));

        REQUIRE_EQ(training_samples.training_samples(6).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10001, ({"即时通讯4"}), training_samples.training_samples(6).features(0));
        TEST_SLOT_FEATURE_STR(10002, ({"聊天4"}), training_samples.training_samples(6).features(1));
        TEST_SLOT_FEATURE_STR(10003, ({"交互4"}), training_samples.training_samples(6).features(2));
    }

    TEST_CASE("seq_n_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_n" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time" start="60" end="86401" default_value="-1" clip_size="3" />
                    <feature name="10813" slot="10813" type="seq_n" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time" start="60" end="86401" default_value="-1" clip_size="3" />
                    <feature name="10814" slot="10814" type="seq_n" source="E@.fe_request.ad_user_app_seq_update_offline.user_app_info.count,E@.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time" start="60" end="86401" default_value="-1" clip_size="3" strategy="not_empty" />
                    <feature name="10815" slot="10815" type="seq_n" source="E@.fe_request.ad_user_app_seq_update_offline.user_app_info.count,E@.fe_request.ad_user_app_seq_update_offline.user_app_info.event_time,.fe_request.event_time" start="60" end="86401" default_value="-1" clip_size="3" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        //false
        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);

        //false
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 11 * 86400 * 1000);

        //false
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86404 * 1000);

        //true
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86401 * 1000);

        //true
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);

        //true
        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({900778570, 104436777, 104436888}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({0}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({-1}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(0).features(3));
    }

    TEST_CASE("seq_n_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_n" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time" start="60" end="86401" default_value="-1" clip_size="3" />
                    <feature name="10813" slot="10813" type="seq_n" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.req_time" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 11 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 11 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 9 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86401 * 1000);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10812, ({900778570, 104436777, 104436888}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({104435568, 104436777, 900778570}), ret.training_samples(0).features(1));
    }

    TEST_CASE("seq_n_hour_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_n_hour" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time" start="864000" day_n="30" hour="2" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);//start过滤

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000 + 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000 + 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000 - 3600 * 2000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 82 * 86400 * 1000 - 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10006);
        pb_info->set_event_time((int64_t) 89 * 86400 * 1000 - 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10007);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);//day_n过滤

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10813, ({10001, 10002, 10004, 10006}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(
                10814,
                ({(int64_t) 84 * 86400 * 1000, (int64_t) 92 * 86400 * 1000 + 3600 * 1000,
                  (int64_t) 99 * 86400 * 1000 - 3600 * 2000, (int64_t) 89 * 86400 * 1000 - 3600 * 1000}),
                ret.training_samples(0).features(1));
    }

    TEST_CASE("seq_n_hour_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_n_hour" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.event_time" start="864000" day_n="30" hour="2" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_n_hour" source=".fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" hour="2" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_bid((int64_t) 82 * 86400 * 1000);
        item_fea->mutable_item_info()->set_creative_id(10000);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 84 * 86400 * 1000 - 3600 * 1000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_bid((int64_t) 90 * 86400 * 1000 - 3600 * 3000);
        item_fea->mutable_item_info()->set_creative_id(10001);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 92 * 86400 * 1000 + 3600 * 2000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea->mutable_item_info()->set_bid((int64_t) 105 * 86400 * 1000);
        item_fea->mutable_item_info()->set_creative_id(10002);
        item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 98 * 86400 * 1000 + 3600 * 8000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);
        item_fea->mutable_item_info()->set_bid((int64_t) 85 * 86400 * 1000 + 3600 * 3000);
        item_fea->mutable_item_info()->set_creative_id(10003);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10004);
        item_fea->mutable_item_info()->set_bid((int64_t) 95 * 86400 * 1000);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 5);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 82 * 86400 * 1000}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10000}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 84 * 86400 * 1000 - 3600 * 1000}),
                                ret.training_samples(0).features(3));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10001}), ret.training_samples(1).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 92 * 86400 * 1000 + 3600 * 2000}),
                                ret.training_samples(1).features(3));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(2).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(2).features(3));

        REQUIRE_EQ(ret.training_samples(3).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(3).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(3).features(3));

        REQUIRE_EQ(ret.training_samples(4).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({10004}), ret.training_samples(4).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 95 * 86400 * 1000}), ret.training_samples(4).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(4).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(4).features(3));
    }

    TEST_CASE("test_seq_topn_v2_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.duration" topn="3" topn_type="3" reserve="0" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_duration(100);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 11 * 86400 * 1000);
        pb_info->set_duration(300);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 9 * 86400 * 1000);
        pb_info->set_duration(200);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time(10 * 86400 * 1000);
        pb_info->set_duration(500);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 9 * 86400 * 1000);
        pb_info->set_duration(100);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 4 * 86400 * 1000);
        pb_info->set_duration(300);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 7 * 86400 * 1000);
        pb_info->set_duration(200);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10812, ({10003, 10002, 10001}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({500, 500, 300}), ret.training_samples(0).features(1));
    }

    TEST_CASE("test_seq_topn_v2_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816,10818,10819" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time" topn_type="1" topn="10" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_topn_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time" topn_type="2" topn="10" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                    <feature name="10817" slot="10817" type="seq_topn_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.duration" topn_type="3" topn="10" />
                    <feature name="10818" slot="10818" type="direct" source="10817:0" />
                    <feature name="10819" slot="10819" type="direct" source="10817:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10001);
        pb_info->set_event_time(300);
        pb_info->set_duration(1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time(200);
        pb_info->set_duration(2);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time(200);
        pb_info->set_duration(2);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time(300);
        pb_info->set_duration(2);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time(200);
        pb_info->set_duration(2);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time(300);
        pb_info->set_duration(3);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 6);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10004, 10005, 10002, 10003, 10001}),
                                ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({300, 300, 300, 200, 200, 200}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10001, 10004, 10005, 10002, 10003}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({2, 1, 1, 1, 1}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10818, ({10001, 10005, 10004, 10002, 10003}), ret.training_samples(0).features(4));
        TEST_SLOT_FEATURE_INT64(10819, ({3, 3, 2, 2, 2}), ret.training_samples(0).features(5));
    }

    TEST_CASE("test_seq_topn_v2_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" topn="3" topn_type="3" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_name(10000);
        user_ads_stats_info->set_last_event_time(5 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.1);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time(11 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.3);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(9 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.2);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10003);
        user_ads_stats_info->set_last_event_time(10 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.5);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10004);
        user_ads_stats_info->set_last_event_time(9 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.1);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(4 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.3);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10004);
        user_ads_stats_info->set_last_event_time(7 * 86400 * 1000);
        user_ads_stats_info->set_dtr(0.2);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10812, ({10003, 10002, 10001}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, ({0.5, 0.5, 0.3}), ret.training_samples(0).features(1));
    }

    TEST_CASE("test_seq_topn_v2_4") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816,10818,10819,10821,10822" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time" topn_type="1" topn="2" reserve="1" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_topn_v2" source=".fe_request.ad_user_app_seq_install_list_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_install_list_offline.user_app_info.event_time" topn_type="1" topn="2"  reserve="1" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                    <feature name="10817" slot="10817" type="seq_topn_v2" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time" topn_type="2" topn="3" />
                    <feature name="10818" slot="10818" type="direct" source="10817:0" />
                    <feature name="10819" slot="10819" type="direct" source="10817:1" />
                    <feature name="10820" slot="10820" type="seq_topn_v2" source=".fe_request.ad_user_app_seq_install_list_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_install_list_offline.user_app_info.event_time" topn_type="2" topn="1" />
                    <feature name="10821" slot="10821" type="direct" source="10820:0" />
                    <feature name="10822" slot="10822" type="direct" source="10820:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 9 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 7 * 86400 * 1000);

        pb_use = fe_request.mutable_ad_user_app_seq_install_list_offline();
        pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 11 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 8);

        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10002}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 5 * 86400 * 1000, (int64_t) 7 * 86400 * 1000}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10000}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 11 * 86400 * 1000}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_INT64(10818, ({10001, 10002, 10000}), ret.training_samples(0).features(4));
        TEST_SLOT_FEATURE_INT64(10819, ({1, 1, 1}), ret.training_samples(0).features(5));
        TEST_SLOT_FEATURE_INT64(10821, ({10000}), ret.training_samples(0).features(6));
        TEST_SLOT_FEATURE_INT64(10822, ({1}), ret.training_samples(0).features(7));
    }

    TEST_CASE("test_seq_topn_v2_5") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_expose" topn="1" topn_type="3" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="seq_topn_v2" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" topn="0" topn_type="3" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_name(10001);
        user_ads_stats_info->set_last_event_time(10);
        user_ads_stats_info->set_num_expose(1);
        user_ads_stats_info->set_dtr(1.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10002);
        user_ads_stats_info->set_last_event_time(20);
        user_ads_stats_info->set_num_expose(2);
        user_ads_stats_info->set_dtr(2.1);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10003);
        user_ads_stats_info->set_last_event_time(30);
        user_ads_stats_info->set_num_expose(0);
        user_ads_stats_info->set_dtr(0.6);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_name(10003);
        user_ads_stats_info->set_last_event_time(40);
        user_ads_stats_info->set_num_expose(2);
        user_ads_stats_info->set_dtr(2.7);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({2}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({10003, 10002, 10001}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_FLOAT(10816, ({3.3, 2.1, 1.0}), ret.training_samples(0).features(3));
    }

    TEST_CASE("seq_hit_count_v1_1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({3}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(3).features(1));
        // std::cout << ret.DebugString() << std::endl;
    }

    TEST_CASE("seq_hit_count_v1_2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 100 * 86400 * 1000 - 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({1}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({3}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({3}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(3).features(1));
        // std::cout << ret.DebugString() << std::endl;
    }

    TEST_CASE("seq_hit_count_v1_3") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        // empty

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(3).features(1));
        // std::cout << ret.DebugString() << std::endl;
    }

    TEST_CASE("seq_hit_count_v1_4") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);// 防穿越

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(0).features(1));
    }

    TEST_CASE("seq_hit_count_v2_1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407,31408,31409,31410,31411" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407" slot="31407" type="direct" source="31406:0" />
                    <feature name="31408" slot="31408" type="direct" source="31406:1" />
                    
                    <feature name="31409"
                        slot="31409"
                        type="seq_hit_count_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                    <feature name="31410" slot="31410" type="direct" source="31409:0" />
                    <feature name="31411" slot="31411" type="direct" source="31409:1" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({0}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({1}), ret.training_samples(0).features(3));

        CHECK_EQ(ret.training_samples(1).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({2}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(1).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({2}), ret.training_samples(1).features(3));

        CHECK_EQ(ret.training_samples(2).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({3}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(2).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({2}), ret.training_samples(2).features(3));

        CHECK_EQ(ret.training_samples(3).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({0}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({0}), ret.training_samples(3).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({0}), ret.training_samples(3).features(3));
    }

    TEST_CASE("seq_hit_count_v2_2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407,31408,31409,31410,31411" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407" slot="31407" type="direct" source="31406:0" />
                    <feature name="31408" slot="31408" type="direct" source="31406:1" />
                    
                    <feature name="31409"
                        slot="31409"
                        type="seq_hit_count_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        />
                    <feature name="31410" slot="31410" type="direct" source="31409:0" />
                    <feature name="31411" slot="31411" type="direct" source="31409:1" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 100 * 86400 * 1000 - 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({1}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({1}), ret.training_samples(0).features(3));

        CHECK_EQ(ret.training_samples(1).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({2}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(1).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({2}), ret.training_samples(1).features(3));

        CHECK_EQ(ret.training_samples(2).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({3}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(2).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({3}), ret.training_samples(2).features(3));

        CHECK_EQ(ret.training_samples(3).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({0}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({0}), ret.training_samples(3).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({0}), ret.training_samples(3).features(3));
    }

    TEST_CASE("seq_hit_count_v2_3") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407,31408,31409,31410,31411" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407" slot="31407" type="direct" source="31406:0" />
                    <feature name="31408" slot="31408" type="direct" source="31406:1" />
                    
                    <feature name="31409"
                        slot="31409"
                        type="seq_hit_count_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        />
                    <feature name="31410" slot="31410" type="direct" source="31409:0" />
                    <feature name="31411" slot="31411" type="direct" source="31409:1" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        // empty

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({}), ret.training_samples(0).features(3));

        CHECK_EQ(ret.training_samples(1).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({}), ret.training_samples(1).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({}), ret.training_samples(1).features(3));

        CHECK_EQ(ret.training_samples(2).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({}), ret.training_samples(2).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({}), ret.training_samples(2).features(3));

        CHECK_EQ(ret.training_samples(3).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({}), ret.training_samples(3).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({}), ret.training_samples(3).features(3));
    }

    TEST_CASE("seq_hit_count_v2_4") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407,31408,31409,31410,31411" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407" slot="31407" type="direct" source="31406:0" />
                    <feature name="31408" slot="31408" type="direct" source="31406:1" />
                    
                    <feature name="31409"
                        slot="31409"
                        type="seq_hit_count_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                    <feature name="31410" slot="31410" type="direct" source="31409:0" />
                    <feature name="31411" slot="31411" type="direct" source="31409:1" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({0}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(31411, ({1}), ret.training_samples(0).features(3));
    }

    TEST_CASE("seq_hit_count_v2_event_time_qs_10") {
        //userappinfo.appid中传入item_info.appid中不存在的值，结果为0
        MESSAGE("seq_hit_count_v2 supplement start.... ");
        std::string xml_content_string = R"(
            <versions>
                <version name="union_ctr" dict="app_info" value="31406,31407,31408" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
						max_num="2"
                        />
                    <feature name="31407" slot="31407" type="direct" source="31406:0" />
                    <feature name="31408" slot="31408" type="direct" source="31406:1" />
                </features>
            </config>
        )";
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 10 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 1 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({0}), ret.training_samples(0).features(1));
    }

    TEST_CASE("seq_hit_count_v2_event_time_qs_1") {
        //传入1条数据，其中传入event_time，不传入req_time，结果为0；
        MESSAGE("seq_hit_count_v2 supplement start.... ");
        std::string xml_content_string = R"(
            <versions>
                <version name="union_ctr" dict="app_info" value="31406,31407,31408" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407" slot="31407" type="direct" source="31406:0" />
                    <feature name="31408" slot="31408" type="direct" source="31406:1" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        // fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31408, ({0}), ret.training_samples(0).features(1));
    }

    TEST_CASE("test_seq_coalesce_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_coalesce" source=".fe_request.ad_user_app_seq_install_list_realtime.user_app_info,.fe_request.ad_user_app_seq_install_list_offline.user_app_info" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.count" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *realtime = fe_request.mutable_ad_user_app_seq_install_list_realtime();

        auto *user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(60);
        user_app_info->set_count(100);
        user_app_info->set_app_id(10001);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(120);
        user_app_info->set_count(200);
        user_app_info->set_app_id(10002);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(180);
        user_app_info->set_count(300);
        user_app_info->set_app_id(10003);

        auto *offline = fe_request.mutable_ad_user_app_seq_install_list_offline();

        user_app_info = offline->add_user_app_info();
        user_app_info->set_event_time(240);
        user_app_info->set_count(400);
        user_app_info->set_app_id(20001);

        user_app_info = offline->add_user_app_info();
        user_app_info->set_event_time(300);
        user_app_info->set_count(500);
        user_app_info->set_app_id(20002);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10002, 10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 120, 180}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 200, 300}), ret.training_samples(0).features(2));
    }

    TEST_CASE("test_seq_coalesce_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_coalesce" source=".fe_request.ad_user_app_seq_install_list_offline.user_app_info,.fe_request.ad_user_app_seq_install_list_realtime.user_app_info" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.count" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *realtime = fe_request.mutable_ad_user_app_seq_install_list_realtime();

        auto *user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(60);
        user_app_info->set_count(100);
        user_app_info->set_app_id(10001);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(120);
        user_app_info->set_count(200);
        user_app_info->set_app_id(10002);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(180);
        user_app_info->set_count(300);
        user_app_info->set_app_id(10003);

        auto *offline = fe_request.mutable_ad_user_app_seq_install_list_offline();

        user_app_info = offline->add_user_app_info();
        user_app_info->set_event_time(240);
        user_app_info->set_count(400);
        user_app_info->set_app_id(20001);

        user_app_info = offline->add_user_app_info();
        user_app_info->set_event_time(300);
        user_app_info->set_count(500);
        user_app_info->set_app_id(20002);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({20001, 20002}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({240, 300}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({400, 500}), ret.training_samples(0).features(2));
    }

    TEST_CASE("test_seq_coalesce_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_coalesce" source=".fe_request.ad_user_app_seq_install_list_offline.user_app_info,.fe_request.ad_user_app_seq_install_list_realtime.user_app_info" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.count" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *realtime = fe_request.mutable_ad_user_app_seq_install_list_realtime();

        auto *user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(60);
        user_app_info->set_count(100);
        user_app_info->set_app_id(10001);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(120);
        user_app_info->set_count(200);
        user_app_info->set_app_id(10002);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(180);
        user_app_info->set_count(300);
        user_app_info->set_app_id(10003);

        // offline为空

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10002, 10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 120, 180}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 200, 300}), ret.training_samples(0).features(2));
    }

    TEST_CASE("test_seq_coalesce_4") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_coalesce" source=".fe_request.ad_user_app_seq_install_list_offline.user_app_info,.fe_request.ad_user_app_seq_install_list_realtime.user_app_info" strategy="not_empty" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.count" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        // realtime、offline都为空

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(0).features(2));
    }

    TEST_CASE("test_seq_coalesce_5") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_coalesce" source=".fe_request.ad_user_app_seq_all_first_use_offline.user_app_info,.fe_request.ad_user_app_seq_install_list_offline.user_app_info,.fe_request.ad_user_app_seq_install_list_realtime.user_app_info" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.count" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *realtime = fe_request.mutable_ad_user_app_seq_install_list_realtime();

        auto *user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(60);
        user_app_info->set_count(100);
        user_app_info->set_app_id(10001);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(120);
        user_app_info->set_count(200);
        user_app_info->set_app_id(10002);

        user_app_info = realtime->add_user_app_info();
        user_app_info->set_event_time(180);
        user_app_info->set_count(300);
        user_app_info->set_app_id(10003);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10002, 10003}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 120, 180}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 200, 300}), ret.training_samples(0).features(2));
    }

    TEST_CASE("test_seq_pb_clip_1") {
        MESSAGE("test_seq_pb_clip_1 start");
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_pb_clip" source=".fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" eventtime_key="event_time" start_day="0" end_day = "6" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                </features>
            </config>
          )";
        auto config_handle =
                reinterpret_cast<long>(init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr"));
        {
            google::protobuf::Arena arena{};
            auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
            auto fe_request = *fe_ptr;

            fe_request.set_req_time(15_calendar_day);
            fe_request.add_item_fea();

            auto *user_app_conv_seq =
                    fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10001);
            user_app_conv_seq->set_event_time(10_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10002);
            user_app_conv_seq->set_event_time(11_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10003);
            user_app_conv_seq->set_event_time(13_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10005);
            user_app_conv_seq->set_event_time(16_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(9_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(8_calendar_day);

            auto fe_str = fe_request.SerializeAsString();
            auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
            auto ua_str = user_action->SerializeAsString();
            auto batch_training_sample_str =
                    to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);

            phx::BatchTrainingSample batch_training_sample;
            batch_training_sample.ParseFromString(batch_training_sample_str);

            auto user_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();

            TEST_SLOT_FEATURE_INT64(10812, ({10001, 10002, 10003, 10006}),
                                    batch_training_sample.training_samples(0).features(0));
            TEST_SLOT_FEATURE_INT64(
                    10813,
                    ({user_seq->ad_user_app_conv_seq(0).event_time(), user_seq->ad_user_app_conv_seq(1).event_time(),
                      user_seq->ad_user_app_conv_seq(2).event_time(), user_seq->ad_user_app_conv_seq(4).event_time()}),
                    batch_training_sample.training_samples(0).features(1));
        }
        MESSAGE("test_seq_pb_clip_1 end");
    }

    TEST_CASE("test_seq_pb_clip_2") {
        MESSAGE("test_seq_pb_clip_2 start");
        //不配置start,不限制event_time起始时间
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_pb_clip" source=".fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" eventtime_key="event_time" end_day = "6" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                </features>
            </config>
          )";
        auto config_handle =
                reinterpret_cast<long>(init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr"));
        {
            google::protobuf::Arena arena{};
            auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
            auto fe_request = *fe_ptr;

            fe_request.set_req_time(15_calendar_day);
            fe_request.add_item_fea();

            auto *user_app_conv_seq =
                    fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10001);
            user_app_conv_seq->set_event_time(10_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10002);
            user_app_conv_seq->set_event_time(11_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10003);
            user_app_conv_seq->set_event_time(13_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10005);
            //超过请求时间,但是由于不限制start_day,所以会放到结果里
            user_app_conv_seq->set_event_time(16_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(9_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(8_calendar_day);

            auto fe_str = fe_request.SerializeAsString();
            auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
            auto ua_str = user_action->SerializeAsString();
            auto batch_training_sample_str =
                    to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);

            phx::BatchTrainingSample batch_training_sample;
            batch_training_sample.ParseFromString(batch_training_sample_str);

            auto user_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();

            TEST_SLOT_FEATURE_INT64(10812, ({10001, 10002, 10003, 10005, 10006}),
                                    batch_training_sample.training_samples(0).features(0));
            TEST_SLOT_FEATURE_INT64(
                    10813,
                    ({user_seq->ad_user_app_conv_seq(0).event_time(), user_seq->ad_user_app_conv_seq(1).event_time(),
                      user_seq->ad_user_app_conv_seq(2).event_time(), user_seq->ad_user_app_conv_seq(3).event_time(),
                      user_seq->ad_user_app_conv_seq(4).event_time()}),
                    batch_training_sample.training_samples(0).features(1));
        }
        MESSAGE("test_seq_pb_clip_2 end");
    }

    TEST_CASE("test_seq_pb_clip_3") {
        MESSAGE("test_seq_pb_clip_3 start");
        //不配置start,不限制event_time起始时间
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_pb_clip" source=".fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" eventtime_key="event_time" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                </features>
            </config>
          )";
        auto config_handle =
                reinterpret_cast<long>(init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr"));
        {
            google::protobuf::Arena arena{};
            auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
            auto fe_request = *fe_ptr;

            fe_request.set_req_time(15_calendar_day);
            fe_request.add_item_fea();

            auto *user_app_conv_seq =
                    fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10001);
            user_app_conv_seq->set_event_time(10_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10002);
            user_app_conv_seq->set_event_time(11_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10003);
            user_app_conv_seq->set_event_time(13_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10005);
            //超过请求时间,但是由于不限制start_day,所以会放到结果里
            user_app_conv_seq->set_event_time(16_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(9_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10007);
            user_app_conv_seq->set_event_time(8_calendar_day);

            auto fe_str = fe_request.SerializeAsString();
            auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
            auto ua_str = user_action->SerializeAsString();
            auto batch_training_sample_str =
                    to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);

            phx::BatchTrainingSample batch_training_sample;
            batch_training_sample.ParseFromString(batch_training_sample_str);

            auto user_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();

            TEST_SLOT_FEATURE_INT64(10812, ({10001, 10002, 10003, 10005, 10006, 10007}),
                                    batch_training_sample.training_samples(0).features(0));
            TEST_SLOT_FEATURE_INT64(
                    10813,
                    ({user_seq->ad_user_app_conv_seq(0).event_time(), user_seq->ad_user_app_conv_seq(1).event_time(),
                      user_seq->ad_user_app_conv_seq(2).event_time(), user_seq->ad_user_app_conv_seq(3).event_time(),
                      user_seq->ad_user_app_conv_seq(4).event_time(), user_seq->ad_user_app_conv_seq(5).event_time()}),
                    batch_training_sample.training_samples(0).features(1));
        }
        MESSAGE("test_seq_pb_clip_3 end");
    }
    //测试未命中任何的情况
    TEST_CASE("test_seq_pb_clip_4") {
        MESSAGE("test_seq_pb_clip_4 start");
        //不配置start,不限制event_time起始时间
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_pb_clip" source=".fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" eventtime_key="event_time" start_day = "20" />
                    <feature name="10812" slot="10812" type="direct" source="10811.app_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                </features>
            </config>
          )";
        auto config_handle =
                reinterpret_cast<long>(init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr"));
        {
            google::protobuf::Arena arena{};
            auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
            auto fe_request = *fe_ptr;

            fe_request.set_req_time(15_calendar_day);
            fe_request.add_item_fea();

            auto *user_app_conv_seq =
                    fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10001);
            user_app_conv_seq->set_event_time(10_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10002);
            user_app_conv_seq->set_event_time(11_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10003);
            user_app_conv_seq->set_event_time(13_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10005);
            //超过请求时间,但是由于不限制start_day,所以会放到结果里
            user_app_conv_seq->set_event_time(16_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10006);
            user_app_conv_seq->set_event_time(9_calendar_day);

            user_app_conv_seq = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
            user_app_conv_seq->set_app_id(10007);
            user_app_conv_seq->set_event_time(8_calendar_day);

            auto fe_str = fe_request.SerializeAsString();
            auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
            auto ua_str = user_action->SerializeAsString();
            auto batch_training_sample_str =
                    to_training_sample_v2(fe_str.c_str(), fe_str.size(), ua_str.c_str(), ua_str.size(), config_handle);

            phx::BatchTrainingSample batch_training_sample;
            batch_training_sample.ParseFromString(batch_training_sample_str);

            TEST_SLOT_FEATURE_INT64(10812, ({}), batch_training_sample.training_samples(0).features(0));
            TEST_SLOT_FEATURE_INT64(10813, ({}), batch_training_sample.training_samples(0).features(1));
        }
        MESSAGE("test_seq_pb_clip_4 end");
    }

    TEST_CASE("test_seq_priority_merge_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_priority_merge" source=".user_action.user_action_item_info.deep_conv_type,.user_action.user_action_item_info.conv_type,.user_action.user_action_item_info.conv_goal" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_deep_conv_type(5);
        user_action_item_info->set_conv_type(8);
        user_action_item_info->set_conv_goal(7);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_deep_conv_type(0);
        user_action_item_info->set_conv_type(6);
        user_action_item_info->set_conv_goal(1);

        user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_conv_type(0);
        user_action_item_info->set_conv_goal(9);

        user_action_item_info = user_action.add_user_action_item_info();

        // item 不为空
        fe_request.add_item_fea();
        fe_request.add_item_fea();
        fe_request.add_item_fea();
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 4);

        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(10812, ({5}), ret.training_samples(0).features(0));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(10812, ({6}), ret.training_samples(1).features(0));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(10812, ({9}), ret.training_samples(2).features(0));

        REQUIRE_EQ(ret.training_samples(3).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(3).features(0));
    }

    TEST_CASE("test_seq_priority_merge_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_priority_merge" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr_over_all,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr_over_avg" />
                    <feature name="10813" slot="10813" type="seq_priority_merge" source=".fe_request.ad_user_dmp_feature.user_dmp_feature.mkt_name_short_name,.fe_request.ad_user_dmp_feature.user_dmp_feature.last_magicui_version,.fe_request.ad_user_dmp_feature.user_dmp_feature.device_name" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ad_user = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *stats_info = ad_user->add_user_ads_stats_info();

        stats_info->set_dtr(1.1);
        stats_info->set_dtr_over_all(8.7);
        stats_info->set_dtr_over_avg(7.4);

        stats_info = ad_user->add_user_ads_stats_info();
        stats_info->set_dtr_over_all(8.8);
        stats_info->set_dtr_over_avg(3.4);

        stats_info = ad_user->add_user_ads_stats_info();
        stats_info->set_dtr(0);
        stats_info->set_dtr_over_avg(1.4);

        stats_info = ad_user->add_user_ads_stats_info();

        stats_info = ad_user->add_user_ads_stats_info();
        stats_info->set_dtr_over_all(0);
        stats_info->set_dtr_over_avg(2.7);

        auto *dmp_feature = fe_request.mutable_ad_user_dmp_feature()->mutable_user_dmp_feature();
        dmp_feature->set_last_magicui_version("");
        dmp_feature->set_device_name("13");

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);

        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_FLOAT(10812, ({1.1, 8.8, 1.4, 2.7}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10813, ({"13"}), ret.training_samples(0).features(1));
    }

    TEST_CASE("test_seq_priority_merge_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_priority_merge" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr_over_all,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr_over_avg" illegal_float="1.1" />
                    <feature name="10813" slot="10813" type="seq_priority_merge" source=".fe_request.ad_user_dmp_feature.user_dmp_feature.mkt_name_short_name,.fe_request.ad_user_dmp_feature.user_dmp_feature.last_magicui_version,.fe_request.ad_user_dmp_feature.user_dmp_feature.device_name" illegal_string="xxx" />
                    <feature name="10814" slot="10814" type="seq_priority_merge" source=".user_action.user_action_item_info.deep_conv_type,.user_action.user_action_item_info.conv_type,.user_action.user_action_item_info.conv_goal" illegal_int="5" />
                \</features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ad_user = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *stats_info = ad_user->add_user_ads_stats_info();

        stats_info->set_dtr(1.1);
        stats_info->set_dtr_over_all(8.7);
        stats_info->set_dtr_over_avg(7.4);

        stats_info = ad_user->add_user_ads_stats_info();
        stats_info->set_dtr_over_all(8.8);
        stats_info->set_dtr_over_avg(3.4);

        stats_info = ad_user->add_user_ads_stats_info();
        stats_info->set_dtr(0);
        stats_info->set_dtr_over_avg(1.4);

        stats_info = ad_user->add_user_ads_stats_info();

        stats_info = ad_user->add_user_ads_stats_info();
        stats_info->set_dtr_over_all(0);
        stats_info->set_dtr_over_avg(2.7);

        auto *dmp_feature = fe_request.mutable_ad_user_dmp_feature()->mutable_user_dmp_feature();
        dmp_feature->set_mkt_name_short_name("xxx");
        dmp_feature->set_last_magicui_version("xxx");
        dmp_feature->set_device_name("13");

        auto *user_action_item_info = user_action.add_user_action_item_info();
        user_action_item_info->set_deep_conv_type(5);
        user_action_item_info->set_conv_type(8);
        user_action_item_info->set_conv_goal(7);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);

        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_FLOAT(10812, ({8.7, 0, 0, 0, 0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10813, ({"13"}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({8}), ret.training_samples(0).features(2));
    }

    TEST_CASE("test_seq_ratio_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_ratio" source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.duration" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(20);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(30);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(40);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);

        TEST_SLOT_FEATURE_FLOAT(10811, ({0.1f, 0.2f, 0.3f, 0.4f}), ret.training_samples(0).features(0));
    }

    TEST_CASE("test_seq_ratio_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_ratio" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();

        user_ads_stats_info->set_dtr(1.0);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.5);

        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.5);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);

        TEST_SLOT_FEATURE_FLOAT(10811, ({0.2f, 0.3f, 0.5f}), ret.training_samples(0).features(0));
    }

    TEST_CASE("test_seq_ratio_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_ratio" source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.duration" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(-20);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(-30);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(40);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);

        TEST_SLOT_FEATURE_FLOAT(10811, ({-1.0f, -1.0f, -1.0f, -1.0f}), ret.training_samples(0).features(0));
    }

    TEST_CASE("test_seq_ratio_4") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_ratio" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                    default_value="2"
                    strategy="not_empty" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        // 输入为空
        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);

        TEST_SLOT_FEATURE_FLOAT(10811, ({2.0f}), ret.training_samples(0).features(0));
    }

    TEST_CASE("test_seq_ratio_5") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_ratio" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                    default_value="2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        // 输入为空
        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);

        TEST_SLOT_FEATURE_FLOAT(10811, ({}), ret.training_samples(0).features(0));
    }

    TEST_CASE("test_seq_div_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_div" source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.duration,.fe_request.ad_user_app_seq_expose_offline.user_app_info.count" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(10);
        ad_user_app_info->set_count(2);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(20);
        ad_user_app_info->set_count(5);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(30);
        ad_user_app_info->set_count(15);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(40);
        ad_user_app_info->set_count(8);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);

        TEST_SLOT_FEATURE_FLOAT(10811, ({5.0f, 4.0f, 2.0f, 5.0f}), ret.training_samples(0).features(0));
    }

    // 序列长度不一样，取短的；int/float混搭
    TEST_CASE("test_seq_div_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_div" source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.duration,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(20);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(30);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(40);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.8);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.5);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.5);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);

        TEST_SLOT_FEATURE_FLOAT(10811, ({12.5f, 8.0f, 20.0f}), ret.training_samples(0).features(0));
    }

    // 分母为0
    TEST_CASE("test_seq_div_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_div" source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.duration,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(20);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(30);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_duration(40);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.8);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.5);
        user_ads_stats_info = ads->add_user_ads_stats_info();

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);

        TEST_SLOT_FEATURE_FLOAT(10811, ({12.5f, 8.0f, -1.0f}), ret.training_samples(0).features(0));
    }

    // 输入为空 默认值
    TEST_CASE("test_seq_div_4") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_div" source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.duration,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" 
                        strategy="not_empty" default_value="2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.8);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.5);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.5);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);

        TEST_SLOT_FEATURE_FLOAT(10811, ({2.0f}), ret.training_samples(0).features(0));
    }

    // 输入为空 默认值
    TEST_CASE("test_seq_div_4") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_div" source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.duration,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr" 
                        default_value="2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.8);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.5);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.5);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);

        TEST_SLOT_FEATURE_FLOAT(10811, ({}), ret.training_samples(0).features(0));
    }

    // int类型值
    TEST_CASE("seq_hit_value_v2_1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31409,31410,31411" />
            </versions>
            <config>
                <features>
                    <feature name="31409"
                        slot="31409"
                        type="seq_hit_value_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.duration,.fe_request.item_fea.item_info.appid"
                        default_int64_value="-2"
                        />
                    <feature name="31410" slot="31410" type="direct" source="31409:0" />
                    <feature name="31411" slot="31411" type="direct" source="31409:1" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_duration(10);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_duration(20);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_duration(30);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_duration(40);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_duration(50);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_duration(60);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({10}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({20, 30}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({40, 50, 60}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({0}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({}), ret.training_samples(3).features(1));
    }

    // int类型值+string类型值
    TEST_CASE("seq_hit_value_v2_2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31409,31410,31411,31412" />
            </versions>
            <config>
                <features>
                    <feature name="31409"
                        slot="31409"
                        type="seq_hit_value_v2"
                        source=".fe_request.ad_user_seq_download_offline.user_behavior_info.app_id,.fe_request.ad_user_seq_download_offline.user_behavior_info.adunit_id,.fe_request.ad_user_seq_download_offline.user_behavior_info.session_id,.fe_request.item_fea.item_info.appid"
                        default_int64_value="-2"
                        />
                    <feature name="31410" slot="31410" type="direct" source="31409:0" />
                    <feature name="31411" slot="31411" type="direct" source="31409:1" />
                    <feature name="31412" slot="31412" type="direct" source="31409:2" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        auto *user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_app_id(10000);
        user_behavior_info->set_adunit_id(1);
        user_behavior_info->set_session_id("s1");

        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_app_id(10001);
        user_behavior_info->set_adunit_id(2);
        user_behavior_info->set_session_id("s2");

        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_app_id(10001);
        user_behavior_info->set_adunit_id(3);
        user_behavior_info->set_session_id("s3");

        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_app_id(10002);
        user_behavior_info->set_adunit_id(4);
        user_behavior_info->set_session_id("s4");

        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_app_id(10002);
        user_behavior_info->set_adunit_id(5);
        user_behavior_info->set_session_id("s5");

        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_app_id(10002);
        user_behavior_info->set_adunit_id(6);
        user_behavior_info->set_session_id("s6");

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({1}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(31412, ({"s1"}), ret.training_samples(0).features(2));

        CHECK_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({2, 3}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_STR(31412, ({"s2", "s3"}), ret.training_samples(1).features(2));

        CHECK_EQ(ret.training_samples(2).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({4, 5, 6}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_STR(31412, ({"s4", "s5", "s6"}), ret.training_samples(2).features(2));

        CHECK_EQ(ret.training_samples(3).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(31410, ({0}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_STR(31412, ({}), ret.training_samples(3).features(2));
    }

    // float类型值
    TEST_CASE("seq_hit_value_v2_3") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31409,31410,31411" />
            </versions>
            <config>
                <features>
                    <feature name="31409"
                        slot="31409"
                        type="seq_hit_value_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.item_fea.item_info.appid"
                        default_float_value="666"
                        />
                    <feature name="31410" slot="31410" type="direct" source="31409:0" />
                    <feature name="31411" slot="31411" type="direct" source="31409:1" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);

        auto *ads = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid();
        auto *user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.1);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.2);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.3);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.4);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.5);
        user_ads_stats_info = ads->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.6);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(31411, ({0.1f}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_FLOAT(31411, ({0.2f, 0.3f}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({1}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_FLOAT(31411, ({0.4f, 0.5f, 0.6f}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({0}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_FLOAT(31411, ({}), ret.training_samples(3).features(1));
    }

    // 没有值，退化为是否命中
    TEST_CASE("seq_hit_value_v2_4") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31409" />
            </versions>
            <config>
                <features>
                    <feature name="31409"
                        slot="31409"
                        type="seq_hit_value_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31409, ({1}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31409, ({1}), ret.training_samples(1).features(0));

        CHECK_EQ(ret.training_samples(2).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31409, ({1}), ret.training_samples(2).features(0));

        CHECK_EQ(ret.training_samples(3).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31409, ({0}), ret.training_samples(3).features(0));
    }

    TEST_CASE("seq_hit_value_v2_5") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31409,31410,31411" />
            </versions>
            <config>
                <features>
                    <feature name="31409"
                        slot="31409"
                        type="seq_hit_value_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.duration,.fe_request.item_fea.item_info.appid"
                        default_int64_value="-2"
                        />
                    <feature name="31410" slot="31410" type="direct" source="31409:0" />
                    <feature name="31411" slot="31411" type="direct" source="31409:1" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        // empty

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31410, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31411, ({}), ret.training_samples(3).features(1));
    }

    TEST_CASE("seq_hit_value_v2_6") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31409,31410,31411" />
            </versions>
            <config>
                <features>
                    <feature name="31409"
                        slot="31409"
                        type="seq_hit_value_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.duration,.fe_request.item_fea.item_info.appid"
                        default_int64_value="-2"
                        />
                    <feature name="31410" slot="31410" type="direct" source="31409:0" attr="cross" />
                    <feature name="31411" slot="31411" type="direct" source="31409:1" attr="cross" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_duration(10);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_duration(20);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_duration(30);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_duration(40);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_duration(50);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_duration(60);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(3010000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(3010001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto *extractor_response_ret = google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(&arena);
        toExtractorResponse(&arena, *fe_request, user_action, *ptr, *extractor_response_ret, false);

        CHECK_EQ(extractor_response_ret->item_features(0 + 0).slot_id(), 31410);
        CHECK_EQ(extractor_response_ret->item_features(0 + 0).bytes_list_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(0 + 0).signs_size(), 1);
        CHECK_EQ(extractor_response_ret->item_features(0 + 0).weights_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(0 + 0).signs(0), 0);

        CHECK_EQ(extractor_response_ret->item_features(0 + 1).slot_id(), 31410);
        CHECK_EQ(extractor_response_ret->item_features(0 + 1).bytes_list_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(0 + 1).signs_size(), 1);
        CHECK_EQ(extractor_response_ret->item_features(0 + 1).weights_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(0 + 1).signs(0), 0);

        CHECK_EQ(extractor_response_ret->item_features(0 + 2).slot_id(), 31410);
        CHECK_EQ(extractor_response_ret->item_features(0 + 2).bytes_list_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(0 + 2).signs_size(), 1);
        CHECK_EQ(extractor_response_ret->item_features(0 + 2).weights_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(0 + 2).signs(0), 1);

        CHECK_EQ(extractor_response_ret->item_features(0 + 3).slot_id(), 31410);
        CHECK_EQ(extractor_response_ret->item_features(0 + 3).bytes_list_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(0 + 3).signs_size(), 1);
        CHECK_EQ(extractor_response_ret->item_features(0 + 3).weights_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(0 + 1).signs(0), 0);

        CHECK_EQ(extractor_response_ret->item_features(4 + 0).slot_id(), 31411);
        CHECK_EQ(extractor_response_ret->item_features(4 + 0).bytes_list_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(4 + 0).signs_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(4 + 0).weights_size(), 0);

        CHECK_EQ(extractor_response_ret->item_features(4 + 1).slot_id(), 31411);
        CHECK_EQ(extractor_response_ret->item_features(4 + 1).bytes_list_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(4 + 1).signs_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(4 + 1).weights_size(), 0);

        CHECK_EQ(extractor_response_ret->item_features(4 + 2).slot_id(), 31411);
        CHECK_EQ(extractor_response_ret->item_features(4 + 2).bytes_list_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(4 + 2).signs_size(), 3);
        CHECK_EQ(extractor_response_ret->item_features(4 + 2).weights_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(4 + 2).signs(0), 40);
        CHECK_EQ(extractor_response_ret->item_features(4 + 2).signs(1), 50);
        CHECK_EQ(extractor_response_ret->item_features(4 + 2).signs(2), 60);

        CHECK_EQ(extractor_response_ret->item_features(4 + 3).slot_id(), 31411);
        CHECK_EQ(extractor_response_ret->item_features(4 + 3).bytes_list_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(4 + 3).signs_size(), 0);
        CHECK_EQ(extractor_response_ret->item_features(4 + 3).weights_size(), 0);
    }
}