#include "phx-fe/src/framework.h"
#include "phx-fe/src/service.h"
#include "phx-fe/util/farmhash.h"
#include "phx-fe/util/math.h"
#include "phx-fe/util/murmur_hash3.h"
#include "phx_test.h"
#include <cstdint>
#include <gflags/gflags.h>
#include <string>

// base类算子
TEST_SUITE("base_1") {
    TEST_CASE("combine_1") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="combine"
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.conv_type"
                        strategy="hash"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        pb_item_fea->mutable_item_info()->set_rta_id("2000");
        pb_item_fea->mutable_item_info()->set_conv_type(18);

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        pb_item_fea->mutable_item_info()->set_rta_id("2001");
        pb_item_fea->mutable_item_info()->set_conv_type(9);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        TEST_HASH_SLOT_FEATURE_INT64(10811, ({1000, 18}), ret.training_samples(0).features(0));
        TEST_HASH_SLOT_FEATURE_INT64(10811, ({1001, 9}), ret.training_samples(1).features(0));
    }

    TEST_CASE("combine_2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="combine"
                        source=".fe_request.ad_user_seq_download_offline.user_behavior_info.session_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.count,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.request_id"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        pb_item_fea->mutable_item_info()->set_rta_id("2000");
        pb_item_fea->mutable_item_info()->set_conv_type(18);

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        pb_item_fea->mutable_item_info()->set_rta_id("2001");
        pb_item_fea->mutable_item_info()->set_conv_type(9);

        auto ad_user_seq = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        ad_user_seq->set_session_id("test_seesion_id_1");
        ad_user_seq = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        ad_user_seq->set_session_id("test_seesion_id_2");
        ad_user_seq = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        ad_user_seq->set_session_id("test_seesion_id_3");

        auto ad_user_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_conv_seq->set_request_id("conv_request_id_1");
        ad_user_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_conv_seq->set_request_id("conv_request_id_2");

        auto ad_user_app_seq_expose_offline = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_seq_expose_offline->set_count(100);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        TEST_FEATURE_STR(({"test_seesion_id_1", "test_seesion_id_2", "test_seesion_id_3", "conv_request_id_1",
                           "conv_request_id_2"}),
                         ret.training_samples(0).features(0));
        TEST_FEATURE_STR(({"test_seesion_id_1", "test_seesion_id_2", "test_seesion_id_3", "conv_request_id_1",
                           "conv_request_id_2"}),
                         ret.training_samples(1).features(0));
    }

    TEST_CASE("combine_3") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="combine"
                        source=".fe_request.ad_user_seq_download_offline.user_behavior_info.session_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.count,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.request_id"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        pb_item_fea->mutable_item_info()->set_rta_id("2000");
        pb_item_fea->mutable_item_info()->set_conv_type(18);

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        pb_item_fea->mutable_item_info()->set_rta_id("2001");
        pb_item_fea->mutable_item_info()->set_conv_type(9);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        TEST_FEATURE_STR(({}), ret.training_samples(0).features(0));
        TEST_FEATURE_STR(({}), ret.training_samples(0).features(0));

        TEST_FEATURE_INT64(({}), ret.training_samples(0).features(0));
        TEST_FEATURE_INT64(({}), ret.training_samples(0).features(0));

        TEST_FEATURE_FLOAT(({}), ret.training_samples(0).features(0));
        TEST_FEATURE_FLOAT(({}), ret.training_samples(0).features(0));
    }

    TEST_CASE("combine_4") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="combine"
                        source=".user_action.user_action_item_info.pctr,.user_action.user_action_item_info.pcvr"
                        strategy="hash"
                    />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request->add_item_fea();

        phx::UserAction *user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action->add_user_action_item_info();
        auto user_action_str = user_action->SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();

        // 哈希策略不支持float类型，抛出异常，使用doctest框架捕获
        CHECK_THROWS_AS(to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                              user_action_str.size(), config_handle),
                        std::runtime_error);
    }

    TEST_CASE("combine_5") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="combine"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id,.fe_request.ad_user_seq_download_realtime.user_behavior_info.app_id"
                        max_size="5"
                        strategy="hash"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_app_id(1);
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_app_id(2);
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_app_id(3);

        fe_request->mutable_ad_user_seq_download_realtime()->add_user_behavior_info()->set_app_id(4);
        fe_request->mutable_ad_user_seq_download_realtime()->add_user_behavior_info()->set_app_id(5);
        fe_request->mutable_ad_user_seq_download_realtime()->add_user_behavior_info()->set_app_id(6);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        TEST_HASH_SLOT_FEATURE_INT64(10811, ({1, 2, 3, 4, 5}), ret.training_samples(0).features(0));
    }

    TEST_CASE("combine_6") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="combine"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id,.fe_request.ad_user_seq_download_realtime.user_behavior_info.session_id,.fe_request.ad_user_seq_game_payment_realtime.ad_user_app_conv_seq.request_id"
                        max_size="7"
                        strategy="hash"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("A");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("B");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("C");

        fe_request->mutable_ad_user_seq_download_realtime()->add_user_behavior_info()->set_session_id("D");
        fe_request->mutable_ad_user_seq_download_realtime()->add_user_behavior_info()->set_session_id("E");
        fe_request->mutable_ad_user_seq_download_realtime()->add_user_behavior_info()->set_session_id("F");

        fe_request->mutable_ad_user_seq_game_payment_realtime()->add_ad_user_app_conv_seq()->set_request_id("G");
        fe_request->mutable_ad_user_seq_game_payment_realtime()->add_ad_user_app_conv_seq()->set_request_id("H");
        fe_request->mutable_ad_user_seq_game_payment_realtime()->add_ad_user_app_conv_seq()->set_request_id("I");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        TEST_HASH_SLOT_FEATURE_STR(10811, ({"A", "B", "C", "D", "E", "F", "G"}), ret.training_samples(0).features(0));
    }

    TEST_CASE("int64_difference") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="int64_difference"
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        auto item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_appid(10l * 86400 * 1000);
        item_info->set_bid(10l * 86300 * 1000);

        item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_bid(10l * 86200 * 1000);

        item_info = fe_request->add_item_fea()->mutable_item_info();
        item_info->set_bid(10l * 86100 * 1000);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(3, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        CHECK_EQ(10811, ret.training_samples(0).features(0).slot_id());
        REQUIRE_EQ(1, ret.training_samples(0).features(0).signs_size());
        CHECK_EQ(1000000l, ret.training_samples(0).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        CHECK_EQ(10811, ret.training_samples(1).features(0).slot_id());
        REQUIRE_EQ(1, ret.training_samples(1).features(0).signs_size());
        CHECK_EQ(2000000l, ret.training_samples(1).features(0).signs(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        CHECK_EQ(10811, ret.training_samples(2).features(0).slot_id());
        REQUIRE_EQ(1, ret.training_samples(2).features(0).signs_size());
        CHECK_EQ(3000000l, ret.training_samples(2).features(0).signs(0));
    }

    TEST_CASE("clip") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="clip"
                        source=".fe_request.context.info_flow_context.info_flow_item.source"
                        start="0"
                        size="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("123");
        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("456");
        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("789");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_STR(10811, ({"123", "456"}), ret.training_samples(0).features(0));
    }

    TEST_CASE("exists") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="exists"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10811, {1}, ret.training_samples(0).features(0));

        fe_request->mutable_ad_user_seq_click_realtime()->clear_user_behavior_info();
        fe_request_str = fe_request->SerializeAsString();
        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10811, {0}, ret.training_samples(0).features(0));
    }

    TEST_CASE("len_diff") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="len_diff"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id,.fe_request.context.info_flow_context.info_flow_item.source"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");

        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("测试");
        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("测试");
        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("测试");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10811, {-2}, ret.training_samples(0).features(0));

        fe_request->mutable_ad_user_seq_click_realtime()->clear_user_behavior_info();
        fe_request->mutable_context()->mutable_info_flow_context()->clear_info_flow_item();

        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");

        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("测试");

        fe_request_str = fe_request->SerializeAsString();
        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10811, {2}, ret.training_samples(0).features(0));
    }

    TEST_CASE("connect_all_to_string_empty") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="connect_all_to_string"
                        source=".fe_request.item_fea.item_info.rta_id,.fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.conv_type"
                        first_connector="#"
                        second_connector=";"
                        tail="game"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        pb_item_fea->mutable_item_info()->set_conv_type(18);

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        pb_item_fea->mutable_item_info()->set_conv_type(9);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        // TODO: 测试first_connector
        REQUIRE_EQ(2, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f0_0 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f0_0.bytes_list_size());
        CHECK_EQ(";1000;18;game", f0_0.bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f1_0 = ret.training_samples(1).features(0);
        REQUIRE_EQ(1, f1_0.bytes_list_size());
        CHECK_EQ(";1001;9;game", f1_0.bytes_list(0));
    }

    TEST_CASE("connect_all_to_string_user_empty") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="connect_all_to_string"
                        source=".user_action.oaid,.user_action.request_id,.user_action.media_id,.user_action.adunit_id,.user_action.query,.user_action.request_time,.user_action.experiment_algo_id,.user_action.traffic_type,.user_action.algo_id,.user_action.algo_trace_id"
                        first_connector="#"
                        second_connector=";"
                        tail="game"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        pb_item_fea->mutable_item_info()->set_conv_type(18);

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        pb_item_fea->mutable_item_info()->set_conv_type(9);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        // TODO: 测试first_connector
        REQUIRE_EQ(2, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f0_0 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f0_0.bytes_list_size());
        CHECK_EQ(";;0;0;;0;0;0;;;game", f0_0.bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f1_0 = ret.training_samples(1).features(0);
        REQUIRE_EQ(1, f1_0.bytes_list_size());
        CHECK_EQ(";;0;0;;0;0;0;;;game", f1_0.bytes_list(0));
    }
    TEST_CASE("len_ratio ratio_type=1") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="len_ratio"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id,.fe_request.context.info_flow_context.info_flow_item.source"
                        ratio_type="1"
                        default_value="-1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");

        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("测试");
        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("测试");
        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("测试");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10811, {0.5}, ret.training_samples(0).features(0));
    }

    TEST_CASE("len_ratio ratio_type=2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="len_ratio"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id,.fe_request.context.info_flow_context.info_flow_item.source"
                        ratio_type="2"
                        default_value="-1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");

        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("测试");
        fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item()->set_source("测试");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10811, {1.5}, ret.training_samples(0).features(0));
    }

    // 如果多个item，非第一个item为空，设置not_empty也抛出异常
    TEST_CASE("test_not_first_hf") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_hit_list"
                        source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.app_id,.fe_request.item_fea.item_info.appid,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.request_id"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        strategy="not_empty"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        strategy="not_empty"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserConvInfo *ad_conv_info =
                fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10000);
        ad_conv_info->set_request_id("游戏中心0");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10001);
        ad_conv_info->set_request_id("应用市场1");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10000);
        ad_conv_info->set_request_id("游戏中心2");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10002);
        ad_conv_info->set_request_id("游戏中心3");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10001);
        ad_conv_info->set_request_id("应用市场4");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10002);
        ad_conv_info->set_request_id("游戏中心5");

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        bool flag = false;
        try {
            const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                       user_action_str.c_str(), user_action_str.size(), config_handle);
        } catch (...) {
            flag = true;
        }

        CHECK_EQ(true, flag);
    }

    TEST_CASE("select_model_config_1") {
        std::string fe_config = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info" filter_key="num_expose" fields="name,dtr,dtr_over_all" topn="4" reserve="0" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
        )";
        std::string model_input_config = R"(
    input_tensors:
        - input_part:
            tensor_name: "gate_embs"
            type: "sparse"
            slots:  ['10813','10814']
            embedding_size: 62
            combine_method: "sum"
            save_ratio: 1
        - input_part:
            tensor_name: "dnn_embs"
            type: "sparse"
            slots:  ['10812']
            embedding_size: 62
            combine_method: "sum"
            save_ratio: 1
        )";
        auto model_input_fe_config =
                init_xml_online_by_decypt_content_new_sample(fe_config, model_input_config, nullptr);
        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAdsStatsInfo *ad_stat_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10001);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(0.2);
        ad_stat_info->set_dtr_over_all(8.7);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10000);
        ad_stat_info->set_num_expose(10006);
        ad_stat_info->set_dtr(3.1);
        ad_stat_info->set_dtr_over_all(6.4);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10003);
        ad_stat_info->set_num_expose(10001);
        ad_stat_info->set_dtr(2.0);
        ad_stat_info->set_dtr_over_all(2.8);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10002);
        ad_stat_info->set_num_expose(10003);
        ad_stat_info->set_dtr(7.1);
        ad_stat_info->set_dtr_over_all(6.3);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10004);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(1.1);
        ad_stat_info->set_dtr_over_all(1.9);

        // item
        fe_request->add_item_fea();
        fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        phx::BatchTrainingSample ret;
        toTraningSampleV2(&arena, *fe_request, user_action, *model_input_fe_config, ret);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10002, 10003, 10001}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, ({3.1, 7.1, 2.0, 0.2}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({6.4, 6.3, 2.8, 8.7}), ret.training_samples(0).features(2));

        CHECK_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10002, 10003, 10001}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, ({3.1, 7.1, 2.0, 0.2}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({6.4, 6.3, 2.8, 8.7}), ret.training_samples(1).features(2));
    }

    TEST_CASE("select_model_config_2") {
        std::string fe_config = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info" filter_key="num_expose" fields="name,dtr,dtr_over_all" topn="4" reserve="0" />
                    <feature name="10813" slot="10813" type="connect" source="10812,10814" connector="#" tail="game" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
        )";
        std::string model_input_config = R"(
    input_tensors:
        - input_part:
            tensor_name: "gate_embs"
            type: "sparse"
            slots:  ['10814']
            embedding_size: 62
            combine_method: "sum"
            save_ratio: 1
        - input_part:
            tensor_name: "dnn_embs"
            type: "sparse"
            slots:  ['10812','10813']
            embedding_size: 62
            combine_method: "sum"
            save_ratio: 1
        )";
        auto model_input_fe_config =
                init_xml_online_by_decypt_content_new_sample(fe_config, model_input_config, nullptr);
        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAdsStatsInfo *ad_stat_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10001);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(0.2);
        ad_stat_info->set_dtr_over_all(8.7);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10000);
        ad_stat_info->set_num_expose(10006);
        ad_stat_info->set_dtr(3.1);
        ad_stat_info->set_dtr_over_all(6.4);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10003);
        ad_stat_info->set_num_expose(10001);
        ad_stat_info->set_dtr(2.0);
        ad_stat_info->set_dtr_over_all(2.8);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10002);
        ad_stat_info->set_num_expose(10003);
        ad_stat_info->set_dtr(7.1);
        ad_stat_info->set_dtr_over_all(6.3);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10004);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(1.1);
        ad_stat_info->set_dtr_over_all(1.9);

        // item
        fe_request->add_item_fea();
        fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        phx::BatchTrainingSample ret;
        toTraningSampleV2(&arena, *fe_request, user_action, *model_input_fe_config, ret);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10002, 10003, 10001}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10814, ({6.4, 6.3, 2.8, 8.7}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(
                10813, ({"10000#6.400000#game", "10002#6.300000#game", "10003#2.800000#game", "10001#8.700000#game"}),
                ret.training_samples(0).features(2));

        CHECK_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10002, 10003, 10001}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_FLOAT(10814, ({6.4, 6.3, 2.8, 8.7}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_STR(
                10813, ({"10000#6.400000#game", "10002#6.300000#game", "10003#2.800000#game", "10001#8.700000#game"}),
                ret.training_samples(0).features(2));
    }

    TEST_CASE("select_model_config_3") {
        std::string fe_config = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info" filter_key="num_expose" fields="name,dtr,dtr_over_all" topn="4" reserve="0" />
                    <feature name="10813" slot="10813" type="connect" source="10812,10814" connector="#" tail="game" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
        )";
        std::string model_input_config = R"(
    input_tensors:
        - input_part:
            tensor_name: "gate_embs"
            type: "sparse"
            slot: 10814
            embedding_size: 62
            combine_method: "sum"
            save_ratio: 1
        - input_part:
            tensor_name: "dnn_embs"
            type: "sparse"
            slots:  ['10812','10813']
            embedding_size: 62
            combine_method: "sum"
            save_ratio: 1
        )";
        auto model_input_fe_config =
                init_xml_online_by_decypt_content_new_sample(fe_config, model_input_config, nullptr);
        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAdsStatsInfo *ad_stat_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10001);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(0.2);
        ad_stat_info->set_dtr_over_all(8.7);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10000);
        ad_stat_info->set_num_expose(10006);
        ad_stat_info->set_dtr(3.1);
        ad_stat_info->set_dtr_over_all(6.4);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10003);
        ad_stat_info->set_num_expose(10001);
        ad_stat_info->set_dtr(2.0);
        ad_stat_info->set_dtr_over_all(2.8);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10002);
        ad_stat_info->set_num_expose(10003);
        ad_stat_info->set_dtr(7.1);
        ad_stat_info->set_dtr_over_all(6.3);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10004);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(1.1);
        ad_stat_info->set_dtr_over_all(1.9);

        // item
        fe_request->add_item_fea();
        fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        phx::BatchTrainingSample ret;
        toTraningSampleV2(&arena, *fe_request, user_action, *model_input_fe_config, ret);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10002, 10003, 10001}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10814, ({6.4, 6.3, 2.8, 8.7}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(
                10813, ({"10000#6.400000#game", "10002#6.300000#game", "10003#2.800000#game", "10001#8.700000#game"}),
                ret.training_samples(0).features(2));

        CHECK_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10002, 10003, 10001}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_FLOAT(10814, ({6.4, 6.3, 2.8, 8.7}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_STR(
                10813, ({"10000#6.400000#game", "10002#6.300000#game", "10003#2.800000#game", "10001#8.700000#game"}),
                ret.training_samples(0).features(2));
    }

    TEST_CASE("message_filter") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                             slot="10811"
                             type="message_filter"
                             source=".fe_request.ad_user_seq_game_payment_offline.ad_user_app_conv_seq,.fe_request.req_time"
                             str_filter="service_id,hit,sid_1,sid_6,sid_7;request_id,hit,rid_1,rid_7"
                             int_filter="pay_money,hit,100,200,300,10"
                             eventtime_key="event_time"
                             clip_h="720"
                             start_ms="864000000" />
                    <feature name="10812" slot="10812" type="direct" source="10811.adunit_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.pay_money" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();
        fe_request->set_req_time(110L * 86400 * 1000);

        auto ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_1");
        ad_user_app_conv_seq->set_request_id("rid_1");
        ad_user_app_conv_seq->set_pay_money(10);
        ad_user_app_conv_seq->set_event_time(95L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(100);
        ad_user_app_conv_seq->set_app_id(1000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_2");
        ad_user_app_conv_seq->set_request_id("rid_2");
        ad_user_app_conv_seq->set_pay_money(20);
        ad_user_app_conv_seq->set_event_time(85L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(200);
        ad_user_app_conv_seq->set_app_id(2000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_3");
        ad_user_app_conv_seq->set_request_id("rid_3");
        ad_user_app_conv_seq->set_pay_money(30);
        ad_user_app_conv_seq->set_event_time(60L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(300);
        ad_user_app_conv_seq->set_app_id(3000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_4");
        ad_user_app_conv_seq->set_request_id("rid_4");
        ad_user_app_conv_seq->set_pay_money(40);
        ad_user_app_conv_seq->set_event_time(105L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(400);
        ad_user_app_conv_seq->set_app_id(4000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_5");
        ad_user_app_conv_seq->set_request_id("rid_5");
        ad_user_app_conv_seq->set_pay_money(50);
        ad_user_app_conv_seq->set_event_time(95L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(500);
        ad_user_app_conv_seq->set_app_id(5000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_6");
        ad_user_app_conv_seq->set_request_id("rid_6");
        ad_user_app_conv_seq->set_pay_money(200);
        ad_user_app_conv_seq->set_event_time(95L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(600);
        ad_user_app_conv_seq->set_app_id(6000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_7");
        ad_user_app_conv_seq->set_request_id("rid_7");
        ad_user_app_conv_seq->set_pay_money(100);
        ad_user_app_conv_seq->set_event_time(85L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(700);
        ad_user_app_conv_seq->set_app_id(7000);

        phx::UserAction *user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action->SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(2, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({100, 700}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({10, 100}), ret.training_samples(0).features(1));
    }

    TEST_CASE("message_filter_v2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                             slot="10811"
                             type="message_filter_v2"
                             source=".fe_request.ad_user_seq_game_payment_offline.ad_user_app_conv_seq,.fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.service_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.app_id"
                             str_filter="${source[2]},hit,sid_1,sid_6,sid_7;request_id,hit,rid_1,rid_7"
                             int_filter="pay_money,hit,${source[3]}"
                             eventtime_key="event_time"
                             clip_h="720"
                             start_ms="864000000" />
                    <feature name="10812" slot="10812" type="direct" source="10811.adunit_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.pay_money" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();
        fe_request->set_req_time(110L * 86400 * 1000);

        auto ad_user_app_conv_seq =
                fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_1");

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_2");

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_3");

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_4");

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_5");

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_6");

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_7");

        auto user_app_info = fe_request->mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(10);
        user_app_info = fe_request->mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(100);

        // 设置字段值
        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_request_id("rid_1");
        ad_user_app_conv_seq->set_pay_money(10);
        ad_user_app_conv_seq->set_event_time(95L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(100);
        ad_user_app_conv_seq->set_app_id(1000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_request_id("rid_2");
        ad_user_app_conv_seq->set_pay_money(20);
        ad_user_app_conv_seq->set_event_time(85L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(200);
        ad_user_app_conv_seq->set_app_id(2000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_request_id("rid_3");
        ad_user_app_conv_seq->set_pay_money(30);
        ad_user_app_conv_seq->set_event_time(60L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(300);
        ad_user_app_conv_seq->set_app_id(3000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_request_id("rid_4");
        ad_user_app_conv_seq->set_pay_money(40);
        ad_user_app_conv_seq->set_event_time(105L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(400);
        ad_user_app_conv_seq->set_app_id(4000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_request_id("rid_5");
        ad_user_app_conv_seq->set_pay_money(50);
        ad_user_app_conv_seq->set_event_time(95L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(500);
        ad_user_app_conv_seq->set_app_id(5000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_request_id("rid_6");
        ad_user_app_conv_seq->set_pay_money(200);
        ad_user_app_conv_seq->set_event_time(95L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(600);
        ad_user_app_conv_seq->set_app_id(6000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_request_id("rid_7");
        ad_user_app_conv_seq->set_pay_money(100);
        ad_user_app_conv_seq->set_event_time(85L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(700);
        ad_user_app_conv_seq->set_app_id(7000);

        phx::UserAction *user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action->SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(2, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({100, 700}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({10, 100}), ret.training_samples(0).features(1));
    }

    TEST_CASE("message_filter_v2_2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                             slot="10811"
                             type="message_filter_v2"
                             source=".fe_request.ad_user_seq_game_payment_offline.ad_user_app_conv_seq,.fe_request.req_time,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.service_id,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.request_id,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.pay_money,.fe_request.ad_user_seq_conv_game_first_payment_realtime.ad_user_app_conv_seq.service_id,.fe_request.ad_user_seq_conv_game_first_payment_realtime.ad_user_app_conv_seq.request_id,.fe_request.ad_user_seq_conv_game_first_payment_realtime.ad_user_app_conv_seq.pay_money"
                             str_filter="${source[2]},hit,${source[5]},sid_7;${source[3]},hit,${source[6]}"
                             int_filter="${source[4]},hit,${source[7]}"
                             eventtime_key="event_time"
                             clip_h="720"
                             start_ms="864000000" />
                    <feature name="10812" slot="10812" type="direct" source="10811.adunit_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.pay_money" />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();
        fe_request->set_req_time(110L * 86400 * 1000);

        auto ad_user_app_conv_seq =
                fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_1");
        ad_user_app_conv_seq->set_request_id("rid_1");
        ad_user_app_conv_seq->set_pay_money(10);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_2");
        ad_user_app_conv_seq->set_request_id("rid_2");
        ad_user_app_conv_seq->set_pay_money(20);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_3");
        ad_user_app_conv_seq->set_request_id("rid_3");
        ad_user_app_conv_seq->set_pay_money(30);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_4");
        ad_user_app_conv_seq->set_request_id("rid_4");
        ad_user_app_conv_seq->set_pay_money(40);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_5");
        ad_user_app_conv_seq->set_request_id("rid_5");
        ad_user_app_conv_seq->set_pay_money(50);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_6");
        ad_user_app_conv_seq->set_request_id("rid_6");
        ad_user_app_conv_seq->set_pay_money(20);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_7");
        ad_user_app_conv_seq->set_request_id("rid_7");
        ad_user_app_conv_seq->set_pay_money(100);

        fe_request->mutable_ad_user_seq_conv_sdk_conversion_realtime()->add_ad_user_app_conv_seq()->set_service_id(
                "request_id");

        ad_user_app_conv_seq =
                fe_request->mutable_ad_user_seq_conv_game_first_payment_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_1");
        ad_user_app_conv_seq->set_request_id("rid_1");
        ad_user_app_conv_seq->set_pay_money(100);// pay_money不符合

        ad_user_app_conv_seq =
                fe_request->mutable_ad_user_seq_conv_game_first_payment_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_2");
        ad_user_app_conv_seq->set_request_id("rid_2_2");// rid不符合
        ad_user_app_conv_seq->set_pay_money(20);

        ad_user_app_conv_seq =
                fe_request->mutable_ad_user_seq_conv_game_first_payment_realtime()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_8");// sid_7 配置在xml中
        ad_user_app_conv_seq->set_request_id("rid_7");
        ad_user_app_conv_seq->set_pay_money(100);

        auto user_app_info = fe_request->mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(10);
        user_app_info = fe_request->mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(20);
        user_app_info = fe_request->mutable_ad_user_app_seq_use_offline()->add_user_app_info();
        user_app_info->set_app_id(200);

        // 设置字段值
        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_1");
        ad_user_app_conv_seq->set_request_id("rid_1");
        ad_user_app_conv_seq->set_pay_money(10);
        ad_user_app_conv_seq->set_event_time(95L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(100);
        ad_user_app_conv_seq->set_app_id(1000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_2");
        ad_user_app_conv_seq->set_request_id("rid_2");
        ad_user_app_conv_seq->set_pay_money(20);
        ad_user_app_conv_seq->set_event_time(85L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(200);
        ad_user_app_conv_seq->set_app_id(2000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_3");
        ad_user_app_conv_seq->set_request_id("rid_3");
        ad_user_app_conv_seq->set_pay_money(30);
        ad_user_app_conv_seq->set_event_time(60L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(300);
        ad_user_app_conv_seq->set_app_id(3000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_4");
        ad_user_app_conv_seq->set_request_id("rid_4");
        ad_user_app_conv_seq->set_pay_money(40);
        ad_user_app_conv_seq->set_event_time(105L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(400);
        ad_user_app_conv_seq->set_app_id(4000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_5");
        ad_user_app_conv_seq->set_request_id("rid_5");
        ad_user_app_conv_seq->set_pay_money(50);
        ad_user_app_conv_seq->set_event_time(95L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(500);
        ad_user_app_conv_seq->set_app_id(5000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_6");
        ad_user_app_conv_seq->set_request_id("rid_6");
        ad_user_app_conv_seq->set_pay_money(600);
        ad_user_app_conv_seq->set_event_time(95L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(600);
        ad_user_app_conv_seq->set_app_id(6000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("sid_7");
        ad_user_app_conv_seq->set_request_id("rid_7");
        ad_user_app_conv_seq->set_pay_money(70);
        ad_user_app_conv_seq->set_event_time(85L * 86400 * 1000);
        ad_user_app_conv_seq->set_adunit_id(700);
        ad_user_app_conv_seq->set_app_id(7000);

        phx::UserAction *user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action->SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(2, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({700}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({70}), ret.training_samples(0).features(1));
    }

    TEST_CASE("get_valid_value_1") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="test" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="get_valid_value"
                        source=".fe_request.req_time,.fe_request.ad_user_seq_download_offline.user_behavior_info.event_time"
                        config="1"
                        config_int64_value="0"
                        default_int64_value="-1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "test");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request->add_item_fea();
        auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({-1}), ret.training_samples(0).features(0));

        fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info()->set_event_time(100);

        fe_request_str = fe_request->SerializeAsString();

        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({100}), ret.training_samples(0).features(0));

        fe_request->set_req_time(200);

        fe_request_str = fe_request->SerializeAsString();

        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({200}), ret.training_samples(0).features(0));
    }

    TEST_CASE("get_valid_value_2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="test" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="get_valid_value"
                        source=".fe_request.req_time,.fe_request.ad_user_seq_download_offline.user_behavior_info.event_time"
                        config="2"
                        config_int64_value="1704038400000"
                        default_int64_value="-1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "test");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request->add_item_fea();
        fe_request->set_req_time(1704038500000);
        fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info()->set_event_time(1704038600000);
        auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);
        TEST_SLOT_FEATURE_INT64(10811, ({-1}), ret.training_samples(0).features(0));

        fe_request->set_req_time(1704038300000);
        fe_request_str = fe_request->SerializeAsString();

        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);
        TEST_SLOT_FEATURE_INT64(10811, ({1704038300000}), ret.training_samples(0).features(0));

        fe_request->set_req_time(1704038500000);
        fe_request->mutable_ad_user_seq_download_offline()->mutable_user_behavior_info(0)->set_event_time(
                1704038200000);
        fe_request_str = fe_request->SerializeAsString();
        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);
        TEST_SLOT_FEATURE_INT64(10811, ({1704038200000}), ret.training_samples(0).features(0));
    }

    TEST_CASE("get_valid_value_3") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="test" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="get_valid_value"
                        source=".fe_request.req_time,.fe_request.ad_user_seq_download_offline.user_behavior_info.event_time"
                        config="3"
                        config_int64_value="1704038400000"
                        default_int64_value="-1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "test");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request->add_item_fea();
        auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({-1}), ret.training_samples(0).features(0));

        fe_request->set_req_time(1704038300000);
        fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info()->set_event_time(1704038600000);

        fe_request_str = fe_request->SerializeAsString();

        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);
        TEST_SLOT_FEATURE_INT64(10811, ({1704038600000}), ret.training_samples(0).features(0));

        fe_request->set_req_time(1704038500000);
        fe_request_str = fe_request->SerializeAsString();

        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);
        TEST_SLOT_FEATURE_INT64(10811, ({1704038500000}), ret.training_samples(0).features(0));
    }

    // config传1，两个pb都传值，类型为float，取pb2
    TEST_CASE("test_get_valid_value_4") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="test" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="get_valid_value"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr_over_avg"
                        config="1"
                        config_float_value="0"
                        default_int64_value="-1"
                        precision="0.01"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "test");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request->add_item_fea();

        auto user_ads_stats_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(0.002);
        user_ads_stats_info->set_dtr_over_avg(0.1);

        auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_FLOAT(10811, ({0.1}), ret.training_samples(0).features(0));
    }

    TEST_CASE("get_valid_value_v2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="test" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="get_valid_value_v2"
                        source=".fe_request.req_time,.fe_request.ad_user_seq_download_offline.user_behavior_info.event_time"
                        invalid="0"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "test");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request->add_item_fea();
        auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(0, ret.training_samples(0).features(0).signs_size());

        fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info()->set_event_time(100);

        fe_request_str = fe_request->SerializeAsString();

        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({100}), ret.training_samples(0).features(0));

        fe_request->set_req_time(200);

        fe_request_str = fe_request->SerializeAsString();

        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({200}), ret.training_samples(0).features(0));
    }
}