#include "phx_test.h"
#include "phx-fe/src/framework.h"
#include "phx-fe/src/service.h"
#include "phx-fe/util/farmhash.h"
#include "phx-fe/util/math.h"
#include "phx-fe/util/murmur_hash3.h"
#include <chrono>
#include <cstdint>
#include <iostream>
#include <thread>
#include <string>

TEST_SUITE("plus") {
    TEST_CASE("test_query_dict_z1") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="app_info" value="10820,10821" />
        </versions>
        <config>
            <dict name="app_info"
                path="/home/zmw/phx-predictor/phx-fe/dict_test_data_online/appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
                class_name="AppinfoDict"
             />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="10810"
                    type="query_dict"
                    dict_name="app_info"
                    output_fields="package_name,third_class_id"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    default_int64_value="688"
                    default_float_value="-1.11f"
                    default_string_value="no_value" />
                <feature name = "10820"
                    slot="10820"
                    type="direct_to_feature"
                    source="10810:0"
                    />
                <feature name = "10821"
                    slot="10821"
                    type="direct_to_feature"
                    source="10810:1"
                    />
            </features>
        </config>
    )";
        auto ret = XmlConfigMgr::get_dict_configs_from_string(xml_content_string, "union_ctr");
        std::vector<hidict::DictConfig> hidict_configs{};
        for (const auto &conf: ret) {
            hidict::DictConfig hidict_config{};
            hidict_config.m_path = conf.path;
            hidict_config.m_name = conf.path;
            hidict_config.m_clazz = conf.class_name;
            hidict_configs.emplace_back(hidict_config);
        }
        AdDict::AdDictCollectorInstance::instance().init("zmw", hidict_configs, false);
        hidict_configs.clear();
        for (const auto &conf: ret) {
            hidict::DictConfig hidict_config{};
            hidict_config.m_path = conf.path;
            hidict_config.m_name = conf.name;
            hidict_config.m_clazz = conf.class_name;
            hidict_configs.emplace_back(hidict_config);
        }
        AdDict::AdDictCollector *dict_collector = new AdDict::AdDictCollector();
        long handle = reinterpret_cast<long>(dict_collector);
        if (!hidict_configs.empty()) {
            bool ret = dict_collector->init(std::to_string(handle), hidict_configs, false);
            if (!ret) {
                delete dict_collector;
                handle = 0;
            }
        }

        if (handle == 0) {
            std::cout << "init handle failed! handle = 0\n";
            return;
        }
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), handle, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto *fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::FeRequest &fe_request = *fe_ptr;
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(19980604);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(19980605);
        ad_user_app_info->set_count(20);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
        item_fea->mutable_item_info()->set_creative_id(1110);
        item_fea->mutable_item_info()->set_ocpx_sbp(2);
        item_fea->mutable_item_info()->set_data_source(7);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(8);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("236");
        item_fea->mutable_item_info()->set_creative_id(1112);
        item_fea->mutable_item_info()->set_ocpx_sbp(10);
        item_fea->mutable_item_info()->set_data_source(0);

        auto fe_str = fe_ptr->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto user_action_str = user_action.SerializeAsString();
        while (true) {
            auto batch_training_sample_str = to_training_sample_v2(
                    fe_str.c_str(), fe_str.size(), user_action_str.c_str(), user_action_str.size(), config_handle);
            phx::BatchTrainingSample training_sample;
            training_sample.ParseFromString(batch_training_sample_str);
            {
                for (const auto i: times(3)) {
                    CHECK_EQ(training_sample.training_samples(i).features(0).slot_id(), 10820);
                    TEST_FEATURE_STR(({"no_value", "no_value"}), training_sample.training_samples(i).features(0));
                }
            }
            {
                for (const auto i: times(3)) {
                    CHECK_EQ(training_sample.training_samples(i).features(1).slot_id(), 10821);
                    TEST_FEATURE_INT64(({688, 688}), training_sample.training_samples(i).features(1));
                }
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }
    }

    
}