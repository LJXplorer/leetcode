#include "test.h"

void test_gather_cross_by_grams_seg_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source=".user_feature.query_feature.query,.item_feature.item_id.app_id" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="1" start="0" size="5" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  pb_ufv2->mutable_query_feature()->set_query("他使用高德地图来导航。");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("高德地图");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 0, 3}), ({1, 4}), ({-1, 2, 2, 2}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_gather_cross_by_grams_seg_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source=".user_feature.query_feature.query,.item_feature.item_feature_se.feature_lists.feature_list.appid" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="2" start="0" size="15" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,3,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  pb_ufv2->mutable_query_feature()->set_query("高考的难度不算高，但却是筛选性测试，被学生们卷的分数很高");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("高德地图");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("高途高中规划");
  item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  feat_list2.add_feature()->mutable_bytes_list()->add_value("高铁管家");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map01 = batch_ret.batch(1).feature_lists().feature_list();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_LIST_INT64(({{-1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, 2}, 
                            {-1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1}}), itr00->second);
  TEST_FEATURE_LIST_INT64(({{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({-1, 2, -1, -1, 1, -1, -1, -1, -1, 0, 0, 0}), itr0->second);
  TEST_LIST_INT32(({2, 1}), itr_len0->second);

  FUNC_TEST_END();
}

void test_gather() {
  test_gather_cross_by_grams_seg_1();
  test_gather_cross_by_grams_seg_2();
}