#include "phx_test.h"
#include "phx-fe/src/service.h"
#include <fstream>
#include <iostream>

TEST_SUITE("seq") {

    TEST_CASE("test_seq_merge_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_merge" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.ad_user_seq_conv_sdk_conversion_realtime.ad_user_app_conv_seq" 
                    eventtime_key="event_time" />
                    <feature name="10812" slot="10812" type="direct" source="10811.request_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.pay_money" />
                </features>
            </config>
            )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        // auto *user_app_conv_seq1 = ads->add_ad_user_app_conv_seq();

        ads = fe_request.mutable_ad_user_seq_conv_sdk_conversion_realtime();

        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_pay_money(100);
        user_app_conv_seq->set_request_id("appid0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_pay_money(200);
        user_app_conv_seq->set_request_id("appid1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_pay_money(300);
        user_app_conv_seq->set_request_id("appid2");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_pay_money(400);
        user_app_conv_seq->set_request_id("appid3");

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({  "appid3","appid2", "appid1","appid0"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({ 360,240, 120,60, }), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({  400, 300,200,100}), ret.training_samples(0).features(2));

    }

    TEST_CASE("test_seq_merge_3") {
        //source1不为空，source2输入空，输出等于source1
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_merge" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.ad_user_seq_conv_sdk_conversion_realtime.ad_user_app_conv_seq" eventtime_key="event_time" />
                    <feature name="10812" slot="10812" type="direct" source="10811.request_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.pay_money" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_pay_money(100);
        user_app_conv_seq->set_request_id("appid0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_pay_money(200);
        user_app_conv_seq->set_request_id("appid1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_pay_money(300);
        user_app_conv_seq->set_request_id("appid2");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_pay_money(400);
        user_app_conv_seq->set_request_id("appid3");

        ads = fe_request.mutable_ad_user_seq_conv_sdk_conversion_realtime();
        user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({"appid3", "appid2", "appid1", "appid0"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({360, 240, 120, 60}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({400, 300, 200, 100}), ret.training_samples(0).features(2));
    }

    TEST_CASE("test_seq_merge_3") {
        //输入全是空，输出为空
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" type="seq_merge" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.ad_user_seq_conv_sdk_conversion_realtime.ad_user_app_conv_seq" eventtime_key="event_time" />
                    <feature name="10812" slot="10812" type="direct" source="10811.request_id" />
                    <feature name="10813" slot="10813" type="direct" source="10811.event_time" />
                    <feature name="10814" slot="10814" type="direct" source="10811.pay_money" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        ads->add_ad_user_app_conv_seq();

        auto *ads1 = fe_request.mutable_ad_user_seq_conv_sdk_conversion_realtime();
        ads1->add_ad_user_app_conv_seq();

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({""}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({0}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({0}), ret.training_samples(0).features(2));
    }

}