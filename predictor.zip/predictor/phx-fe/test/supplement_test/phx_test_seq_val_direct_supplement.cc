#include "phx_test.h"
#include "phx-fe/src/service.h"
#include <fstream>
#include <iostream>

TEST_SUITE("seq") {
    TEST_CASE("seq_val_direct") {
        //不配置day_n
        //结果：数据不被过滤
        MESSAGE("seq_val_direct START");

         std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.duration"
                     start="86400" 
                     clip_size="2" 
                     upper_bound="86400000"/>
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info->set_duration((int64_t) 1 * 3600 * 1000);



        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 105 * 86400 * 1000}),
                                ret.training_samples(0).features(1));
        // TEST_SLOT_FEATURE_INT64(10814, ({(int64_t) 2 * 3600 * 1000, (int64_t) 4 * 3600 * 1000}),
        //                         ret.training_samples(0).features(2));
    }

    TEST_CASE("seq_val_direct_1") {
        //clip_size
        //结果：数据不被截断
        MESSAGE("seq_val_direct START");

         std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.duration"
                     start="86400" 
                     upper_bound="86400000" 
                     day_n="-1"
                      />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info->set_duration((int64_t) 1 * 3600 * 1000);

        ::phx::AdUserAppInfo *pb_info1 = pb_use->add_user_app_info();

        pb_info1->set_app_id(10001);
        pb_info1->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info1->set_duration((int64_t) 1 * 3600 * 1000);

        ::phx::AdUserAppInfo *pb_info2 = pb_use->add_user_app_info();

        pb_info2->set_app_id(10002);
        pb_info2->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info2->set_duration((int64_t) 1 * 3600 * 1000);



        // item 不为空
        fe_request.add_item_fea();
        fe_request.add_item_fea();
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 3);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10000,10001,10002}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 105 * 86400 * 1000,(int64_t) 105 * 86400 * 1000,(int64_t) 105 * 86400 * 1000}),
                                ret.training_samples(0).features(1));

        
        // TEST_SLOT_FEATURE_INT64(10814, ({(int64_t) 2 * 3600 * 1000, (int64_t) 4 * 3600 * 1000}),
        //                         ret.training_samples(0).features(2));
    }

    TEST_CASE("seq_val_direct_2") {
        //value的值等于upper_bound设置的值,结果：数据不被过滤
        MESSAGE("seq_val_direct START");

         std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_val_direct" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.duration"
                     start="86400" 
                     upper_bound="86400000" 
                     day_n="-1"
                      />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info->set_duration((int64_t) 1 * 3600 * 1000);

        ::phx::AdUserAppInfo *pb_info1 = pb_use->add_user_app_info();

        pb_info1->set_app_id(10001);
        pb_info1->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info1->set_duration((int64_t) 1 * 3600 * 1000);

        ::phx::AdUserAppInfo *pb_info2 = pb_use->add_user_app_info();

        pb_info2->set_app_id(10002);
        pb_info2->set_event_time((int64_t) 105 * 86400 * 1000);
        pb_info2->set_duration(86400000);



        // item 不为空
        fe_request.add_item_fea();
        fe_request.add_item_fea();
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 3);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_INT64(10812, ({10000,10001,10002}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 105 * 86400 * 1000,(int64_t) 105 * 86400 * 1000,(int64_t) 105 * 86400 * 1000}),
                                ret.training_samples(0).features(1));

        
        // TEST_SLOT_FEATURE_INT64(10814, ({(int64_t) 2 * 3600 * 1000, (int64_t) 4 * 3600 * 1000}),
        //                         ret.training_samples(0).features(2));
    }
}