#include "phx_test.h"
#include "phx-fe/src/service.h"
#include <fstream>
#include <iostream>

TEST_SUITE("seq") {

    TEST_CASE("test_seq_by_inter_1") {
        //配置inter_key为抽取路径下没有的字段
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_by_inter" 
                    source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.item_fea.item_info.appid" 
                    inter_key="app_id1" 
                    fields="request_id,event_time,ad_group_id" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 4);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({"2"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({360}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({400}), ret.training_samples(0).features(2));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"1"}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({120}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({200}), ret.training_samples(1).features(2));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"0", "0"}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 240}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 300}), ret.training_samples(2).features(2));

        REQUIRE_EQ(ret.training_samples(3).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(3).features(2));
    }

    TEST_CASE("test_seq_by_inter_1") {
        //配置fields为空 结果：报错
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_by_inter" 
                    source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.item_fea.item_info.appid" 
                    inter_key="app_id" 
                    fields="" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 4);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({"2"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({360}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({400}), ret.training_samples(0).features(2));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"1"}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({120}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({200}), ret.training_samples(1).features(2));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"0", "0"}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 240}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 300}), ret.training_samples(2).features(2));

        REQUIRE_EQ(ret.training_samples(3).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(3).features(2));
    }

    TEST_CASE("test_seq_by_inter_1") {
        //配置fields为抽取路径下没有的字段 结果：报错
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_by_inter" 
                    source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.item_fea.item_info.appid" 
                    inter_key="app_id" 
                    fields="request_id1,event_time1,ad_group_id1" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 4);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({"2"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({360}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({400}), ret.training_samples(0).features(2));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"1"}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({120}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({200}), ret.training_samples(1).features(2));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"0", "0"}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 240}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 300}), ret.training_samples(2).features(2));

        REQUIRE_EQ(ret.training_samples(3).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(3).features(2));
    }

    TEST_CASE("test_seq_by_inter_1") {
        //查找条件在抽取路径下无对应的值
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_by_inter" 
                    source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.item_fea.item_info.appid" 
                    inter_key="app_id" 
                    fields="request_id,event_time,ad_group_id" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        //查找条件在抽取路径下无对应的值
        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10006);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 4);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(0).features(2));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"1"}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({120}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({200}), ret.training_samples(1).features(2));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"0", "0"}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 240}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 300}), ret.training_samples(2).features(2));

        REQUIRE_EQ(ret.training_samples(3).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(3).features(2));
    }

    TEST_CASE("test_seq_by_inter_1") {
        //抽取路径中配置float、double类型的值
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_by_inter" 
                    source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq,.fe_request.item_fea.item_info.appid" 
                    inter_key="app_id" 
                    fields="request_id,event_time,ad_group_id" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        //查找条件在抽取路径下无对应的值
        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10006);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 4);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(0).features(2));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"1"}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({120}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({200}), ret.training_samples(1).features(2));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"0", "0"}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 240}), ret.training_samples(2).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 300}), ret.training_samples(2).features(2));

        REQUIRE_EQ(ret.training_samples(3).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(3).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({}), ret.training_samples(3).features(2));
    }
}