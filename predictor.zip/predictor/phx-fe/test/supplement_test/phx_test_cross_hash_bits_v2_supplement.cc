#include "phx_test.h"
#include "phx-fe/src/service.h"
#include <fstream>
#include <iostream>

TEST_SUITE("seq") {
    TEST_CASE("cross_hash_bits_v2_1") {
        //clip_size不配置或者配置为-1,结果：输出结果不截断
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="cross_hash_bits_v2"
                        source=".fe_request.item_fea.item_info.rta_id,.fe_request.context.info_flow_context.info_flow_item.group_id,.fe_request.item_fea.item_info.bid"
                        clip_size="-1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // user
        auto *info_flow_item = fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->set_group_id("900778570");
        info_flow_item = fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->set_group_id("104436666");
        info_flow_item = fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->set_group_id("104436666111");

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("123");
        item_fea->mutable_item_info()->set_bid(123);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("456");
        item_fea->mutable_item_info()->set_bid(456);


        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        std::cout << "ret:" << ret.DebugString() << std::endl;

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({8840176746255942284L, 8840039651195226436L}),
                                ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({8840021783360860749L, 8840192412990929285L}),
                                ret.training_samples(1).features(0));
    }

    TEST_CASE("cross_hash_bits_v2_1") {
        //输入中某个数组为空
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="cross_hash_bits_v2"
                        source=".fe_request.item_fea.item_info.rta_id,.fe_request.context.info_flow_context.info_flow_item.group_id,.fe_request.item_fea.item_info.bid"
                        clip_size="-1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // user
        auto *info_flow_item = fe_request->mutable_context()->mutable_info_flow_context();
        // info_flow_item->set_group_id("900778570");
        // info_flow_item = fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        // info_flow_item->set_group_id("104436666");

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("123");
        item_fea->mutable_item_info()->set_bid(123);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("456");
        item_fea->mutable_item_info()->set_bid(456);



        std::cout << "fe_request:" << fe_request->DebugString() << std::endl;
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        std::cout << "ret:" << ret.DebugString() << std::endl;

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({}),
                                ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({}),
                                ret.training_samples(1).features(0));
    }
}