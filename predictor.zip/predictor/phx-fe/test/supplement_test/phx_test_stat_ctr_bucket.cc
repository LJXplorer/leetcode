#include "phx_test.h"
#include "phx-fe/src/service.h"
#include <fstream>
#include <iostream>

TEST_SUITE("seq") {
    //bucket_type=2，输入为空，不配置策略"not_empty"，输出为空
    TEST_CASE("stat_ctr_bucket int(size * score)") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="stat_ctr_bucket"
                        source=".user_action.user_action_item_info.click"
                        size="26.2"
                        bucket_type="2"
                        default_value="0"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        int click_0 = 380, click_1 = 549, click_2 = 1348, click_3 = 0;
        double size = 26.2;

        // auto user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_0);

        // user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_1);

        // user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_2);

        // user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_3);

        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        for (int i = 0; i < 4; ++i)
            fe_request->add_item_fea();
        auto fe_request_str = fe_request->SerializeAsString();

        auto user_action_str = user_action->SerializeAsString();

        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features().Get(0);
        REQUIRE_EQ(0, f1.signs().size());
        // CHECK_EQ(static_cast<int64_t>(size * click_0), f1.signs().Get(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f2 = ret.training_samples(1).features().Get(0);
        REQUIRE_EQ(0, f2.signs().size());
        // CHECK_EQ(static_cast<int64_t>(size * click_1), f2.signs().Get(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        const phx::Feature &f3 = ret.training_samples(2).features().Get(0);
        REQUIRE_EQ(0, f3.signs().size());
        // CHECK_EQ(static_cast<int64_t>(size * click_2), f3.signs().Get(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        const phx::Feature &f4 = ret.training_samples(3).features().Get(0);
        REQUIRE_EQ(0, f4.signs().size());
        // CHECK_EQ(static_cast<int64_t>(size * click_3), f4.signs().Get(0));
    }

    //bucket_type=4，输入为空，配置策略"not_empty"，不配置default_value，输出默认值-1
    TEST_CASE("stat_ctr_bucket int(size * score)") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="stat_ctr_bucket"
                        source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.event_time"
                        size="26.2"
                        bucket_type="4"
                        strategy="not_empty"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        
        int click_0 = 380, click_1 = 549, click_2 = 1348, click_3 = 0;
        double size = 26.2;

        // auto user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_0);

        // user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_1);

        // user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_2);

        // user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_3);

        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        auto *ads = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime();

        for (int i = 0; i < 4; ++i)
            fe_request->add_item_fea();
        auto fe_request_str = fe_request->SerializeAsString();

        auto user_action_str = user_action->SerializeAsString();

        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features().Get(0);
        REQUIRE_EQ(1, f1.weights_size());
        CHECK_EQ(-1, f1.weights().Get(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f2 = ret.training_samples(1).features().Get(0);
        REQUIRE_EQ(1, f2.weights_size());
        CHECK_EQ(-1, f2.weights().Get(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        const phx::Feature &f3 = ret.training_samples(2).features().Get(0);
        REQUIRE_EQ(1, f3.weights_size());
        CHECK_EQ(-1, f3.weights().Get(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        const phx::Feature &f4 = ret.training_samples(3).features().Get(0);
        REQUIRE_EQ(1, f4.weights_size());
        CHECK_EQ(-1, f4.weights().Get(0));
    }

    //bucket_type=4，输出为log(a + b *score)，以2为底
    TEST_CASE("stat_ctr_bucket int(size * score)") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="stat_ctr_bucket"
                        source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.event_time"
                        size="26.2"
                        bucket_type="4"
                        strategy="not_empty"
                        a="4"
                        b="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        
        int click_0 = 380, click_1 = 549, click_2 = 1348, click_3 = 0;
        double size = 26.2;

        // auto user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_0);

        // user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_1);

        // user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_2);

        // user_action_item_info = user_action->add_user_action_item_info();
        // user_action_item_info->set_click(click_3);

        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        auto *ads = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_event_time(2);

        for (int i = 0; i < 4; ++i)
            fe_request->add_item_fea();
        auto fe_request_str = fe_request->SerializeAsString();

        auto user_action_str = user_action->SerializeAsString();

        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features().Get(0);
        REQUIRE_EQ(1, f1.weights_size());
        CHECK_EQ(std::log2(8), f1.weights().Get(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f2 = ret.training_samples(1).features().Get(0);
        REQUIRE_EQ(1, f2.weights_size());
        CHECK_EQ(std::log2(8), f2.weights().Get(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        const phx::Feature &f3 = ret.training_samples(2).features().Get(0);
        REQUIRE_EQ(1, f3.weights_size());
        CHECK_EQ(std::log2(8), f3.weights().Get(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        const phx::Feature &f4 = ret.training_samples(3).features().Get(0);
        REQUIRE_EQ(1, f4.weights_size());
        CHECK_EQ(std::log2(8), f4.weights().Get(0));
    }
}