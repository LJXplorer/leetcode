#include "phx_test.h"
#include "phx-fe/src/service.h"
#include <fstream>
#include <iostream>

// seq类算子
TEST_SUITE("seq") {
    TEST_CASE("seq_hit_count_v1_event_time1") {
        //传入1条数据，其中传入event_time，不传入req_time，结果为0；
        MESSAGE("seq_hit_count_v1 supplement start.... "); 
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        // fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10001);
        // ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10001);
        // ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10001);
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10002);
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(0).features(1));

        // CHECK_EQ(ret.training_samples(1).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(1).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(1).features(1));

        // CHECK_EQ(ret.training_samples(2).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({3}), ret.training_samples(2).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(2).features(1));

        // CHECK_EQ(ret.training_samples(3).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(3).features(0));
        // TE
        // 
        // ST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(3).features(1));
    }


    TEST_CASE("seq_hit_count_v1_event_time1") {
        //传入1条数据，其中不传入event_time，传入req_time，结果为1
        MESSAGE("seq_hit_count_v1 supplement start.... "); 
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        // ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10001);
        // ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10001);
        // ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10001);
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10002);
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({1}), ret.training_samples(0).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(0).features(1));

        // CHECK_EQ(ret.training_samples(1).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(1).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(1).features(1));

        // CHECK_EQ(ret.training_samples(2).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({3}), ret.training_samples(2).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(2).features(1));

        // CHECK_EQ(ret.training_samples(3).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(3).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(3).features(1));
    }

    TEST_CASE("seq_hit_count_v1_event_time1") {
        //传入1条数据，其中不传入user_app_info.app_id，结果为0
        MESSAGE("seq_hit_count_v1 supplement start.... "); 
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10001);
        // ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10001);
        // ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10001);
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10002);
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(0).features(1));

        // CHECK_EQ(ret.training_samples(1).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(1).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(1).features(1));

        // CHECK_EQ(ret.training_samples(2).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({3}), ret.training_samples(2).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(2).features(1));

        // CHECK_EQ(ret.training_samples(3).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(3).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(3).features(1));
    }

    TEST_CASE("seq_hit_count_v1_event_time1") {
        //传入1条数据，不传入item_info.appid，结果为0
        MESSAGE("seq_hit_count_v1 supplement start.... "); 
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10001);
        // ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10001);
        // ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        // ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        // ad_user_app_info->set_app_id(10002);
        // ad_user_app_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10001);
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10002);
        // item_fea = fe_request->add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(0).features(1));

        // CHECK_EQ(ret.training_samples(1).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(1).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(1).features(1));

        // CHECK_EQ(ret.training_samples(2).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({3}), ret.training_samples(2).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(2).features(1));

        // CHECK_EQ(ret.training_samples(3).features_size(), 2);
        // TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(3).features(0));
        // TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(3).features(1));
    }

    TEST_CASE("seq_hit_count_v1_event_time3") {
        //event_time等于边界值110 * 86400 * 1000（设置start="864000"），结果为0
        MESSAGE("seq_hit_count_v1 supplement start.... "); 
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 110 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越


        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                    user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
    }

    TEST_CASE("seq_hit_count_v1_event_time4") {
        //第一种输入且设置max_num，即传入event_time，req_time同时设置max_num，过滤结果等于max_num，结果为max_num
        MESSAGE("seq_hit_count_v1 supplement start.... "); 
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="86400"
                        max_num="2"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 10 * 86400 * 1000);

        // appid eventtime
         ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 1 * 86400 * 1000);
        ::phx::AdUserAppInfo *ad_user_app_info1 =
            fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info1->set_app_id(10000);
        ad_user_app_info1->set_event_time((int64_t) 1 * 86400 * 1000);


        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越


        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                    user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(0).features(0));
    }

    TEST_CASE("seq_hit_count_v1_event_time4") {
        //第一种输入且设置max_num，即传入event_time，req_time同时设置max_num=2，过滤结果大于2，结果为2
        MESSAGE("seq_hit_count_v1 supplement start.... "); 
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="86400"
                        max_num="2"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 10 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 1 * 86400 * 1000);
        ::phx::AdUserAppInfo *ad_user_app_info1 =
            fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info1->set_app_id(10000);
        ad_user_app_info1->set_event_time((int64_t) 1 * 86400 * 1000);

        ::phx::AdUserAppInfo *ad_user_app_info2 =
            fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info2->set_app_id(10000);
        ad_user_app_info2->set_event_time((int64_t) 1 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越


        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                    user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(0).features(0));
    }

     TEST_CASE("seq_hit_count_v1_event_time5") {
        //max_num设置为0，结果为0
        MESSAGE("seq_hit_count_v1 supplement start.... "); 
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="86400"
                        max_num="0"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 10 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 1 * 86400 * 1000);
        ::phx::AdUserAppInfo *ad_user_app_info1 =
            fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info1->set_app_id(10000);
        ad_user_app_info1->set_event_time((int64_t) 1 * 86400 * 1000);

        ::phx::AdUserAppInfo *ad_user_app_info2 =
            fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info2->set_app_id(10000);
        ad_user_app_info2->set_event_time((int64_t) 1 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越


        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                    user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
    }

    TEST_CASE("seq_hit_count_v1_event_time5") {
        //max_num设置为负数，方法报错
        MESSAGE("seq_hit_count_v1 supplement start.... "); 
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="86400"
                        max_num="-1"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 10 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 1 * 86400 * 1000);
        ::phx::AdUserAppInfo *ad_user_app_info1 =
            fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info1->set_app_id(10000);
        ad_user_app_info1->set_event_time((int64_t) 1 * 86400 * 1000);

        ::phx::AdUserAppInfo *ad_user_app_info2 =
            fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info2->set_app_id(10000);
        ad_user_app_info2->set_event_time((int64_t) 1 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越


        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                    user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
    }

    TEST_CASE("seq_hit_count_v1_event_time6") {
        //userappinfo.appid中传入item_info.appid中不存在的值，结果为0
        MESSAGE("seq_hit_count_v1 supplement start.... "); 
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="86400"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v1"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 10 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 1 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越


        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                    user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
    }
}