#include "phx_test.h"
#include "phx-fe/src/service.h"
#include <fstream>
#include <iostream>

TEST_SUITE("seq") {
    TEST_CASE("seq_n_hour_1") {
        //输入的source1中的appid存在重复的appid，最后的输出不会过滤重复的appid
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_n_hour" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time" 
                    start="864000" 
                    day_n="30" 
                    hour="2" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);//start过滤

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000 + 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000 + 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000 - 3600 * 2000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 82 * 86400 * 1000 - 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10006);
        pb_info->set_event_time((int64_t) 89 * 86400 * 1000 - 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10007);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);//day_n过滤

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10813, ({10001,10001, 10002, 10004, 10006}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(
                10814,
                ({(int64_t) 84 * 86400 * 1000,(int64_t) 84 * 86400 * 1000, (int64_t) 92 * 86400 * 1000 + 3600 * 1000,
                  (int64_t) 99 * 86400 * 1000 - 3600 * 2000, (int64_t) 89 * 86400 * 1000 - 3600 * 1000}),
                ret.training_samples(0).features(1));
    }


     TEST_CASE("seq_n_hour_1") {
        //start和day_n未设置使用默认值
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_n_hour" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time" 
                    hour="2" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);//start过滤

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000 + 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000 + 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000 - 3600 * 2000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 82 * 86400 * 1000 - 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10006);
        pb_info->set_event_time((int64_t) 89 * 86400 * 1000 - 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10007);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);//day_n过滤

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10813, ({10000,10001,10001, 10002, 10004, 10006,10007}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(
                10814,
                ({(int64_t) 105 * 86400 * 1000, (int64_t) 84 * 86400 * 1000,(int64_t) 84 * 86400 * 1000, (int64_t) 92 * 86400 * 1000 + 3600 * 1000,
                  (int64_t) 99 * 86400 * 1000 - 3600 * 2000, (int64_t) 89 * 86400 * 1000 - 3600 * 1000,(int64_t) 78 * 86400 * 1000}),
                ret.training_samples(0).features(1));
    }

    TEST_CASE("seq_n_hour_1") {
        //hour未手动配置或配置负数会报错
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_n_hour" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time" 
                    start="864000" 
                    day_n="30" 
                     />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);//start过滤

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000 + 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000 + 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000 - 3600 * 2000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 82 * 86400 * 1000 - 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10006);
        pb_info->set_event_time((int64_t) 89 * 86400 * 1000 - 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10007);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);//day_n过滤

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10813, ({10001,10001, 10002, 10004, 10006}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(
                10814,
                ({(int64_t) 84 * 86400 * 1000,(int64_t) 84 * 86400 * 1000, (int64_t) 92 * 86400 * 1000 + 3600 * 1000,
                  (int64_t) 99 * 86400 * 1000 - 3600 * 2000, (int64_t) 89 * 86400 * 1000 - 3600 * 1000}),
                ret.training_samples(0).features(1));
    }

    TEST_CASE("seq_n_hour_1") {
        //hour未手动配置或配置负数会报错
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_n_hour" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time" 
                    start="864000" 
                    day_n="30" 
                    hour = "-1"
                     />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);//start过滤

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000 + 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000 + 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000 - 3600 * 2000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 82 * 86400 * 1000 - 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10006);
        pb_info->set_event_time((int64_t) 89 * 86400 * 1000 - 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10007);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);//day_n过滤

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10813, ({10001,10001, 10002, 10004, 10006}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(
                10814,
                ({(int64_t) 84 * 86400 * 1000,(int64_t) 84 * 86400 * 1000, (int64_t) 92 * 86400 * 1000 + 3600 * 1000,
                  (int64_t) 99 * 86400 * 1000 - 3600 * 2000, (int64_t) 89 * 86400 * 1000 - 3600 * 1000}),
                ret.training_samples(0).features(1));
    }

    TEST_CASE("seq_n_hour_1") {
        //hour配置大于24的数字，所有的输出都不会被过滤，全部输出
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_n_hour" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.event_time" 
                    start="864000" 
                    day_n="30" 
                    hour="25" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 105 * 86400 * 1000);//start过滤


        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10001);
        pb_info->set_event_time((int64_t) 84 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10002);
        pb_info->set_event_time((int64_t) 92 * 86400 * 1000 + 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10003);
        pb_info->set_event_time((int64_t) 95 * 86400 * 1000 + 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10004);
        pb_info->set_event_time((int64_t) 99 * 86400 * 1000 - 3600 * 2000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10005);
        pb_info->set_event_time((int64_t) 82 * 86400 * 1000 - 3600 * 3000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10006);
        pb_info->set_event_time((int64_t) 89 * 86400 * 1000 - 3600 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(10007);
        pb_info->set_event_time((int64_t) 78 * 86400 * 1000);//day_n过滤

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);

        TEST_SLOT_FEATURE_INT64(10813, ({10001, 10002, 10003,10004, 10005,10006}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(
                10814,
                ({(int64_t) 84 * 86400 * 1000, (int64_t) 92 * 86400 * 1000 + 3600 * 1000,
                  (int64_t) 95 * 86400 * 1000 + 3600 * 3000,(int64_t) 99 * 86400 * 1000 - 3600 * 2000, (int64_t) 82 * 86400 * 1000 - 3600 * 3000,(int64_t) 89 * 86400 * 1000 - 3600 * 1000}),
                ret.training_samples(0).features(1));
    }

}