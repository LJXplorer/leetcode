#include "phx_test.h"
#include "phx-fe/src/service.h"
#include <fstream>
#include <iostream>

TEST_SUITE("seq") {
    TEST_CASE("fully_cross") {
        //user和user特征拼接，connect未手动配置默认为”_”(单个下划线)
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="fully_cross"
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.rta_id"
                        default_value="NONE"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        pb_item_fea->mutable_item_info()->set_rta_id("abc");

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        pb_item_fea->mutable_item_info()->set_rta_id("def");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(2, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f0_0 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f0_0.bytes_list_size());
        CHECK_EQ("1000_abc", f0_0.bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f1_0 = ret.training_samples(1).features(0);
        REQUIRE_EQ(1, f1_0.bytes_list_size());
        CHECK_EQ("1001_def", f1_0.bytes_list(0));
    }

    TEST_CASE("fully_cross") {
        //source1包含两个值，空字符串和特殊字符；source2包含1个值，是特殊字符；最后的结果应该是两个值，两个值都是空字符串和特殊字符的拼接，connect手动配置为不可见字符
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="fully_cross"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id,.fe_request.item_fea.item_info.rta_id"
                        connector=""
                        default_value="NONE"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="fully_cross"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id,.fe_request.item_fea.item_info.rta_id"
                        connector=""
                        default_value="NONE"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id(".");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id(" ");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("/");


        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f0_0 = ret.training_samples(0).features(0);
        CHECK_EQ(" .", f0_0.bytes_list(0));
        
        CHECK_EQ("/.", f0_0.bytes_list(1));
        // const phx::Feature &f1_0 = ret.training_samples(0).features(1);
        // CHECK_EQ("", f1_0.bytes_list(0));
    }

    TEST_CASE("fully_cross") {
        //拼接的输入为空，配置default_value="null"，不配置not_empty策略，结果使用默认值输出
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="fully_cross"
                        source=".fe_request.context.info_flow_context.info_flow_item.group_id,.fe_request.item_fea.item_info.rta_id"
                        default_value="null"
                        strategy="not_empty"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        auto *pb_item_fea = fe_request->mutable_context()->mutable_info_flow_context();
        // pb_item_fea->mutable_item_info()->set_appid(1000);
        // pb_item_fea->mutable_item_info()->set_rta_id("abc");

        // pb_item_fea = fe_request->add_item_fea();
        // pb_item_fea->mutable_item_info()->set_appid(1001);
        // pb_item_fea->mutable_item_info()->set_rta_id("def");


        phx::ItemFeature *pb_item_fea1 = fe_request->add_item_fea();
   

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f0_0 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f0_0.bytes_list_size());
        CHECK_EQ("null", f0_0.bytes_list(0));

        // REQUIRE_EQ(1, ret.training_samples(1).features_size());
        // const phx::Feature &f1_0 = ret.training_samples(1).features(0);
        // REQUIRE_EQ(1, f1_0.bytes_list_size());
        // CHECK_EQ("1001_def", f1_0.bytes_list(0));
    }
}
