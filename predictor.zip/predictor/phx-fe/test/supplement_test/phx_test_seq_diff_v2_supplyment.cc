#include "phx_test.h"
#include "phx-fe/src/service.h"
#include <fstream>
#include <iostream>

TEST_SUITE("seq") {
    TEST_CASE("seq_diff_v2_2") {
        //设置day_n=-1/不配置day_n
        //结果：数据不被过滤
        MESSAGE("seq_diff_v2_2 START");
            std::string config_str = R"(
                <versions>
                <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
                </versions>
                <config>
                    <features>
                        <feature name="10811" slot="10811" type="seq_diff_v2" 
                            source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" 
                            day_n="-1" 
                            delta_day="-10" 
                            status="0" 
                            clip_size="3" />
                        <feature name="10812" slot="10812" type="direct" source="10811:0" />
                        <feature name="10813" slot="10813" type="direct" source="10811:1" />
                        <feature name="10814" slot="10811" type="seq_diff_v2" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="1" clip_size="3" />
                        <feature name="10815" slot="10815" type="direct" source="10814:0" />
                        <feature name="10816" slot="10816" type="direct" source="10814:1" />
                    </features>
                </config>
            )";

            google::protobuf::Arena arena;
            phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
            fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

            ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
            ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();
            //防穿越
            pb_info->set_app_id(10000);
            pb_info->set_event_time((int64_t) 80* 86400 * 1000);
            // pb_info = pb_use->add_user_app_info();
            // pb_info->set_app_id(10001);
            // pb_info->set_event_time((int64_t) 86 * 86400 * 1000);
            // pb_info = pb_use->add_user_app_info();

            auto *item_fea = fe_request.add_item_fea();
            item_fea->mutable_item_info()->set_appid(10000);
            item_fea->mutable_item_info()->set_bid((int64_t) 80 * 86400 * 1000);
            // item_fea->mutable_item_info()->set_creative_id(10001);
            // item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 85 * 86400 * 1000);

            // item_fea = fe_request.add_item_fea();
            // item_fea->mutable_item_info()->set_appid(10002);
            // item_fea->mutable_item_info()->set_bid((int64_t) 85 * 86400 * 1000);
            // item_fea->mutable_item_info()->set_creative_id(10002);
            // item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 90 * 86400 * 1000);

            auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
            auto config_handle = reinterpret_cast<long>(ptr);
            auto fe_request_str = fe_request.SerializeAsString();
            phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
            auto user_action_str = user_action.SerializeAsString();
            auto batch_training_sample_str =
                    to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);
            phx::BatchTrainingSample ret{};
            ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

            REQUIRE_EQ(ret.training_samples_size(), 1);
            REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

            TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(0).features(0));
            TEST_SLOT_FEATURE_INT64(10813, ({6912000000}), ret.training_samples(0).features(1));
            // TEST_SLOT_FEATURE_INT64(10815, ({10001}), ret.training_samples(0).features(2));
            // TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 90 * 86400 * 1000}), ret.training_samples(0).features(3));

            // REQUIRE_EQ(ret.training_samples(1).features_size(), 4);
            // TEST_SLOT_FEATURE_INT64(10812, ({10002}), ret.training_samples(1).features(0));
            // TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 85 * 86400 * 1000}), ret.training_samples(1).features(1));
            // TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(1).features(2));
            // TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(1).features(3));
        }

    TEST_CASE("seq_diff_v2_2") {
    //有效日期边界值 设置day_n="30" 传入请求时间（输入五）为110 * 86400 * 1000
    //ad_user_app_seq_use_offline.event_time = 80* 86400 * 1000
    MESSAGE("seq_diff_v2_2 START");
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_v2" 
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" 
                        day_n="30" 
                        delta_day="-10" 
                        status="0" 
                        clip_size="3" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10811" type="seq_diff_v2" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="1" clip_size="3" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
        )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();
        //防穿越
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 80* 86400 * 1000);
        // pb_info = pb_use->add_user_app_info();
        // pb_info->set_app_id(10001);
        // pb_info->set_event_time((int64_t) 86 * 86400 * 1000);
        // pb_info = pb_use->add_user_app_info();

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_bid((int64_t) 80 * 86400 * 1000);
        // item_fea->mutable_item_info()->set_creative_id(10001);
        // item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 85 * 86400 * 1000);

        // item_fea = fe_request.add_item_fea();
        // item_fea->mutable_item_info()->set_appid(10002);
        // item_fea->mutable_item_info()->set_bid((int64_t) 85 * 86400 * 1000);
        // item_fea->mutable_item_info()->set_creative_id(10002);
        // item_fea->mutable_item_info()->set_ocpx_sbp((int64_t) 90 * 86400 * 1000);

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                    user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));
        // TEST_SLOT_FEATURE_INT64(10815, ({10001}), ret.training_samples(0).features(2));
        // TEST_SLOT_FEATURE_INT64(10816, ({(int64_t) 90 * 86400 * 1000}), ret.training_samples(0).features(3));

        // REQUIRE_EQ(ret.training_samples(1).features_size(), 4);
        // TEST_SLOT_FEATURE_INT64(10812, ({10002}), ret.training_samples(1).features(0));
        // TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 85 * 86400 * 1000}), ret.training_samples(1).features(1));
        // TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(1).features(2));
        // TEST_SLOT_FEATURE_INT64(10816, ({}), ret.training_samples(1).features(3));
    }

    TEST_CASE("seq_diff_v2_2") {
        //不配置day_n
        MESSAGE("seq_diff_v2_2 START");
            std::string config_str = R"(
                <versions>
                <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
                </versions>
                <config>
                    <features>
                        <feature name="10811" slot="10811" type="seq_diff_v2" 
                            source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" 

                            delta_day="-10" 
                            status="0" 
                            clip_size="3" />
                        <feature name="10812" slot="10812" type="direct" source="10811:0" />
                        <feature name="10813" slot="10813" type="direct" source="10811:1" />
                        <feature name="10814" slot="10811" type="seq_diff_v2" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="1" clip_size="3" />
                        <feature name="10815" slot="10815" type="direct" source="10814:0" />
                        <feature name="10816" slot="10816" type="direct" source="10814:1" />
                    </features>
                </config>
            )";

            google::protobuf::Arena arena;
            phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
            fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

            ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
            ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();
            //防穿越
            pb_info->set_app_id(10000);
            pb_info->set_event_time((int64_t) 80* 86400 * 1000);


            auto *item_fea = fe_request.add_item_fea();
            item_fea->mutable_item_info()->set_appid(10000);
            item_fea->mutable_item_info()->set_bid((int64_t) 80 * 86400 * 1000);
 

            auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
            auto config_handle = reinterpret_cast<long>(ptr);
            auto fe_request_str = fe_request.SerializeAsString();
            phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
            auto user_action_str = user_action.SerializeAsString();
            auto batch_training_sample_str =
                    to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);
            phx::BatchTrainingSample ret{};
            ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

            REQUIRE_EQ(ret.training_samples_size(), 1);
            REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

            TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(0).features(0));
            TEST_SLOT_FEATURE_INT64(10813, ({6912000000}), ret.training_samples(0).features(1));

        }
    TEST_CASE("seq_diff_v2_2") {
        //clip_size=-1/
        MESSAGE("seq_diff_v2_2 START");
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_v2" 
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" 

                        delta_day="-10" 
                        status="0" 
                        clip_size="-1" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10811" type="seq_diff_v2" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="1" clip_size="3" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
        )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();
        //防穿越
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 80* 86400 * 1000);


        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_bid((int64_t) 80 * 86400 * 1000);


        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                    user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({6912000000}), ret.training_samples(0).features(1));

    }

    TEST_CASE("seq_diff_v2_2") {
        //不配置clip_size
        MESSAGE("seq_diff_v2_2 START");
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_v2" 
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" 

                        delta_day="-10" 
                        status="0" 
                    />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10811" type="seq_diff_v2" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="1" clip_size="3" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
        )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();
        //防穿越
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 80* 86400 * 1000);


        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_bid((int64_t) 80 * 86400 * 1000);


        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                    user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({6912000000}), ret.training_samples(0).features(1));

    }

    TEST_CASE("seq_diff_v2_2") {
        //delta_day=0
        MESSAGE("seq_diff_v2_2 START");
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_v2" 
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000"  
                        status="0" 
                        clip_size="2" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10811" type="seq_diff_v2" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="1" clip_size="3" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
        )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();
        //防穿越
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 80* 86400 * 1000);


        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_bid((int64_t) 80 * 86400 * 1000);


        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                    user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({6912000000}), ret.training_samples(0).features(1));

    }

    TEST_CASE("seq_diff_v2_2") {
        //不配置delta_day
        MESSAGE("seq_diff_v2_2 START");
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_v2" 
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" 

                        delta_day="0" 
                        status="0" 
                        clip_size="2"
                    />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10811" type="seq_diff_v2" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="1" clip_size="3" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
        )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();
        //防穿越
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 80* 86400 * 1000);


        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_bid((int64_t) 80 * 86400 * 1000);


        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                    user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({6912000000}), ret.training_samples(0).features(1));

    }

    TEST_CASE("seq_diff_v2_2") {
        //配置了not_empty = true，过滤结果为空时，不会对空结果进行填充
        MESSAGE("seq_diff_v2_2 START");
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10815,10816" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_diff_v2" 
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" 

                        day_n="-1" 
                        delta_day="1" 
                        status="0" 
                        clip_size="3"
                        strategy="empty"
                    />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10811" type="seq_diff_v2" source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.bid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.ocpx_sbp,.fe_request.event_time" start="864000" day_n="30" delta_day="-10" status="1" clip_size="3" />
                    <feature name="10815" slot="10815" type="direct" source="10814:0" />
                    <feature name="10816" slot="10816" type="direct" source="10814:1" />
                </features>
            </config>
        )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 110 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();
        //防穿越
        pb_info->set_app_id(10000);
        pb_info->set_event_time((int64_t) 80* 86400 * 1000);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_bid((int64_t) 80 * 86400 * 1000);


        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                    user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 4);

        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));

    }
}