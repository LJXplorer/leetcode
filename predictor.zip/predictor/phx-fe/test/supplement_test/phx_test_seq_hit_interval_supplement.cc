#include "phx_test.h"
#include "phx-fe/src/service.h"
#include <fstream>
#include <iostream>

TEST_SUITE("seq") {
    TEST_CASE("seq_hit_interval_1") {
        //event_time等于边界值110 * 86400 * 1000（设置start="864000"），输出-1
        MESSAGE("seq_hit_count_v2 supplement start.... ");
         std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 110 * 86400 * 1000);
    

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({-1}), ret.training_samples(0).features(0));

        // CHECK_EQ(ret.training_samples(1).features_size(), 1);
        // TEST_SLOT_FEATURE_INT64(31406, ({20 * 86400}), ret.training_samples(1).features(0));

        // CHECK_EQ(ret.training_samples(2).features_size(), 1);
        // TEST_SLOT_FEATURE_INT64(31406, ({50 * 86400}), ret.training_samples(2).features(0));
    }

    TEST_CASE("seq_hit_interval_2") {
        //不传入event_time，输出req_time设置的值
        MESSAGE("seq_hit_count_v2 supplement start.... ");
         std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        // ad_user_app_info->set_event_time((int64_t) 110 * 86400 * 1000);
    

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({110 * 86400}), ret.training_samples(0).features(0));

        // CHECK_EQ(ret.training_samples(1).features_size(), 1);
        // TEST_SLOT_FEATURE_INT64(31406, ({20 * 86400}), ret.training_samples(1).features(0));

        // CHECK_EQ(ret.training_samples(2).features_size(), 1);
        // TEST_SLOT_FEATURE_INT64(31406, ({50 * 86400}), ret.training_samples(2).features(0));
    }

    TEST_CASE("seq_hit_interval_2") {
        //userappinfo.appid中传入item_info.appid中不存在的值，输出-1
        MESSAGE("seq_hit_count_v2 supplement start.... ");
         std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_interval"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        // ad_user_app_info->set_event_time((int64_t) 110 * 86400 * 1000);
    

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({-1}), ret.training_samples(0).features(0));

        // CHECK_EQ(ret.training_samples(1).features_size(), 1);
        // TEST_SLOT_FEATURE_INT64(31406, ({20 * 86400}), ret.training_samples(1).features(0));

        // CHECK_EQ(ret.training_samples(2).features_size(), 1);
        // TEST_SLOT_FEATURE_INT64(31406, ({50 * 86400}), ret.training_samples(2).features(0));
    }
}