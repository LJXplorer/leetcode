#include "test.h"


void test_vocab_set_z2() {
  // 传值空，输出空
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="vocab_set" source="E@.item_feature.item_feature_se.context.feature.app_id" strategy="empty,string" dict="test/data/query_appname.txt" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  VocabSetConfig* config = dynamic_cast<VocabSetConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_FEATURE_STR(({}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                         itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_vocab_set_z1() {
  // 传值NO_EXIST返回空字符串
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="vocab_set" source=".item_feature.item_feature_se.context.feature.app_id" dict="test/data/query_appname.txt" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  VocabSetConfig* config = dynamic_cast<VocabSetConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("NOT_EXIST");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_FEATURE_STR(({""}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({1, 1}), ({""}),
                         itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_utf8_coincide_z1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_coincide",
          "source": [
              ".item_feature.item_feature_se.context.feature.query",
              ".item_feature.item_feature_se.context.feature.appname"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  // 将上面创建的config字符串和vec容器解析为json，然后填充默认值到config中
  JsonConfigMgr::parse_from_string(config_str, vec);
  // 检查config输入个数，一个f就是一个config，vec中存放指向config类的指针
  TEST_ASSERT_EQUAL(1, vec.size());
  // 指针转换
  Utf8CoincideConfig* config = dynamic_cast<Utf8CoincideConfig*>(vec[0].get());
  // 检查指针转换是否成功
  TEST_ASSERT_BOOL(nullptr != config);
  // 初始化输入的字符串
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入类型是否为sparse
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);
  // 创建一个ferequest
  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  // add_item_feature返回一个指针，需要先解引用
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  // 给request添加item和入参
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("音火山");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("dadfasf地64364536串火热抖那我跟325");
  (*(item->mutable_context()->mutable_feature()))["appname"].mutable_bytes_list()->add_value("抖音");
  (*(item->mutable_context()->mutable_feature()))["appname"].mutable_bytes_list()->add_value("");

  toSequenceExample(&arena, request, vec, batch_ret);
  // 检查是否只有两个item
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  // 检查item里面是否有内容
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  
  const auto& map0 = batch_ret.batch(0).context().feature();

  auto itr00 = map0.find("f13");
  // 检查是否查询到f13，没查询到会将结尾返回给指针
  TEST_ASSERT_BOOL(itr00 != map0.end());
  // 取键值对的值，做比较
  TEST_FEATURE_STR(({"音", ""}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1}), ({1, 2}), ({"音", ""}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_utf8_coincide_z2() {
  // query传值，appname不传值，输出空
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_coincide",
          "source": [
              ".item_feature.item_feature_se.context.feature.query",
              "E@.item_feature.item_feature_se.context.feature.appname"
          ],
          "strategy": ["empty"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  // 将上面创建的config字符串和vec容器解析为json，然后填充默认值到config中
  JsonConfigMgr::parse_from_string(config_str, vec);
  // 检查config输入个数，一个f就是一个config，vec中存放指向config类的指针
  TEST_ASSERT_EQUAL(1, vec.size());
  // 指针转换
  Utf8CoincideConfig* config = dynamic_cast<Utf8CoincideConfig*>(vec[0].get());
  // 检查指针转换是否成功
  TEST_ASSERT_BOOL(nullptr != config);
  // 初始化输入的字符串
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入类型是否为sparse
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);
  // 创建一个ferequest
  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  // add_item_feature返回一个指针，需要先解引用
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  // 给request添加item和入参
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("音火山");
  (*(item->mutable_context()->mutable_feature()))["appname"];

  toSequenceExample(&arena, request, vec, batch_ret);
  // 检查是否只有两个item
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  // 检查item里面是否有内容
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  
  const auto& map0 = batch_ret.batch(0).context().feature();

  auto itr00 = map0.find("f13");
  // 检查是否查询到f13，没查询到会将结尾返回给指针
  TEST_ASSERT_BOOL(itr00 != map0.end());
  // 取键值对的值，做比较
  TEST_FEATURE_STR(({}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_utf8_coincide_z3() {
  // query不传值，appname传值，输出空
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_coincide",
          "source": [
              "E@.item_feature.item_feature_se.context.feature.query",
              ".item_feature.item_feature_se.context.feature.appname"
          ],
          "strategy": ["empty"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  // 将上面创建的config字符串和vec容器解析为json，然后填充默认值到config中
  JsonConfigMgr::parse_from_string(config_str, vec);
  // 检查config输入个数，一个f就是一个config，vec中存放指向config类的指针
  TEST_ASSERT_EQUAL(1, vec.size());
  // 指针转换
  Utf8CoincideConfig* config = dynamic_cast<Utf8CoincideConfig*>(vec[0].get());
  // 检查指针转换是否成功
  TEST_ASSERT_BOOL(nullptr != config);
  // 初始化输入的字符串
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入类型是否为sparse
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);
  // 创建一个ferequest
  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  // add_item_feature返回一个指针，需要先解引用
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  // 给request添加item和入参
  (*(item->mutable_context()->mutable_feature()))["query"];
  (*(item->mutable_context()->mutable_feature()))["appname"].mutable_bytes_list()->add_value("音火山");

  toSequenceExample(&arena, request, vec, batch_ret);
  // 检查是否只有两个item
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  // 检查item里面是否有内容
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  
  const auto& map0 = batch_ret.batch(0).context().feature();

  auto itr00 = map0.find("f13");
  // 检查是否查询到f13，没查询到会将结尾返回给指针
  TEST_ASSERT_BOOL(itr00 != map0.end());
  // 取键值对的值，做比较
  TEST_FEATURE_STR(({}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_utf8_coincide_z4() {
  // query不传值，appname传值，输出空
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_coincide",
          "source": [
              "E@.item_feature.item_feature_se.context.feature.query",
              "E@.item_feature.item_feature_se.context.feature.appname"
          ],
          "strategy": ["empty"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  // 将上面创建的config字符串和vec容器解析为json，然后填充默认值到config中
  JsonConfigMgr::parse_from_string(config_str, vec);
  // 检查config输入个数，一个f就是一个config，vec中存放指向config类的指针
  TEST_ASSERT_EQUAL(1, vec.size());
  // 指针转换
  Utf8CoincideConfig* config = dynamic_cast<Utf8CoincideConfig*>(vec[0].get());
  // 检查指针转换是否成功
  TEST_ASSERT_BOOL(nullptr != config);
  // 初始化输入的字符串
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入类型是否为sparse
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);
  // 创建一个ferequest
  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  // add_item_feature返回一个指针，需要先解引用
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  // 给request添加item和入参
  (*(item->mutable_context()->mutable_feature()))["query"];
  (*(item->mutable_context()->mutable_feature()))["appname"];

  toSequenceExample(&arena, request, vec, batch_ret);
  // 检查是否只有两个item
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  // 检查item里面是否有内容
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  
  const auto& map0 = batch_ret.batch(0).context().feature();

  auto itr00 = map0.find("f13");
  // 检查是否查询到f13，没查询到会将结尾返回给指针
  TEST_ASSERT_BOOL(itr00 != map0.end());
  // 取键值对的值，做比较
  TEST_FEATURE_STR(({}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_segment_z1() {
  /* 
  segment算子用于分词，用作测试cross_by_grams_seg算子之前，先检查分词结果
   */
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="segment" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,3,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SegmentConfig* conf = dynamic_cast<SegmentConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  // BatchSequenceExample的下面是SequenceExample
  // SequenceExample的内容分为Features context = 1;FeatureLists feature_lists = 2;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  // ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  // TEST_ASSERT_EQUAL(1, in_vec.size());
  // TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("他使用高德地图来导航。");
  pb_use->add_user_sequence()->set_app_id("我来自北京邮电大学。");
  pb_use->add_user_sequence()->set_app_id("我来自北京邮电大学。。。学号123456，用AK47");

  //item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  // 拿到feature_list对象，是一个字典，key为字符串，值为FeatureList对象
  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  // 拿到指定的FeatureList对象，下面是feature
  auto itr00 = map0.find("f15");

  TEST_ASSERT_BOOL(itr00 != map0.end());

  auto& list = itr00->second;
  // 打印出每个feature中的bytes_list，feature_size拿到feature的数量
  for(int32_t i = 0; i < list.feature_size(); i++) {
      // bytes_list是一个列表，还需要拿到value的长度
      for(int32_t j = 0; j < list.feature(i).bytes_list().value_size(); j++) {
        std::cout << list.feature(i).bytes_list().value(j) << std::endl;
      }
  }

  FUNC_TEST_END();
}

void test_cross_by_grams_seg_z1() {
  FUNC_TEST_START();
  // 定义config字符串
  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source=".user_feature.query_feature.query,.item_feature.item_id.app_id" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="1" start="0" size="5" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";
  // 定义输入字符串，type=sparse
  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  // 将config字符串解析为xml对象，并填充特征
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);
  // 检查是否只构建了一个对象
  TEST_ASSERT_EQUAL(1, vec.size());
  // 类型强制转换为SeqFeatureConfig对象
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  // 将input字符串解析为xml对象
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入config的类型
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  pb_ufv2->mutable_query_feature()->set_query("他");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("高德地图");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  // TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);
  TEST_FEATURE_INT64(({-1}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({-1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_cross_by_grams_seg_z2() {
  FUNC_TEST_START();
  // 定义config字符串
  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source=".user_feature.query_feature.query,.item_feature.item_id.app_id" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="1" start="0" size="5" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";
  // 定义输入字符串，type=sparse
  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  // 将config字符串解析为xml对象，并填充特征
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);
  // 检查是否只构建了一个对象
  TEST_ASSERT_EQUAL(1, vec.size());
  // 类型强制转换为SeqFeatureConfig对象
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  // 将input字符串解析为xml对象
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入config的类型
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  pb_ufv2->mutable_query_feature()->set_query("");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("高德地图");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  // TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);
  TEST_FEATURE_INT64(({-1}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({-1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_cross_by_grams_seg_z3() {
  FUNC_TEST_START();
  // 定义config字符串
  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source=".user_feature.query_feature.query,.item_feature.item_id.app_id" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="0" start="0" size="5" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";
  // 定义输入字符串，type=sparse
  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  // 将config字符串解析为xml对象，并填充特征
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);
  // 检查是否只构建了一个对象
  TEST_ASSERT_EQUAL(1, vec.size());
  // 类型强制转换为SeqFeatureConfig对象
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  // 将input字符串解析为xml对象
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入config的类型
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  pb_ufv2->mutable_query_feature()->set_query("");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("高德地图");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  // TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);
  TEST_FEATURE_INT64(({-1}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({-1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_cross_by_grams_seg_z4() {
  FUNC_TEST_START();
  // 定义config字符串
  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source=".user_feature.query_feature.query,.item_feature.item_id.app_id" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="1" start="0" size="100" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";
  // 定义输入字符串，type=sparse
  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  // 将config字符串解析为xml对象，并填充特征
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);
  // 检查是否只构建了一个对象
  TEST_ASSERT_EQUAL(1, vec.size());
  // 类型强制转换为SeqFeatureConfig对象
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  // 将input字符串解析为xml对象
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入config的类型
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  pb_ufv2->mutable_query_feature()->set_query("他使用高德地图来导航。");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("高德地图");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  // TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);
  TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 0, 3}), ({1, 4}), ({-1, 2, 2, 2}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_cross_by_grams_seg_z5() {
  FUNC_TEST_START();
  // 定义config字符串
  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source=".user_feature.query_feature.query,.item_feature.item_id.app_id" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="1" start="1" size="2" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";
  // 定义输入字符串，type=sparse
  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  // 将config字符串解析为xml对象，并填充特征
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);
  // 检查是否只构建了一个对象
  TEST_ASSERT_EQUAL(1, vec.size());
  // 类型强制转换为SeqFeatureConfig对象
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  // 将input字符串解析为xml对象
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入config的类型
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  pb_ufv2->mutable_query_feature()->set_query("他使用高德地图来导航。");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("高德地图");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  // TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);
  TEST_FEATURE_INT64(({2, 2}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1}), ({1, 2}), ({2, 2}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_cross_by_grams_seg_z6() {
  FUNC_TEST_START();
  // 定义config字符串
  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source=".user_feature.query_feature.query,.item_feature.item_id.app_id" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="1" start="1" size="100" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";
  // 定义输入字符串，type=sparse
  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  // 将config字符串解析为xml对象，并填充特征
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);
  // 检查是否只构建了一个对象
  TEST_ASSERT_EQUAL(1, vec.size());
  // 类型强制转换为SeqFeatureConfig对象
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  // 将input字符串解析为xml对象
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入config的类型
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  pb_ufv2->mutable_query_feature()->set_query("他使用高德地图来导航。");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("高德地图");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  // TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);
  TEST_FEATURE_INT64(({2, 2, 2}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2}), ({1, 3}), ({2, 2, 2}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_cross_by_grams_seg_z7() {
  FUNC_TEST_START();
  // 定义config字符串
  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source=".user_feature.query_feature.query,.item_feature.item_id.app_id" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="1" start="100" size="1" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";
  // 定义输入字符串，type=sparse
  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  // 将config字符串解析为xml对象，并填充特征
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);
  // 检查是否只构建了一个对象
  TEST_ASSERT_EQUAL(1, vec.size());
  // 类型强制转换为SeqFeatureConfig对象
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  // 将input字符串解析为xml对象
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入config的类型
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  pb_ufv2->mutable_query_feature()->set_query("他使用高德地图来导航。");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("高德地图");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  // TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);
  TEST_FEATURE_INT64(({-1}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({-1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_cross_by_grams_seg_z8() {
  // query传空，appname不传空，输出-1
  FUNC_TEST_START();
  // 定义config字符串
  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source="E@.user_feature.user_feature_se.context.feature.query,.item_feature.item_feature_se.context.feature.app_id" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="1" start="0" size="5" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";
  // 定义输入字符串，type=sparse
  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  // 将config字符串解析为xml对象，并填充特征
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);
  // 检查是否只构建了一个对象
  TEST_ASSERT_EQUAL(1, vec.size());
  // 类型强制转换为SeqFeatureConfig对象
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  // 将input字符串解析为xml对象
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入config的类型
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  // qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["query"];
  // pb_ufv2->mutable_query_feature()->set_query("他使用高德地图来导航。");

  // item
  // request.add_item_feature()->mutable_item_id()->set_app_id("高德地图");
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("高德地图");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  // TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);
  TEST_FEATURE_INT64(({-1}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({-1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_cross_by_grams_seg_z9() {
  // query不传空，appname传空，输出-1
  FUNC_TEST_START();
  // 定义config字符串
  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source=".user_feature.user_feature_se.context.feature.query,E@.item_feature.item_feature_se.context.feature.app_id" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="1" start="0" size="5" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";
  // 定义输入字符串，type=sparse
  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  // 将config字符串解析为xml对象，并填充特征
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);
  // 检查是否只构建了一个对象
  TEST_ASSERT_EQUAL(1, vec.size());
  // 类型强制转换为SeqFeatureConfig对象
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  // 将input字符串解析为xml对象
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入config的类型
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  // qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("高德地图");
  // pb_ufv2->mutable_query_feature()->set_query("他使用高德地图来导航。");

  // item
  // request.add_item_feature()->mutable_item_id()->set_app_id("高德地图");
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  // TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);
  TEST_FEATURE_INT64(({-1}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({-1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_cross_by_grams_seg_z10() {
  // query传空，appname传空，输出-1
  FUNC_TEST_START();
  // 定义config字符串
  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="cross_by_grams_seg" source="E@.user_feature.user_feature_se.context.feature.query,E@.item_feature.item_feature_se.context.feature.app_id" 
            jieba_dict_path="third_party/cppjieba-5.0.3/dict/jieba.dict.utf8" hmm_model_path="third_party/cppjieba-5.0.3/dict/hmm_model.utf8" user_dict_path="third_party/cppjieba-5.0.3/dict/user.dict.utf8" 
            length="1" start="0" size="5" dtype="int64" dict="test/data/query_appname_value.txt" />
        </features>
    </config>
  )";
  // 定义输入字符串，type=sparse
  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  // 将config字符串解析为xml对象，并填充特征
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);
  // 检查是否只构建了一个对象
  TEST_ASSERT_EQUAL(1, vec.size());
  // 类型强制转换为SeqFeatureConfig对象
  CrossByGramsSegConfig* config = dynamic_cast<CrossByGramsSegConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  // 将input字符串解析为xml对象
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入config的类型
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  // qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["query"];
  // pb_ufv2->mutable_query_feature()->set_query("他使用高德地图来导航。");

  // item
  // request.add_item_feature()->mutable_item_id()->set_app_id("高德地图");
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  // TEST_FEATURE_INT64(({-1, 2, 2, 2}), itr00->second);
  TEST_FEATURE_INT64(({-1}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({-1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

// user特征传空字符串，输出空
void test_seq_by_inter_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_by_inter" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq,.item_feature.game_item_offline_feature.game_item_atrribute_feature.app_name" inter_key="query" fields="event_type,event_time,pay_money" />
            <feature name="f7" type="direct" source="f6:0" strategy="empty,string" />
            <feature name="f8" type="direct" source="f6:1" strategy="empty,int64" />
            <feature name="f9" type="direct" source="f6:2" strategy="empty,int64" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,2,3" type="sequence" />
        <input name="f8" shape="1,2,3" type="sequence" />
        <input name="f9" shape="1,2,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqByInterConfig* conf = dynamic_cast<SeqByInterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("");
  pb_info->set_event_type("0");
  pb_info->set_event_time(60);
  pb_info->set_pay_money(100);
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("");
  // pb_info->set_event_time(0);
  // pb_info->set_pay_money(200);

  // item
  qinglong::GameItemAttributeFeature* item = request.add_item_feature()->mutable_game_item_offline_feature()->mutable_game_item_atrribute_feature();
  item->add_app_name("appid2");
  item->add_app_name("appid1");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{}, {""}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{}, {0}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{}, {0}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"", "", "", ""}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({0, 0, 0, 0}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({0, 0, 0, 0}), itr2->second);
  TEST_LIST_INT32(({2}), itr_len2->second);

  FUNC_TEST_END();
}

// topn=0取全部数据
void test_seq_topn_direct_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_topn_direct" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq" 
            filter_key="pay_money" fields="query,event_time" topn="0" reserve="1" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopnDirectConfig* conf = dynamic_cast<SeqTopnDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_pay_money(200);
  pb_info->set_event_time(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(300);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid3"}, {"appid2"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{100}, {300}, {200}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid1", "appid3", "appid2"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({100, 300, 200}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}
// reserve=0从大到小排序
void test_seq_topn_direct_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_topn_direct" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq" 
            filter_key="pay_money" fields="query,event_time" topn="100" reserve="0" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopnDirectConfig* conf = dynamic_cast<SeqTopnDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_pay_money(200);
  pb_info->set_event_time(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(300);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}, {"appid1"}, {"appid3"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{200}, {100}, {300}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid2", "appid1", "appid3"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({200, 100, 300}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}
// topn=100取全部数据
void test_seq_topn_direct_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_topn_direct" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq" 
            filter_key="pay_money" fields="query,event_time" topn="100" reserve="1" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopnDirectConfig* conf = dynamic_cast<SeqTopnDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_pay_money(200);
  pb_info->set_event_time(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(300);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid3"}, {"appid2"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{100}, {300}, {200}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid1", "appid3", "appid2"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({100, 300, 200}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

// reserve未配置取默认值0
void test_seq_topn_direct_z4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_topn_direct" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq" 
            filter_key="pay_money" fields="query,event_time" topn="100" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopnDirectConfig* conf = dynamic_cast<SeqTopnDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_pay_money(200);
  pb_info->set_event_time(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(300);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}, {"appid1"}, {"appid3"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{200}, {100}, {300}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid2", "appid1", "appid3"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({200, 100, 300}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

// 取topn存在相同值全部输出
void test_seq_topn_direct_z5() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_topn_direct" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq" 
            filter_key="pay_money" fields="query,event_time" topn="2" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopnDirectConfig* conf = dynamic_cast<SeqTopnDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_pay_money(200);
  pb_info->set_event_time(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(300);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}, {"appid1"}, {"appid3"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{200}, {100}, {300}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid2", "appid1", "appid3"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({200, 100, 300}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

// filter_key配置的特征未传值，会使用默认值参与排序
void test_seq_topn_direct_z6() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_topn_direct" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq" 
            filter_key="pay_money" fields="query,event_time" topn="3" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopnDirectConfig* conf = dynamic_cast<SeqTopnDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  // pb_info->set_pay_money(200);
  pb_info->set_event_time(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(300);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid3"}, {"appid2"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{100}, {300}, {200}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid1", "appid3", "appid2"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({100, 300, 200}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}
// fields中的特征值存在空字符串和默认值
void test_seq_topn_direct_z7() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_topn_direct" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq" 
            filter_key="pay_money" fields="query,event_time" topn="3" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopnDirectConfig* conf = dynamic_cast<SeqTopnDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_pay_money(200);
  pb_info->set_event_time(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_pay_money(100);
  // pb_info->set_event_time(300);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}, {""}, {"appid3"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{200}, {100}, {0}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid2", "", "appid3"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({200, 100, 0}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

// connector如果未设置默认为'\002'不可见字符
void test_dict_to_attributes_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" dict_type="app_id" default_value="test_no_data" />
            <feature name="f11" type="direct" source="f10:0" />
            <feature name="f12" type="direct" source="f10:1" />
            <feature name="f13" type="direct" source="f10:2" />
            <feature name="f14" type="direct" source="f10:3" />
            <feature name="f15" type="direct" source="f10:4" />
            <feature name="f16" type="direct" source="f10:5" />
            <feature name="f17" type="direct" source="f10:6" />
            <feature name="f18" type="direct" source="f10:7" />
            <feature name="f19" type="direct" source="f10:8" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini</app_info>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f11" shape="1,1,5" type="sequence" />
        <input name="f12" shape="1,1,5" type="sequence" />
        <input name="f13" shape="1,1,5" type="sequence" />
        <input name="f14" shape="1,1,5" type="sequence" />
        <input name="f15" shape="1,1,5" type="sequence" />
        <input name="f16" shape="1,1,5" type="sequence" />
        <input name="f17" shape="1,1,5" type="sequence" />
        <input name="f18" shape="1,1,5" type="sequence" />
        <input name="f19" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(10, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesConfig* conf = dynamic_cast<DictToAttributesConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("925850548");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"925850548"}}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"com.tencent.tmgp.mhmnz"}}), itr02->second);

  auto itr03 = map00.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_STR(({{"梦幻模拟战"}}), itr03->second);

  auto itr04 = map00.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_LIST_STR(({{"游戏"}}), itr04->second);

  auto itr05 = map00.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_LIST_STR(({{"经营策略"}}), itr05->second);

  auto itr06 = map00.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_FEATURE_LIST_STR(({{"卡牌"}}), itr06->second);

  auto itr07 = map00.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_FEATURE_LIST_STR(({{"策略紫龙回合制奇幻日系二次元模拟"}}), itr07->second);

  auto itr08 = map00.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_FEATURE_LIST_STR(({{"默认值"}}), itr08->second);

  auto itr09 = map00.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_FEATURE_LIST_STR(({{"默认值"}}), itr09->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr1 = map.find("f11");
  auto itr_len1 = map.find("f11_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"925850548"}), itr1->second);
  TEST_LIST_INT32(({1}), itr_len1->second);

  auto itr2 = map.find("f12");
  auto itr_len2 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"com.tencent.tmgp.mhmnz"}), itr2->second);
  TEST_LIST_INT32(({1}), itr_len2->second);

  auto itr3 = map.find("f13");
  auto itr_len3 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_STRING(({"梦幻模拟战"}), itr3->second);
  TEST_LIST_INT32(({1}), itr_len3->second);

  auto itr4 = map.find("f14");
  auto itr_len4 = map.find("f14_length");
  TEST_ASSERT_BOOL(itr4 != map.end());
  TEST_ASSERT_BOOL(itr_len4 != map.end());
  TEST_LIST_STRING(({"游戏"}), itr4->second);
  TEST_LIST_INT32(({1}), itr_len4->second);

  auto itr5 = map.find("f15");
  auto itr_len5 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr5 != map.end());
  TEST_ASSERT_BOOL(itr_len5 != map.end());
  TEST_LIST_STRING(({"经营策略"}), itr5->second);
  TEST_LIST_INT32(({1}), itr_len5->second);

  auto itr6 = map.find("f16");
  auto itr_len6 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr6 != map.end());
  TEST_ASSERT_BOOL(itr_len6 != map.end());
  TEST_LIST_STRING(({"卡牌"}), itr6->second);
  TEST_LIST_INT32(({1}), itr_len6->second);

  auto itr7 = map.find("f17");
  auto itr_len7 = map.find("f17_length");
  TEST_ASSERT_BOOL(itr7 != map.end());
  TEST_ASSERT_BOOL(itr_len7 != map.end());
  TEST_LIST_STRING(({"策略紫龙回合制奇幻日系二次元模拟"}), itr7->second);
  TEST_LIST_INT32(({1}), itr_len7->second);

  auto itr8 = map.find("f18");
  auto itr_len8 = map.find("f18_length");
  TEST_ASSERT_BOOL(itr8 != map.end());
  TEST_ASSERT_BOOL(itr_len8 != map.end());
  TEST_LIST_STRING(({"默认值"}), itr8->second);
  TEST_LIST_INT32(({1}), itr_len8->second);

  auto itr9 = map.find("f19");
  auto itr_len9 = map.find("f19_length");
  TEST_ASSERT_BOOL(itr9 != map.end());
  TEST_ASSERT_BOOL(itr_len9 != map.end());
  TEST_LIST_STRING(({"默认值"}), itr9->second);
  TEST_LIST_INT32(({1}), itr_len9->second);

  FUNC_TEST_END();
}
// connector设置为'\031'
void test_dict_to_attributes_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" dict_type="app_id" connector="\031" default_value="test_no_data" />
            <feature name="f11" type="direct" source="f10:0" />
            <feature name="f12" type="direct" source="f10:1" />
            <feature name="f13" type="direct" source="f10:2" />
            <feature name="f14" type="direct" source="f10:3" />
            <feature name="f15" type="direct" source="f10:4" />
            <feature name="f16" type="direct" source="f10:5" />
            <feature name="f17" type="direct" source="f10:6" />
            <feature name="f18" type="direct" source="f10:7" />
            <feature name="f19" type="direct" source="f10:8" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini</app_info>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f11" shape="1,1,5" type="sequence" />
        <input name="f12" shape="1,1,5" type="sequence" />
        <input name="f13" shape="1,1,5" type="sequence" />
        <input name="f14" shape="1,1,5" type="sequence" />
        <input name="f15" shape="1,1,5" type="sequence" />
        <input name="f16" shape="1,1,5" type="sequence" />
        <input name="f17" shape="1,1,5" type="sequence" />
        <input name="f18" shape="1,1,5" type="sequence" />
        <input name="f19" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(10, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesConfig* conf = dynamic_cast<DictToAttributesConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("925850548");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"925850548"}}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"com.tencent.tmgp.mhmnz"}}), itr02->second);

  auto itr03 = map00.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_STR(({{"梦幻模拟战"}}), itr03->second);

  auto itr04 = map00.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_LIST_STR(({{"游戏"}}), itr04->second);

  auto itr05 = map00.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_LIST_STR(({{"经营策略"}}), itr05->second);

  auto itr06 = map00.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_FEATURE_LIST_STR(({{"卡牌"}}), itr06->second);

  auto itr07 = map00.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  
  const char c = 31;
  std::string invisible_char = std::string(1,c);
  std::string str11;
  str11.append("策略").append(invisible_char).append("紫龙").append(invisible_char).append("回合制").append(invisible_char).append("奇幻").append(invisible_char)
  .append("日系").append(invisible_char).append("二次元").append(invisible_char).append("模拟");

  TEST_FEATURE_LIST_STR(({{str11}}), itr07->second);

  auto itr08 = map00.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_FEATURE_LIST_STR(({{"默认值"}}), itr08->second);

  auto itr09 = map00.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_FEATURE_LIST_STR(({{"默认值"}}), itr09->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr1 = map.find("f11");
  auto itr_len1 = map.find("f11_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"925850548"}), itr1->second);
  TEST_LIST_INT32(({1}), itr_len1->second);

  auto itr2 = map.find("f12");
  auto itr_len2 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"com.tencent.tmgp.mhmnz"}), itr2->second);
  TEST_LIST_INT32(({1}), itr_len2->second);

  auto itr3 = map.find("f13");
  auto itr_len3 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_STRING(({"梦幻模拟战"}), itr3->second);
  TEST_LIST_INT32(({1}), itr_len3->second);

  auto itr4 = map.find("f14");
  auto itr_len4 = map.find("f14_length");
  TEST_ASSERT_BOOL(itr4 != map.end());
  TEST_ASSERT_BOOL(itr_len4 != map.end());
  TEST_LIST_STRING(({"游戏"}), itr4->second);
  TEST_LIST_INT32(({1}), itr_len4->second);

  auto itr5 = map.find("f15");
  auto itr_len5 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr5 != map.end());
  TEST_ASSERT_BOOL(itr_len5 != map.end());
  TEST_LIST_STRING(({"经营策略"}), itr5->second);
  TEST_LIST_INT32(({1}), itr_len5->second);

  auto itr6 = map.find("f16");
  auto itr_len6 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr6 != map.end());
  TEST_ASSERT_BOOL(itr_len6 != map.end());
  TEST_LIST_STRING(({"卡牌"}), itr6->second);
  TEST_LIST_INT32(({1}), itr_len6->second);

  auto itr7 = map.find("f17");
  auto itr_len7 = map.find("f17_length");
  TEST_ASSERT_BOOL(itr7 != map.end());
  TEST_ASSERT_BOOL(itr_len7 != map.end());
  TEST_LIST_STRING(({str11}), itr7->second);
  TEST_LIST_INT32(({1}), itr_len7->second);

  auto itr8 = map.find("f18");
  auto itr_len8 = map.find("f18_length");
  TEST_ASSERT_BOOL(itr8 != map.end());
  TEST_ASSERT_BOOL(itr_len8 != map.end());
  TEST_LIST_STRING(({"默认值"}), itr8->second);
  TEST_LIST_INT32(({1}), itr_len8->second);

  auto itr9 = map.find("f19");
  auto itr_len9 = map.find("f19_length");
  TEST_ASSERT_BOOL(itr9 != map.end());
  TEST_ASSERT_BOOL(itr_len9 != map.end());
  TEST_LIST_STRING(({"默认值"}), itr9->second);
  TEST_LIST_INT32(({1}), itr_len9->second);

  FUNC_TEST_END();
}
// 查询不到对应的信息时，返回配置的默认值test_no_data
void test_dict_to_attributes_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" dict_type="app_id" connector="\002" default_value="test_no_data" />
            <feature name="f11" type="direct" source="f10:0" />
            <feature name="f12" type="direct" source="f10:1" />
            <feature name="f13" type="direct" source="f10:2" />
            <feature name="f14" type="direct" source="f10:3" />
            <feature name="f15" type="direct" source="f10:4" />
            <feature name="f16" type="direct" source="f10:5" />
            <feature name="f17" type="direct" source="f10:6" />
            <feature name="f18" type="direct" source="f10:7" />
            <feature name="f19" type="direct" source="f10:8" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini</app_info>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f11" shape="1,1,5" type="sequence" />
        <input name="f12" shape="1,1,5" type="sequence" />
        <input name="f13" shape="1,1,5" type="sequence" />
        <input name="f14" shape="1,1,5" type="sequence" />
        <input name="f15" shape="1,1,5" type="sequence" />
        <input name="f16" shape="1,1,5" type="sequence" />
        <input name="f17" shape="1,1,5" type="sequence" />
        <input name="f18" shape="1,1,5" type="sequence" />
        <input name="f19" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(10, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesConfig* conf = dynamic_cast<DictToAttributesConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("666");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}}), itr02->second);

  auto itr03 = map00.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}}), itr03->second);

  auto itr04 = map00.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}}), itr04->second);

  auto itr05 = map00.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}}), itr05->second);

  auto itr06 = map00.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}}), itr06->second);

  auto itr07 = map00.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}}), itr07->second);

  auto itr08 = map00.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}}), itr08->second);

  auto itr09 = map00.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_FEATURE_LIST_STR(({{"test_no_data"}}), itr09->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr1 = map.find("f11");
  auto itr_len1 = map.find("f11_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"test_no_data"}), itr1->second);
  TEST_LIST_INT32(({1}), itr_len1->second);

  auto itr2 = map.find("f12");
  auto itr_len2 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"test_no_data"}), itr2->second);
  TEST_LIST_INT32(({1}), itr_len2->second);

  auto itr3 = map.find("f13");
  auto itr_len3 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_STRING(({"test_no_data"}), itr3->second);
  TEST_LIST_INT32(({1}), itr_len3->second);

  auto itr4 = map.find("f14");
  auto itr_len4 = map.find("f14_length");
  TEST_ASSERT_BOOL(itr4 != map.end());
  TEST_ASSERT_BOOL(itr_len4 != map.end());
  TEST_LIST_STRING(({"test_no_data"}), itr4->second);
  TEST_LIST_INT32(({1}), itr_len4->second);

  auto itr5 = map.find("f15");
  auto itr_len5 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr5 != map.end());
  TEST_ASSERT_BOOL(itr_len5 != map.end());
  TEST_LIST_STRING(({"test_no_data"}), itr5->second);
  TEST_LIST_INT32(({1}), itr_len5->second);

  auto itr6 = map.find("f16");
  auto itr_len6 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr6 != map.end());
  TEST_ASSERT_BOOL(itr_len6 != map.end());
  TEST_LIST_STRING(({"test_no_data"}), itr6->second);
  TEST_LIST_INT32(({1}), itr_len6->second);

  auto itr7 = map.find("f17");
  auto itr_len7 = map.find("f17_length");
  TEST_ASSERT_BOOL(itr7 != map.end());
  TEST_ASSERT_BOOL(itr_len7 != map.end());
  TEST_LIST_STRING(({"test_no_data"}), itr7->second);
  TEST_LIST_INT32(({1}), itr_len7->second);

  auto itr8 = map.find("f18");
  auto itr_len8 = map.find("f18_length");
  TEST_ASSERT_BOOL(itr8 != map.end());
  TEST_ASSERT_BOOL(itr_len8 != map.end());
  TEST_LIST_STRING(({"test_no_data"}), itr8->second);
  TEST_LIST_INT32(({1}), itr_len8->second);

  auto itr9 = map.find("f19");
  auto itr_len9 = map.find("f19_length");
  TEST_ASSERT_BOOL(itr9 != map.end());
  TEST_ASSERT_BOOL(itr_len9 != map.end());
  TEST_LIST_STRING(({"test_no_data"}), itr9->second);
  TEST_LIST_INT32(({1}), itr_len9->second);

  FUNC_TEST_END();
}
// 查询不到对应的信息时，并且没有配置默认值，返回空
void test_dict_to_attributes_z4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" dict_type="app_id" connector="\002" />
            <feature name="f11" type="direct" source="f10:0" strategy="empty,string" />
            <feature name="f12" type="direct" source="f10:1" strategy="empty,string" />
            <feature name="f13" type="direct" source="f10:2" strategy="empty,string" />
            <feature name="f14" type="direct" source="f10:3" strategy="empty,string" />
            <feature name="f15" type="direct" source="f10:4" strategy="empty,string" />
            <feature name="f16" type="direct" source="f10:5" strategy="empty,string" />
            <feature name="f17" type="direct" source="f10:6" strategy="empty,string" />
            <feature name="f18" type="direct" source="f10:7" strategy="empty,string" />
            <feature name="f19" type="direct" source="f10:8" strategy="empty,string" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini</app_info>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f11" shape="1,1,5" type="sequence" />
        <input name="f12" shape="1,1,5" type="sequence" />
        <input name="f13" shape="1,1,5" type="sequence" />
        <input name="f14" shape="1,1,5" type="sequence" />
        <input name="f15" shape="1,1,5" type="sequence" />
        <input name="f16" shape="1,1,5" type="sequence" />
        <input name="f17" shape="1,1,5" type="sequence" />
        <input name="f18" shape="1,1,5" type="sequence" />
        <input name="f19" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(10, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesConfig* conf = dynamic_cast<DictToAttributesConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("666");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{}}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{}}), itr02->second);

  auto itr03 = map00.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_STR(({{}}), itr03->second);

  auto itr04 = map00.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_LIST_STR(({{}}), itr04->second);

  auto itr05 = map00.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_LIST_STR(({{}}), itr05->second);

  auto itr06 = map00.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_FEATURE_LIST_STR(({{}}), itr06->second);

  auto itr07 = map00.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_FEATURE_LIST_STR(({{}}), itr07->second);

  auto itr08 = map00.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_FEATURE_LIST_STR(({{}}), itr08->second);

  auto itr09 = map00.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_FEATURE_LIST_STR(({{}}), itr09->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr1 = map.find("f11");
  auto itr_len1 = map.find("f11_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({""}), itr1->second);
  TEST_LIST_INT32(({1}), itr_len1->second);

  auto itr2 = map.find("f12");
  auto itr_len2 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({""}), itr2->second);
  TEST_LIST_INT32(({1}), itr_len2->second);

  auto itr3 = map.find("f13");
  auto itr_len3 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_STRING(({""}), itr3->second);
  TEST_LIST_INT32(({1}), itr_len3->second);

  auto itr4 = map.find("f14");
  auto itr_len4 = map.find("f14_length");
  TEST_ASSERT_BOOL(itr4 != map.end());
  TEST_ASSERT_BOOL(itr_len4 != map.end());
  TEST_LIST_STRING(({""}), itr4->second);
  TEST_LIST_INT32(({1}), itr_len4->second);

  auto itr5 = map.find("f15");
  auto itr_len5 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr5 != map.end());
  TEST_ASSERT_BOOL(itr_len5 != map.end());
  TEST_LIST_STRING(({""}), itr5->second);
  TEST_LIST_INT32(({1}), itr_len5->second);

  auto itr6 = map.find("f16");
  auto itr_len6 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr6 != map.end());
  TEST_ASSERT_BOOL(itr_len6 != map.end());
  TEST_LIST_STRING(({""}), itr6->second);
  TEST_LIST_INT32(({1}), itr_len6->second);

  auto itr7 = map.find("f17");
  auto itr_len7 = map.find("f17_length");
  TEST_ASSERT_BOOL(itr7 != map.end());
  TEST_ASSERT_BOOL(itr_len7 != map.end());
  TEST_LIST_STRING(({""}), itr7->second);
  TEST_LIST_INT32(({1}), itr_len7->second);

  auto itr8 = map.find("f18");
  auto itr_len8 = map.find("f18_length");
  TEST_ASSERT_BOOL(itr8 != map.end());
  TEST_ASSERT_BOOL(itr_len8 != map.end());
  TEST_LIST_STRING(({""}), itr8->second);
  TEST_LIST_INT32(({1}), itr_len8->second);

  auto itr9 = map.find("f19");
  auto itr_len9 = map.find("f19_length");
  TEST_ASSERT_BOOL(itr9 != map.end());
  TEST_ASSERT_BOOL(itr_len9 != map.end());
  TEST_LIST_STRING(({""}), itr9->second);
  TEST_LIST_INT32(({1}), itr_len9->second);

  FUNC_TEST_END();
}
// source特征传空，输出空
void test_dict_to_attributes_z5() {
  // 特征使用feature来配置传空，config需要使用sparse类型
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes" source="E@.user_feature.user_feature_se.context.feature.app_id" dict_type="app_id" connector="\002" default_value="test_no_data" />
            <feature name="f11" type="direct" source="f10:0" strategy="empty,string" />
            <feature name="f12" type="direct" source="f10:1" strategy="empty,string" />
            <feature name="f13" type="direct" source="f10:2" strategy="empty,string" />
            <feature name="f14" type="direct" source="f10:3" strategy="empty,string" />
            <feature name="f15" type="direct" source="f10:4" strategy="empty,string" />
            <feature name="f16" type="direct" source="f10:5" strategy="empty,string" />
            <feature name="f17" type="direct" source="f10:6" strategy="empty,string" />
            <feature name="f18" type="direct" source="f10:7" strategy="empty,string" />
            <feature name="f19" type="direct" source="f10:8" strategy="empty,string" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini</app_info>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f11" shape="1,1,5" type="sparse" />
        <input name="f12" shape="1,1,5" type="sparse" />
        <input name="f13" shape="1,1,5" type="sparse" />
        <input name="f14" shape="1,1,5" type="sparse" />
        <input name="f15" shape="1,1,5" type="sparse" />
        <input name="f16" shape="1,1,5" type="sparse" />
        <input name="f17" shape="1,1,5" type="sparse" />
        <input name="f18" shape="1,1,5" type="sparse" />
        <input name="f19" shape="1,1,5" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(10, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesConfig* conf = dynamic_cast<DictToAttributesConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["app_id"];

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  // TEST_ASSERT_EQUAL(false, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr01 = map00.find("f11");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_STR(({}), itr01->second);
  // TEST_FEATURE_LIST_STR(({{}}), itr01->second);

  auto itr02 = map00.find("f12");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_STR(({}), itr02->second);
  // TEST_FEATURE_LIST_STR(({{}}), itr02->second);

  auto itr03 = map00.find("f13");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_STR(({}), itr03->second);

  auto itr04 = map00.find("f14");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_STR(({}), itr04->second);

  auto itr05 = map00.find("f15");
  TEST_ASSERT_BOOL(itr05 != map00.end());
  TEST_FEATURE_STR(({}), itr05->second);

  auto itr06 = map00.find("f16");
  TEST_ASSERT_BOOL(itr06 != map00.end());
  TEST_FEATURE_STR(({}), itr06->second);

  auto itr07 = map00.find("f17");
  TEST_ASSERT_BOOL(itr07 != map00.end());
  TEST_FEATURE_STR(({}), itr07->second);

  auto itr08 = map00.find("f18");
  TEST_ASSERT_BOOL(itr08 != map00.end());
  TEST_FEATURE_STR(({}), itr08->second);

  auto itr09 = map00.find("f19");
  TEST_ASSERT_BOOL(itr09 != map00.end());
  TEST_FEATURE_STR(({}), itr09->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values1 = map.find("f11_values");
  auto itr_indices1 = map.find("f11_indices");
  auto itr_dense_shape1 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);
  
  auto itr_values2 = map.find("f12_values");
  auto itr_indices2 = map.find("f12_indices");
  auto itr_dense_shape2 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                            itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f13_values");
  auto itr_indices3 = map.find("f13_indices");
  auto itr_dense_shape3 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                            itr_indices3->second, itr_dense_shape3->second, itr_values3->second);
  
  auto itr_values4 = map.find("f14_values");
  auto itr_indices4 = map.find("f14_indices");
  auto itr_dense_shape4 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values4 != map.end());
  TEST_ASSERT_BOOL(itr_indices4 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape4 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                            itr_indices4->second, itr_dense_shape4->second, itr_values4->second);
  
  auto itr_values5 = map.find("f15_values");
  auto itr_indices5 = map.find("f15_indices");
  auto itr_dense_shape5 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values5 != map.end());
  TEST_ASSERT_BOOL(itr_indices5 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape5 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                            itr_indices5->second, itr_dense_shape5->second, itr_values5->second);
  
  auto itr_values6 = map.find("f16_values");
  auto itr_indices6 = map.find("f16_indices");
  auto itr_dense_shape6 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values6 != map.end());
  TEST_ASSERT_BOOL(itr_indices6 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape6 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                            itr_indices6->second, itr_dense_shape6->second, itr_values6->second);
  
  auto itr_values7 = map.find("f17_values");
  auto itr_indices7 = map.find("f17_indices");
  auto itr_dense_shape7 = map.find("f17_dense_shape");
  TEST_ASSERT_BOOL(itr_values7 != map.end());
  TEST_ASSERT_BOOL(itr_indices7 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape7 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                            itr_indices7->second, itr_dense_shape7->second, itr_values7->second);
  
  auto itr_values8 = map.find("f18_values");
  auto itr_indices8 = map.find("f18_indices");
  auto itr_dense_shape8 = map.find("f18_dense_shape");
  TEST_ASSERT_BOOL(itr_values8 != map.end());
  TEST_ASSERT_BOOL(itr_indices8 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape8 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                            itr_indices8->second, itr_dense_shape8->second, itr_values8->second);
  
  auto itr_values9 = map.find("f19_values");
  auto itr_indices9 = map.find("f19_indices");
  auto itr_dense_shape9 = map.find("f19_dense_shape");
  TEST_ASSERT_BOOL(itr_values9 != map.end());
  TEST_ASSERT_BOOL(itr_indices9 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape9 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                            itr_indices9->second, itr_dense_shape9->second, itr_values9->second);

  FUNC_TEST_END();
}

// connector未手动配置默认为”_”
void test_connect_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="connect" source=".user_feature.user_feature_se.context.feature.num,.user_feature.user_feature_se.context.feature.query" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  //user
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(10);
  (*(pb_ufv2->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("大师");
  
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"10_大师"}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({1, 1}), ({"10_大师"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}
// connector手动配置为”\002”
void test_connect_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="connect" source=".user_feature.user_feature_se.context.feature.num,.user_feature.user_feature_se.context.feature.query" 
            connector="\002" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  //user
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(10);
  (*(pb_ufv2->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("大师");
  
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"10大师"}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({1, 1}), ({"10大师"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}
// 设置tail后会拼接在尾部
void test_connect_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="connect" source=".user_feature.user_feature_se.context.feature.num,.user_feature.user_feature_se.context.feature.query" 
            tail="尾巴" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  //user
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(10);
  (*(pb_ufv2->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("大师");
  
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"10_大师_尾巴"}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({1, 1}), ({"10_大师_尾巴"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}

// 拼接的第一个特征为空，输出空
void test_connect_z4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="connect" source="E@.user_feature.user_feature_se.context.feature.num,.user_feature.user_feature_se.context.feature.query" 
            tail="尾巴" strategy="empty,string" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  //user
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["num"];
  (*(pb_ufv2->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("大师");
  
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}

// 拼接的两个特征都为空，输出空
void test_connect_z5() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="connect" source="E@.user_feature.user_feature_se.context.feature.num,E@.user_feature.user_feature_se.context.feature.query" 
            tail="尾巴" strategy="empty,string" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  //user
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["num"];
  (*(pb_ufv2->mutable_context()->mutable_feature()))["query"];
  
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({1, 0}), ({}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}

// 不同数据类型的特征拼接为字符串
void test_connect_z6() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="connect" source=".user_feature.user_feature_se.context.feature.num,.user_feature.user_feature_se.context.feature.query" 
            tail="尾巴" strategy="empty,string" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  //user
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(1.0);
  (*(pb_ufv2->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("大师");
  
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"1.000000_大师_尾巴"}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({1, 1}), ({"1.000000_大师_尾巴"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}

// 不同数据类型的特征拼接为字符串
void test_connect_z7() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="connect" source=".user_feature.user_feature_se.context.feature.num,.user_feature.user_feature_se.context.feature.fnum" 
            tail="尾巴" strategy="empty,string" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  //user
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["fnum"].mutable_float_list()->add_value(1.0);
  (*(pb_ufv2->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(10);
  
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"10_1.000000_尾巴"}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({1, 1}), ({"10_1.000000_尾巴"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}

// 空字符串拼接
void test_connect_z8() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="connect" source=".user_feature.user_feature_se.context.feature.num,.user_feature.user_feature_se.context.feature.query" 
            tail="尾巴" strategy="empty,string" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectConfig* conf = dynamic_cast<ConnectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  //user
  tensorflow::SequenceExample* pb_ufv2 = request.mutable_user_feature()->mutable_user_feature_se();
  (*(pb_ufv2->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(10);
  (*(pb_ufv2->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("");
  
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"10__尾巴"}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({1, 1}), ({"10__尾巴"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}
// 输入1为空或invalid，输入2不为空，返回取2的数据
void test_get_valid_value_v2_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="get_valid_value_v2" source="E@.item_feature.item_feature_se.context.feature.num,.item_feature.game_item_offline_feature.game_item_statistic_feature.ictr_dou_v1" invalid="-1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  GetValidValueV2Config* conf = dynamic_cast<GetValidValueV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* item_se = item->mutable_item_feature_se();
  (*(item_se->mutable_context()->mutable_feature()))["num"];

  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_ictr_dou_v1(100.0);

  item = request.add_item_feature();
  item_se = item->mutable_item_feature_se();
  (*(item_se->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(-1.0);

  item->mutable_game_item_offline_feature()->mutable_game_item_statistic_feature()->set_ictr_dou_v1(0.1);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr01 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_FEATURE_FLOAT(({100.0}), itr00->second);
  TEST_FEATURE_FLOAT(({0.1}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0}), ({2, 1}), ({100.0, 0.1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

// 输入1为空或invalid，输入2为空或invalid，返回空
void test_get_valid_value_v2_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="get_valid_value_v2" source="E@.item_feature.item_feature_se.context.feature.num,E@.item_feature.item_feature_se.context.feature.name" invalid="-1" strategy="empty,int64" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  GetValidValueV2Config* conf = dynamic_cast<GetValidValueV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* item_se = item->mutable_item_feature_se();
  (*(item_se->mutable_context()->mutable_feature()))["num"];
  (*(item_se->mutable_context()->mutable_feature()))["name"];

  item = request.add_item_feature();
  item_se = item->mutable_item_feature_se();
  (*(item_se->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(-1);
  (*(item_se->mutable_context()->mutable_feature()))["name"].mutable_int64_list()->add_value(-1);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr01 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_FEATURE_INT64(({}), itr00->second);
  TEST_FEATURE_INT64(({-1}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({1, 0}), ({2, 1}), ({-1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}
// 输入1不为空，输入2为空或invalid，返回取1的数据，数据类型为字符串
void test_get_valid_value_v2_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="get_valid_value_v2" source="E@.item_feature.item_feature_se.context.feature.num,E@.item_feature.item_feature_se.context.feature.name" invalid="-1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  GetValidValueV2Config* conf = dynamic_cast<GetValidValueV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* item_se = item->mutable_item_feature_se();
  (*(item_se->mutable_context()->mutable_feature()))["num"].mutable_bytes_list()->add_value("666");
  (*(item_se->mutable_context()->mutable_feature()))["name"];

  item = request.add_item_feature();
  item_se = item->mutable_item_feature_se();
  (*(item_se->mutable_context()->mutable_feature()))["num"].mutable_bytes_list()->add_value("777");
  (*(item_se->mutable_context()->mutable_feature()))["name"].mutable_bytes_list()->add_value("-1");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr01 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_FEATURE_STR(({"666"}), itr00->second);
  TEST_FEATURE_STR(({"777"}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), ({"666", "777"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

// 参数不配置
void test_connect_all_to_string_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="connect_all_to_string" source=".item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.feature_lists.feature_list.float,.request_time" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectAllToStringConfig* conf = dynamic_cast<ConnectAllToStringConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time(1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid01");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid02");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid03");

  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["float"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(12.0);
  fate->mutable_float_list()->add_value(34.0);
  fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(56.0);
  fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(78.0);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid04");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid05");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"appid01_appid02_appid03;12.000000_34.000000_56.000000_78.000000;1000"}), itr00->second);
  TEST_FEATURE_STR(({"appid04_appid05;1000"}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), 
                         ({"appid01_appid02_appid03;12.000000_34.000000_56.000000_78.000000;1000",
                           "appid04_appid05;1000"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}

// 拼接数据存在空
void test_connect_all_to_string_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="connect_all_to_string" source="E@.item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.feature_lists.feature_list.float,.request_time" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectAllToStringConfig* conf = dynamic_cast<ConnectAllToStringConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time(1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];

  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["float"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(12.0);
  fate->mutable_float_list()->add_value(34.0);
  fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(56.0);
  fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(78.0);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"12.000000_34.000000_56.000000_78.000000;1000"}), itr00->second);
  TEST_FEATURE_STR(({"1000"}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), 
                         ({"12.000000_34.000000_56.000000_78.000000;1000",
                           "1000"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}

// 使用不可见字符
void test_connect_all_to_string_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="connect_all_to_string" source="E@.item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.feature_lists.feature_list.float,.request_time" first_connector="\002"/>
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConnectAllToStringConfig* conf = dynamic_cast<ConnectAllToStringConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time(1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];

  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["float"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(12.0);
  fate->mutable_float_list()->add_value(34.0);
  fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(56.0);
  fate = feat_list.add_feature();
  fate->mutable_float_list()->add_value(78.0);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"12.00000034.00000056.00000078.000000;1000"}), itr00->second);
  TEST_FEATURE_STR(({"1000"}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), 
                         ({"12.00000034.00000056.00000078.000000;1000",
                           "1000"}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);
  FUNC_TEST_END();
}
// pb1中包含空值，对应输出为空，类型为浮点数
void test_act_value_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="act_value" source=".user_feature.user_feature_se.feature_lists.feature_list.num,.user_feature.user_feature_se.feature_lists.feature_list.sum" activation_value="300" default_value="1200" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  ActValueConfig* conf = dynamic_cast<ActValueConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();

  tensorflow::SequenceExample* user_se = pb_ufv2->mutable_user_feature_se();
  auto& map01 = *user_se->mutable_feature_lists()->mutable_feature_list();
  tensorflow::FeatureList& list01 = map01["num"];
  tensorflow::Feature* feat = list01.add_feature();
  feat->mutable_float_list()->add_value(10.0);
  feat->mutable_float_list()->add_value(2000.0);

  feat = list01.add_feature();

  tensorflow::FeatureList& list02 = map01["sum"];
  tensorflow::Feature* featt = list02.add_feature();
  featt->mutable_float_list()->add_value(1.6);

  featt = list02.add_feature();
  featt->mutable_float_list()->add_value(10.6);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_FLOAT(({{1200}, {}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_FLOAT(({1200, 0}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  FUNC_TEST_END();
}

// 字段未指定值，输出为pb默认值
void test_conditional_filter_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="conditional_filter" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq" filter="query,appid1,appid3;event_type,001" fields="pay_money,event_time" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  ConditionalFilterConfig* conf = dynamic_cast<ConditionalFilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_event_type("001");
  pb_info->set_pay_money(20);
  pb_info->set_event_time(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_pay_money(30);
  pb_info->set_event_time(300);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{0}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{0}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({0}), itr0->second);
  TEST_LIST_INT32(({1}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({0}), itr1->second);
  TEST_LIST_INT32(({1}), itr_len1->second);

  FUNC_TEST_END();
}

// start未配置默认为0，day_n未配置默认为-1-，1时不限制天数
void test_seq_n_hour_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_n_hour" source=".item_feature.item_feature_se.context.feature.app_id,.item_feature.item_feature_se.context.feature.event_time,.request_time" hour="2" />
            <feature name="f8" type="direct" source="f7:0" />
            <feature name="f9" type="direct" source="f7:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqNHourConfig* conf = dynamic_cast<SeqNHourConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000 - 3600 * 2000);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000 + 3600 * 3000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid3");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000 + 3600 * 1000);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid4");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)110 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f8");
  auto itr10 = map01.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"appid0", "appid1"}), itr00->second);
  TEST_FEATURE_STR(({"appid3"}), itr10->second);

  auto itr01 = map00.find("f9");
  auto itr11 = map01.find("f9");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({(int64_t)100 * 86400 * 1000, (int64_t)100 * 86400 * 1000 - 3600 * 2000}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)100 * 86400 * 1000 + 3600 * 1000}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f8_values");
  auto itr_indices0 = map.find("f8_indices");
  auto itr_dense_shape0 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0}), ({2, 2}), ({"appid0", "appid1", "appid3"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f9_values");
  auto itr_indices1 = map.find("f9_indices");
  auto itr_dense_shape1 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 1, 0}), ({2, 2}), ({(int64_t)100 * 86400 * 1000, (int64_t)100 * 86400 * 1000 - 3600 * 2000,
                                                             (int64_t)100 * 86400 * 1000 + 3600 * 1000}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

// 输入为空，输出为空
void test_seq_n_hour_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_n_hour" source="E@.item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.event_time,.request_time" hour="2" strategy="empty" />
            <feature name="f8" type="direct" source="f7:0" strategy="empty,string" />
            <feature name="f9" type="direct" source="f7:1" strategy="empty,int64" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqNHourConfig* conf = dynamic_cast<SeqNHourConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");;
  (*(item->mutable_context()->mutable_feature()))["event_time"];

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];
  (*(item->mutable_context()->mutable_feature()))["event_time"];


  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(3, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(2).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();
  const auto& map02 = batch_ret.batch(2).context().feature();

  auto itr00 = map00.find("f8");
  auto itr10 = map01.find("f8");
  auto itr20 = map02.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_ASSERT_BOOL(itr20 != map02.end());
  TEST_FEATURE_STR(({}), itr00->second);
  TEST_FEATURE_STR(({}), itr10->second);
  TEST_FEATURE_STR(({}), itr20->second);

  auto itr01 = map00.find("f9");
  auto itr11 = map01.find("f9");
  auto itr21 = map02.find("f9");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_ASSERT_BOOL(itr21 != map02.end());
  TEST_FEATURE_INT64(({}), itr01->second);
  TEST_FEATURE_INT64(({}), itr11->second);
  TEST_FEATURE_INT64(({}), itr21->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f8_values");
  auto itr_indices0 = map.find("f8_indices");
  auto itr_dense_shape0 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({3, 0}), ({}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f9_values");
  auto itr_indices1 = map.find("f9_indices");
  auto itr_dense_shape1 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({}), ({3, 0}), ({}),
                          itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}


void test_seq_merge_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_merge" source="E@.user_feature.af_user_feature.user_open_seq_off_fg.user_open_off.user_sequence,E@.user_feature.af_user_feature.user_open_seq_nl_fg.user_open_nl_48h.user_sequence" eventtime_key="event_time" />
            <feature name="f7" type="direct" source="f6.app_id" />
            <feature name="f8" type="direct" source="f6.event_time" />
            <feature name="f9" type="direct" source="f6.use_duration" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqMergeConfig* conf = dynamic_cast<SeqMergeConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_off_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->mutable_user_open_off();
  qinglong::UserSequenceInfo* pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time(60);
  pb_info->set_use_duration(100);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_event_time(120);
  pb_info->set_use_duration(200);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(20);
  pb_info->set_use_duration(300);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time(360);

  qinglong::UserSequenceEntity* pb_nl_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->mutable_user_open_nl_48h();
  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_event_time(10);

  //item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid3"}, {""}, {"appid0"}, {"appid2"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{360}, {120}, {60}, {20}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{0}, {200}, {100}, {300}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid3", "", "appid0","appid2"}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({360, 120, 60, 20}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({0, 200, 100, 300}), itr2->second);
  TEST_LIST_INT32(({4}), itr_len2->second);

  FUNC_TEST_END();
}

//1、输入为空，输出为空 2、过滤功能正确
void test_utf8_get_re_result_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_get_re_result" source="E@.item_feature.item_feature_se.context.feature.app_id" strategy="empty,string" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8GetReresultConfig* config = dynamic_cast<Utf8GetReresultConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("!@#$%^758&*()_=+[]{}|:;?/*-+"); 
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("123abcDEF");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({}), itr00->second);
  TEST_FEATURE_STR(({"758","123abcdef"}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({1, 0, 1, 1}), ({2, 2}), ({"758","123abcdef"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

// 输入为空，输出为空；输入为空字符串，输出为空
void test_utf8_get_prefix_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_get_prefix" source="E@.item_feature.item_feature_se.context.feature.app_id" max_size="10" strategy="empty,string" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8GetPrefixConfig* config = dynamic_cast<Utf8GetPrefixConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({}), itr00->second);
  TEST_FEATURE_STR(({}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({2, 0}), ({}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}
// 输入为空，输出为空；输入为空字符串，输出为默认值
void test_is_match_str_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="is_match_str" source="E@.item_feature.item_feature_se.context.feature.appid" default_value="test_no_data" strategy="empty,string" />
        </features>
    </config>

    <app_info path="test/data/app_info_minor_mini" />
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f10" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  IsMatchStrConfig* conf = dynamic_cast<IsMatchStrConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("自由落体模拟器");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"];

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(3, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(2).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();
  const auto& map02 = batch_ret.batch(2).context().feature();
  
  auto itr00 = map00.find("f10");
  auto itr10 = map01.find("f10");
  auto itr20 = map02.find("f10");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_ASSERT_BOOL(itr20 != map02.end());

  TEST_FEATURE_STR(({"自由落体模拟器", "test_no_data"}), itr00->second);
  TEST_FEATURE_STR(({}), itr10->second);
  TEST_FEATURE_STR(({}), itr20->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f10_values");
  auto itr_indices0 = map.find("f10_indices");
  auto itr_dense_shape0 = map.find("f10_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1}), ({3, 2}), ({"自由落体模拟器", "test_no_data"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

// 配置start、day_n和clip_size，满足条件的数据量大于clip_size，输出被截断
void test_seq_day_n_direct_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_day_n_direct" source=".user_feature.game_user_online_feature.game_user_behavior_seq_feature.game_user_click_sequence_30d,.request_time" eventtime_key="event_time" fields="udid,data_source" start="5" day_n="7" clip_size="3" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDayNDirectConfig* conf = dynamic_cast<SeqDayNDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::GameUserBehaviorSequenceFeatureGroup* pb_gruop = pb_ufv2->mutable_game_user_online_feature()->mutable_game_user_behavior_seq_feature();
  qinglong::GameUserBehaviorEntity* pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid1");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)110 * 86400 * 1000 + 2000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid2");
  pb_entity->set_data_source(2);
  pb_entity->set_event_time((int64_t)108 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid3");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)106 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid4");
  pb_entity->set_data_source(2);
  pb_entity->set_event_time((int64_t)110 * 86400 * 1000 - 6 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid5");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)103 * 86400 * 1000 + 2000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid6");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)105 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}, {"appid3"}, {"appid4"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{2}, {1}, {2}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid2", "appid3", "appid4"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({2, 1, 2}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

// 配置start、day_n和clip_size，start配置的时间段覆盖所有数据，输出空
void test_seq_day_n_direct_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_day_n_direct" source=".user_feature.game_user_online_feature.game_user_behavior_seq_feature.game_user_click_sequence_30d,.request_time" eventtime_key="event_time" fields="udid,data_source" start="864000" day_n="7" clip_size="3" />
            <feature name="f7" type="direct" source="f6:0" strategy="empty,string" />
            <feature name="f8" type="direct" source="f6:1" strategy="empty,int64" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDayNDirectConfig* conf = dynamic_cast<SeqDayNDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::GameUserBehaviorSequenceFeatureGroup* pb_gruop = pb_ufv2->mutable_game_user_online_feature()->mutable_game_user_behavior_seq_feature();
  qinglong::GameUserBehaviorEntity* pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid1");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)110 * 86400 * 1000 + 2000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid2");
  pb_entity->set_data_source(2);
  pb_entity->set_event_time((int64_t)108 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid3");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)106 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid4");
  pb_entity->set_data_source(2);
  pb_entity->set_event_time((int64_t)105 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid5");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)103 * 86400 * 1000 + 2000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid6");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)98 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({}), itr0->second);
  TEST_LIST_INT32(({0}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({}), itr1->second);
  TEST_LIST_INT32(({0}), itr_len1->second);

  FUNC_TEST_END();
}

// 不配置start、clip_size和day_n，start默认值0，day_n默认值-1，clip_size默认值-1，正常输出
void test_seq_day_n_direct_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_day_n_direct" source=".user_feature.game_user_online_feature.game_user_behavior_seq_feature.game_user_click_sequence_30d,.request_time" eventtime_key="event_time" fields="udid,data_source" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDayNDirectConfig* conf = dynamic_cast<SeqDayNDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::GameUserBehaviorSequenceFeatureGroup* pb_gruop = pb_ufv2->mutable_game_user_online_feature()->mutable_game_user_behavior_seq_feature();
  qinglong::GameUserBehaviorEntity* pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid1");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)110 * 86400 * 1000 + 2000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid2");
  pb_entity->set_data_source(2);
  pb_entity->set_event_time((int64_t)108 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid3");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)106 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid4");
  pb_entity->set_data_source(2);
  pb_entity->set_event_time((int64_t)105 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid5");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)103 * 86400 * 1000 + 2000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid6");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)98 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}, {"appid3"}, {"appid4"}, {"appid5"}, {"appid6"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{2}, {1}, {2}, {1}, {1}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid2", "appid3", "appid4", "appid5", "appid6"}), itr0->second);
  TEST_LIST_INT32(({5}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({2, 1, 2, 1, 1}), itr1->second);
  TEST_LIST_INT32(({5}), itr_len1->second);

  FUNC_TEST_END();
}

// 输入空值，输出空值
void test_seq_day_n_direct_z4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_day_n_direct" source=".user_feature.game_user_online_feature.game_user_behavior_seq_feature.game_user_click_sequence_30d,.request_time" eventtime_key="event_time" fields="udid,data_source" start="5" day_n="7" clip_size="3" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDayNDirectConfig* conf = dynamic_cast<SeqDayNDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::GameUserBehaviorSequenceFeatureGroup* pb_gruop = pb_ufv2->mutable_game_user_online_feature()->mutable_game_user_behavior_seq_feature();
  qinglong::GameUserBehaviorEntity* pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid1");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)110 * 86400 * 1000 + 2000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("");
  pb_entity->set_data_source(2);
  pb_entity->set_event_time((int64_t)108 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid3");
  // pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)106 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  // pb_entity->set_udid("appid4");
  pb_entity->set_data_source(2);
  pb_entity->set_event_time((int64_t)105 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid5");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)103 * 86400 * 1000 + 2000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid6");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)98 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{""}, {"appid3"}, {""}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{2}, {0}, {2}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"", "appid3", ""}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({2, 0, 2}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

// input1传空，输出空;input1传空字符串，输出空字符串
void test_seq_filter_v2_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v2" source="E@.item_feature.item_feature_se.feature_lists.feature_list.name,.item_feature.item_feature_se.feature_lists.feature_list.appid" default_value="-1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1,2,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV2Config* conf = dynamic_cast<SeqFilterV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["name"];
  tensorflow::Feature* fate = feat_list.add_feature();

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");

  item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list3 = (*(item->mutable_feature_lists()->mutable_feature_list()))["name"];
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("");

  auto& feat_list4 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  fate = feat_list4.add_feature();
  fate->mutable_bytes_list()->add_value("appid1");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map01 = batch_ret.batch(1).feature_lists().feature_list();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"-1"}}), itr00->second);

  auto itr10 = map01.find("f6");
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_LIST_STR(({{""}}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f6");
  auto itr_len0 = map.find("f6_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  TEST_LIST_STRING(({"-1", "", "", ""}), itr0->second);
  TEST_LIST_INT32(({1, 1}), itr_len0->second);

  FUNC_TEST_END();
}

// input1传空字符串，input2传空字符串，输出空;input2传空，输出完整的input1
void test_seq_filter_v2_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v2" source=".item_feature.item_feature_se.feature_lists.feature_list.name,E@.item_feature.item_feature_se.feature_lists.feature_list.appid" default_value="-1" strategy="empty,string" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1,2,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV2Config* conf = dynamic_cast<SeqFilterV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["name"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("");

  item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list3 = (*(item->mutable_feature_lists()->mutable_feature_list()))["name"];
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");

  auto& feat_list4 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  fate = feat_list4.add_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map01 = batch_ret.batch(1).feature_lists().feature_list();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"-1"}}), itr00->second);

  auto itr10 = map01.find("f6");
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_LIST_STR(({{"appid0"}}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f6");
  auto itr_len0 = map.find("f6_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  TEST_LIST_STRING(({"-1", "", "appid0", ""}), itr0->second);
  TEST_LIST_INT32(({1, 1}), itr_len0->second);

  FUNC_TEST_END();
}

// 输入包含完整时间，不包含appid，返回默认值
void test_seq_interval_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_interval" source="E@.item_feature.item_feature_se.context.feature.appid,E@.item_feature.item_feature_se.context.feature.first,E@.item_feature.item_feature_se.context.feature.second,E@.item_feature.item_feature_se.context.feature.third,.request_time,.item_feature.item_feature_se.context.feature.app_id" day_n="30" clip_size="5" default_mean="1.1" default_interval="2" />
            <feature name="f5" type="direct" source="f4:0" />
            <feature name="f6" type="direct" source="f4:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqInterval* conf = dynamic_cast<SeqInterval*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"];
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)75 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)68 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)64 * 86400 * 1000);


  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f5");
  auto itr10 = map01.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_FLOAT(({1.1000}), itr00->second);
  TEST_FEATURE_FLOAT(({1.1000}), itr10->second);

  auto itr01 = map00.find("f6");
  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({2, 2, 2}), itr01->second);
  TEST_FEATURE_INT64(({2, 2, 2}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0}), ({2, 1}), ({1.1000, 1.1000}),
                           itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0 ,1, 0, 2, 1, 0, 1, 1, 1, 2}), ({2, 3}), ({2, 2, 2, 2, 2, 2}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

// 输入1不为空，输入2为空，输出空
void test_seq_interval_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_interval" source="E@.item_feature.item_feature_se.context.feature.appid,E@.item_feature.item_feature_se.context.feature.first,E@.item_feature.item_feature_se.context.feature.second,E@.item_feature.item_feature_se.context.feature.third,.request_time,E@.item_feature.item_feature_se.context.feature.app_id" day_n="30" clip_size="5" default_mean="1.1" default_interval="2" strategy="empty,string" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty,string" />
            <feature name="f6" type="direct" source="f4:1" strategy="empty,string" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqInterval* conf = dynamic_cast<SeqInterval*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");;
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)75 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)68 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)64 * 86400 * 1000);


  (*(item->mutable_context()->mutable_feature()))["app_id"];

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f5");
  auto itr10 = map01.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_FLOAT(({}), itr00->second);
  TEST_FEATURE_FLOAT(({1.1000}), itr10->second);

  auto itr01 = map00.find("f6");
  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({}), itr01->second);
  TEST_FEATURE_INT64(({2, 2, 2}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({1, 0}), ({2, 1}), ({1.1000}),
                           itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({1, 0, 1, 1, 1, 2}), ({2, 3}), ({2, 2, 2}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

// clip_size使用默认值，day_n使用默认值，start设置防穿越时间,单位秒
void test_seq_interval_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_interval" source="E@.item_feature.item_feature_se.context.feature.appid,E@.item_feature.item_feature_se.context.feature.first,E@.item_feature.item_feature_se.context.feature.second,E@.item_feature.item_feature_se.context.feature.third,.request_time,E@.item_feature.item_feature_se.context.feature.app_id" start="5" default_mean="1.1" default_interval="2" strategy="empty,string" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty,string" />
            <feature name="f6" type="direct" source="f4:1" strategy="empty,string" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqInterval* conf = dynamic_cast<SeqInterval*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)110 * 86400 * 1000 - 4);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)68 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)64 * 86400 * 1000);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");;
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)98 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000);

  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f5");
  auto itr10 = map01.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_FLOAT(({2.0000, 1.1000}), itr00->second);
  TEST_FEATURE_FLOAT(({1.1000}), itr10->second);

  auto itr01 = map00.find("f6");
  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({1036800000, 259200000, 259200000, 2, 2, 2}), itr01->second);
  TEST_FEATURE_INT64(({2, 2, 2}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 1, 0}), ({2, 2}), ({2.0000, 1.1000, 1.1000}),
                           itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 1, 0, 1, 1, 1, 2}), ({2, 6}), ({1036800000, 259200000, 259200000, 2, 2, 2, 2, 2, 2}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

// 合并空字符串
void test_seq_merge_v2_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_merge_v2" source=".user_feature.af_user_feature.user_open_seq_off_fg.user_open_off.user_sequence,.user_feature.af_user_feature.user_open_seq_nl_fg.user_open_nl_48h.user_sequence" appid_key="app_id" eventtime_key="event_time" />
            <feature name="f7" type="direct" source="f6.app_id" />
            <feature name="f8" type="direct" source="f6.event_time" />
            <feature name="f9" type="direct" source="f6.use_duration" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqMergeV2Config* conf = dynamic_cast<SeqMergeV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_off_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->mutable_user_open_off();
  qinglong::UserSequenceInfo* pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("");
  pb_info->set_event_time(60);
  pb_info->set_use_duration(100);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_use_duration(200);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(240);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time(360);
  pb_info->set_use_duration(400);

  qinglong::UserSequenceEntity* pb_nl_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->mutable_user_open_nl_48h();
  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(200);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid1");           //重复数据过滤
  pb_info->set_event_time(120);
  pb_info->set_use_duration(200);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid2");           //重复数据过滤
  pb_info->set_event_time(240);
  pb_info->set_use_duration(300);

  //item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid3"}, {"appid2"}, {""}, {"appid1"}, {""}, {"appid1"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{360}, {240}, {240}, {120}, {60}, {0}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{400}, {0}, {200}, {200}, {100}, {200}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid3", "appid2", "", "appid1", "", "appid1"}), itr0->second);
  TEST_LIST_INT32(({6}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({360, 240, 240, 120, 60, 0}), itr1->second);
  TEST_LIST_INT32(({6}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({400, 0, 200, 200, 100, 200}), itr2->second);
  TEST_LIST_INT32(({6}), itr_len2->second);

  FUNC_TEST_END();
}

// appid和event_time相同，近线特征use_duration不同，根据输入顺序取最靠前的use_duration
void test_seq_merge_v2_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_merge_v2" source=".user_feature.af_user_feature.user_open_seq_off_fg.user_open_off.user_sequence,.user_feature.af_user_feature.user_open_seq_nl_fg.user_open_nl_48h.user_sequence" appid_key="app_id" eventtime_key="event_time" />
            <feature name="f7" type="direct" source="f6.app_id" />
            <feature name="f8" type="direct" source="f6.event_time" />
            <feature name="f9" type="direct" source="f6.use_duration" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqMergeV2Config* conf = dynamic_cast<SeqMergeV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_off_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->mutable_user_open_off();
  qinglong::UserSequenceInfo* pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("");
  pb_info->set_event_time(60);
  pb_info->set_use_duration(100);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_use_duration(200);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(240);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time(360);
  pb_info->set_use_duration(400);

  qinglong::UserSequenceEntity* pb_nl_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->mutable_user_open_nl_48h();
  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(200);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid1");           //重复数据过滤
  pb_info->set_event_time(120);
  pb_info->set_use_duration(200);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid2");           //重复数据过滤
  pb_info->set_event_time(240);
  pb_info->set_use_duration(300);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid2");           //重复数据过滤
  pb_info->set_event_time(240);
  pb_info->set_use_duration(600);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid2");           //重复数据过滤
  pb_info->set_event_time(240);
  pb_info->set_use_duration(500);

  //item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid3"}, {"appid2"}, {""}, {"appid1"}, {""}, {"appid1"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{360}, {240}, {240}, {120}, {60}, {0}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{400}, {0}, {200}, {200}, {100}, {200}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid3", "appid2", "", "appid1", "", "appid1"}), itr0->second);
  TEST_LIST_INT32(({6}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({360, 240, 240, 120, 60, 0}), itr1->second);
  TEST_LIST_INT32(({6}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({400, 0, 200, 200, 100, 200}), itr2->second);
  TEST_LIST_INT32(({6}), itr_len2->second);

  FUNC_TEST_END();
}

// input为空，输出为空
void test_seq_diff_v2_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_diff_v2" source="E@.item_feature.item_feature_se.context.feature.ins_appid,E@.item_feature.item_feature_se.context.feature.ins_time,E@.item_feature.item_feature_se.context.feature.clk_appid,E@.item_feature.item_feature_se.context.feature.clk_time,.request_time" day_n="30" delta_day="-10" status="0" clip_size="3" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
            <feature name="f6" type="direct" source="f4:1" strategy="empty" />
            <feature name="f7" type="seq_diff_v2" source="E@.item_feature.item_feature_se.context.feature.ins_appid,E@.item_feature.item_feature_se.context.feature.ins_time,E@.item_feature.item_feature_se.context.feature.clk_appid,E@.item_feature.item_feature_se.context.feature.clk_time,.request_time" day_n="30" delta_day="-10" status="1" clip_size="3" />
            <feature name="f8" type="direct" source="f7:0" strategy="empty" />
            <feature name="f9" type="direct" source="f7:1" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(6, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDiffV2Config* conf = dynamic_cast<SeqDiffV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000); 

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"];
  (*(item->mutable_context()->mutable_feature()))["ins_time"];
  (*(item->mutable_context()->mutable_feature()))["clk_appid"];
  (*(item->mutable_context()->mutable_feature()))["clk_time"];

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["ins_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["clk_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["clk_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f5");
  auto itr10 = map01.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({}), itr00->second);
  TEST_FEATURE_STR(({"appid2"}), itr10->second);

  auto itr01 = map00.find("f6");
  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)85 * 86400 * 1000}), itr11->second);

  auto itr02 = map00.find("f8");
  auto itr12 = map01.find("f8");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());
  TEST_FEATURE_STR(({}), itr02->second);
  TEST_FEATURE_STR(({}), itr12->second);

  auto itr03 = map00.find("f9");
  auto itr13 = map01.find("f9");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());
  TEST_FEATURE_INT64(({}), itr03->second);
  TEST_FEATURE_INT64(({}), itr13->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({1, 0}), ({2, 1}), ({"appid2"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({1, 0}), ({2, 1}), ({(int64_t)85 * 86400 * 1000}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f8_values");
  auto itr_indices2 = map.find("f8_indices");
  auto itr_dense_shape2 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({2, 0}), ({}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f9_values");
  auto itr_indices3 = map.find("f9_indices");
  auto itr_dense_shape3 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_INT64(({}), ({2, 0}), ({}),
                            itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  FUNC_TEST_END();
}

// input中appid为空，输出为空
void test_seq_diff_v2_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_diff_v2" source="E@.item_feature.item_feature_se.context.feature.ins_appid,E@.item_feature.item_feature_se.context.feature.ins_time,E@.item_feature.item_feature_se.context.feature.clk_appid,E@.item_feature.item_feature_se.context.feature.clk_time,.request_time" day_n="30" delta_day="-10" status="0" clip_size="3" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
            <feature name="f6" type="direct" source="f4:1" strategy="empty" />
            <feature name="f7" type="seq_diff_v2" source="E@.item_feature.item_feature_se.context.feature.ins_appid,E@.item_feature.item_feature_se.context.feature.ins_time,E@.item_feature.item_feature_se.context.feature.clk_appid,E@.item_feature.item_feature_se.context.feature.clk_time,.request_time" day_n="30" delta_day="-10" status="1" clip_size="3" />
            <feature name="f8" type="direct" source="f7:0" strategy="empty" />
            <feature name="f9" type="direct" source="f7:1" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(6, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDiffV2Config* conf = dynamic_cast<SeqDiffV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000); 

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"];
  (*(item->mutable_context()->mutable_feature()))["ins_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["clk_appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["clk_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["ins_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["clk_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["clk_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f5");
  auto itr10 = map01.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({}), itr00->second);
  TEST_FEATURE_STR(({"appid2"}), itr10->second);

  auto itr01 = map00.find("f6");
  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)85 * 86400 * 1000}), itr11->second);

  auto itr02 = map00.find("f8");
  auto itr12 = map01.find("f8");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());
  TEST_FEATURE_STR(({}), itr02->second);
  TEST_FEATURE_STR(({}), itr12->second);

  auto itr03 = map00.find("f9");
  auto itr13 = map01.find("f9");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());
  TEST_FEATURE_INT64(({}), itr03->second);
  TEST_FEATURE_INT64(({}), itr13->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({1, 0}), ({2, 1}), ({"appid2"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({1, 0}), ({2, 1}), ({(int64_t)85 * 86400 * 1000}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f8_values");
  auto itr_indices2 = map.find("f8_indices");
  auto itr_dense_shape2 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({2, 0}), ({}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f9_values");
  auto itr_indices3 = map.find("f9_indices");
  auto itr_dense_shape3 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_INT64(({}), ({2, 0}), ({}),
                            itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  FUNC_TEST_END();
}

// input中时间为空，输出为空
void test_seq_diff_v2_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_diff_v2" source="E@.item_feature.item_feature_se.context.feature.ins_appid,E@.item_feature.item_feature_se.context.feature.ins_time,E@.item_feature.item_feature_se.context.feature.clk_appid,E@.item_feature.item_feature_se.context.feature.clk_time,.request_time" day_n="30" delta_day="-10" status="0" clip_size="3" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
            <feature name="f6" type="direct" source="f4:1" strategy="empty" />
            <feature name="f7" type="seq_diff_v2" source="E@.item_feature.item_feature_se.context.feature.ins_appid,E@.item_feature.item_feature_se.context.feature.ins_time,E@.item_feature.item_feature_se.context.feature.clk_appid,E@.item_feature.item_feature_se.context.feature.clk_time,.request_time" day_n="30" delta_day="-10" status="1" clip_size="3" />
            <feature name="f8" type="direct" source="f7:0" strategy="empty" />
            <feature name="f9" type="direct" source="f7:1" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(6, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDiffV2Config* conf = dynamic_cast<SeqDiffV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000); 

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["ins_time"];
  (*(item->mutable_context()->mutable_feature()))["clk_appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["clk_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["ins_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["clk_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["clk_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f5");
  auto itr10 = map01.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({}), itr00->second);
  TEST_FEATURE_STR(({"appid2"}), itr10->second);

  auto itr01 = map00.find("f6");
  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)85 * 86400 * 1000}), itr11->second);

  auto itr02 = map00.find("f8");
  auto itr12 = map01.find("f8");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());
  TEST_FEATURE_STR(({}), itr02->second);
  TEST_FEATURE_STR(({}), itr12->second);

  auto itr03 = map00.find("f9");
  auto itr13 = map01.find("f9");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());
  TEST_FEATURE_INT64(({}), itr03->second);
  TEST_FEATURE_INT64(({}), itr13->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({1, 0}), ({2, 1}), ({"appid2"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({1, 0}), ({2, 1}), ({(int64_t)85 * 86400 * 1000}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f8_values");
  auto itr_indices2 = map.find("f8_indices");
  auto itr_dense_shape2 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({}), ({2, 0}), ({}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f9_values");
  auto itr_indices3 = map.find("f9_indices");
  auto itr_dense_shape3 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_INT64(({}), ({2, 0}), ({}),
                            itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  FUNC_TEST_END();
}

// 输入空，输出默认值
void test_seq_max_value_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_max_value" source="E@.item_feature.item_feature_se.context.feature.ins_time,.request_time" start="1" day_n="10" default_value="100" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="dense" />
    </model_input_config>
  )";
  {
     std::vector<std::shared_ptr<Config>> vec;
     XmlConfigMgr::parse_from_string(config_str, "", "", vec);
     TEST_ASSERT_EQUAL(2, vec.size());
     TEST_ASSERT_BOOL(nullptr != vec[0]);
  
     auto config = std::dynamic_pointer_cast<SeqMaxValueConfig>(vec[0]);
     TEST_ASSERT_BOOL(nullptr != config);
  
     std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
     ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
  
     TEST_ASSERT_EQUAL(1, in_vec.size());
     TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  
     google::protobuf::Arena arena;
     qinglong::FeRequest request;
     qinglong::BatchSequenceExample batch_ret;
     qinglong::PredictRequest ret;
  
     // 请求时间
     request.set_request_time((int64_t)100 * 86400 * 1000);
     tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
     auto& event_times = (*(item->mutable_context()->mutable_feature()))["ins_time"];
    //  event_times.mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);

  
     toSequenceExample(&arena, request, vec, batch_ret);
  
     TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
     TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  
     const auto& map1 = batch_ret.batch(0).context().feature();
     auto itr1 = map1.find("f5");
     TEST_ASSERT_BOOL(itr1 != map1.end());
     TEST_FEATURE_INT64(({100}), itr1->second);
  
     std::vector<std::shared_ptr<Config>> need_vec;
     selectConfigUsingModelInput(vec, in_vec, need_vec);
     toPredictRequest(&arena, request, need_vec, in_vec, ret);
     
     auto& map = ret.inputs();
     auto itr0 = map.find("f5");
     TEST_ASSERT_BOOL(itr0 != map.end());
     TEST_ASSERT_BOOL(itr0->second.int64_val().at(0) ==  100);
  }

  FUNC_TEST_END();
}

// 配置start，day_n取默认值
void test_seq_max_value_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_max_value" source="E@.item_feature.item_feature_se.context.feature.ins_time,.request_time" start="1000" default_value="100" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="dense" />
    </model_input_config>
  )";
  {
     std::vector<std::shared_ptr<Config>> vec;
     XmlConfigMgr::parse_from_string(config_str, "", "", vec);
     TEST_ASSERT_EQUAL(2, vec.size());
     TEST_ASSERT_BOOL(nullptr != vec[0]);
  
     auto config = std::dynamic_pointer_cast<SeqMaxValueConfig>(vec[0]);
     TEST_ASSERT_BOOL(nullptr != config);
  
     std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
     ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
  
     TEST_ASSERT_EQUAL(1, in_vec.size());
     TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  
     google::protobuf::Arena arena;
     qinglong::FeRequest request;
     qinglong::BatchSequenceExample batch_ret;
     qinglong::PredictRequest ret;
  
     // 请求时间
     request.set_request_time((int64_t)100 * 86400 * 1000);
     tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
     auto& event_times = (*(item->mutable_context()->mutable_feature()))["ins_time"];
     event_times.mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000 - 900);
     event_times.mutable_int64_list()->add_value((int64_t)10 * 86400 * 1000);

  
     toSequenceExample(&arena, request, vec, batch_ret);
  
     TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
     TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  
     const auto& map1 = batch_ret.batch(0).context().feature();
     auto itr1 = map1.find("f5");
     TEST_ASSERT_BOOL(itr1 != map1.end());
     TEST_FEATURE_INT64(({(int64_t)10 * 86400 * 1000}), itr1->second);
  
     std::vector<std::shared_ptr<Config>> need_vec;
     selectConfigUsingModelInput(vec, in_vec, need_vec);
     toPredictRequest(&arena, request, need_vec, in_vec, ret);
     
     auto& map = ret.inputs();
     auto itr0 = map.find("f5");
     TEST_ASSERT_BOOL(itr0 != map.end());
     TEST_ASSERT_BOOL(itr0->second.int64_val().at(0) ==  (int64_t)10 * 86400 * 1000);
  }

  FUNC_TEST_END();
}

// 正常配置start，day_n
void test_seq_max_value_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_max_value" source="E@.item_feature.item_feature_se.context.feature.ins_time,.request_time" start="1000" day_n="10" default_value="100" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
        </features>
    </config>
  )";

  std::string config_str_not_hit = R"(
    <config>
        <features>
            <feature name="f4" type="seq_max_value" source=".item_feature.item_feature_se.context.feature.ins_time,.request_time" day_n="1" default_value="101" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="dense" />
    </model_input_config>
  )";
  {
     std::vector<std::shared_ptr<Config>> vec;
     XmlConfigMgr::parse_from_string(config_str, "", "", vec);
     TEST_ASSERT_EQUAL(2, vec.size());
     TEST_ASSERT_BOOL(nullptr != vec[0]);
  
     auto config = std::dynamic_pointer_cast<SeqMaxValueConfig>(vec[0]);
     TEST_ASSERT_BOOL(nullptr != config);
  
     std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
     ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
  
     TEST_ASSERT_EQUAL(1, in_vec.size());
     TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  
     google::protobuf::Arena arena;
     qinglong::FeRequest request;
     qinglong::BatchSequenceExample batch_ret;
     qinglong::PredictRequest ret;
  
     // 请求时间
     request.set_request_time((int64_t)100 * 86400 * 1000);
     tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
     auto& event_times = (*(item->mutable_context()->mutable_feature()))["ins_time"];
     event_times.mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000 - 900);
     event_times.mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000);
     event_times.mutable_int64_list()->add_value((int64_t)93 * 86400 * 1000);
     event_times.mutable_int64_list()->add_value((int64_t)10 * 86400 * 1000);

  
     toSequenceExample(&arena, request, vec, batch_ret);
  
     TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
     TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  
     const auto& map1 = batch_ret.batch(0).context().feature();
     auto itr1 = map1.find("f5");
     TEST_ASSERT_BOOL(itr1 != map1.end());
     TEST_FEATURE_INT64(({(int64_t)93 * 86400 * 1000}), itr1->second);
  
     std::vector<std::shared_ptr<Config>> need_vec;
     selectConfigUsingModelInput(vec, in_vec, need_vec);
     toPredictRequest(&arena, request, need_vec, in_vec, ret);
     
     auto& map = ret.inputs();
     auto itr0 = map.find("f5");
     TEST_ASSERT_BOOL(itr0 != map.end());
     TEST_ASSERT_BOOL(itr0->second.int64_val().at(0) ==  (int64_t)93 * 86400 * 1000);
  }
  {
    std::vector<std::shared_ptr<Config>> vec;
    XmlConfigMgr::parse_from_string(config_str_not_hit, "", "", vec);
    TEST_ASSERT_EQUAL(2, vec.size());
    TEST_ASSERT_BOOL(nullptr != vec[0]);
 
    auto config = std::dynamic_pointer_cast<SeqMaxValueConfig>(vec[0]);
    TEST_ASSERT_BOOL(nullptr != config);
 
    std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
    ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
 
    TEST_ASSERT_EQUAL(1, in_vec.size());
    TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
 
    google::protobuf::Arena arena;
    qinglong::FeRequest request;
    qinglong::BatchSequenceExample batch_ret;
    qinglong::PredictRequest ret;
 
    // 请求时间
    request.set_request_time((int64_t)100 * 86400 * 1000);
    tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
    auto& event_times = (*(item->mutable_context()->mutable_feature()))["ins_time"];
    event_times.mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000);
    event_times.mutable_int64_list()->add_value((int64_t)80 * 86400 * 1000);
 
    toSequenceExample(&arena, request, vec, batch_ret);
 
    TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
    TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
 
    const auto& map1 = batch_ret.batch(0).context().feature();
    auto itr1 = map1.find("f5");
    TEST_ASSERT_BOOL(itr1 != map1.end());
    TEST_FEATURE_INT64(({101}), itr1->second);
 
    std::vector<std::shared_ptr<Config>> need_vec;
    selectConfigUsingModelInput(vec, in_vec, need_vec);
    toPredictRequest(&arena, request, need_vec, in_vec, ret);
    
    auto& map = ret.inputs();
    auto itr0 = map.find("f5");
    TEST_ASSERT_BOOL(itr0 != map.end());
    TEST_ASSERT_BOOL(itr0->second.int64_val().at(0) ==  (int64_t)101);
  }

  FUNC_TEST_END();
}
// connector设置为'\031'
void test_dict_to_attributes_v2_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f10" type="dict_to_attributes_v2" source=".item_feature.item_feature_se.context.feature.package_name" dict_type="package_name" connector="\031" default_value="test_no_data" />
            <feature name="f11" type="direct" source="f10:0" />
            <feature name="f12" type="direct" source="f10:1" />
            <feature name="f13" type="direct" source="f10:2" />
            <feature name="f14" type="direct" source="f10:3" />
            <feature name="f15" type="direct" source="f10:4" />
            <feature name="f16" type="direct" source="f10:5" />
            <feature name="f17" type="direct" source="f10:6" />
            <feature name="f18" type="direct" source="f10:7" />
            <feature name="f19" type="direct" source="f10:8" />
            <feature name="f20" type="direct" source="f10:9" />
            <feature name="f21" type="direct" source="f10:10" />
            <feature name="f22" type="direct" source="f10:11" />
        </features>
    </config>

    <app_info>test/data/app_info_minor_mini_extra</app_info>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f11" shape="1" type="sparse" />
        <input name="f12" shape="1" type="sparse" />
        <input name="f13" shape="1" type="sparse" />
        <input name="f14" shape="1" type="sparse" />
        <input name="f15" shape="1" type="sparse" />
        <input name="f16" shape="1" type="sparse" />
        <input name="f17" shape="1" type="sparse" />
        <input name="f18" shape="1" type="sparse" />
        <input name="f19" shape="1" type="sparse" />
        <input name="f20" shape="1" type="sparse" />
        <input name="f21" shape="1" type="sparse" />
        <input name="f22" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "/home/featureextractor/", "", vec);

  TEST_ASSERT_EQUAL(13, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  DictToAttributesV2Config* conf = dynamic_cast<DictToAttributesV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.network.xf18142");
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.tzyz.meng.honor");
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("com.PeacockStudio.KongfuPunchLite");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["package_name"].mutable_bytes_list()->add_value("111");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr001 = map00.find("f11");
  auto itr101 = map01.find("f11");
  TEST_ASSERT_BOOL(itr001 != map00.end());
  TEST_ASSERT_BOOL(itr101 != map01.end());

  TEST_FEATURE_STR(({"925089172", "104422431", "922331498"}), itr001->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr101->second);

  auto itr002 = map00.find("f12");
  auto itr102 = map01.find("f12");
  TEST_ASSERT_BOOL(itr002 != map00.end());
  TEST_ASSERT_BOOL(itr102 != map01.end());

  TEST_FEATURE_STR(({"com.network.xf18142", "com.tzyz.meng.honor", "com.PeacockStudio.KongfuPunchLite"}), itr002->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr102->second);

  auto itr003 = map00.find("f13");
  auto itr103 = map01.find("f13");
  TEST_ASSERT_BOOL(itr003 != map00.end());
  TEST_ASSERT_BOOL(itr103 != map01.end());

  TEST_FEATURE_STR(({"旋风加速器", "无尽梦回", "功夫之拳2"}), itr003->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr103->second);

  auto itr004 = map00.find("f14");
  auto itr104 = map01.find("f14");
  TEST_ASSERT_BOOL(itr004 != map00.end());
  TEST_ASSERT_BOOL(itr104 != map01.end());

  TEST_FEATURE_STR(({"应用", "游戏", "游戏"}), itr004->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr104->second);

  auto itr005 = map00.find("f15");
  auto itr105 = map01.find("f15");
  TEST_ASSERT_BOOL(itr005 != map00.end());
  TEST_ASSERT_BOOL(itr105 != map01.end());

  TEST_FEATURE_STR(({"生活", "角色扮演", "动作射击"}), itr005->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr105->second);

  auto itr006 = map00.find("f16");
  auto itr106 = map01.find("f16");
  TEST_ASSERT_BOOL(itr006 != map00.end());
  TEST_ASSERT_BOOL(itr106 != map01.end());

  TEST_FEATURE_STR(({"生活-其他", "角色扮演-其他", "格斗"}), itr006->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr106->second);

  auto itr007 = map00.find("f17");
  auto itr107 = map01.find("f17");
  TEST_ASSERT_BOOL(itr007 != map00.end());
  TEST_ASSERT_BOOL(itr107 != map01.end());
  
  const char c = 31;
  std::string invisible_char = std::string(1,c);
  std::string str12;
  str12.append("经典").append(invisible_char).append("破解").append(invisible_char).append("格斗").append(invisible_char).append("李小龙");

  TEST_FEATURE_STR(({"默认值", "默认值", str12}), itr007->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr107->second);

  auto itr008 = map00.find("f18");
  auto itr108 = map01.find("f18");
  TEST_ASSERT_BOOL(itr008 != map00.end());
  TEST_ASSERT_BOOL(itr108 != map01.end());

  TEST_FEATURE_STR(({"默认值", "杭州弹指宇宙科技有限公司", "默认值"}), itr008->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr108->second);

  auto itr009 = map00.find("f19");
  auto itr109 = map01.find("f19");
  TEST_ASSERT_BOOL(itr009 != map00.end());
  TEST_ASSERT_BOOL(itr109 != map01.end());

  TEST_FEATURE_STR(({"默认值", "109999814778", "默认值"}), itr009->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr109->second);

  auto itr010 = map00.find("f20");
  auto itr110 = map01.find("f20");
  TEST_ASSERT_BOOL(itr010 != map00.end());
  TEST_ASSERT_BOOL(itr110 != map01.end());

  TEST_FEATURE_STR(({"test1", "默认值", "test3"}), itr010->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr110->second);

  auto itr011 = map00.find("f21");
  auto itr111 = map01.find("f21");
  TEST_ASSERT_BOOL(itr011 != map00.end());
  TEST_ASSERT_BOOL(itr111 != map01.end());

  
  std::string str11;
  str11.append("a").append(invisible_char).append("b").append(invisible_char).append("c");

  TEST_FEATURE_STR(({str11, "test_no_data", "默认值"}), itr011->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr111->second);

  auto itr012 = map00.find("f22");
  auto itr112 = map01.find("f22");
  TEST_ASSERT_BOOL(itr012 != map00.end());
  TEST_ASSERT_BOOL(itr112 != map01.end());

  TEST_FEATURE_STR(({"test_no_data", "test_no_data", "扩展3"}), itr012->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr112->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values1 = map.find("f11_values");
  auto itr_indices1 = map.find("f11_indices");
  auto itr_dense_shape1 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"925089172", "104422431", "922331498", "test_no_data"}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f12_values");
  auto itr_indices2 = map.find("f12_indices");
  auto itr_dense_shape2 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"com.network.xf18142", "com.tzyz.meng.honor", "com.PeacockStudio.KongfuPunchLite", "test_no_data"}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f13_values");
  auto itr_indices3 = map.find("f13_indices");
  auto itr_dense_shape3 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"旋风加速器", "无尽梦回", "功夫之拳2", "test_no_data"}),
                        itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  auto itr_values4 = map.find("f14_values");
  auto itr_indices4 = map.find("f14_indices");
  auto itr_dense_shape4 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values4 != map.end());
  TEST_ASSERT_BOOL(itr_indices4 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape4 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"应用", "游戏", "游戏", "test_no_data"}),
                        itr_indices4->second, itr_dense_shape4->second, itr_values4->second);

  auto itr_values5 = map.find("f15_values");
  auto itr_indices5 = map.find("f15_indices");
  auto itr_dense_shape5 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values5 != map.end());
  TEST_ASSERT_BOOL(itr_indices5 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape5 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"生活", "角色扮演", "动作射击", "test_no_data"}),
                        itr_indices5->second, itr_dense_shape5->second, itr_values5->second);

  auto itr_values6 = map.find("f16_values");
  auto itr_indices6 = map.find("f16_indices");
  auto itr_dense_shape6 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values6 != map.end());
  TEST_ASSERT_BOOL(itr_indices6 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape6 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"生活-其他", "角色扮演-其他", "格斗", "test_no_data"}),
                        itr_indices6->second, itr_dense_shape6->second, itr_values6->second);

  auto itr_values7 = map.find("f17_values");
  auto itr_indices7 = map.find("f17_indices");
  auto itr_dense_shape7 = map.find("f17_dense_shape");
  TEST_ASSERT_BOOL(itr_values7 != map.end());
  TEST_ASSERT_BOOL(itr_indices7 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape7 != map.end());

  
  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"默认值", "默认值", str12, "test_no_data"}),
                        itr_indices7->second, itr_dense_shape7->second, itr_values7->second);

  auto itr_values8 = map.find("f18_values");
  auto itr_indices8 = map.find("f18_indices");
  auto itr_dense_shape8 = map.find("f18_dense_shape");
  TEST_ASSERT_BOOL(itr_values8 != map.end());
  TEST_ASSERT_BOOL(itr_indices8 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape8 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"默认值", "杭州弹指宇宙科技有限公司", "默认值", "test_no_data"}),
                        itr_indices8->second, itr_dense_shape8->second, itr_values8->second);

  auto itr_values9 = map.find("f19_values");
  auto itr_indices9 = map.find("f19_indices");
  auto itr_dense_shape9 = map.find("f19_dense_shape");
  TEST_ASSERT_BOOL(itr_values9 != map.end());
  TEST_ASSERT_BOOL(itr_indices9 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape9 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"默认值", "109999814778", "默认值", "test_no_data"}),
                        itr_indices9->second, itr_dense_shape9->second, itr_values9->second);

  
  auto itr_values10 = map.find("f20_values");
  auto itr_indices10 = map.find("f20_indices");
  auto itr_dense_shape10 = map.find("f20_dense_shape");
  TEST_ASSERT_BOOL(itr_values10 != map.end());
  TEST_ASSERT_BOOL(itr_indices10 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape10 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"test1", "默认值", "test3", "test_no_data"}),
                        itr_indices10->second, itr_dense_shape10->second, itr_values10->second);

  auto itr_values11 = map.find("f21_values");
  auto itr_indices11 = map.find("f21_indices");
  auto itr_dense_shape11 = map.find("f21_dense_shape");
  TEST_ASSERT_BOOL(itr_values11 != map.end());
  TEST_ASSERT_BOOL(itr_indices11 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape11 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({str11, "test_no_data", "默认值", "test_no_data"}),
                        itr_indices11->second, itr_dense_shape11->second, itr_values11->second);

  auto itr_values12 = map.find("f22_values");
  auto itr_indices12 = map.find("f22_indices");
  auto itr_dense_shape12 = map.find("f22_dense_shape");
  TEST_ASSERT_BOOL(itr_values12 != map.end());
  TEST_ASSERT_BOOL(itr_indices12 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape12 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"test_no_data", "test_no_data", "扩展3", "test_no_data"}),
                        itr_indices12->second, itr_dense_shape12->second, itr_values12->second);
  FUNC_TEST_END();
}

// group赋值的slot不与featurename校验重复
void test_hash_slot_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" />
            <feature name="f3" type="direct" source=".item_feature.item_feature_se.context.feature.appid" strategy="hash" />
        </features>
    </config>
  )";

  std::string config_str2 = R"(
    <config>
        <features>
            <feature name="12345" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" />
            <feature name="21543" type="direct" source=".item_feature.item_feature_se.context.feature.appid" strategy="hash" />
        </features>
    </config>
    <hash_slot flag="true" />
  )";

  std::string config_str3 = R"(
    <config>
        <features>
            <feature name="10000" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" />
            <feature name="6666" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" />
            <feature name="f3" type="direct" source=".item_feature.item_feature_se.context.feature.appid" strategy="hash" />
            <feature name="12345" type="direct" source=".item_feature.item_feature_se.context.feature.appid" strategy="hash" />
        </features>
    </config>
    <hash_slot flag="true">
      <group name="10000,f3" slot="12345" />
    </hash_slot>
  )";

  std::string config_str4 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" />
        </features>
    </config>
    <hash_slot flag="true">
      <group name="f1,f3" slot="65535" />
    </hash_slot>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_BOOL(nullptr != vec[0]);
  DirectConfig* conf1 = dynamic_cast<DirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf1);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_num(0);
  pb_use->add_user_sequence()->set_num(1);
  pb_use->add_user_sequence()->set_num(2);
  pb_use->add_user_sequence()->set_num(3);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::Feature& input_f = (*(item->mutable_context()->mutable_feature()))["appid"];
  input_f.mutable_bytes_list()->add_value("900778570");
  input_f.mutable_bytes_list()->add_value("104436666");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map = batch_ret.batch(0).context().feature();
  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map0.find("f1");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_FEATURE_LIST_INT64(({{3042990692995248735}, {6333283390351972457}, {6238308942721332819}, {4266776588970077092}}), itr01->second);

  auto itr02 = map.find("f3");
  TEST_ASSERT_BOOL(itr02 != map.end());
  TEST_FEATURE_INT64(({4332178348574154799, 3756374228245537501}), itr02->second);

  vec.clear();
  XmlConfigMgr::parse_from_string(config_str2, "", "", vec);
  qinglong::BatchSequenceExample batch_ret2;

  toSequenceExample(&arena, request, vec, batch_ret2);

  TEST_ASSERT_EQUAL(1, batch_ret2.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(0).has_feature_lists());

  const auto& map1 = batch_ret2.batch(0).context().feature();
  const auto& map01 = batch_ret2.batch(0).feature_lists().feature_list();

  auto itr03 = map01.find("12345");
  TEST_ASSERT_BOOL(itr03 != map01.end());
  TEST_FEATURE_LIST_INT64(({{3475054782246105695}, {3474905001855260777}, {3475069096352822867}, {3474987479483001764}}), itr03->second);

  auto itr04 = map1.find("21543");
  TEST_ASSERT_BOOL(itr04 != map1.end());
  TEST_FEATURE_INT64(({6064093880274821167, 6063906087319495389}), itr04->second);

  vec.clear();
  XmlConfigMgr::parse_from_string(config_str3, "", "", vec);
  qinglong::BatchSequenceExample batch_ret3;

  toSequenceExample(&arena, request, vec, batch_ret3);

  TEST_ASSERT_EQUAL(1, batch_ret3.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret3.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret3.batch(0).has_feature_lists());

  const auto& map2 = batch_ret3.batch(0).context().feature();
  const auto& map02 = batch_ret3.batch(0).feature_lists().feature_list();

  auto itr05 = map02.find("10000");
  TEST_ASSERT_BOOL(itr05 != map02.end());
  TEST_FEATURE_LIST_INT64(({{3475054782246105695}, {3474905001855260777}, {3475069096352822867}, {3474987479483001764}}), itr05->second);

  auto itr06 = map02.find("6666");
  TEST_ASSERT_BOOL(itr06 != map02.end());
  TEST_FEATURE_LIST_INT64(({{1876558389506290271}, {1876408609115445353}, {1876572703613007443}, {1876491086743186340}}), itr06->second);

  auto itr07 = map2.find("f3");
  TEST_ASSERT_BOOL(itr07 != map2.end());
  TEST_FEATURE_INT64(({3475087044490207279, 3474899251534881501}), itr07->second);

  auto itr08 = map2.find("12345");
  TEST_ASSERT_BOOL(itr08 != map2.end());
  TEST_FEATURE_INT64(({3475087044490207279, 3474899251534881501}), itr08->second);

  vec.clear();
  XmlConfigMgr::parse_from_string(config_str4, "", "", vec);
  qinglong::BatchSequenceExample batch_ret4;

  toSequenceExample(&arena, request, vec, batch_ret4);

  TEST_ASSERT_EQUAL(1, batch_ret4.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret4.batch(0).has_feature_lists());

  const auto& map03 = batch_ret4.batch(0).feature_lists().feature_list();

  auto itr09 = map03.find("f1");
  TEST_ASSERT_BOOL(itr09 != map03.end());
  TEST_FEATURE_LIST_INT64(({{-35280223653281}, {-185060614498199}, {-20966116936109}, {-102582986757212}}), itr09->second);

  bool flag = false;
  vec.clear();

  std::string config_str5 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" />
        </features>
    </config>
    <hash_slot flag="true" />
  )";

  try {
    XmlConfigMgr::parse_from_string(config_str5, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  flag = false;
  vec.clear();

  std::string config_str6 = R"(
    <config>
        <features>
            <feature name="888888" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" />
        </features>
    </config>
    <hash_slot flag="true" />
  )";

  try {
    XmlConfigMgr::parse_from_string(config_str6, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  std::string config_str7 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" />
        </features>
    </config>
    <hash_slot flag="true">
      <group name="f1,f3" slot="ff5" />
    </hash_slot>
 )";

  flag = false;
  vec.clear();

  try {
    XmlConfigMgr::parse_from_string(config_str7, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  std::string config_str8 = R"(
    <config>
        <features>
            <feature name="f1" type="direct" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.num" strategy="hash" />
        </features>
    </config>
    <hash_slot flag="true">
      <group name="f1,f3" slot="666666" />
    </hash_slot>
 )";

  flag = false;
  vec.clear();

  try {
    XmlConfigMgr::parse_from_string(config_str8, "", "", vec);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);

  FUNC_TEST_END();
}

// 特殊字符处理
void test_utf8_prefix_repetition_string_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f3" type="utf8_prefix_repetition_string" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" cross="false" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f3" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre\n@!");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre =^*=");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("pre\n@\t6666");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("pre ");


  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f3");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_FLOAT(({{0.5}, {0.5}}), itr00->second);

 
  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f3");
  auto itr_len0 = map.find("f3_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_FLOAT(({0.5, 0.5}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);


  FUNC_TEST_END();
}

// 空字符串或传空，结果为0.0和空
void test_utf8_prefix_repetition_string_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f3" type="utf8_prefix_repetition_string" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" cross="false" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f3" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("");
  fate = feat_list.add_feature();


  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f3");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_FLOAT(({{0.0}, {}}), itr00->second);

 
  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f3");
  auto itr_len0 = map.find("f3_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_FLOAT(({0.0, 0.0}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);


  FUNC_TEST_END();
}

// 列表元素维度计算相似度，支持特殊字符，区分大小写
void test_repetition_list_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
            <config>
                <features>
                    <feature name="f11" type="repetition_list" source=".item_feature.item_feature_se.feature_lists.feature_list.query_word1,.item_feature.item_feature_se.feature_lists.feature_list.query_word2" strategy="empty" />
                    <feature name="f12" type="direct" source="f11" strategy="empty" />
    
              </features>
            </config>
        )";

  std::string in_str = R"(
        <model_input_config>
            <input name="f12" shape="1" type="dense" />
        </model_input_config>
      )";

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<Config>> vec;
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  std::vector<std::shared_ptr<Config>> need_vec;

  
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());

  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);



  RepetitionListConfig *conf =
      dynamic_cast<RepetitionListConfig *>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  tensorflow::SequenceExample *item =
      request.add_item_feature()->mutable_item_feature_se();
  auto &item_feature_list_map =
      *(item->mutable_feature_lists()->mutable_feature_list());
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("荣耀");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("@ =");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("天A");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("气");

  (item_feature_list_map["query_word2"].add_feature())
      ->mutable_bytes_list()
      ->add_value("天a");
  (item_feature_list_map["query_word2"].add_feature())
      ->mutable_bytes_list()
      ->add_value("气");
  (item_feature_list_map["query_word2"].add_feature())
      ->mutable_bytes_list()
      ->add_value("@ =");
  (item_feature_list_map["query_word2"].add_feature())
      ->mutable_bytes_list()
      ->add_value("荣");
  float expected_value =
      (1 * 1 + 1 * 1) / (std::sqrt((std::pow(1, 2) + std::pow(1, 2)) + std::pow(1, 2) + std::pow(1, 2)) * std::sqrt((std::pow(1, 2) + std::pow(1, 2)) + std::pow(1, 2) + std::pow(1, 2)));

  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto &map = ret.inputs();

  auto itr0 = map.find("f12");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_LIST_FLOAT(({expected_value}), itr0->second);

  FUNC_TEST_END();
}

// 传空字符串和传空
void test_repetition_list_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
            <config>
                <features>
                    <feature name="f11" type="repetition_list" source=".item_feature.item_feature_se.feature_lists.feature_list.query_word1,.item_feature.item_feature_se.feature_lists.feature_list.query_word2" strategy="empty" />
                    <feature name="f12" type="direct" source="f11" strategy="empty" />
    
              </features>
            </config>
        )";

  std::string in_str = R"(
        <model_input_config>
            <input name="f12" shape="1" type="dense" />
        </model_input_config>
      )";

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<Config>> vec;
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  std::vector<std::shared_ptr<Config>> need_vec;

  
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());

  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);



  RepetitionListConfig *conf =
      dynamic_cast<RepetitionListConfig *>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  tensorflow::SequenceExample *item =
      request.add_item_feature()->mutable_item_feature_se();
  auto &item_feature_list_map =
      *(item->mutable_feature_lists()->mutable_feature_list());
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("天A");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("气");

  item_feature_list_map["query_word2"];
  float expected_value =
      (1 * 1) / (std::sqrt((std::pow(1, 2) + std::pow(1, 2))) * std::sqrt((std::pow(1, 2) + std::pow(1, 2))));

  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto &map = ret.inputs();

  auto itr0 = map.find("f12");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_LIST_FLOAT(({0.0}), itr0->second);

  FUNC_TEST_END();
}

// 传空字符串,零相似
void test_repetition_list_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
            <config>
                <features>
                    <feature name="f11" type="repetition_list" source=".item_feature.item_feature_se.feature_lists.feature_list.query_word1,.item_feature.item_feature_se.feature_lists.feature_list.query_word2" strategy="empty" />
                    <feature name="f12" type="direct" source="f11" strategy="empty" />
    
              </features>
            </config>
        )";

  std::string in_str = R"(
        <model_input_config>
            <input name="f12" shape="1" type="dense" />
        </model_input_config>
      )";

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<Config>> vec;
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  std::vector<std::shared_ptr<Config>> need_vec;

  
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());

  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);



  RepetitionListConfig *conf =
      dynamic_cast<RepetitionListConfig *>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  tensorflow::SequenceExample *item =
      request.add_item_feature()->mutable_item_feature_se();
  auto &item_feature_list_map =
      *(item->mutable_feature_lists()->mutable_feature_list());
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("天A");
  (item_feature_list_map["query_word1"].add_feature())
      ->mutable_bytes_list()
      ->add_value("气");

  (item_feature_list_map["query_word2"].add_feature())
      ->mutable_bytes_list()
      ->add_value("天");
  float expected_value =
      (1 * 1) / (std::sqrt((std::pow(1, 2) + std::pow(1, 2))) * std::sqrt((std::pow(1, 2) + std::pow(1, 2))));

  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto &map = ret.inputs();

  auto itr0 = map.find("f12");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_LIST_FLOAT(({0.0}), itr0->second);

  FUNC_TEST_END();
}

// 传空字符串和特殊字符，传空值
void test_utf8_repetition_string_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_repetition_string" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8RepetitionStringConfig* config = dynamic_cast<Utf8RepetitionStringConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");
  pb_info->set_event_time(20);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("=@@ ");
  pb_info->set_event_time(30);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");
  pb_info->set_event_time(40);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value(" @");
  fate = feat_list.add_feature();


  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_FLOAT(({{0.0}, {0.866025}, {}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_FLOAT(({0.0, 0.866025, 0.0}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  FUNC_TEST_END();
}

// appid传空字符串和空格,use_duration传空值
void test_seq_filter_v3_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v3" source=".item_feature.item_feature_se.context.feature.appid,.item_feature.item_feature_se.context.feature.event_time,.request_time,E@.item_feature.item_feature_se.context.feature.use_duration" reverse="1" filter=", ,2, 3" />
            <feature name="f7" type="direct" source="f6:0" strategy="empty" />
            <feature name="f8" type="direct" source="f6:1" strategy="empty" />
            <feature name="f9" type="direct" source="f6:2" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV3Config* conf = dynamic_cast<SeqFilterV3Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"];

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value(" ");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(200);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value(" 3");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(300);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({""}), itr00->second);
  TEST_FEATURE_STR(({" ", " 3"}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({(int64_t)85 * 86400 * 1000}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)105 * 86400 * 1000, (int64_t)95 * 86400 * 1000}), itr11->second);

  auto itr02 = map00.find("f9");
  auto itr12 = map01.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_INT64(({}), itr02->second);
  TEST_FEATURE_INT64(({200, 300}), itr12->second);


  FUNC_TEST_END();
}

// event_time和appid传空值
void test_seq_filter_v3_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v3" source="E@.item_feature.item_feature_se.context.feature.appid,E@.item_feature.item_feature_se.context.feature.event_time,.request_time,E@.item_feature.item_feature_se.context.feature.use_duration" reverse="1" filter=", ,2, 3" />
            <feature name="f7" type="direct" source="f6:0" strategy="empty" />
            <feature name="f8" type="direct" source="f6:1" strategy="empty" />
            <feature name="f9" type="direct" source="f6:2" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV3Config* conf = dynamic_cast<SeqFilterV3Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"];
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"];

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value(" ");
  (*(item->mutable_context()->mutable_feature()))["event_time"];
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(200);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value(" 3");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(300);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({}), itr00->second);
  TEST_FEATURE_STR(({" "}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)95 * 86400 * 1000}), itr11->second);

  auto itr02 = map00.find("f9");
  auto itr12 = map01.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_INT64(({}), itr02->second);
  TEST_FEATURE_INT64(({200}), itr12->second);


  FUNC_TEST_END();
}

// 保留输入中不存在的值，结果会输出空值
void test_seq_filter_v3_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v3" source="E@.item_feature.item_feature_se.context.feature.appid,E@.item_feature.item_feature_se.context.feature.event_time,.request_time,E@.item_feature.item_feature_se.context.feature.use_duration" reverse="1" filter="3" />
            <feature name="f7" type="direct" source="f6:0" strategy="empty" />
            <feature name="f8" type="direct" source="f6:1" strategy="empty" />
            <feature name="f9" type="direct" source="f6:2" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV3Config* conf = dynamic_cast<SeqFilterV3Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("@！#");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"];

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("1");
  (*(item->mutable_context()->mutable_feature()))["event_time"];
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(200);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("3");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(300);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({}), itr00->second);
  TEST_FEATURE_STR(({}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({}), itr01->second);
  TEST_FEATURE_INT64(({}), itr11->second);

  auto itr02 = map00.find("f9");
  auto itr12 = map01.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_INT64(({}), itr02->second);
  TEST_FEATURE_INT64(({}), itr12->second);


  FUNC_TEST_END();
}

// start和end_day的边界值
void test_seq_filter_v3_z4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v3" source="E@.item_feature.item_feature_se.context.feature.appid,E@.item_feature.item_feature_se.context.feature.event_time,.request_time,E@.item_feature.item_feature_se.context.feature.use_duration" start="864000" day_n ="30" reverse="1" filter="1,2" />
            <feature name="f7" type="direct" source="f6:0" strategy="empty" />
            <feature name="f8" type="direct" source="f6:1" strategy="empty" />
            <feature name="f9" type="direct" source="f6:2" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV3Config* conf = dynamic_cast<SeqFilterV3Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("1");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)(110 * 86400 * 1000 - 864000));
  (*(item->mutable_context()->mutable_feature()))["use_duration"];

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("2");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)(110 * 86400 * 1000 - 30 * 86400));
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(200);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("3");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(300);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({}), itr00->second);
  TEST_FEATURE_STR(({}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({}), itr01->second);
  TEST_FEATURE_INT64(({}), itr11->second);

  auto itr02 = map00.find("f9");
  auto itr12 = map01.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_INT64(({}), itr02->second);
  TEST_FEATURE_INT64(({}), itr12->second);


  FUNC_TEST_END();
}

// 使用end_ms和start_ms过滤时间，输入存在空字符串
void test_message_filter_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq,.request_time" str_filter="query,hit,appid1,appid3;event_type,hit,001," int_filter="pay_money,hit,100,200,300" eventtime_key="event_time" end_ms="2592000000" start_ms="864000000" />
            <feature name="f7" type="direct" source="f6.pay_money" />
            <feature name="f8" type="direct" source="f6.query" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterConfig* conf = dynamic_cast<MessageFilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  
  //pay_money过滤
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(10);
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);

  //query过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(20);
  pb_info->set_event_time((int64_t)85 * 86400 * 1000);

  //时间范围过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(30);
  pb_info->set_event_time((int64_t)60 * 86400 * 1000);

  //防穿越过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(40);
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);

  //event_type过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("003");
  pb_info->set_pay_money(50);
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(200);
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_event_type("");
  pb_info->set_pay_money(100);
  pb_info->set_event_time((int64_t)85 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{200}, {100}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid3"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({200, 100}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"appid1", "appid3"}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  FUNC_TEST_END();
}

// 过滤的备选值中提供空字符串和空值
void test_message_filter_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq,.request_time" str_filter="query,hit,,appid3;event_type,miss,001," int_filter="pay_money,hit,100,200,300" eventtime_key="event_time" end_ms="2592000000" start_ms="864000000" />
            <feature name="f7" type="direct" source="f6.pay_money" />
            <feature name="f8" type="direct" source="f6.query" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterConfig* conf = dynamic_cast<MessageFilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  
  //pay_money过滤
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(10);
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);

  //query过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(20);
  pb_info->set_event_time((int64_t)85 * 86400 * 1000);

  //时间范围过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(30);
  pb_info->set_event_time((int64_t)60 * 86400 * 1000);

  //防穿越过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(40);
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);

  //event_type过滤
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("003");
  pb_info->set_pay_money(50);
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("");
  pb_info->set_event_type("002");
  pb_info->set_pay_money(200);
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_event_type("");
  pb_info->set_pay_money(100);
  pb_info->set_event_time((int64_t)85 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{200}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{""}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({200}), itr0->second);
  TEST_LIST_INT32(({1}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({""}), itr1->second);
  TEST_LIST_INT32(({1}), itr_len1->second);

  FUNC_TEST_END();
}
// 使用两次算子，第一次结果为空，输出为空
void test_message_filter_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f5" type="message_filter" source=".user_feature.ad_context_feature.info_flow_context.info_flow_item" str_filter="label,miss,200;tip,hit,1,2,3" />
            <feature name="f6" type="message_filter" source="f5.filter_words" str_filter="id,hit,0,1,2" strategy="empty" />
            <feature name="f7" type="direct" source="f6.id" strategy="empty" />
            <feature name="f8" type="direct" source="f6.name" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterConfig* conf = dynamic_cast<MessageFilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::InfoFlowContext* pb_info = pb_ufv2->mutable_ad_context_feature()->mutable_info_flow_context();
  qinglong::InfoFlowItem* pb_item = pb_info->add_info_flow_item();

  //label过滤
  pb_item->set_label("200");
  pb_item->set_tip("1");

  qinglong::FilterWords* pb_word = pb_item->add_filter_words();
  pb_word->set_id("0");
  pb_word->set_name("appid0");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("1");
  pb_word->set_name("appid1");

  //tip过滤
  pb_item = pb_info->add_info_flow_item();
  pb_item->set_label("100");
  pb_item->set_tip("0");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("0");
  pb_word->set_name("appid2");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("1");
  pb_word->set_name("appid3");

  pb_item = pb_info->add_info_flow_item();
  pb_item->set_label("100");
  pb_item->set_tip("4");

  //id过滤
  pb_word = pb_item->add_filter_words();
  pb_word->set_id("3");
  pb_word->set_name("appid4");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("1");
  pb_word->set_name("appid5");
  
  pb_item = pb_info->add_info_flow_item();
  pb_item->set_label("100");
  pb_item->set_tip("5");

  //id过滤
  pb_word = pb_item->add_filter_words();
  pb_word->set_id("6");
  pb_word->set_name("appid6");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("2");
  pb_word->set_name("appid7");

  pb_word = pb_item->add_filter_words();
  pb_word->set_id("0");
  pb_word->set_name("appid8");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({}), itr0->second);
  TEST_LIST_INT32(({0}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({}), itr1->second);
  TEST_LIST_INT32(({0}), itr_len1->second);

  FUNC_TEST_END();
}
// 输入为空，输出为空
void test_utf8_split_to_list_z1() {
  FUNC_TEST_START();
  std::string xml_fe_config = R"(
    <config>
        <features>
            <feature name="f13" type="utf8_split_to_list" source="E@.item_feature.item_feature_se.context.feature.pkg" sep="." filters="com," strategy="empty" />
        </features>
    </config>
    )";

  std::string in_str = R"(
        <model_input_config>
            <input name="f13" shape="0" type="dense" />
        </model_input_config>
      )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(xml_fe_config, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8SplitToListConfig *config =
      dynamic_cast<Utf8SplitToListConfig *>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample *item =
      request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["pkg"];

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto &map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto &map = ret.inputs();
  auto itr0 = map.find("f13");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_LIST_STRING(({}), itr0->second);

  FUNC_TEST_END();
}

// 输入包含空字符串，输出为空
void test_utf8_split_to_list_z2() {
  FUNC_TEST_START();
  std::string xml_fe_config = R"(
    <config>
        <features>
            <feature name="f13" type="utf8_split_to_list" source="E@.item_feature.item_feature_se.context.feature.pkg" sep="." filters="com@," strategy="empty" />
        </features>
    </config>
    )";

  std::string in_str = R"(
        <model_input_config>
            <input name="f13" shape="1" type="dense" />
        </model_input_config>
      )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(xml_fe_config, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8SplitToListConfig *config =
      dynamic_cast<Utf8SplitToListConfig *>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample *item =
      request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["pkg"].mutable_bytes_list()->add_value("coM@..galLery");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto &map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"gallery"}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto &map = ret.inputs();
  auto itr0 = map.find("f13");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_LIST_STRING(({"gallery"}), itr0->second);

  FUNC_TEST_END();
}

// 输入为空，输出为空
void test_utf8_ip_to_list_z1() {
  FUNC_TEST_START();
    std::string xml_fe_config = R"(
        <config>
            <features>
                <feature name="f13" type="utf8_ip_to_list" source="E@.item_feature.item_feature_se.context.feature.pkg" sep="." strategy="empty" />
            </features>
        </config>
        )";
    
      std::string in_str = R"(
            <model_input_config>
                <input name="f13" shape="0" type="dense" />
            </model_input_config>
          )";
    
      std::vector<std::shared_ptr<Config>> vec;
      XmlConfigMgr::parse_from_string(xml_fe_config, "", "", vec);
    
      TEST_ASSERT_EQUAL(1, vec.size());
      Utf8IpToListConfig *config =
          dynamic_cast<Utf8IpToListConfig *>(vec[0].get());
      TEST_ASSERT_BOOL(nullptr != config);
    
      std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
      ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
    
      TEST_ASSERT_EQUAL(1, in_vec.size());
      TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
    
      google::protobuf::Arena arena;
      qinglong::FeRequest request;
      qinglong::BatchSequenceExample batch_ret;
      qinglong::PredictRequest ret;
    
      // item
      tensorflow::SequenceExample *item =
          request.add_item_feature()->mutable_item_feature_se();
      (*(item->mutable_context()->mutable_feature()))["pkg"];
    
      toSequenceExample(&arena, request, vec, batch_ret);
      TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
      TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
      const auto &map00 = batch_ret.batch(0).context().feature();
      auto itr00 = map00.find("f13");
    
      TEST_ASSERT_BOOL(itr00 != map00.end());
      TEST_FEATURE_STR(({}), itr00->second);
    
      std::vector<std::shared_ptr<Config>> need_vec;
      selectConfigUsingModelInput(vec, in_vec, need_vec);
      toPredictRequest(&arena, request, need_vec, in_vec, ret);
    
      auto &map = ret.inputs();
      auto itr0 = map.find("f13");
      TEST_ASSERT_BOOL(itr0 != map.end());
      TEST_LIST_STRING(({}), itr0->second);
      FUNC_TEST_END();
}

// 输入包含空字符串和特殊字符
void test_utf8_ip_to_list_z2() {
  FUNC_TEST_START();
    std::string xml_fe_config = R"(
        <config>
            <features>
                <feature name="f13" type="utf8_ip_to_list" source="E@.item_feature.item_feature_se.context.feature.pkg" sep="." strategy="empty" />
            </features>
        </config>
        )";
    
      std::string in_str = R"(
            <model_input_config>
                <input name="f13" shape="2" type="dense" />
            </model_input_config>
          )";
    
      std::vector<std::shared_ptr<Config>> vec;
      XmlConfigMgr::parse_from_string(xml_fe_config, "", "", vec);
    
      TEST_ASSERT_EQUAL(1, vec.size());
      Utf8IpToListConfig *config =
          dynamic_cast<Utf8IpToListConfig *>(vec[0].get());
      TEST_ASSERT_BOOL(nullptr != config);
    
      std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
      ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
    
      TEST_ASSERT_EQUAL(1, in_vec.size());
      TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
    
      google::protobuf::Arena arena;
      qinglong::FeRequest request;
      qinglong::BatchSequenceExample batch_ret;
      qinglong::PredictRequest ret;
    
      // item
      tensorflow::SequenceExample *item =
          request.add_item_feature()->mutable_item_feature_se();
      (*(item->mutable_context()->mutable_feature()))["pkg"].mutable_bytes_list()->add_value("com..@!好gallery");
    
      toSequenceExample(&arena, request, vec, batch_ret);
      TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
      TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
      const auto &map00 = batch_ret.batch(0).context().feature();
      auto itr00 = map00.find("f13");
    
      TEST_ASSERT_BOOL(itr00 != map00.end());
      TEST_FEATURE_STR(({"com.", "com..@!好gallery"}), itr00->second);
    
      std::vector<std::shared_ptr<Config>> need_vec;
      selectConfigUsingModelInput(vec, in_vec, need_vec);
      toPredictRequest(&arena, request, need_vec, in_vec, ret);
    
      auto &map = ret.inputs();
      auto itr0 = map.find("f13");
      TEST_ASSERT_BOOL(itr0 != map.end());
      TEST_LIST_STRING(({"com.", "com..@!好gallery"}), itr0->second);
      FUNC_TEST_END();
}

// 输入只包含一个分割符
void test_utf8_ip_to_list_z3() {
  FUNC_TEST_START();
    std::string xml_fe_config = R"(
        <config>
            <features>
                <feature name="f13" type="utf8_ip_to_list" source="E@.item_feature.item_feature_se.context.feature.pkg" sep="." strategy="empty" />
            </features>
        </config>
        )";
    
      std::string in_str = R"(
            <model_input_config>
                <input name="f13" shape="1" type="dense" />
            </model_input_config>
          )";
    
      std::vector<std::shared_ptr<Config>> vec;
      XmlConfigMgr::parse_from_string(xml_fe_config, "", "", vec);
    
      TEST_ASSERT_EQUAL(1, vec.size());
      Utf8IpToListConfig *config =
          dynamic_cast<Utf8IpToListConfig *>(vec[0].get());
      TEST_ASSERT_BOOL(nullptr != config);
    
      std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
      ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
    
      TEST_ASSERT_EQUAL(1, in_vec.size());
      TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
    
      google::protobuf::Arena arena;
      qinglong::FeRequest request;
      qinglong::BatchSequenceExample batch_ret;
      qinglong::PredictRequest ret;
    
      // item
      tensorflow::SequenceExample *item =
          request.add_item_feature()->mutable_item_feature_se();
      (*(item->mutable_context()->mutable_feature()))["pkg"].mutable_bytes_list()->add_value("com.");
    
      toSequenceExample(&arena, request, vec, batch_ret);
      TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
      TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
      const auto &map00 = batch_ret.batch(0).context().feature();
      auto itr00 = map00.find("f13");
    
      TEST_ASSERT_BOOL(itr00 != map00.end());
      TEST_FEATURE_STR(({"com."}), itr00->second);
    
      std::vector<std::shared_ptr<Config>> need_vec;
      selectConfigUsingModelInput(vec, in_vec, need_vec);
      toPredictRequest(&arena, request, need_vec, in_vec, ret);
    
      auto &map = ret.inputs();
      auto itr0 = map.find("f13");
      TEST_ASSERT_BOOL(itr0 != map.end());
      TEST_LIST_STRING(({"com."}), itr0->second);
      FUNC_TEST_END();
}

// default_value未设置使用默认值
void test_seq_avg_interval_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f5" type="seq_avg_interval" source="E@.item_feature.item_feature_se.context.feature.first" time_type="1" />
            <feature name="f6" type="seq_avg_interval" source="E@.item_feature.item_feature_se.context.feature.first" time_type="2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqAvgIntervalConfig* conf = dynamic_cast<SeqAvgIntervalConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)75 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)77 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)83 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)86 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)86 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(3, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(2).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();
  const auto& map02 = batch_ret.batch(2).context().feature();

  auto itr00 = map00.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_FLOAT(({2.7500}), itr00->second);

  auto itr10 = map00.find("f6");
  TEST_ASSERT_BOOL(itr10 != map00.end());
  TEST_FEATURE_FLOAT(({66.0000}), itr10->second);

  auto itr01 = map01.find("f5");
  TEST_ASSERT_BOOL(itr01 != map01.end());
  TEST_FEATURE_FLOAT(({0}), itr01->second);

  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_FLOAT(({0}), itr11->second);

  auto itr02 = map02.find("f5");
  TEST_ASSERT_BOOL(itr02 != map02.end());
  TEST_FEATURE_FLOAT(({-1}), itr02->second);

  auto itr12 = map02.find("f6");
  TEST_ASSERT_BOOL(itr12 != map02.end());
  TEST_FEATURE_FLOAT(({-1}), itr12->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0, 2, 0}), ({3, 1}), ({2.7500, 0, -1}),
                           itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0, 2, 0}), ({3, 1}), ({66.0000, 0, -1}),
                           itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

// 输入数据中有重复的数据
void test_seq_avg_interval_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f5" type="seq_avg_interval" source="E@.item_feature.item_feature_se.context.feature.first" time_type="1" />
            <feature name="f6" type="seq_avg_interval" source="E@.item_feature.item_feature_se.context.feature.first" time_type="2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqAvgIntervalConfig* conf = dynamic_cast<SeqAvgIntervalConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)75 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)75 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)80 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)80 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)83 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)86 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(3, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(2).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();
  const auto& map02 = batch_ret.batch(2).context().feature();

  auto itr00 = map00.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_FLOAT(({2.0000}), itr00->second);

  auto itr10 = map00.find("f6");
  TEST_ASSERT_BOOL(itr10 != map00.end());
  TEST_FEATURE_FLOAT(({48.0000}), itr10->second);

  auto itr01 = map01.find("f5");
  TEST_ASSERT_BOOL(itr01 != map01.end());
  TEST_FEATURE_FLOAT(({0}), itr01->second);

  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_FLOAT(({0}), itr11->second);

  auto itr02 = map02.find("f5");
  TEST_ASSERT_BOOL(itr02 != map02.end());
  TEST_FEATURE_FLOAT(({-1}), itr02->second);

  auto itr12 = map02.find("f6");
  TEST_ASSERT_BOOL(itr12 != map02.end());
  TEST_FEATURE_FLOAT(({-1}), itr12->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0, 2, 0}), ({3, 1}), ({2.0000, 0, -1}),
                           itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0, 2, 0}), ({3, 1}), ({48.0000, 0, -1}),
                           itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

// 输入数据中全部为0
void test_seq_avg_interval_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f5" type="seq_avg_interval" source="E@.item_feature.item_feature_se.context.feature.first" time_type="1" />
            <feature name="f6" type="seq_avg_interval" source="E@.item_feature.item_feature_se.context.feature.first" time_type="2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqAvgIntervalConfig* conf = dynamic_cast<SeqAvgIntervalConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)86 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(3, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(2).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();
  const auto& map02 = batch_ret.batch(2).context().feature();

  auto itr00 = map00.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_FLOAT(({0}), itr00->second);

  auto itr10 = map00.find("f6");
  TEST_ASSERT_BOOL(itr10 != map00.end());
  TEST_FEATURE_FLOAT(({0}), itr10->second);

  auto itr01 = map01.find("f5");
  TEST_ASSERT_BOOL(itr01 != map01.end());
  TEST_FEATURE_FLOAT(({0}), itr01->second);

  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_FLOAT(({0}), itr11->second);

  auto itr02 = map02.find("f5");
  TEST_ASSERT_BOOL(itr02 != map02.end());
  TEST_FEATURE_FLOAT(({-1}), itr02->second);

  auto itr12 = map02.find("f6");
  TEST_ASSERT_BOOL(itr12 != map02.end());
  TEST_FEATURE_FLOAT(({-1}), itr12->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0, 2, 0}), ({3, 1}), ({0, 0, -1}),
                           itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0, 2, 0}), ({3, 1}), ({0, 0, -1}),
                           itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

// 序列为空或包含空字符串
void test_len_diff_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="len_diff" source="E@.item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.query" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  LenDiffConfig* config = dynamic_cast<LenDiffConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("2");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app5");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app3");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app5");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app1");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({2}), itr00->second);
  TEST_FEATURE_INT64(({-3}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0,}), ({2, 1}), ({2, -3}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

// 两个序列的数据类型不同
void test_len_diff_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="len_diff" source="E@.item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.query" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  LenDiffConfig* config = dynamic_cast<LenDiffConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_int64_list()->add_value(1);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_int64_list()->add_value(2);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_int64_list()->add_value(3);
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app5");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_int64_list()->add_value(4);
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app3");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app5");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app1");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_INT64(({2}), itr00->second);
  TEST_FEATURE_INT64(({-2}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0,}), ({2, 1}), ({2, -2}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

// default_value不设置默认为-1
void test_len_ratio_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="len_ratio" source=".item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.query" ratio_type="1" />
            <feature name="f16" type="len_ratio" source=".item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.query" ratio_type="2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
        <input name="f16" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  LenRatioConfig* config = dynamic_cast<LenRatioConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app2");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app3");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app5");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app5");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_FLOAT(({2}), itr00->second);
  TEST_FEATURE_FLOAT(({2}), itr10->second);

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_FLOAT(({3}), itr01->second);
  TEST_FEATURE_FLOAT(({-1}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0,}), ({2, 1}), ({2, 2}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f16_values");
  auto itr_indices1 = map.find("f16_indices");
  auto itr_dense_shape1 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0,}), ({2, 1}), ({3, -1}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

// 两个序列的类型不同
void test_len_ratio_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="len_ratio" source=".item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.query" ratio_type="1" />
            <feature name="f16" type="len_ratio" source=".item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.query" ratio_type="2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
        <input name="f16" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  LenRatioConfig* config = dynamic_cast<LenRatioConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_int64_list()->add_value(1);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_int64_list()->add_value(2);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_int64_list()->add_value(3);
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app5");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_int64_list()->add_value(4);

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_FLOAT(({2}), itr00->second);
  TEST_FEATURE_FLOAT(({2}), itr10->second);

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_FLOAT(({3}), itr01->second);
  TEST_FEATURE_FLOAT(({-1}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0,}), ({2, 1}), ({2, 2}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f16_values");
  auto itr_indices1 = map.find("f16_indices");
  auto itr_dense_shape1 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0,}), ({2, 1}), ({3, -1}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

// 输入数据为空或包含空字符串
void test_len_ratio_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="len_ratio" source="E@.item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.query" ratio_type="1" />
            <feature name="f16" type="len_ratio" source="E@.item_feature.item_feature_se.context.feature.app_id,E@.item_feature.item_feature_se.context.feature.query" ratio_type="2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
        <input name="f16" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  LenRatioConfig* config = dynamic_cast<LenRatioConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("app1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("app5");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"];

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_FLOAT(({2}), itr00->second);
  TEST_FEATURE_FLOAT(({1}), itr10->second);

  auto itr01 = map00.find("f16");
  auto itr11 = map01.find("f16");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_FLOAT(({3}), itr01->second);
  TEST_FEATURE_FLOAT(({-1}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0,}), ({2, 1}), ({2, 1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f16_values");
  auto itr_indices1 = map.find("f16_indices");
  auto itr_dense_shape1 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0,}), ({2, 1}), ({3, -1}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

// 空字符串匹配
void test_message_filter_v2_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter_v2" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq,.item_feature.item_feature_se.context.feature.query,.item_feature.item_feature_se.context.feature.event_type,.item_feature.item_feature_se.context.feature.pay_money" filter="str,query,hit;str,event_type,miss;int,pay_money,hit" />
            <feature name="f7" type="direct" source="f6.pay_money" />
            <feature name="f8" type="direct" source="f6.query" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterV2Config* conf = dynamic_cast<MessageFilterV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(10);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(20);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("003");
  pb_info->set_pay_money(50);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("");
  pb_info->set_event_type("");
  pb_info->set_pay_money(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("");
  pb_info->set_event_type("002");
  pb_info->set_pay_money(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(100);

  // 筛选上面输入中query、pay_money命中，eventType不命中的pay_money和query
  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* sq = item->mutable_item_feature_se();
  tensorflow::Features* fs = sq->mutable_context();
  auto& input_map = *fs->mutable_feature();
  tensorflow::Feature& input_q = input_map["query"];
  input_q.mutable_bytes_list()->add_value("");
  tensorflow::Feature& input_t = input_map["event_type"];
  input_t.mutable_bytes_list()->add_value("001");
  tensorflow::Feature& input_p = input_map["pay_money"];
  input_p.mutable_int64_list()->add_value(100);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{100}, {100}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{""}, {""}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({100, 100}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"", ""}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  FUNC_TEST_END();
}

// 输入均未命中条件，输出空
void test_message_filter_v2_z2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter_v2" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq,.item_feature.item_feature_se.context.feature.query,.item_feature.item_feature_se.context.feature.event_type,.item_feature.item_feature_se.context.feature.pay_money" filter="str,query,hit;str,event_type,miss;int,pay_money,hit" />
            <feature name="f7" type="direct" source="f6.pay_money" strategy="empty" />
            <feature name="f8" type="direct" source="f6.query" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterV2Config* conf = dynamic_cast<MessageFilterV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(10);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(20);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("003");
  pb_info->set_pay_money(50);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("");
  pb_info->set_event_type("002");
  pb_info->set_pay_money(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(100);

  // 筛选上面输入中query、pay_money命中，eventType不命中的pay_money和query
  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* sq = item->mutable_item_feature_se();
  tensorflow::Features* fs = sq->mutable_context();
  auto& input_map = *fs->mutable_feature();
  tensorflow::Feature& input_q = input_map["query"];
  input_q.mutable_bytes_list()->add_value("");
  tensorflow::Feature& input_t = input_map["event_type"];
  input_t.mutable_bytes_list()->add_value("001");
  tensorflow::Feature& input_p = input_map["pay_money"];
  input_p.mutable_int64_list()->add_value(100);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({}), itr0->second);
  TEST_LIST_INT32(({0}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({}), itr1->second);
  TEST_LIST_INT32(({0}), itr_len1->second);

  FUNC_TEST_END();
}

// 输出与过滤条件使用不同的message
void test_message_filter_v2_z3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_filter_v2" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq,.item_feature.item_feature_se.context.feature.query,.item_feature.item_feature_se.context.feature.event_type,.item_feature.item_feature_se.context.feature.pay_money" filter="str,query,hit;str,event_type,miss;int,pay_money,hit" />
            <feature name="f7" type="direct" source="f6.ad_group_id" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageFilterV2Config* conf = dynamic_cast<MessageFilterV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(100);
  pb_info->set_ad_group_id("10");

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("");
  pb_info->set_event_type("002");
  pb_info->set_pay_money(100);
  pb_info->set_ad_group_id("20");

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("001");
  pb_info->set_pay_money(100);
  pb_info->set_ad_group_id("30");

  // 筛选上面输入中query、pay_money命中，eventType不命中的pay_money和query
  qinglong::ItemFeature* item = request.add_item_feature();
  tensorflow::SequenceExample* sq = item->mutable_item_feature_se();
  tensorflow::Features* fs = sq->mutable_context();
  auto& input_map = *fs->mutable_feature();
  tensorflow::Feature& input_q = input_map["query"];
  input_q.mutable_bytes_list()->add_value("");
  tensorflow::Feature& input_t = input_map["event_type"];
  input_t.mutable_bytes_list()->add_value("001");
  tensorflow::Feature& input_p = input_map["pay_money"];
  input_p.mutable_int64_list()->add_value(100);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"20"}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"20"}), itr0->second);
  TEST_LIST_INT32(({1}), itr_len0->second);

  FUNC_TEST_END();
}

// 使用除1,2外的其他数字
void test_message_filter_select_z1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="message_select" source=".user_action,.user_action.download_start" select_option="int;6,item_id;4,conv_ascribe_type" />
            <feature name="f7" type="message_select" source=".user_action,.user_action.media_id" select_option="str;-1,item_id;0,conv_ascribe_type" />
            <feature name="f8" type="direct" source="f6.sdk_conversion.flag" />
            <feature name="f9" type="direct" source="f7.item_id" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  MessageSelectConfig<int64_t>* conf = dynamic_cast<MessageSelectConfig<int64_t>*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserAction* pb_action = request.add_user_action();
  pb_action->set_download_start(4);
  pb_action->set_media_id("-1");
  qinglong::ConvInfo* pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  qinglong::ItemId* item = pb_action->mutable_item_id();
  item->set_item_id("10");
  pb_info->set_flag(2);


  //不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{2}}), itr00->second);

  auto itr01 = map00.find("f9");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"10"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f8");
  auto itr_len0 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({2}), itr0->second);  
  TEST_LIST_INT32(({1}), itr_len0->second);

  auto itr1 = map.find("f9");
  auto itr_len1 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"10"}), itr1->second);
  TEST_LIST_INT32(({1}), itr_len1->second);

  FUNC_TEST_END();
}

void test_plus(){
    // test_utf8_coincide_z1();
    // test_utf8_coincide_z2();
    // test_utf8_coincide_z3();
    // test_utf8_coincide_z4();
    // test_segment_z1();
    // test_cross_by_grams_seg_z1();
    // test_cross_by_grams_seg_z2();
    // test_cross_by_grams_seg_z3();
    // test_cross_by_grams_seg_z4();
    // test_cross_by_grams_seg_z5();
    // test_cross_by_grams_seg_z6();
    // test_cross_by_grams_seg_z7();
    // test_cross_by_grams_seg_z8();
    // test_cross_by_grams_seg_z9();
    // test_cross_by_grams_seg_z10();
    // test_vocab_set_z1();
    // test_vocab_set_z2();
    // test_seq_by_inter_z1();
    // test_seq_topn_direct_z1();
    // test_seq_topn_direct_z2();
    // test_seq_topn_direct_z3();
    // test_seq_topn_direct_z4();
    // test_seq_topn_direct_z5();
    // test_seq_topn_direct_z6();
    // test_seq_topn_direct_z7();
    // test_dict_to_attributes_z1();
    // test_dict_to_attributes_z2();
    // test_dict_to_attributes_z3();
    // test_dict_to_attributes_z4();
    // test_dict_to_attributes_z5();
    // test_connect_z1();
    // test_connect_z2();
    // test_connect_z3();
    // test_connect_z4();
    // test_connect_z5();
    // test_connect_z6();
    // test_connect_z7();
    // test_connect_z8();
    // test_get_valid_value_v2_z1();
    // test_get_valid_value_v2_z2();
    // test_get_valid_value_v2_z3();
    // test_connect_all_to_string_z1();
    // test_connect_all_to_string_z2();
    // test_connect_all_to_string_z3();
    // test_act_value_z1();
    // test_conditional_filter_z1();
    // test_seq_n_hour_z1();
    // test_seq_n_hour_z2();
    // test_seq_merge_z1();
    
    // // 第九批算子
    // test_utf8_get_re_result_z1();
    // test_utf8_get_prefix_z1();
    // test_is_match_str_z1();
    // test_seq_day_n_direct_z1();
    // test_seq_day_n_direct_z2();
    // test_seq_day_n_direct_z3();
    // test_seq_day_n_direct_z4();

    // // 第十批算子
    // test_seq_filter_v2_z1();
    // test_seq_filter_v2_z2();
    // test_seq_interval_z1();
    // test_seq_interval_z2();
    // test_seq_interval_z3();
    // test_seq_merge_v2_z1();
    // test_seq_merge_v2_z2();
    // test_seq_diff_v2_z1();
    // test_seq_diff_v2_z2();
    // test_seq_diff_v2_z3();

    // // 第十一批算子
    // test_seq_max_value_z1();
    // test_seq_max_value_z2();
    // test_seq_max_value_z3();

    // // 第十二批算子
    // test_dict_to_attributes_v2_z1();

    // // 特征hash升级
    // test_hash_slot_z1();

    // // 第十二批算子-第二部分
    // test_utf8_prefix_repetition_string_z1();
    // test_utf8_prefix_repetition_string_z2();
    // test_repetition_list_z1();
    // test_repetition_list_z2();
    // test_repetition_list_z3();
    // test_utf8_repetition_string_z1();

    // // 第十三批算子
    // test_seq_filter_v3_z1();
    // test_seq_filter_v3_z2();
    // test_seq_filter_v3_z3();
    // test_seq_filter_v3_z4();

    // // 第十四批算子
    // test_message_filter_z1();
    // test_message_filter_z2();
    // test_message_filter_z3();
    // test_utf8_split_to_list_z1();
    // test_utf8_split_to_list_z2();
    // test_utf8_ip_to_list_z1();
    // test_utf8_ip_to_list_z2();
    // test_utf8_ip_to_list_z3();

    // // 第十五批算子-第一部分
    // test_seq_avg_interval_z1();
    // test_seq_avg_interval_z2();
    // test_seq_avg_interval_z3();
    // test_len_diff_z1();
    // test_len_diff_z2();
    // test_len_ratio_z1();
    // test_len_ratio_z2();
    // test_len_ratio_z3();

    // 第十六批算子
    test_message_filter_v2_z1();
    test_message_filter_v2_z2();
    test_message_filter_v2_z3();
    test_message_filter_select_z1();
}