#include "phx-fe/src/service.h"
#include "phx-fe/util/murmur_hash3.h"
#include "phx_test.h"
#include <fstream>
#include <iostream>
TEST_SUITE("seq_1") {
    TEST_CASE("seq_cross_hash_bits_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_cross_hash_bits" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time" clip_size="3" />
                    <feature name="10813" slot="10813" type="seq_cross_hash_bits" source=".fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 11 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 11 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 9 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86401 * 1000);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);
        std::vector<int64_t> hash_10812;
        int64_t hash_ret_1;
        int64_t hash_ret_2;

        murmur_hash(104435568, hash_ret_1);
        murmur_hash(5 * 86400 * 1000, hash_ret_2);
        hash_10812.emplace_back(hash_ret_1 ^ hash_ret_2);

        murmur_hash(104436666, hash_ret_1);
        murmur_hash(11 * 86400 * 1000, hash_ret_2);
        hash_10812.emplace_back(hash_ret_1 ^ hash_ret_2);

        murmur_hash(900778570, hash_ret_1);
        murmur_hash(9 * 86404 * 1000, hash_ret_2);
        hash_10812.emplace_back(hash_ret_1 ^ hash_ret_2);

        TEST_SLOT_FEATURE_INT64(10812, (hash_10812), ret.training_samples(0).features(0));

        std::vector<int64_t> hash_10813;
        murmur_hash(104435568, hash_ret_1);
        murmur_hash(5 * 86400 * 1000, hash_ret_2);
        hash_10813.emplace_back(hash_ret_1 ^ hash_ret_2);

        murmur_hash(104435568, hash_ret_1);
        murmur_hash(11 * 86400 * 1000, hash_ret_2);
        hash_10813.emplace_back(hash_ret_1 ^ hash_ret_2);

        murmur_hash(900778570, hash_ret_1);
        murmur_hash(9 * 86400 * 1000, hash_ret_2);
        hash_10813.emplace_back(hash_ret_1 ^ hash_ret_2);

        murmur_hash(104436777, hash_ret_1);
        murmur_hash(10 * 86400 * 1000, hash_ret_2);
        hash_10813.emplace_back(hash_ret_1 ^ hash_ret_2);

        murmur_hash(900778570, hash_ret_1);
        murmur_hash(7 * 86400 * 1000, hash_ret_2);
        hash_10813.emplace_back(hash_ret_1 ^ hash_ret_2);

        murmur_hash(900778570, hash_ret_1);
        murmur_hash(7 * 86400 * 1000, hash_ret_2);
        hash_10813.emplace_back(hash_ret_1 ^ hash_ret_2);
        TEST_SLOT_FEATURE_INT64(10813, (hash_10813), ret.training_samples(0).features(1));
    }

    TEST_CASE("seq_cross_hash_bits_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_cross_hash_bits" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.download_success_ratio" clip_size="3" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest *fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // item 不为空
        fe_request->add_item_fea();
        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request->SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        // seq_cross_hash_bits算子不支持float类型，抛出异常，使用doctest框架捕获
        CHECK_THROWS_AS(to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                              user_action_str.size(), config_handle),
                        std::runtime_error);
    }

    TEST_CASE("seq_hit_list_1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_hit_list"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 1 * 3600 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 2 * 3600 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 5 * 3600 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 6 * 3600 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10001}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 2 * 3600 * 1000, (int64_t) 6 * 3600 * 1000}),
                                ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10002}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 5 * 3600 * 1000}), ret.training_samples(1).features(1));
    }

    TEST_CASE("seq_hit_list_2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_hit_list"
                        source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.app_id,.fe_request.item_fea.item_info.appid,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.request_id"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserConvInfo *ad_conv_info =
                fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10000);
        ad_conv_info->set_request_id("游戏中心0");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10001);
        ad_conv_info->set_request_id("应用市场1");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10000);
        ad_conv_info->set_request_id("游戏中心2");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10002);
        ad_conv_info->set_request_id("游戏中心3");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10001);
        ad_conv_info->set_request_id("应用市场4");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10002);
        ad_conv_info->set_request_id("游戏中心5");

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10002, 10002}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10813, ({"游戏中心3", "游戏中心5"}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10001}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_STR(10813, ({"应用市场1", "应用市场4"}), ret.training_samples(1).features(1));
    }

    TEST_CASE("seq_hit_list_3") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_hit_list"
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.bid"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_creative_id(10002);
        item_fea->mutable_item_info()->set_bid(21);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_creative_id(10002);
        item_fea->mutable_item_info()->set_bid(32);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea->mutable_item_info()->set_creative_id(10002);
        item_fea->mutable_item_info()->set_bid(25);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_creative_id(10000);
        item_fea->mutable_item_info()->set_bid(54);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_creative_id(10000);
        item_fea->mutable_item_info()->set_bid(28);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea->mutable_item_info()->set_creative_id(10000);
        item_fea->mutable_item_info()->set_bid(17);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_creative_id(10001);
        item_fea->mutable_item_info()->set_bid(72);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_creative_id(10001);
        item_fea->mutable_item_info()->set_bid(15);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea->mutable_item_info()->set_creative_id(10001);
        item_fea->mutable_item_info()->set_bid(43);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 9);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10002}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({25}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({54}), ret.training_samples(3).features(1));

        CHECK_EQ(ret.training_samples(4).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(4).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(4).features(1));

        CHECK_EQ(ret.training_samples(5).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(5).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(5).features(1));

        CHECK_EQ(ret.training_samples(6).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(6).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(6).features(1));

        CHECK_EQ(ret.training_samples(7).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10001}), ret.training_samples(7).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({15}), ret.training_samples(7).features(1));

        CHECK_EQ(ret.training_samples(8).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(8).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(8).features(1));
    }

    TEST_CASE("seq_hit_list_4") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="10812,10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_hit_list"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_expose,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr_over_all,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                    <feature name="10815"
                        slot="10815"
                        type="direct"
                        source="10811:3"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAdsStatsInfo *ad_stat_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10001);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(0.2);
        ad_stat_info->set_dtr_over_all(8.7);
        ad_stat_info->set_last_event_time(20);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10000);
        ad_stat_info->set_num_expose(10006);
        ad_stat_info->set_dtr(3.1);
        ad_stat_info->set_dtr_over_all(6.4);
        ad_stat_info->set_last_event_time(0);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10003);
        ad_stat_info->set_num_expose(10001);
        ad_stat_info->set_dtr(2.0);
        ad_stat_info->set_dtr_over_all(2.8);
        ad_stat_info->set_last_event_time(7);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10004);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(1.1);
        ad_stat_info->set_dtr_over_all(1.9);
        ad_stat_info->set_last_event_time(22);

        // item
        fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10001, 10000}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, ({3.1, 0.2, 3.1}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({6.4, 8.7, 6.4}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10815, ({0, 20, 0}), ret.training_samples(0).features(3));
    }
    TEST_CASE("stat_smooth_ctr_1") {
        std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="app_info" value="31406" />
        </versions>
        <config>
            <dict name="app_info" 
                path="dict_test_data/appinfo"
                partition="{pt_d-1}"
                value_proto="phx.AppInfoDict"
             />
            <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
            <source name="item_info"
                value=".fe_request.item_fea.item_info" />

            <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
            <features>
                <feature name="31406"
                    slot="31406"
                    type="stat_smooth_ctr"
                    source="item_info.ocpx_sbp,item_info.data_source"
                    min_expo="2"
                    default_value="-1.1"
                    alpha="1"
                    beta="10"
                    />

            </features>
        </config>
    )";
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;

        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1110);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1111);
        ad_user_app_info->set_count(20);

        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20001);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20002);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
        item_fea->mutable_item_info()->set_creative_id(1110);
        item_fea->mutable_item_info()->set_ocpx_sbp(2);
        item_fea->mutable_item_info()->set_data_source(7);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(8);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("236");
        item_fea->mutable_item_info()->set_creative_id(1112);
        item_fea->mutable_item_info()->set_ocpx_sbp(1);
        item_fea->mutable_item_info()->set_data_source(1);
        auto fe_str = fe_request.SerializeAsString();

        auto user_action = phx::UserAction{};
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);
        TEST_SLOT_FEATURE_FLOAT(31406, ({(float) (2 + 1) / (7 + 10)}), training_sample.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(31406, ({(float) (3 + 1) / (8 + 10)}), training_sample.training_samples(1).features(0));
        TEST_SLOT_FEATURE_FLOAT(31406, ({-1.1f}), training_sample.training_samples(2).features(0));
    }

    TEST_CASE("test_seq_topn_direct_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq" filter_key="app_id" fields="request_id,event_time,ad_group_id" topn="3" reserve="1" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *ads = fe_request.mutable_ad_user_seq_conv_sdk_lahuo_realtime();
        auto *user_app_conv_seq = ads->add_ad_user_app_conv_seq();

        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(60);
        user_app_conv_seq->set_ad_group_id(100);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10001);
        user_app_conv_seq->set_event_time(120);
        user_app_conv_seq->set_ad_group_id(200);
        user_app_conv_seq->set_request_id("1");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10000);
        user_app_conv_seq->set_event_time(240);
        user_app_conv_seq->set_ad_group_id(300);
        user_app_conv_seq->set_request_id("0");

        user_app_conv_seq = ads->add_ad_user_app_conv_seq();
        user_app_conv_seq->set_app_id(10002);
        user_app_conv_seq->set_event_time(360);
        user_app_conv_seq->set_ad_group_id(400);
        user_app_conv_seq->set_request_id("2");

        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_STR(10812, ({"0", "0", "1"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({60, 240, 120}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({100, 300, 200}), ret.training_samples(0).features(2));
    }

    TEST_CASE("test_seq_topn_direct_2") {
        //user一层repeated且在source中间,inter_key存在未设置的
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info" filter_key="name" fields="num_expose,num_download_success" topn="3" reserve="1" />
                    <feature name="10813" slot="10813" type="direct" source="10811:0" />
                    <feature name="10814" slot="10814" type="direct" source="10811:1" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        // appid eventtime
        ::phx::AdUserAdsStatsInfo *ad_stat_info =
                fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10000);
        ad_stat_info->set_num_expose(0);
        ad_stat_info->set_num_download_success(0);

        ad_stat_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10001);
        ad_stat_info->set_num_expose(0);
        ad_stat_info->set_num_download_success(1);

        ad_stat_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10002);
        ad_stat_info->set_num_expose(1);
        ad_stat_info->set_num_download_success(0);

        ad_stat_info = fe_request.mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_num_expose(1);
        ad_stat_info->set_num_download_success(1);

        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10813, ({1, 0, 0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10814, ({1, 0, 1}), ret.training_samples(0).features(1));
    }

    TEST_CASE("test_seq_topn_direct_3") {
        //user一层repeated且在source中间,inter_key存在未设置的
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811" slot="10811" type="seq_topn_direct" source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info" filter_key="num_expose" fields="name,dtr,dtr_over_all" topn="4" reserve="0" />
                    <feature name="10812" slot="10812" type="direct" source="10811:0" />
                    <feature name="10813" slot="10813" type="direct" source="10811:1" />
                    <feature name="10814" slot="10814" type="direct" source="10811:2" />
                </features>
            </config>
          )";

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAdsStatsInfo *ad_stat_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10001);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(0.2);
        ad_stat_info->set_dtr_over_all(8.7);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10000);
        ad_stat_info->set_num_expose(10006);
        ad_stat_info->set_dtr(3.1);
        ad_stat_info->set_dtr_over_all(6.4);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10003);
        ad_stat_info->set_num_expose(10001);
        ad_stat_info->set_dtr(2.0);
        ad_stat_info->set_dtr_over_all(2.8);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10002);
        ad_stat_info->set_num_expose(10003);
        ad_stat_info->set_dtr(7.1);
        ad_stat_info->set_dtr_over_all(6.3);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10004);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(1.1);
        ad_stat_info->set_dtr_over_all(1.9);

        // item
        fe_request->add_item_fea();
        fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10002, 10003, 10001}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, ({3.1, 7.1, 2.0, 0.2}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({6.4, 6.3, 2.8, 8.7}), ret.training_samples(0).features(2));

        CHECK_EQ(ret.training_samples(1).features_size(), 3);
        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10002, 10003, 10001}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, ({3.1, 7.1, 2.0, 0.2}), ret.training_samples(1).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({6.4, 6.3, 2.8, 8.7}), ret.training_samples(1).features(2));
    }

    TEST_CASE("seq_avg_interval") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_avg_interval"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id"
                        time_type="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_app_id(
                1751942516000);// 2025-07-08 10:41:56
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_app_id(
                1751949716000);// 2025-07-08 12:41:56
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_app_id(
                1751960516000);// 2025-07-08 15:41:56

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10811, {2.5}, ret.training_samples(0).features(0));
    }

    TEST_CASE("seq_avg_interval_2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_avg_interval"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id"
                        time_type="1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_app_id(
                1751856116000);// 2025-07-07 10:41:56
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_app_id(
                1751985716000);// 2025-07-08 22:41:56
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_app_id(
                1752108116000);// 2025-07-10 08:41:56

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10811, {1.45833}, ret.training_samples(0).features(0));
    }

    TEST_CASE("seq_statistics") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                        math_type="avg,min,max"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info()->set_dtr(1.2f);
        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info()->set_dtr(2.3f);
        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info()->set_dtr(3.4f);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10812, {2.3f}, ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, {1.2f}, ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, {3.4f}, ret.training_samples(0).features(2));
    }

    TEST_CASE("seq_statistics_2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_statistics"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.event_time"
                        math_type="avg,min,max"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                    <feature name="10815"
                        slot="10815"
                        type="direct"
                        source="10811:3"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(1);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(2);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(4);
        user_behavior_info->set_event_time(100);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(4);
        user_behavior_info->set_event_time(200);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(6);
        user_behavior_info->set_event_time(200);
        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(8);
        user_behavior_info->set_event_time(200);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(4, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10812, ({2.33333f, 6.0f}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({1L, 4L}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({4L, 8L}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10815, ({100L, 200L}), ret.training_samples(0).features(3));
    }

    TEST_CASE("seq_sort") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_sort"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_download_success,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time"
                        sort_cols="2,1,0"
                        sort_orders="desc,asc,desc"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto user_ads_stats_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.3f);
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(3.4f);
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(1.2f);
        user_ads_stats_info->set_num_download_success(200);
        user_ads_stats_info->set_last_event_time(3000);

        user_ads_stats_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        user_ads_stats_info->set_dtr(2.3f);
        user_ads_stats_info->set_num_download_success(300);
        user_ads_stats_info->set_last_event_time(4000);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_FLOAT(10812, ({2.3f, 3.4f, 2.3f, 1.2f}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({200L, 300L, 300L, 200L}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({4000L, 4000L, 4000L, 3000L}), ret.training_samples(0).features(2));
    }

    TEST_CASE("seq_sort_2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_sort"
                        source=".fe_request.ad_user_seq_game_payment_offline.ad_user_app_conv_seq.service_id,.fe_request.ad_user_seq_game_payment_offline.ad_user_app_conv_seq.adunit_id"
                        sort_cols="0,1"
                        sort_orders="asc,desc"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("a");
        ad_user_app_conv_seq->set_adunit_id(1000);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("b");
        ad_user_app_conv_seq->set_adunit_id(1001);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("a");
        ad_user_app_conv_seq->set_adunit_id(1001);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("c");
        ad_user_app_conv_seq->set_adunit_id(1001);

        ad_user_app_conv_seq = fe_request->mutable_ad_user_seq_game_payment_offline()->add_ad_user_app_conv_seq();
        ad_user_app_conv_seq->set_service_id("c");
        ad_user_app_conv_seq->set_adunit_id(1002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(2, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_STR(10812, ({"a", "a", "b", "c", "c"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({1001L, 1000L, 1001L, 1002L, 1001L}), ret.training_samples(0).features(1));
    }

    TEST_CASE("seq_flatten") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10812,10813,10814" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_flatten"
                        source=".fe_request.ad_user_auction_win_seq_1h_realtime.ad_user_auction_win_adunit_seq_1h_realtime"
                        from_lv1="adunit_id,callback_time"
                        from_lv2="app_id"
                        repeated_field="user_behavior_info"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto ad_user_auction_win_adunit_seq_1h_realtime = fe_request->mutable_ad_user_auction_win_seq_1h_realtime()
                                                                  ->add_ad_user_auction_win_adunit_seq_1h_realtime();

        ad_user_auction_win_adunit_seq_1h_realtime->set_adunit_id(12345);
        ad_user_auction_win_adunit_seq_1h_realtime->set_callback_time(1738704554000);

        ad_user_auction_win_adunit_seq_1h_realtime->add_user_behavior_info()->set_app_id(987);
        ad_user_auction_win_adunit_seq_1h_realtime->add_user_behavior_info()->set_app_id(654);
        ad_user_auction_win_adunit_seq_1h_realtime->add_user_behavior_info()->set_app_id(321);

        ad_user_auction_win_adunit_seq_1h_realtime = fe_request->mutable_ad_user_auction_win_seq_1h_realtime()
                                                             ->add_ad_user_auction_win_adunit_seq_1h_realtime();

        ad_user_auction_win_adunit_seq_1h_realtime->set_adunit_id(67890);
        ad_user_auction_win_adunit_seq_1h_realtime->set_callback_time(1738704502000);

        ad_user_auction_win_adunit_seq_1h_realtime->add_user_behavior_info()->set_app_id(98765);
        ad_user_auction_win_adunit_seq_1h_realtime->add_user_behavior_info()->set_app_id(43210);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(3, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10812, ({12345L, 12345L, 12345L, 67890L, 67890L}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813,
                                ({1738704554000L, 1738704554000L, 1738704554000L, 1738704502000L, 1738704502000L}),
                                ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10814, ({987L, 654L, 321L, 98765L, 43210L}), ret.training_samples(0).features(2));
    }

    TEST_CASE("seq_arithmetic") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_arithmetic"
                        source=".fe_request.ad_user_seq_click_realtime.user_behavior_info.app_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.event_time"
                        math_type="-"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();

        auto user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(179797980);
        user_behavior_info->set_event_time(179797970);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(179797992);
        user_behavior_info->set_event_time(179797972);

        user_behavior_info = fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info();
        user_behavior_info->set_app_id(179797988);
        user_behavior_info->set_event_time(179797977);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_INT64(10811, ({10, 20, 11}), ret.training_samples(0).features(0));
    }

    TEST_CASE("test_seq_filter_1") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.context.adunit_id" 
                    clip_size="3"
                    start = "86400"
                    day_n = "5"
                    filters = "int64_filter:${source[5]}" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 11 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 11 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 9 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86401 * 1000);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({900778570L}), ret.user_features(0));
        TEST_FEATURE_INT64(({(int64_t) (9 * 86401 * 1000)}), ret.user_features(1));
        TEST_FEATURE_INT64(({(int64_t) (104436777)}), ret.user_features(2));
    }
    TEST_CASE("test_seq_filter_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.context.adunit_id" 
                    clip_size="3"
                    start = "86400"
                    day_n = "5"
                    filters = "int64_filter:${source[5]}" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000 + 1);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 11 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 11 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 9 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86401 * 1000);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({}), ret.user_features(0));
        TEST_FEATURE_INT64(({}), ret.user_features(1));
        TEST_FEATURE_INT64(({}), ret.user_features(2));
    }

    TEST_CASE("test_seq_filter_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.context.adunit_id" 
                    clip_size="3"
                    start = "86400"
                    day_n = "5"
                    filters = "int64_filter:864000001,864000000" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000 + 1);

        ::phx::AdUserAppSeq *pb_use = fe_request.mutable_ad_user_app_seq_use_offline();
        ::phx::AdUserAppInfo *pb_info = pb_use->add_user_app_info();

        pb_info->set_app_id(104435568);
        pb_info->set_event_time((int64_t) 5 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 5 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436666);
        pb_info->set_event_time((int64_t) 11 * 86400 * 1000);
        pb_info->set_count(104435568);
        pb_info->set_first_event_time((int64_t) 11 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86404 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000 + 1);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(900778570);
        pb_info->set_event_time((int64_t) 9 * 86401 * 1000 + 1);
        pb_info->set_count(104436777);
        pb_info->set_first_event_time((int64_t) 10 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436777);
        pb_info->set_event_time((int64_t) 9 * 86403 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        pb_info = pb_use->add_user_app_info();
        pb_info->set_app_id(104436888);
        pb_info->set_event_time((int64_t) 9 * 86402 * 1000);
        pb_info->set_count(900778570);
        pb_info->set_first_event_time((int64_t) 7 * 86400 * 1000);

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({900778570, 900778570}), ret.user_features(0));
        TEST_FEATURE_INT64(({(int64_t) 9 * 86404 * 1000, (int64_t) 9 * 86401 * 1000 + 1}), ret.user_features(1));
        TEST_FEATURE_INT64(({900778570, 104436777}), ret.user_features(2));
    }

    TEST_CASE("test_seq_filter_3") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10812" slot="10812" type="seq_filter" 
                    source=".fe_request.ad_user_app_seq_use_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_use_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.count,.fe_request.req_time,.fe_request.ad_user_app_seq_use_offline.user_app_info.first_event_time,.fe_request.context.adunit_id" 
                    clip_size="3"
                    start = "86400"
                    day_n = "5"
                    filters = "int64_filter:864000001,864000000" />
                    <feature name="10813" slot="10813" type="direct" source="10812:0" attr="user" />
                    <feature name="10814" slot="10814" type="direct" source="10812:1" attr="user" />
                    <feature name="10815" slot="10815" type="direct" source="10812:2" attr="user" />
                </features>
            </config>
          )";
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request.set_event_time((int64_t) 10 * 86400 * 1000);
        fe_request.set_req_time((int64_t) 12 * 86400 * 1000);
        fe_request.mutable_context()->set_adunit_id((int64_t) 10 * 86400 * 1000 + 1);

        fe_request.mutable_ad_user_app_seq_use_offline();

        // item 不为空
        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto batch_training_sample_str =
                to_extractor_response(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::ExtractorResponse ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());
        CHECK_EQ(ret.user_features().size(), 3);
        TEST_FEATURE_INT64(({}), ret.user_features(0));
        TEST_FEATURE_INT64(({}), ret.user_features(1));
        TEST_FEATURE_INT64(({}), ret.user_features(2));
    }

    TEST_CASE("seq_hit_count_v3_1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v3"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        data_type="int64"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v3"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        data_type="int64"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({3}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(3).features(1));
        // std::cout << ret.DebugString() << std::endl;
    }

    TEST_CASE("seq_hit_count_v3_2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v3"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        data_type="int64"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v3"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        data_type="int64"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 100 * 86400 * 1000 - 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 70 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 90 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 40 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 60 * 86400 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({1}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({3}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({3}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(3).features(1));
        // std::cout << ret.DebugString() << std::endl;
    }

    TEST_CASE("seq_hit_count_v3_3") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v3"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        data_type="int64"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v3"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        data_type="int64"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        // empty

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10003);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({}), ret.training_samples(3).features(1));
    }

    TEST_CASE("seq_hit_count_v3_4") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v3"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.appid"
                        start="864000"
                        data_type="int64"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v3"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid"
                        max_num="2"
                        data_type="int64"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 105 * 86400 * 1000);// 防穿越

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);// 防穿越

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(0).features(1));
    }

    TEST_CASE("seq_hit_count_v3_5") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406,31407" />
            </versions>
            <config>
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="seq_hit_count_v3"
                        source=".fe_request.ad_user_seq_download_offline.user_behavior_info.session_id,.fe_request.ad_user_seq_download_offline.user_behavior_info.event_time,.fe_request.req_time,.fe_request.item_fea.item_info.rta_id"
                        start="864000"
                        data_type="string"
                        />
                    <feature name="31407"
                        slot="31407"
                        type="seq_hit_count_v3"
                        source=".fe_request.ad_user_seq_download_offline.user_behavior_info.session_id,.fe_request.item_fea.item_info.rta_id"
                        max_num="2"
                        data_type="string"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        // req_time
        fe_request->set_req_time((int64_t) 110 * 86400 * 1000);

        // appid eventtime
        ::phx::AdUserBehaviorInfo *user_behavior_info =
                fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10000");
        user_behavior_info->set_event_time((int64_t) 105 * 86400 * 1000);
        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10001");
        user_behavior_info->set_event_time((int64_t) 70 * 86400 * 1000);
        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10001");
        user_behavior_info->set_event_time((int64_t) 90 * 86400 * 1000);
        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10002");
        user_behavior_info->set_event_time((int64_t) 40 * 86400 * 1000);
        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10002");
        user_behavior_info->set_event_time((int64_t) 60 * 86400 * 1000);
        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10002");
        user_behavior_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("10000");// 防穿越
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("10001");
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("10002");
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("10003");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 4);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({1}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({2}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({3}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({2}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(31406, ({0}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(31407, ({0}), ret.training_samples(3).features(1));
    }

    TEST_CASE("seq_hit_list_v2_1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_hit_list_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.appid,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                        data_type="int64"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        ad_user_app_info->set_event_time((int64_t) 1 * 3600 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 2 * 3600 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time((int64_t) 5 * 3600 * 1000);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time((int64_t) 6 * 3600 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10001}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 2 * 3600 * 1000, (int64_t) 6 * 3600 * 1000}),
                                ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10002}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({(int64_t) 5 * 3600 * 1000}), ret.training_samples(1).features(1));
    }

    TEST_CASE("seq_hit_list_2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_hit_list"
                        source=".fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.app_id,.fe_request.item_fea.item_info.appid,.fe_request.ad_user_seq_conv_sdk_lahuo_realtime.ad_user_app_conv_seq.request_id"
                        data_type="int64"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserConvInfo *ad_conv_info =
                fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10000);
        ad_conv_info->set_request_id("游戏中心0");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10001);
        ad_conv_info->set_request_id("应用市场1");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10000);
        ad_conv_info->set_request_id("游戏中心2");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10002);
        ad_conv_info->set_request_id("游戏中心3");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10001);
        ad_conv_info->set_request_id("应用市场4");
        ad_conv_info = fe_request->mutable_ad_user_seq_conv_sdk_lahuo_realtime()->add_ad_user_app_conv_seq();
        ad_conv_info->set_app_id(10002);
        ad_conv_info->set_request_id("游戏中心5");

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10002, 10002}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10813, ({"游戏中心3", "游戏中心5"}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10001, 10001}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_STR(10813, ({"应用市场1", "应用市场4"}), ret.training_samples(1).features(1));
    }

    TEST_CASE("seq_hit_list_3") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_hit_list"
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.creative_id,.fe_request.item_fea.item_info.bid"
                        data_type="int64"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_creative_id(10002);
        item_fea->mutable_item_info()->set_bid(21);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_creative_id(10002);
        item_fea->mutable_item_info()->set_bid(32);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea->mutable_item_info()->set_creative_id(10002);
        item_fea->mutable_item_info()->set_bid(25);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_creative_id(10000);
        item_fea->mutable_item_info()->set_bid(54);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_creative_id(10000);
        item_fea->mutable_item_info()->set_bid(28);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea->mutable_item_info()->set_creative_id(10000);
        item_fea->mutable_item_info()->set_bid(17);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10000);
        item_fea->mutable_item_info()->set_creative_id(10001);
        item_fea->mutable_item_info()->set_bid(72);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10001);
        item_fea->mutable_item_info()->set_creative_id(10001);
        item_fea->mutable_item_info()->set_bid(15);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_appid(10002);
        item_fea->mutable_item_info()->set_creative_id(10001);
        item_fea->mutable_item_info()->set_bid(43);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 9);

        CHECK_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(0).features(1));

        CHECK_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(1).features(1));

        CHECK_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10002}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({25}), ret.training_samples(2).features(1));

        CHECK_EQ(ret.training_samples(3).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10000}), ret.training_samples(3).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({54}), ret.training_samples(3).features(1));

        CHECK_EQ(ret.training_samples(4).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(4).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(4).features(1));

        CHECK_EQ(ret.training_samples(5).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(5).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(5).features(1));

        CHECK_EQ(ret.training_samples(6).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(6).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(6).features(1));

        CHECK_EQ(ret.training_samples(7).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({10001}), ret.training_samples(7).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({15}), ret.training_samples(7).features(1));

        CHECK_EQ(ret.training_samples(8).features_size(), 2);
        TEST_SLOT_FEATURE_INT64(10812, ({}), ret.training_samples(8).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({}), ret.training_samples(8).features(1));
    }

    TEST_CASE("seq_hit_list_4") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="10812,10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_hit_list"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.name,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.num_expose,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr_over_all,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.last_event_time"
                        data_type="int64"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source="10811:2"
                        />
                    <feature name="10815"
                        slot="10815"
                        type="direct"
                        source="10811:3"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserAdsStatsInfo *ad_stat_info =
                fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10001);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(0.2);
        ad_stat_info->set_dtr_over_all(8.7);
        ad_stat_info->set_last_event_time(20);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10000);
        ad_stat_info->set_num_expose(10006);
        ad_stat_info->set_dtr(3.1);
        ad_stat_info->set_dtr_over_all(6.4);
        ad_stat_info->set_last_event_time(0);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10003);
        ad_stat_info->set_num_expose(10001);
        ad_stat_info->set_dtr(2.0);
        ad_stat_info->set_dtr_over_all(2.8);
        ad_stat_info->set_last_event_time(7);

        ad_stat_info = fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        ad_stat_info->set_name(10004);
        ad_stat_info->set_num_expose(10000);
        ad_stat_info->set_dtr(1.1);
        ad_stat_info->set_dtr_over_all(1.9);
        ad_stat_info->set_last_event_time(22);

        // item
        fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 1);

        CHECK_EQ(ret.training_samples(0).features_size(), 4);
        TEST_SLOT_FEATURE_INT64(10812, ({10000, 10001, 10000}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_FLOAT(10813, ({3.1, 0.2, 3.1}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_FLOAT(10814, ({6.4, 8.7, 6.4}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_INT64(10815, ({0, 20, 0}), ret.training_samples(0).features(3));
    }

    TEST_CASE("seq_hit_list_v2_5") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="10812,10813" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="seq_hit_list_v2"
                        source=".fe_request.ad_user_seq_download_offline.user_behavior_info.session_id,.fe_request.item_fea.item_info.rta_id,.fe_request.ad_user_seq_download_offline.user_behavior_info.event_time"
                        data_type="string"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source="10811:0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source="10811:1"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // appid eventtime
        ::phx::AdUserBehaviorInfo *user_behavior_info =
                fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10000");
        user_behavior_info->set_event_time((int64_t) 105 * 86400 * 1000);
        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10001");
        user_behavior_info->set_event_time((int64_t) 70 * 86400 * 1000);
        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10001");
        user_behavior_info->set_event_time((int64_t) 90 * 86400 * 1000);
        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10002");
        user_behavior_info->set_event_time((int64_t) 40 * 86400 * 1000);
        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10002");
        user_behavior_info->set_event_time((int64_t) 60 * 86400 * 1000);
        user_behavior_info = fe_request->mutable_ad_user_seq_download_offline()->add_user_behavior_info();
        user_behavior_info->set_session_id("10002");
        user_behavior_info->set_event_time((int64_t) 50 * 86400 * 1000);

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("10000");
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("10001");
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("10002");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(ret.training_samples_size(), 3);

        REQUIRE_EQ(ret.training_samples(0).features_size(), 2);
        TEST_SLOT_FEATURE_STR(10812, ({"10000"}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({105 * 86400 * 1000L}), ret.training_samples(0).features(1));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 2);
        TEST_SLOT_FEATURE_STR(10812, ({"10001", "10001"}), ret.training_samples(1).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({70 * 86400 * 1000L, 90 * 86400 * 1000L}), ret.training_samples(1).features(1));

        REQUIRE_EQ(ret.training_samples(2).features_size(), 2);
        TEST_SLOT_FEATURE_STR(10812, ({"10002", "10002", "10002"}), ret.training_samples(2).features(0));
        TEST_SLOT_FEATURE_INT64(10813, ({40 * 86400 * 1000L, 60 * 86400 * 1000L, 50 * 86400 * 1000L}), ret.training_samples(2).features(1));
    }
}
