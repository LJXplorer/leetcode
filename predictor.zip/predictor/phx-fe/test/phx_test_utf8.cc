#include "phx_test.h"


TEST_SUITE("utf8") {

    TEST_CASE("utf8_coincide") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="utf8_coincide"
                    source=".fe_request.item_fea.item_info.rta_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // 部分重合
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("品质测试");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("试验品");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f0 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f0.bytes_list_size());
        CHECK_EQ("试品", f0.bytes_list(0));

        // 完全重合
        fe_request->clear_item_fea();
        fe_request->mutable_ad_user_seq_click_realtime()->clear_user_behavior_info();
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("上海自来水来自海上");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id(
                "上海自来水来自海上");

        fe_request_str = fe_request->SerializeAsString();
        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f1.bytes_list_size());
        CHECK_EQ("上海自来水来自海上", f1.bytes_list(0));

        // 没有重合
        fe_request->clear_item_fea();
        fe_request->mutable_ad_user_seq_click_realtime()->clear_user_behavior_info();
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("abcd");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("1234");

        fe_request_str = fe_request->SerializeAsString();
        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f2 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f2.bytes_list_size());
        CHECK_EQ("", f2.bytes_list(0));
    }

    TEST_CASE("utf8_is_equal") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="utf8_is_equal"
                    source=".fe_request.item_fea.item_info.rta_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("测试试验");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试试验");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f1.signs_size());
        CHECK_EQ(1, f1.signs(0));

        fe_request->clear_item_fea();
        fe_request->mutable_ad_user_seq_click_realtime()->clear_user_behavior_info();
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("测试试");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试试验");

        fe_request_str = fe_request->SerializeAsString();
        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f2 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f2.signs_size());
        CHECK_EQ(0, f2.signs(0));
    }

    TEST_CASE("utf8_is_prefix") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="utf8_is_prefix"
                    source=".fe_request.item_fea.item_info.rta_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("测试试验");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f1.signs_size());
        CHECK_EQ(1, f1.signs(0));

        fe_request->mutable_ad_user_seq_click_realtime()->clear_user_behavior_info();
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试1");

        fe_request_str = fe_request->SerializeAsString();
        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f2 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f2.signs_size());
        CHECK_EQ(0, f2.signs(0));
    }

    TEST_CASE("utf8_is_contains") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="utf8_is_contains"
                    source=".fe_request.item_fea.item_info.rta_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("测试试验");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f1.signs_size());
        CHECK_EQ(1, f1.signs(0));

        fe_request->mutable_ad_user_seq_click_realtime()->clear_user_behavior_info();
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试1");

        fe_request_str = fe_request->SerializeAsString();
        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f2 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f2.signs_size());
        CHECK_EQ(0, f2.signs(0));
    }

    TEST_CASE("utf8_public_prefix_length") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="utf8_public_prefix_length"
                    source=".fe_request.item_fea.item_info.rta_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("测试试验");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f1.signs_size());
        CHECK_EQ(2, f1.signs(0));

        fe_request->clear_item_fea();
        fe_request->mutable_ad_user_seq_click_realtime()->clear_user_behavior_info();
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("最小距离");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("变换距离");

        fe_request_str = fe_request->SerializeAsString();
        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f2 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f2.signs_size());
        CHECK_EQ(0, f2.signs(0));
    }

    // 计算编辑距离
    TEST_CASE("utf8_distance") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="utf8_distance"
                    source=".fe_request.item_fea.item_info.rta_id,.fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("测试试验");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("测试");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f1 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f1.signs_size());
        CHECK_EQ(2, f1.signs(0));

        fe_request->clear_item_fea();
        fe_request->mutable_ad_user_seq_click_realtime()->clear_user_behavior_info();
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("abcdef");
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("azced");

        fe_request_str = fe_request->SerializeAsString();
        ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                        user_action_str.size(), config_handle);

        ret.ParseFromString(ret_str);

        REQUIRE_EQ(1, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f2 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f2.signs_size());
        CHECK_EQ(3, f2.signs(0));
    }

    TEST_CASE("utf8_get_re_result") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="utf8_get_re_result"
                    source=".fe_request.item_fea.item_info.rta_id"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("a1中文!@#");
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("🍎→★");
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("漢字こんにちは안녕하세요αβγ");
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("123abcDEF");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(4, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_STR(10811, {"a1中文"}, ret.training_samples(0).features(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        TEST_SLOT_FEATURE_STR(10811, {""}, ret.training_samples(1).features(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        TEST_SLOT_FEATURE_STR(10811, {"漢字こんにちは안녕하세요"}, ret.training_samples(2).features(0));

        REQUIRE_EQ(1, ret.training_samples(3).features_size());
        TEST_SLOT_FEATURE_STR(10811, {"123abcdef"}, ret.training_samples(3).features(0));
    }

    TEST_CASE("utf8_get_prefix") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="utf8_get_prefix"
                    source=".fe_request.item_fea.item_info.rta_id"
                    max_size="10"
                    />
            </features>
        </config>
    )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("a1中文!@#");
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("123abcDEF");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(2, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_STR(10811, ({"a", "a1", "a1中", "a1中文", "a1中文!", "a1中文!@"}),
                              ret.training_samples(0).features(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        TEST_SLOT_FEATURE_STR(10811, ({"1", "12", "123", "123a", "123ab", "123abc", "123abcD", "123abcDE"}),
                              ret.training_samples(1).features(0));
    }

    TEST_CASE("utf8_sub_str") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="utf8_sub_str"
                    source=".fe_request.item_fea.item_info.rta_id"
                    len="5"
                    />
            </features>
        </config>
    )";
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("地下城与勇士：征途");
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("a1中文");
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("");
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("€√￥×♂♀♪");
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("😊🌙🌍👍📧📱🎵");
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("a地♪😊ち勇士♂♀📧");
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);
        REQUIRE_EQ(6, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_STR(10811, ({"地下城与勇"}), ret.training_samples(0).features(0));
        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        TEST_SLOT_FEATURE_STR(10811, ({"a1中文"}), ret.training_samples(1).features(0));
        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        TEST_SLOT_FEATURE_STR(10811, ({""}), ret.training_samples(2).features(0));
        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        TEST_SLOT_FEATURE_STR(10811, ({"€√￥×♂"}), ret.training_samples(3).features(0));
        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        TEST_SLOT_FEATURE_STR(10811, ({"😊🌙🌍👍📧"}), ret.training_samples(4).features(0));
        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        TEST_SLOT_FEATURE_STR(10811, ({"a地♪😊ち"}), ret.training_samples(5).features(0));
    }

    TEST_CASE("utf8_ip_to_list") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="utf8_ip_to_list"
                    source=".fe_request.item_fea.item_info.rta_id"
                    sep="."
                    />
            </features>
        </config>
    )";
        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("com.test.gallery");
        fe_request->add_item_fea()->mutable_item_info()->set_rta_id("192.168.1.1");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        auto fe_request_str = fe_request->SerializeAsString();
        auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                             user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);
        REQUIRE_EQ(2, ret.training_samples_size());
        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        TEST_SLOT_FEATURE_STR(10811, ({"com.test", "com.test.gallery"}), ret.training_samples(0).features(0));
        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        TEST_SLOT_FEATURE_STR(10811, ({"192.168", "192.168.1", "192.168.1.1"}), ret.training_samples(1).features(0));
    }
}
