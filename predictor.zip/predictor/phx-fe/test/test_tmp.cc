
#include "phx-fe/config_mgr/xml_config_mgr.h"
#include "phx-fe/decode/base64.h"
#include "phx-fe/decode/decode.h"
#include "dict/item_info_dict.pb.h"
#include "fe_request.pb.h"
#include "feature_extractor.pb.h"
#include "phx-fe/src/framework.h"
#include "phx-fe/src/service.h"
#include "phx-fe/util/log.h"
#include "phx-fe/util/pb_utils.h"
#include "phx-fe/util/printer.h"
#include "phx-fe/util/util.h"
#include <fstream>
#include <google/protobuf/util/json_util.h>
#include <iostream>
#include <sstream>
#include <string>
std::string readFileToString(const std::string &filename) {
    std::ifstream file(filename);
    if (!file) {
        throw std::runtime_error("无法打开文件: " + filename);
    }
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}
void writeStringToFile(const std::string &filename, const std::string &content) {
    std::ofstream file(filename);
    if (!file) {
        throw std::runtime_error("无法打开文件: " + filename);
    }
    file << content;
}

phx::FeRequest *mockFePb(google::protobuf::Arena *arena) {
    phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(arena);
    ::phx::AdUserAppInfo *ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
    ad_user_app_info->set_app_id(1110);
    ad_user_app_info->set_count(10);
    ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
    ad_user_app_info->set_app_id(1111);
    ad_user_app_info->set_count(20);

    auto *app_fea = fe_request.add_app_fea();
    app_fea->mutable_ad_info()->set_app_id(20001);
    app_fea = fe_request.add_app_fea();
    app_fea->mutable_ad_info()->set_app_id(20002);

    auto *item_fea = fe_request.add_item_fea();
    item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
    item_fea->mutable_item_info()->set_creative_id(1110);
    item_fea->mutable_item_info()->set_ocpx_sbp(2);
    item_fea->mutable_item_info()->set_data_source(7);

    item_fea = fe_request.add_item_fea();
    item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
    item_fea->mutable_item_info()->set_creative_id(1111);
    item_fea->mutable_item_info()->set_ocpx_sbp(3);
    item_fea->mutable_item_info()->set_data_source(8);

    item_fea = fe_request.add_item_fea();
    item_fea->mutable_item_info()->mutable_rta_id()->assign("236");
    item_fea->mutable_item_info()->set_creative_id(1112);
    item_fea->mutable_item_info()->set_ocpx_sbp(10);
    item_fea->mutable_item_info()->set_data_source(0);

    mocker::FillProto(fe_request);
    return &fe_request;
}

phx::UserAction *mockUserActionPb(google::protobuf::Arena *arena) {
    phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(arena);
    user_action.set_adunit_id(17088784918);
    user_action.set_algo_id("mock_algo_id");
    auto *item_info = user_action.add_user_action_item_info();
    item_info->set_ad_group_id(700001);
    item_info->set_creative_id(60000001);

    item_info = user_action.add_user_action_item_info();
    item_info->set_ad_group_id(700002);
    item_info->set_creative_id(60000002);

    item_info = user_action.add_user_action_item_info();
    item_info->set_ad_group_id(700003);
    item_info->set_creative_id(60000003);
    return &user_action;
}

void mockAppinfoDict() {
    phx::UserAction ua;
    phx::FeRequest fe;
    debug::LoadPbFromFile("ua_8.bin", &ua, debug::PbFormat::kRawBinary);
    debug::LoadPbFromFile("fe_8.bin", &fe, debug::PbFormat::kRawBinary);
    std::cout << "debug::SavePbToFile ua_8_base64.txt \n";
    debug::SavePbToFile("ua_8_base64.txt", ua, debug::PbFormat::kBase64);
    std::cout << "debug::SavePbToFile fe_8_base64.txt \n";
    debug::SavePbToFile("fe_8_base64.txt", fe, debug::PbFormat::kBase64);

    std::cout << "debug::SavePbToFile ua_8_base64.json \n";
    debug::SavePbToFile("ua_8_base64.json", ua, debug::PbFormat::kJson);
    std::cout << "debug::SavePbToFile fe_8_base64.json \n";
    debug::SavePbToFile("fe_8_base64.json", fe, debug::PbFormat::kJson);
}

int main() {
    mockAppinfoDict();
    return 0;
}