#include "test.h"

//feature
void test_utf8_distance_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_distance",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8DistanceConfig* config = dynamic_cast<Utf8DistanceConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("456");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("好欧啊斯亿");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("132");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("987");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("啊欧斯");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("测试");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("最小距离");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("爱嗯特额嗯特爱哦嗯");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("测验");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("变换距");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("额克额词有特爱哦嗯");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(3, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(3, itr00->second.int64_list().value(1));
  TEST_EXPECT_EQUAL(3, itr00->second.int64_list().value(2));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(3, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(3, itr01->second.int64_list().value(1));
  TEST_EXPECT_EQUAL(5, itr01->second.int64_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(6, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(3, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(3, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(3));
  TEST_EXPECT_EQUAL(3, tvalues0.int64_val(4));
  TEST_EXPECT_EQUAL(5, tvalues0.int64_val(5));

  TEST_ASSERT_EQUAL(12, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices0.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(6));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(7));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(8));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(9));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(10));
  TEST_EXPECT_EQUAL(2, tindices0.int64_val(11));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_utf8_distance_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_distance",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.appid",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8DistanceConfig* config = dynamic_cast<Utf8DistanceConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("456");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("测试距离");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("132");
  fate->mutable_bytes_list()->add_value("987");
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("实际距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(2, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(3, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(2, list.feature(1).int64_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(3, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(2, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_utf8_is_contains_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_is_contains",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8IsContainsConfig* config = dynamic_cast<Utf8IsContainsConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("567");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("56");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("测试试验1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("最小距离");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("测试");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("变换距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr00->second.int64_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(0, itr01->second.int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(3));

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(6));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_utf8_is_contains_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_is_contains",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.appid",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8IsContainsConfig* config = dynamic_cast<Utf8IsContainsConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("567");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("测试试验1");
  fate->mutable_bytes_list()->add_value("距离");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("56");
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("测试");
  fate->mutable_bytes_list()->add_value("变换距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(2, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, list.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(0, list.feature(1).int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_utf8_is_equal_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_is_equal",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8IsEqualConfig* config = dynamic_cast<Utf8IsEqualConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("567");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("56");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("测试试验1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("最小距离");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("测试");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("变换距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(0, itr00->second.int64_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(0, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(0, itr01->second.int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(3));

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(6));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_utf8_is_equal_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_is_equal",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.appid",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8IsEqualConfig* config = dynamic_cast<Utf8IsEqualConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("567");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("测试试验1");
  fate->mutable_bytes_list()->add_value("距离");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("56");
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("测试");
  fate->mutable_bytes_list()->add_value("变换距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(0, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(2, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(0, list.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(0, list.feature(1).int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_utf8_is_prefix_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_is_prefix",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8IsPrefixConfig* config = dynamic_cast<Utf8IsPrefixConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("567");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("56");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("测试试验1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("最小距离");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("测试");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("变换距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(1, itr00->second.int64_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(1, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(0, itr01->second.int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(3));

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(6));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_utf8_is_prefix_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_is_prefix",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.appid",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8IsPrefixConfig* config = dynamic_cast<Utf8IsPrefixConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("567");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("测试试验1");
  fate->mutable_bytes_list()->add_value("距离");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("56");
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("测试");
  fate->mutable_bytes_list()->add_value("变换距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(1, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(2, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(1, list.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(0, list.feature(1).int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(1, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_utf8_join_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_join",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "delimiter" : "-"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8JoinConfig* config = dynamic_cast<Utf8JoinConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_int64_list()->add_value(8);
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_int64_list()->add_value(11);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_int64_list()->add_value(14);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_int64_list()->add_value(5);
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_int64_list()->add_value(3);
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_int64_list()->add_value(21);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_int64_list()->add_value(17);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_int64_list()->add_value(6);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("8-14", itr00->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("11-5", itr00->second.bytes_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("3-17", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("21-6", itr01->second.bytes_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.string_val_size());
  TEST_EXPECT_EQUAL("8-14", tvalues0.string_val(0));
  TEST_EXPECT_EQUAL("11-5", tvalues0.string_val(1));
  TEST_EXPECT_EQUAL("3-17", tvalues0.string_val(2));
  TEST_EXPECT_EQUAL("21-6", tvalues0.string_val(3));

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(6));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_utf8_join_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_join",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.appid",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8JoinConfig* config = dynamic_cast<Utf8JoinConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value(8);
  fate->mutable_int64_list()->add_value(11);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value(3);
  fate->mutable_int64_list()->add_value(21);

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value(14);
  fate->mutable_int64_list()->add_value(5);
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value(17);
  fate->mutable_int64_list()->add_value(6);

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("814", list.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("115", list.feature(0).bytes_list().value(1));
  TEST_ASSERT_EQUAL(2, list.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("317", list.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("216", list.feature(1).bytes_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.string_val_size());
  TEST_EXPECT_EQUAL("814", tvalues0.string_val(0));
  TEST_EXPECT_EQUAL("115", tvalues0.string_val(1));
  TEST_EXPECT_EQUAL("317", tvalues0.string_val(2));
  TEST_EXPECT_EQUAL("216", tvalues0.string_val(3));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_utf8_public_prefix_length_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_public_prefix_length",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8PublicPrefixLengthConfig* config = dynamic_cast<Utf8PublicPrefixLengthConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("567");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("56");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("测试试验1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("最小距离");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("测试");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("变换距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(2, itr00->second.int64_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(2, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(0, itr01->second.int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(3, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(2, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(3));

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(6));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_utf8_public_prefix_length_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_public_prefix_length",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.appid",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8PublicPrefixLengthConfig* config = dynamic_cast<Utf8PublicPrefixLengthConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("567");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("测试试验1");
  fate->mutable_bytes_list()->add_value("距离");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("56");
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("测试");
  fate->mutable_bytes_list()->add_value("变换距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(3, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(2, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(2, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(2, list.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(0, list.feature(1).int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(3, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(2, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues0.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_utf8_length_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_length",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8LengthConfig* config = dynamic_cast<Utf8LengthConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("567");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("测试试验1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("最小距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(3, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(3, itr00->second.int64_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(5, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(4, itr01->second.int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(3, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(3, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(5, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(4, tvalues0.int64_val(3));

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(6));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_utf8_length_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_length",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.appid"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8LengthConfig* config = dynamic_cast<Utf8LengthConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("567");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("测试试验1");
  fate->mutable_bytes_list()->add_value("距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(3, list.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(3, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(2, list.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(5, list.feature(1).int64_list().value(0));
  TEST_EXPECT_EQUAL(2, list.feature(1).int64_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.int64_val_size());
  TEST_EXPECT_EQUAL(3, tvalues0.int64_val(0));
  TEST_EXPECT_EQUAL(3, tvalues0.int64_val(1));
  TEST_EXPECT_EQUAL(5, tvalues0.int64_val(2));
  TEST_EXPECT_EQUAL(2, tvalues0.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_utf8_preprocess_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_preprocess",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8PreprocessConfig* config = dynamic_cast<Utf8PreprocessConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("1 2 3");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("￥56\t7");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("测试，试验\n1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("最小·距离");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("123", itr00->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("567", itr00->second.bytes_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("测试试验1", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("最小距离", itr01->second.bytes_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.string_val_size());
  TEST_EXPECT_EQUAL("123", tvalues0.string_val(0));
  TEST_EXPECT_EQUAL("567", tvalues0.string_val(1));
  TEST_EXPECT_EQUAL("测试试验1", tvalues0.string_val(2));
  TEST_EXPECT_EQUAL("最小距离", tvalues0.string_val(3));

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(6));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_utf8_preprocess_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_preprocess",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.appid"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 2, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8PreprocessConfig* config = dynamic_cast<Utf8PreprocessConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("1 2 3。");
  fate->mutable_bytes_list()->add_value("￥5：6\t7！");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("测试，试验\n1");
  fate->mutable_bytes_list()->add_value("“最小·距离”");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("123", list.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("567", list.feature(0).bytes_list().value(1));
  TEST_ASSERT_EQUAL(2, list.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("测试试验1", list.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("最小距离", list.feature(1).bytes_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.string_val_size());
  TEST_EXPECT_EQUAL("123", tvalues0.string_val(0));
  TEST_EXPECT_EQUAL("567", tvalues0.string_val(1));
  TEST_EXPECT_EQUAL("测试试验1", tvalues0.string_val(2));
  TEST_EXPECT_EQUAL("最小距离", tvalues0.string_val(3));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

//feature
void test_utf8_split_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_split",
          "source": [
              ".item_feature.item_feature_se.context.feature.appid"
          ],
          "split_width" : 2
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8SplitConfig* config = dynamic_cast<Utf8SplitConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("测试1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("123");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("测试结果预期4");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("不处理");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("测试", itr00->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("1", itr00->second.bytes_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(4, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("测试", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("结果", itr01->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("预期", itr01->second.bytes_list().value(2));
  TEST_EXPECT_EQUAL("4", itr01->second.bytes_list().value(3));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(6, tvalues0.string_val_size());
  TEST_EXPECT_EQUAL("测试", tvalues0.string_val(0));
  TEST_EXPECT_EQUAL("1", tvalues0.string_val(1));
  TEST_EXPECT_EQUAL("测试", tvalues0.string_val(2));
  TEST_EXPECT_EQUAL("结果", tvalues0.string_val(3));
  TEST_EXPECT_EQUAL("预期", tvalues0.string_val(4));
  TEST_EXPECT_EQUAL("4", tvalues0.string_val(5));

  TEST_ASSERT_EQUAL(12, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(6));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(7));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(8));
  TEST_EXPECT_EQUAL(2, tindices0.int64_val(9));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(10));
  TEST_EXPECT_EQUAL(3, tindices0.int64_val(11));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(4, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_utf8_split_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_split",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.appid"
          ],
          "split_width" : 3
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 3, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());

  Utf8SplitConfig* config = dynamic_cast<Utf8SplitConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("测试用例1");
  fate->mutable_bytes_list()->add_value("12345");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("测试长度超出dim状况");
  fate->mutable_bytes_list()->add_value("5555");

  item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("测试");
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("测试test");
  fate->mutable_bytes_list()->add_value("222");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("测试用", list.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("例1", list.feature(0).bytes_list().value(1));
  TEST_ASSERT_EQUAL(4, list.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("测试长", list.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("度超出", list.feature(1).bytes_list().value(1));
  TEST_EXPECT_EQUAL("dim", list.feature(1).bytes_list().value(2));
  TEST_EXPECT_EQUAL("状况", list.feature(1).bytes_list().value(3));

  const auto& map01 = batch_ret.batch(1).feature_lists().feature_list();
  auto itr01 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  const auto& list01 = itr01->second;
  TEST_ASSERT_EQUAL(2, list01.feature_size());
  TEST_ASSERT_EQUAL(1, list01.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("测试", list01.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(2, list01.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("测试t", list01.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("est", list01.feature(1).bytes_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(12, tvalues0.string_val_size());
  TEST_EXPECT_EQUAL("测试用", tvalues0.string_val(0));
  TEST_EXPECT_EQUAL("例1", tvalues0.string_val(1));
  TEST_EXPECT_EQUAL("", tvalues0.string_val(2));

  TEST_EXPECT_EQUAL("测试长", tvalues0.string_val(3));
  TEST_EXPECT_EQUAL("度超出", tvalues0.string_val(4));
  TEST_EXPECT_EQUAL("dim", tvalues0.string_val(5));

  TEST_EXPECT_EQUAL("测试", tvalues0.string_val(6));
  TEST_EXPECT_EQUAL("", tvalues0.string_val(7));
  TEST_EXPECT_EQUAL("", tvalues0.string_val(8));

  TEST_EXPECT_EQUAL("测试t", tvalues0.string_val(9));
  TEST_EXPECT_EQUAL("est", tvalues0.string_val(10));
  TEST_EXPECT_EQUAL("", tvalues0.string_val(11));

  TEST_ASSERT_EQUAL(2, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));
  TEST_EXPECT_EQUAL(2, tlen0.int_val(1));

  FUNC_TEST_END();
}
void test_utf8_split_to_list_1() {
  FUNC_TEST_START();
  std::string xml_fe_config = R"(
    <config>
        <features>
            <feature name="f13" type="utf8_split_to_list" source=".item_feature.item_feature_se.context.feature.pkg" sep="." filters="com,"/>
        </features>
    </config>
    )";

  std::string in_str = R"(
        <model_input_config>
            <input name="f13" shape="2" type="dense" />
        </model_input_config>
      )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(xml_fe_config, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8SplitToListConfig *config =
      dynamic_cast<Utf8SplitToListConfig *>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample *item =
      request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["pkg"]
      .mutable_bytes_list()
      ->add_value("com.tEst.galLery");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  const auto &map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"test", "gallery"}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto &map = ret.inputs();
  auto itr0 = map.find("f13");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_LIST_STRING(({"test", "gallery"}), itr0->second);

  FUNC_TEST_END();
}

void test_utf8_split_to_list_2() {
    FUNC_TEST_START();
    std::string xml_fe_config = R"(
      <config>
          <features>
              <feature name="f13" type="utf8_split_to_list" source=".item_feature.item_feature_se.feature_lists.feature_list.appid" sep="." filters="com,net"/>
          </features>
      </config>
      )";
  
    std::string in_str = R"(
          <model_input_config>
              <input name="f13" shape="1,2,2" type="sequence" />
          </model_input_config>
        )";
  
    std::vector<std::shared_ptr<Config>> vec;
    XmlConfigMgr::parse_from_string(xml_fe_config, "", "", vec);
  
    TEST_ASSERT_EQUAL(1, vec.size());
    Utf8SplitToListConfig *config =
        dynamic_cast<Utf8SplitToListConfig *>(vec[0].get());
    TEST_ASSERT_BOOL(nullptr != config);
  
    std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
    ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
  
    TEST_ASSERT_EQUAL(1, in_vec.size());
    TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
  
    google::protobuf::Arena arena;
    qinglong::FeRequest request;
    qinglong::BatchSequenceExample batch_ret;
    qinglong::PredictRequest ret;
  
    // item
    tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
    auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
    tensorflow::Feature* fate = feat_list.add_feature();
    fate->mutable_bytes_list()->add_value("com.tEst.galLery");
    fate = feat_list.add_feature();
    fate->mutable_bytes_list()->add_value("net.test.Gpdd");
  
    toSequenceExample(&arena, request, vec, batch_ret);
    TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
    TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
    const auto &map00 = batch_ret.batch(0).feature_lists().feature_list();
    auto itr00 = map00.find("f13");
  
    TEST_ASSERT_BOOL(itr00 != map00.end());
    TEST_FEATURE_LIST_STR(({{"test", "gallery"},{"test","gpdd"}}), itr00->second);
  
    std::vector<std::shared_ptr<Config>> need_vec;
    selectConfigUsingModelInput(vec, in_vec, need_vec);
    toPredictRequest(&arena, request, need_vec, in_vec, ret);
  
    auto &map = ret.inputs();
    auto itr0 = map.find("f13");
    auto itr_len0 = map.find("f13_length");
  
    TEST_ASSERT_BOOL(itr0 != map.end());
    TEST_ASSERT_BOOL(itr_len0 != map.end());
    TEST_ASSERT_EQUAL(itr_len0->second.int_val_size(), 1);
    TEST_ASSERT_EQUAL(itr_len0->second.int_val(0), 2);
    TEST_ASSERT_EQUAL(itr0->second.string_val(0), "test");
    TEST_ASSERT_EQUAL(itr0->second.string_val(1), "gallery");
    TEST_ASSERT_EQUAL(itr0->second.string_val(2), "test");
    TEST_ASSERT_EQUAL(itr0->second.string_val(3), "gpdd");

    FUNC_TEST_END();
  }

void test_utf8_ip_to_list_1() {
  FUNC_TEST_START();
    std::string xml_fe_config = R"(
        <config>
            <features>
                <feature name="f13" type="utf8_ip_to_list" source=".item_feature.item_feature_se.context.feature.pkg" sep="." />
            </features>
        </config>
        )";
    
      std::string in_str = R"(
            <model_input_config>
                <input name="f13" shape="2" type="dense" />
            </model_input_config>
          )";
    
      std::vector<std::shared_ptr<Config>> vec;
      XmlConfigMgr::parse_from_string(xml_fe_config, "", "", vec);
    
      TEST_ASSERT_EQUAL(1, vec.size());
      Utf8IpToListConfig *config =
          dynamic_cast<Utf8IpToListConfig *>(vec[0].get());
      TEST_ASSERT_BOOL(nullptr != config);
    
      std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
      ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
    
      TEST_ASSERT_EQUAL(1, in_vec.size());
      TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
    
      google::protobuf::Arena arena;
      qinglong::FeRequest request;
      qinglong::BatchSequenceExample batch_ret;
      qinglong::PredictRequest ret;
    
      // item
      tensorflow::SequenceExample *item =
          request.add_item_feature()->mutable_item_feature_se();
      (*(item->mutable_context()->mutable_feature()))["pkg"]
          .mutable_bytes_list()
          ->add_value("com.test.gallery");
    
      toSequenceExample(&arena, request, vec, batch_ret);
      TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
      TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
      const auto &map00 = batch_ret.batch(0).context().feature();
      auto itr00 = map00.find("f13");
    
      TEST_ASSERT_BOOL(itr00 != map00.end());
      TEST_FEATURE_STR(({"com.test", "com.test.gallery"}), itr00->second);
    
      std::vector<std::shared_ptr<Config>> need_vec;
      selectConfigUsingModelInput(vec, in_vec, need_vec);
      toPredictRequest(&arena, request, need_vec, in_vec, ret);
    
      auto &map = ret.inputs();
      auto itr0 = map.find("f13");
      TEST_ASSERT_BOOL(itr0 != map.end());
      TEST_LIST_STRING(({"com.test", "com.test.gallery"}), itr0->second);
      FUNC_TEST_END();
}

void test_utf8_ip_to_list_2() {
  FUNC_TEST_START();
    std::string xml_fe_config = R"(
        <config>
            <features>
                <feature name="f13" type="utf8_ip_to_list" source=".item_feature.item_feature_se.context.feature.pkg" sep="." />
            </features>
        </config>
        )";
    
      std::string in_str = R"(
            <model_input_config>
                <input name="f13" shape="1" type="dense" />
            </model_input_config>
          )";
    
      std::vector<std::shared_ptr<Config>> vec;
      XmlConfigMgr::parse_from_string(xml_fe_config, "", "", vec);
    
      TEST_ASSERT_EQUAL(1, vec.size());
      Utf8IpToListConfig *config =
          dynamic_cast<Utf8IpToListConfig *>(vec[0].get());
      TEST_ASSERT_BOOL(nullptr != config);
    
      std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
      ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
    
      TEST_ASSERT_EQUAL(1, in_vec.size());
      TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
    
      google::protobuf::Arena arena;
      qinglong::FeRequest request;
      qinglong::BatchSequenceExample batch_ret;
      qinglong::PredictRequest ret;
    
      // item
      tensorflow::SequenceExample *item =
          request.add_item_feature()->mutable_item_feature_se();
      (*(item->mutable_context()->mutable_feature()))["pkg"]
          .mutable_bytes_list()
          ->add_value("com_test_gallery_");
    
      toSequenceExample(&arena, request, vec, batch_ret);
      TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
      TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
      const auto &map00 = batch_ret.batch(0).context().feature();
      auto itr00 = map00.find("f13");
    
      TEST_ASSERT_BOOL(itr00 != map00.end());

      TEST_FEATURE_STR(({"com_test_gallery_"}), itr00->second);
    
      std::vector<std::shared_ptr<Config>> need_vec;
      selectConfigUsingModelInput(vec, in_vec, need_vec);
      toPredictRequest(&arena, request, need_vec, in_vec, ret);
    
      auto &map = ret.inputs();
      auto itr0 = map.find("f13");
      TEST_ASSERT_BOOL(itr0 != map.end());
      TEST_LIST_STRING(({"com_test_gallery_"}), itr0->second);
      
      FUNC_TEST_END();
}
//feature
void test_utf8_coincide_1() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_coincide",
          "source": [
              ".item_feature.item_feature_se.context.feature.query",
              ".item_feature.item_feature_se.context.feature.appname"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  // 将上面创建的config字符串和vec容器解析为json，然后填充默认值到config中
  JsonConfigMgr::parse_from_string(config_str, vec);
  // 检查config输入个数，一个f就是一个config，vec中存放指向config类的指针
  TEST_ASSERT_EQUAL(1, vec.size());
  // 指针转换
  Utf8CoincideConfig* config = dynamic_cast<Utf8CoincideConfig*>(vec[0].get());
  // 检查指针转换是否成功
  TEST_ASSERT_BOOL(nullptr != config);
  // 初始化输入的字符串
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  // 检查输入类型是否为sparse
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);
  // 创建一个ferequest
  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  // add_item_feature返回一个指针，需要先解引用
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  // 给request添加item和入参
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("抖音火山");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("dadfasf地64364536串火热抖那我跟325");
  (*(item->mutable_context()->mutable_feature()))["appname"].mutable_bytes_list()->add_value("抖音");
  (*(item->mutable_context()->mutable_feature()))["appname"].mutable_bytes_list()->add_value("抖音");
  // 再添加一个item
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("cba");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("dadfasf地64364536串火热那我跟325");
  (*(item->mutable_context()->mutable_feature()))["appname"].mutable_bytes_list()->add_value("adcd");
  (*(item->mutable_context()->mutable_feature()))["appname"].mutable_bytes_list()->add_value("抖音");

  toSequenceExample(&arena, request, vec, batch_ret);
  // 检查是否只有两个item
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  // 检查item里面是否有内容
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  
  const auto& map0 = batch_ret.batch(0).context().feature();
  const auto& map1 = batch_ret.batch(1).context().feature();

  auto itr00 = map0.find("f13");
  auto itr10 = map1.find("f13");
  // 检查是否查询到f13，没查询到会将结尾返回给指针
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr10 != map1.end());
  // 取键值对的值，做比较
  TEST_FEATURE_STR(({"抖音", "抖"}), itr00->second);
  TEST_FEATURE_STR(({"ac", ""}), itr10->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({"抖音", "抖", "ac", ""}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

//featurelist
void test_utf8_coincide_2() {
  FUNC_TEST_START();

  std::string config_str = R"({
    "extract_features" : {
      "f13" : {
          "fe_type" : "uft8_coincide",
          "source": [
              ".item_feature.item_feature_se.feature_lists.feature_list.query",
              ".item_feature.item_feature_se.feature_lists.feature_list.appname"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 3, 1] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(config_str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8CoincideConfig* config = dynamic_cast<Utf8CoincideConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["query"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("");
  fate->mutable_bytes_list()->add_value("567");
  fate->mutable_bytes_list()->add_value("");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("cj19测sad45686试验a1");
  fate->mutable_bytes_list()->add_value("试15id(验+56ds测cd453asf量2!");
  fate->mutable_bytes_list()->add_value("试验");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appname"];
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("");
   fate->mutable_bytes_list()->add_value("");
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("测试");
  fate->mutable_bytes_list()->add_value("测试");
  fate->mutable_bytes_list()->add_value("测试试验");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"", "", ""}, {"测试", "测试", "试试验"}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"", "", "", "测试", "测试", "试试验"}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  FUNC_TEST_END();
}

void test_utf8_filter_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_filter" source=".item_feature.item_feature_se.context.feature.app_id" length="1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8FilterConfig* config = dynamic_cast<Utf8FilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("test");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("t");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("看");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("报纸");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"test"}), itr00->second);
  TEST_FEATURE_STR(({"报纸"}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), ({"test", "报纸"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_utf8_filter_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_filter" source=".item_feature.item_feature_se.feature_lists.feature_list.app_id" length="1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,2,1" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8FilterConfig* config = dynamic_cast<Utf8FilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["app_id"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("。");
  fate->mutable_bytes_list()->add_value("￥");
  fate->mutable_bytes_list()->add_value("：");
  fate->mutable_bytes_list()->add_value("\t");
  fate->mutable_bytes_list()->add_value("！");
  fate->mutable_bytes_list()->add_value("——");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("我");
  fate->mutable_bytes_list()->add_value("来到");
  fate->mutable_bytes_list()->add_value("中国");
  fate->mutable_bytes_list()->add_value("了");
  fate->mutable_bytes_list()->add_value("吗");
  fate->mutable_bytes_list()->add_value("？");
  fate->mutable_bytes_list()->add_value("\n");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_FEATURE_LIST_STR(({{"——"}, {"来到", "中国"}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"——", "", "来到", "中国"}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  FUNC_TEST_END();
}

void test_utf8_filter_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_filter" source=".item_feature.item_feature_se.feature_lists.feature_list.app_id" length="2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,2,1" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8FilterConfig* config = dynamic_cast<Utf8FilterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["app_id"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("。");
  fate->mutable_bytes_list()->add_value("￥");
  fate->mutable_bytes_list()->add_value("：");
  fate->mutable_bytes_list()->add_value("\t");
  fate->mutable_bytes_list()->add_value("！");
  fate->mutable_bytes_list()->add_value("——");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("我");
  fate->mutable_bytes_list()->add_value("来到");
  fate->mutable_bytes_list()->add_value("中国");
  fate->mutable_bytes_list()->add_value("了");
  fate->mutable_bytes_list()->add_value("吗");
  fate->mutable_bytes_list()->add_value("？");
  fate->mutable_bytes_list()->add_value("\n");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_FEATURE_LIST_STR(({{"。", "￥", "：", "\t", "！"}, {"我", "了", "吗", "？", "\n"}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"。", "￥", "我", "了"}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  FUNC_TEST_END();
}

void test_utf8_get_prefix_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_get_prefix" source=".item_feature.item_feature_se.context.feature.app_id" max_size="10" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8GetPrefixConfig* config = dynamic_cast<Utf8GetPrefixConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("test");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("t");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("看");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("报纸");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("游戏1中心");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"t", "te", "tes"}), itr00->second);
  TEST_FEATURE_STR(({"报","游", "游戏", "游戏1", "游戏1中"}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1, 1, 2, 1, 3, 1, 4}), ({2, 5}), ({"t", "te", "tes", "报","游", "游戏", "游戏1", "游戏1中"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_utf8_get_prefix_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_get_prefix" source=".item_feature.item_feature_se.feature_lists.feature_list.app_id" max_size="3" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,3,1" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8GetPrefixConfig* config = dynamic_cast<Utf8GetPrefixConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["app_id"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("中国国际论坛");

  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("倒春寒");
  fate->mutable_bytes_list()->add_value("特大级台风登陆");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_FEATURE_LIST_STR(({{"中", "中国", "中国国"}, {"倒", "倒春", "特", "特大", "特大级"}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"中", "中国", "中国国", "倒", "倒春", "特"}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  FUNC_TEST_END();
}

void test_utf8_get_re_result_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_get_re_result" source=".item_feature.item_feature_se.context.feature.app_id" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8GetReresultConfig* config = dynamic_cast<Utf8GetReresultConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("a1中文!@#");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("🍎→★"); //特殊符号过滤
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("\xE4\xB8"); //错误字节处理
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("123abcDEF");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"a1中文", ""}), itr00->second);
  TEST_FEATURE_STR(({"","123abcdef"}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({"a1中文", "", "","123abcdef"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_utf8_get_re_result_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_get_re_result" source=".item_feature.item_feature_se.feature_lists.feature_list.app_id" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,1,1" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8GetReresultConfig* config = dynamic_cast<Utf8GetReresultConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["app_id"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("");

  fate = feat_list.add_feature();

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_FEATURE_LIST_STR(({{""}, {}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"", ""}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  FUNC_TEST_END();
}

void test_utf8_cross() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f3" type="utf8_distance" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" cross="true" />
            <feature name="f4" type="utf8_is_contains" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" cross="true" />
            <feature name="f5" type="utf8_is_equal" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" cross="true" />
            <feature name="f6" type="utf8_is_prefix" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" cross="true" />
            <feature name="f7" type="utf8_join" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.item_feature.item_feature_se.feature_lists.feature_list.num" delimiter="-" cross="true" />
            <feature name="f8" type="utf8_public_prefix_length" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" cross="true" />
            <feature name="f9" type="utf8_coincide" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" cross="true" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f3" shape="1,1,5" type="sequence" />
        <input name="f4" shape="1,1,5" type="sequence" />
        <input name="f5" shape="1,1,5" type="sequence" />
        <input name="f6" shape="1,1,5" type="sequence" />
        <input name="f7" shape="1,1,5" type="sequence" />
        <input name="f8" shape="1,1,5" type="sequence" />
        <input name="f9" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(7, vec.size());
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(7, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");
  pb_info->set_event_time(20);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");
  pb_info->set_event_time(30);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");
  pb_info->set_event_time(40);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("pre");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("precase");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("recade");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["num"];
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value(5);
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value(6);

  item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list3 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("preall");
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("pre");
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("prace");

  auto& feat_list4 = (*(item->mutable_feature_lists()->mutable_feature_list()))["num"];
  fate = feat_list4.add_feature();
  fate->mutable_int64_list()->add_value(5);
  fate = feat_list4.add_feature();
  fate->mutable_int64_list()->add_value(8);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map1 = batch_ret.batch(1).feature_lists().feature_list();

  auto itr00 = map0.find("f3");
  auto itr10 = map1.find("f3");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_FEATURE_LIST_INT64(({{0}, {4}, {5}}), itr00->second);
  TEST_FEATURE_LIST_INT64(({{3}, {0}, {2}}), itr10->second);

  auto itr01 = map0.find("f4");
  auto itr11 = map1.find("f4");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());
  TEST_FEATURE_LIST_INT64(({{1}, {0}, {0}}), itr01->second);
  TEST_FEATURE_LIST_INT64(({{0}, {1}, {0}}), itr11->second);

  auto itr02 = map0.find("f5");
  auto itr12 = map1.find("f5");
  TEST_ASSERT_BOOL(itr02 != map0.end());
  TEST_ASSERT_BOOL(itr12 != map1.end());
  TEST_FEATURE_LIST_INT64(({{1}, {0}, {0}}), itr02->second);
  TEST_FEATURE_LIST_INT64(({{0}, {1}, {0}}), itr12->second);

  auto itr03 = map0.find("f6");
  auto itr13 = map1.find("f6");
  TEST_ASSERT_BOOL(itr03 != map0.end());
  TEST_ASSERT_BOOL(itr13 != map1.end());
  TEST_FEATURE_LIST_INT64(({{1}, {0}, {0}}), itr03->second);
  TEST_FEATURE_LIST_INT64(({{0}, {1}, {0}}), itr13->second);

  auto itr04 = map0.find("f7");
  auto itr14 = map1.find("f7");
  TEST_ASSERT_BOOL(itr04 != map0.end());
  TEST_ASSERT_BOOL(itr14 != map1.end());
  TEST_FEATURE_LIST_STR(({{"20-5"}, {"30-6"}}), itr04->second);
  TEST_FEATURE_LIST_STR(({{"20-5"}, {"30-8"}}), itr14->second);

  auto itr05 = map0.find("f8");
  auto itr15 = map1.find("f8");
  TEST_ASSERT_BOOL(itr05 != map0.end());
  TEST_ASSERT_BOOL(itr15 != map1.end());
  TEST_FEATURE_LIST_INT64(({{3}, {3}, {0}}), itr05->second);
  TEST_FEATURE_LIST_INT64(({{3}, {3}, {2}}), itr15->second);

  auto itr06 = map0.find("f9");
  auto itr16 = map1.find("f9");
  TEST_ASSERT_BOOL(itr06 != map0.end());
  TEST_ASSERT_BOOL(itr16 != map1.end());
  TEST_FEATURE_LIST_STR(({{"pre"}, {"pree"}, {"ree"}}), itr06->second);
  TEST_FEATURE_LIST_STR(({{"pre"}, {"pre"}, {"pre"}}), itr16->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f3");
  auto itr_len0 = map.find("f3_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({0, 4, 5, 3, 0, 2}), itr0->second);
  TEST_LIST_INT32(({3, 3}), itr_len0->second);

  auto itr1 = map.find("f4");
  auto itr_len1 = map.find("f4_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({1, 0, 0, 0, 1, 0}), itr1->second);
  TEST_LIST_INT32(({3, 3}), itr_len1->second);

  auto itr2 = map.find("f5");
  auto itr_len2 = map.find("f5_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({1, 0, 0, 0, 1, 0}), itr2->second);
  TEST_LIST_INT32(({3, 3}), itr_len2->second);

  auto itr3 = map.find("f6");
  auto itr_len3 = map.find("f6_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_INT64(({1, 0, 0, 0, 1, 0}), itr3->second);
  TEST_LIST_INT32(({3, 3}), itr_len3->second);

  auto itr4 = map.find("f7");
  auto itr_len4 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr4 != map.end());
  TEST_ASSERT_BOOL(itr_len4 != map.end());
  TEST_LIST_STRING(({"20-5", "30-6", "20-5", "30-8"}), itr4->second);
  TEST_LIST_INT32(({2, 2}), itr_len4->second);

  auto itr5 = map.find("f8");
  auto itr_len5 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr5 != map.end());
  TEST_ASSERT_BOOL(itr_len5 != map.end());
  TEST_LIST_INT64(({3, 3, 0, 3, 3, 2}), itr5->second);
  TEST_LIST_INT32(({3, 3}), itr_len5->second);

  auto itr6 = map.find("f9");
  auto itr_len6 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr6 != map.end());
  TEST_ASSERT_BOOL(itr_len6 != map.end());
  TEST_LIST_STRING(({"pre", "pree", "ree", "pre", "pre", "pre"}), itr6->second);
  TEST_LIST_INT32(({3, 3}), itr_len6->second);

  FUNC_TEST_END();
}
void test_utf8_repetition_string_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_repetition_string" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8RepetitionStringConfig* config = dynamic_cast<Utf8RepetitionStringConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");
  pb_info->set_event_time(20);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");
  pb_info->set_event_time(30);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");
  pb_info->set_event_time(40);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("pre");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("precase");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("recade");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["num"];
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value(5);
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value(6);

  item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list3 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("preall");
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("pre");
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("prace");

  auto& feat_list4 = (*(item->mutable_feature_lists()->mutable_feature_list()))["num"];
  fate = feat_list4.add_feature();
  fate->mutable_int64_list()->add_value(5);
  fate = feat_list4.add_feature();
  fate->mutable_int64_list()->add_value(8);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map1 = batch_ret.batch(1).feature_lists().feature_list();

  auto itr00 = map0.find("f15");
  auto itr10 = map1.find("f15");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_FEATURE_LIST_FLOAT(({{1.000000}, {0.769800}, {0.612372}}), itr00->second);
  TEST_FEATURE_LIST_FLOAT(({{0.612372}, {1.000000}, {0.774597}}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f15");
  auto itr_len0 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_FLOAT(({1.0000, 0.769800, 0.612372, 0.612372, 1.0000, 0.774597}), itr0->second);
  TEST_LIST_INT32(({3, 3}), itr_len0->second);

  FUNC_TEST_END();
}

void test_utf8_repetition_string_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f15" type="utf8_repetition_string" source=".item_feature.item_feature_se.context.feature.query,.item_feature.item_feature_se.context.feature.appname" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f15" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  Utf8RepetitionStringConfig* config = dynamic_cast<Utf8RepetitionStringConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("天天天气");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("王者王者");
  (*(item->mutable_context()->mutable_feature()))["appname"].mutable_bytes_list()->add_value("天气");
  (*(item->mutable_context()->mutable_feature()))["appname"].mutable_bytes_list()->add_value("王者王者");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("cwb测试");
  (*(item->mutable_context()->mutable_feature()))["query"].mutable_bytes_list()->add_value("dadfasf地64364536串火热那我跟325");
  (*(item->mutable_context()->mutable_feature()))["appname"].mutable_bytes_list()->add_value("cb测试");
  (*(item->mutable_context()->mutable_feature()))["appname"].mutable_bytes_list()->add_value("64364dad536串火热325那地我跟fasf");

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f15");
  auto itr10 = map01.find("f15");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_FLOAT(({0.894427, 1.000000}), itr00->second);
  TEST_FEATURE_FLOAT(({0.894427, 1.000000}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f15_values");
  auto itr_indices0 = map.find("f15_indices");
  auto itr_dense_shape0 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({0.894427, 1.000000, 0.894427, 1.000000}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_utf8_prefix_repetition_string_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f3" type="utf8_prefix_repetition_string" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" cross="true" />
            <feature name="f4" type="utf8_prefix_repetition_string" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.item_feature.item_feature_se.feature_lists.feature_list.appid" cross="false" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f3" shape="1,1,5" type="sequence" />
        <input name="f4" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("pre");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("pre");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("precase");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("recade");


  item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list3 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("preall");
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("pre");
  fate = feat_list3.add_feature();
  fate->mutable_bytes_list()->add_value("prace");


  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map1 = batch_ret.batch(1).feature_lists().feature_list();

  auto itr00 = map0.find("f3");
  auto itr10 = map1.find("f3");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_FEATURE_LIST_FLOAT(({{1.0}, {0.4285714}, {0.0}}), itr00->second);
  TEST_FEATURE_LIST_FLOAT(({{0.5}, {1.0}, {0.4}}), itr10->second);

  auto itr01 = map0.find("f4");
  auto itr11 = map1.find("f4");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());
  TEST_FEATURE_LIST_FLOAT(({{1.0}, {0.4285714}, {0.0}}), itr01->second);
  TEST_FEATURE_LIST_FLOAT(({{1.0}, {0.4285714}, {0.0}}), itr11->second);

 
  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f3");
  auto itr_len0 = map.find("f3_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_FLOAT(({1.0, 0.4285714, 0.0, 0.5, 1.0, 0.4}), itr0->second);
  TEST_LIST_INT32(({3, 3}), itr_len0->second);

  auto itr1 = map.find("f4");
  auto itr_len1 = map.find("f4_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_FLOAT(({1.0, 0.4285714, 0.0, 1.0, 0.4285714, 0.0}), itr1->second);
  TEST_LIST_INT32(({3, 3}), itr_len1->second);

  FUNC_TEST_END();
}

//feature
void test_utf8_prefix_repetition_string_2() {
  FUNC_TEST_START();

   std::string config_str = R"(
    <config>
        <features>
            <feature name="f3" type="utf8_prefix_repetition_string" source=".item_feature.item_feature_se.context.feature.appid,.item_feature.item_feature_se.context.feature.item"/>
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f3" shape="1,1,5" type="sparse" />
    </model_input_config>
  )";


  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("123");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("567");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("1234");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("测a试试验1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("前缀repetition重复度");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("测试");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("前缀repetition长度");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f3");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_ASSERT_EQUAL(2, itr00->second.float_list().value_size());
  TEST_EXPECT_EQUAL(0.75, itr00->second.float_list().value(0));
  TEST_EXPECT_EQUAL(0.0, itr00->second.float_list().value(1));

  const auto& map01 = batch_ret.batch(1).context().feature();
  auto itr01 = map01.find("f3");
  TEST_ASSERT_BOOL(itr01 != map01.end());

  TEST_ASSERT_EQUAL(2, itr01->second.float_list().value_size());
  TEST_EXPECT_EQUAL(0.166666667, itr01->second.float_list().value(0));
  TEST_EXPECT_EQUAL(0.8, itr01->second.float_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f3_values");
  auto itr_indices0 = map.find("f3_indices");
  auto itr_dense_shape0 = map.find("f3_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.float_val_size());
  TEST_EXPECT_EQUAL(0.75, tvalues0.float_val(0));
  TEST_EXPECT_EQUAL(0.0, tvalues0.float_val(1));
  TEST_EXPECT_EQUAL(0.166666667, tvalues0.float_val(2));
  TEST_EXPECT_EQUAL(0.8, tvalues0.float_val(3));

  TEST_ASSERT_EQUAL(8, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(6));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  FUNC_TEST_END();
}

// featurelist
void test_utf8_prefix_repetition_string_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f3" type="utf8_prefix_repetition_string" source=".item_feature.item_feature_se.feature_lists.feature_list.appid,.item_feature.item_feature_se.feature_lists.feature_list.item"/>
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f3" shape="1,2,1" type="sequence" />
    </model_input_config>
  )";


  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("567");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("测试1@~2k#j试验1");
  fate->mutable_bytes_list()->add_value("距离");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate->mutable_bytes_list()->add_value("56");
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("测试");
  fate->mutable_bytes_list()->add_value(" 距离变换");

  qinglong::BatchSequenceExample batch_ret;
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f3");
  TEST_ASSERT_BOOL(itr00 != map00.end());

  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).float_list().value_size());
  TEST_EXPECT_EQUAL(1.0, list.feature(0).float_list().value(0));
  TEST_EXPECT_EQUAL(0.66666667, list.feature(0).float_list().value(1));
  TEST_ASSERT_EQUAL(2, list.feature(1).float_list().value_size());
  TEST_EXPECT_EQUAL(0.16666667, list.feature(1).float_list().value(0));
  TEST_EXPECT_EQUAL(0.0, list.feature(1).float_list().value(1));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f3");
  auto itr_len0 = map.find("f3_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(4, tvalues0.float_val_size());
  TEST_EXPECT_EQUAL(1.0, tvalues0.float_val(0));
  TEST_EXPECT_EQUAL(0.66666667, tvalues0.float_val(1));
  TEST_EXPECT_EQUAL(0.16666667, tvalues0.float_val(2));
  TEST_EXPECT_EQUAL(0.0, tvalues0.float_val(3));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  FUNC_TEST_END();
}

void test_utf8() {
  test_utf8_distance_1();
  test_utf8_distance_2();

  test_utf8_is_contains_1();
  test_utf8_is_contains_2();

  test_utf8_is_equal_1();
  test_utf8_is_equal_2();

  test_utf8_is_prefix_1();
  test_utf8_is_prefix_2();
  
  test_utf8_join_1();
  test_utf8_join_2();

  test_utf8_public_prefix_length_1();
  test_utf8_public_prefix_length_2();

  test_utf8_length_1();
  test_utf8_length_2();

  test_utf8_preprocess_1();
  test_utf8_preprocess_2();

  test_utf8_split_1();
  test_utf8_split_2();

  test_utf8_split_to_list_1();
  test_utf8_split_to_list_2();
  test_utf8_ip_to_list_1();
  test_utf8_ip_to_list_2();

  test_utf8_coincide_1();
  test_utf8_coincide_2();

  test_utf8_filter_1();
  test_utf8_filter_2();
  test_utf8_filter_3();

  test_utf8_get_prefix_1();
  test_utf8_get_prefix_2();

  test_utf8_get_re_result_1();
  test_utf8_get_re_result_2();

  test_utf8_cross();

  test_utf8_repetition_string_1();
  test_utf8_repetition_string_2();

  test_utf8_prefix_repetition_string_1();
  test_utf8_prefix_repetition_string_2();
  test_utf8_prefix_repetition_string_3();
}