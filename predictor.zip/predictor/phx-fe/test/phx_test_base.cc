#include "phx_test.h"
#include "phx-fe/src/framework.h"
#include "phx-fe/src/service.h"
#include "phx-fe/util/farmhash.h"
#include "phx-fe/util/math.h"
#include "phx-fe/util/murmur_hash3.h"
#include "phx-fe/util/mock_utils.h"
#include <cstdint>
#include <string>

// base类算子
TEST_SUITE("base") {
    TEST_CASE("default_input_value") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811,10812,10813,10814,10815,10816" />
            </versions>
            <config>
                <features default_input_int64="-1" default_input_float="-1" default_input_str="empty" >
                    <feature name="10811"
                        slot="10811"
                        type="direct"
                        source=".fe_request.item_fea.item_info.creative_id"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="direct"
                        source=".fe_request.item_fea.item_info.creative_id"
                        default_input_int64="0"
                        />
                    <feature name="10813"
                        slot="10813"
                        type="direct"
                        source=".fe_request.item_fea.item_info.rta_id"
                        />
                    <feature name="10814"
                        slot="10814"
                        type="direct"
                        source=".fe_request.item_fea.item_info.rta_id"
                        default_input_str="1"
                        />
                    <feature name="10815"
                        slot="10815"
                        type="direct"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                        />
                    <feature name="10816"
                        slot="10816"
                        type="direct"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr"
                        default_input_float="0"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();
        fe_request->add_item_fea();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 6);

        TEST_SLOT_FEATURE_INT64(10811, ({-1}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_INT64(10812, ({0}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_STR(10813, ({"empty"}), ret.training_samples(0).features(2));
        TEST_SLOT_FEATURE_STR(10814, ({"1"}), ret.training_samples(0).features(3));
        TEST_SLOT_FEATURE_FLOAT(10815, ({-1}), ret.training_samples(0).features(4));
        TEST_SLOT_FEATURE_FLOAT(10816, ({0}), ret.training_samples(0).features(5));
    }

    TEST_CASE("direct") {
        MESSAGE("direct start...");

        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="direct"
                        source=".fe_request.item_fea.item_info.rta_id"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("900778570");

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("104436666");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        std::string json_string;
        google::protobuf::util::MessageToJsonString(ret, &json_string);
        std::cout << "ret = " << json_string << std::endl;

        const std::vector<std::string> vec{"900778570", "104436666"};

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        CHECK_EQ(ret.training_samples(0).features(0).bytes_list_size(), 1);
        CHECK(ret.training_samples(0).features(0).bytes_list(0) == vec[0]);

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        CHECK_EQ(ret.training_samples(1).features(0).bytes_list_size(), 1);
        CHECK(ret.training_samples(1).features(0).bytes_list(0) == vec[1]);

        std::cout << ret.DebugString() << std::endl;

        MESSAGE("direct end...");
    }

    TEST_CASE("test_direct_repeated") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10813" slot="10813" type="direct" source=".fe_request.context.info_flow_context.info_flow_item.filter_words.id" />
                    <feature name="10814" slot="10814" type="direct" source=".fe_request.context.info_flow_context.info_flow_item.filter_words.name" />
                    <feature name="10815" slot="10815" type="direct" source=".fe_request.ad_query_ad_topdl_appid_offline.query_ad_appid_sequence_7day" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *info_flow_context = fe_request.mutable_context()->mutable_info_flow_context();
        auto *info_flow_item = info_flow_context->add_info_flow_item();
        info_flow_item = info_flow_context->add_info_flow_item();
        auto *filter_words = info_flow_item->add_filter_words();

        info_flow_item = info_flow_context->add_info_flow_item();
        info_flow_item = info_flow_context->add_info_flow_item();
        filter_words = info_flow_item->add_filter_words();
        info_flow_item = info_flow_context->add_info_flow_item();

        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10813, ({"", ""}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10814, ({"", ""}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(0).features(2));
    }

    TEST_CASE("direct_to_feature") {
        MESSAGE("direct_to_feature start...");

        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    source=".fe_request.item_fea.item_info.rta_id"
                    />
            </features>
        </config>
  )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("900778570");

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("104436666");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        std::string json_string;
        google::protobuf::util::MessageToJsonString(ret, &json_string);
        std::cout << "ret = " << json_string << std::endl;

        const std::vector<std::string> vec{"900778570", "104436666"};

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        CHECK_EQ(ret.training_samples(0).features(0).bytes_list_size(), 1);
        CHECK(ret.training_samples(0).features(0).bytes_list(0) == vec[0]);

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        CHECK_EQ(ret.training_samples(1).features(0).bytes_list_size(), 1);
        CHECK(ret.training_samples(1).features(0).bytes_list(0) == vec[1]);

        std::cout << ret.DebugString() << std::endl;

        MESSAGE("direct_to_feature end...");
    }

    TEST_CASE("direct_to_feature_2") {
        std::string config_str = R"(
            <versions>
            <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10813,10814,10815" />
            </versions>
            <config>
                <features>
                    <feature name="10813" slot="10813" type="direct_to_feature" source=".fe_request.context.info_flow_context.info_flow_item.filter_words.id" />
                    <feature name="10814" slot="10814" type="direct_to_feature" source=".fe_request.context.info_flow_context.info_flow_item.filter_words.name" />
                    <feature name="10815" slot="10815" type="direct_to_feature" source=".fe_request.ad_query_ad_topdl_appid_offline.query_ad_appid_sequence_7day" />
                </features>
            </config>
          )";

        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);

        auto *info_flow_context = fe_request.mutable_context()->mutable_info_flow_context();
        auto *info_flow_item = info_flow_context->add_info_flow_item();
        info_flow_item = info_flow_context->add_info_flow_item();
        auto *filter_words = info_flow_item->add_filter_words();

        info_flow_item = info_flow_context->add_info_flow_item();
        info_flow_item = info_flow_context->add_info_flow_item();
        filter_words = info_flow_item->add_filter_words();
        info_flow_item = info_flow_context->add_info_flow_item();

        fe_request.add_item_fea();

        auto ptr = init_xml_offline_by_content_new_sample(config_str.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);
        auto fe_request_str = fe_request.SerializeAsString();

        auto user_action_str = user_action.SerializeAsString();
        auto batch_training_sample_str =
                to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(), user_action_str.c_str(),
                                      user_action_str.size(), config_handle);
        phx::BatchTrainingSample ret{};
        ret.ParseFromArray(batch_training_sample_str.c_str(), batch_training_sample_str.size());

        REQUIRE_EQ(ret.training_samples_size(), 1);
        REQUIRE_EQ(ret.training_samples(0).features_size(), 3);

        TEST_SLOT_FEATURE_STR(10813, ({"", ""}), ret.training_samples(0).features(0));
        TEST_SLOT_FEATURE_STR(10814, ({"", ""}), ret.training_samples(0).features(1));
        TEST_SLOT_FEATURE_INT64(10815, ({}), ret.training_samples(0).features(2));
    }

    TEST_CASE("direct_to_feature_3") {
        const std::string xml_content_string = R"(
        <versions>
        <version name="union_ctr" dict="appInfo" value="10811" />
        </versions>
        <config>
            <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    source=".fe_request.item_fea.item_info.rta_id"
                    />
            </features>
        </config>
  )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("900778570");

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("104436666");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        std::string json_string;
        google::protobuf::util::MessageToJsonString(ret, &json_string);
        std::cout << "ret = " << json_string << std::endl;

        const std::vector<std::string> vec{"900778570", "104436666"};

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        CHECK_EQ(ret.training_samples(0).features(0).bytes_list_size(), 1);
        CHECK(ret.training_samples(0).features(0).bytes_list(0) == vec[0]);

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        CHECK_EQ(ret.training_samples(1).features(0).bytes_list_size(), 1);
        CHECK(ret.training_samples(1).features(0).bytes_list(0) == vec[1]);
    }

    TEST_CASE("stat_smooth_ctr") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                 />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />
                <source name="item_info"
                    value=".fe_request.item_fea.item_info" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="stat_smooth_ctr"
                        source="item_info.ocpx_sbp,item_info.data_source"
                        min_expo="1"
                        default_value="-1.1"
                        alpha="1"
                        beta="10"
                        />

                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;

        auto fe_ptr = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        auto &fe_request = *fe_ptr;
        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1110);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(1111);
        ad_user_app_info->set_count(20);

        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20001);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20002);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
        item_fea->mutable_item_info()->set_creative_id(1110);
        item_fea->mutable_item_info()->set_ocpx_sbp(2);
        item_fea->mutable_item_info()->set_data_source(7);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");
        item_fea->mutable_item_info()->set_creative_id(1111);
        item_fea->mutable_item_info()->set_ocpx_sbp(3);
        item_fea->mutable_item_info()->set_data_source(8);

        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("236");
        item_fea->mutable_item_info()->set_creative_id(1112);
        item_fea->mutable_item_info()->set_ocpx_sbp(10);
        item_fea->mutable_item_info()->set_data_source(0);
        auto fe_str = fe_ptr->SerializeAsString();

        auto user_action_ptr = google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action_ptr->add_user_action_item_info();
        user_action_ptr->add_user_action_item_info();
        user_action_ptr->add_user_action_item_info();
        auto user_action_str = user_action_ptr->SerializeAsString();

        auto batch_training_sample_str = to_training_sample_v2(fe_str.c_str(), fe_str.size(), user_action_str.c_str(),
                                                               user_action_str.size(), config_handle);
        phx::BatchTrainingSample training_sample;
        training_sample.ParseFromString(batch_training_sample_str);
        CHECK_EQ(training_sample.training_samples(0).features(0).weights(0), (float) 3 / 17);
        CHECK_EQ(training_sample.training_samples(1).features(0).weights(0), (float) 4 / 18);
        CHECK_EQ(training_sample.training_samples(2).features(0).weights(0), -1.1f);
        std::cout << "batch training sample = " << training_sample.DebugString();
        MESSAGE("stat_smooth_ctr end...");
    }

    TEST_CASE("versions_1") {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811"
                    labels="cvr_label_1,cvr_label_2"
                    weights="cvr_weights_1,cvr_weights_2"
                    extras_int64="ad_group_id"
                    extras_float="cvr_weights_1"
                    extras_bytes="req_id,rta_id"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            source=".user_action.user_action_item_info.sdk_lahuo_conversion_rate" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    source=".user_action.user_action_item_info.api_lahuo_conversion_rate" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        source=".fe_request.req_id"
                    />
                <feature name="rta_id"
                    type="direct_to_feature" 
                        source="item_info.rta_id"
                    />
                <feature name="ad_group_id"
                    type="direct_to_feature" 
                        source=".user_action.user_action_item_info.ad_group_id"
                    />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);

        fe_request->set_req_id("reqid0001");

        // extras_bytes
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features(0).signs_size(), 2);
        CHECK(ret.training_samples(0).features(0).signs(0) == 10001);
        CHECK(ret.training_samples(0).features(0).signs(1) == 10002);

        CHECK(ret.training_samples(1).features(0).signs_size() == 2);
        CHECK(ret.training_samples(1).features(0).signs(0) == 10001);
        CHECK(ret.training_samples(1).features(0).signs(1) == 10002);

        // std::cout << ret.DebugString() << std::endl;
    }



    TEST_CASE("versions_2") {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811"
                    labels="10811,ad_group_id"
                    weights="ad_group_id,cvr_weights_2"
                    item_extras_int64="ad_group_id"
                    item_extras_float="cvr_weights_1"
                    item_extras_bytes="req_id,rta_id"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            source=".user_action.user_action_item_info.sdk_lahuo_conversion_rate" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    source=".user_action.user_action_item_info.api_lahuo_conversion_rate" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        source=".fe_request.req_id"
                    />
                <feature name="rta_id"
                    type="direct_to_feature" 
                        source="item_info.rta_id"
                    />
                <feature name="ad_group_id"
                    type="direct_to_feature" 
                        source=".user_action.user_action_item_info.ad_group_id"
                    />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);

        fe_request->set_req_id("reqid0001");

        // extras_bytes
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features(0).signs_size(), 2);
        CHECK(ret.training_samples(0).features(0).signs(0) == 10001);
        CHECK(ret.training_samples(0).features(0).signs(1) == 10002);

        CHECK(ret.training_samples(1).features(0).signs_size() == 2);
        CHECK(ret.training_samples(1).features(0).signs(0) == 10001);
        CHECK(ret.training_samples(1).features(0).signs(1) == 10002);
        // std::cout << ret.DebugString() << std::endl;
    }

    TEST_CASE("ltr_test") {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811,10812,10813,10814,10815,10816"
                    labels="cvr_label_1,cvr_label_2"
                    weights="cvr_weights_1,cvr_weights_2,cvr_weights_3"
                    extras_int64="ad_group_id"
                    extras_float="cvr_weights_1"
                    extras_bytes="req_id,rta_id"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812"
                    slot="10812"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                    />
                <feature name="10813"
                    slot="10813"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.creative_id"
                    />
                <feature name="10814"
                    slot="10814"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.conv_type"
                    />
                <feature name="10815"
                    slot="10815"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="10816"
                    slot="10816"
                    attr="cross"
                    type="seq_hit_sum"
                    source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,item_info.appid"
                    start="0"
                    default_value="-2"
                    />

                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            attr="item"
                            source=".user_action.user_action_item_info.sdk_lahuo_conversion_rate" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_lahuo_conversion_rate" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="cvr_weights_3" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_register_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        attr="user"
                        source=".fe_request.req_id"
                    />
                <feature name="rta_id"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="ad_group_id"
                    type="direct_to_feature" 
                    attr="item"
                        source=".user_action.user_action_item_info.ad_group_id"
                    />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        
        // req_time
        fe_request->set_req_time((int64_t) 500);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(100);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(200);

        fe_request->set_req_id("reqid0001");

        fe_request->add_prerank_item_fea();
        fe_request->add_prerank_item_fea();

        // item_info
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea->mutable_item_info()->set_creative_id(10);
        item_fea->mutable_item_info()->set_conv_type(20);
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");
        item_fea->mutable_item_info()->set_creative_id(11);
        item_fea->mutable_item_info()->set_conv_type(21);
        item_fea->mutable_item_info()->set_appid(10002);

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info->set_api_register_conversion_rate(0.15);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        item_info->set_api_register_conversion_rate(0.25);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_ltr_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                       user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::LTRTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.user_features_size(), 2);
        CHECK_EQ(ret.user_features(0).slot_id(), 10811);
        CHECK_EQ(ret.user_features(0).signs_size(), 2);
        CHECK_EQ(ret.user_features(0).signs(0), 10001);
        CHECK_EQ(ret.user_features(0).signs(1), 10002);
        CHECK_EQ(ret.user_features(1).slot_id(), 10812);
        CHECK_EQ(ret.user_features(1).signs_size(), 2);
        CHECK_EQ(ret.user_features(1).signs(0), 100);
        CHECK_EQ(ret.user_features(1).signs(1), 200);

        CHECK_EQ(ret.item_features_size(), 4);
        CHECK_EQ(ret.item_features(0).slot_id(), 10813);
        CHECK_EQ(ret.item_features(0).features_size(), 2);
        CHECK_EQ(ret.item_features(0).features(0).slot_id(), 10813);
        CHECK_EQ(ret.item_features(0).features(0).signs_size(), 1);
        CHECK_EQ(ret.item_features(0).features(0).signs(0), 10);
        CHECK_EQ(ret.item_features(0).features(1).slot_id(), 10813);
        CHECK_EQ(ret.item_features(0).features(1).signs_size(), 1);
        CHECK_EQ(ret.item_features(0).features(1).signs(0), 11);

        CHECK_EQ(ret.item_features(1).slot_id(), 10814);
        CHECK_EQ(ret.item_features(1).features_size(), 2);
        CHECK_EQ(ret.item_features(1).features(0).slot_id(), 10814);
        CHECK_EQ(ret.item_features(1).features(0).signs_size(), 1);
        CHECK_EQ(ret.item_features(1).features(0).signs(0), 20);
        CHECK_EQ(ret.item_features(1).features(1).slot_id(), 10814);
        CHECK_EQ(ret.item_features(1).features(1).signs_size(), 1);
        CHECK_EQ(ret.item_features(1).features(1).signs(0), 21);

        CHECK_EQ(ret.item_features(2).slot_id(), 10815);
        CHECK_EQ(ret.item_features(2).features_size(), 2);
        CHECK_EQ(ret.item_features(2).features(0).slot_id(), 10815);
        CHECK_EQ(ret.item_features(2).features(0).bytes_list_size(), 1);
        CHECK_EQ(ret.item_features(2).features(0).bytes_list(0), "rta_id_124");
        CHECK_EQ(ret.item_features(2).features(1).slot_id(), 10815);
        CHECK_EQ(ret.item_features(2).features(1).bytes_list_size(), 1);
        CHECK_EQ(ret.item_features(2).features(1).bytes_list(0), "rta_id_235");

        CHECK_EQ(ret.item_features(3).slot_id(), 10816);
        CHECK_EQ(ret.item_features(3).features_size(), 2);
        CHECK_EQ(ret.item_features(3).features(0).slot_id(), 10816);
        CHECK_EQ(ret.item_features(3).features(0).signs_size(), 1);
        CHECK_EQ(ret.item_features(3).features(0).signs(0), 100);
        CHECK_EQ(ret.item_features(3).features(1).slot_id(), 10816);
        CHECK_EQ(ret.item_features(3).features(1).signs_size(), 1);
        CHECK_EQ(ret.item_features(3).features(1).signs(0), 200);
    }

        TEST_CASE("ltr_test_int") {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811,10812,10813,10814,10815,10816"
                    labels="cvr_label_1,cvr_label_2"
                    weights="cvr_weights_1,cvr_weights_2,cvr_weights_3"
                    extras_int64="ad_group_id"
                    extras_float="cvr_weights_2"
                    extras_bytes="req_id,rta_id"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812"
                    slot="10812"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                    />
                <feature name="10813"
                    slot="10813"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.creative_id"
                    />
                <feature name="10814"
                    slot="10814"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.conv_type"
                    />
                <feature name="10815"
                    slot="10815"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="10816"
                    slot="10816"
                    attr="cross"
                    type="seq_hit_sum"
                    source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,item_info.appid"
                    start="0"
                    default_value="-2"
                    />

                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            attr="item"
                            source=".user_action.user_action_item_info.position" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.sdk_conversion" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="cvr_weights_3" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_register_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        attr="user"
                        source=".fe_request.req_id"
                    />
                <feature name="rta_id"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="ad_group_id"
                    type="direct_to_feature" 
                    attr="item"
                        source=".user_action.user_action_item_info.ad_group_id"
                    />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        
        // req_time
        fe_request->set_req_time((int64_t) 500);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(100);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(200);

        fe_request->set_req_id("reqid0001");

        fe_request->add_prerank_item_fea();
        fe_request->add_prerank_item_fea();

        // item_info
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea->mutable_item_info()->set_creative_id(10);
        item_fea->mutable_item_info()->set_conv_type(20);
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");
        item_fea->mutable_item_info()->set_creative_id(11);
        item_fea->mutable_item_info()->set_conv_type(21);
        item_fea->mutable_item_info()->set_appid(10002);

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info->set_api_register_conversion_rate(0.15);
        item_info->set_position(11);
        item_info->set_sdk_conversion(76);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        item_info->set_api_register_conversion_rate(0.25);
        item_info->set_position(21);
        item_info->set_sdk_conversion(86);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_ltr_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                       user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::LTRTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.user_features_size(), 2);
        CHECK_EQ(ret.user_features(0).slot_id(), 10811);
        CHECK_EQ(ret.user_features(0).signs_size(), 2);
        CHECK_EQ(ret.user_features(0).signs(0), 10001);
        CHECK_EQ(ret.user_features(0).signs(1), 10002);
        CHECK_EQ(ret.user_features(1).slot_id(), 10812);
        CHECK_EQ(ret.user_features(1).signs_size(), 2);
        CHECK_EQ(ret.user_features(1).signs(0), 100);
        CHECK_EQ(ret.user_features(1).signs(1), 200);

        CHECK_EQ(ret.item_features_size(), 4);
        CHECK_EQ(ret.item_features(0).slot_id(), 10813);
        CHECK_EQ(ret.item_features(0).features_size(), 2);
        CHECK_EQ(ret.item_features(0).features(0).slot_id(), 10813);
        CHECK_EQ(ret.item_features(0).features(0).signs_size(), 1);
        CHECK_EQ(ret.item_features(0).features(0).signs(0), 10);
        CHECK_EQ(ret.item_features(0).features(1).slot_id(), 10813);
        CHECK_EQ(ret.item_features(0).features(1).signs_size(), 1);
        CHECK_EQ(ret.item_features(0).features(1).signs(0), 11);

        CHECK_EQ(ret.item_features(1).slot_id(), 10814);
        CHECK_EQ(ret.item_features(1).features_size(), 2);
        CHECK_EQ(ret.item_features(1).features(0).slot_id(), 10814);
        CHECK_EQ(ret.item_features(1).features(0).signs_size(), 1);
        CHECK_EQ(ret.item_features(1).features(0).signs(0), 20);
        CHECK_EQ(ret.item_features(1).features(1).slot_id(), 10814);
        CHECK_EQ(ret.item_features(1).features(1).signs_size(), 1);
        CHECK_EQ(ret.item_features(1).features(1).signs(0), 21);

        CHECK_EQ(ret.item_features(2).slot_id(), 10815);
        CHECK_EQ(ret.item_features(2).features_size(), 2);
        CHECK_EQ(ret.item_features(2).features(0).slot_id(), 10815);
        CHECK_EQ(ret.item_features(2).features(0).bytes_list_size(), 1);
        CHECK_EQ(ret.item_features(2).features(0).bytes_list(0), "rta_id_124");
        CHECK_EQ(ret.item_features(2).features(1).slot_id(), 10815);
        CHECK_EQ(ret.item_features(2).features(1).bytes_list_size(), 1);
        CHECK_EQ(ret.item_features(2).features(1).bytes_list(0), "rta_id_235");

        CHECK_EQ(ret.item_features(3).slot_id(), 10816);
        CHECK_EQ(ret.item_features(3).features_size(), 2);
        CHECK_EQ(ret.item_features(3).features(0).slot_id(), 10816);
        CHECK_EQ(ret.item_features(3).features(0).signs_size(), 1);
        CHECK_EQ(ret.item_features(3).features(0).signs(0), 100);
        CHECK_EQ(ret.item_features(3).features(1).slot_id(), 10816);
        CHECK_EQ(ret.item_features(3).features(1).signs_size(), 1);
        CHECK_EQ(ret.item_features(3).features(1).signs(0), 200);
    }

    TEST_CASE("to_extractor_response_1") {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811,10812,10813,10814,10815,10816"
                    labels="cvr_label_1,cvr_label_2,ad_group_id"
                    weights="cvr_weights_1,cvr_weights_2,cvr_weights_3"
                    item_extras_int64="ad_group_id"
                    item_extras_float="cvr_weights_1,cvr_label_2"
                    item_extras_bytes="rta_id,req_id"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812"
                    slot="10812"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                    />
                <feature name="10813"
                    slot="10813"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.creative_id"
                    />
                <feature name="10814"
                    slot="10814"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.conv_type"
                    />
                <feature name="10815"
                    slot="10815"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="10816"
                    slot="10816"
                    attr="cross"
                    type="seq_hit_sum"
                    source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,item_info.appid"
                    start="0"
                    default_value="-2"
                    />

                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            attr="item"
                            source=".user_action.user_action_item_info.sdk_lahuo_conversion_rate" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_lahuo_conversion_rate" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="cvr_weights_3" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_register_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        attr="user"
                        source=".fe_request.req_id"
                    />
                <feature name="rta_id"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="ad_group_id"
                    type="direct_to_feature" 
                    attr="item"
                        source=".user_action.user_action_item_info.ad_group_id"
                    />
                <feature name="query"
                    type="direct_to_feature" 
                    attr="user"
                    source=".user_action.query"
                />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        
        // req_time
        fe_request->set_req_time((int64_t) 500);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(100);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(200);

        fe_request->set_req_id("reqid0001");

        // item_info
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea->mutable_item_info()->set_creative_id(10);
        item_fea->mutable_item_info()->set_conv_type(20);
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");
        item_fea->mutable_item_info()->set_creative_id(11);
        item_fea->mutable_item_info()->set_conv_type(21);
        item_fea->mutable_item_info()->set_appid(10002);

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action.set_query("test_query_1");
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info->set_api_register_conversion_rate(0.15);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        item_info->set_api_register_conversion_rate(0.25);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_extractor_response(fe_request_str.c_str(), fe_request_str.size(),
                                                       user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({10001, 10002}), ret.user_features(0));
        TEST_SLOT_FEATURE_INT64(10812, ({100, 200}), ret.user_features(1));
        TEST_BATCH_SLOT_FEATURES_INT64(0, 10813, ({{10}, {11}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(1, 10814, ({{20}, {21}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_STR(2, 10815, ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(3, 10816, ({{100}, {200}}), ret.item_features());

        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_label_1", ({{0.11}, {0.21}}), ret.labels());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_label_2", ({{0.12}, {0.22}}), ret.labels());
        TEST_BATCH_EXTRA_FEATURES_INT64(2, "ad_group_id", ({{20001}, {20002}}), ret.labels());

        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_weights_1", ({{0.13}, {0.23}}), ret.weights());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_weights_2", ({{0.14}, {0.24}}), ret.weights());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(2, "cvr_weights_3", ({{0.15}, {0.25}}), ret.weights());

        TEST_BATCH_EXTRA_FEATURES_INT64(0, "ad_group_id", ({{20001}, {20002}}), ret.item_extras_int64());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_weights_1", ({{0.13}, {0.23}}), ret.item_extras_float());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_label_2", ({{0.12}, {0.22}}), ret.item_extras_float());
        TEST_BATCH_EXTRA_FEATURES_STR(0, "rta_id", ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_extras_bytes());
        TEST_BATCH_EXTRA_FEATURES_STR(1, "req_id", ({{"reqid0001"}, {"reqid0001"}}), ret.item_extras_bytes());

        CHECK_EQ(0, ret.user_extras_int64_size());
        CHECK_EQ(0, ret.user_extras_float_size());
        CHECK_EQ(0, ret.user_extras_bytes_size());
        CHECK_EQ(2, ret.item_cnt());
    }

    // 不从user_action抽
    TEST_CASE("to_extractor_response_2") {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811,10812,10813,10814,10815,10816"
                    labels="10813_name"
                    weights="10814_name"
                    item_extras_int64="10816_name"
                    item_extras_bytes="rta_id"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811_name"
                    slot="10811"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812_name"
                    slot="10812"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                    />
                <feature name="10813_name"
                    slot="10813"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.creative_id"
                    />
                <feature name="10814_name"
                    slot="10814"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.conv_type"
                    />
                <feature name="10815_name"
                    slot="10815"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="10816_name"
                    slot="10816"
                    attr="cross"
                    type="seq_hit_sum"
                    source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,item_info.appid"
                    start="0"
                    default_value="-2"
                    />

                <feature name="req_id" 
                        type="direct_to_feature" 
                        attr="user"
                        source=".fe_request.req_id"
                    />
                <feature name="rta_id"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        
        // req_time
        fe_request->set_req_time((int64_t) 500);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(100);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(200);

        fe_request->set_req_id("reqid0001");

        // item_info
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea->mutable_item_info()->set_creative_id(10);
        item_fea->mutable_item_info()->set_conv_type(20);
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");
        item_fea->mutable_item_info()->set_creative_id(11);
        item_fea->mutable_item_info()->set_conv_type(21);
        item_fea->mutable_item_info()->set_appid(10002);

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_extractor_response(fe_request_str.c_str(), fe_request_str.size(),
                                                       nullptr, 0, config_handle);

        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({10001, 10002}), ret.user_features(0));
        TEST_SLOT_FEATURE_INT64(10812, ({100, 200}), ret.user_features(1));
        TEST_BATCH_SLOT_FEATURES_INT64(0, 10813, ({{10}, {11}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(1, 10814, ({{20}, {21}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_STR(2, 10815, ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(3, 10816, ({{100}, {200}}), ret.item_features());

        CHECK_EQ(2, ret.labels_size());
        TEST_BATCH_EXTRA_FEATURES_INT64(0, "10813_name", ({{10}, {11}}), ret.labels());

        CHECK_EQ(2, ret.weights_size());
        TEST_BATCH_EXTRA_FEATURES_INT64(0, "10814_name", ({{20}, {21}}), ret.weights());

        CHECK_EQ(2, ret.item_extras_int64_size());
        TEST_BATCH_EXTRA_FEATURES_INT64(0, "10816_name", ({{100}, {200}}), ret.item_extras_int64());

        CHECK_EQ(0, ret.item_extras_float_size());

        CHECK_EQ(2, ret.item_extras_bytes_size());
        TEST_BATCH_EXTRA_FEATURES_STR(0, "rta_id", ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_extras_bytes());

        CHECK_EQ(0, ret.user_extras_int64_size());
        CHECK_EQ(0, ret.user_extras_float_size());
        CHECK_EQ(0, ret.user_extras_bytes_size());
        CHECK_EQ(2, ret.item_cnt());
    }

    TEST_CASE("to_extractor_response_ltr_1") {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811,10812,10813,10814,10815,10816"
                    labels="cvr_label_1,cvr_label_2,ad_group_id"
                    weights="cvr_weights_1,cvr_weights_2,cvr_weights_3"
                    item_extras_int64="ad_group_id"
                    item_extras_float="cvr_weights_1,cvr_label_2"
                    item_extras_bytes="rta_id"
                    user_extras_int64="10811,10812"
                    user_extras_bytes="req_id,query"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811"
                    slot="10811"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812"
                    slot="10812"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                    />
                <feature name="10813"
                    slot="10813"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.creative_id"
                    />
                <feature name="10814"
                    slot="10814"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.conv_type"
                    />
                <feature name="10815"
                    slot="10815"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="10816"
                    slot="10816"
                    attr="cross"
                    type="seq_hit_sum"
                    source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,item_info.appid"
                    start="0"
                    default_value="-2"
                    />

                <feature name="cvr_label_1" 
                            type="direct_to_feature" 
                            attr="item"
                            source=".user_action.user_action_item_info.sdk_lahuo_conversion_rate" 
                        />
                <feature name="cvr_label_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.sdk_conversion_rate" 
                    />
                        
                <feature name="cvr_weights_1" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_lahuo_conversion_rate" 
                    />
                <feature name="cvr_weights_2" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_conversion_rate" 
                    />
                <feature name="cvr_weights_3" 
                    type="direct_to_feature" 
                    attr="item"
                    source=".user_action.user_action_item_info.api_register_conversion_rate" 
                    />
                <feature name="req_id" 
                        type="direct_to_feature" 
                        attr="user"
                        source=".fe_request.req_id"
                    />
                <feature name="rta_id"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="ad_group_id"
                    type="direct_to_feature" 
                    attr="item"
                        source=".user_action.user_action_item_info.ad_group_id"
                    />
                <feature name="query"
                    type="direct_to_feature" 
                    attr="user"
                    source=".user_action.query"
                />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        
        // req_time
        fe_request->set_req_time((int64_t) 500);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(100);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(200);

        fe_request->set_req_id("reqid0001");

        // 用于计算batch_size
        fe_request->add_prerank_item_fea();
        fe_request->add_prerank_item_fea();

        // item_info
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea->mutable_item_info()->set_creative_id(10);
        item_fea->mutable_item_info()->set_conv_type(20);
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");
        item_fea->mutable_item_info()->set_creative_id(11);
        item_fea->mutable_item_info()->set_conv_type(21);
        item_fea->mutable_item_info()->set_appid(10002);

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action.set_query("test_query_1");
        auto *item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20001);
        item_info->set_sdk_lahuo_conversion_rate(0.11);
        item_info->set_sdk_conversion_rate(0.12);
        item_info->set_api_lahuo_conversion_rate(0.13);
        item_info->set_api_conversion_rate(0.14);
        item_info->set_api_register_conversion_rate(0.15);
        item_info = user_action.add_user_action_item_info();
        item_info->set_ad_group_id(20002);
        item_info->set_sdk_lahuo_conversion_rate(0.21);
        item_info->set_sdk_conversion_rate(0.22);
        item_info->set_api_lahuo_conversion_rate(0.23);
        item_info->set_api_conversion_rate(0.24);
        item_info->set_api_register_conversion_rate(0.25);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_extractor_response_ltr(fe_request_str.c_str(), fe_request_str.size(),
                                                       user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({10001, 10002}), ret.user_features(0));
        TEST_SLOT_FEATURE_INT64(10812, ({100, 200}), ret.user_features(1));
        TEST_BATCH_SLOT_FEATURES_INT64(0, 10813, ({{10}, {11}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(1, 10814, ({{20}, {21}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_STR(2, 10815, ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(3, 10816, ({{100}, {200}}), ret.item_features());

        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_label_1", ({{0.11}, {0.21}}), ret.labels());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_label_2", ({{0.12}, {0.22}}), ret.labels());
        TEST_BATCH_EXTRA_FEATURES_INT64(2, "ad_group_id", ({{20001}, {20002}}), ret.labels());

        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_weights_1", ({{0.13}, {0.23}}), ret.weights());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_weights_2", ({{0.14}, {0.24}}), ret.weights());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(2, "cvr_weights_3", ({{0.15}, {0.25}}), ret.weights());

        TEST_BATCH_EXTRA_FEATURES_INT64(0, "ad_group_id", ({{20001}, {20002}}), ret.item_extras_int64());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(0, "cvr_weights_1", ({{0.13}, {0.23}}), ret.item_extras_float());
        TEST_BATCH_EXTRA_FEATURES_FLOAT(1, "cvr_label_2", ({{0.12}, {0.22}}), ret.item_extras_float());
        TEST_BATCH_EXTRA_FEATURES_STR(0, "rta_id", ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_extras_bytes());

        TEST_EXTRA_FEATURE_INT64("10811", ({10001, 10002}), ret.user_extras_int64(0));
        TEST_EXTRA_FEATURE_INT64("10812", ({100, 200}), ret.user_extras_int64(1));
        CHECK_EQ(0, ret.user_extras_float_size());
        TEST_EXTRA_FEATURE_STR("req_id", ({"reqid0001"}), ret.user_extras_bytes(0));
        TEST_EXTRA_FEATURE_STR("query", ({"test_query_1"}), ret.user_extras_bytes(1));

        CHECK_EQ(2, ret.item_cnt());
    }

    // 不从user_action抽
    TEST_CASE("to_extractor_response_ltr_2") {
        std::string xml_content_string = R"(
            <versions>
                <version 
                    name="union_ctr" 
                    dict="app_info" 
                    value="10811,10812,10813,10814,10815,10816"
                    labels="10813_name"
                    weights="10814_name"
                    item_extras_int64="10816_name"
                    item_extras_bytes="rta_id"
                    user_extras_int64="10811_name,10812_name"
                    user_extras_float="10812_name"
                    user_extras_bytes="req_id"
                />
            </versions>
            <config>
                
                <dict name="app_info" 
                            path="dict_test_data/appinfo"
                            partition="{pt_d-1}"
                            value_proto="phx.AppInfoDict" />
                <dict name="ad_info" 
                path="dict_test_data/adinfo"
                partition="{pt_d-1}"
                value_proto="phx::AdInfoDict" />
                
                <!--保留替换功能-->
                <source name="item_info"
                value=".fe_request.item_fea.item_info" />

                <!--libfe库的配置-->
                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                <feature name="10811_name"
                    slot="10811"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id"
                    />
                <feature name="10812_name"
                    slot="10812"
                    type="direct_to_feature"
                    attr="user"
                    source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time"
                    />
                <feature name="10813_name"
                    slot="10813"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.creative_id"
                    />
                <feature name="10814_name"
                    slot="10814"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.conv_type"
                    />
                <feature name="10815_name"
                    slot="10815"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                <feature name="10816_name"
                    slot="10816"
                    attr="cross"
                    type="seq_hit_sum"
                    source=".fe_request.req_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,.fe_request.ad_user_app_seq_expose_offline.user_app_info.event_time,item_info.appid"
                    start="0"
                    default_value="-2"
                    />

                <feature name="req_id" 
                        type="direct_to_feature" 
                        attr="user"
                        source=".fe_request.req_id"
                    />
                <feature name="rta_id"
                    type="direct_to_feature" 
                    attr="item"
                        source="item_info.rta_id"
                    />
                </features>
            </config>
            )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        
        // req_time
        fe_request->set_req_time((int64_t) 500);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_event_time(100);
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_event_time(200);

        fe_request->set_req_id("reqid0001");

        // 用于计算batch_size
        fe_request->add_prerank_item_fea();
        fe_request->add_prerank_item_fea();

        // item_info
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_124");
        item_fea->mutable_item_info()->set_creative_id(10);
        item_fea->mutable_item_info()->set_conv_type(20);
        item_fea->mutable_item_info()->set_appid(10001);

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("rta_id_235");
        item_fea->mutable_item_info()->set_creative_id(11);
        item_fea->mutable_item_info()->set_conv_type(21);
        item_fea->mutable_item_info()->set_appid(10002);

        const auto fe_request_str = fe_request->SerializeAsString();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();
        const auto ret_str = to_extractor_response_ltr(fe_request_str.c_str(), fe_request_str.size(),
                                                       nullptr, 0, config_handle);

        phx::ExtractorResponse ret;
        ret.ParseFromString(ret_str);

        TEST_SLOT_FEATURE_INT64(10811, ({10001, 10002}), ret.user_features(0));
        TEST_SLOT_FEATURE_INT64(10812, ({100, 200}), ret.user_features(1));
        TEST_BATCH_SLOT_FEATURES_INT64(0, 10813, ({{10}, {11}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(1, 10814, ({{20}, {21}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_STR(2, 10815, ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_features());
        TEST_BATCH_SLOT_FEATURES_INT64(3, 10816, ({{100}, {200}}), ret.item_features());

        CHECK_EQ(2, ret.labels_size());
        TEST_BATCH_EXTRA_FEATURES_INT64(0, "10813_name", ({{10}, {11}}), ret.labels());

        CHECK_EQ(2, ret.weights_size());
        TEST_BATCH_EXTRA_FEATURES_INT64(0, "10814_name", ({{20}, {21}}), ret.weights());

        CHECK_EQ(2, ret.item_extras_int64_size());
        TEST_BATCH_EXTRA_FEATURES_INT64(0, "10816_name", ({{100}, {200}}), ret.item_extras_int64());

        CHECK_EQ(0, ret.item_extras_float_size());

        CHECK_EQ(2, ret.item_extras_bytes_size());
        TEST_BATCH_EXTRA_FEATURES_STR(0, "rta_id", ({{"rta_id_124"}, {"rta_id_235"}}), ret.item_extras_bytes());

        CHECK_EQ(2, ret.user_extras_int64_size());
        TEST_EXTRA_FEATURE_INT64("10811_name", ({10001, 10002}), ret.user_extras_int64(0));
        TEST_EXTRA_FEATURE_INT64("10812_name", ({100, 200}), ret.user_extras_int64(1));
        CHECK_EQ(1, ret.user_extras_float_size());
        TEST_EXTRA_FEATURE_INT64("10812_name", ({100, 200}), ret.user_extras_float(0));
        CHECK_EQ(1, ret.user_extras_bytes_size());
        TEST_EXTRA_FEATURE_STR("req_id", ({"reqid0001"}), ret.user_extras_bytes(0));
        
        CHECK_EQ(2, ret.item_cnt());
    }

    TEST_CASE("trans_type") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811,10812" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="trans_type"
                        source=".fe_request.item_fea.item_info.rta_id"
                        data_type="int64"
                        default_value="-20"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="trans_type"
                        source=".fe_request.item_fea.item_info.rta_id"
                        data_type="float"
                        default_value="-20"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("133.3");

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("a");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(2, ret.training_samples_size());
        CHECK_EQ(2, ret.training_samples(0).features_size());

        CHECK_EQ(1, ret.training_samples(0).features(0).signs_size());
        CHECK_EQ(133, ret.training_samples(0).features(0).signs(0));
        CHECK_EQ(1, ret.training_samples(0).features(1).weights_size());
        CHECK(doctest::Approx(133.3).epsilon(0.001) == ret.training_samples(0).features(1).weights(0));

        CHECK_EQ(1, ret.training_samples(1).features(0).signs_size());
        CHECK_EQ(-20, ret.training_samples(1).features(0).signs(0));
        CHECK_EQ(1, ret.training_samples(1).features(1).weights_size());
        CHECK(doctest::Approx(-20).epsilon(0.001) == ret.training_samples(1).features(1).weights(0));
    }

    TEST_CASE("cross_hash_bits_v2_1") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="cross_hash_bits_v2"
                        source=".fe_request.item_fea.item_info.rta_id,.fe_request.context.info_flow_context.info_flow_item.group_id,.fe_request.item_fea.item_info.bid"
                        clip_size="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // user
        auto *info_flow_item = fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->set_group_id("900778570");
        info_flow_item = fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->set_group_id("104436666");

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("123");
        item_fea->mutable_item_info()->set_bid(123);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("456");
        item_fea->mutable_item_info()->set_bid(456);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        std::cout << "ret:" << ret.DebugString() << std::endl;

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({8840176746255942284L, 8840039651195226436L}),
                                ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({8840021783360860749L, 8840192412990929285L}),
                                ret.training_samples(1).features(0));
    }

    TEST_CASE("cross_hash_bits_v2_2") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="cross_hash_bits_v2"
                        source=".fe_request.context.info_flow_context.info_flow_item.group_id,.fe_request.item_fea.item_info.bid"
                        clip_size="4"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // user
        auto *info_flow_item = fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->set_group_id("900778570");
        info_flow_item = fe_request->mutable_context()->mutable_info_flow_context()->add_info_flow_item();
        info_flow_item->set_group_id("104436666");

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_bid(123);
        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_bid(456);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 2);

        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({8840033402015866826L, 8840079959590492718L}),
                                ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_SLOT_FEATURE_INT64(31406, ({8840183330329124570L, 8840281908279925566L}),
                                ret.training_samples(1).features(0));
    }

    TEST_CASE("cross_hash_bits_v2_3") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="cross_hash_bits_v2"
                        source=".fe_request.ad_user_app_seq_expose_offline.user_app_info.app_id,.fe_request.item_fea.item_info.rta_id,.fe_request.item_fea.item_info.bid"
                        clip_size="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        // user
        int64_t hash_value;
        auto *ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10000);
        murmur_hash(ad_user_app_info->app_id(), hash_value);
        MESSAGE("murmur_hash int:", std::to_string(ad_user_app_info->app_id()), "->", std::to_string(hash_value));
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        murmur_hash(ad_user_app_info->app_id(), hash_value);
        MESSAGE("murmur_hash int:", std::to_string(ad_user_app_info->app_id()), "->", std::to_string(hash_value));
        ad_user_app_info = fe_request->mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        murmur_hash(ad_user_app_info->app_id(), hash_value);
        MESSAGE("murmur_hash int:", std::to_string(ad_user_app_info->app_id()), "->", std::to_string(hash_value));

        // item
        auto *item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("123");
        murmur_hash(item_fea->item_info().rta_id(), hash_value);
        MESSAGE("murmur_hash str:", item_fea->item_info().rta_id(), "->", std::to_string(hash_value));
        item_fea->mutable_item_info()->set_bid(123);
        murmur_hash(item_fea->item_info().bid(), hash_value);
        MESSAGE("murmur_hash int:", item_fea->item_info().bid(), "->", std::to_string(hash_value));

        item_fea = fe_request->add_item_fea();
        item_fea->mutable_item_info()->set_rta_id("456");
        murmur_hash(item_fea->item_info().rta_id(), hash_value);
        MESSAGE("murmur_hash str:", item_fea->item_info().rta_id(), "->", std::to_string(hash_value));
        item_fea->mutable_item_info()->set_bid(456);
        murmur_hash(item_fea->item_info().bid(), hash_value);
        MESSAGE("murmur_hash int:", item_fea->item_info().bid(), "->", std::to_string(hash_value));

        //item 1
        // 第一轮：
        int64_t batch0_res1_1 = Math::left_rotate(324263529222902731, 1) ^ Math::left_rotate(5430309250450513548, 2);
        int64_t batch0_res1_2 = Math::left_rotate(4807318727292809522, 1) ^ Math::left_rotate(5430309250450513548, 2);

        // 第二轮：
        int64_t batch0_res2_1 = batch0_res1_1 ^ Math::left_rotate(1682578529731790821, 3);
        int64_t batch0_res2_2 = batch0_res1_2 ^ Math::left_rotate(1682578529731790821, 3);

        // 高位置零
        Math::set_highest_bit_to_zero(batch0_res2_1);
        Math::set_highest_bit_to_zero(batch0_res2_2);

        //item 2
        // 第一轮：
        int64_t batch1_res1_1 = Math::left_rotate(324263529222902731, 1) ^ Math::left_rotate(8999647371002439676, 2);
        int64_t batch1_res1_2 = Math::left_rotate(4807318727292809522, 1) ^ Math::left_rotate(8999647371002439676, 2);

        // 第二轮：
        int64_t batch1_res2_1 = batch1_res1_1 ^ Math::left_rotate(4485469063372695457, 3);
        int64_t batch1_res2_2 = batch1_res1_2 ^ Math::left_rotate(4485469063372695457, 3);

        // 高位置零
        Math::set_highest_bit_to_zero(batch1_res2_1);
        Math::set_highest_bit_to_zero(batch1_res2_2);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        CHECK_EQ(ret.training_samples_size(), 2);
        CHECK_EQ(ret.training_samples(0).features_size(), 1);
        TEST_ONLY_SLOT_FEATURE_INT64(31406, ({batch0_res2_1, batch0_res2_2}), ret.training_samples(0).features(0));

        CHECK_EQ(ret.training_samples(1).features_size(), 1);
        TEST_ONLY_SLOT_FEATURE_INT64(31406, ({batch1_res2_1, batch1_res2_2}), ret.training_samples(1).features(0));
    }

    TEST_CASE("cross_hash_bits_v2_4") {
        std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="app_info" value="31406" />
            </versions>
            <config>
                <dict name="app_info" 
                    path="dict_test_data/appinfo"
                    partition="{pt_d-1}"
                    value_proto="phx.AppInfoDict"
                />
                <dict name="ad_info" 
                    path="dict_test_data/adinfo"
                    partition="{pt_d-1}"
                    value_proto="phx::AdInfoDict" />

                <libfe path="/path_to_libfe/v1.7.0/libfe.so" md5="xxx" />
                <features>
                    <feature name="31406"
                        slot="31406"
                        type="cross_hash_bits_v2"
                        source=".fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.dtr,.fe_request.ad_user_ads_stats_seq_appstore_neg_appid.user_ads_stats_info.download_success_ratio"
                        clip_size="2"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        fe_request->add_item_fea();
        fe_request->mutable_ad_user_ads_stats_seq_appstore_neg_appid()->add_user_ads_stats_info();

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        // cross_hash_bits_v2算子不支持float类型，抛出异常，使用doctest框架捕获
        CHECK_THROWS_AS(to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle), std::runtime_error);
    }

    TEST_CASE("connect") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811,10812" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="connect"
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.rta_id"
                        connector="#"
                        tail="game"
                        />
                    <feature name="10812"
                        slot="10812"
                        type="connect"
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.conv_type"
                        tail="market"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        pb_item_fea->mutable_item_info()->set_rta_id("2000");
        pb_item_fea->mutable_item_info()->set_conv_type(18);

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        pb_item_fea->mutable_item_info()->set_rta_id("2001");
        pb_item_fea->mutable_item_info()->set_conv_type(9);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(2, ret.training_samples_size());
        REQUIRE_EQ(2, ret.training_samples(0).features_size());

        const phx::Feature &f0_0 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f0_0.bytes_list_size());
        CHECK_EQ("1000#2000#game", f0_0.bytes_list(0));

        const phx::Feature &f0_1 = ret.training_samples(0).features(1);
        REQUIRE_EQ(1, f0_1.bytes_list_size());
        CHECK_EQ("1000_18_market", f0_1.bytes_list(0));

        const phx::Feature &f1_0 = ret.training_samples(1).features(0);
        REQUIRE_EQ(1, f1_0.bytes_list_size());
        CHECK_EQ("1001#2001#game", f1_0.bytes_list(0));

        const phx::Feature &f1_1 = ret.training_samples(1).features(1);
        REQUIRE_EQ(1, f1_1.bytes_list_size());
        CHECK_EQ("1001_9_market", f1_1.bytes_list(0));
    }

    TEST_CASE("connect_all_to_string") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="connect_all_to_string"
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.rta_id,.fe_request.item_fea.item_info.conv_type"
                        first_connector="#"
                        second_connector=";"
                        tail="game"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        pb_item_fea->mutable_item_info()->set_rta_id("\1");// 不可见字符
        pb_item_fea->mutable_item_info()->set_conv_type(18);

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        pb_item_fea->mutable_item_info()->set_rta_id("\2");// 不可见字符
        pb_item_fea->mutable_item_info()->set_conv_type(9);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        // TODO: 测试first_connector
        REQUIRE_EQ(2, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f0_0 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f0_0.bytes_list_size());
        CHECK_EQ("1000;\1;18;game", f0_0.bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f1_0 = ret.training_samples(1).features(0);
        REQUIRE_EQ(1, f1_0.bytes_list_size());
        CHECK_EQ("1001;\2;9;game", f1_0.bytes_list(0));
    }

    TEST_CASE("fully_cross") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="fully_cross"
                        source=".fe_request.item_fea.item_info.appid,.fe_request.item_fea.item_info.rta_id"
                        connector="#"
                        default_value="NONE"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        pb_item_fea->mutable_item_info()->set_rta_id("abc");

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        pb_item_fea->mutable_item_info()->set_rta_id("def");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(2, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f0_0 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f0_0.bytes_list_size());
        CHECK_EQ("1000#abc", f0_0.bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f1_0 = ret.training_samples(1).features(0);
        REQUIRE_EQ(1, f1_0.bytes_list_size());
        CHECK_EQ("1001#def", f1_0.bytes_list(0));
    }

    TEST_CASE("fully_cross_2") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="fully_cross"
                        source=".fe_request.item_fea.item_info.appid,.fe_request.ad_user_seq_click_realtime.user_behavior_info.session_id"
                        connector="#"
                        default_value="NONE"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature* pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1000);
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("abc");

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_appid(1001);
        fe_request->mutable_ad_user_seq_click_realtime()->add_user_behavior_info()->set_session_id("def");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(2, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature& f0_0 = ret.training_samples(0).features(0);
        REQUIRE_EQ(2, f0_0.bytes_list_size());
        CHECK_EQ("1000#abc", f0_0.bytes_list(0));
        CHECK_EQ("1000#def", f0_0.bytes_list(1));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature& f1_0 = ret.training_samples(1).features(0);
        REQUIRE_EQ(2, f1_0.bytes_list_size());
        CHECK_EQ("1001#abc", f1_0.bytes_list(0));
        CHECK_EQ("1001#def", f1_0.bytes_list(1));
    }

    TEST_CASE("fully_cross_3")
    {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="fully_cross"
                        source=".fe_request.item_fea.item_info.rta_id,.user_action.user_action_item_info.click"
                        connector="_"
                        default_value="NONE"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("abc");

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("def");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        user_action.add_user_action_item_info()->set_click(100);
        user_action.add_user_action_item_info()->set_click(200);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(2, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature& f0_0 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f0_0.bytes_list_size());
        CHECK_EQ("abc_100", f0_0.bytes_list(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature& f1_0 = ret.training_samples(1).features(0);
        REQUIRE_EQ(1, f1_0.bytes_list_size());
        CHECK_EQ("def_200", f1_0.bytes_list(0));
    }

    TEST_CASE("hash") {
        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="hash"
                        source=".fe_request.item_fea.item_info.rta_id"
                        bucket_size="1000"
                        />
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        const std::string source = ".fe_request.item_fea.item_info.rta_id";
        const std::string s1 = "123", s2 = "456", s3 = "789";

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id(s1);

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id(s2);

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id(s3);

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(3, ret.training_samples_size());

        REQUIRE_EQ(1, ret.training_samples(0).features_size());
        const phx::Feature &f0 = ret.training_samples(0).features(0);
        REQUIRE_EQ(1, f0.signs_size());
        const std::string origin_s1 = s1 + source;
        CHECK_EQ(util::Fingerprint64(origin_s1.c_str(), origin_s1.size()) % 1000, f0.signs(0));

        REQUIRE_EQ(1, ret.training_samples(1).features_size());
        const phx::Feature &f1 = ret.training_samples(1).features(0);
        REQUIRE_EQ(1, f1.signs_size());
        const std::string origin_s2 = s2 + source;
        CHECK_EQ(util::Fingerprint64(origin_s2.c_str(), origin_s2.size()) % 1000, f1.signs(0));

        REQUIRE_EQ(1, ret.training_samples(2).features_size());
        const phx::Feature &f2 = ret.training_samples(2).features(0);
        REQUIRE_EQ(1, f2.signs_size());
        const std::string origin_s3 = s3 + source;
        CHECK_EQ(util::Fingerprint64(origin_s3.c_str(), origin_s3.size()) % 1000, f2.signs(0));
    }

    TEST_CASE("message_pb") {
        MESSAGE("message_pb start...");
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        ::phx::AdUserAppInfo *ad_user_app_info =
                fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10001);
        ad_user_app_info->set_count(10);
        ad_user_app_info = fe_request.mutable_ad_user_app_seq_expose_offline()->add_user_app_info();
        ad_user_app_info->set_app_id(10002);
        ad_user_app_info->set_count(20);

        auto *app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20001);
        app_fea = fe_request.add_app_fea();
        app_fea->mutable_ad_info()->set_app_id(20002);

        auto *item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("124");
        item_fea = fe_request.add_item_fea();
        item_fea->mutable_item_info()->mutable_rta_id()->assign("235");

        mocker::FillProto(fe_request);
        // 单message
        {
            std::string user_source_input{".fe_request.ad_user_app_seq_expose_offline"};
            Input user_input{user_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            CHECK_EQ(user_output.values[0].ifeatures[0].messages[0],
                     (google::protobuf::Message *) fe_request.mutable_ad_user_app_seq_expose_offline());
        }
        //多user message
        {

            std::string user_source_input{".fe_request.ad_user_app_seq_expose_offline.user_app_info"};
            Input user_input{user_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            CHECK_EQ(user_output.values[0].ifeatures[0].messages[0],
                     (google::protobuf::Message *) fe_request.mutable_ad_user_app_seq_expose_offline()
                             ->mutable_user_app_info(0));
            CHECK_EQ(user_output.values[0].ifeatures[0].messages[1],
                     (google::protobuf::Message *) fe_request.mutable_ad_user_app_seq_expose_offline()
                             ->mutable_user_app_info(1));
        }
        //多item message
        {
            std::string item_source_input{".fe_request.item_fea.item_info"};
            Input user_input{item_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            CHECK_EQ(user_output.values[0].ifeatures[0].messages[0],
                     (google::protobuf::Message *) fe_request.mutable_item_fea(0)->mutable_item_info());

            CHECK_EQ(user_output.values[0].ifeatures[1].messages[0],
                     (google::protobuf::Message *) fe_request.mutable_item_fea(1)->mutable_item_info());
        }

        MESSAGE("message_pb end...");
    }

    TEST_CASE("hash_slot_strategy") {
        MESSAGE("hash_slot_strategy start");

        const std::string xml_content_string = R"(
            <versions>
            <version name="union_ctr" dict="appInfo" value="10811" />
            </versions>
            <config>
                <features>
                    <feature name="10811"
                        slot="10811"
                        type="direct"
                        source=".fe_request.item_fea.item_info.rta_id"
                        strategy = "hash"/>
                </features>
            </config>
        )";

        auto ptr = init_xml_offline_by_content_new_sample(xml_content_string.c_str(), 0, "union_ctr");
        auto config_handle = reinterpret_cast<long>(ptr);

        google::protobuf::Arena arena;
        auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

        phx::ItemFeature *pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("900778570");

        pb_item_fea = fe_request->add_item_fea();
        pb_item_fea->mutable_item_info()->set_rta_id("104436666");

        phx::UserAction &user_action = *google::protobuf::Arena::CreateMessage<phx::UserAction>(&arena);
        auto user_action_str = user_action.SerializeAsString();

        const auto fe_request_str = fe_request->SerializeAsString();
        const auto ret_str = to_training_sample_v2(fe_request_str.c_str(), fe_request_str.size(),
                                                   user_action_str.c_str(), user_action_str.size(), config_handle);

        phx::BatchTrainingSample ret;
        ret.ParseFromString(ret_str);

        REQUIRE_EQ(ret.training_samples_size(), 2);

        REQUIRE_EQ(ret.training_samples(0).features_size(), 1);
        TEST_HASH_SLOT_FEATURE_STR(10811, ({"900778570"}), ret.training_samples(0).features(0));

        REQUIRE_EQ(ret.training_samples(1).features_size(), 1);
        TEST_HASH_SLOT_FEATURE_STR(10811, ({"104436666"}), ret.training_samples(1).features(0));
    }

    /**
    * @brief 测试单层repeated field的情况
    * 
    */
    TEST_CASE("framework_null_repeated_1") {
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        std::string user_source_input{".fe_request.ad_user_seq_click_offline.user_behavior_info.event_time"};
        {
            Input user_input{user_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->has_bytes_list(), false);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->has_int64_list(), false);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->has_float_list(), false);
        }
        fe_request.mutable_ad_user_seq_click_offline()->add_user_behavior_info()->mutable_session_id()->assign(
                "mock_session_id_1");
        fe_request.mutable_ad_user_seq_click_offline()->add_user_behavior_info()->mutable_session_id()->assign(
                "mock_session_id_2");
        {
            Input user_input{user_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            CHECK_EQ(user_output.values.size(), (size_t) 1);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value_size(), 2);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(0), 0l);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(1), 0l);
        }

        fe_request.Clear();
        fe_request.mutable_ad_user_seq_click_offline()->add_user_behavior_info()->set_event_time(1987l);
        fe_request.mutable_ad_user_seq_click_offline()->add_user_behavior_info()->mutable_session_id()->assign(
                "mock_session_id_2");
        {
            Input user_input{user_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            CHECK_EQ(user_output.values.size(), (size_t) 1);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value_size(), 2);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(0), 1987l);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(1), 0l);
        }

        fe_request.Clear();
        fe_request.mutable_ad_user_seq_click_offline()->add_user_behavior_info()->set_event_time(1987l);
        fe_request.mutable_ad_user_seq_click_offline()->add_user_behavior_info()->mutable_session_id()->assign(
                "mock_session_id_2");
        fe_request.mutable_ad_user_seq_click_offline()->add_user_behavior_info()->set_event_time(1988l);
        {
            Input user_input{user_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            CHECK_EQ(user_output.values.size(), (size_t) 1);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value_size(), 3);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(0), 1987l);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(1), 0l);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(2), 1988l);
        }
    }

    /**
    * @brief 测试两层repeated field的情况
    * 
    */
    TEST_CASE("framework_null_repeated_2") {
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        {
            std::string user_source_input{".fe_request.context.info_flow_context.info_flow_item.filter_words.id"};
            //添加第一个元素,但下面的字段都没填

            Input user_input{user_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature, nullptr);
            CHECK_NE(user_output.values[0].ifeatures[0].feature_list, nullptr);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature_list->feature_size(), 0);
        }
        {
            std::string user_source_input{".fe_request.context.info_flow_context.info_flow_item"};
            //添加第一个元素,但下面的字段都没填
            fe_request.mutable_context()->mutable_info_flow_context()->add_info_flow_item();
            Input user_input{user_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature, nullptr);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature_list, nullptr);
            CHECK_EQ(user_output.values[0].ifeatures[0].messages.size(), 1);
        }

        {
            std::string user_source_input{".fe_request.context.info_flow_context.info_flow_item.filter_words.id"};
            for (auto i: times(3)) {
                // 第一层repeated元素添加了但字段未设置,feature list
                auto info_flow_item = fe_request.mutable_context()->mutable_info_flow_context()->add_info_flow_item();
                for (auto j: times(2)) {
                    auto filter_words = info_flow_item->add_filter_words();
                    filter_words->mutable_id()->assign(std::to_string(i).append("_id_").append(std::to_string(j)));
                    filter_words->mutable_name()->assign(std::to_string(i).append("_name_").append(std::to_string(j)));
                }
            }
            Input user_input{user_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            {
                CHECK_EQ(user_output.values.size(), 1);
                CHECK_EQ(user_output.values[0].ifeatures.size(), 1);
                CHECK_NE(user_output.values[0].ifeatures[0].feature_list, nullptr);
                CHECK_EQ(user_output.values[0].ifeatures[0].feature_list->feature_size(), 4);
                auto feature_list = user_output.values[0].ifeatures[0].feature_list;
                auto first_feature = feature_list->feature(0);
                CHECK_EQ(first_feature.has_bytes_list(), false);
                CHECK_EQ(first_feature.has_int64_list(), false);
                CHECK_EQ(first_feature.has_float_list(), false);

                for (auto i: range<int64_t>(1, 3)) {
                    auto feature = feature_list->feature(i);
                    CHECK_EQ(feature.has_bytes_list(), true);
                    CHECK_EQ(feature.bytes_list().value_size(), 2);
                    for (auto j: times(2)) {
                        CHECK_EQ(feature.bytes_list().value(j),
                                 std::to_string(i - 1).append("_id_").append(std::to_string(j)));
                    }
                }
            }
        }
    }

    /**
    * @brief 测试单层repeated field,其最后一层为repeated的基本数据类型的情况
    * 
    */
    TEST_CASE("framework_null_repeated_3") {
        google::protobuf::Arena arena;
        phx::FeRequest &fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
        std::string user_source_input{".fe_request.ad_user_dmp_feature.user_dmp_feature.label_interest"};
        {
            Input user_input{user_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->has_bytes_list(), false);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->has_int64_list(), false);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->has_float_list(), false);
        }

        {
            fe_request.mutable_ad_user_dmp_feature()->mutable_user_dmp_feature()->add_label_interest(2324);
            fe_request.mutable_ad_user_dmp_feature()->mutable_user_dmp_feature()->add_label_interest(2325);
            fe_request.mutable_ad_user_dmp_feature()->mutable_user_dmp_feature()->add_label_interest(2305);

            Input user_input{user_source_input, {}, "20001"};
            Output user_output{};
            user_output.arena = &arena;

            phx::UserAction ua{};
            GenerateOutputFromRequest(fe_request, ua, user_input, user_output);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->has_bytes_list(), false);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->has_int64_list(), true);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->has_float_list(), false);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(0), 2324);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(1), 2325);
            CHECK_EQ(user_output.values[0].ifeatures[0].feature->int64_list().value(2), 2305);
        }
    }
}
