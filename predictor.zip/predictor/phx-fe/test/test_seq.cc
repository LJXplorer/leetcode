#include "phx-fe/config/config_seq.h"
#include "test.h"
#include "phx-fe/util/util.h"
#include <cstdint>

//featurelist
void test_seq_topn_1(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_topn",
        "source": [
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
          ".request_time"
        ],
        "start" : 60,
        "topn": 3,
        "type": 2, 
        "default_value": "life is life!"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104435568"); //false
  pb_info->set_event_time(5 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666"); //false
  pb_info->set_event_time(11 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570"); //false
  pb_info->set_event_time(9 * 86404 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570"); //true
  pb_info->set_event_time(9 * 86401 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436777"); //true
  pb_info->set_event_time(9 * 86403 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436888"); //false
  pb_info->set_event_time(9 * 86402 * 1000);

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
 
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f0");

  TEST_ASSERT_BOOL(itr0 != map0.end());
  TEST_ASSERT_EQUAL(3, itr0->second.feature_size());

  TEST_ASSERT_EQUAL(1, itr0->second.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr0->second.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr0->second.feature(2).bytes_list().value_size());

  TEST_EXPECT_EQUAL("900778570", itr0->second.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("104436777", itr0->second.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("104436888", itr0->second.feature(2).bytes_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  auto itr = map.find("f0");
  auto itr_len = map.find("f0_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(3, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("900778570", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("104436777", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("104436888", tvalues.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen.int_val(0));

  //空值测试
  qinglong::FeRequest request1;
  qinglong::BatchSequenceExample ret1;

  qinglong::UserFeature* pb_ufv21 = request1.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use1 = pb_ufv21->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use1->add_user_sequence();

  pb_use->add_user_sequence();
  pb_use->add_user_sequence();

  request1.add_item_feature();

  toSequenceExample(&arena, request1, vec, ret1);

  TEST_ASSERT_EQUAL(1, ret1.batch_size());
  TEST_ASSERT_EQUAL(true, ret1.batch(0).has_feature_lists());

  const auto& map1 = ret1.batch(0).feature_lists().feature_list();
  auto itr1 = map1.find("f0");

  TEST_ASSERT_EQUAL(1, itr1->second.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("life is life!", itr1->second.feature(0).bytes_list().value(0));

  FUNC_TEST_END();
}
//feature
void test_seq_topn_2(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_topn",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ],
        "start" : 60,
        "topn": 3,
        "type": 2, 
        "default_value": "life is life!"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);
  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436666");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436777");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436888");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)11 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86404 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86401 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86403 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86402 * 1000);

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr0 = map0.find("f0");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  TEST_ASSERT_EQUAL(3, itr0->second.bytes_list().value_size());

  TEST_EXPECT_EQUAL("900778570", itr0->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("104436777", itr0->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("104436888", itr0->second.bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  auto itr_values = map.find("f0_values");
  auto itr_indices = map.find("f0_indices");
  auto itr_dense_shape = map.find("f0_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(3, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("900778570", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("104436777", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("104436888", tvalues.string_val(2));

  TEST_ASSERT_EQUAL(6, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape.int64_val(1));

  FUNC_TEST_END();
}

//默认参数
void test_seq_topn_3(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_topn",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ],
        "topn": 5
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);
  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436888");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)7 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436888");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)11 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(2, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  const auto& map1 = ret.batch(1).context().feature();
  
  auto itr00 = map0.find("f0");
  auto itr10 = map1.find("f0");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_FEATURE_STR(({"900778570", "104436888", "104435568"}), itr00->second);
  TEST_FEATURE_STR(({"NOT_EXIST"}), itr10->second);

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  auto itr_values = map.find("f0_values");
  auto itr_indices = map.find("f0_indices");
  auto itr_dense_shape = map.find("f0_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"900778570", "104436888", "104435568", "NOT_EXIST"}),
                          itr_indices->second, itr_dense_shape->second, itr_values->second);

  FUNC_TEST_END();
}

//默认参数
void test_seq_appcategory_topn_3(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12": {
        "fe_type" : "seq_appcategory_topn",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ],
        "topn": 3
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "104435568,母婴,健康育儿,母婴健康;900778570,工具,生活工具,日历;104430325,社交,聊天交友,匿名/陌生人;900834783,默认值,默认值,默认值;220738225,默认值,默认值,默认值;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f14": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f15": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }        
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);

  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104430325");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)7 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)20 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(2, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  const auto& map1 = ret.batch(1).context().feature();

  auto itr00 = map0.find("f13");
  auto itr10 = map1.find("f13");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_FEATURE_STR(({"工具", "社交", "母婴"}), itr00->second);
  TEST_FEATURE_STR(({"NOT_EXIST"}), itr10->second);

  auto itr01 = map0.find("f14");
  auto itr11 = map1.find("f14");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());
  TEST_FEATURE_STR(({"生活工具", "聊天交友", "健康育儿"}), itr01->second);
  TEST_FEATURE_STR(({"NOT_EXIST"}), itr11->second);

  auto itr02 = map0.find("f15");
  auto itr12 = map1.find("f15");
  TEST_ASSERT_BOOL(itr02 != map0.end());
  TEST_ASSERT_BOOL(itr12 != map1.end());
  TEST_FEATURE_STR(({"日历", "匿名/陌生人", "母婴健康"}), itr02->second);
  TEST_FEATURE_STR(({"NOT_EXIST"}), itr12->second);

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"工具", "社交", "母婴", "NOT_EXIST"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f14_values");
  auto itr_indices1 = map.find("f14_indices");
  auto itr_dense_shape1 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"生活工具", "聊天交友", "健康育儿", "NOT_EXIST"}),
                          itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f15_values");
  auto itr_indices2 = map.find("f15_indices");
  auto itr_dense_shape2 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"日历", "匿名/陌生人", "母婴健康", "NOT_EXIST"}),
                          itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  FUNC_TEST_END();
}

//feature
void test_seq_appcategory_topn_2(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12": {
        "fe_type" : "seq_appcategory_topn",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ],
        "start" : 60,
        "topn": 3,
        "type": 2, 
        "default_value": "life is life!"
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "104435568,母婴,健康育儿,母婴健康;900778570,工具,生活工具,日历;104430325,社交,聊天交友,匿名/陌生人;900834783,默认值,默认值,默认值;220738225,默认值,默认值,默认值;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f14": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f15": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }        
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);

  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436666");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104430325");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900834783");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)11 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86404 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86401 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86403 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86402 * 1000);

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr00 = map0.find("f13");
  auto itr01 = map0.find("f14");
  auto itr02 = map0.find("f15");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr02 != map0.end());

  TEST_ASSERT_EQUAL(3, itr00->second.bytes_list().value_size());
  TEST_ASSERT_EQUAL(3, itr00->second.bytes_list().value_size());
  TEST_ASSERT_EQUAL(3, itr00->second.bytes_list().value_size());

  TEST_EXPECT_EQUAL("工具", itr00->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("社交", itr00->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("默认值", itr00->second.bytes_list().value(2));

  TEST_EXPECT_EQUAL("生活工具", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("聊天交友", itr01->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("默认值", itr01->second.bytes_list().value(2));

  TEST_EXPECT_EQUAL("日历", itr02->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("匿名/陌生人", itr02->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("默认值", itr02->second.bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  auto itr_values = map.find("f13_values");
  auto itr_indices = map.find("f13_indices");
  auto itr_dense_shape = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(3, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("工具", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("社交", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("默认值", tvalues.string_val(2));

  TEST_ASSERT_EQUAL(6, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_seq_appcategory_topn_1(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12": {
        "fe_type" : "seq_appcategory_topn",
        "source": [
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
          ".request_time"
        ],
        "start" : 60,
        "topn": 3,
        "type": 2, 
        "default_value": "life is life!"
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "104435568,母婴,健康育儿,母婴健康;900778570,工具,生活工具,日历;104430325,社交,聊天交友,匿名/陌生人;900834783,默认值,默认值,默认值;220738225,默认值,默认值,默认值;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        },
        "f14": {
            "dtype" : "string",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        },
        "f15": {
            "dtype" : "string",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104435568"); //true
  pb_info->set_event_time(5 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666"); //false
  pb_info->set_event_time(11 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570"); //true
  pb_info->set_event_time(9 * 86404 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104430325"); //true
  pb_info->set_event_time(9 * 86401 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104435568"); //true
  pb_info->set_event_time(9 * 86403 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900834783"); //true
  pb_info->set_event_time(9 * 86402 * 1000);

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
 
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr00 = map0.find("f13");
  auto itr01 = map0.find("f14");
  auto itr02 = map0.find("f15");

  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr02 != map0.end());

  TEST_ASSERT_EQUAL(3, itr00->second.feature_size());
  TEST_ASSERT_EQUAL(3, itr01->second.feature_size());
  TEST_ASSERT_EQUAL(3, itr02->second.feature_size());
  TEST_ASSERT_EQUAL(1, itr00->second.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr00->second.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr00->second.feature(2).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr01->second.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr01->second.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr01->second.feature(2).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr02->second.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr02->second.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr02->second.feature(2).bytes_list().value_size());

  TEST_EXPECT_EQUAL("母婴", itr00->second.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("工具", itr00->second.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("默认值", itr00->second.feature(2).bytes_list().value(0));

  TEST_EXPECT_EQUAL("健康育儿", itr01->second.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("生活工具", itr01->second.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("默认值", itr01->second.feature(2).bytes_list().value(0));

  TEST_EXPECT_EQUAL("母婴健康", itr02->second.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("日历", itr02->second.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("默认值", itr02->second.feature(2).bytes_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(3, tvalues0.string_val_size());
  TEST_EXPECT_EQUAL("母婴", tvalues0.string_val(0));
  TEST_EXPECT_EQUAL("工具", tvalues0.string_val(1));
  TEST_EXPECT_EQUAL("默认值", tvalues0.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen0.int_val(0));

  auto itr1 = map.find("f14");
  auto itr_len1 = map.find("f14_length");

  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());

  auto& tvalues1 = itr1->second;
  auto& tlen1 = itr_len1->second;

  TEST_ASSERT_EQUAL(3, tvalues1.string_val_size());
  TEST_EXPECT_EQUAL("健康育儿", tvalues1.string_val(0));
  TEST_EXPECT_EQUAL("生活工具", tvalues1.string_val(1));
  TEST_EXPECT_EQUAL("默认值", tvalues1.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen1.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen1.int_val(0));

  auto itr2 = map.find("f15");
  auto itr_len2 = map.find("f15_length");

  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());

  auto& tvalues2 = itr2->second;
  auto& tlen2 = itr_len2->second;

  TEST_ASSERT_EQUAL(3, tvalues2.string_val_size());
  TEST_EXPECT_EQUAL("母婴健康", tvalues2.string_val(0));
  TEST_EXPECT_EQUAL("日历", tvalues2.string_val(1));
  TEST_EXPECT_EQUAL("默认值", tvalues2.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen2.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen2.int_val(0));

  ////////////
  //空值测试
  qinglong::FeRequest request1;
  qinglong::BatchSequenceExample ret1;

  qinglong::UserFeature* pb_ufv21 = request1.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use1 = pb_ufv21->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use1->add_user_sequence();

  pb_use->add_user_sequence();

  request1.add_item_feature();

  toSequenceExample(&arena, request1, vec, ret1);

  TEST_ASSERT_EQUAL(1, ret1.batch_size());
  TEST_ASSERT_EQUAL(true, ret1.batch(0).has_feature_lists());

  const auto& map3 = ret1.batch(0).feature_lists().feature_list();
  auto itr3 = map3.find("f13");
  auto itr4 = map3.find("f14");
  auto itr5 = map3.find("f15");

  TEST_ASSERT_EQUAL(1, itr3->second.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("life is life!", itr3->second.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, itr4->second.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("life is life!", itr3->second.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, itr5->second.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("life is life!", itr3->second.feature(0).bytes_list().value(0));

  FUNC_TEST_END();
}

//sparse
void test_to_predict_request_v3_1(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_n",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ],
        "save" : true,
        "end" : 86401,
        "start" : 60,
        "clip_size": 3
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
      "f0": {
          "dtype" : "string",
          "shape" : [1] ,
          "model_input_type" : "sparse"
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  init_online_by_content_v3(str, in_str, vec, in_vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);

  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::SequenceExample* item1 = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::SequenceExample* item2 = request.add_item_feature()->mutable_item_feature_se();

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436666");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436777");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436888");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)11 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86404 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86401 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86403 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86402 * 1000);


  (*(item1->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778111");
  (*(item1->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778222");
  (*(item1->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436333");
  (*(item1->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436444");
  (*(item1->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86404 * 1000);
  (*(item1->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86401 * 1000);
  (*(item1->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86403 * 1000);
  (*(item1->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86402 * 1000);

  (*(item2->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778555");
  (*(item2->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778666");
  (*(item2->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778777");
  (*(item2->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778888");
  (*(item2->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86404 * 1000);
  (*(item2->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86401 * 1000);
  (*(item2->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86403 * 1000);
  (*(item2->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86402 * 1000);

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(3, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(2).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  const auto& map1 = ret.batch(1).context().feature();
  const auto& map2 = ret.batch(2).context().feature();
  auto itr0 = map0.find("f0");
  auto itr1 = map1.find("f0");
  auto itr2 = map2.find("f0");

  TEST_ASSERT_BOOL(itr0 != map0.end());
  TEST_ASSERT_BOOL(itr1 != map0.end());
  TEST_ASSERT_BOOL(itr2 != map0.end());

  TEST_ASSERT_EQUAL(3, itr0->second.bytes_list().value_size());
  TEST_ASSERT_EQUAL(3, itr1->second.bytes_list().value_size());
  TEST_ASSERT_EQUAL(3, itr2->second.bytes_list().value_size());

  TEST_EXPECT_EQUAL("900778570", itr0->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("104436777", itr0->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("104436888", itr0->second.bytes_list().value(2));

  TEST_EXPECT_EQUAL("900778111", itr1->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("104436333", itr1->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("104436444", itr1->second.bytes_list().value(2));

  TEST_EXPECT_EQUAL("900778555", itr2->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("900778777", itr2->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("900778888", itr2->second.bytes_list().value(2));

  //在线
  uint32_t item_start_index = 1;
  uint32_t item_end_index = 3;
  to_predict_request_v3(vec, in_vec, &arena, &request, &pre_ret, item_start_index, item_end_index);
  
  auto& map = pre_ret.inputs();

  auto itr_values = map.find("f0_values");
  auto itr_indices = map.find("f0_indices");
  auto itr_dense_shape = map.find("f0_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(6, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("900778111", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("104436333", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("104436444", tvalues.string_val(2));
  TEST_EXPECT_EQUAL("900778555", tvalues.string_val(3));
  TEST_EXPECT_EQUAL("900778777", tvalues.string_val(4));
  TEST_EXPECT_EQUAL("900778888", tvalues.string_val(5));

  TEST_ASSERT_EQUAL(12, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(5));
  
  TEST_EXPECT_EQUAL(1, tindices.int64_val(6));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(7));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(8));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(9));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(10));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(11));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape.int64_val(1));

  FUNC_TEST_END();
}

//dense
void test_to_predict_request_v3_2(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_n",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ],
        "save" : true,
        "end" : 86401,
        "start" : 60,
        "clip_size": 3
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
      "f0": {
          "dtype" : "string",
          "shape" : [3] ,
          "model_input_type" : "dense"
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  init_online_by_content_v3(str, in_str, vec, in_vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;


  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);

  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::SequenceExample* item1 = request.add_item_feature()->mutable_item_feature_se();
  tensorflow::SequenceExample* item2 = request.add_item_feature()->mutable_item_feature_se();

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436666");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436777");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436888");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)11 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86404 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86401 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86403 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86402 * 1000);


  (*(item1->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778111");
  (*(item1->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778222");
  (*(item1->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436333");
  (*(item1->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436444");
  (*(item1->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86404 * 1000);
  (*(item1->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86401 * 1000);
  (*(item1->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86403 * 1000);
  (*(item1->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86402 * 1000);

  (*(item2->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778555");
  (*(item2->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778666");
  (*(item2->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778777");
  (*(item2->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778888");
  (*(item2->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86404 * 1000);
  (*(item2->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86401 * 1000);
  (*(item2->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86403 * 1000);
  (*(item2->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86402 * 1000);

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(3, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(2).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  const auto& map1 = ret.batch(1).context().feature();
  const auto& map2 = ret.batch(2).context().feature();
  auto itr0 = map0.find("f0");
  auto itr1 = map1.find("f0");
  auto itr2 = map2.find("f0");

  TEST_ASSERT_BOOL(itr0 != map0.end());
  TEST_ASSERT_BOOL(itr1 != map0.end());
  TEST_ASSERT_BOOL(itr2 != map0.end());

  TEST_ASSERT_EQUAL(3, itr0->second.bytes_list().value_size());
  TEST_ASSERT_EQUAL(3, itr1->second.bytes_list().value_size());
  TEST_ASSERT_EQUAL(3, itr2->second.bytes_list().value_size());

  TEST_EXPECT_EQUAL("900778570", itr0->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("104436777", itr0->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("104436888", itr0->second.bytes_list().value(2));

  TEST_EXPECT_EQUAL("900778111", itr1->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("104436333", itr1->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("104436444", itr1->second.bytes_list().value(2));

  TEST_EXPECT_EQUAL("900778555", itr2->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("900778777", itr2->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("900778888", itr2->second.bytes_list().value(2));

  //在线
  uint32_t item_start_index = 1;
  uint32_t item_end_index = 3;
  to_predict_request_v3(vec, in_vec, &arena, &request, &pre_ret, item_start_index, item_end_index);

  auto& map = pre_ret.inputs();
  auto itr00 = map.find("f0");
  TEST_ASSERT_BOOL(itr00 != map.end());

  auto& tproto_00 = itr00->second;

  TEST_ASSERT_EQUAL(6, tproto_00.string_val_size());
  TEST_EXPECT_EQUAL("900778111", tproto_00.string_val(0));
  TEST_EXPECT_EQUAL("104436333", tproto_00.string_val(1));
  TEST_EXPECT_EQUAL("104436444", tproto_00.string_val(2));
  TEST_EXPECT_EQUAL("900778555", tproto_00.string_val(3));
  TEST_EXPECT_EQUAL("900778777", tproto_00.string_val(4));
  TEST_EXPECT_EQUAL("900778888", tproto_00.string_val(5));
  
  FUNC_TEST_END();
}

//sequence
void test_to_predict_request_v3_3(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  init_online_by_content_v3(str, in_str, vec, in_vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitConfig* conf = dynamic_cast<SeqHitConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)0 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  
  pb_info->set_app_id("appid10");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid11");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid12");
  pb_info->set_event_time((int64_t)0 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();

  pb_info->set_app_id("appid20");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid21");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid22");
  pb_info->set_event_time((int64_t)0 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");

  tensorflow::SequenceExample* item1 = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list1 = (*(item1->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate1 = feat_list1.add_feature();
  fate1->mutable_bytes_list()->add_value("appid10");
  fate1->mutable_bytes_list()->add_value("appid11");
  fate1 = feat_list1.add_feature();
  fate1->mutable_bytes_list()->add_value("appid12");

  tensorflow::SequenceExample* item2 = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list2 = (*(item2->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate2 = feat_list2.add_feature();
  fate2->mutable_bytes_list()->add_value("appid20");
  fate2->mutable_bytes_list()->add_value("appid21");
  fate2 = feat_list2.add_feature();
  fate2->mutable_bytes_list()->add_value("appid22");


  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(3, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_ASSERT_EQUAL(0, list.feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value_size());
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value(0));

  //在线
  uint32_t item_start_index = 1;
  uint32_t item_end_index = 3;
  to_predict_request_v3(vec, in_vec, &arena, &request, &ret, item_start_index, item_end_index);

  auto& map = ret.inputs();

  auto itr = map.find("f6");
  auto itr_len = map.find("f6_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(8, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(3));

  TEST_EXPECT_EQUAL(0, tvalues.int64_val(4));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(5));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(6));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(7));

  TEST_ASSERT_EQUAL(2, tlen.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen.int_val(0));
  TEST_EXPECT_EQUAL(2, tlen.int_val(1));
  
  FUNC_TEST_END();
}

//E@开头的request允许为空
void test_request_empty_1(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit", 
          "source": [
              "E@.user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              "E@.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  JsonConfigMgr::parse_from_string(str, vec);
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitConfig* conf = dynamic_cast<SeqHitConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_ASSERT_EQUAL(0, list.feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(0, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value_size());
  TEST_ASSERT_EQUAL(0, list.feature(1).int64_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f6");
  auto itr_len = map.find("f6_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(4, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen.int_val(0));
  
  FUNC_TEST_END();
}

//无E@开头的request开头不允许为空
void test_request_empty_2(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitConfig* conf = dynamic_cast<SeqHitConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");
  
  bool flag = false;
  try {
    toSequenceExample(&arena, request, vec, batch_ret);
  } catch (const std::runtime_error& e) {
    std::cout << e.what() << std::endl;
    flag = true;
  }
  TEST_EXPECT_EQUAL(true, flag);
  
  FUNC_TEST_END();
}

//featurelist
void test_seq_n_1(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_n",
        "source": [
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
          ".request_time"
        ],
        "save" : true, 
        "end" : 86401,
        "start" : 60,
        "clip_size": 3, 
        "default_value": "life is life!"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104435568"); //false
  pb_info->set_event_time(5 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436666"); //false
  pb_info->set_event_time(11 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570"); //false
  pb_info->set_event_time(9 * 86404 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570"); //true
  pb_info->set_event_time(9 * 86401 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436777"); //true
  pb_info->set_event_time(9 * 86403 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104436888"); //false
  pb_info->set_event_time(9 * 86402 * 1000);

  /* 
    toSequenceExample函数根据item size确定输出batch，因此至少要有一个item字段
  */
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_feature_lists());

  const auto& map0 = ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f0");

  TEST_ASSERT_BOOL(itr0 != map0.end());
  TEST_ASSERT_EQUAL(3, itr0->second.feature_size());

  TEST_ASSERT_EQUAL(1, itr0->second.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr0->second.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL(1, itr0->second.feature(2).bytes_list().value_size());

  TEST_EXPECT_EQUAL("900778570", itr0->second.feature(0).bytes_list().value(0));
  TEST_EXPECT_EQUAL("104436777", itr0->second.feature(1).bytes_list().value(0));
  TEST_EXPECT_EQUAL("104436888", itr0->second.feature(2).bytes_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  auto itr = map.find("f0");
  auto itr_len = map.find("f0_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(3, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("900778570", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("104436777", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("104436888", tvalues.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen.int_val(0));

  ////////////
  //空值测试
  qinglong::FeRequest request1;
  qinglong::BatchSequenceExample ret1;

  qinglong::UserFeature* pb_ufv21 = request1.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use1 = pb_ufv21->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use1->add_user_sequence();

  pb_use->add_user_sequence();
  pb_use->add_user_sequence();

  request1.add_item_feature();

  toSequenceExample(&arena, request1, vec, ret1);

  TEST_ASSERT_EQUAL(1, ret1.batch_size());
  TEST_ASSERT_EQUAL(true, ret1.batch(0).has_feature_lists());

  const auto& map1 = ret1.batch(0).feature_lists().feature_list();
  auto itr1 = map1.find("f0");

  TEST_ASSERT_EQUAL(1, itr1->second.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("life is life!", itr1->second.feature(0).bytes_list().value(0));

  FUNC_TEST_END();
}

//feature
void test_seq_n_2(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_n",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ],
        "save" : true,
        "end" : 86401,
        "start" : 60,
        "clip_size": 3
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  // 请求时间
  request.set_request_time(10 * 86400 * 1000);

  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436666");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436777");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436888");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)11 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86404 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86401 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86403 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86402 * 1000);

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr0 = map0.find("f0");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  TEST_ASSERT_EQUAL(3, itr0->second.bytes_list().value_size());

  TEST_EXPECT_EQUAL("900778570", itr0->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("104436777", itr0->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("104436888", itr0->second.bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);
  
  auto& map = pre_ret.inputs();

  auto itr_values = map.find("f0_values");
  auto itr_indices = map.find("f0_indices");
  auto itr_dense_shape = map.find("f0_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(3, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("900778570", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("104436777", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("104436888", tvalues.string_val(2));

  TEST_ASSERT_EQUAL(6, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape.int64_val(1));
  
  FUNC_TEST_END();
}

//默认参数
void test_seq_n_3(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_n",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f0": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  // 请求时间
  request.set_request_time(12 * 86400 * 1000);

  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104435568");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104436777");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)11 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)10 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)7 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, ret);
  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  auto itr0 = map0.find("f0");
  TEST_ASSERT_BOOL(itr0 != map0.end());
  TEST_FEATURE_STR(({"104435568", "104436777", "900778570"}), itr0->second);

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);
  
  auto& map = pre_ret.inputs();

  auto itr_values = map.find("f0_values");
  auto itr_indices = map.find("f0_indices");
  auto itr_dense_shape = map.find("f0_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2}), ({1, 3}), ({"104435568", "104436777", "900778570"}),
                          itr_indices->second, itr_dense_shape->second, itr_values->second);

  FUNC_TEST_END();
}

//feature
void test_seq_n_v2_1(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_n_v2",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ],
        "end" : 864000,
        "start" : 86400,
        "clip_size": 4,
        "default_value" : "test_no_date"
      },
      "f1" : {
          "fe_type" : "direct", 
          "source": ["f0:0"]
      },
      "f2" : {
          "fe_type" : "direct", 
          "source": ["f0:1"]
      },
      "f3" : {
          "fe_type" : "direct", 
          "source": ["f0:2"]
      },
      "f4" : {
          "fe_type" : "direct", 
          "source": ["f0:3"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f1": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f2": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f3": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f4": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(5, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqNV2Config* conf = dynamic_cast<SeqNV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  // 请求时间
  request.set_request_time((int64_t)15 * 86400 * 1000);

  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("001");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("002");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("003");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("004");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("005");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("006");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("006");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)8 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)14 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)12 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)4 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)10 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)11 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("000");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)2 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr01 = map00.find("f1");
  auto itr11 = map01.find("f1");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_STR(({"003", "005", "006"}), itr01->second);
  TEST_FEATURE_STR(({"test_no_date"}), itr11->second);  

  auto itr02 = map00.find("f2");
  auto itr12 = map01.find("f2");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_STR(({"003_1", "005_1", "006_2"}), itr02->second);
  TEST_FEATURE_STR(({"test_no_date"}), itr12->second);

  auto itr03 = map00.find("f3");
  auto itr13 = map01.find("f3");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());

  TEST_FEATURE_STR(({"003_1036800", "006_950400", "006_864000", "005_777600"}), itr03->second);
  TEST_FEATURE_STR(({"test_no_date"}), itr13->second);

  auto itr04 = map00.find("f4");
  auto itr14 = map01.find("f4");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_ASSERT_BOOL(itr14 != map01.end());

  TEST_FEATURE_STR(({"003_259200", "006_345600", "006_432000", "005_518400"}), itr04->second);
  TEST_FEATURE_STR(({"test_no_date"}), itr14->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);
  
  auto& map = ret.inputs();

  auto itr_values0 = map.find("f1_values");
  auto itr_indices0 = map.find("f1_indices");
  auto itr_dense_shape0 = map.find("f1_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"003", "005", "006", "test_no_date"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f2_values");
  auto itr_indices1 = map.find("f2_indices");
  auto itr_dense_shape1 = map.find("f2_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"003_1", "005_1", "006_2", "test_no_date"}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f3_values");
  auto itr_indices2 = map.find("f3_indices");
  auto itr_dense_shape2 = map.find("f3_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 0, 3, 1, 0}), ({2, 4}),
                         ({"003_1036800", "006_950400", "006_864000", "005_777600", "test_no_date"}),
                         itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f4_values");
  auto itr_indices3 = map.find("f4_indices");
  auto itr_dense_shape3 = map.find("f4_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 0, 3, 1, 0}), ({2, 4}),
                         ({"003_259200", "006_345600", "006_432000", "005_518400", "test_no_date"}),
                         itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  FUNC_TEST_END();
}

//featurelist
void test_seq_n_v2_2(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_n_v2",
        "source": [
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
          ".request_time"
        ],
        "end" : 864000,
        "start" : 86400,
        "clip_size": 4,
        "default_value" : "test_no_date"
      },
      "f1" : {
          "fe_type" : "direct", 
          "source": ["f0:0"]
      },
      "f2" : {
          "fe_type" : "direct", 
          "source": ["f0:1"]
      },
      "f3" : {
          "fe_type" : "direct", 
          "source": ["f0:2"]
      },
      "f4" : {
          "fe_type" : "direct", 
          "source": ["f0:3"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f1": {
            "dtype" : "string",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        },
        "f2": {
            "dtype" : "string",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        },
        "f3": {
            "dtype" : "string",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        },
        "f4": {
            "dtype" : "string",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(5, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqNV2Config* conf = dynamic_cast<SeqNV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  // 请求时间
  request.set_request_time((int64_t)15 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("001"); //false
  pb_info->set_event_time(8 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("002"); //false
  pb_info->set_event_time(14 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("003"); //true
  pb_info->set_event_time(12 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("004"); //false
  pb_info->set_event_time(4 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("005"); //true
  pb_info->set_event_time(9 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("006"); //true
  pb_info->set_event_time(10 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("006"); //true
  pb_info->set_event_time(11 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f1");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"003"}, {"005"}, {"006"}}), itr00->second);

  auto itr01 = map00.find("f2");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"003_1"}, {"005_1"}, {"006_2"}}), itr01->second);

  auto itr02 = map00.find("f3");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"003_1036800"}, {"006_950400"}, {"006_864000"}, {"005_777600"}}), itr02->second);

  auto itr03 = map00.find("f4");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_STR(({{"003_259200"}, {"006_345600"}, {"006_432000"}, {"005_518400"}}), itr03->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f1");
  auto itr_len0 = map.find("f1_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"003", "005", "006"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f2");
  auto itr_len1 = map.find("f2_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"003_1", "005_1", "006_2"}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  auto itr2 = map.find("f3");
  auto itr_len2 = map.find("f3_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"003_1036800", "006_950400", "006_864000", "005_777600"}), itr2->second);
  TEST_LIST_INT32(({4}), itr_len2->second);

  auto itr3 = map.find("f4");
  auto itr_len3 = map.find("f4_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_STRING(({"003_259200", "006_345600", "006_432000", "005_518400"}), itr3->second);
  TEST_LIST_INT32(({4}), itr_len3->second);

  FUNC_TEST_END();
}

//默认参数
void test_seq_n_v2_3(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_n_v2",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time",
          ".request_time"
        ]
      },
      "f1" : {
          "fe_type" : "direct", 
          "source": ["f0:0"]
      },
      "f2" : {
          "fe_type" : "direct", 
          "source": ["f0:1"]
      },
      "f3" : {
          "fe_type" : "direct", 
          "source": ["f0:2"]
      },
      "f4" : {
          "fe_type" : "direct", 
          "source": ["f0:3"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f1": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f2": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f3": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f4": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(5, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqNV2Config* conf = dynamic_cast<SeqNV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  // 请求时间
  request.set_request_time((int64_t)15 * 86400 * 1000);

  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("001");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("002");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("003");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)8 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)14 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)12 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("000");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)20 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr01 = map00.find("f1");
  auto itr11 = map01.find("f1");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_STR(({"001", "002", "003"}), itr01->second);
  TEST_FEATURE_STR(({"NOT_EXIST"}), itr11->second);  

  auto itr02 = map00.find("f2");
  auto itr12 = map01.find("f2");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_STR(({"001_1", "002_1", "003_1"}), itr02->second);
  TEST_FEATURE_STR(({"NOT_EXIST"}), itr12->second);

  auto itr03 = map00.find("f3");
  auto itr13 = map01.find("f3");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());

  TEST_FEATURE_STR(({"002_1209600", "003_1036800", "001_691200"}), itr03->second);
  TEST_FEATURE_STR(({"NOT_EXIST"}), itr13->second);

  auto itr04 = map00.find("f4");
  auto itr14 = map01.find("f4");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_ASSERT_BOOL(itr14 != map01.end());

  TEST_FEATURE_STR(({"002_86400", "003_259200", "001_604800"}), itr04->second);
  TEST_FEATURE_STR(({"NOT_EXIST"}), itr14->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);
  
  auto& map = ret.inputs();

  auto itr_values0 = map.find("f1_values");
  auto itr_indices0 = map.find("f1_indices");
  auto itr_dense_shape0 = map.find("f1_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"001", "002", "003", "NOT_EXIST"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f2_values");
  auto itr_indices1 = map.find("f2_indices");
  auto itr_dense_shape1 = map.find("f2_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"001_1", "002_1", "003_1", "NOT_EXIST"}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f3_values");
  auto itr_indices2 = map.find("f3_indices");
  auto itr_dense_shape2 = map.find("f3_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}),
                         ({"002_1209600", "003_1036800", "001_691200", "NOT_EXIST"}),
                         itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f4_values");
  auto itr_indices3 = map.find("f4_indices");
  auto itr_dense_shape3 = map.find("f4_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}),
                         ({"002_86400", "003_259200", "001_604800", "NOT_EXIST"}),
                         itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  FUNC_TEST_END();
}

//featurelist
void test_seq_hit_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitConfig* conf = dynamic_cast<SeqHitConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)0 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_ASSERT_EQUAL(0, list.feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value_size());
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f6");
  auto itr_len = map.find("f6_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(4, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen.int_val(0));
  
  FUNC_TEST_END();
}

//feature
void test_seq_hit_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "start" : 864000
      }
    }
  })";

   std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitConfig* conf = dynamic_cast<SeqHitConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(3 == itr00->second.kind_case());
  TEST_ASSERT_EQUAL(3, itr00->second.int64_list().value_size());
  TEST_ASSERT_EQUAL(0, itr00->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr00->second.int64_list().value(1));
  TEST_ASSERT_EQUAL(1, itr00->second.int64_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f6_values");
  auto itr_indices = map.find("f6_indices");
  auto itr_dense_shape = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(3, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(2));

  TEST_ASSERT_EQUAL(6, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape.int64_val(1));

  FUNC_TEST_END();
}

//feature
void test_seq_hit_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ]
      }
    }
  })";

   std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitConfig* conf = dynamic_cast<SeqHitConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid1");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_INT64(({1, 1}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f6_values");
  auto itr_indices = map.find("f6_indices");
  auto itr_dense_shape = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1}), ({1, 2}), ({1, 1}),
                          itr_indices->second, itr_dense_shape->second, itr_values->second);

  FUNC_TEST_END();
}

//featurelist
void test_seq_hit_num_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_num", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000,
          "max_num" : 2
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitNumConfig* conf = dynamic_cast<SeqHitNumConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)70 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)60 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)40 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_ASSERT_EQUAL(0, list.feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(1, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value_size());
  TEST_ASSERT_EQUAL(2, list.feature(1).int64_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f6");
  auto itr_len = map.find("f6_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(4, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(2, tvalues.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen.int_val(0));
  
  FUNC_TEST_END();
}

//feature
void test_seq_hit_num_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_num", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "start" : 864000,
          "max_num" : 2
      }
    }
  })";

   std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitNumConfig* conf = dynamic_cast<SeqHitNumConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)70 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)40 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(3 == itr00->second.kind_case());
  TEST_ASSERT_EQUAL(3, itr00->second.int64_list().value_size());
  TEST_ASSERT_EQUAL(0, itr00->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(1, itr00->second.int64_list().value(1));
  TEST_ASSERT_EQUAL(2, itr00->second.int64_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f6_values");
  auto itr_indices = map.find("f6_indices");
  auto itr_dense_shape = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(3, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(1, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(2, tvalues.int64_val(2));

  TEST_ASSERT_EQUAL(6, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape.int64_val(1));

  FUNC_TEST_END();
}

//feature
void test_seq_hit_num_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_num", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "max_num" : 2
      }
    }
  })";

   std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitNumConfig* conf = dynamic_cast<SeqHitNumConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)70 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_INT64(({2}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f6_values");
  auto itr_indices = map.find("f6_indices");
  auto itr_dense_shape = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({1, 1}), ({2}),
                          itr_indices->second, itr_dense_shape->second, itr_values->second);

  FUNC_TEST_END();
}

//featurelist
void test_seq_hit_duration_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_duration", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitDurationConfig* conf = dynamic_cast<SeqHitDurationConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)70 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)40 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)60 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).int64_list().value_size());
  TEST_ASSERT_EQUAL(-1, list.feature(0).int64_list().value(0));
  TEST_ASSERT_EQUAL(14, list.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list.feature(1).int64_list().value_size());
  TEST_ASSERT_EQUAL(15, list.feature(1).int64_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f6");
  auto itr_len = map.find("f6_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(4, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(-1, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(14, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(15, tvalues.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen.int_val(0));
  
  FUNC_TEST_END();
}

//feature
void test_seq_hit_duration_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_duration", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "start" : 864000
      }
    }
  })";

   std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitDurationConfig* conf = dynamic_cast<SeqHitDurationConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)70 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)40 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(3 == itr00->second.kind_case());
  TEST_ASSERT_EQUAL(3, itr00->second.int64_list().value_size());
  TEST_ASSERT_EQUAL(-1, itr00->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(14, itr00->second.int64_list().value(1));
  TEST_ASSERT_EQUAL(15, itr00->second.int64_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f6_values");
  auto itr_indices = map.find("f6_indices");
  auto itr_dense_shape = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(3, tvalues.int64_val_size());
  TEST_EXPECT_EQUAL(-1, tvalues.int64_val(0));
  TEST_EXPECT_EQUAL(14, tvalues.int64_val(1));
  TEST_EXPECT_EQUAL(15, tvalues.int64_val(2));

  TEST_ASSERT_EQUAL(6, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape.int64_val(1));

  FUNC_TEST_END();
}

//默认参数
void test_seq_hit_duration_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_duration", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ]
      }
    }
  })";

   std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitDurationConfig* conf = dynamic_cast<SeqHitDurationConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_INT64(({12, 14, -1}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f6_values");
  auto itr_indices = map.find("f6_indices");
  auto itr_dense_shape = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2}), ({1, 3}), ({12, 14, -1}),
                          itr_indices->second, itr_dense_shape->second, itr_values->second);

  FUNC_TEST_END();
}

void test_seq_hit_list_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_list", 
          "source": [
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration",
            ".item_feature.item_id.app_id"
          ]
      },
      "f7" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitListConfig* conf = dynamic_cast<SeqHitListConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_use_duration((int64_t)1 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_use_duration((int64_t)2 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_use_duration((int64_t)5 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_use_duration((int64_t)6 * 3600 * 1000);

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("appid1");
  request.add_item_feature()->mutable_item_id()->set_app_id("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"appid1", "appid1"}), itr00->second);
  TEST_FEATURE_STR(({"appid2"}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({(int64_t)2 * 3600 * 1000, (int64_t)6 * 3600 * 1000}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)5 * 3600 * 1000}), itr11->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0}), ({2, 2}), ({"appid1", "appid1", "appid2"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f8_values");
  auto itr_indices1 = map.find("f8_indices");
  auto itr_dense_shape1 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 1, 0}), ({2, 2}), ({(int64_t)2 * 3600 * 1000, (int64_t)6 * 3600 * 1000, (int64_t)5 * 3600 * 1000}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_seq_hit_list_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_list", 
          "source": [
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_source",
            ".item_feature.game_item_offline_feature.game_item_atrribute_feature.app_name"
          ]
      },
      "f7" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f8": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitListConfig* conf = dynamic_cast<SeqHitListConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_source("游戏中心0");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_source("应用市场1");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_source("游戏中心2");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_source("游戏中心3");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_source("应用市场4");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_source("游戏中心5");

  // item不为空
  qinglong::GameItemAttributeFeature* item = request.add_item_feature()->mutable_game_item_offline_feature()->mutable_game_item_atrribute_feature();
  item->add_app_name("appid2");
  item->add_app_name("appid1");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2", "appid2"}, {"appid1", "appid1"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"游戏中心3", "游戏中心5"}, {"应用市场1", "应用市场4"}}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid2", "appid2", "appid1", "appid1"}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"游戏中心3", "游戏中心5", "应用市场1", "应用市场4"}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  FUNC_TEST_END();
}

void test_seq_hit_list_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_list", 
          "source": [
            ".item_feature.item_feature_se.context.feature.app_id",
            ".item_feature.item_feature_se.context.feature.float",
            ".item_feature.item_feature_se.context.feature.name"
          ]
      },
      "f7" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f8": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitListConfig* conf = dynamic_cast<SeqHitListConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(0.28);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(0.19);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(0.11);

  (*(item->mutable_context()->mutable_feature()))["name"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["name"].mutable_bytes_list()->add_value("appid0");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(0.13);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(0.87);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(0.59);

  (*(item->mutable_context()->mutable_feature()))["name"].mutable_bytes_list()->add_value("appid1");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"appid2", "appid2", "appid0", "appid0"}), itr00->second);
  TEST_FEATURE_STR(({"appid1", "appid1"}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_FLOAT(({0.11, 0.59, 0.28, 0.13}), itr01->second);
  TEST_FEATURE_FLOAT(({0.19, 0.87}), itr11->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 0, 3, 1, 0, 1, 1}), ({2, 4}), ({"appid2", "appid2", "appid0", "appid0", "appid1", "appid1"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f8_values");
  auto itr_indices1 = map.find("f8_indices");
  auto itr_dense_shape1 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 0, 2, 0, 3, 1, 0, 1, 1}), ({2, 4}), ({0.11, 0.59, 0.28, 0.13, 0.19, 0.87}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

//feature_base
template <typename T>
void test_seq_hit_list_base(const std::vector<std::string> appid_value,
                            const std::vector<T> list_value,
                            const std::vector<std::string> find_value,
                            const std::vector<std::string> out_value1,
                            const std::vector<T> out_value2) {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_list", 
          "source": [
            ".item_feature.item_feature_se.context.feature.app_id",
            ".item_feature.item_feature_se.context.feature.value",
            ".item_feature.item_feature_se.context.feature.name"
          ]
      },
      "f7" : {
          "fe_type" : "direct",
          "strategy" : "empty", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "strategy" : "empty",
          "source": ["f6:1"]
      }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_BOOL(nullptr != vec[0]);
  SeqHitListConfig* conf = dynamic_cast<SeqHitListConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;


  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  for (uint32_t i = 0; i < appid_value.size(); i++) {
    (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value(appid_value[i]);
  }

  for (uint32_t i = 0; i < find_value.size(); i++) {
    (*(item->mutable_context()->mutable_feature()))["name"].mutable_bytes_list()->add_value(find_value[i]);
  }

  fill_map_data((*(item->mutable_context()->mutable_feature())), list_value, "value");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR({out_value1}, itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  feature_equal(out_value2, itr01->second);

  FUNC_TEST_END();
}

//feature
void test_no_date() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "start" : 864000
      },
      "f7": {
          "fe_type" : "seq_hit_num", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "start" : 864000,
          "max_num" : 2
      },
      "f8": {
          "fe_type" : "seq_hit_duration", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "start" : 864000
      }
    },
    "default_values": {
        ".item_feature.item_feature_se.context.feature.appid": {
            "dtype": "string",
            "values": ["appid20", "appid30", "appid40"] 
        },
        ".item_feature.item_feature_se.context.feature.time": {
            "dtype": "int64",
            "values": [864000, 8640000, 1864000]
        }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f7": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitConfig* conf = dynamic_cast<SeqHitConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"];

  (*(item->mutable_context()->mutable_feature()))["time"];

  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid2");
 
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(3 == itr00->second.kind_case());
  TEST_ASSERT_EQUAL(3, itr00->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(0, itr00->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(0, itr00->second.int64_list().value(1));
  TEST_EXPECT_EQUAL(0, itr00->second.int64_list().value(2));

  auto itr01 = map00.find("f7");

  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(3 == itr01->second.kind_case());
  TEST_ASSERT_EQUAL(3, itr01->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(0, itr01->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(0, itr01->second.int64_list().value(1));
  TEST_EXPECT_EQUAL(0, itr01->second.int64_list().value(2));

  auto itr02 = map00.find("f8");

  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(3 == itr02->second.kind_case());
  TEST_ASSERT_EQUAL(3, itr02->second.int64_list().value_size());
  TEST_EXPECT_EQUAL(-1, itr02->second.int64_list().value(0));
  TEST_EXPECT_EQUAL(-1, itr02->second.int64_list().value(1));
  TEST_EXPECT_EQUAL(-1, itr02->second.int64_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values00 = map.find("f6_values");
  auto itr_indices00 = map.find("f6_indices");
  auto itr_dense_shape00 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values00 != map.end());
  TEST_ASSERT_BOOL(itr_indices00 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape00 != map.end());

  auto& tdense_shape00 = itr_dense_shape00->second;

  TEST_ASSERT_EQUAL(2, tdense_shape00.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape00.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape00.int64_val(1));

  auto itr_values01 = map.find("f7_values");
  auto itr_indices01 = map.find("f7_indices");
  auto itr_dense_shape01 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values01 != map.end());
  TEST_ASSERT_BOOL(itr_indices01 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape01 != map.end());

  auto& tdense_shape01 = itr_dense_shape01->second;

  TEST_ASSERT_EQUAL(2, tdense_shape01.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape01.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape01.int64_val(1));

  auto itr_values02 = map.find("f8_values");
  auto itr_indices02 = map.find("f8_indices");
  auto itr_dense_shape02 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values02 != map.end());
  TEST_ASSERT_BOOL(itr_indices02 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape02 != map.end());

  auto& tdense_shape02 = itr_dense_shape02->second;

  TEST_ASSERT_EQUAL(2, tdense_shape02.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape02.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape02.int64_val(1));

  FUNC_TEST_END();
}

//featurelist
void test_no_date_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000
      },
      "f7": {
          "fe_type" : "seq_hit_num", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000,
          "max_num" : 2
      },
      "f8": {
          "fe_type" : "seq_hit_duration", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f7": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }        
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitConfig* conf = dynamic_cast<SeqHitConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();

  pb_use->add_user_sequence();
  pb_use->add_user_sequence();
  pb_use->add_user_sequence();

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  const auto& list00 = itr00->second;
  TEST_ASSERT_EQUAL(2, list00.feature_size());
  TEST_ASSERT_EQUAL(2, list00.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(0, list00.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(0, list00.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list00.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(0, list00.feature(1).int64_list().value(0));

  auto itr01 = map00.find("f7");

  TEST_ASSERT_BOOL(itr01 != map00.end());
  const auto& list01 = itr01->second;
  TEST_ASSERT_EQUAL(2, list01.feature_size());
  TEST_ASSERT_EQUAL(2, list01.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(0, list01.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(0, list01.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list01.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(0, list01.feature(1).int64_list().value(0));

  auto itr02 = map00.find("f8");

  TEST_ASSERT_BOOL(itr02 != map00.end());
  const auto& list02 = itr02->second;
  TEST_ASSERT_EQUAL(2, list02.feature_size());
  TEST_ASSERT_EQUAL(2, list02.feature(0).int64_list().value_size());
  TEST_EXPECT_EQUAL(-1, list02.feature(0).int64_list().value(0));
  TEST_EXPECT_EQUAL(-1, list02.feature(0).int64_list().value(1));
  TEST_ASSERT_EQUAL(1, list02.feature(1).int64_list().value_size());
  TEST_EXPECT_EQUAL(-1, list02.feature(1).int64_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr03 = map.find("f6");
  auto itr_len00 = map.find("f6_length");

  TEST_ASSERT_BOOL(itr03 != map.end());
  TEST_ASSERT_BOOL(itr_len00 != map.end());

  auto& tvalues00 = itr03->second;
  auto& tlen00 = itr_len00->second;

  TEST_ASSERT_EQUAL(4, tvalues00.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues00.int64_val(0));
  TEST_EXPECT_EQUAL(0, tvalues00.int64_val(1));
  TEST_EXPECT_EQUAL(0, tvalues00.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues00.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen00.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen00.int_val(0));

  auto itr04 = map.find("f7");
  auto itr_len01 = map.find("f7_length");

  TEST_ASSERT_BOOL(itr04 != map.end());
  TEST_ASSERT_BOOL(itr_len01 != map.end());

  auto& tvalues01 = itr04->second;
  auto& tlen01 = itr_len01->second;

  TEST_ASSERT_EQUAL(4, tvalues01.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues01.int64_val(0));
  TEST_EXPECT_EQUAL(0, tvalues01.int64_val(1));
  TEST_EXPECT_EQUAL(0, tvalues01.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues01.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen01.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen01.int_val(0));

  auto itr05 = map.find("f8");
  auto itr_len02 = map.find("f8_length");

  TEST_ASSERT_BOOL(itr05 != map.end());
  TEST_ASSERT_BOOL(itr_len02 != map.end());

  auto& tvalues02 = itr05->second;
  auto& tlen02 = itr_len02->second;

  TEST_ASSERT_EQUAL(4, tvalues02.int64_val_size());
  TEST_EXPECT_EQUAL(-1, tvalues02.int64_val(0));
  TEST_EXPECT_EQUAL(-1, tvalues02.int64_val(1));
  TEST_EXPECT_EQUAL(-1, tvalues02.int64_val(2));
  TEST_EXPECT_EQUAL(0, tvalues02.int64_val(3));

  TEST_ASSERT_EQUAL(1, tlen02.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen02.int_val(0));
  
  FUNC_TEST_END();
}

//设置default_value
void test_no_date_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "start" : 864000,
          "default_value" : 0
      },
      "f7": {
          "fe_type" : "seq_hit_num", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "start" : 864000,
          "max_num" : 2,
          "default_value" : 0
      },
      "f8": {
          "fe_type" : "seq_hit_duration", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "start" : 864000,
          "default_value" : 0
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f7": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitConfig* conf = dynamic_cast<SeqHitConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  
  pb_use->add_user_sequence();
  pb_use->add_user_sequence();
  pb_use->add_user_sequence();

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();

  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("appid2");
 
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(3 == itr00->second.kind_case());
  TEST_ASSERT_EQUAL(3, itr00->second.int64_list().value_size());
  TEST_ASSERT_EQUAL(0, itr00->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(0, itr00->second.int64_list().value(1));
  TEST_ASSERT_EQUAL(0, itr00->second.int64_list().value(2));

  auto itr01 = map00.find("f7");

  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(3 == itr01->second.kind_case());
  TEST_ASSERT_EQUAL(3, itr01->second.int64_list().value_size());
  TEST_ASSERT_EQUAL(0, itr01->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(0, itr01->second.int64_list().value(1));
  TEST_ASSERT_EQUAL(0, itr01->second.int64_list().value(2));

  auto itr02 = map00.find("f8");

  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(3 == itr02->second.kind_case());
  TEST_ASSERT_EQUAL(3, itr02->second.int64_list().value_size());
  TEST_ASSERT_EQUAL(0, itr02->second.int64_list().value(0));
  TEST_ASSERT_EQUAL(0, itr02->second.int64_list().value(1));
  TEST_ASSERT_EQUAL(0, itr02->second.int64_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values00 = map.find("f6_values");
  auto itr_indices00 = map.find("f6_indices");
  auto itr_dense_shape00 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values00 != map.end());
  TEST_ASSERT_BOOL(itr_indices00 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape00 != map.end());

  auto& tvalues00 = itr_values00->second;
  auto& tindices00 = itr_indices00->second;
  auto& tdense_shape00 = itr_dense_shape00->second;

  TEST_ASSERT_EQUAL(3, tvalues00.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues00.int64_val(0));
  TEST_EXPECT_EQUAL(0, tvalues00.int64_val(1));
  TEST_EXPECT_EQUAL(0, tvalues00.int64_val(2));

  TEST_ASSERT_EQUAL(6, tindices00.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices00.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices00.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices00.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices00.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices00.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices00.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape00.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape00.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape00.int64_val(1));

  auto itr_values01 = map.find("f7_values");
  auto itr_indices01 = map.find("f7_indices");
  auto itr_dense_shape01 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values01 != map.end());
  TEST_ASSERT_BOOL(itr_indices01 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape01 != map.end());

  auto& tvalues01 = itr_values01->second;
  auto& tindices01 = itr_indices01->second;
  auto& tdense_shape01 = itr_dense_shape01->second;

  TEST_ASSERT_EQUAL(3, tvalues01.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues01.int64_val(0));
  TEST_EXPECT_EQUAL(0, tvalues01.int64_val(1));
  TEST_EXPECT_EQUAL(0, tvalues01.int64_val(2));

  TEST_ASSERT_EQUAL(6, tindices01.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices01.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices01.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices01.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices01.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices01.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices01.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape01.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape01.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape01.int64_val(1));

  auto itr_values02 = map.find("f8_values");
  auto itr_indices02 = map.find("f8_indices");
  auto itr_dense_shape02 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values02 != map.end());
  TEST_ASSERT_BOOL(itr_indices02 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape02 != map.end());

  auto& tvalues02 = itr_values00->second;
  auto& tindices02 = itr_indices00->second;
  auto& tdense_shape02 = itr_dense_shape02->second;

  TEST_ASSERT_EQUAL(3, tvalues02.int64_val_size());
  TEST_EXPECT_EQUAL(0, tvalues02.int64_val(0));
  TEST_EXPECT_EQUAL(0, tvalues02.int64_val(1));
  TEST_EXPECT_EQUAL(0, tvalues02.int64_val(2));

  TEST_ASSERT_EQUAL(6, tindices02.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices02.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices02.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices02.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices02.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices02.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices02.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape02.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape02.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape02.int64_val(1));

  FUNC_TEST_END();
}

//设置default_value
void test_no_date_4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_hit" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time,E@.item_feature.item_feature_se.feature_lists.feature_list.item" start="864000" default_value="-1" />
            <feature name="f7" type="seq_hit_num" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time,E@.item_feature.item_feature_se.feature_lists.feature_list.item"  start="864000" default_value="-1" max_num="2" />
            <feature name="f8" type="seq_hit_duration" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time,E@.item_feature.item_feature_se.feature_lists.feature_list.item"  start="864000" default_value="-1" />
            <feature name="f9" type="seq_hit_value" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time,E@.item_feature.item_feature_se.feature_lists.feature_list.item"  start="864000" default_value="-1" />
            <feature name="f10" type="stat_ctr" source="E@.item_feature.item_feature_se.feature_lists.feature_list.item,E@.item_feature.item_feature_se.feature_lists.feature_list.item" min_expo="100" default_value="-1" />
            <feature name="f11" type="stat_ctr_bucket" source="E@.item_feature.item_feature_se.feature_lists.feature_list.item"  bucket_type="2" default_value="-1" />
        </features>
    </config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);
  TEST_ASSERT_EQUAL(6, vec.size());

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  
  pb_use->add_user_sequence();
  pb_use->add_user_sequence();
  pb_use->add_user_sequence();

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();

  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  feat_list.add_feature();

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
 
  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map1 = batch_ret.batch(1).feature_lists().feature_list();

  auto itr00 = map0.find("f6");
  auto itr10 = map1.find("f6");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_FEATURE_LIST_INT64(({{0}, {-1}}), itr00->second);
  TEST_FEATURE_LIST_INT64(({{-1}}), itr10->second);

  auto itr01 = map0.find("f7");
  auto itr11 = map1.find("f7");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());
  TEST_FEATURE_LIST_INT64(({{0}, {-1}}), itr01->second);
  TEST_FEATURE_LIST_INT64(({{-1}}), itr11->second);

  auto itr02 = map0.find("f8");
  auto itr12 = map1.find("f8");
  TEST_ASSERT_BOOL(itr02 != map0.end());
  TEST_ASSERT_BOOL(itr12 != map1.end());
  TEST_FEATURE_LIST_INT64(({{-1}, {-1}}), itr02->second);
  TEST_FEATURE_LIST_INT64(({{-1}}), itr12->second);

  auto itr03 = map0.find("f9");
  auto itr13 = map1.find("f9");
  TEST_ASSERT_BOOL(itr03 != map0.end());
  TEST_ASSERT_BOOL(itr13 != map1.end());
  TEST_FEATURE_LIST_STR(({{"-1"}, {"-1"}}), itr03->second);
  TEST_FEATURE_LIST_STR(({{"-1"}}), itr13->second);

  auto itr04 = map0.find("f10");
  auto itr14 = map1.find("f10");
  TEST_ASSERT_BOOL(itr04 != map0.end());
  TEST_ASSERT_BOOL(itr14 != map1.end());
  TEST_FEATURE_LIST_FLOAT(({{-1}, {-1}}), itr04->second);
  TEST_FEATURE_LIST_FLOAT(({{-1}}), itr14->second);

  auto itr05 = map0.find("f11");
  auto itr15 = map1.find("f11");
  TEST_ASSERT_BOOL(itr05 != map0.end());
  TEST_ASSERT_BOOL(itr15 != map1.end());
  TEST_FEATURE_LIST_FLOAT(({{-1}, {-1}}), itr05->second);
  TEST_FEATURE_LIST_FLOAT(({{-1}}), itr15->second);

  FUNC_TEST_END();
}

//item 是feature
void test_cross2_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "cross2", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.context.feature.item"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("000");
  pb_use->add_user_sequence()->set_app_id("001");
  pb_use->add_user_sequence()->set_app_id("002");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("123");
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("456");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f15");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list00 = itr0->second;
  TEST_ASSERT_EQUAL(6, list00.feature_size());
  TEST_ASSERT_EQUAL(1, list00.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("000123", list00.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("000456", list00.feature(1).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(2).bytes_list().value_size());
  TEST_EXPECT_EQUAL("001123", list00.feature(2).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(3).bytes_list().value_size());
  TEST_EXPECT_EQUAL("001456", list00.feature(3).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(4).bytes_list().value_size());
  TEST_EXPECT_EQUAL("002123", list00.feature(4).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(5).bytes_list().value_size());
  TEST_EXPECT_EQUAL("002456", list00.feature(5).bytes_list().value(0));

  const auto& map1 = batch_ret.batch(1).feature_lists().feature_list();
  auto itr1 = map1.find("f15");

  TEST_ASSERT_BOOL(itr1 != map1.end());

  const auto& list01 = itr1->second;
  TEST_ASSERT_EQUAL(6, list01.feature_size());
  TEST_ASSERT_EQUAL(1, list01.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("000123", list01.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list01.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("000456", list01.feature(1).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list01.feature(2).bytes_list().value_size());
  TEST_EXPECT_EQUAL("001123", list01.feature(2).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list01.feature(3).bytes_list().value_size());
  TEST_EXPECT_EQUAL("001456", list01.feature(3).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list01.feature(4).bytes_list().value_size());
  TEST_EXPECT_EQUAL("002123", list01.feature(4).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list01.feature(5).bytes_list().value_size());
  TEST_EXPECT_EQUAL("002456", list01.feature(5).bytes_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f15");
  auto itr_len = map.find("f15_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(12, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("000123", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("000456", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("001123", tvalues.string_val(2));
  TEST_EXPECT_EQUAL("001456", tvalues.string_val(3));
  TEST_EXPECT_EQUAL("002123", tvalues.string_val(4));
  TEST_EXPECT_EQUAL("002456", tvalues.string_val(5));
  TEST_EXPECT_EQUAL("000123", tvalues.string_val(6));
  TEST_EXPECT_EQUAL("000456", tvalues.string_val(7));
  TEST_EXPECT_EQUAL("001123", tvalues.string_val(8));
  TEST_EXPECT_EQUAL("001456", tvalues.string_val(9));
  TEST_EXPECT_EQUAL("002123", tvalues.string_val(10));
  TEST_EXPECT_EQUAL("002456", tvalues.string_val(11));

  TEST_ASSERT_EQUAL(2, tlen.int_val_size());
  TEST_EXPECT_EQUAL(6, tlen.int_val(0));

  FUNC_TEST_END();
}

//item 是featurelist 设置截断长度
void test_cross2_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "cross2", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"],
          "fea1_clip" : 2,
          "fea2_clip" : 2,
          "clip_size" : 3
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence()->set_app_id("000");
  pb_use->add_user_sequence()->set_app_id("001");
  pb_use->add_user_sequence()->set_app_id("002");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("456");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("789");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f15");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list00 = itr0->second;
  TEST_ASSERT_EQUAL(3, list00.feature_size());
  TEST_ASSERT_EQUAL(1, list00.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("000123", list00.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("000456", list00.feature(1).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(2).bytes_list().value_size());
  TEST_EXPECT_EQUAL("001123", list00.feature(2).bytes_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f15");
  auto itr_len = map.find("f15_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(3, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("000123", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("000456", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("001123", tvalues.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen.int_val(0));

  FUNC_TEST_END();
}

//两层repeated 设置截断长度
void test_cross2_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "cross2", 
          "source": [
              ".user_feature.am_gm_clk_off.gm_app_click_seq_appid_1d.value",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"],
          "fea1_clip" : 3,
          "fea2_clip" : 2,
          "clip_size" : 5
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::StringArray* pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("000");
  pb_seq->add_value("001");

  pb_seq = pb_ufv2->mutable_am_gm_clk_off()->add_gm_app_click_seq_appid_1d();
  pb_seq->add_value("010");
  pb_seq->add_value("011");
  pb_seq->add_value("012");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("456");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("789");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f15");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list00 = itr0->second;
  TEST_ASSERT_EQUAL(5, list00.feature_size());
  TEST_ASSERT_EQUAL(1, list00.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("000123", list00.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("000456", list00.feature(1).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(2).bytes_list().value_size());
  TEST_EXPECT_EQUAL("001123", list00.feature(2).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(3).bytes_list().value_size());
  TEST_EXPECT_EQUAL("001456", list00.feature(3).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(4).bytes_list().value_size());
  TEST_EXPECT_EQUAL("010123", list00.feature(4).bytes_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f15");
  auto itr_len = map.find("f15_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(5, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("000123", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("000456", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("001123", tvalues.string_val(2));
  TEST_EXPECT_EQUAL("001456", tvalues.string_val(3));
  TEST_EXPECT_EQUAL("010123", tvalues.string_val(4));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(5, tlen.int_val(0));

  FUNC_TEST_END();
}

//item 是featurelist 测试default_value,string为空值直接拼接
void test_cross2_4() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f15" : {
          "fe_type" : "cross2", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"],
          "fea1_clip" : 2,
          "fea2_clip" : 2,
          "clip_size" : 3,
          "default_value" : "test_no_data"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f15": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;
  
  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
  TEST_EXPECT_EQUAL(DATATYPE_STRING, in_vec[0]->dtype);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_use->add_user_sequence();
  pb_use->add_user_sequence();

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("123");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("456");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("789");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr0 = map0.find("f15");

  TEST_ASSERT_BOOL(itr0 != map0.end());

  const auto& list00 = itr0->second;
  TEST_ASSERT_EQUAL(3, list00.feature_size());
  TEST_ASSERT_EQUAL(1, list00.feature(0).bytes_list().value_size());
  TEST_EXPECT_EQUAL("123", list00.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(1).bytes_list().value_size());
  TEST_EXPECT_EQUAL("456", list00.feature(1).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(2).bytes_list().value_size());
  TEST_EXPECT_EQUAL("123", list00.feature(2).bytes_list().value(0));
  

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f15");
  auto itr_len = map.find("f15_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(3, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("123", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("456", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("123", tvalues.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen.int_val(0));

  FUNC_TEST_END();
}

//featurelist
void test_seq_hit_value_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_value", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time",
              ".item_feature.item_feature_se.feature_lists.feature_list.item"
          ],
          "start" : 864000
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitValueConfig* conf = dynamic_cast<SeqHitValueConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("100");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("111");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("122");
  pb_info->set_event_time((int64_t)0 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("100");
  fate->mutable_bytes_list()->add_value("111");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("122");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  const auto& list = itr00->second;
  TEST_ASSERT_EQUAL(2, list.feature_size());
  TEST_ASSERT_EQUAL(2, list.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL("NOT_EXIST", list.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL("111", list.feature(0).bytes_list().value(1));
  TEST_ASSERT_EQUAL(1, list.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL("122", list.feature(1).bytes_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f6");
  auto itr_len = map.find("f6_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  auto& tvalues = itr->second;
  auto& tlen = itr_len->second;

  TEST_ASSERT_EQUAL(4, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("NOT_EXIST", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("111", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("122", tvalues.string_val(2));
  TEST_EXPECT_EQUAL("", tvalues.string_val(3));

  TEST_ASSERT_EQUAL(1, tlen.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen.int_val(0));
  
  FUNC_TEST_END();
}

//feature
void test_seq_hit_value_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_value", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ],
          "start" : 864000
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitValueConfig* conf = dynamic_cast<SeqHitValueConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("100");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("111");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("122");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("100");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("111");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("122");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_EQUAL(3, itr00->second.bytes_list().value_size());
  TEST_ASSERT_EQUAL("NOT_EXIST", itr00->second.bytes_list().value(0));
  TEST_ASSERT_EQUAL("111", itr00->second.bytes_list().value(1));
  TEST_ASSERT_EQUAL("122", itr00->second.bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f6_values");
  auto itr_indices = map.find("f6_indices");
  auto itr_dense_shape = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  auto& tvalues = itr_values->second;
  auto& tindices = itr_indices->second;
  auto& tdense_shape = itr_dense_shape->second;

  TEST_ASSERT_EQUAL(3, tvalues.string_val_size());
  TEST_EXPECT_EQUAL("NOT_EXIST", tvalues.string_val(0));
  TEST_EXPECT_EQUAL("111", tvalues.string_val(1));
  TEST_EXPECT_EQUAL("122", tvalues.string_val(2));

  TEST_ASSERT_EQUAL(6, tindices.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape.int64_val(1));

  FUNC_TEST_END();
}

//默认参数
void test_seq_hit_value_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_value", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time",
              ".item_feature.item_feature_se.context.feature.item"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitValueConfig* conf = dynamic_cast<SeqHitValueConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("100");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("111");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("100");
  (*(item->mutable_context()->mutable_feature()))["item"].mutable_bytes_list()->add_value("111");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"100", "111"}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f6_values");
  auto itr_indices = map.find("f6_indices");
  auto itr_dense_shape = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1}), ({1, 2}), ({"100", "111"}),
                          itr_indices->second, itr_dense_shape->second, itr_values->second);

  FUNC_TEST_END();
}

//featurelist
void test_stat_ctr_and_stat_ctr_bucket_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f10" : {
          "fe_type" : "stat_ctr", 
          "source": [
              ".user_action.click",
              ".user_action.impression"],
          "min_expo" : 100,
          "default_value" : 0
      },
      "f11" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": ["f10:0"],
          "size" : 26.2,
          "bucket_type" : 1
      },
      "f12" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": ["f10:0"],
          "size" : 6.7,
          "bucket_type" : 2
      },
      "f13" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": ["f10:0"],
          "bucket_type" : 3,
          "b" : 6,
          "a" : 1,
          "k" : 2
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f10": {
            "dtype" : "float",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
         "f11": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f12": {
            "dtype" : "float",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }            
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());

  StatCtrConfig* config = dynamic_cast<StatCtrConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  StatCtrBucketConfig* config2 = dynamic_cast<StatCtrBucketConfig*>(vec[1].get());
  TEST_ASSERT_BOOL(nullptr != config2);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user_action
  qinglong::UserAction* user_action = request.add_user_action();
  user_action->set_click(380);
  user_action->set_impression(10000);
  user_action = request.add_user_action();
  user_action->set_click(549);
  user_action->set_impression(10000);
  user_action = request.add_user_action();
  user_action->set_click(1348);
  user_action->set_impression(10000);
  user_action = request.add_user_action();
  user_action->set_click(0);
  user_action->set_impression(0);

  //item不为0
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map0.find("f10");
  TEST_ASSERT_BOOL(itr00 != map0.end());

  TEST_FEATURE_LIST_FLOAT(({{0.038}, {0.0549}, {0.1348}, {0}}), itr00->second);

  auto itr01 = map0.find("f11");
  TEST_ASSERT_BOOL(itr01 != map0.end());

  TEST_FEATURE_LIST_INT64(({{0}, {1}, {3}, {0}}), itr01->second);

  auto itr02 = map0.find("f12");
  TEST_ASSERT_BOOL(itr02 != map0.end());

  TEST_ASSERT_EQUAL(4, itr02->second.feature_size());

  TEST_FEATURE_LIST_FLOAT(({{1.90776}, {1.91027}, {1.92203}, {1.90211}}), itr02->second);

  auto itr03 = map0.find("f13");
  TEST_ASSERT_BOOL(itr03 != map0.end());

  TEST_ASSERT_EQUAL(4, itr03->second.feature_size());

  TEST_FEATURE_LIST_INT64(({{0}, {0}, {1}, {0}}), itr03->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f10");
  auto itr_len0 = map.find("f10_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  TEST_LIST_FLOAT(({0.038, 0.0549, 0.1348, 0}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f11");
  auto itr_len1 = map.find("f11_length");

  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());

  TEST_LIST_INT64(({0, 1, 3, 0}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  auto itr2 = map.find("f12");
  auto itr_len2 = map.find("f12_length");

  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());

  TEST_LIST_FLOAT(({1.90776, 1.91027, 1.92203, 1.90211}), itr2->second);
  TEST_LIST_INT32(({4}), itr_len2->second);

  auto itr3 = map.find("f13");
  auto itr_len3 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());

  TEST_LIST_INT64(({0, 0, 1, 0}), itr3->second);
  TEST_LIST_INT32(({4}), itr_len3->second);

  FUNC_TEST_END();
}

//feature
void test_stat_ctr_and_stat_ctr_bucket_2() { 
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f10" : {
          "fe_type" : "stat_ctr", 
          "source": [
              ".item_feature.item_feature_se.context.feature.click",
              ".item_feature.item_feature_se.context.feature.expo"],
          "min_expo" : 100,
          "default_value" : 0
      },
      "f11" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": ["f10:0"],
          "size" : 26.2,
          "bucket_type" : 1
      },
      "f12" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": ["f10:0"],
          "size" : 6.7,
          "bucket_type" : 2
      },
      "f13" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": ["f10:0"],
          "bucket_type" : 3,
          "b" : 6,
          "a" : 1,
          "k" : 2
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f10": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f11": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f12": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f13": {
            "dtype" : "int64",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());

  StatCtrConfig* config = dynamic_cast<StatCtrConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);
  StatCtrBucketConfig* config2 = dynamic_cast<StatCtrBucketConfig*>(vec[1].get());
  TEST_ASSERT_BOOL(nullptr != config2);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_int64_list()->add_value(380);
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_int64_list()->add_value(549);
  (*(item->mutable_context()->mutable_feature()))["expo"].mutable_int64_list()->add_value(10000);
  (*(item->mutable_context()->mutable_feature()))["expo"].mutable_int64_list()->add_value(10000);
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_int64_list()->add_value(1348);
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_int64_list()->add_value(0);
  (*(item->mutable_context()->mutable_feature()))["expo"].mutable_int64_list()->add_value(10000);
  (*(item->mutable_context()->mutable_feature()))["expo"].mutable_int64_list()->add_value(0);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map0 = batch_ret.batch(0).context().feature();
  const auto& map1 = batch_ret.batch(1).context().feature();
  auto itr00 = map0.find("f10");
  auto itr10 = map1.find("f10");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr10 != map1.end());

  TEST_FEATURE_FLOAT(({0.038, 0.0549}), itr00->second);
  TEST_FEATURE_FLOAT(({0.1348, 0}), itr10->second);

  auto itr01 = map0.find("f11");
  auto itr11 = map1.find("f11");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());

  TEST_FEATURE_INT64(({0, 1}), itr01->second);
  TEST_FEATURE_INT64(({3, 0}), itr11->second);

  auto itr02 = map0.find("f12");
  auto itr12 = map1.find("f12");
  TEST_ASSERT_BOOL(itr02 != map0.end());
  TEST_ASSERT_BOOL(itr12 != map1.end());

  TEST_FEATURE_FLOAT(({1.90776, 1.91027}), itr02->second);
  TEST_FEATURE_FLOAT(({1.92203, 1.90211}), itr12->second);

  auto itr03 = map0.find("f13");
  auto itr13 = map1.find("f13");
  TEST_ASSERT_BOOL(itr03 != map0.end());
  TEST_ASSERT_BOOL(itr13 != map1.end());

  TEST_FEATURE_INT64(({0, 0}), itr03->second);
  TEST_FEATURE_INT64(({1, 0}), itr13->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f10_values");
  auto itr_indices0 = map.find("f10_indices");
  auto itr_dense_shape0 = map.find("f10_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_LIST_FLOAT(({0.038, 0.0549, 0.1348, 0}), itr_values0->second);
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), itr_indices0->second);
  TEST_LIST_INT64(({2, 2}), itr_dense_shape0->second);

  auto itr_values1 = map.find("f11_values");
  auto itr_indices1 = map.find("f11_indices");
  auto itr_dense_shape1 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_LIST_INT64(({0, 1, 3, 0}), itr_values1->second);
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), itr_indices1->second);
  TEST_LIST_INT64(({2, 2}), itr_dense_shape1->second);

  auto itr_values2 = map.find("f12_values");
  auto itr_indices2 = map.find("f12_indices");
  auto itr_dense_shape2 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_LIST_FLOAT(({1.90776, 1.91027, 1.92203, 1.90211}), itr_values2->second);
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), itr_indices2->second);
  TEST_LIST_INT64(({2, 2}), itr_dense_shape2->second);

  auto itr_values3 = map.find("f13_values");
  auto itr_indices3 = map.find("f13_indices");
  auto itr_dense_shape3 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_LIST_INT64(({0, 0, 1, 0}), itr_values3->second);
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), itr_indices3->second);
  TEST_LIST_INT64(({2, 2}), itr_dense_shape3->second);

  FUNC_TEST_END();
}

void test_stat_ctr_bucket_1() {
FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f11" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": [".item_feature.item_feature_se.context.feature.click"],
          "size" : 0.2,
          "bucket_type" : 1
      },
      "f12" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": [".item_feature.item_feature_se.context.feature.click"],
          "size" : 0,
          "bucket_type" : 2
      },
      "f13" : {
          "fe_type" : "stat_ctr_bucket", 
          "source": [".item_feature.item_feature_se.context.feature.click"],
          "bucket_type" : 3,
          "b" : 3,
          "a" : 6,
          "k" : 2
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f11": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f12": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f13": {
            "dtype" : "int64",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());

  StatCtrBucketConfig* config = dynamic_cast<StatCtrBucketConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != config);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_int64_list()->add_value(380);
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_int64_list()->add_value(549);
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_int64_list()->add_value(1348);
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_int64_list()->add_value(0);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map0 = batch_ret.batch(0).context().feature();
  const auto& map1 = batch_ret.batch(1).context().feature();

  auto itr01 = map0.find("f11");
  auto itr11 = map1.find("f11");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());
  TEST_FEATURE_INT64(({76, 109}), itr01->second);
  TEST_FEATURE_INT64(({269, 0}), itr11->second);

  auto itr02 = map0.find("f12");
  auto itr12 = map1.find("f12");
  TEST_ASSERT_BOOL(itr02 != map0.end());
  TEST_ASSERT_BOOL(itr12 != map1.end());
  TEST_FEATURE_FLOAT(({5.94017, 6.30810}), itr02->second);
  TEST_FEATURE_FLOAT(({7.20638, -1}), itr12->second);

  auto itr03 = map0.find("f13");
  auto itr13 = map1.find("f13");
  TEST_ASSERT_BOOL(itr03 != map0.end());
  TEST_ASSERT_BOOL(itr13 != map1.end());
  TEST_FEATURE_INT64(({20, 21}), itr03->second);
  TEST_FEATURE_INT64(({23, 5}), itr13->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values1 = map.find("f11_values");
  auto itr_indices1 = map.find("f11_indices");
  auto itr_dense_shape1 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_LIST_INT64(({76, 109, 269, 0}), itr_values1->second);
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), itr_indices1->second);
  TEST_LIST_INT64(({2, 2}), itr_dense_shape1->second);

  auto itr_values2 = map.find("f12_values");
  auto itr_indices2 = map.find("f12_indices");
  auto itr_dense_shape2 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_LIST_FLOAT(({5.94017, 6.30810, 7.20638, -1}), itr_values2->second);
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), itr_indices2->second);
  TEST_LIST_INT64(({2, 2}), itr_dense_shape2->second);

  auto itr_values3 = map.find("f13_values");
  auto itr_indices3 = map.find("f13_indices");
  auto itr_dense_shape3 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_LIST_INT64(({20, 21, 23, 5}), itr_values3->second);
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), itr_indices3->second);
  TEST_LIST_INT64(({2, 2}), itr_dense_shape3->second);

  FUNC_TEST_END();
}

void test_stat_ctr_bucket_2() {
FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f11" type="stat_ctr_bucket" source=".item_feature.item_feature_se.context.feature.click" bucket_type="4" a="3" b="1000" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f11" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  StatCtrBucketConfig* conf = dynamic_cast<StatCtrBucketConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_float_list()->add_value(0.8);
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_float_list()->add_value(3.4);
  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_int64_list()->add_value(-100);
  (*(item->mutable_context()->mutable_feature()))["click"].mutable_int64_list()->add_value(0);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map0 = batch_ret.batch(0).context().feature();
  const auto& map1 = batch_ret.batch(1).context().feature();

  auto itr01 = map0.find("f11");
  auto itr11 = map1.find("f11");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());
  TEST_FEATURE_FLOAT(({6.68835449, 8.13241291}), itr01->second);
  TEST_FEATURE_FLOAT(({-1.0000000, 1.09861231}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values1 = map.find("f11_values");
  auto itr_indices1 = map.find("f11_indices");
  auto itr_dense_shape1 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_LIST_FLOAT(({6.68835449, 8.13241291, -1.0000000, 1.09861231}), itr_values1->second);
  TEST_LIST_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), itr_indices1->second);
  TEST_LIST_INT64(({2, 2}), itr_dense_shape1->second);

  FUNC_TEST_END();
}

//feature 不去重
void test_seq_app2category_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "seq_app2category", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time"
          ],
          "start" : 840000,
          "dedup" : false,
          "clip_size" : 3
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f14": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f15": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqApp2CategoryConfig* conf = dynamic_cast<SeqApp2CategoryConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900804211");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900242957");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104418979");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900744462");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900785693");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)70 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)40 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_EQUAL(3, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("工具", itr00->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("工具", itr00->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("工具", itr00->second.bytes_list().value(2));

  auto itr01 = map00.find("f14");

  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_EQUAL(3, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("娱乐工具", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("生活工具", itr01->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("娱乐工具", itr01->second.bytes_list().value(2));

  auto itr02 = map00.find("f15");

  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_EQUAL(3, itr02->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("娱乐测试", itr02->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("家居控制", itr02->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("变声器", itr02->second.bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(3, tvalues0.string_val_size());
  TEST_EXPECT_EQUAL("工具", tvalues0.string_val(0));
  TEST_EXPECT_EQUAL("工具", tvalues0.string_val(1));
  TEST_EXPECT_EQUAL("工具", tvalues0.string_val(2));

  TEST_ASSERT_EQUAL(6, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices0.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape0.int64_val(1));

  auto itr_values1 = map.find("f14_values");
  auto itr_indices1 = map.find("f14_indices");
  auto itr_dense_shape1 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  auto& tvalues1 = itr_values1->second;
  auto& tindices1 = itr_indices1->second;
  auto& tdense_shape1 = itr_dense_shape1->second;

  TEST_ASSERT_EQUAL(3, tvalues1.string_val_size());
  TEST_EXPECT_EQUAL("娱乐工具", tvalues1.string_val(0));
  TEST_EXPECT_EQUAL("生活工具", tvalues1.string_val(1));
  TEST_EXPECT_EQUAL("娱乐工具", tvalues1.string_val(2));

  TEST_ASSERT_EQUAL(6, tindices1.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices1.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices1.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices1.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices1.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices1.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices1.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape1.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape1.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape1.int64_val(1));

  auto itr_values2 = map.find("f15_values");
  auto itr_indices2 = map.find("f15_indices");
  auto itr_dense_shape2 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  auto& tvalues2 = itr_values2->second;
  auto& tindices2 = itr_indices2->second;
  auto& tdense_shape2 = itr_dense_shape2->second;

  TEST_ASSERT_EQUAL(3, tvalues2.string_val_size());
  TEST_EXPECT_EQUAL("娱乐测试", tvalues2.string_val(0));
  TEST_EXPECT_EQUAL("家居控制", tvalues2.string_val(1));
  TEST_EXPECT_EQUAL("变声器", tvalues2.string_val(2));

  TEST_ASSERT_EQUAL(6, tindices2.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices2.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices2.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices2.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices2.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices2.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices2.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape2.int64_val_size());
  TEST_EXPECT_EQUAL(1, tdense_shape2.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape2.int64_val(1));

  FUNC_TEST_END();
}

//feature 去重
void test_seq_app2category_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "seq_app2category", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time"
          ],
          "start" : 840000,
          "dedup" : true,
          "clip_size" : 3,
          "default_value" : "NOT_EXIST"
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f14": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f15": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqApp2CategoryConfig* conf = dynamic_cast<SeqApp2CategoryConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900804211");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900242957");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104418979");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900744462");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900785693");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)70 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)40 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900804211");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)110 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  auto itr00 = map00.find("f13");

  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_EQUAL(2, itr00->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("工具", itr00->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("办公", itr00->second.bytes_list().value(1));

  auto itr01 = map00.find("f14");

  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_EQUAL(3, itr01->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("娱乐工具", itr01->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("生活工具", itr01->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("办公软件", itr01->second.bytes_list().value(2));

  auto itr02 = map00.find("f15");

  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_EQUAL(3, itr02->second.bytes_list().value_size());
  TEST_EXPECT_EQUAL("娱乐测试", itr02->second.bytes_list().value(0));
  TEST_EXPECT_EQUAL("家居控制", itr02->second.bytes_list().value(1));
  TEST_EXPECT_EQUAL("变声器", itr02->second.bytes_list().value(2));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  auto& tvalues0 = itr_values0->second;
  auto& tindices0 = itr_indices0->second;
  auto& tdense_shape0 = itr_dense_shape0->second;

  TEST_ASSERT_EQUAL(3, tvalues0.string_val_size());
  TEST_EXPECT_EQUAL("工具", tvalues0.string_val(0));
  TEST_EXPECT_EQUAL("办公", tvalues0.string_val(1));
  TEST_EXPECT_EQUAL("NOT_EXIST", tvalues0.string_val(2));

  TEST_ASSERT_EQUAL(6, tindices0.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(3));
  TEST_EXPECT_EQUAL(1, tindices0.int64_val(4));
  TEST_EXPECT_EQUAL(0, tindices0.int64_val(5));

  TEST_ASSERT_EQUAL(2, tdense_shape0.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(0));
  TEST_EXPECT_EQUAL(2, tdense_shape0.int64_val(1));

  auto itr_values1 = map.find("f14_values");
  auto itr_indices1 = map.find("f14_indices");
  auto itr_dense_shape1 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  auto& tvalues1 = itr_values1->second;
  auto& tindices1 = itr_indices1->second;
  auto& tdense_shape1 = itr_dense_shape1->second;

  TEST_ASSERT_EQUAL(4, tvalues1.string_val_size());
  TEST_EXPECT_EQUAL("娱乐工具", tvalues1.string_val(0));
  TEST_EXPECT_EQUAL("生活工具", tvalues1.string_val(1));
  TEST_EXPECT_EQUAL("办公软件", tvalues1.string_val(2));
  TEST_EXPECT_EQUAL("NOT_EXIST", tvalues1.string_val(3));

  TEST_ASSERT_EQUAL(8, tindices1.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices1.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices1.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices1.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices1.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices1.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices1.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices1.int64_val(6));
  TEST_EXPECT_EQUAL(0, tindices1.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape1.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape1.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape1.int64_val(1));

  auto itr_values2 = map.find("f15_values");
  auto itr_indices2 = map.find("f15_indices");
  auto itr_dense_shape2 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  auto& tvalues2 = itr_values2->second;
  auto& tindices2 = itr_indices2->second;
  auto& tdense_shape2 = itr_dense_shape2->second;

  TEST_ASSERT_EQUAL(4, tvalues2.string_val_size());
  TEST_EXPECT_EQUAL("娱乐测试", tvalues2.string_val(0));
  TEST_EXPECT_EQUAL("家居控制", tvalues2.string_val(1));
  TEST_EXPECT_EQUAL("变声器", tvalues2.string_val(2));
  TEST_EXPECT_EQUAL("NOT_EXIST", tvalues2.string_val(3));

  TEST_ASSERT_EQUAL(8, tindices2.int64_val_size());
  TEST_EXPECT_EQUAL(0, tindices2.int64_val(0));
  TEST_EXPECT_EQUAL(0, tindices2.int64_val(1));
  TEST_EXPECT_EQUAL(0, tindices2.int64_val(2));
  TEST_EXPECT_EQUAL(1, tindices2.int64_val(3));
  TEST_EXPECT_EQUAL(0, tindices2.int64_val(4));
  TEST_EXPECT_EQUAL(2, tindices2.int64_val(5));
  TEST_EXPECT_EQUAL(1, tindices2.int64_val(6));
  TEST_EXPECT_EQUAL(0, tindices2.int64_val(7));

  TEST_ASSERT_EQUAL(2, tdense_shape2.int64_val_size());
  TEST_EXPECT_EQUAL(2, tdense_shape2.int64_val(0));
  TEST_EXPECT_EQUAL(3, tdense_shape2.int64_val(1));

  FUNC_TEST_END();
}

//featurelist 不去重
void test_seq_app2category_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "seq_app2category", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time"
          ],
          "start" : 840000,
          "dedup" : false,
          "clip_size" : 3
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f14": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f15": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqApp2CategoryConfig* conf = dynamic_cast<SeqApp2CategoryConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900804211");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900242957");
  pb_info->set_event_time((int64_t)70 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104418979");
  pb_info->set_event_time((int64_t)40 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900785693");
  pb_info->set_event_time((int64_t)0 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  const auto& list00 = itr00->second;

  TEST_ASSERT_EQUAL(3, list00.feature_size());
  TEST_ASSERT_EQUAL(1, list00.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL("工具", list00.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL("工具", list00.feature(1).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(2).bytes_list().value_size());
  TEST_ASSERT_EQUAL("工具", list00.feature(2).bytes_list().value(0));

  auto itr01 = map00.find("f14");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  const auto& list01 = itr01->second;

  TEST_ASSERT_EQUAL(3, list01.feature_size());
  TEST_ASSERT_EQUAL(1, list01.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL("娱乐工具", list01.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list01.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL("生活工具", list01.feature(1).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list01.feature(2).bytes_list().value_size());
  TEST_ASSERT_EQUAL("娱乐工具", list01.feature(2).bytes_list().value(0));

  auto itr02 = map00.find("f15");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  const auto& list02 = itr02->second;

  TEST_ASSERT_EQUAL(3, list02.feature_size());
  TEST_ASSERT_EQUAL(1, list02.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL("娱乐测试", list02.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list02.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL("家居控制", list02.feature(1).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list02.feature(2).bytes_list().value_size());
  TEST_ASSERT_EQUAL("变声器", list02.feature(2).bytes_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(3, tvalues0.string_val_size());
  TEST_EXPECT_EQUAL("工具", tvalues0.string_val(0));
  TEST_EXPECT_EQUAL("工具", tvalues0.string_val(1));
  TEST_EXPECT_EQUAL("工具", tvalues0.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen0.int_val(0));

  auto itr1 = map.find("f14");
  auto itr_len1 = map.find("f14_length");

  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());

  auto& tvalues1 = itr1->second;
  auto& tlen1 = itr_len1->second;

  TEST_ASSERT_EQUAL(3, tvalues1.string_val_size());
  TEST_EXPECT_EQUAL("娱乐工具", tvalues1.string_val(0));
  TEST_EXPECT_EQUAL("生活工具", tvalues1.string_val(1));
  TEST_EXPECT_EQUAL("娱乐工具", tvalues1.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen1.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen1.int_val(0));

  auto itr2 = map.find("f15");
  auto itr_len2 = map.find("f15_length");

  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());

  auto& tvalues2 = itr2->second;
  auto& tlen2 = itr_len2->second;

  TEST_ASSERT_EQUAL(3, tvalues2.string_val_size());
  TEST_EXPECT_EQUAL("娱乐测试", tvalues2.string_val(0));
  TEST_EXPECT_EQUAL("家居控制", tvalues2.string_val(1));
  TEST_EXPECT_EQUAL("变声器", tvalues2.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen2.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen2.int_val(0));

  FUNC_TEST_END();
}

//featurelist 去重
void test_seq_app2category_4() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "seq_app2category", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
              ".request_time"
          ],
          "start" : 840000,
          "dedup" : true,
          "clip_size" : 3
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f14": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f15": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqApp2CategoryConfig* conf = dynamic_cast<SeqApp2CategoryConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900804211");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900242957");
  pb_info->set_event_time((int64_t)70 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104418979");
  pb_info->set_event_time((int64_t)40 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900785693");
  pb_info->set_event_time((int64_t)0 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  const auto& list00 = itr00->second;

  TEST_ASSERT_EQUAL(2, list00.feature_size());
  TEST_ASSERT_EQUAL(1, list00.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL("工具", list00.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list00.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL("办公", list00.feature(1).bytes_list().value(0));

  auto itr01 = map00.find("f14");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  const auto& list01 = itr01->second;

  TEST_ASSERT_EQUAL(3, list01.feature_size());
  TEST_ASSERT_EQUAL(1, list01.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL("娱乐工具", list01.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list01.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL("生活工具", list01.feature(1).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list01.feature(2).bytes_list().value_size());
  TEST_ASSERT_EQUAL("办公软件", list01.feature(2).bytes_list().value(0));

  auto itr02 = map00.find("f15");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  const auto& list02 = itr02->second;

  TEST_ASSERT_EQUAL(3, list02.feature_size());
  TEST_ASSERT_EQUAL(1, list02.feature(0).bytes_list().value_size());
  TEST_ASSERT_EQUAL("娱乐测试", list02.feature(0).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list02.feature(1).bytes_list().value_size());
  TEST_ASSERT_EQUAL("家居控制", list02.feature(1).bytes_list().value(0));
  TEST_ASSERT_EQUAL(1, list02.feature(2).bytes_list().value_size());
  TEST_ASSERT_EQUAL("变声器", list02.feature(2).bytes_list().value(0));

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f13");
  auto itr_len0 = map.find("f13_length");

  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  auto& tvalues0 = itr0->second;
  auto& tlen0 = itr_len0->second;

  TEST_ASSERT_EQUAL(2, tvalues0.string_val_size());
  TEST_EXPECT_EQUAL("工具", tvalues0.string_val(0));
  TEST_EXPECT_EQUAL("办公", tvalues0.string_val(1));

  TEST_ASSERT_EQUAL(1, tlen0.int_val_size());
  TEST_EXPECT_EQUAL(2, tlen0.int_val(0));

  auto itr1 = map.find("f14");
  auto itr_len1 = map.find("f14_length");

  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());

  auto& tvalues1 = itr1->second;
  auto& tlen1 = itr_len1->second;

  TEST_ASSERT_EQUAL(3, tvalues1.string_val_size());
  TEST_EXPECT_EQUAL("娱乐工具", tvalues1.string_val(0));
  TEST_EXPECT_EQUAL("生活工具", tvalues1.string_val(1));
  TEST_EXPECT_EQUAL("办公软件", tvalues1.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen1.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen1.int_val(0));

  auto itr2 = map.find("f15");
  auto itr_len2 = map.find("f15_length");

  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());

  auto& tvalues2 = itr2->second;
  auto& tlen2 = itr_len2->second;

  TEST_ASSERT_EQUAL(3, tvalues2.string_val_size());
  TEST_EXPECT_EQUAL("娱乐测试", tvalues2.string_val(0));
  TEST_EXPECT_EQUAL("家居控制", tvalues2.string_val(1));
  TEST_EXPECT_EQUAL("变声器", tvalues2.string_val(2));

  TEST_ASSERT_EQUAL(1, tlen2.int_val_size());
  TEST_EXPECT_EQUAL(3, tlen2.int_val(0));

  FUNC_TEST_END();
}

//默认参数
void test_seq_app2category_5() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f12" : {
          "fe_type" : "seq_app2category", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid",
              ".item_feature.item_feature_se.context.feature.time",
              ".request_time"
          ]
      },
      "f13" : {
          "fe_type" : "direct", 
          "source": ["f12:0"]
      },
      "f14" : {
          "fe_type" : "direct", 
          "source": ["f12:1"]
      },
      "f15" : {
          "fe_type" : "direct", 
          "source": ["f12:2"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f13": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f14": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f15": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqApp2CategoryConfig* conf = dynamic_cast<SeqApp2CategoryConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900804211");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900242957");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104418979");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900744462");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900785693");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)70 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)40 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)0 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  
  auto itr00 = map00.find("f13");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"经营养成", "工具", "工具", "工具", "办公"}), itr00->second);

  auto itr01 = map00.find("f14");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_STR(({"经营模拟", "娱乐工具", "生活工具", "娱乐工具", "办公软件"}), itr01->second);

  auto itr02 = map00.find("f15");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_STR(({"经营模拟", "娱乐测试", "家居控制", "变声器", "日程管理"}), itr02->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f13_values");
  auto itr_indices0 = map.find("f13_indices");
  auto itr_dense_shape0 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 0, 3, 0, 4}), ({1, 5}), ({"经营养成", "工具", "工具", "工具", "办公"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f14_values");
  auto itr_indices1 = map.find("f14_indices");
  auto itr_dense_shape1 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 0, 3, 0, 4}), ({1, 5}), ({"经营模拟", "娱乐工具", "生活工具", "娱乐工具", "办公软件"}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f15_values");
  auto itr_indices2 = map.find("f15_indices");
  auto itr_dense_shape2 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 0, 3, 0, 4}), ({1, 5}), ({"经营模拟", "娱乐测试", "家居控制", "变声器", "日程管理"}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  FUNC_TEST_END();
}

void test_seq_filter_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_filter", 
          "source": [
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration",
            ".request_time",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.first_intent_type",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.second_intent_type",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.third_intent_type",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_type",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_source"
          ],
          "start" : 864000,
          "day_n" : 30,
          "clip_size" : 2,
          "default_value" : "test_no_data",
          "filter" : [["100"], ["18", "101"], ["20", "102"], ["103", "3"], ["104", "222"]]
      },
      "f7" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      },
      "f9" : {
          "fe_type" : "direct", 
          "source": ["f6:2"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f9": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterConfig* conf = dynamic_cast<SeqFilterConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("1");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info->set_use_duration(10);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("102");
  pb_info->set_event_type("103");
  pb_info->set_event_source("104");

  //filter过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("2");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info->set_use_duration(20);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("100");
  pb_info->set_third_intent_type("100");
  pb_info->set_event_type("100");
  pb_info->set_event_source("100");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("3");
  pb_info->set_event_time((int64_t)85 * 86400 * 1000);
  pb_info->set_use_duration(30);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("20");
  pb_info->set_event_type("3");
  pb_info->set_event_source("222");

  //时间范围过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("4");
  pb_info->set_event_time((int64_t)75 * 86400 * 1000);
  pb_info->set_use_duration(40);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("20");
  pb_info->set_event_type("3");
  pb_info->set_event_source("222");

  //防穿越过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("5");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info->set_use_duration(50);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("20");
  pb_info->set_event_type("3");
  pb_info->set_event_source("222");

  //clip截断
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("6");
  pb_info->set_event_time((int64_t)82 * 86400 * 1000);
  pb_info->set_use_duration(60);
  pb_info->set_first_intent_type("100");
  pb_info->set_second_intent_type("101");
  pb_info->set_third_intent_type("20");
  pb_info->set_event_type("3");
  pb_info->set_event_source("222");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"1"}, {"3"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)95 * 86400 * 1000}, {(int64_t)85 * 86400 * 1000}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{10}, {30}}), itr02->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  TEST_LIST_STRING(({"1", "", "3", ""}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());

  TEST_LIST_INT64(({(int64_t)95 * 86400 * 1000, 0, (int64_t)85 * 86400 * 1000, 0}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());

  TEST_LIST_INT64(({10, 0, 30, 0}), itr2->second);
  TEST_LIST_INT32(({2}), itr_len2->second);

  FUNC_TEST_END();
}

void test_seq_filter_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_filter", 
          "source": [
            ".item_feature.item_feature_se.context.feature.appid",
            ".item_feature.item_feature_se.context.feature.time",
            ".item_feature.item_feature_se.context.feature.use_duration",
            ".request_time",
            ".item_feature.item_feature_se.context.feature.first_intent_type",
            ".item_feature.item_feature_se.context.feature.second_intent_type",
            ".item_feature.item_feature_se.context.feature.third_intent_type",
            ".item_feature.item_feature_se.context.feature.event_type"
          ],
          "start" : 864000,
          "day_n" : 30,
          "clip_size" : 2,
          "default_value" : "test_no_data",
          "filter" : [["100"], ["18", "101"], ["20", "102"], ["103", "3"]]
      },
      "f7" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      },
      "f9" : {
          "fe_type" : "direct", 
          "source": ["f6:2"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f9": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterConfig* conf = dynamic_cast<SeqFilterConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(100);
  (*(item->mutable_context()->mutable_feature()))["first_intent_type"].mutable_bytes_list()->add_value("100");
  (*(item->mutable_context()->mutable_feature()))["second_intent_type"].mutable_bytes_list()->add_value("200");
  (*(item->mutable_context()->mutable_feature()))["third_intent_type"].mutable_bytes_list()->add_value("300");
  (*(item->mutable_context()->mutable_feature()))["event_type"].mutable_bytes_list()->add_value("400");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(200);
  (*(item->mutable_context()->mutable_feature()))["first_intent_type"].mutable_bytes_list()->add_value("100");
  (*(item->mutable_context()->mutable_feature()))["second_intent_type"].mutable_bytes_list()->add_value("101");
  (*(item->mutable_context()->mutable_feature()))["third_intent_type"].mutable_bytes_list()->add_value("102");
  (*(item->mutable_context()->mutable_feature()))["event_type"].mutable_bytes_list()->add_value("103");

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(300);
  (*(item->mutable_context()->mutable_feature()))["first_intent_type"].mutable_bytes_list()->add_value("100");
  (*(item->mutable_context()->mutable_feature()))["second_intent_type"].mutable_bytes_list()->add_value("101");
  (*(item->mutable_context()->mutable_feature()))["third_intent_type"].mutable_bytes_list()->add_value("102");
  (*(item->mutable_context()->mutable_feature()))["event_type"].mutable_bytes_list()->add_value("103");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"test_no_data"}), itr00->second);
  TEST_FEATURE_STR(({"appid1", "appid1"}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({-1}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)95 * 86400 * 1000, (int64_t)85 * 86400 * 1000}), itr11->second);

  auto itr02 = map00.find("f9");
  auto itr12 = map01.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_INT64(({-1}), itr02->second);
  TEST_FEATURE_INT64(({300, 200}), itr12->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0, 1, 1}), ({2, 2}), ({"test_no_data", "appid1", "appid1"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f8_values");
  auto itr_indices1 = map.find("f8_indices");
  auto itr_dense_shape1 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0, 1, 1}), ({2, 2}), ({-1, (int64_t)95 * 86400 * 1000, (int64_t)85 * 86400 * 1000}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f9_values");
  auto itr_indices2 = map.find("f9_indices");
  auto itr_dense_shape2 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0, 1, 1}), ({2, 2}), ({-1, 300, 200}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  FUNC_TEST_END();
}

//默认参数
void test_seq_filter_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_filter", 
          "source": [
            ".item_feature.item_feature_se.context.feature.appid",
            ".item_feature.item_feature_se.context.feature.time",
            ".item_feature.item_feature_se.context.feature.use_duration",
            ".request_time",
            ".item_feature.item_feature_se.context.feature.first_intent_type",
            ".item_feature.item_feature_se.context.feature.second_intent_type",
            ".item_feature.item_feature_se.context.feature.third_intent_type",
            ".item_feature.item_feature_se.context.feature.event_type"
          ],
          "filter" : [["100"], ["18", "101"], ["20", "102"], ["103", "3"]]
      },
      "f7" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      },
      "f9" : {
          "fe_type" : "direct", 
          "source": ["f6:2"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f9": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterConfig* conf = dynamic_cast<SeqFilterConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(100);
  (*(item->mutable_context()->mutable_feature()))["first_intent_type"].mutable_bytes_list()->add_value("100");
  (*(item->mutable_context()->mutable_feature()))["second_intent_type"].mutable_bytes_list()->add_value("101");
  (*(item->mutable_context()->mutable_feature()))["third_intent_type"].mutable_bytes_list()->add_value("300");
  (*(item->mutable_context()->mutable_feature()))["event_type"].mutable_bytes_list()->add_value("400");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(200);
  (*(item->mutable_context()->mutable_feature()))["first_intent_type"].mutable_bytes_list()->add_value("100");
  (*(item->mutable_context()->mutable_feature()))["second_intent_type"].mutable_bytes_list()->add_value("101");
  (*(item->mutable_context()->mutable_feature()))["third_intent_type"].mutable_bytes_list()->add_value("102");
  (*(item->mutable_context()->mutable_feature()))["event_type"].mutable_bytes_list()->add_value("103");

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(300);
  (*(item->mutable_context()->mutable_feature()))["first_intent_type"].mutable_bytes_list()->add_value("100");
  (*(item->mutable_context()->mutable_feature()))["second_intent_type"].mutable_bytes_list()->add_value("101");
  (*(item->mutable_context()->mutable_feature()))["third_intent_type"].mutable_bytes_list()->add_value("102");
  (*(item->mutable_context()->mutable_feature()))["event_type"].mutable_bytes_list()->add_value("103");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"NOT_EXIST"}), itr00->second);
  TEST_FEATURE_STR(({"appid0", "appid1"}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({-1}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)105 * 86400 * 1000, (int64_t)95 * 86400 * 1000}), itr11->second);

  auto itr02 = map00.find("f9");
  auto itr12 = map01.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_INT64(({-1}), itr02->second);
  TEST_FEATURE_INT64(({200, 300}), itr12->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0, 1, 1}), ({2, 2}), ({"NOT_EXIST", "appid0", "appid1"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f8_values");
  auto itr_indices1 = map.find("f8_indices");
  auto itr_dense_shape1 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0, 1, 1}), ({2, 2}), ({-1, (int64_t)105 * 86400 * 1000, (int64_t)95 * 86400 * 1000}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f9_values");
  auto itr_indices2 = map.find("f9_indices");
  auto itr_dense_shape2 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0, 1, 1}), ({2, 2}), ({-1, 200, 300}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  FUNC_TEST_END();
}

// xml格式空过滤条件
void test_seq_filter_4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time" start="864000" day_n="30"  default_value="test_no_data" filter="" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
            <feature name="f9" type="direct" source="f6:2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,5" type="sequence" />
        <input name="f8" shape="1,1,5" type="sequence" />
        <input name="f9" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterConfig* conf = dynamic_cast<SeqFilterConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("1");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("2");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("3");
  pb_info->set_event_time((int64_t)85 * 86400 * 1000);

  //时间范围过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("4");
  pb_info->set_event_time((int64_t)75 * 86400 * 1000);

  //防穿越过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("5");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("6");
  pb_info->set_event_time((int64_t)82 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"1"}, {"2"}, {"3"}, {"6"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)95 * 86400 * 1000}, {(int64_t)90 * 86400 * 1000}, {(int64_t)85 * 86400 * 1000}, {(int64_t)82 * 86400 * 1000}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)95 * 86400 * 1000}, {(int64_t)90 * 86400 * 1000}, {(int64_t)85 * 86400 * 1000}, {(int64_t)82 * 86400 * 1000}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  TEST_LIST_STRING(({"1", "2", "3", "6"}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());

  TEST_LIST_INT64(({(int64_t)95 * 86400 * 1000, (int64_t)90 * 86400 * 1000, (int64_t)85 * 86400 * 1000, (int64_t)82 * 86400 * 1000}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());

  TEST_LIST_INT64(({(int64_t)95 * 86400 * 1000, (int64_t)90 * 86400 * 1000, (int64_t)85 * 86400 * 1000, (int64_t)82 * 86400 * 1000}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len2->second);

  FUNC_TEST_END();
}

void test_seq_filter_v2_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v2" source=".user_feature.am_gm_ins_off.am_ins_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"/>
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV2Config* conf = dynamic_cast<SeqFilterV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user_ins
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_ins_off()->mutable_am_ins_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid3");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid5");

  // user_clk
  pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid5");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid5");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid6");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}, {"appid3"}, {"appid4"}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f6");
  auto itr_len0 = map.find("f6_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  TEST_LIST_STRING(({"appid2", "appid3", "appid4"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  FUNC_TEST_END();
}

void test_seq_filter_v2_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v2" source=".user_feature.am_gm_ins_off.am_ins_off.user_sequence.app_id,.item_feature.item_feature_se.context.feature.appid" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV2Config* conf = dynamic_cast<SeqFilterV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user_ins
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_ins_off()->mutable_am_ins_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid3");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid5");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid4");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}, {"appid3"}, {"appid5"}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f6");
  auto itr_len0 = map.find("f6_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  TEST_LIST_STRING(({"appid2", "appid3", "appid5"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  FUNC_TEST_END();
}

void test_seq_filter_v2_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v2" source=".item_feature.item_feature_se.context.feature.appid,.item_feature.item_feature_se.feature_lists.feature_list.appid" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV2Config* conf = dynamic_cast<SeqFilterV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");

  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid4");
  fate->mutable_bytes_list()->add_value("appid2");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid3");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid3");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid4");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid4");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("appid1");
  fate->mutable_bytes_list()->add_value("appid2");
  fate = feat_list2.add_feature();
  fate->mutable_bytes_list()->add_value("appid3");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"appid0", "appid1"}), itr00->second);

  auto itr10 = map01.find("f6");
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"appid4", "appid4"}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({"appid0", "appid1", "appid4", "appid4"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_seq_filter_v2_4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v2" source=".item_feature.item_feature_se.feature_lists.feature_list.int,.item_feature.item_feature_se.feature_lists.feature_list.num" default_value="-1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1,2,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV2Config* conf = dynamic_cast<SeqFilterV2Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["int"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value(10);
  fate->mutable_int64_list()->add_value(20);
  fate = feat_list.add_feature();
  fate->mutable_int64_list()->add_value(30);

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["num"];
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value(30);
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value(5);

  item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list3 = (*(item->mutable_feature_lists()->mutable_feature_list()))["int"];
  fate = feat_list3.add_feature();
  fate->mutable_int64_list()->add_value(20);
  fate->mutable_int64_list()->add_value(30);
  fate = feat_list3.add_feature();

  auto& feat_list4 = (*(item->mutable_feature_lists()->mutable_feature_list()))["num"];
  fate = feat_list4.add_feature();
  fate->mutable_int64_list()->add_value(20);
  fate = feat_list4.add_feature();
  fate->mutable_int64_list()->add_value(30);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map01 = batch_ret.batch(1).feature_lists().feature_list();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{10, 20}}), itr00->second);

  auto itr10 = map01.find("f6");
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_LIST_INT64(({{-1}}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f6");
  auto itr_len0 = map.find("f6_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  TEST_LIST_INT64(({10, 20, -1, 0}), itr0->second);
  TEST_LIST_INT32(({1, 1}), itr_len0->second);

  FUNC_TEST_END();
}

void test_seq_filter_v3_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v3" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration" start="864000" day_n ="30" clip_size="2" reverse="1" filter="1,3,4,6,5" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
            <feature name="f9" type="direct" source="f6:2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,2,5" type="sequence" />
        <input name="f8" shape="1,2,5" type="sequence" />
        <input name="f9" shape="1,2,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV3Config* conf = dynamic_cast<SeqFilterV3Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("1");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info->set_use_duration(10);

  //filter过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("2");
  pb_info->set_event_time((int64_t)90 * 86400 * 1000);
  pb_info->set_use_duration(20);

  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("3");
  pb_info->set_event_time((int64_t)85 * 86400 * 1000);
  pb_info->set_use_duration(30);

  //时间范围过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("4");
  pb_info->set_event_time((int64_t)75 * 86400 * 1000);
  pb_info->set_use_duration(40);

  //防穿越过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("5");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info->set_use_duration(50);

  //clip截断
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("6");
  pb_info->set_event_time((int64_t)82 * 86400 * 1000);
  pb_info->set_use_duration(60);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"1"}, {"3"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)95 * 86400 * 1000}, {(int64_t)85 * 86400 * 1000}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{10}, {30}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());

  TEST_LIST_STRING(({"1", "", "3", ""}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());

  TEST_LIST_INT64(({(int64_t)95 * 86400 * 1000, 0, (int64_t)85 * 86400 * 1000, 0}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());

  TEST_LIST_INT64(({10, 0, 30, 0}), itr2->second);
  TEST_LIST_INT32(({2}), itr_len2->second);

  FUNC_TEST_END();
}

//默认参数
void test_seq_filter_v3_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v3" source=".item_feature.item_feature_se.context.feature.appid,.item_feature.item_feature_se.context.feature.time,.request_time,.item_feature.item_feature_se.context.feature.use_duration,.item_feature.item_feature_se.context.feature.float,.item_feature.item_feature_se.context.feature.type" filter="1,3,4,6,5" />
            <feature name="f7" type="direct" source="f6:0" strategy="empty" />
            <feature name="f8" type="direct" source="f6:1" strategy="empty" />
            <feature name="f9" type="direct" source="f6:2" strategy="empty" />
            <feature name="f10" type="direct" source="f6:3" strategy="empty" />
            <feature name="f11" type="direct" source="f6:4" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
        <input name="f10" shape="1" type="sparse" />
        <input name="f11" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(6, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV3Config* conf = dynamic_cast<SeqFilterV3Config*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(5, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("1");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(100);
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(0.64);
  (*(item->mutable_context()->mutable_feature()))["type"].mutable_bytes_list()->add_value("400");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("2");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(200);
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(0.48);
  (*(item->mutable_context()->mutable_feature()))["type"].mutable_bytes_list()->add_value("103");

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("3");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["use_duration"].mutable_int64_list()->add_value(300);
  (*(item->mutable_context()->mutable_feature()))["float"].mutable_float_list()->add_value(0.25);
  (*(item->mutable_context()->mutable_feature()))["type"].mutable_bytes_list()->add_value("103");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({}), itr00->second);
  TEST_FEATURE_STR(({"2"}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)105 * 86400 * 1000}), itr11->second);

  auto itr02 = map00.find("f9");
  auto itr12 = map01.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_INT64(({}), itr02->second);
  TEST_FEATURE_INT64(({200}), itr12->second);

  auto itr03 = map00.find("f10");
  auto itr13 = map01.find("f10");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());

  TEST_FEATURE_FLOAT(({}), itr03->second);
  TEST_FEATURE_FLOAT(({0.48}), itr13->second);

  auto itr04 = map00.find("f11");
  auto itr14 = map01.find("f11");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_ASSERT_BOOL(itr14 != map01.end());

  TEST_FEATURE_STR(({}), itr04->second);
  TEST_FEATURE_STR(({"103"}), itr14->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({1, 0}), ({2, 1}), ({"2"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f8_values");
  auto itr_indices1 = map.find("f8_indices");
  auto itr_dense_shape1 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({1, 0}), ({2, 1}), ({(int64_t)105 * 86400 * 1000}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f9_values");
  auto itr_indices2 = map.find("f9_indices");
  auto itr_dense_shape2 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_INT64(({1, 0}), ({2, 1}), ({200}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f10_values");
  auto itr_indices3 = map.find("f10_indices");
  auto itr_dense_shape3 = map.find("f10_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({1, 0}), ({2, 1}), ({0.48}),
                        itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  auto itr_values4 = map.find("f11_values");
  auto itr_indices4 = map.find("f11_indices");
  auto itr_dense_shape4 = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values4 != map.end());
  TEST_ASSERT_BOOL(itr_indices4 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape4 != map.end());

  TEST_SPARSE_TENSOR_STR(({1, 0}), ({2, 1}), ({"103"}),
                        itr_indices4->second, itr_dense_shape4->second, itr_values4->second);

  FUNC_TEST_END();
}

void test_seq_diff_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_diff", 
          "source": [
            ".user_feature.am_gm_ins_off.am_ins_off.user_sequence.app_id",
            ".user_feature.am_gm_ins_off.am_ins_off.user_sequence.event_time",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
            ".request_time"
          ],
          "start" : 864000,
          "day_n" : 30,
          "delta_day" : 10,
          "clip_size" : 2,
          "default_value" : "test_no_data"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDiffConfig* conf = dynamic_cast<SeqDiffConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_ins_off()->mutable_am_ins_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  //防穿越
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)102 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)86 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  //活跃
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)84 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  //长度截断
  pb_info->set_app_id("appid3");
  pb_info->set_event_time((int64_t)81 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time((int64_t)83 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  //时间范围过滤
  pb_info->set_app_id("appid5");
  pb_info->set_event_time((int64_t)78 * 86400 * 1000);

  pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)98 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)92 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time((int64_t)99 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid5");
  pb_info->set_event_time((int64_t)82 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  auto itr00 = map00.find("f6");

  TEST_ASSERT_BOOL(itr00 != map00.end());

  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid4"}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr = map.find("f6");
  auto itr_len = map.find("f6_length");

  TEST_ASSERT_BOOL(itr != map.end());
  TEST_ASSERT_BOOL(itr_len != map.end());

  TEST_LIST_STRING(({"appid1", "", "appid4", ""}), itr->second);
  TEST_LIST_INT32(({2}), itr_len->second);

  FUNC_TEST_END();
}

void test_seq_diff_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_diff", 
          "source": [
            ".item_feature.item_feature_se.context.feature.ins_appid",
            ".item_feature.item_feature_se.context.feature.ins_time",
            ".item_feature.item_feature_se.context.feature.clk_appid",
            ".item_feature.item_feature_se.context.feature.clk_time",
            ".request_time"
          ],
          "start" : 864000,
          "day_n" : 30,
          "delta_day" : 10,
          "clip_size" : 2,
          "default_value" : "test_no_data"
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDiffConfig* conf = dynamic_cast<SeqDiffConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000); 

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["ins_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["clk_appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["clk_time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["ins_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["clk_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["clk_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f6");
  auto itr10 = map01.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"appid1"}), itr00->second);
  TEST_FEATURE_STR(({"test_no_data"}), itr10->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f6_values");
  auto itr_indices = map.find("f6_indices");
  auto itr_dense_shape = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), ({"appid1", "test_no_data"}),
                        itr_indices->second, itr_dense_shape->second, itr_values->second);

  FUNC_TEST_END();
}
void test_seq_diff_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_diff", 
          "source": [
            ".item_feature.item_feature_se.context.feature.ins_appid",
            ".item_feature.item_feature_se.context.feature.ins_time",
            ".item_feature.item_feature_se.context.feature.clk_appid",
            ".item_feature.item_feature_se.context.feature.clk_time",
            ".request_time"
          ],
          "delta_day" : 3
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDiffConfig* conf = dynamic_cast<SeqDiffConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000); 

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["ins_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["clk_appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["clk_time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["ins_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["clk_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["clk_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f6");
  auto itr10 = map01.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"appid1"}), itr00->second);
  TEST_FEATURE_STR(({"appid2"}), itr10->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f6_values");
  auto itr_indices = map.find("f6_indices");
  auto itr_dense_shape = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), ({"appid1", "appid2"}),
                        itr_indices->second, itr_dense_shape->second, itr_values->second);

  FUNC_TEST_END();
}

void test_seq_diff_v2_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_diff_v2" source=".user_feature.am_gm_ins_off.am_ins_off.user_sequence.app_id,.user_feature.am_gm_ins_off.am_ins_off.user_sequence.event_time,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time" start="864000" day_n="30" delta_day="10" status="0" clip_size="2" />
            <feature name="f5" type="direct" source="f4:0" />
            <feature name="f6" type="direct" source="f4:1" />
            <feature name="f7" type="seq_diff_v2" source=".user_feature.am_gm_ins_off.am_ins_off.user_sequence.app_id,.user_feature.am_gm_ins_off.am_ins_off.user_sequence.event_time,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time" start="864000" day_n="30" delta_day="10" status="1" clip_size="2" />
            <feature name="f8" type="direct" source="f7:0" />
            <feature name="f9" type="direct" source="f7:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1,1,5" type="sequence" />
        <input name="f6" shape="1,1,5" type="sequence" />
        <input name="f8" shape="1,1,5" type="sequence" />
        <input name="f9" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(6, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDiffV2Config* conf = dynamic_cast<SeqDiffV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_ins_off()->mutable_am_ins_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  //防穿越
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)102 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)86 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  //活跃
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)84 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  //长度截断
  pb_info->set_app_id("appid3");
  pb_info->set_event_time((int64_t)81 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time((int64_t)83 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  //时间范围过滤
  pb_info->set_app_id("appid5");
  pb_info->set_event_time((int64_t)78 * 86400 * 1000);

  pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)98 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)92 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time((int64_t)99 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid5");
  pb_info->set_event_time((int64_t)82 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid4"}}), itr00->second);

  auto itr01 = map00.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)86 * 86400 * 1000}, {(int64_t)83 * 86400 * 1000}}), itr01->second);

  auto itr02 = map00.find("f8");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}}), itr02->second);

  auto itr03 = map00.find("f9");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)84 * 86400 * 1000}}), itr03->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f5");
  auto itr_len0 = map.find("f5_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid1", "appid4"}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f6");
  auto itr_len1 = map.find("f6_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({(int64_t)86 * 86400 * 1000, (int64_t)83 * 86400 * 1000}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  auto itr2 = map.find("f8");
  auto itr_len2 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"appid2"}), itr2->second);
  TEST_LIST_INT32(({1}), itr_len2->second);

  auto itr3 = map.find("f9");
  auto itr_len3 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_INT64(({(int64_t)84 * 86400 * 1000}), itr3->second);
  TEST_LIST_INT32(({1}), itr_len3->second);

  FUNC_TEST_END();
}

void test_seq_diff_v2_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_diff_v2" source=".item_feature.item_feature_se.context.feature.ins_appid,.item_feature.item_feature_se.context.feature.ins_time,.item_feature.item_feature_se.context.feature.clk_appid,.item_feature.item_feature_se.context.feature.clk_time,.request_time" day_n="30" delta_day="-10" status="0" clip_size="3" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
            <feature name="f6" type="direct" source="f4:1" strategy="empty" />
            <feature name="f7" type="seq_diff_v2" source=".item_feature.item_feature_se.context.feature.ins_appid,.item_feature.item_feature_se.context.feature.ins_time,.item_feature.item_feature_se.context.feature.clk_appid,.item_feature.item_feature_se.context.feature.clk_time,.request_time" day_n="30" delta_day="-10" status="1" clip_size="3" />
            <feature name="f8" type="direct" source="f7:0" strategy="empty" />
            <feature name="f9" type="direct" source="f7:1" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(6, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDiffV2Config* conf = dynamic_cast<SeqDiffV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000); 

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["ins_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["clk_appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["clk_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["ins_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["ins_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["clk_appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["clk_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f5");
  auto itr10 = map01.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({}), itr00->second);
  TEST_FEATURE_STR(({"appid2"}), itr10->second);

  auto itr01 = map00.find("f6");
  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)85 * 86400 * 1000}), itr11->second);

  auto itr02 = map00.find("f8");
  auto itr12 = map01.find("f8");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());
  TEST_FEATURE_STR(({"appid1"}), itr02->second);
  TEST_FEATURE_STR(({}), itr12->second);

  auto itr03 = map00.find("f9");
  auto itr13 = map01.find("f9");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());
  TEST_FEATURE_INT64(({(int64_t)90 * 86400 * 1000}), itr03->second);
  TEST_FEATURE_INT64(({}), itr13->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({1, 0}), ({2, 1}), ({"appid2"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({1, 0}), ({2, 1}), ({(int64_t)85 * 86400 * 1000}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f8_values");
  auto itr_indices2 = map.find("f8_indices");
  auto itr_dense_shape2 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0}), ({2, 1}), ({"appid1"}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f9_values");
  auto itr_indices3 = map.find("f9_indices");
  auto itr_dense_shape3 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0}), ({2, 1}), ({(int64_t)90 * 86400 * 1000}),
                            itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  FUNC_TEST_END();
}

void test_seq_max_value_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_max_value" source=".item_feature.item_feature_se.context.feature.ins_time,.request_time" day_n="10" default_value="100" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
        </features>
    </config>
  )";

  std::string config_str_not_hit = R"(
    <config>
        <features>
            <feature name="f4" type="seq_max_value" source=".item_feature.item_feature_se.context.feature.ins_time,.request_time" day_n="1" default_value="101" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="dense" />
    </model_input_config>
  )";
  {
     std::vector<std::shared_ptr<Config>> vec;
     XmlConfigMgr::parse_from_string(config_str, "", "", vec);
     TEST_ASSERT_EQUAL(2, vec.size());
     TEST_ASSERT_BOOL(nullptr != vec[0]);
  
     auto config = std::dynamic_pointer_cast<SeqMaxValueConfig>(vec[0]);
     TEST_ASSERT_BOOL(nullptr != config);
  
     std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
     ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
  
     TEST_ASSERT_EQUAL(1, in_vec.size());
     TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
  
     google::protobuf::Arena arena;
     qinglong::FeRequest request;
     qinglong::BatchSequenceExample batch_ret;
     qinglong::PredictRequest ret;
  
     // 请求时间
     request.set_request_time((int64_t)100 * 86400 * 1000);
     tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
     auto& event_times = (*(item->mutable_context()->mutable_feature()))["ins_time"];
     event_times.mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
     event_times.mutable_int64_list()->add_value((int64_t)91 * 86400 * 1000);
     event_times.mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000);
     event_times.mutable_int64_list()->add_value((int64_t)93 * 86400 * 1000);
     event_times.mutable_int64_list()->add_value((int64_t)94 * 86400 * 1000);
     event_times.mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  
     toSequenceExample(&arena, request, vec, batch_ret);
  
     TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
     TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  
     const auto& map1 = batch_ret.batch(0).context().feature();
     auto itr1 = map1.find("f5");
     TEST_ASSERT_BOOL(itr1 != map1.end());
     TEST_FEATURE_INT64(({(int64_t)95 * 86400 * 1000}), itr1->second);
  
     std::vector<std::shared_ptr<Config>> need_vec;
     selectConfigUsingModelInput(vec, in_vec, need_vec);
     toPredictRequest(&arena, request, need_vec, in_vec, ret);
     
     auto& map = ret.inputs();
     auto itr0 = map.find("f5");
     TEST_ASSERT_BOOL(itr0 != map.end());
     TEST_ASSERT_BOOL(itr0->second.int64_val().at(0) ==  (int64_t)95 * 86400 * 1000);
  }
  // 测试不命中
  {
    std::vector<std::shared_ptr<Config>> vec;
    XmlConfigMgr::parse_from_string(config_str_not_hit, "", "", vec);
    TEST_ASSERT_EQUAL(2, vec.size());
    TEST_ASSERT_BOOL(nullptr != vec[0]);
 
    auto config = std::dynamic_pointer_cast<SeqMaxValueConfig>(vec[0]);
    TEST_ASSERT_BOOL(nullptr != config);
 
    std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
    ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
 
    TEST_ASSERT_EQUAL(1, in_vec.size());
    TEST_EXPECT_EQUAL(INPUT_DENSE, in_vec[0]->input_type);
 
    google::protobuf::Arena arena;
    qinglong::FeRequest request;
    qinglong::BatchSequenceExample batch_ret;
    qinglong::PredictRequest ret;
 
    // 请求时间
    request.set_request_time((int64_t)100 * 86400 * 1000);
    tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
    auto& event_times = (*(item->mutable_context()->mutable_feature()))["ins_time"];
    event_times.mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
    event_times.mutable_int64_list()->add_value((int64_t)91 * 86400 * 1000);
    event_times.mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000);
    event_times.mutable_int64_list()->add_value((int64_t)93 * 86400 * 1000);
    event_times.mutable_int64_list()->add_value((int64_t)94 * 86400 * 1000);
    event_times.mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
 
    toSequenceExample(&arena, request, vec, batch_ret);
 
    TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
    TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
 
    const auto& map1 = batch_ret.batch(0).context().feature();
    auto itr1 = map1.find("f5");
    TEST_ASSERT_BOOL(itr1 != map1.end());
    TEST_FEATURE_INT64(({101}), itr1->second);
 
    std::vector<std::shared_ptr<Config>> need_vec;
    selectConfigUsingModelInput(vec, in_vec, need_vec);
    toPredictRequest(&arena, request, need_vec, in_vec, ret);
    
    auto& map = ret.inputs();
    auto itr0 = map.find("f5");
    TEST_ASSERT_BOOL(itr0 != map.end());
    TEST_ASSERT_BOOL(itr0->second.int64_val().at(0) ==  (int64_t)101);
  }

  FUNC_TEST_END();
}

void test_seq_max_value_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_max_value" source=".item_feature.item_feature_se.feature_lists.feature_list.ins_time,.request_time" day_n="10" default_value="100" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
        </features>
    </config>
  )";

  std::string config_str_not_hit = R"(
    <config>
        <features>
            <feature name="f4" type="seq_max_value" source=".item_feature.item_feature_se.feature_lists.feature_list.ins_time,.request_time" day_n="1" default_value="101" />
            <feature name="f5" type="direct" source="f4:0" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1,1" type="sequence" />
    </model_input_config>
  )";
  {
     std::vector<std::shared_ptr<Config>> vec;
     XmlConfigMgr::parse_from_string(config_str, "", "", vec);
     TEST_ASSERT_EQUAL(2, vec.size());
     TEST_ASSERT_BOOL(nullptr != vec[0]);
  
     auto config = std::dynamic_pointer_cast<SeqMaxValueConfig>(vec[0]);
     TEST_ASSERT_BOOL(nullptr != config);
  
     std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
     ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
  
     TEST_ASSERT_EQUAL(1, in_vec.size());
     TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
  
     google::protobuf::Arena arena;
     qinglong::FeRequest request;
     qinglong::BatchSequenceExample batch_ret;
     qinglong::PredictRequest ret;
  
     // 请求时间
     request.set_request_time((int64_t)100 * 86400 * 1000);
     tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
     auto& event_times = (*(item->mutable_feature_lists()->mutable_feature_list()))["ins_time"];
     auto* list1 = event_times.add_feature();
     list1->mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
     list1->mutable_int64_list()->add_value((int64_t)91 * 86400 * 1000);
     list1->mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000);

     auto* list2 = event_times.add_feature();
     list2->mutable_int64_list()->add_value((int64_t)93 * 86400 * 1000);
     list2->mutable_int64_list()->add_value((int64_t)94 * 86400 * 1000);
     list2->mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  
     toSequenceExample(&arena, request, vec, batch_ret);
  
     TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
     TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  
     const auto& map1 = batch_ret.batch(0).feature_lists().feature_list();
     auto itr1 = map1.find("f5");
     TEST_ASSERT_BOOL(itr1 != map1.end());
     TEST_FEATURE_LIST_INT64(({{(int64_t)95 * 86400 * 1000}}), itr1->second);
  
     std::vector<std::shared_ptr<Config>> need_vec;
     selectConfigUsingModelInput(vec, in_vec, need_vec);
     toPredictRequest(&arena, request, need_vec, in_vec, ret);
     
     auto& map = ret.inputs();
     auto itr0 = map.find("f5");
     TEST_ASSERT_BOOL(itr0 != map.end());
     TEST_ASSERT_BOOL(itr0->second.int64_val().at(0) ==  (int64_t)95 * 86400 * 1000);
  }
  // 测试不命中
  {
    std::vector<std::shared_ptr<Config>> vec;
    XmlConfigMgr::parse_from_string(config_str_not_hit, "", "", vec);
    TEST_ASSERT_EQUAL(2, vec.size());
    TEST_ASSERT_BOOL(nullptr != vec[0]);
 
    auto config = std::dynamic_pointer_cast<SeqMaxValueConfig>(vec[0]);
    TEST_ASSERT_BOOL(nullptr != config);
 
    std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
    ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);
 
    TEST_ASSERT_EQUAL(1, in_vec.size());
    TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);
 
    google::protobuf::Arena arena;
    qinglong::FeRequest request;
    qinglong::BatchSequenceExample batch_ret;
    qinglong::PredictRequest ret;
 
    // 请求时间
    request.set_request_time((int64_t)100 * 86400 * 1000);
    tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
    auto& event_times = (*(item->mutable_feature_lists()->mutable_feature_list()))["ins_time"];
    auto* list1 = event_times.add_feature();
    list1->mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
    list1->mutable_int64_list()->add_value((int64_t)91 * 86400 * 1000);
    list1->mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000);

    auto* list2 = event_times.add_feature();
    list2->mutable_int64_list()->add_value((int64_t)93 * 86400 * 1000);
    list2->mutable_int64_list()->add_value((int64_t)94 * 86400 * 1000);
    list2->mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
 
    toSequenceExample(&arena, request, vec, batch_ret);
 
    TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
    TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
 
    const auto& map1 = batch_ret.batch(0).feature_lists().feature_list();
    auto itr1 = map1.find("f5");
    TEST_ASSERT_BOOL(itr1 != map1.end());
    TEST_FEATURE_LIST_INT64(({{101}}), itr1->second);
 
    std::vector<std::shared_ptr<Config>> need_vec;
    selectConfigUsingModelInput(vec, in_vec, need_vec);
    toPredictRequest(&arena, request, need_vec, in_vec, ret);
    
    auto& map = ret.inputs();
    auto itr0 = map.find("f5");
    TEST_ASSERT_BOOL(itr0 != map.end());
    TEST_ASSERT_BOOL(itr0->second.int64_val().at(0) ==  (int64_t)101);
  }

  FUNC_TEST_END();
}

// start使用source配置
void test_seq_diff_v2_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_diff_v2" source=".user_feature.am_gm_ins_off.am_ins_off.user_sequence.app_id,.user_feature.am_gm_ins_off.am_ins_off.user_sequence.event_time,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time,.item_feature.item_feature_se.context.feature.time" day_n="30" delta_day="10" status="0" clip_size="2" />
            <feature name="f5" type="direct" source="f4:0" />
            <feature name="f6" type="direct" source="f4:1" />
            <feature name="f7" type="seq_diff_v2" source=".user_feature.am_gm_ins_off.am_ins_off.user_sequence.app_id,.user_feature.am_gm_ins_off.am_ins_off.user_sequence.event_time,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time,.item_feature.item_feature_se.context.feature.time" day_n="30" delta_day="10" status="1" clip_size="2" />
            <feature name="f8" type="direct" source="f7:0" />
            <feature name="f9" type="direct" source="f7:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1,1,5" type="sequence" />
        <input name="f6" shape="1,1,5" type="sequence" />
        <input name="f8" shape="1,1,5" type="sequence" />
        <input name="f9" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(6, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDiffV2Config* conf = dynamic_cast<SeqDiffV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(4, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_ins_off()->mutable_am_ins_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  //防穿越
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)102 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)86 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  //活跃
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)84 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  //长度截断
  pb_info->set_app_id("appid3");
  pb_info->set_event_time((int64_t)81 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time((int64_t)83 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  //时间范围过滤
  pb_info->set_app_id("appid5");
  pb_info->set_event_time((int64_t)78 * 86400 * 1000);

  pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)98 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)92 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time((int64_t)99 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid5");
  pb_info->set_event_time((int64_t)82 * 86400 * 1000);

  // 设置start
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)100 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid4"}}), itr00->second);

  auto itr01 = map00.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)86 * 86400 * 1000}, {(int64_t)83 * 86400 * 1000}}), itr01->second);

  auto itr02 = map00.find("f8");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}}), itr02->second);

  auto itr03 = map00.find("f9");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)84 * 86400 * 1000}}), itr03->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f5");
  auto itr_len0 = map.find("f5_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid1", "appid4"}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f6");
  auto itr_len1 = map.find("f6_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({(int64_t)86 * 86400 * 1000, (int64_t)83 * 86400 * 1000}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  auto itr2 = map.find("f8");
  auto itr_len2 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"appid2"}), itr2->second);
  TEST_LIST_INT32(({1}), itr_len2->second);

  auto itr3 = map.find("f9");
  auto itr_len3 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_INT64(({(int64_t)84 * 86400 * 1000}), itr3->second);
  TEST_LIST_INT32(({1}), itr_len3->second);

  FUNC_TEST_END();
}

void test_seq_interest_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f11": {
          "fe_type" : "seq_interest", 
          "source": [
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
            ".request_time",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration"
          ],
          "start" : 864000,
          "end" : 2538000,
          "default_value" : "test_no_data"
      },
      "f12" : {
          "fe_type" : "direct",
          "source": ["f11:0"]
      },
      "f13" : {
          "fe_type" : "direct",
          "source": ["f11:1"]
      },
      "f14" : {
          "fe_type" : "direct",
          "source": ["f11:2"]
      },
      "f15" : {
          "fe_type" : "direct",
          "source": ["f11:3"]
      },
      "f16" : {
          "fe_type" : "direct",
          "source": ["f11:4"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f12": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f14": {
            "dtype" : "float",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f15": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f16": {
            "dtype" : "float",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(6, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqInterestConfig* conf = dynamic_cast<SeqInterestConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104418979");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info->set_use_duration(10 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)98 * 86400 * 1000);
  pb_info->set_use_duration(20 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_event_time((int64_t)92 * 86400 * 1000);
  pb_info->set_use_duration(30 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900785693");
  pb_info->set_event_time((int64_t)99 * 86400 * 1000);
  pb_info->set_use_duration(40 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info->set_use_duration(50 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900242957");
  pb_info->set_event_time((int64_t)82 * 86400 * 1000);
  pb_info->set_use_duration(60 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900242957");
  pb_info->set_event_time((int64_t)75 * 86400 * 1000);
  pb_info->set_use_duration(20 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f12");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"900242957"}, {"900744462"}, {"900778570"}, {"900785693"}}), itr00->second);

  auto itr01 = map00.find("f13");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{60000}, {70000}, {30000}, {40000}}), itr01->second);

  auto itr02 = map00.find("f14");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_FLOAT(({{0.3}, {0.35}, {0.15}, {0.2}}), itr02->second);

  auto itr03 = map00.find("f15");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_INT64(({{1}, {2}, {1}, {1}}), itr03->second);

  auto itr04 = map00.find("f16");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_LIST_FLOAT(({{0.2}, {0.4}, {0.2}, {0.2}}), itr04->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f12");
  auto itr_len0 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"900242957", "", "900744462", "","900778570", "","900785693", ""}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f13");
  auto itr_len1 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({60000, 0, 70000, 0, 30000, 0, 40000, 0}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  auto itr2 = map.find("f14");
  auto itr_len2 = map.find("f14_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_FLOAT(({0.3, 0, 0.35, 0, 0.15, 0, 0.2, 0}), itr2->second);
  TEST_LIST_INT32(({4}), itr_len2->second);

  auto itr3 = map.find("f15");
  auto itr_len3 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_INT64(({1, 0, 2, 0, 1, 0, 1, 0}), itr3->second);
  TEST_LIST_INT32(({4}), itr_len3->second);

  auto itr4 = map.find("f16");
  auto itr_len4 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr4 != map.end());
  TEST_ASSERT_BOOL(itr_len4 != map.end());
  TEST_LIST_FLOAT(({0.2, 0, 0.4, 0, 0.2, 0, 0.2, 0}), itr4->second);
  TEST_LIST_INT32(({4}), itr_len4->second);

  FUNC_TEST_END();
}

void test_seq_interest_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f10": {
          "fe_type" : "appid_to_123_class", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"],
          "class_type" : 0,
          "default_value" : "test_no_data"
      },
      "f11": {
          "fe_type" : "seq_interest", 
          "source": [
            "f10:0",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
            ".request_time",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration"
          ],
          "now_hour" : true,
          "start" : 864000,
          "end" : 2538000,
          "default_value" : "test_no_data"
      },
      "f12" : {
          "fe_type" : "direct",
          "source": ["f11:0"]
      },
      "f13" : {
          "fe_type" : "direct",
          "source": ["f11:1"]
      },
      "f14" : {
          "fe_type" : "direct",
          "source": ["f11:2"]
      },
      "f15" : {
          "fe_type" : "direct",
          "source": ["f11:3"]
      },
      "f16" : {
          "fe_type" : "direct",
          "source": ["f11:4"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f12": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f14": {
            "dtype" : "float",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f15": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f16": {
            "dtype" : "float",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(7, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  TEST_ASSERT_BOOL(nullptr != vec[1]);

  AppidTo123ClassConfig* conf = dynamic_cast<AppidTo123ClassConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);
  SeqInterestConfig* conf2 = dynamic_cast<SeqInterestConfig*>(vec[1].get());
  TEST_ASSERT_BOOL(nullptr != conf2);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec[0]->shape.size());
  TEST_EXPECT_EQUAL(1, in_vec[0]->shape[0]);
  TEST_EXPECT_EQUAL(2, in_vec[0]->shape[1]);
  TEST_EXPECT_EQUAL(5, in_vec[0]->shape[2]);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104418979");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info->set_use_duration(10 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)98 * 86400 * 1000);
  pb_info->set_use_duration(20 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_event_time((int64_t)92 * 86400 * 1000);
  pb_info->set_use_duration(30 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900785693");
  pb_info->set_event_time((int64_t)99 * 86400 * 1000);
  pb_info->set_use_duration(40 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000 + 3600 * 2 * 1000);
  pb_info->set_use_duration(50 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900242957");
  pb_info->set_event_time((int64_t)82 * 86400 * 1000);
  pb_info->set_use_duration(60 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900242957");
  pb_info->set_event_time((int64_t)75 * 86400 * 1000);
  pb_info->set_use_duration(20 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f12");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"办公"}, {"工具"}}), itr00->second);

  auto itr01 = map00.find("f13");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{40000}, {110000}}), itr01->second);

  auto itr02 = map00.find("f14");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_FLOAT(({{0.266667}, {0.733333}}), itr02->second);

  auto itr03 = map00.find("f15");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_INT64(({{1}, {3}}), itr03->second);

  auto itr04 = map00.find("f16");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_LIST_FLOAT(({{0.25}, {0.75}}), itr04->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f12");
  auto itr_len0 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"办公", "", "工具", ""}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f13");
  auto itr_len1 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({40000, 0, 110000, 0}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  auto itr2 = map.find("f14");
  auto itr_len2 = map.find("f14_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_FLOAT(({0.266667, 0, 0.733333, 0}), itr2->second);
  TEST_LIST_INT32(({2}), itr_len2->second);

  auto itr3 = map.find("f15");
  auto itr_len3 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_INT64(({1, 0, 3, 0}), itr3->second);
  TEST_LIST_INT32(({2}), itr_len3->second);

  auto itr4 = map.find("f16");
  auto itr_len4 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr4 != map.end());
  TEST_ASSERT_BOOL(itr_len4 != map.end());
  TEST_LIST_FLOAT(({0.25, 0, 0.75, 0}), itr4->second);
  TEST_LIST_INT32(({2}), itr_len4->second);

  FUNC_TEST_END();
}

void test_seq_interest_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f10": {
          "fe_type" : "appid_to_123_class", 
          "source": [".item_feature.item_feature_se.context.feature.appid"],
          "class_type" : 1,
          "default_value" : "test_no_data"
      },
      "f11": {
          "fe_type" : "seq_interest", 
          "source": [
            "f10:0",
            ".item_feature.item_feature_se.context.feature.time",
            ".request_time",
            ".item_feature.item_feature_se.context.feature.duration"
          ],
          "now_hour" : false,
          "start" : 864000,
          "end" : 2538000,
          "default_value" : "test_no_data"
      },
      "f12" : {
          "fe_type" : "direct",
          "source": ["f11:0"]
      },
      "f13" : {
          "fe_type" : "direct",
          "source": ["f11:1"]
      },
      "f14" : {
          "fe_type" : "direct",
          "source": ["f11:2"]
      },
      "f15" : {
          "fe_type" : "direct",
          "source": ["f11:3"]
      },
      "f16" : {
          "fe_type" : "direct",
          "source": ["f11:4"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f12": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f13": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f14": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f15": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f16": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(7, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  TEST_ASSERT_BOOL(nullptr != vec[1]);

  AppidTo123ClassConfig* conf = dynamic_cast<AppidTo123ClassConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);
  SeqInterestConfig* conf2 = dynamic_cast<SeqInterestConfig*>(vec[1].get());
  TEST_ASSERT_BOOL(nullptr != conf2);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(5, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104418979");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["duration"].mutable_int64_list()->add_value(10 * 1000);
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900744462");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)98 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["duration"].mutable_int64_list()->add_value(20 * 1000);
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["duration"].mutable_int64_list()->add_value(30 * 1000);
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900785693");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)99 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["duration"].mutable_int64_list()->add_value(40 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900744462");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["duration"].mutable_int64_list()->add_value(50 * 1000);
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900242957");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["duration"].mutable_int64_list()->add_value(60 * 1000);
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900242957");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)75 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["duration"].mutable_int64_list()->add_value(20 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f12");
  auto itr10 = map01.find("f12");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"办公软件", "娱乐工具", "生活工具"}), itr00->second);
  TEST_FEATURE_STR(({"娱乐工具", "生活工具"}), itr10->second);

  auto itr01 = map00.find("f13");
  auto itr11 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_INT64(({40000, 20000, 30000}), itr01->second);
  TEST_FEATURE_INT64(({50000, 60000}), itr11->second);

  auto itr02 = map00.find("f14");
  auto itr12 = map01.find("f14");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_FLOAT(({0.444444, 0.222222, 0.333333}), itr02->second);
  TEST_FEATURE_FLOAT(({0.454545, 0.545454}), itr12->second);

  auto itr03 = map00.find("f15");
  auto itr13 = map01.find("f15");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_ASSERT_BOOL(itr13 != map01.end());

  TEST_FEATURE_INT64(({1, 1, 1}), itr03->second);
  TEST_FEATURE_INT64(({1, 1}), itr13->second);

  auto itr04 = map00.find("f16");
  auto itr14 = map01.find("f16");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_ASSERT_BOOL(itr14 != map01.end());

  TEST_FEATURE_FLOAT(({0.333333, 0.333333, 0.333333}), itr04->second);
  TEST_FEATURE_FLOAT(({0.5, 0.5}), itr14->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f12_values");
  auto itr_indices0 = map.find("f12_indices");
  auto itr_dense_shape0 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}), ({"办公软件", "娱乐工具", "生活工具", "娱乐工具", "生活工具"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f13_values");
  auto itr_indices1 = map.find("f13_indices");
  auto itr_dense_shape1 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}), ({40000, 20000, 30000, 50000, 60000}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f14_values");
  auto itr_indices2 = map.find("f14_indices");
  auto itr_dense_shape2 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}), ({0.444444, 0.222222, 0.333333, 0.454545, 0.545454}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  auto itr_values3 = map.find("f15_values");
  auto itr_indices3 = map.find("f15_indices");
  auto itr_dense_shape3 = map.find("f15_dense_shape");
  TEST_ASSERT_BOOL(itr_values3 != map.end());
  TEST_ASSERT_BOOL(itr_indices3 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape3 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}), ({1, 1, 1, 1, 1}),
                        itr_indices3->second, itr_dense_shape3->second, itr_values3->second);

  auto itr_values4 = map.find("f16_values");
  auto itr_indices4 = map.find("f16_indices");
  auto itr_dense_shape4 = map.find("f16_dense_shape");
  TEST_ASSERT_BOOL(itr_values4 != map.end());
  TEST_ASSERT_BOOL(itr_indices4 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape4 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}), ({0.333333, 0.333333, 0.333333, 0.5, 0.5}),
                        itr_indices4->second, itr_dense_shape4->second, itr_values4->second);

  FUNC_TEST_END();
}

void test_seq_interest_4() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f11": {
          "fe_type" : "seq_interest", 
          "source": [
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
            ".request_time",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration"
          ]
      },
      "f12" : {
          "fe_type" : "direct",
          "source": ["f11:0"]
      },
      "f13" : {
          "fe_type" : "direct",
          "source": ["f11:1"]
      },
      "f14" : {
          "fe_type" : "direct",
          "source": ["f11:2"]
      },
      "f15" : {
          "fe_type" : "direct",
          "source": ["f11:3"]
      },
      "f16" : {
          "fe_type" : "direct",
          "source": ["f11:4"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f12": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f13": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f14": {
            "dtype" : "float",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f15": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f16": {
            "dtype" : "float",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(6, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqInterestConfig* conf = dynamic_cast<SeqInterestConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104418979");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000);
  pb_info->set_use_duration(10 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)98 * 86400 * 1000);
  pb_info->set_use_duration(20 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_event_time((int64_t)92 * 86400 * 1000);
  pb_info->set_use_duration(30 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info->set_use_duration(50 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900242957");
  pb_info->set_event_time((int64_t)82 * 86400 * 1000);
  pb_info->set_use_duration(60 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900242957");
  pb_info->set_event_time((int64_t)75 * 86400 * 1000);
  pb_info->set_use_duration(20 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f12");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"104418979"}, {"900242957"}, {"900744462"}, {"900778570"}}), itr00->second);

  auto itr01 = map00.find("f13");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{10000}, {80000}, {70000}, {30000}}), itr01->second);

  auto itr02 = map00.find("f14");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_FLOAT(({{0.052632}, {0.421053}, {0.368421}, {0.157895}}), itr02->second);

  auto itr03 = map00.find("f15");
  TEST_ASSERT_BOOL(itr03 != map00.end());
  TEST_FEATURE_LIST_INT64(({{1}, {2}, {2}, {1}}), itr03->second);

  auto itr04 = map00.find("f16");
  TEST_ASSERT_BOOL(itr04 != map00.end());
  TEST_FEATURE_LIST_FLOAT(({{0.166667}, {0.333333}, {0.333333}, {0.166667}}), itr04->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f12");
  auto itr_len0 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"104418979", "900242957", "900744462", "900778570"}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f13");
  auto itr_len1 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({10000, 80000, 70000, 30000}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  auto itr2 = map.find("f14");
  auto itr_len2 = map.find("f14_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_FLOAT(({0.052632, 0.421053, 0.368421, 0.157895}), itr2->second);
  TEST_LIST_INT32(({4}), itr_len2->second);

  auto itr3 = map.find("f15");
  auto itr_len3 = map.find("f15_length");
  TEST_ASSERT_BOOL(itr3 != map.end());
  TEST_ASSERT_BOOL(itr_len3 != map.end());
  TEST_LIST_INT64(({1, 2, 2, 1}), itr3->second);
  TEST_LIST_INT32(({4}), itr_len3->second);

  auto itr4 = map.find("f16");
  auto itr_len4 = map.find("f16_length");
  TEST_ASSERT_BOOL(itr4 != map.end());
  TEST_ASSERT_BOOL(itr_len4 != map.end());
  TEST_LIST_FLOAT(({0.166667, 0.333333, 0.333333, 0.166667}), itr4->second);
  TEST_LIST_INT32(({4}), itr_len4->second);

  FUNC_TEST_END();
}

//feature
void test_seq_fresh_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f9": {
          "fe_type" : "appid_to_123_class", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"],
          "class_type" : 1,
          "default_value" : "test_no_data"
      },
      "f10": {
          "fe_type" : "appid_to_123_class", 
          "source": [".item_feature.item_feature_se.context.feature.appid"],
          "class_type" : 1,
          "default_value" : "test_no_data"
      },
      "f11": {
          "fe_type" : "seq_fresh", 
          "source": [
            "f9:0",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
            ".request_time",
            "f10:0"
          ],
          "start" : 864000,
          "end" : 874800
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f11": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  TEST_ASSERT_BOOL(nullptr != vec[2]);

  AppidTo123ClassConfig* conf = dynamic_cast<AppidTo123ClassConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);
  SeqFreshConfig* conf2 = dynamic_cast<SeqFreshConfig*>(vec[2].get());
  TEST_ASSERT_BOOL(nullptr != conf2);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104418979");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 2 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 3 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900785693");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 2 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 5 * 3600 * 1000);

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104418979");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900744462");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104408865");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900804211");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  
  auto itr00 = map00.find("f11");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_INT64(({2, 2, 1, 0}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f11_values");
  auto itr_indices = map.find("f11_indices");
  auto itr_dense_shape = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 0, 3}), ({1, 4}), ({2, 2, 1, 0}),
                            itr_indices->second, itr_dense_shape->second, itr_values->second);

  FUNC_TEST_END();
}

//feature_list
void test_seq_fresh_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f9": {
          "fe_type" : "appid_to_123_class", 
          "source": [".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"],
          "class_type" : 2,
          "default_value" : "test_no_data"
      },
      "f10": {
          "fe_type" : "appid_to_123_class", 
          "source": [".item_feature.item_feature_se.feature_lists.feature_list.appid"],
          "class_type" : 2,
          "default_value" : "test_no_data"
      },
      "f11": {
          "fe_type" : "seq_fresh", 
          "source": [
            "f9:0",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
            ".request_time",
            "f10:0"
          ],
          "start" : 864000,
          "end" : 874800
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f11": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  TEST_ASSERT_BOOL(nullptr != vec[2]);

  AppidTo123ClassConfig* conf = dynamic_cast<AppidTo123ClassConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);
  SeqFreshConfig* conf2 = dynamic_cast<SeqFreshConfig*>(vec[2].get());
  TEST_ASSERT_BOOL(nullptr != conf2);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104418979");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 2 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 1 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900785693");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 4 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104408865");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 2 * 3600 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("104418979");
  fate->mutable_bytes_list()->add_value("900778570");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("900785693");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"].add_feature()->mutable_bytes_list()->add_value("104438810");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  const auto& map01 = batch_ret.batch(1).feature_lists().feature_list();
  
  auto itr00 = map00.find("f11");
  auto itr10 = map01.find("f11");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_LIST_INT64(({{1, 1}, {0}}), itr00->second);
  TEST_FEATURE_LIST_INT64(({{0}}), itr10->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f11");
  auto itr_len0 = map.find("f11_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({1, 1, 0, 0, 0, 0, 0, 0}), itr0->second);
  TEST_LIST_INT32(({2, 1}), itr_len0->second);

  FUNC_TEST_END();
}

//默认参数
void test_seq_fresh_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f11": {
          "fe_type" : "seq_fresh", 
          "source": [
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
            ".request_time",
            ".item_feature.item_feature_se.context.feature.appid"
          ],
          "now_hour" : true
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f11": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFreshConfig* conf = dynamic_cast<SeqFreshConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("104418979");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 24 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900778570");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 36 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900785693");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 24 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("900744462");
  pb_info->set_event_time((int64_t)100 * 86400 * 1000 - 48 * 3600 * 1000);

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104418979");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900744462");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900785693");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  
  auto itr00 = map00.find("f11");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_INT64(({0, 2, 0, 1}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values = map.find("f11_values");
  auto itr_indices = map.find("f11_indices");
  auto itr_dense_shape = map.find("f11_dense_shape");
  TEST_ASSERT_BOOL(itr_values != map.end());
  TEST_ASSERT_BOOL(itr_indices != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 0, 3}), ({1, 4}), ({0, 2, 0, 1}),
                            itr_indices->second, itr_dense_shape->second, itr_values->second);

  FUNC_TEST_END();
}

void test_seq_dsp_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f11": {
          "fe_type" : "seq_dsp", 
          "source": [
            ".user_action.request_id",
            ".user_action.click_time",
            ".request_time",
            ".user_action.pctr"
          ],
          "start" : 864000,
          "end" : 2538000,
          "default_value" : "test_no_data"
      },
      "f12" : {
          "fe_type" : "direct",
          "source": ["f11:0"]
      },
      "f13" : {
          "fe_type" : "direct",
          "source": ["f11:1"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f12": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f13": {
            "dtype" : "float",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDspConfig* conf = dynamic_cast<SeqDspConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user_action
  qinglong::UserAction* user_action = request.add_user_action();
  user_action->set_request_id("104418979");
  user_action->set_click_time((int64_t)105 * 86400 * 1000);
  user_action->set_pctr(0.2);
  user_action = request.add_user_action();
  user_action->set_request_id("900744462");
  user_action->set_click_time((int64_t)98 * 86400 * 1000);
  user_action->set_pctr(0.4);
  user_action = request.add_user_action();
  user_action->set_request_id("900778570");
  user_action->set_click_time((int64_t)92 * 86400 * 1000);
  user_action->set_pctr(0.2);
  user_action = request.add_user_action();
  user_action->set_request_id("900785693");
  user_action->set_click_time((int64_t)99 * 86400 * 1000);
  user_action->set_pctr(0.5);
  user_action = request.add_user_action();
  user_action->set_request_id("900744462");
  user_action->set_click_time((int64_t)95 * 86400 * 1000);
  user_action->set_pctr(0.3);
  user_action = request.add_user_action();
  user_action->set_request_id("900242957");
  user_action->set_click_time((int64_t)82 * 86400 * 1000);
  user_action->set_pctr(0.1);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f12");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"900242957"}, {"900744462"}, {"900778570"}, {"900785693"}}), itr00->second);

  auto itr01 = map00.find("f13");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_FLOAT(({{0.1}, {0.35}, {0.2}, {0.5}}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f12");
  auto itr_len0 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"900242957", "", "900744462", "","900778570", "","900785693", ""}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f13");
  auto itr_len1 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_FLOAT(({0.1, 0, 0.35, 0, 0.2, 0, 0.5, 0}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  FUNC_TEST_END();
}

void test_seq_dsp_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f10": {
          "fe_type" : "appid_to_123_class", 
          "source": [".item_feature.item_feature_se.context.feature.appid"],
          "class_type" : 2,
          "default_value" : "test_no_data"
      },
      "f11": {
          "fe_type" : "seq_dsp", 
          "source": [
            "f10:0",
            ".item_feature.item_feature_se.context.feature.time",
            ".request_time",
            ".item_feature.item_feature_se.context.feature.pctr",
            ".item_feature.item_feature_se.context.feature.pcvr"
          ],
          "start" : 864000,
          "end" : 2538000,
          "default_value" : "test_no_data"
      },
      "f12" : {
          "fe_type" : "direct",
          "source": ["f11:0"]
      },
      "f13" : {
          "fe_type" : "direct",
          "source": ["f11:1"]
      },
      "f14" : {
          "fe_type" : "direct",
          "source": ["f11:2"]
      }
    },
    "item_map": "900744462,工具,娱乐工具,娱乐测试;900778570,工具,生活工具,日历;104418979,工具,娱乐工具,变声器;900242957,工具,生活工具,家居控制;900785693,办公,办公软件,日程管理;104408865,办公,办公软件,效率办公;900804211,经营养成,经营模拟,经营模拟;104438810,视频,直播,真人娱乐直播;900738655,教育,学生学习,家校沟通;900770543,交通出行,导航定位,定位;900795471,购物,商城,超市/便利店"
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f12": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f13": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f14": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(5, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);
  TEST_ASSERT_BOOL(nullptr != vec[1]);

  AppidTo123ClassConfig* conf = dynamic_cast<AppidTo123ClassConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);
  SeqDspConfig* conf2 = dynamic_cast<SeqDspConfig*>(vec[1].get());
  TEST_ASSERT_BOOL(nullptr != conf2);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item不为空
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("104418979");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["pctr"].mutable_float_list()->add_value(0.2);
  (*(item->mutable_context()->mutable_feature()))["pcvr"].mutable_float_list()->add_value(0.2);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900744462");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)98 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["pctr"].mutable_float_list()->add_value(0.4);
  (*(item->mutable_context()->mutable_feature()))["pcvr"].mutable_float_list()->add_value(0.4);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900778570");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["pctr"].mutable_float_list()->add_value(0.2);
  (*(item->mutable_context()->mutable_feature()))["pcvr"].mutable_float_list()->add_value(0.2);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900785693");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)99 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["pctr"].mutable_float_list()->add_value(0.5);
  (*(item->mutable_context()->mutable_feature()))["pcvr"].mutable_float_list()->add_value(0.5);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900744462");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["duration"].mutable_int64_list()->add_value(50 * 1000);
  (*(item->mutable_context()->mutable_feature()))["pctr"].mutable_float_list()->add_value(0.3);
  (*(item->mutable_context()->mutable_feature()))["pcvr"].mutable_float_list()->add_value(0.3);
  
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("900242957");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["pctr"].mutable_float_list()->add_value(0.1);
  (*(item->mutable_context()->mutable_feature()))["pcvr"].mutable_float_list()->add_value(0.1);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f12");
  auto itr10 = map01.find("f12");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());

  TEST_FEATURE_STR(({"娱乐测试", "日历", "日程管理"}), itr00->second);
  TEST_FEATURE_STR(({"娱乐测试", "家居控制"}), itr10->second);

  auto itr01 = map00.find("f13");
  auto itr11 = map01.find("f13");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());

  TEST_FEATURE_FLOAT(({0.4, 0.2, 0.5}), itr01->second);
  TEST_FEATURE_FLOAT(({0.3, 0.1}), itr11->second);

  auto itr02 = map00.find("f14");
  auto itr12 = map01.find("f14");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());

  TEST_FEATURE_FLOAT(({0.4, 0.2, 0.5}), itr02->second);
  TEST_FEATURE_FLOAT(({0.3, 0.1}), itr12->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f12_values");
  auto itr_indices0 = map.find("f12_indices");
  auto itr_dense_shape0 = map.find("f12_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}), ({"娱乐测试", "日历", "日程管理", "娱乐测试", "家居控制"}),
                        itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f13_values");
  auto itr_indices1 = map.find("f13_indices");
  auto itr_dense_shape1 = map.find("f13_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}), ({0.4, 0.2, 0.5, 0.3, 0.1}),
                        itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f14_values");
  auto itr_indices2 = map.find("f14_indices");
  auto itr_dense_shape2 = map.find("f14_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}), ({0.4, 0.2, 0.5, 0.3, 0.1}),
                        itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  FUNC_TEST_END();
}

void test_seq_dsp_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f11": {
          "fe_type" : "seq_dsp", 
          "source": [
            ".user_action.request_id",
            ".user_action.click_time",
            ".request_time",
            ".user_action.pctr"
          ]
      },
      "f12" : {
          "fe_type" : "direct",
          "source": ["f11:0"]
      },
      "f13" : {
          "fe_type" : "direct",
          "source": ["f11:1"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f12": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f13": {
            "dtype" : "float",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDspConfig* conf = dynamic_cast<SeqDspConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user_action
  qinglong::UserAction* user_action = request.add_user_action();
  user_action->set_request_id("104418979");
  user_action->set_click_time((int64_t)105 * 86400 * 1000);
  user_action->set_pctr(0.2);
  user_action = request.add_user_action();
  user_action->set_request_id("900744462");
  user_action->set_click_time((int64_t)98 * 86400 * 1000);
  user_action->set_pctr(0.4);
  user_action = request.add_user_action();
  user_action->set_request_id("900778570");
  user_action->set_click_time((int64_t)92 * 86400 * 1000);
  user_action->set_pctr(0.2);
  user_action = request.add_user_action();
  user_action->set_request_id("900785693");
  user_action->set_click_time((int64_t)99 * 86400 * 1000);
  user_action->set_pctr(0.5);
  user_action = request.add_user_action();
  user_action->set_request_id("900744462");
  user_action->set_click_time((int64_t)95 * 86400 * 1000);
  user_action->set_pctr(0.3);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f12");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"104418979"}, {"900744462"}, {"900778570"}, {"900785693"}}), itr00->second);

  auto itr01 = map00.find("f13");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_FLOAT(({{0.2}, {0.35}, {0.2}, {0.5}}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f12");
  auto itr_len0 = map.find("f12_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"104418979", "", "900744462", "","900778570", "","900785693", ""}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f13");
  auto itr_len1 = map.find("f13_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_FLOAT(({0.2, 0, 0.35, 0, 0.2, 0, 0.5, 0}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  FUNC_TEST_END();
}

//featurelist
void test_seq_num_convert_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_num_convert", 
          "source": [
              ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id"
          ],
          "type" : 1
      },
      "f7" : {
          "fe_type" : "direct",
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct",
          "source": ["f6:1"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqNumConvertConfig* conf = dynamic_cast<SeqNumConvertConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid0"}, {"appid1"}, {"appid2"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{40}, {20}, {40}}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid0", "", "appid1", "", "appid2", ""}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({40, 0, 20, 0, 40, 0}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

//feature
void test_seq_num_convert_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_num_convert", 
          "source": [
              ".item_feature.item_feature_se.context.feature.appid"
          ],
          "type" : 0
      },
      "f7" : {
          "fe_type" : "direct",
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct",
          "source": ["f6:1"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqNumConvertConfig* conf = dynamic_cast<SeqNumConvertConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"appid0", "appid1", "appid2"}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_INT64(({1, 3, 2}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2}), ({1, 3}), ({"appid0", "appid1", "appid2"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f8_values");
  auto itr_indices1 = map.find("f8_indices");
  auto itr_dense_shape1 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2}), ({1, 3}), ({1, 3, 2}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

//type=2,频率输出float
void test_seq_num_convert_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_num_convert" source=".item_feature.item_feature_se.context.feature.appid" count_type="2" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
            <feature name="f9" type="seq_num_convert" source=".item_feature.item_feature_se.feature_lists.feature_list.item" count_type="2" />
            <feature name="f10" type="direct" source="f9:0" />
            <feature name="f11" type="direct" source="f9:1" />
        </features>
    </config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(6, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqNumConvertConfig* conf = dynamic_cast<SeqNumConvertConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");

  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["item"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"appid0", "appid1", "appid2"}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_FLOAT(({16.66666, 50.000000, 33.333333}), itr01->second);

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr02 = map0.find("f10");
  TEST_ASSERT_BOOL(itr02 != map0.end());
  TEST_FEATURE_LIST_STR(({{"appid0"}, {"appid1"}, {"appid2"}}), itr02->second);

  auto itr03 = map0.find("f11");
  TEST_ASSERT_BOOL(itr03 != map0.end());
  TEST_FEATURE_LIST_FLOAT(({{33.333333}, {33.333333}, {33.333333}}), itr03->second);

  FUNC_TEST_END();
}

//feature_base
void test_seq_num_convert_base(const std::vector<std::string> source_value,
                               const std::vector<std::string> out_value1,
                               const std::vector<int64_t> out_value2,
                               int64_t type = 0) {
  FUNC_TEST_START();

  std::string before_str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_num_convert", 
          "source": [
              "E@.item_feature.item_feature_se.context.feature.appid"
          ],
          "type" : )";

  std::string after_str = R"(
      },
      "f7" : {
          "fe_type" : "direct",
          "strategy" : "empty",
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct",
          "strategy" : "empty",
          "source": ["f6:1"]
      }
    }
  })";

  std::string str = before_str + std::to_string(type) + after_str;

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  for (uint32_t i = 0; i < source_value.size(); i++) {
    (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value(source_value[i]);
  }

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR({out_value1}, itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_INT64({out_value2}, itr01->second);

  FUNC_TEST_END();
}

void test_seq_val_direct_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_val_direct", 
          "source": [
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
            ".request_time",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration"
          ],
          "start" : 864000,
          "day_n" : 30,
          "clip_size" : 2,
          "upper_bound" : 86400000
      },
      "f7" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      },
      "f9" : {
          "fe_type" : "direct", 
          "source": ["f6:2"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        },
        "f9": {
            "dtype" : "int64",
            "shape" : [1, 2, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqValDirectConfig* conf = dynamic_cast<SeqValDirectConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000); //start过滤
  pb_info->set_use_duration((int64_t)1 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)84 * 86400 * 1000);
  pb_info->set_use_duration((int64_t)2 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)92 * 86400 * 1000);
  pb_info->set_use_duration((int64_t)100 * 3600 * 1000); //upper_bound过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info->set_use_duration((int64_t)4 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time((int64_t)99 * 86400 * 1000); //clip_size截断
  pb_info->set_use_duration((int64_t)5 * 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid5");
  pb_info->set_event_time((int64_t)78 * 86400 * 1000); //day_n过滤
  pb_info->set_use_duration((int64_t)6 * 3600 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid3"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)84 * 86400 * 1000}, {(int64_t)95 * 86400 * 1000}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)2 * 3600 * 1000}, {(int64_t)4 * 3600 * 1000}}), itr02->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid1", "", "appid3", ""}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({(int64_t)84 * 86400 * 1000, 0, (int64_t)95 * 86400 * 1000, 0}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({(int64_t)2 * 3600 * 1000, 0, (int64_t)4 * 3600 * 1000, 0}), itr2->second);
  TEST_LIST_INT32(({2}), itr_len2->second);
 
  FUNC_TEST_END();
}

void test_seq_val_direct_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_val_direct", 
          "source": [
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
            ".request_time",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_source"
          ],
          "start" : 864000,
          "day_n" : 30,
          "clip_size" : 5
      },
      "f7" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      },
      "f9" : {
          "fe_type" : "direct", 
          "source": ["f6:2"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f9": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqValDirectConfig* conf = dynamic_cast<SeqValDirectConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000); //start过滤
  pb_info->set_event_source("游戏中心");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)84 * 86400 * 1000);
  pb_info->set_event_source("应用市场");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)92 * 86400 * 1000);
  pb_info->set_event_source("游戏中心");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info->set_event_source("应用市场");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time((int64_t)99 * 86400 * 1000);
  pb_info->set_event_source("应用市场");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid5");
  pb_info->set_event_time((int64_t)78 * 86400 * 1000); //day_n过滤
  pb_info->set_event_source("应用市场");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid2"}, {"appid3"}, {"appid4"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)84 * 86400 * 1000}, {(int64_t)92 * 86400 * 1000},
                            {(int64_t)95 * 86400 * 1000}, {(int64_t)99 * 86400 * 1000}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_STR(({{"应用市场"}, {"游戏中心"}, {"应用市场"}, {"应用市场"}}), itr02->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid1", "appid2", "appid3", "appid4"}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({(int64_t)84 * 86400 * 1000, (int64_t)92 * 86400 * 1000,
                    (int64_t)95 * 86400 * 1000, (int64_t)99 * 86400 * 1000}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_STRING(({"应用市场", "游戏中心", "应用市场", "应用市场"}), itr2->second);
  TEST_LIST_INT32(({4}), itr_len2->second);
 
  FUNC_TEST_END();
}

void test_seq_val_direct_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_val_direct", 
          "source": [
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
            ".request_time"
          ],
          "start" : 864000,
          "day_n" : 30,
          "clip_size" : 5
      },
      "f7" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqValDirectConfig* conf = dynamic_cast<SeqValDirectConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000); //start过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)84 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)92 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time((int64_t)99 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid5");
  pb_info->set_event_time((int64_t)78 * 86400 * 1000); //day_n过滤

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid2"}, {"appid3"}, {"appid4"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)84 * 86400 * 1000}, {(int64_t)92 * 86400 * 1000},
                            {(int64_t)95 * 86400 * 1000}, {(int64_t)99 * 86400 * 1000}}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid1", "appid2", "appid3", "appid4"}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({(int64_t)84 * 86400 * 1000, (int64_t)92 * 86400 * 1000,
                    (int64_t)95 * 86400 * 1000, (int64_t)99 * 86400 * 1000}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);
 
  FUNC_TEST_END();
}

void test_seq_val_direct_4() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_val_direct", 
          "source": [
            ".item_feature.item_feature_se.context.feature.app_id",
            ".item_feature.item_feature_se.context.feature.event_time",
            ".request_time",
            ".item_feature.item_feature_se.context.feature.num"
          ],
          "start" : 864000,
          "day_n" : 30,
          "clip_size" : 2,
          "upper_bound" : 1.00
      },
      "f7" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      },
      "f9" : {
          "fe_type" : "direct", 
          "source": ["f6:2"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f9": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqValDirectConfig* conf = dynamic_cast<SeqValDirectConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(0.43);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(0.28);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(0.34);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid3");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(1.28);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid4");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(0.19);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"appid0", "appid1"}), itr00->second);
  TEST_FEATURE_STR(({"appid4"}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({(int64_t)82 * 86400 * 1000, (int64_t)90 * 86400 * 1000}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)95 * 86400 * 1000}), itr11->second);

  auto itr02 = map00.find("f9");
  auto itr12 = map01.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());
  TEST_FEATURE_FLOAT(({0.43, 0.28}), itr02->second);
  TEST_FEATURE_FLOAT(({0.19}), itr12->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0}), ({2, 2}), ({"appid0", "appid1", "appid4"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f8_values");
  auto itr_indices1 = map.find("f8_indices");
  auto itr_dense_shape1 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 1, 0}), ({2, 2}), ({(int64_t)82 * 86400 * 1000, (int64_t)90 * 86400 * 1000, (int64_t)95 * 86400 * 1000}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f9_values");
  auto itr_indices2 = map.find("f9_indices");
  auto itr_dense_shape2 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 1, 0}), ({2, 2}), ({0.43, 0.28, 0.19}),
                            itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  FUNC_TEST_END();
}

//feature_base
template <typename T>
void test_seq_val_direct_base(int64_t time,
                              const std::vector<std::string> appid_value,
                              const std::vector<int64_t> event_value,
                              bool flag,
                              const std::vector<T> list_value,
                              const std::vector<std::string> out_value1,
                              const std::vector<int64_t> out_value2,
                              const std::vector<T> out_value3,
                              int64_t start = 0,
                              int64_t day_n = -1,
                              int64_t clip_size = -1,
                              float upper_bound = -1) {
  FUNC_TEST_START();

  std::string str0 = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_val_direct", 
          "source": [
            "E@.item_feature.item_feature_se.context.feature.app_id",
            "E@.item_feature.item_feature_se.context.feature.event_time",
            ".request_time")";

  std::string str_list = R"(,
            "E@.item_feature.item_feature_se.context.feature.num")";

  std::string str1 = R"(],
          "start" : )";

  std::string str2 = R"(,
          "day_n" : )";

  std::string str3 = R"(,
          "clip_size" : )";

  std::string str4 = R"(,
          "upper_bound" : )";

  std::string str5 = R"(
      },
      "f7" : {
          "fe_type" : "direct", 
          "strategy" : "empty",
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "strategy" : "empty",
          "source": ["f6:1"]
      })";

  std::string str6 = R"(,
      "f9" : {
          "fe_type" : "direct", 
          "strategy" : "empty",
          "source": ["f6:2"]
      })";

  std::string str7 = R"(
    }
  })";

  std::string str = str0;

  if (flag) {
    str.append(str_list);
  }
  str.append(str1).append(std::to_string(start)).append(str2).append(std::to_string(day_n)).append(str3).append(std::to_string(clip_size)).append(str4).append(std::to_string(upper_bound)).append(str5);
  if (flag) {
    str.append(str6);
  }
  str.append(str7);

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_BOOL(nullptr != vec[0]);
  SeqValDirectConfig* conf = dynamic_cast<SeqValDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // 请求时间
  request.set_request_time(time);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  for (uint32_t i = 0; i < appid_value.size(); i++) {
    (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value(appid_value[i]);
  }

  for (uint32_t i = 0; i < event_value.size(); i++) {
    (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value(event_value[i]);
  }

  if (flag) {
    fill_map_data((*(item->mutable_context()->mutable_feature())), list_value, "num");
  }

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR({out_value1}, itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_INT64({out_value2}, itr01->second);

  if (flag) {
    auto itr02 = map00.find("f9");
    TEST_ASSERT_BOOL(itr02 != map00.end());
    feature_equal(out_value3, itr02->second);
  }

  FUNC_TEST_END();
}

//默认参数
void test_seq_val_direct_5() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_val_direct", 
          "source": [
            ".item_feature.item_feature_se.context.feature.app_id",
            ".item_feature.item_feature_se.context.feature.event_time",
            ".request_time",
            ".item_feature.item_feature_se.context.feature.num"
          ]
      },
      "f7" : {
          "fe_type" : "direct", 
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "source": ["f6:1"]
      },
      "f9" : {
          "fe_type" : "direct", 
          "source": ["f6:2"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f7": {
            "dtype" : "string",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f8": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        },
        "f9": {
            "dtype" : "float",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqValDirectConfig* conf = dynamic_cast<SeqValDirectConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(0.43);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(0.28);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(0.34);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid3");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(1.28);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid4");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_float_list()->add_value(0.19);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"appid0", "appid1", "appid2"}), itr00->second);
  TEST_FEATURE_STR(({"appid3", "appid4"}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({(int64_t)82 * 86400 * 1000, (int64_t)90 * 86400 * 1000, (int64_t)105 * 86400 * 1000}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)85 * 86400 * 1000, (int64_t)95 * 86400 * 1000}), itr11->second);

  auto itr02 = map00.find("f9");
  auto itr12 = map01.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_ASSERT_BOOL(itr12 != map01.end());
  TEST_FEATURE_FLOAT(({0.43, 0.28, 0.34}), itr02->second);
  TEST_FEATURE_FLOAT(({1.28, 0.19}), itr12->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}), ({"appid0", "appid1", "appid2", "appid3", "appid4"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f8_values");
  auto itr_indices1 = map.find("f8_indices");
  auto itr_dense_shape1 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}),
                           ({(int64_t)82 * 86400 * 1000, (int64_t)90 * 86400 * 1000, (int64_t)105 * 86400 * 1000, 
                             (int64_t)85 * 86400 * 1000, (int64_t)95 * 86400 * 1000,}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  auto itr_values2 = map.find("f9_values");
  auto itr_indices2 = map.find("f9_indices");
  auto itr_dense_shape2 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values2 != map.end());
  TEST_ASSERT_BOOL(itr_indices2 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape2 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 0, 2, 1, 0, 1, 1}), ({2, 3}), ({0.43, 0.28, 0.34, 1.28, 0.19}),
                            itr_indices2->second, itr_dense_shape2->second, itr_values2->second);

  FUNC_TEST_END();
}

//featurelist
void test_seq_topn_v2_1(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_topn_v2",
        "source": [
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.use_duration"
        ],
        "topn" : 3,
        "type" : 3, 
        "reserve" : 0
      },
      "f1" : {
          "fe_type" : "direct",
          "source": ["f0:0"]
      },
      "f2" : {
          "fe_type" : "direct",
          "source": ["f0:1"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f1": {
            "dtype" : "string",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        },
        "f2": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopNV2Config* conf = dynamic_cast<SeqTopNV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time(5 * 86400 * 1000);
  pb_info->set_use_duration(100);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time(11 * 86400 * 1000);
  pb_info->set_use_duration(300);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(9 * 86400 * 1000);
  pb_info->set_use_duration(200);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time(10 * 86400 * 1000);
  pb_info->set_use_duration(500);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time(9 * 86400 * 1000);
  pb_info->set_use_duration(100);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(4 * 86400 * 1000);
  pb_info->set_use_duration(300);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time(7 * 86400 * 1000);
  pb_info->set_use_duration(200);

  //item不为零
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f1");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid3"}, {"appid2"}, {"appid1"}, {"appid4"}}), itr00->second);

  auto itr01 = map00.find("f2");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{500}, {500}, {300}, {300}}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  auto itr0 = map.find("f1");
  auto itr_len0 = map.find("f1_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid3", "appid2", "appid1", "appid4"}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f2");
  auto itr_len1 = map.find("f2_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({500, 500, 300, 300}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  FUNC_TEST_END();
}

void test_seq_topn_v2_2(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_topn_v2",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time"
        ],
        "topn" : 2,
        "type" : 1, 
        "reserve" : 1
      },
      "f1" : {
          "fe_type" : "direct",
          "source": ["f0:0"]
      },
      "f2" : {
          "fe_type" : "direct",
          "source": ["f0:1"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f1": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f2": {
            "dtype" : "int64",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopNV2Config* conf = dynamic_cast<SeqTopNV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)7 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)11 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(2, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  const auto& map1 = ret.batch(1).context().feature();
  
  auto itr00 = map0.find("f1");
  auto itr10 = map1.find("f1");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_FEATURE_STR(({"appid0", "appid2"}), itr00->second);
  TEST_FEATURE_STR(({"appid0"}), itr10->second);

  auto itr01 = map0.find("f2");
  auto itr11 = map1.find("f2");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());
  TEST_FEATURE_INT64(({(int64_t)5 * 86400 * 1000, (int64_t)7 * 86400 * 1000}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)11 * 86400 * 1000}), itr11->second);

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  auto itr_values0 = map.find("f1_values");
  auto itr_indices0 = map.find("f1_indices");
  auto itr_dense_shape0 = map.find("f1_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 1, 0}), ({2, 2}), ({"appid0", "appid2", "appid0"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f2_values");
  auto itr_indices1 = map.find("f2_indices");
  auto itr_dense_shape1 = map.find("f2_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 1, 0}), ({2, 2}), ({(int64_t)5 * 86400 * 1000, (int64_t)7 * 86400 * 1000, (int64_t)11 * 86400 * 1000}),
                          itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_seq_topn_v2_3(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_topn_v2",
        "source": [
          ".item_feature.item_feature_se.context.feature.appid",
          ".item_feature.item_feature_se.context.feature.time"
        ],
        "topn" : 1,
        "type" : 2
      },
      "f1" : {
          "fe_type" : "direct",
          "source": ["f0:0"]
      },
      "f2" : {
          "fe_type" : "direct",
          "source": ["f0:1"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f1": {
            "dtype" : "string",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        },
        "f2": {
            "dtype" : "int64",
            "shape" : [1] ,
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopNV2Config* conf = dynamic_cast<SeqTopNV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)5 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)9 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)7 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value((int64_t)11 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(2, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, ret.batch(1).has_context());

  const auto& map0 = ret.batch(0).context().feature();
  const auto& map1 = ret.batch(1).context().feature();
  
  auto itr00 = map0.find("f1");
  auto itr10 = map1.find("f1");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_ASSERT_BOOL(itr10 != map1.end());
  TEST_FEATURE_STR(({"appid1", "appid2", "appid0"}), itr00->second);
  TEST_FEATURE_STR(({"appid0"}), itr10->second);

  auto itr01 = map0.find("f2");
  auto itr11 = map1.find("f2");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_ASSERT_BOOL(itr11 != map1.end());
  TEST_FEATURE_INT64(({1, 1, 1}), itr01->second);
  TEST_FEATURE_INT64(({1}), itr11->second);

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  auto itr_values0 = map.find("f1_values");
  auto itr_indices0 = map.find("f1_indices");
  auto itr_dense_shape0 = map.find("f1_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({"appid1", "appid2", "appid0", "appid0"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f2_values");
  auto itr_indices1 = map.find("f2_indices");
  auto itr_dense_shape1 = map.find("f2_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 1, 0}), ({2, 3}), ({1, 1, 1, 1}),
                          itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_seq_topn_v2_4(){
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f0": {
        "fe_type" : "seq_topn_v2",
        "source": [
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
          ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time",
          ".item_feature.item_feature_se.feature_lists.feature_list.float"
        ],
        "topn" : 3,
        "type" : 3
      },
      "f1" : {
          "fe_type" : "direct",
          "source": ["f0:0"]
      },
      "f2" : {
          "fe_type" : "direct",
          "source": ["f0:1"]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f1": {
            "dtype" : "string",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        },
        "f2": {
            "dtype" : "float",
            "shape" : [1, 1, 5] ,
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);
  
  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopNV2Config* conf = dynamic_cast<SeqTopNV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest pre_ret;

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time(5 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time(11 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(9 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time(10 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time(9 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(4 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time(7 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["float"];
  feat_list.add_feature()->mutable_float_list()->add_value(0.1);
  feat_list.add_feature()->mutable_float_list()->add_value(0.3);
  feat_list.add_feature()->mutable_float_list()->add_value(0.2);
  feat_list.add_feature()->mutable_float_list()->add_value(0.5);
  feat_list.add_feature()->mutable_float_list()->add_value(0.1);
  feat_list.add_feature()->mutable_float_list()->add_value(0.3);
  feat_list.add_feature()->mutable_float_list()->add_value(0.2);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();
  
  auto itr00 = map00.find("f1");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid3"}, {"appid2"}, {"appid1"}, {"appid4"}}), itr00->second);

  auto itr01 = map00.find("f2");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_FLOAT(({{0.5}, {0.5}, {0.3}, {0.3}}), itr01->second);

  toPredictRequest(&arena, request, vec, in_vec, pre_ret);

  auto& map = pre_ret.inputs();

  auto itr0 = map.find("f1");
  auto itr_len0 = map.find("f1_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid3", "appid2", "appid1", "appid4"}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f2");
  auto itr_len1 = map.find("f2_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_FLOAT(({0.5, 0.5, 0.3, 0.3}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  FUNC_TEST_END();
}

//feature_base
template <typename T>
void test_seq_topn_v2_base(const std::vector<std::string> appid_value,
                           const std::vector<int64_t> event_value,
                           bool flag,
                           const std::vector<T> list_value,
                           const std::vector<std::string> out_value1,
                           const std::vector<T> out_value2,
                           int64_t topn = -1,
                           int64_t type = 1,
                           int64_t reserve = 0) {
  FUNC_TEST_START();

  std::string str0 = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_topn_v2", 
          "source": [
            "E@.item_feature.item_feature_se.context.feature.app_id",
            "E@.item_feature.item_feature_se.context.feature.event_time")";

  std::string str_list = R"(,
            "E@.item_feature.item_feature_se.context.feature.num")";

  std::string str1 = R"(
          ],
          "topn" : )";

  std::string str2 = R"(,
          "type" : )";

  std::string str3 = R"(,
          "reserve" : )";

  std::string str4 = R"(
      },
      "f7" : {
          "fe_type" : "direct", 
          "strategy" : "empty",
          "source": ["f6:0"]
      },
      "f8" : {
          "fe_type" : "direct", 
          "strategy" : "empty",
          "source": ["f6:1"]
      }
    }
  })";

  std::string str = str0;
  if (flag) {
    str.append(str_list);
  }
  str.append(str1).append(std::to_string(topn)).append(str2).append(std::to_string(type)).append(str3).append(std::to_string(reserve)).append(str4);

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_BOOL(nullptr != vec[0]);
  SeqTopNV2Config* conf = dynamic_cast<SeqTopNV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  for (uint32_t i = 0; i < appid_value.size(); i++) {
    (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value(appid_value[i]);
  }

  for (uint32_t i = 0; i < event_value.size(); i++) {
    (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value(event_value[i]);
  }

  if (flag) {
    fill_map_data((*(item->mutable_context()->mutable_feature())), list_value, "num");
  }

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR({out_value1}, itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  feature_equal(out_value2, itr01->second);

  FUNC_TEST_END();
}

void test_seq_hit_or_not_1() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_or_not", 
          "source": [
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".item_feature.item_id.app_id"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitOrNotConfig* conf = dynamic_cast<SeqHitOrNotConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");

  // item
  request.add_item_feature()->mutable_item_id()->set_app_id("appid1");
  request.add_item_feature()->mutable_item_id()->set_app_id("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f6");
  auto itr10 = map01.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_INT64(({1}), itr00->second);
  TEST_FEATURE_INT64(({1}), itr10->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({1, 1}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_seq_hit_or_not_2() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_or_not", 
          "source": [
            ".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id",
            ".item_feature.game_item_offline_feature.game_item_atrribute_feature.app_name"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1, 1, 5] , 
            "model_input_type" : "sequence"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitOrNotConfig* conf = dynamic_cast<SeqHitOrNotConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");

  // item不为空
  qinglong::GameItemAttributeFeature* item = request.add_item_feature()->mutable_game_item_offline_feature()->mutable_game_item_atrribute_feature();
  item->add_app_name("appid2");
  item->add_app_name("appid1");
  item->add_app_name("appid3");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{1}, {1}, {0}}), itr00->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f6");
  auto itr_len0 = map.find("f6_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({1, 1, 0}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  FUNC_TEST_END();
}

void test_seq_hit_or_not_3() {
  FUNC_TEST_START();

  std::string str = R"({
    "extract_features" : {
      "f6": {
          "fe_type" : "seq_hit_or_not", 
          "source": [
            ".item_feature.item_feature_se.context.feature.app_id",
            ".item_feature.item_feature_se.context.feature.name"
          ]
      }
    }
  })";

  std::string in_str = R"({
    "model_input_config": {
        "f6": {
            "dtype" : "int64",
            "shape" : [1] , 
            "model_input_type" : "sparse"
        }
    }
  })";

  std::vector<std::shared_ptr<Config>> vec;
  JsonConfigMgr::parse_from_string(str, vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqHitOrNotConfig* conf = dynamic_cast<SeqHitOrNotConfig*>(vec[0].get());

  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");

  (*(item->mutable_context()->mutable_feature()))["name"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["name"].mutable_bytes_list()->add_value("appid3");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");

  (*(item->mutable_context()->mutable_feature()))["name"].mutable_bytes_list()->add_value("appid1");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f6");
  auto itr10 = map01.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_INT64(({1, 0}), itr00->second);
  TEST_FEATURE_INT64(({1}), itr10->second);

  toPredictRequest(&arena, request, vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 1, 0}), ({2, 2}), ({1, 0, 1}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

//user一层repeated且在source字段尾部
void test_seq_by_inter_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_by_inter" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq,.item_feature.game_item_offline_feature.game_item_atrribute_feature.app_name" inter_key="query" fields="event_type,event_time,pay_money" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
            <feature name="f9" type="direct" source="f6:2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,2,3" type="sequence" />
        <input name="f8" shape="1,2,3" type="sequence" />
        <input name="f9" shape="1,2,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqByInterConfig* conf = dynamic_cast<SeqByInterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid0");
  pb_info->set_event_type("0");
  pb_info->set_event_time(60);
  pb_info->set_pay_money(100);
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_event_type("1");
  pb_info->set_event_time(120);
  pb_info->set_pay_money(200);
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid0");
  pb_info->set_event_type("0");
  pb_info->set_event_time(240);
  pb_info->set_pay_money(300);
  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_event_type("2");
  pb_info->set_event_time(360);
  pb_info->set_pay_money(400);

  // item
  qinglong::GameItemAttributeFeature* item = request.add_item_feature()->mutable_game_item_offline_feature()->mutable_game_item_atrribute_feature();
  item->add_app_name("appid2");
  item->add_app_name("appid1");
  item->add_app_name("appid0");
  item->add_app_name("appid3");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"2"}, {"1"}, {"0", "0"}, {}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{360}, {120}, {60, 240}, {}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{400}, {200}, {100, 300}, {}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"2", "", "1", "", "0", "0", "", ""}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({360, 0, 120, 0, 60, 240, 0, 0}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({400, 0, 200, 0, 100, 300, 0, 0}), itr2->second);
  TEST_LIST_INT32(({4}), itr_len2->second);

  FUNC_TEST_END();
}

//user两层repeated且在source尾部为repeated字段
void test_seq_by_inter_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_by_inter" source=".user_feature.ad_context_feature.info_flow_context.info_flow_item.filter_words,.item_feature.item_feature_se.context.feature.app_id" inter_key="id" fields="name" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f6" shape="1,2,3" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqByInterConfig* conf = dynamic_cast<SeqByInterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::InfoFlowContext* pb_context = pb_ufv2->mutable_ad_context_feature()->mutable_info_flow_context();
  qinglong::InfoFlowItem* pb_info = pb_context->add_info_flow_item();

  qinglong::FilterWords* pb_word = pb_info->add_filter_words();
  pb_word->set_id("appid0");
  pb_word->set_name("0");

  pb_word = pb_info->add_filter_words();
  pb_word->set_id("appid1");
  pb_word->set_name("1");

  pb_info = pb_context->add_info_flow_item();
  pb_word = pb_info->add_filter_words();
  pb_word->set_id("appid0");
  pb_word->set_name("0");

  pb_word = pb_info->add_filter_words();
  pb_word->set_id("appid2");
  pb_word->set_name("2");

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid3");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f6");
  auto itr10 = map01.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"0", "0", "1", "2"}), itr00->second);
  TEST_FEATURE_STR(({"2"}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f6_values");
  auto itr_indices0 = map.find("f6_indices");
  auto itr_dense_shape0 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 0, 1, 0, 2, 0, 3, 1, 0}), ({2, 4}), ({"0", "0", "1", "2", "2"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

//user一层repeated且在source中间
void test_seq_by_inter_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_by_inter" source=".user_action.conv_ascribe_type.sdk_conversion,.item_feature.item_feature_se.feature_lists.feature_list.app_id" inter_key="event_time" fields="label,flag" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,2,3" type="sequence" />
        <input name="f8" shape="1,2,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqByInterConfig* conf = dynamic_cast<SeqByInterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserAction* pb_action = request.add_user_action();
  qinglong::ConvInfo* pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_event_time("appid0");
  pb_info->set_label(0);
  pb_info->set_flag(0);

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_event_time("appid1");
  pb_info->set_label(0);
  pb_info->set_flag(1);

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_event_time("appid2");
  pb_info->set_label(1);
  pb_info->set_flag(0);

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_event_time("appid3");
  pb_info->set_label(1);
  pb_info->set_flag(1);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["app_id"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");
  fate->mutable_bytes_list()->add_value("appid3");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{0, 0}, {1, 1}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{0, 1}, {0, 1}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({0, 0, 1, 1}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({0, 1, 0, 1}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  FUNC_TEST_END();
}

// inter_key为设置
void test_seq_by_inter_4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_by_inter" source=".user_action.conv_ascribe_type.sdk_conversion,.item_feature.item_feature_se.feature_lists.feature_list.app_id" inter_key="event_time" fields="label,flag" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqByInterConfig* conf = dynamic_cast<SeqByInterConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // user
  qinglong::UserAction* pb_action = request.add_user_action();
  qinglong::ConvInfo* pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_event_time("appid0");
  pb_info->set_label(0);
  pb_info->set_flag(0);

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_event_time("appid1");
  pb_info->set_label(0);
  pb_info->set_flag(1);

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_event_time("appid2");
  pb_info->set_label(1);
  pb_info->set_flag(0);

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(1);
  pb_info->set_flag(1);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["app_id"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");
  fate->mutable_bytes_list()->add_value("appid3");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{0, 0}, {1}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{0, 1}, {0}}), itr01->second);

  FUNC_TEST_END();
}

//user一层repeated且在source字段尾部
void test_seq_topn_direct_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_topn_direct" source=".user_feature.af_user_feature.gl_ad_conversion_nl_fg.app_sdk_conversion_seq_offline_nl.user_app_game_active_seq" filter_key="pay_money" fields="query,event_time" topn="3" reserve="1" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopnDirectConfig* conf = dynamic_cast<SeqTopnDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserConvSequenceEntity* pb_use = pb_ufv2->mutable_af_user_feature()->mutable_gl_ad_conversion_nl_fg()->mutable_app_sdk_conversion_seq_offline_nl();
  qinglong::UserConvSequenceInfo* pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid1");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(100);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid2");
  pb_info->set_pay_money(200);
  pb_info->set_event_time(200);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid3");
  pb_info->set_pay_money(100);
  pb_info->set_event_time(300);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid4");
  pb_info->set_pay_money(200);
  pb_info->set_event_time(400);

  pb_info = pb_use->add_user_app_game_active_seq();
  pb_info->set_query("appid5");
  pb_info->set_pay_money(200);
  pb_info->set_event_time(500);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid3"}, {"appid2"}, {"appid4"}, {"appid5"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{100}, {300}, {200}, {400}, {500}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid1", "appid3", "appid2", "appid4", "appid5"}), itr0->second);
  TEST_LIST_INT32(({5}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({100, 300, 200, 400, 500}), itr1->second);
  TEST_LIST_INT32(({5}), itr_len1->second);

  FUNC_TEST_END();
}

//user一层repeated且在source中间
void test_seq_topn_direct_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_topn_direct" source=".user_action.conv_ascribe_type.sdk_conversion" filter_key="flag" fields="label,event_time" topn="3" reserve="1" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopnDirectConfig* conf = dynamic_cast<SeqTopnDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserAction* pb_action = request.add_user_action();
  qinglong::ConvInfo* pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(20);
  pb_info->set_flag(2);
  pb_info->set_event_time("20");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(10);
  pb_info->set_flag(1);
  pb_info->set_event_time("10");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(40);
  pb_info->set_flag(4);
  pb_info->set_event_time("40");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(30);
  pb_info->set_flag(3);
  pb_info->set_event_time("30");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{10}, {20}, {30}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"10"}, {"20"}, {"30"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({10, 20, 30}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"10", "20", "30"}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

void test_seq_topn_direct_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_topn_direct" source=".item_feature.game_item_query_offline_feature.gamecenter_item_query_interact_feature" filter_key="qam_udtr15d_2" fields="qam_app_qpayavg15d_2,qam_app_qpay15d_2" topn="3" reserve="1" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqTopnDirectConfig* conf = dynamic_cast<SeqTopnDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  qinglong::GameCenterItemQueryInteractFeature* interact = item->mutable_game_item_query_offline_feature()->mutable_gamecenter_item_query_interact_feature();
  interact->set_qam_udtr15d_2(0.57);
  interact->set_qam_app_qpayavg15d_2(68.2);
  interact->set_qam_app_qpay15d_2(200);
  
  item = request.add_item_feature();
  interact = item->mutable_game_item_query_offline_feature()->mutable_gamecenter_item_query_interact_feature();
  interact->set_qam_udtr15d_2(0.33);
  interact->set_qam_app_qpayavg15d_2(92.5);
  interact->set_qam_app_qpay15d_2(300);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_FLOAT(({68.2}), itr00->second);
  TEST_FEATURE_FLOAT(({92.5}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({200}), itr01->second);
  TEST_FEATURE_INT64(({300}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0}), ({2, 1}), ({68.2, 92.5}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f8_values");
  auto itr_indices1 = map.find("f8_indices");
  auto itr_dense_shape1 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({200, 300}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_seq_day_n_direct_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_day_n_direct" source=".user_feature.game_user_online_feature.game_user_behavior_seq_feature.game_user_click_sequence_30d,.request_time" eventtime_key="event_time" fields="udid,data_source" start="5" day_n="7" clip_size="3" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDayNDirectConfig* conf = dynamic_cast<SeqDayNDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::GameUserBehaviorSequenceFeatureGroup* pb_gruop = pb_ufv2->mutable_game_user_online_feature()->mutable_game_user_behavior_seq_feature();
  qinglong::GameUserBehaviorEntity* pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid1");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)110 * 86400 * 1000 + 2000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid2");
  pb_entity->set_data_source(2);
  pb_entity->set_event_time((int64_t)108 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid3");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)106 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid4");
  pb_entity->set_data_source(2);
  pb_entity->set_event_time((int64_t)105 * 86400 * 1000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid5");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)103 * 86400 * 1000 + 2000);

  pb_entity = pb_gruop->add_game_user_click_sequence_30d();
  pb_entity->set_udid("appid6");
  pb_entity->set_data_source(1);
  pb_entity->set_event_time((int64_t)98 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}, {"appid3"}, {"appid4"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{2}, {1}, {2}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid2", "appid3", "appid4"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({2, 1, 2}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

//user一层repeated且在source中间
void test_seq_day_n_direct_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_day_n_direct" source=".user_action.conv_ascribe_type.sdk_conversion,.request_time" eventtime_key="flag" fields="label,event_time" day_n="7" clip_size="5"  />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDayNDirectConfig* conf = dynamic_cast<SeqDayNDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)10 * 86400 * 1000);

  // user
  qinglong::UserAction* pb_action = request.add_user_action();
  qinglong::ConvInfo* pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(20);
  pb_info->set_flag((int64_t)8 * 86400 * 1000);
  pb_info->set_event_time("20");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(10);
  pb_info->set_flag((int64_t)6 * 86400 * 1000);
  pb_info->set_event_time("10");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(40);
  pb_info->set_flag((int64_t)5 * 86400 * 1000);
  pb_info->set_event_time("40");

  pb_action = request.add_user_action();
  pb_info = pb_action->mutable_conv_ascribe_type()->mutable_sdk_conversion();
  pb_info->set_label(30);
  pb_info->set_flag((int64_t)2 * 86400 * 1000);
  pb_info->set_event_time("30");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{20}, {10}, {40}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_STR(({{"20"}, {"10"}, {"40"}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({20, 10, 40}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"20", "10", "40"}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  FUNC_TEST_END();
}

void test_seq_day_n_direct_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_day_n_direct" source=".item_feature.game_item_query_offline_feature.gamecenter_item_query_interact_feature,.request_time" eventtime_key="qam_app_qpay15d_2" fields="qam_udtr15d_2,qam_app_qpayavg15d_2" day_n="1" clip_size="3" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1" type="sparse" />
        <input name="f8" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqDayNDirectConfig* conf = dynamic_cast<SeqDayNDirectConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  qinglong::ItemFeature* item = request.add_item_feature();
  qinglong::GameCenterItemQueryInteractFeature* interact = item->mutable_game_item_query_offline_feature()->mutable_gamecenter_item_query_interact_feature();
  interact->set_qam_udtr15d_2(0.57);
  interact->set_qam_app_qpayavg15d_2(68.2);
  interact->set_qam_app_qpay15d_2((int64_t)110 * 86400 * 1000 - 2000);

  item = request.add_item_feature();
  interact = item->mutable_game_item_query_offline_feature()->mutable_gamecenter_item_query_interact_feature();
  interact->set_qam_udtr15d_2(0.33);
  interact->set_qam_app_qpayavg15d_2(92.5);
  interact->set_qam_app_qpay15d_2((int64_t)108 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f7");
  auto itr10 = map01.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_FLOAT(({0.57}), itr00->second);
  TEST_FEATURE_FLOAT(({}), itr10->second);

  auto itr01 = map00.find("f8");
  auto itr11 = map01.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_FLOAT(({68.2}), itr01->second);
  TEST_FEATURE_FLOAT(({}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f7_values");
  auto itr_indices0 = map.find("f7_indices");
  auto itr_dense_shape0 = map.find("f7_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0}), ({2, 1}), ({0.57}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f8_values");
  auto itr_indices1 = map.find("f8_indices");
  auto itr_dense_shape1 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0}), ({2, 1}), ({68.2}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_seq_n_hour_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_n_hour" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time" start="864000" day_n="30" hour="2" />
            <feature name="f8" type="direct" source="f7:0" />
            <feature name="f9" type="direct" source="f7:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,5" type="sequence" />
        <input name="f9" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqNHourConfig* conf = dynamic_cast<SeqNHourConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time((int64_t)105 * 86400 * 1000); //start过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time((int64_t)84 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time((int64_t)92 * 86400 * 1000 + 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time((int64_t)95 * 86400 * 1000 + 3600 * 3000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time((int64_t)99 * 86400 * 1000 - 3600 * 2000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid5");
  pb_info->set_event_time((int64_t)82 * 86400 * 1000 - 3600 * 3000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid6");
  pb_info->set_event_time((int64_t)89 * 86400 * 1000 - 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid7");
  pb_info->set_event_time((int64_t)78 * 86400 * 1000); //day_n过滤

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}, {"appid2"}, {"appid4"}, {"appid6"}}), itr00->second);

  auto itr01 = map00.find("f9");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)84 * 86400 * 1000}, {(int64_t)92 * 86400 * 1000 + 3600 * 1000}, {(int64_t)99 * 86400 * 1000 - 3600 * 2000}, {(int64_t)89 * 86400 * 1000 - 3600 * 1000}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f8");
  auto itr_len0 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid1", "appid2", "appid4", "appid6"}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f9");
  auto itr_len1 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({(int64_t)84 * 86400 * 1000, (int64_t)92 * 86400 * 1000 + 3600 * 1000, (int64_t)99 * 86400 * 1000 - 3600 * 2000, (int64_t)89 * 86400 * 1000 - 3600 * 1000}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  FUNC_TEST_END();
}

void test_seq_n_hour_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_n_hour" source=".item_feature.item_feature_se.context.feature.app_id,.item_feature.item_feature_se.context.feature.event_time,.request_time" start="864000" day_n="30" hour="2" />
            <feature name="f8" type="direct" source="f7:0" />
            <feature name="f9" type="direct" source="f7:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1" type="sparse" />
        <input name="f9" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqNHourConfig* conf = dynamic_cast<SeqNHourConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000 - 3600 * 3000);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid3");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000 + 3600 * 3000);
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid4");
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f8");
  auto itr10 = map01.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({"appid0"}), itr00->second);
  TEST_FEATURE_STR(({"appid4"}), itr10->second);

  auto itr01 = map00.find("f9");
  auto itr11 = map01.find("f9");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({(int64_t)82 * 86400 * 1000}), itr01->second);
  TEST_FEATURE_INT64(({(int64_t)95 * 86400 * 1000}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f8_values");
  auto itr_indices0 = map.find("f8_indices");
  auto itr_dense_shape0 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_STR(({0, 0, 1, 0}), ({2, 1}), ({"appid0", "appid4"}),
                          itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f9_values");
  auto itr_indices1 = map.find("f9_indices");
  auto itr_dense_shape1 = map.find("f9_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({(int64_t)82 * 86400 * 1000, (int64_t)95 * 86400 * 1000}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_seq_n_hour_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_n_hour" source=".item_feature.item_feature_se.feature_lists.feature_list.app_id,.item_feature.item_feature_se.feature_lists.feature_list.event_time,.request_time" start="864000" day_n="30" hour="2" />
            <feature name="f8" type="direct" source="f7:0" />
            <feature name="f9" type="direct" source="f7:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,5" type="sequence" />
        <input name="f9" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqNHourConfig* conf = dynamic_cast<SeqNHourConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["app_id"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid3");

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["event_time"];
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)84 * 86400 * 1000- 3600 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000 + 3600 * 2000);
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)98 * 86400 * 1000 + 3600 * 8000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map0.find("f8");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_LIST_STR(({{"appid0"},{"appid1"}}), itr00->second);

  auto itr01 = map0.find("f9");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_FEATURE_LIST_INT64(({{(int64_t)84 * 86400 * 1000- 3600 * 1000},{(int64_t)92 * 86400 * 1000 + 3600 * 2000}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_STRING(({"appid0", "appid1"}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({(int64_t)84 * 86400 * 1000- 3600 * 1000, (int64_t)92 * 86400 * 1000 + 3600 * 2000}), itr2->second);
  TEST_LIST_INT32(({2}), itr_len2->second);

  FUNC_TEST_END();
}

//合并后使用direct直接提取对应字段
void test_seq_merge_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_merge" source=".user_feature.af_user_feature.user_open_seq_off_fg.user_open_off.user_sequence,.user_feature.af_user_feature.user_open_seq_nl_fg.user_open_nl_48h.user_sequence" eventtime_key="event_time" />
            <feature name="f7" type="direct" source="f6.app_id" />
            <feature name="f8" type="direct" source="f6.event_time" />
            <feature name="f9" type="direct" source="f6.use_duration" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqMergeConfig* conf = dynamic_cast<SeqMergeConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_off_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->mutable_user_open_off();
  qinglong::UserSequenceInfo* pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time(60);
  pb_info->set_use_duration(100);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time(120);
  pb_info->set_use_duration(200);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(300);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time(360);
  pb_info->set_use_duration(400);

  qinglong::UserSequenceEntity* pb_nl_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->mutable_user_open_nl_48h();
  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(200);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid5");
  pb_info->set_event_time(420);
  pb_info->set_use_duration(100);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid6");
  pb_info->set_event_time(540);
  pb_info->set_use_duration(300);

  //item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid6"}, {"appid5"}, {"appid3"}, {"appid2"}, {"appid1"}, {"appid0"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{540}, {420}, {360}, {240}, {120}, {60}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{300}, {100}, {400}, {300}, {200}, {100}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid6", "appid5", "appid3", "appid2", "appid1", "appid0"}), itr0->second);
  TEST_LIST_INT32(({6}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({540, 420, 360, 240, 120, 60}), itr1->second);
  TEST_LIST_INT32(({6}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({300, 100, 400, 300, 200, 100}), itr2->second);
  TEST_LIST_INT32(({6}), itr_len2->second);

  FUNC_TEST_END();
}

//合并后使用seq_by_inter提取对应字段
void test_seq_merge_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f5" type="seq_merge" source=".user_feature.af_user_feature.user_open_seq_off_fg.user_open_off.user_sequence,.user_feature.af_user_feature.user_open_seq_nl_fg.user_open_nl_48h.user_sequence" eventtime_key="event_time" />
            <feature name="f6" type="seq_by_inter" source="f5,.item_feature.game_item_offline_feature.game_item_atrribute_feature.app_name" inter_key="app_id" fields="app_id,event_time,use_duration" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
            <feature name="f9" type="direct" source="f6:2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(5, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqMergeConfig* conf = dynamic_cast<SeqMergeConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_off_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->mutable_user_open_off();
  qinglong::UserSequenceInfo* pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time(60);
  pb_info->set_use_duration(100);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time(120);
  pb_info->set_use_duration(200);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(300);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time(360);
  pb_info->set_use_duration(400);

  qinglong::UserSequenceEntity* pb_nl_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->mutable_user_open_nl_48h();
  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(200);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid5");
  pb_info->set_event_time(420);
  pb_info->set_use_duration(100);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid6");
  pb_info->set_event_time(540);
  pb_info->set_use_duration(300);

  // item
  qinglong::GameItemAttributeFeature* item = request.add_item_feature()->mutable_game_item_offline_feature()->mutable_game_item_atrribute_feature();
  item->add_app_name("appid2");
  item->add_app_name("appid1");
  item->add_app_name("appid0");
  item->add_app_name("appid3");
  item->add_app_name("appid4");
  item->add_app_name("appid6");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}, {"appid1"}, {"appid0"}, {"appid3"}, {}, {"appid6"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{240}, {120}, {60}, {360}, {}, {540}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{300}, {200}, {100}, {400}, {}, {300}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid2", "appid1", "appid0", "appid3", "", "appid6"}), itr0->second);
  TEST_LIST_INT32(({6}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({240, 120, 60, 360, 0, 540}), itr1->second);
  TEST_LIST_INT32(({6}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({300, 200, 100, 400, 0, 300}), itr2->second);
  TEST_LIST_INT32(({6}), itr_len2->second);

  FUNC_TEST_END();
}

//合并后使用seq_topn_direct提取对应字段
void test_seq_merge_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f5" type="seq_merge" source=".user_feature.af_user_feature.user_open_seq_off_fg.user_open_off.user_sequence,.user_feature.af_user_feature.user_open_seq_nl_fg.user_open_nl_48h.user_sequence" eventtime_key="event_time" />
            <feature name="f6" type="seq_topn_direct" source="f5" filter_key="use_duration" fields="app_id,event_time,use_duration" topn="4" reserve="1" />
            <feature name="f7" type="direct" source="f6:0" />
            <feature name="f8" type="direct" source="f6:1" />
            <feature name="f9" type="direct" source="f6:2" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(5, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqMergeConfig* conf = dynamic_cast<SeqMergeConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_off_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->mutable_user_open_off();
  qinglong::UserSequenceInfo* pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time(60);
  pb_info->set_use_duration(100);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time(120);
  pb_info->set_use_duration(200);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(300);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time(360);
  pb_info->set_use_duration(400);

  qinglong::UserSequenceEntity* pb_nl_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->mutable_user_open_nl_48h();
  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid4");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(200);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid5");
  pb_info->set_event_time(420);
  pb_info->set_use_duration(100);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid6");
  pb_info->set_event_time(540);
  pb_info->set_use_duration(300);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid5"}, {"appid0"}, {"appid1"}, {"appid6"}, {"appid2"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{420}, {60}, {120}, {540}, {240}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{100}, {100}, {200}, {300}, {300}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid5", "appid0", "appid1", "appid6", "appid2"}), itr0->second);
  TEST_LIST_INT32(({5}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({420, 60, 120, 540, 240}), itr1->second);
  TEST_LIST_INT32(({5}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({100, 100, 200, 300, 300}), itr2->second);
  TEST_LIST_INT32(({5}), itr_len2->second);

  FUNC_TEST_END();
}

//合并空message
void test_seq_merge_4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_merge" source=".user_feature.af_user_feature.user_open_seq_off_fg.user_open_off.user_sequence,.user_feature.af_user_feature.user_open_seq_nl_fg.user_open_nl_48h.user_sequence" eventtime_key="event_time" strategy="empty" />
            <feature name="f7" type="direct" source="f6.app_id" />
            <feature name="f8" type="direct" source="f6.event_time" />
            <feature name="f9" type="direct" source="f6.use_duration" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqMergeConfig* conf = dynamic_cast<SeqMergeConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_off_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->mutable_user_open_off();
  qinglong::UserSequenceInfo* pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time(60);
  pb_info->set_use_duration(100);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time(120);
  pb_info->set_use_duration(200);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(300);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time(360);
  pb_info->set_use_duration(400);

  //近线为空
  pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->mutable_user_open_nl_48h();

  //item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid3"}, {"appid2"}, {"appid1"}, {"appid0"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{360}, {240}, {120}, {60}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{400}, {300}, {200}, {100}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid3", "appid2", "appid1", "appid0"}), itr0->second);
  TEST_LIST_INT32(({4}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({360, 240, 120, 60}), itr1->second);
  TEST_LIST_INT32(({4}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({400, 300, 200, 100}), itr2->second);
  TEST_LIST_INT32(({4}), itr_len2->second);

  FUNC_TEST_END();
}

//合并全空message
void test_seq_merge_5() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_merge" source=".user_feature.af_user_feature.user_open_seq_off_fg.user_open_off.user_sequence,.user_feature.af_user_feature.user_open_seq_nl_fg.user_open_nl_48h.user_sequence" eventtime_key="event_time" strategy="empty" />
            <feature name="f7" type="direct" source="f6.app_id" strategy="empty" />
            <feature name="f8" type="direct" source="f6.event_time" strategy="empty" />
            <feature name="f9" type="direct" source="f6.use_duration" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqMergeConfig* conf = dynamic_cast<SeqMergeConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->mutable_user_open_off();

  //近线为空
  pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->mutable_user_open_nl_48h();

  //item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({}), itr0->second);
  TEST_LIST_INT32(({0}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({}), itr1->second);
  TEST_LIST_INT32(({0}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({}), itr2->second);
  TEST_LIST_INT32(({0}), itr_len2->second);

  FUNC_TEST_END();
}

//合并后使用direct直接提取对应字段
void test_seq_merge_v2_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_merge_v2" source=".user_feature.af_user_feature.user_open_seq_off_fg.user_open_off.user_sequence,.user_feature.af_user_feature.user_open_seq_nl_fg.user_open_nl_48h.user_sequence" appid_key="app_id" eventtime_key="event_time" />
            <feature name="f7" type="direct" source="f6.app_id" />
            <feature name="f8" type="direct" source="f6.event_time" />
            <feature name="f9" type="direct" source="f6.use_duration" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqMergeV2Config* conf = dynamic_cast<SeqMergeV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_off_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->mutable_user_open_off();
  qinglong::UserSequenceInfo* pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time(60);
  pb_info->set_use_duration(100);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time(120);
  pb_info->set_use_duration(200);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(300);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid3");
  pb_info->set_event_time(360);
  pb_info->set_use_duration(400);

  qinglong::UserSequenceEntity* pb_nl_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->mutable_user_open_nl_48h();
  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(200);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid1");           //重复数据过滤
  pb_info->set_event_time(120);
  pb_info->set_use_duration(200);

  pb_info = pb_nl_use->add_user_sequence();
  pb_info->set_app_id("appid2");           //重复数据过滤
  pb_info->set_event_time(240);
  pb_info->set_use_duration(300);

  //item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid3"}, {"appid2"}, {"appid0"}, {"appid1"}, {"appid0"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{360}, {240}, {240}, {120}, {60}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{400}, {300}, {200}, {200}, {100}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid3", "appid2", "appid0", "appid1", "appid0"}), itr0->second);
  TEST_LIST_INT32(({5}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({360, 240, 240, 120, 60}), itr1->second);
  TEST_LIST_INT32(({5}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({400, 300, 200, 200, 100}), itr2->second);
  TEST_LIST_INT32(({5}), itr_len2->second);

  FUNC_TEST_END();
}

//合并空message
void test_seq_merge_v2_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_merge_v2" source=".user_feature.af_user_feature.user_open_seq_off_fg.user_open_off.user_sequence,.user_feature.af_user_feature.user_open_seq_nl_fg.user_open_nl_48h.user_sequence" appid_key="app_id" eventtime_key="event_time" strategy="empty" />
            <feature name="f7" type="direct" source="f6.app_id" />
            <feature name="f8" type="direct" source="f6.event_time" />
            <feature name="f9" type="direct" source="f6.use_duration" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f7" shape="1,1,3" type="sequence" />
        <input name="f8" shape="1,1,3" type="sequence" />
        <input name="f9" shape="1,1,3" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(4, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqMergeV2Config* conf = dynamic_cast<SeqMergeV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(3, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_off_use = pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_off_fg()->mutable_user_open_off();
  qinglong::UserSequenceInfo* pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid0");
  pb_info->set_event_time(60);
  pb_info->set_use_duration(100);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid1");
  pb_info->set_event_time(120);
  pb_info->set_use_duration(200);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(300);

  pb_info = pb_off_use->add_user_sequence();
  pb_info->set_app_id("appid2");
  pb_info->set_event_time(240);
  pb_info->set_use_duration(300);

  //近线为空
  pb_ufv2->mutable_af_user_feature()->mutable_user_open_seq_nl_fg()->mutable_user_open_nl_48h();

  //item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f7");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid2"}, {"appid1"}, {"appid0"}}), itr00->second);

  auto itr01 = map00.find("f8");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{240}, {120}, {60}}), itr01->second);

  auto itr02 = map00.find("f9");
  TEST_ASSERT_BOOL(itr02 != map00.end());
  TEST_FEATURE_LIST_INT64(({{300}, {200}, {100}}), itr02->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f7");
  auto itr_len0 = map.find("f7_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_STRING(({"appid2", "appid1", "appid0"}), itr0->second);
  TEST_LIST_INT32(({3}), itr_len0->second);

  auto itr1 = map.find("f8");
  auto itr_len1 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({240, 120, 60}), itr1->second);
  TEST_LIST_INT32(({3}), itr_len1->second);

  auto itr2 = map.find("f9");
  auto itr_len2 = map.find("f9_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({300, 200, 100}), itr2->second);
  TEST_LIST_INT32(({3}), itr_len2->second);

  FUNC_TEST_END();
}

void test_seq_interval_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_interval" source="E@.item_feature.item_feature_se.context.feature.appid,E@.item_feature.item_feature_se.context.feature.first,E@.item_feature.item_feature_se.context.feature.second,E@.item_feature.item_feature_se.context.feature.third,.request_time,.item_feature.item_feature_se.feature_lists.feature_list.app_id" day_n="30" clip_size="3" default_mean="1.1" default_interval="-1" />
            <feature name="f5" type="direct" source="f4:0" />
            <feature name="f6" type="direct" source="f4:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1,2,5" type="sequence" />
        <input name="f6" shape="1,2,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqInterval* conf = dynamic_cast<SeqInterval*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)75 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)68 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)64 * 86400 * 1000);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)98 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)87 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)74 * 86400 * 1000);

  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["app_id"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid0");
  fate->mutable_bytes_list()->add_value("appid1");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid2");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_FLOAT(({{2.0000, 1.8462}, {1.1000}}), itr00->second);

  auto itr01 = map00.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_LIST_INT64(({{1036800000, 259200000, 259200000, 1987200000, 432000000, 691200000}, {-1, -1, -1}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f5");
  auto itr_len0 = map.find("f5_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_FLOAT(({2.0000, 1.8462, 1.1000, 0}), itr0->second);
  TEST_LIST_INT32(({2}), itr_len0->second);

  auto itr1 = map.find("f6");
  auto itr_len1 = map.find("f6_length");
  TEST_ASSERT_BOOL(itr1 != map.end());
  TEST_ASSERT_BOOL(itr_len1 != map.end());
  TEST_LIST_INT64(({1036800000, 259200000, -1, -1}), itr1->second);
  TEST_LIST_INT32(({2}), itr_len1->second);

  FUNC_TEST_END();
}

void test_seq_interval_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_interval" source="E@.item_feature.item_feature_se.context.feature.appid,E@.item_feature.item_feature_se.context.feature.first,E@.item_feature.item_feature_se.context.feature.second,E@.item_feature.item_feature_se.context.feature.third,.request_time,.item_feature.item_feature_se.context.feature.app_id" day_n="30" clip_size="5" default_mean="1.1" default_interval="-1" />
            <feature name="f5" type="direct" source="f4:0" />
            <feature name="f6" type="direct" source="f4:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqInterval* conf = dynamic_cast<SeqInterval*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)75 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)68 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)64 * 86400 * 1000);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)98 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)87 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)74 * 86400 * 1000);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)86 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)0);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid3");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)87 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)87 * 86400 * 1000 - 7200 * 1000);

  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid3");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid4");

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f5");
  auto itr10 = map01.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_FLOAT(({1.8462, 2.0000, 1.1000, 184.6667, 1.1000}), itr00->second);
  TEST_FEATURE_FLOAT(({1.1000}), itr10->second);

  auto itr01 = map00.find("f6");
  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_INT64(({1987200000, 432000000, 691200000, 1036800000, 259200000, 259200000, 2073600000, -1, -1, 1987200000, 7200000, -1, -1, -1, -1}), itr01->second);
  TEST_FEATURE_INT64(({-1, -1, -1}), itr11->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 1, 0}), ({2, 5}), ({1.8462, 2.0000, 1.1000, 184.6667, 1.1000, 1.1000}),
                           itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 8, 0, 9, 0, 10, 0, 11, 0, 12, 0, 13, 0, 14, 1, 0, 1, 1, 1, 2}), ({2, 15}),
                           ({1987200000, 432000000, 691200000, 1036800000, 259200000, 259200000, 2073600000, -1, -1, 1987200000, 7200000, -1, -1, -1, -1, -1, -1, -1}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_seq_interval_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f4" type="seq_interval" source="E@.item_feature.item_feature_se.context.feature.appid,E@.item_feature.item_feature_se.context.feature.first,E@.item_feature.item_feature_se.context.feature.second,E@.item_feature.item_feature_se.context.feature.third,.request_time,.item_feature.item_feature_se.context.feature.app_id" day_n="30" clip_size="3" default_mean="1.1" default_interval="-1" />
            <feature name="f5" type="direct" source="f4:0" />
            <feature name="f6" type="direct" source="f4:1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(3, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqInterval* conf = dynamic_cast<SeqInterval*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");  //超出30天填过滤
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)75 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)68 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)64 * 86400 * 1000);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)98 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)98 * 86400 * 1000 - 3600 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)98 * 86400 * 1000 - 7200 * 1000);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)87 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)87 * 86400 * 1000 - 3600 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)87 * 86400 * 1000 - 10800 * 1000);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid3");
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)94 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)94 * 86400 * 1000 - 1800 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)94 * 86400 * 1000 - 3600 * 1000);

  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid4");  //clip截断
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["second"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["third"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);

  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid2");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid3");
  (*(item->mutable_context()->mutable_feature()))["app_id"].mutable_bytes_list()->add_value("appid4");

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();

  auto itr00 = map00.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_FLOAT(({1.1000, 96.6667, 123.3333, 256.6667, 1.1000}), itr00->second);

  auto itr01 = map00.find("f6");
  TEST_ASSERT_BOOL(itr01 != map00.end());
  TEST_FEATURE_INT64(({-1, -1, -1, 1036800000, 3600000, 3600000, 1987200000, 3600000, 7200000, 1382400000, 1800000, 1800000, -1, -1, -1}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 0, 1, 0, 2, 0, 3, 0 ,4}), ({1, 5}), ({1.1000, 96.6667, 123.3333, 256.6667, 1.1000}),
                           itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 0, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 8, 0, 9, 0, 10, 0, 11, 0, 12, 0, 13, 0, 14}), ({1, 15}),
                           ({-1, -1, -1, 1036800000, 3600000, 3600000, 1987200000, 3600000, 7200000, 1382400000, 1800000, 1800000, -1, -1, -1}),
                            itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_seq_avg_interval() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f5" type="seq_avg_interval" source="E@.item_feature.item_feature_se.context.feature.first" time_type="1" one_default_value="0" empty_default_value="-1" />
            <feature name="f6" type="seq_avg_interval" source="E@.item_feature.item_feature_se.context.feature.first" time_type="2" one_default_value="0" empty_default_value="-1" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f5" shape="1" type="sparse" />
        <input name="f6" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqAvgIntervalConfig* conf = dynamic_cast<SeqAvgIntervalConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(2, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)75 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)77 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)83 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)86 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["first"].mutable_int64_list()->add_value((int64_t)86 * 86400 * 1000);

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);
  TEST_ASSERT_EQUAL(3, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(2).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();
  const auto& map02 = batch_ret.batch(2).context().feature();

  auto itr00 = map00.find("f5");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_FLOAT(({2.7500}), itr00->second);

  auto itr10 = map00.find("f6");
  TEST_ASSERT_BOOL(itr10 != map00.end());
  TEST_FEATURE_FLOAT(({66.0000}), itr10->second);

  auto itr01 = map01.find("f5");
  TEST_ASSERT_BOOL(itr01 != map01.end());
  TEST_FEATURE_FLOAT(({0}), itr01->second);

  auto itr11 = map01.find("f6");
  TEST_ASSERT_BOOL(itr11 != map01.end());
  TEST_FEATURE_FLOAT(({0}), itr11->second);

  auto itr02 = map02.find("f5");
  TEST_ASSERT_BOOL(itr02 != map02.end());
  TEST_FEATURE_FLOAT(({-1}), itr02->second);

  auto itr12 = map02.find("f6");
  TEST_ASSERT_BOOL(itr12 != map02.end());
  TEST_FEATURE_FLOAT(({-1}), itr12->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f5_values");
  auto itr_indices0 = map.find("f5_indices");
  auto itr_dense_shape0 = map.find("f5_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0, 2, 0}), ({3, 1}), ({2.7500, 0, -1}),
                           itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  auto itr_values1 = map.find("f6_values");
  auto itr_indices1 = map.find("f6_indices");
  auto itr_dense_shape1 = map.find("f6_dense_shape");
  TEST_ASSERT_BOOL(itr_values1 != map.end());
  TEST_ASSERT_BOOL(itr_indices1 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape1 != map.end());

  TEST_SPARSE_TENSOR_FLOAT(({0, 0, 1, 0, 2, 0}), ({3, 1}), ({66.0000, 0, -1}),
                           itr_indices1->second, itr_dense_shape1->second, itr_values1->second);

  FUNC_TEST_END();
}

void test_sort() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f0" type="seq_topn" source=".item_feature.item_feature_se.context.feature.appid,.item_feature.item_feature_se.context.feature.time,.request_time" topn="10" />
            <feature name="f1" type="seq_topn" source=".item_feature.item_feature_se.context.feature.appid,.item_feature.item_feature_se.context.feature.time,.request_time" topn_type="2" topn="10" />
            <feature name="f2" type="seq_topn_v2" source=".item_feature.item_feature_se.context.feature.appid,.item_feature.item_feature_se.context.feature.time" topn_type="1" topn="10" />
            <feature name="f3" type="direct" source="f2:0" />
            <feature name="f4" type="direct" source="f2:1" />
            <feature name="f5" type="seq_topn_v2" source=".item_feature.item_feature_se.context.feature.appid,.item_feature.item_feature_se.context.feature.time" topn_type="2" topn="10" />
            <feature name="f6" type="direct" source="f5:0" />
            <feature name="f7" type="direct" source="f5:1" />
            <feature name="f8" type="seq_topn_v2" source=".item_feature.item_feature_se.context.feature.appid,.item_feature.item_feature_se.context.feature.time,.item_feature.item_feature_se.context.feature.num" topn_type="3" topn="10" />
            <feature name="f9" type="direct" source="f8:0" />
            <feature name="f10" type="direct" source="f8:1" />
        </features>
    </config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  // 请求时间
  request.set_request_time(10000);
  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("app1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("app2");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("app3");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("app4");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("app1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("app5");

  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value(300);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value(200);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value(200);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value(300);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value(200);
  (*(item->mutable_context()->mutable_feature()))["time"].mutable_int64_list()->add_value(300);

  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(1);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(2);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(2);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(2);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(2);
  (*(item->mutable_context()->mutable_feature()))["num"].mutable_int64_list()->add_value(3);

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();

  auto itr00 = map0.find("f0");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_STR(({"app1", "app4", "app5", "app2", "app3", "app1"}), itr00->second);

  auto itr01 = map0.find("f1");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_FEATURE_STR(({"app1", "app4", "app5", "app2", "app3"}), itr01->second);

  auto itr02 = map0.find("f3");
  TEST_ASSERT_BOOL(itr02 != map0.end());
  TEST_FEATURE_STR(({"app1", "app4", "app5", "app2", "app3", "app1"}), itr02->second);

  auto itr03 = map0.find("f4");
  TEST_ASSERT_BOOL(itr03 != map0.end());
  TEST_FEATURE_INT64(({300, 300, 300, 200, 200, 200}), itr03->second);

  auto itr04 = map0.find("f6");
  TEST_ASSERT_BOOL(itr04 != map0.end());
  TEST_FEATURE_STR(({"app1", "app4", "app5", "app2", "app3"}), itr04->second);

  auto itr05 = map0.find("f7");
  TEST_ASSERT_BOOL(itr05 != map0.end());
  TEST_FEATURE_INT64(({2, 1, 1, 1, 1}), itr05->second);

  auto itr06 = map0.find("f9");
  TEST_ASSERT_BOOL(itr06 != map0.end());
  TEST_FEATURE_STR(({"app1", "app5", "app4", "app2", "app3"}), itr06->second);

  auto itr07 = map0.find("f10");
  TEST_ASSERT_BOOL(itr07 != map0.end());
  TEST_FEATURE_INT64(({3, 3, 2, 2, 2}), itr07->second);

  FUNC_TEST_END();
}

void test_sort2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f0" type="seq_topn" source=".item_feature.item_feature_se.context.feature.appid,.item_feature.item_feature_se.context.feature.time,.request_time" topn_type="2" topn="5" start="5000" />
        </features>
    </config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample ret;
  qinglong::PredictRequest pre_ret;

  // 请求时间
  request.set_request_time((int64_t)1743479189926);
  // user
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  auto& map = (*(item->mutable_context()->mutable_feature()))["appid"];
  std::vector<std::string> appids = {
      "932328455", "104413943", "104415324", "103398473", "104412228",
      "104442658", "104416280", "104463039", "104414029", "104427254",
      "104472129", "104412230", "104440415", "104416963", "934390687",
      "103398473", "104415324", "104422973", "104410702", "104422869",
      "104415760", "220314342", "104450728", "104411633", "104450543",
      "104451180", "104413943", "220314342", "104416963", "104450728",
      "104450728", "104415760", "104415760", "104410702", "104410702",
      "104413405", "104439150", "104422869", "104422869", "104422923",
      "104424828", "104465103", "104415324", "104415290", "104440415",
      "104423840", "104421757", "900803566", "104462127", "900803997",
      "104416475", "104423829", "900807922", "104413643", "104465103",
      "220314342", "104476514", "104450543", "103398473", "104422869",
      "104450728", "104413943", "104440415", "104416963", "104415760",
      "104465103", "220314342", "104476514", "104450543", "103398473",
      "104422869", "104450728", "104413943", "104440415", "104416963",
      "104415760", "104421860", "104465103", "104462149", "104415478",
      "104412192", "104411805", "104422869", "104450728", "104411633",
      "104416963", "104415760", "100100341", "900806152", "900806720",
      "104407935", "103389855", "104456970", "900809484", "103388843",
      "104413968", "104415290", "104413943", "104416557", "104462149"
  };
  for (size_t i = 0; i < appids.size(); ++i) {
    map.mutable_bytes_list()->add_value(appids[i]);
  }

  auto& map2 = (*(item->mutable_context()->mutable_feature()))["time"];
  for (int32_t i = 0; i < 12; ++i) {
    map2.mutable_int64_list()->add_value((int64_t)1743340054000);
  }
  for (int32_t i = 0; i < 11; ++i) {
    map2.mutable_int64_list()->add_value((int64_t)1743236838000);
  }
  for (int32_t i = 0; i < 22; ++i) {
    map2.mutable_int64_list()->add_value((int64_t)1743065200000);
  }
  for (int32_t i = 0; i < 9; ++i) {
    map2.mutable_int64_list()->add_value((int64_t)1743065196000);
  }
  for (int32_t i = 0; i < 11; ++i) {
    map2.mutable_int64_list()->add_value((int64_t)1742971940000);
  }
  for (int32_t i = 0; i < 11; ++i) {
    map2.mutable_int64_list()->add_value((int64_t)1742971236000);
  }
  for (int32_t i = 0; i < 11; ++i) {
    map2.mutable_int64_list()->add_value((int64_t)1742971235000);
  }
  for (int32_t i = 0; i < 8; ++i) {
    map2.mutable_int64_list()->add_value((int64_t)1742971232000);
  }
  for (int32_t i = 0; i < 5; ++i) {
    map2.mutable_int64_list()->add_value((int64_t)1742877550000);
  }
  map2.mutable_int64_list()->add_value(1);

  toSequenceExample(&arena, request, vec, ret);

  TEST_ASSERT_EQUAL(1, ret.batch_size());
  TEST_ASSERT_EQUAL(true, ret.batch(0).has_context());

  const auto& map0 = ret.batch(0).context().feature();

  auto itr00 = map0.find("f0");
  TEST_ASSERT_BOOL(itr00 != map0.end());
  TEST_FEATURE_STR(({"104450728", "104415760", "104422869", "104413943", "104416963"}), itr00->second);

  FUNC_TEST_END();
}

void test_seq_filter_v2_5() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v2" source=".user_feature.am_gm_ins_off.am_ins_off.user_sequence.app_id,.user_feature.am_gm_clk_off.am_clk_off.user_sequence.app_id" strategy="empty" />
        </features>
    </config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV2Config* conf = dynamic_cast<SeqFilterV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // user_ins
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_ins_off()->mutable_am_ins_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid1");

  // user_clk
  pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  pb_info = pb_use->add_user_sequence();
  pb_info->set_app_id("appid2");

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_STR(({{"appid1"}}), itr00->second);

  qinglong::FeRequest request2;
  qinglong::BatchSequenceExample batch_ret2;

  // item不为空
  request2.add_item_feature();

  toSequenceExample(&arena, request2, vec, batch_ret2);
  TEST_ASSERT_EQUAL(1, batch_ret2.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret2.batch(0).has_feature_lists());

  const auto& map01 = batch_ret2.batch(0).feature_lists().feature_list();

  auto itr01 = map01.find("f6");
  TEST_ASSERT_BOOL(itr01 != map01.end());
  TEST_FEATURE_LIST_STR(({}), itr01->second);
  TEST_FEATURE_LIST_INT64(({}), itr01->second);

  FUNC_TEST_END();
}

void test_seq_filter_v2_6() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f6" type="seq_filter_v2" source="E@.item_feature.item_feature_se.context.feature.appid,E@.item_feature.item_feature_se.feature_lists.feature_list.appid" />
        </features>
    </config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(1, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqFilterV2Config* conf = dynamic_cast<SeqFilterV2Config*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid0");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid1");
  (*(item->mutable_context()->mutable_feature()))["appid"].mutable_bytes_list()->add_value("appid2");

  auto& feat_list = (*(item->mutable_feature_lists()->mutable_feature_list()))["appid"];
  tensorflow::Feature* fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid4");
  fate->mutable_bytes_list()->add_value("appid2");
  fate = feat_list.add_feature();
  fate->mutable_bytes_list()->add_value("appid3");

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f6");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_STR(({"appid0", "appid1"}), itr00->second);

  auto itr10 = map01.find("f6");
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_STR(({}), itr10->second);

  FUNC_TEST_END();
}

void test_seq_back_days_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_back_days" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time" start="864000"/>
            <feature name="f8" type="direct" source="f7:0" />W
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqBackDaysConfig* conf = dynamic_cast<SeqBackDaysConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)105 * 86400 * 1000); //start过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)84 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)92 * 86400 * 1000 + 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)95 * 86400 * 1000 + 3600 * 3000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)99 * 86400 * 1000 - 3600 * 2000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)82 * 86400 * 1000 - 3600 * 3000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)89 * 86400 * 1000 - 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)78 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{26}, {17}, {14}, {11}, {28}, {21}, {32}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f8");
  auto itr_len0 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({26, 17, 14, 11, 28, 21, 32}), itr0->second);
  TEST_LIST_INT32(({7}), itr_len0->second);

  FUNC_TEST_END();
}

void test_seq_back_days_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_back_days" source=".item_feature.item_feature_se.context.feature.event_time,.request_time" start="864000"/>
            <feature name="f8" type="direct" source="f7:0" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqBackDaysConfig* conf = dynamic_cast<SeqBackDaysConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000 - 3600 * 3000);
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000); //start过滤

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000 + 3600 * 3000);
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f8");
  auto itr10 = map01.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_INT64(({28, 20}), itr00->second);
  TEST_FEATURE_INT64(({24, 15}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f8_values");
  auto itr_indices0 = map.find("f8_indices");
  auto itr_dense_shape0 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());
  
  TEST_SPARSE_TENSOR_INT64(({0, 0, 0, 1, 1, 0, 1, 1}), ({2, 2}), ({28, 20, 24, 15}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_seq_back_days_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_back_days" source=".item_feature.item_feature_se.feature_lists.feature_list.event_time,.request_time"/>
            <feature name="f8" type="direct" source="f7:0" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqBackDaysConfig* conf = dynamic_cast<SeqBackDaysConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["event_time"];
  tensorflow::Feature* fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)84 * 86400 * 1000 - 3600 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000 + 3600 * 2000);
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)110 * 86400 * 1000 - 3600 * 8000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map0.find("f8");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_FEATURE_LIST_INT64(({{5},{26},{17},{0}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr2 = map.find("f8");
  auto itr_len2 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({5, 26, 17, 0}), itr2->second);
  TEST_LIST_INT32(({4}), itr_len2->second);

  FUNC_TEST_END();
}

// 输出为空
void test_seq_back_days_4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_back_days" source=".item_feature.item_feature_se.feature_lists.feature_list.event_time,.request_time" start="864000" strategy="empty" />
            <feature name="f8" type="direct" source="f7:0" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqBackDaysConfig* conf = dynamic_cast<SeqBackDaysConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["event_time"];
  tensorflow::Feature* fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000); //start过滤
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)110 * 86400 * 1000 - 3600 * 8000); //start过滤

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map0.find("f8");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_FEATURE_LIST_INT64(({}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr2 = map.find("f8");
  auto itr_len2 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({}), itr2->second);
  TEST_LIST_INT32(({0}), itr_len2->second);

  FUNC_TEST_END();
}


void test_seq_interval_days_1() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_interval_days" source=".user_feature.am_gm_clk_off.am_clk_off.user_sequence.event_time,.request_time" start="864000"/>
            <feature name="f8" type="direct" source="f7:0" />W
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqIntervalDaysConfig* conf = dynamic_cast<SeqIntervalDaysConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // user
  qinglong::UserFeature* pb_ufv2 = request.mutable_user_feature();
  qinglong::UserSequenceEntity* pb_use = pb_ufv2->mutable_am_gm_clk_off()->mutable_am_clk_off();
  qinglong::UserSequenceInfo* pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)105 * 86400 * 1000); //start过滤
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)99 * 86400 * 1000 - 3600 * 2000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)95 * 86400 * 1000 + 3600 * 3000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)92 * 86400 * 1000 + 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)89 * 86400 * 1000 - 3600 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)84 * 86400 * 1000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)82 * 86400 * 1000 - 3600 * 3000);
  pb_info = pb_use->add_user_sequence();
  pb_info->set_event_time((int64_t)78 * 86400 * 1000);

  // item不为空
  request.add_item_feature();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map00 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr00 = map00.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_FEATURE_LIST_INT64(({{3}, {3}, {3}, {4}, {2}, {3}}), itr00->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr0 = map.find("f8");
  auto itr_len0 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr0 != map.end());
  TEST_ASSERT_BOOL(itr_len0 != map.end());
  TEST_LIST_INT64(({3, 3, 3, 4, 2, 3}), itr0->second);
  TEST_LIST_INT32(({6}), itr_len0->second);

  FUNC_TEST_END();
}

void test_seq_interval_days_2() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_interval_days" source=".item_feature.item_feature_se.context.feature.event_time,.request_time" start="864000"/>
            <feature name="f8" type="direct" source="f7:0" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqIntervalDaysConfig* conf = dynamic_cast<SeqIntervalDaysConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000); //start过滤
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000 - 3600 * 3000);
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)82 * 86400 * 1000);
  

  item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)95 * 86400 * 1000);
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)85 * 86400 * 1000 + 3600 * 3000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f8");
  auto itr10 = map01.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_INT64(({7}), itr00->second);
  TEST_FEATURE_INT64(({9}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f8_values");
  auto itr_indices0 = map.find("f8_indices");
  auto itr_dense_shape0 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());
  
  TEST_SPARSE_TENSOR_INT64(({0, 0, 1, 0}), ({2, 1}), ({7, 9}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_seq_interval_days_3() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_interval_days" source=".item_feature.item_feature_se.feature_lists.feature_list.event_time,.request_time"/>
            <feature name="f8" type="direct" source="f7:0" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqIntervalDaysConfig* conf = dynamic_cast<SeqIntervalDaysConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["event_time"];
  tensorflow::Feature* fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)110 * 86400 * 1000 - 3600 * 8000);
  fate->mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000);
  fate->mutable_int64_list()->add_value((int64_t)92 * 86400 * 1000 + 3600 * 2000);
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)84 * 86400 * 1000 - 3600 * 1000);

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map0.find("f8");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_FEATURE_LIST_INT64(({{4},{12},{8}}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr2 = map.find("f8");
  auto itr_len2 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({4, 12, 8}), itr2->second);
  TEST_LIST_INT32(({3}), itr_len2->second);

  FUNC_TEST_END();
}

// 输出为空
void test_seq_interval_days_4() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_interval_days" source=".item_feature.item_feature_se.feature_lists.feature_list.event_time,.request_time" start="864000" strategy="empty" />
            <feature name="f8" type="direct" source="f7:0" strategy="empty" />
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1,1,5" type="sequence" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqIntervalDaysConfig* conf = dynamic_cast<SeqIntervalDaysConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SEQUENCE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();

  auto& feat_list2 = (*(item->mutable_feature_lists()->mutable_feature_list()))["event_time"];
  tensorflow::Feature* fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)110 * 86400 * 1000 - 3600 * 8000); //start过滤
  fate = feat_list2.add_feature();
  fate->mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000); //start过滤

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(1, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_feature_lists());

  const auto& map0 = batch_ret.batch(0).feature_lists().feature_list();

  auto itr01 = map0.find("f8");
  TEST_ASSERT_BOOL(itr01 != map0.end());
  TEST_FEATURE_LIST_INT64(({}), itr01->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr2 = map.find("f8");
  auto itr_len2 = map.find("f8_length");
  TEST_ASSERT_BOOL(itr2 != map.end());
  TEST_ASSERT_BOOL(itr_len2 != map.end());
  TEST_LIST_INT64(({}), itr2->second);
  TEST_LIST_INT32(({0}), itr_len2->second);

  FUNC_TEST_END();
}

void test_seq_interval_days_5() {
  FUNC_TEST_START();

  std::string config_str = R"(
    <config>
        <features>
            <feature name="f7" type="seq_interval_days" source=".item_feature.item_feature_se.context.feature.event_time,.request_time" start="864000" strategy="empty" />
            <feature name="f8" type="direct" source="f7:0" strategy="empty"/>
        </features>
    </config>
  )";

  std::string in_str = R"(
    <model_input_config>
        <input name="f8" shape="1" type="sparse" />
    </model_input_config>
  )";

  std::vector<std::shared_ptr<Config>> vec;
  XmlConfigMgr::parse_from_string(config_str, "", "", vec);

  TEST_ASSERT_EQUAL(2, vec.size());
  TEST_ASSERT_BOOL(nullptr != vec[0]);

  SeqIntervalDaysConfig* conf = dynamic_cast<SeqIntervalDaysConfig*>(vec[0].get());
  TEST_ASSERT_BOOL(nullptr != conf);

  std::vector<std::shared_ptr<ModelInputConfig>> in_vec;
  ModelInputMgr::parse_xml_model_input_config_from_string(in_str, in_vec);

  TEST_ASSERT_EQUAL(1, in_vec.size());
  TEST_EXPECT_EQUAL(INPUT_SPARSE, in_vec[0]->input_type);

  google::protobuf::Arena arena;
  qinglong::FeRequest request;
  qinglong::BatchSequenceExample batch_ret;
  qinglong::PredictRequest ret;

  // 请求时间
  request.set_request_time((int64_t)110 * 86400 * 1000);

  // item
  tensorflow::SequenceExample* item = request.add_item_feature()->mutable_item_feature_se();
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)105 * 86400 * 1000); //start过滤
  (*(item->mutable_context()->mutable_feature()))["event_time"].mutable_int64_list()->add_value((int64_t)90 * 86400 * 1000 - 3600 * 3000);
  

  item = request.add_item_feature()->mutable_item_feature_se();

  toSequenceExample(&arena, request, vec, batch_ret);

  TEST_ASSERT_EQUAL(2, batch_ret.batch_size());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(0).has_context());
  TEST_ASSERT_EQUAL(true, batch_ret.batch(1).has_context());

  const auto& map00 = batch_ret.batch(0).context().feature();
  const auto& map01 = batch_ret.batch(1).context().feature();

  auto itr00 = map00.find("f8");
  auto itr10 = map01.find("f8");
  TEST_ASSERT_BOOL(itr00 != map00.end());
  TEST_ASSERT_BOOL(itr10 != map01.end());
  TEST_FEATURE_INT64(({}), itr00->second);
  TEST_FEATURE_INT64(({}), itr10->second);

  std::vector<std::shared_ptr<Config>> need_vec;
  selectConfigUsingModelInput(vec, in_vec, need_vec);
  toPredictRequest(&arena, request, need_vec, in_vec, ret);

  auto& map = ret.inputs();

  auto itr_values0 = map.find("f8_values");
  auto itr_indices0 = map.find("f8_indices");
  auto itr_dense_shape0 = map.find("f8_dense_shape");
  TEST_ASSERT_BOOL(itr_values0 != map.end());
  TEST_ASSERT_BOOL(itr_indices0 != map.end());
  TEST_ASSERT_BOOL(itr_dense_shape0 != map.end());
  
  TEST_SPARSE_TENSOR_INT64(({}), ({2, 0}), ({}),
                            itr_indices0->second, itr_dense_shape0->second, itr_values0->second);

  FUNC_TEST_END();
}

void test_seq() {
  test_seq_topn_1();
  test_seq_topn_2();
  test_seq_topn_3();

  test_seq_topn_v2_1();
  test_seq_topn_v2_2();
  test_seq_topn_v2_3();
  test_seq_topn_v2_4();
  test_seq_topn_v2_base<int64_t>({"1", "2", "3", "3"}, {10, 20, 30, 40}, true, {1, 2, 0, 2}, {"3", "2"}, {2, 2}, 1, 3, 0);
  test_seq_topn_v2_base<float>({"1", "2", "3", "3"}, {10, 20, 30, 40}, true, {1.0, 2.1, 0.6, 2.7}, {"3", "2", "1"}, {3.3, 2.1, 1.0}, 0, 3, 0);

  test_seq_appcategory_topn_1();
  test_seq_appcategory_topn_2();
  test_seq_appcategory_topn_3();

  test_to_predict_request_v3_1();
  test_to_predict_request_v3_2();
  test_to_predict_request_v3_3();

  test_request_empty_1();
  test_request_empty_2();

  test_seq_n_1();
  test_seq_n_2();
  test_seq_n_3();

  test_seq_n_v2_1();
  test_seq_n_v2_2();
  test_seq_n_v2_3();

  test_seq_hit_1();
  test_seq_hit_2();
  test_seq_hit_3();

  test_seq_hit_value_1();
  test_seq_hit_value_2();
  test_seq_hit_value_3();

  test_seq_hit_num_1();
  test_seq_hit_num_2();
  test_seq_hit_num_3();
  
  test_seq_hit_duration_1();
  test_seq_hit_duration_2();
  test_seq_hit_duration_3();

  test_seq_hit_list_1();
  test_seq_hit_list_2();
  test_seq_hit_list_3();
  test_seq_hit_list_base<int64_t>({"1", "", "3", "4"}, {20, 0, 7, 20}, {"1"}, {"1"}, {20});
  test_seq_hit_list_base<float>({"1", "", "3", "4"}, {0.2, 3.1, 2.0, 1.1}, {""}, {""}, {3.1});
  test_seq_hit_list_base<std::string>({"1", "", "3", "4"}, {"a", "b", "c", "d"}, {"6"}, {}, {});

  test_seq_hit_or_not_1();
  test_seq_hit_or_not_2();
  test_seq_hit_or_not_3();

  test_no_date();
  test_no_date_2();
  test_no_date_3();
  test_no_date_4();

  test_cross2_1();
  test_cross2_2();
  test_cross2_3();
  test_cross2_4();

  test_stat_ctr_and_stat_ctr_bucket_1();
  test_stat_ctr_and_stat_ctr_bucket_2();
  test_stat_ctr_bucket_1();
  test_stat_ctr_bucket_2();

  test_seq_app2category_1();
  test_seq_app2category_2();
  test_seq_app2category_3();
  test_seq_app2category_4();
  test_seq_app2category_5();

  test_seq_filter_1();
  test_seq_filter_2();
  test_seq_filter_3();
  test_seq_filter_4();

  test_seq_filter_v2_1();
  test_seq_filter_v2_2();
  test_seq_filter_v2_3();
  test_seq_filter_v2_4();
  test_seq_filter_v2_5();
  test_seq_filter_v2_6();

  test_seq_filter_v3_1();
  test_seq_filter_v3_2();

  test_seq_diff_1();
  test_seq_diff_2();
  test_seq_diff_3();

  test_seq_diff_v2_1();
  test_seq_diff_v2_2();
  test_seq_diff_v2_3();

  test_seq_interest_1();
  test_seq_interest_2();
  test_seq_interest_3();
  test_seq_interest_4();

  test_seq_fresh_1();
  test_seq_fresh_2();
  test_seq_fresh_3();

  test_seq_dsp_1();
  test_seq_dsp_2();
  test_seq_dsp_3();

  test_seq_num_convert_1();
  test_seq_num_convert_2();
  test_seq_num_convert_3();
  test_seq_num_convert_base({"1", "2", "3"}, {"1", "2", "3"}, {1, 1, 1}, 0);
  test_seq_num_convert_base({"视频", "视频", "小说"}, {"小说", "视频"}, {1, 2}, 0);
  test_seq_num_convert_base({"视频", "视频", "小说"}, {"小说", "视频"}, {33, 66}, 1);
  test_seq_num_convert_base({}, {}, {}, 1);
  test_seq_num_convert_base({"2"}, {"2"}, {100}, 1);

  test_seq_val_direct_1();
  test_seq_val_direct_2();
  test_seq_val_direct_3();
  test_seq_val_direct_4();
  test_seq_val_direct_5();
  test_seq_val_direct_base<float>(1000000, {"1", "2", "3"}, {995000, 993000, 991000}, true, {1.0, 3.0, 2.0}, {"2", "3"}, {993000, 991000}, {3.0, 2.0}, 5);
  test_seq_val_direct_base<float>(1000000, {"1", "2", "3"}, {995000, 993000, 991000}, false, {}, {"1", "2", "3"}, {995000, 993000, 991000}, {});
  test_seq_val_direct_base<float>(1000000, {"1", "2", "3"}, {995000, 993000, 991000}, true, {1.0, 3.0, 2.0}, {"3"}, {991000}, {2.0}, 5, -1, -1, 2.0);
  test_seq_val_direct_base<float>(1000000, {"1", "2", "3"}, {995000, 993000, 991000}, false, {}, {"2", "3"}, {993000, 991000}, {}, 5, -1, -1, 2.0);
  test_seq_val_direct_base<float>(1000000, {"1", "2", "3", "4"}, {995000, 993000, 991000, 990000}, true, {1.0, 3.0, 2.0, 2.0}, {}, {}, {}, 5, -1, 1, 1.5);
  test_seq_val_direct_base<float>(1000000, {"1", "2", "3", "4"}, {995000, 993000, 991000, 994000}, true, {1.0, 3.0, 2.0, 2.0}, {"2", "3"}, {993000, 991000}, {3.0, 2.0}, 5, -1, 2);
  test_seq_val_direct_base<std::string>(1000000, {"1", "2", "3", "4"}, {995000, 993000, 991000, 994000}, true, {"a", "b", "c", "d"}, {"2", "3", "4"}, {993000, 991000, 994000}, {"b", "c", "d"}, 5);
  test_seq_val_direct_base<std::string>(86407000, {"1", "2", "3", "4"}, {10000, 7000, 2000, 3000}, true, {"a", "b", "c", "d"}, {"1"}, {10000}, {"a"}, 5, 1);
  test_seq_val_direct_base<std::string>(86407000, {"1", "2", "3", "4"}, {10000, 86402000, 7000, 20000}, true, {"a", "b", "c", "d"}, {"1"}, {10000}, {"a"}, 5, 1, 1, 1.5);
  test_seq_val_direct_base<float>(86407000, {"1", "2", "3", "4"}, {10000, 86402000, 7000, 20000}, true, {1.5, 1.0, 3.0, 1.6}, {"1"}, {10000}, {1.5}, 5, 1, 1, 1.5);
  test_seq_val_direct_base<int64_t>(86407000, {"1", "2", "3", "4"}, {10000, 86402000, 7000, 20000}, true, {1, 1, 3, 2}, {"1"}, {10000}, {1}, 5, 1, 1, 1.5);
  test_seq_val_direct_base<int64_t>(86407000, {"1", "2", "3", "4"}, {20000, 86402000, 7000, 20000}, true, {1, 1, 3, 0}, {"1"}, {20000}, {1}, 5, 1, 1, 1.5);

  test_seq_by_inter_1();
  test_seq_by_inter_2();
  test_seq_by_inter_3();
  test_seq_by_inter_4();

  test_seq_topn_direct_1();
  test_seq_topn_direct_2();
  test_seq_topn_direct_3();

  test_seq_day_n_direct_1();
  test_seq_day_n_direct_2();
  test_seq_day_n_direct_3();

  test_seq_n_hour_1();
  test_seq_n_hour_2();
  test_seq_n_hour_3();

  test_seq_merge_1();
  test_seq_merge_2();
  test_seq_merge_3();
  test_seq_merge_4();
  test_seq_merge_5();

  test_seq_merge_v2_1();
  test_seq_merge_v2_2();

  test_seq_max_value_1();
  test_seq_max_value_2();

  test_seq_interval_1();
  test_seq_interval_2();
  test_seq_interval_3();

  test_seq_avg_interval();

  test_seq_back_days_1();
  test_seq_back_days_2();
  test_seq_back_days_3();
  test_seq_back_days_4();

  test_seq_interval_days_1();
  test_seq_interval_days_2();
  test_seq_interval_days_3();
  test_seq_interval_days_4();
  test_seq_interval_days_5();

  test_sort();
  test_sort2();
}