
#include "phx-fe/config_mgr/xml_config_mgr.h"
#include "phx-fe/decode/base64.h"
#include "phx-fe/decode/decode.h"
#include "dict/item_info_dict.pb.h"
#include "fe_request.pb.h"
#include "feature_extractor.pb.h"
#include "phx-fe/src/framework.h"
#include "phx-fe/src/service.h"
#include "phx-fe/util/log.h"
#include "phx-fe/util/pb_utils.h"
#include "phx-fe/util/printer.h"
#include "phx-fe/util/util.h"
#include <fstream>
#include <google/protobuf/util/json_util.h>
#include <iostream>
#include <sstream>
#include <string>

void test_pre_connect_to_string_1() {
    std::string config_str = R"(
        <versions>
        <version name="union_ctr" dict="appInfo,adunit_info_ctr" value="10811,10812" />
        </versions>
        <config>
            <features>
                <feature name="10811" slot="10811" type="pre_connect_to_string" source=".fe_request.ad_user_query_seq_offline.user_query_seq.query" connector="_" prefixs="p" />
                <feature name="10812" slot="10812" type="pre_connect_to_string" source=".fe_request.ad_user_query_seq_offline.user_query_seq.query,.fe_request.item_fea.item_info.creative_id" connector="_" prefixs="p,c" />
            </features>
        </config>
  )";

    init_xml_offline_by_content(config_str.c_str(), "", "union_ctr");

    google::protobuf::Arena arena;
    phx::FeRequest& fe_request = *google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);

    ::phx::AdUserQuerySeq* pb_use = fe_request.mutable_ad_user_query_seq_offline();
    ::phx::AdUserQueryInfo* pb_info = pb_use->add_user_query_seq();

    pb_info->set_query("app01");

    pb_info = pb_use->add_user_query_seq();
    pb_info->set_query("app02");

    pb_info = pb_use->add_user_query_seq();
    pb_info->set_query("app03");

    pb_info = pb_use->add_user_query_seq();
    pb_info->set_query("app04");

    auto *item_fea = fe_request.add_item_fea();
    item_fea->mutable_item_info()->set_creative_id(12);
    item_fea = fe_request.add_item_fea();
    item_fea->mutable_item_info()->set_creative_id(23);
    item_fea = fe_request.add_item_fea();

    mocker::FillProto(fe_request);
    debug::SavePbToFile("phx_ferequest.json", fe_request);
    ConfigInfo config_info;
    init_xml_offline_by_content(config_str.c_str(), "", "union_ctr");

    auto fe_request_str = fe_request.SerializeAsString();
    auto ret_str = to_training_sample(fe_request_str.c_str(), fe_request_str.size());
    phx::BatchTrainingSample ret{};
    ret.ParseFromArray(ret_str.c_str(), ret_str.size());
    std::cout << "ret = " << debug::printer::ToJsonObject(ret) << std::endl;
}

int main() {
  test_pre_connect_to_string_1();
}