#include "phx-fe/decode/base64.h"
#include "phx-fe/util/mock_utils.h"
#include <google/protobuf/util/json_util.h>
#include "fe_request.pb.h"
#include <iostream>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        std::cerr << "Usage " << argv[0] << " <fe_request>" << std::endl;
        return -1;
    }

    const std::string fe_request_path(argv[1]);

    google::protobuf::Arena arena;
    auto fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(&arena);
    google::protobuf::util::JsonStringToMessage(Calc::read_file_to_string(fe_request_path), fe_request);

    const auto index = fe_request_path.find_last_of('.');
    if (index != std::string::npos) {
        std::ofstream fe_bin(fe_request_path.substr(0, index) + ".bin");
        fe_bin << base64_encode(fe_request->SerializeAsString());
    } else {
        std::cerr << "base64_encode error" << std::endl;
    }

    return 0;
}