#ifndef TEST_H
#define TEST_H
#include "phx-fe/src/service.h"
#include "phx-fe/src/framework.h"
#include "phx-fe/config_mgr/json_config_mgr.h"
#include "phx-fe/config_mgr/xml_config_mgr.h"
#include "phx-fe/src/model_input_config.h"
#include "phx-fe/decode/decode.h"

#include <google/protobuf/arena.h>
#include <google/protobuf/util/message_differencer.h>

#include <iomanip>
#include <atomic>
#include <cassert>
#include <chrono>
#include <condition_variable>
#include <fstream>
#include <iostream>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>
#include <type_traits>
#include <cmath>

extern int g_total;
extern int g_success;

#define FUNC_TEST_START() std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ -------------- START -------------- ]" << std::endl
#define FUNC_TEST_END()   std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ -------------- END -------------- ]" << std::endl

#define TEST_EXPECT_BOOL(c) { \
  g_total++; \
  if (!(c)) { \
    std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ERROR]" << std::endl; \
  } else { \
    g_success++; \
  } \
}

#define TEST_ASSERT_BOOL(c) { \
  g_total++; \
  if (!(c)) { \
    std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ERROR]" << std::endl; \
    std::cout << "[ERROR] exit" << std::endl; \
    return; \
  } else { \
    g_success++; \
  } \
}

// 泛型版本，排除浮点数和字符串类型
template<typename T1, typename T2, typename std::enable_if<!std::is_floating_point<T1>::value && !std::is_same<T2, std::string>::value, bool>::type = true>
inline bool TEST_IS_EQUAL(const T1& t1, const T2& t2) {
  //std::cout << "in T1 T2" << std::endl;
  return t1 == t2;
}

// 浮点数重载版本
template<typename T1, typename T2, typename std::enable_if<std::is_floating_point<T1>::value && std::is_floating_point<T2>::value, bool>::type = true>
inline bool TEST_IS_EQUAL(const T1& t1, const T2& t2) {
  //std::cout << "in float" << std::endl;
  return std::abs(t1 - t2) <= 1e-5;
}

// 字符串重载版本
inline bool TEST_IS_EQUAL(const std::string& s1, const std::string& s2) {
  //std::cout << "in string" << std::endl;
  return s1 == s2;
}

#define TEST_EXPECT_EQUAL(c1, c2) { \
  g_total++; \
  if (!TEST_IS_EQUAL((c1), (c2))) { \
    std::cout << std::fixed << std::setprecision(4); \
    std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ERROR]" << #c1"=" << (c1) << " "#c2"=" << (c2) << std::endl; \
  } else { \
    g_success++; \
  } \
}

#define TEST_ASSERT_EQUAL(c1, c2) { \
  g_total++; \
  if (!TEST_IS_EQUAL((c1), (c2))) { \
    std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ERROR]" << #c1"=" << (c1) << " "#c2"=" << (c2) << std::endl; \
    std::cout << "[ERROR] exit" << std::endl; \
    return; \
  } else { \
    g_success++; \
  } \
}

#define TEST_LIST(type_value, type_pb, vec, list) { \
  std::vector<type_value> _test_values = std::vector<type_value>vec; \
  TEST_ASSERT_EQUAL(_test_values.size(), list.type_pb##_val_size()); \
  for(uint32_t i = 0; i < _test_values.size(); i++) { \
    TEST_EXPECT_EQUAL(_test_values[i], list.type_pb##_val(i)); \
  } \
} 

#define TEST_LIST_INT64(vec, list) \
  TEST_LIST(int64_t, int64, vec, list)

#define TEST_LIST_INT32(vec, list) \
  TEST_LIST(int, int, vec, list)

#define TEST_LIST_FLOAT(vec, list) \
  TEST_LIST(float, float, vec, list)

#define TEST_LIST_STRING(vec, list) \
  TEST_LIST(std::string, string, vec, list)

#define TEST_SPARSE_TENSOR(type_value, type_pb, vec_indices, vec_dense_shape, vec_values, out_indices, out_dense_shape, out_values) { \
  std::vector<int64_t> _test_v_indices = std::vector<int64_t>vec_indices; \
  std::vector<int64_t> _test_v_dense_shape = std::vector<int64_t>vec_dense_shape; \
  std::vector<type_value> _test_v_values = std::vector<type_value>vec_values; \
  \
  TEST_ASSERT_EQUAL(_test_v_indices.size(), _test_v_values.size() * 2);\
  \
  TEST_ASSERT_EQUAL(_test_v_indices.size(), out_indices.int64_val_size()); \
  TEST_ASSERT_EQUAL(_test_v_dense_shape.size(), out_dense_shape.int64_val_size()); \
  TEST_ASSERT_EQUAL(_test_v_values.size(), out_values.type_pb##_val_size()); \
  \
  for(uint32_t i = 0; i < _test_v_indices.size(); i++) { \
    TEST_EXPECT_EQUAL(_test_v_indices[i], out_indices.int64_val(i)); \
  } \
  for(uint32_t i = 0; i < _test_v_dense_shape.size(); i++) { \
    TEST_EXPECT_EQUAL(_test_v_dense_shape[i], out_dense_shape.int64_val(i)); \
  } \
  for(uint32_t i = 0; i < _test_v_values.size(); i++) { \
    TEST_EXPECT_EQUAL(_test_v_values[i], out_values.type_pb##_val(i)); \
  } \
}

#define TEST_SPARSE_TENSOR_STR(vec_indices, vec_dense_shape, vec_values, out_indices, out_dense_shape, out_values) \
  TEST_SPARSE_TENSOR(std::string, string, vec_indices, vec_dense_shape, vec_values, out_indices, out_dense_shape, out_values)

#define TEST_SPARSE_TENSOR_FLOAT(vec_indices, vec_dense_shape, vec_values, out_indices, out_dense_shape, out_values) \
  TEST_SPARSE_TENSOR(float, float, vec_indices, vec_dense_shape, vec_values, out_indices, out_dense_shape, out_values)

#define TEST_SPARSE_TENSOR_INT64(vec_indices, vec_dense_shape, vec_values, out_indices, out_dense_shape, out_values) \
  TEST_SPARSE_TENSOR(int64_t, int64, vec_indices, vec_dense_shape, vec_values, out_indices, out_dense_shape, out_values)

#define TEST_FEATURE_LIST(type_value, type_pb, double_vec, list) { \
  std::vector<std::vector<type_value>> _test_v_ = std::vector<std::vector<type_value>>double_vec; \
  TEST_ASSERT_EQUAL(_test_v_.size(), list.feature_size()); \
  \
  for(uint32_t i = 0; i < _test_v_.size(); i++) { \
    TEST_ASSERT_EQUAL(_test_v_[i].size(), list.feature(i).type_pb##_list().value_size()); \
    \
    for(uint32_t j = 0; j < _test_v_[i].size(); j++) { \
      TEST_EXPECT_EQUAL(_test_v_[i][j], list.feature(i).type_pb##_list().value(j)); \
    } \
  } \
}

#define TEST_FEATURE_LIST_STR(double_vec, list) \
  TEST_FEATURE_LIST(std::string, bytes, double_vec, list)

#define TEST_FEATURE_LIST_FLOAT(double_vec, list) \
  TEST_FEATURE_LIST(float, float, double_vec, list)

#define TEST_FEATURE_LIST_INT64(double_vec, list) \
  TEST_FEATURE_LIST(int64_t, int64, double_vec, list)

#define TEST_FEATURE(type_value, type_pb, vec, feature) { \
  std::vector<type_value> _test_v_ = std::vector<type_value>vec; \
  TEST_ASSERT_EQUAL(_test_v_.size(), feature.type_pb##_list().value_size()); \
  \
  for(uint32_t i = 0; i < _test_v_.size(); i++) { \
    TEST_EXPECT_EQUAL(_test_v_[i], feature.type_pb##_list().value(i)); \
  } \
}

#define TEST_FEATURE_STR(vec, feature) \
  TEST_FEATURE(std::string, bytes, vec, feature)

#define TEST_FEATURE_FLOAT(vec, feature) \
  TEST_FEATURE(float, float, vec, feature)

#define TEST_FEATURE_INT64(vec, feature) \
  TEST_FEATURE(int64_t, int64, vec, feature)

template<typename T, typename std::enable_if<std::is_floating_point<T>::value, bool>::type = true>
void fill_map_data(google::protobuf::Map<std::basic_string<char>, tensorflow::Feature>& map, const std::vector<T> list_value, const std::string& name) {
  for (uint32_t i = 0; i < list_value.size(); i++) {
    map[name].mutable_float_list()->add_value(list_value[i]);
  }
}

template<typename T, typename std::enable_if<std::is_same<T, int64_t>::value, bool>::type = true>
void fill_map_data(google::protobuf::Map<std::basic_string<char>, tensorflow::Feature>& map, const std::vector<T> list_value, const std::string& name) {
  for (uint32_t i = 0; i < list_value.size(); i++) {
    map[name].mutable_int64_list()->add_value(list_value[i]);
  }
}

template<typename T, typename std::enable_if<std::is_same<T, std::string>::value, bool>::type = true>
void fill_map_data(google::protobuf::Map<std::basic_string<char>, tensorflow::Feature>& map, const std::vector<T> list_value, const std::string& name) {
  for (uint32_t i = 0; i < list_value.size(); i++) {
    map[name].mutable_bytes_list()->add_value(list_value[i]);
  }
}

template<typename T, typename std::enable_if<std::is_floating_point<T>::value, bool>::type = true>
void feature_equal(const std::vector<T> out_value, const tensorflow::Feature& feature) {
  TEST_FEATURE_FLOAT({out_value}, feature);
}

template<typename T, typename std::enable_if<std::is_same<T, int64_t>::value, bool>::type = true>
void feature_equal(const std::vector<T> out_value, const tensorflow::Feature& feature) {
  TEST_FEATURE_INT64({out_value}, feature);
}

template<typename T, typename std::enable_if<std::is_same<T, std::string>::value, bool>::type = true>
void feature_equal(const std::vector<T> out_value, const tensorflow::Feature& feature) {
  TEST_FEATURE_STR({out_value}, feature);
}

inline void to_predict_request_v3(const std::vector<std::shared_ptr<Config>>& configs, const std::vector<std::shared_ptr<ModelInputConfig>>& model_inputs,
                                  google::protobuf::Arena* arena, qinglong::FeRequest* fe_request, qinglong::PredictRequest* predict_request,
                                  int32_t item_start_index = -1, int32_t item_end_index = -1) {
  FeatureExtractorObject fe_object(*fe_request);
  to_predict_request_v3(configs, model_inputs, arena, fe_object, predict_request, item_start_index, item_end_index);
}

inline void toSequenceExample(google::protobuf::Arena* arena,
                              qinglong::FeRequest& request,
                              const std::vector<std::shared_ptr<Config>>& configs,
                              qinglong::BatchSequenceExample& ret) {
  auto* arena_fe_request = google::protobuf::Arena::CreateMessage<qinglong::FeRequest>(arena);
  auto* arena_result_bse =  google::protobuf::Arena::CreateMessage<qinglong::BatchSequenceExample>(arena);
  arena_fe_request->CopyFrom(request);
  FeatureExtractorObject fe_object(*arena_fe_request);
  ConfigInfo config_info(configs, {}, "", "");
  toSequenceExample(arena, fe_object, config_info, *arena_result_bse);
  ret.CopyFrom(*arena_result_bse);
}

inline void toPredictRequest(google::protobuf::Arena* arena,
                              qinglong::FeRequest& request,
                              const std::vector<std::shared_ptr<Config>>& fe_configs,
                              const std::vector<std::shared_ptr<ModelInputConfig>>& mi_configs,
                              qinglong::PredictRequest& pr,
                              int32_t item_start_index = -1,
                              int32_t item_end_index = -1) {
  FeatureExtractorObject fe_object(request);
  ConfigInfo config_info(fe_configs, mi_configs, "", "");
  toPredictRequest(arena, fe_object, config_info, pr, item_start_index, item_end_index);
}

void test_base();
void test_seq();
void test_time();
void test_utf8();
void test_gather();
void test_plus();

#endif  // TEST_H