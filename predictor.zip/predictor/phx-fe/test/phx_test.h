
#ifndef PHX_TEST_H
#define PHX_TEST_H

#ifndef USE_UT_FRAMEWORK
#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#endif
#include "doctest.h"
#include <cstdint>
#include <string>
#include <memory>
#include <iostream>
#include <sstream>
#include <fstream>
#include <google/protobuf/util/json_util.h>

#include "phx-fe/config_mgr/xml_config_mgr.h"
#include "dict/item_info_dict.pb.h"
#include "fe_request.pb.h"
#include "feature_extractor.pb.h"
#include "phx-fe/src/framework.h"
#include "phx-fe/src/service.h"
#include "phx-fe/decode/base64.h"
#include <iterator>

#define CMP_EQ(a, b) CHECK_EQ(a, b)
#define CMP_APPROX(a, b) CHECK(a == doctest::Approx(b))
#define ORIGIN(slot, value) value
#define HASH(slot, value) \
    ([&]() -> int64_t { \
        int64_t out = 0; \
        murmur_hash(value, out); \
        return out; \
    }())
#define HASH_SLOT(slot, value) \
    ([&]() -> int64_t { \
        int64_t out = 0; \
        murmur_hash(value, out); \
        out &= 0x00FFFFFFFFFFFF; \
        out |= (static_cast<uint64_t>(slot) << 48); \
        return out; \
    }())
#define SLOT(slot, value) \
    ([&]() -> int64_t { \
        value &= 0x00FFFFFFFFFFFF; \
        value |= (static_cast<uint64_t>(slot) << 48); \
        return value; \
    }())

#define TEST_FEATURE(type_value, type_pb, vec, feature, CMP, TRAN) { \
  std::vector<type_value> _test_v_ = std::vector<type_value>vec; \
  REQUIRE_EQ(_test_v_.size(), feature.type_pb##_size()); \
  \
  for(uint32_t i = 0; i < _test_v_.size(); i++) { \
    CHECK_EQ(TRAN(slot, _test_v_[i]), feature.type_pb(i)); \
  } \
}

#define TEST_FEATURE_STR(vec, feature) \
  TEST_FEATURE(std::string, bytes_list, vec, feature, CMP_EQ, ORIGIN)

#define TEST_FEATURE_FLOAT(vec, feature) \
  TEST_FEATURE(float, weights, vec, feature, CMP_APPROX, ORIGIN)

#define TEST_FEATURE_INT64(vec, feature) \
  TEST_FEATURE(int64_t, signs, vec, feature, CMP_EQ, ORIGIN)

#define TEST_SLOT_FEATURE(slot, type_value, type_pb, vec, feature, CMP, TRAN) { \
  CHECK_EQ(slot, feature.slot_id()); \
  std::vector<type_value> _test_v_ = std::vector<type_value>vec; \
  REQUIRE_EQ(_test_v_.size(), feature.type_pb##_size()); \
  \
  for(uint32_t i = 0; i < _test_v_.size(); i++) { \
    CMP(TRAN(slot, _test_v_[i]), feature.type_pb(i)); \
  } \
}

#define TEST_SLOT_FEATURE_STR(slot, vec, feature) \
  TEST_SLOT_FEATURE(slot, std::string, bytes_list, vec, feature, CMP_EQ, ORIGIN)

#define TEST_SLOT_FEATURE_FLOAT(slot, vec, feature) \
  TEST_SLOT_FEATURE(slot, float, weights, vec, feature, CMP_APPROX, ORIGIN)

#define TEST_SLOT_FEATURE_INT64(slot, vec, feature) \
  TEST_SLOT_FEATURE(slot, int64_t, signs, vec, feature, CMP_EQ, ORIGIN)

#define TEST_HASH_SLOT_FEATURE_INT64(slot, vec, feature) \
  TEST_SLOT_FEATURE(slot, int64_t, signs, vec, feature, CMP_EQ, HASH_SLOT)

#define TEST_HASH_SLOT_FEATURE_STR(slot, vec, feature) \
  TEST_SLOT_FEATURE(slot, std::string, signs, vec, feature, CMP_EQ, HASH_SLOT)

#define TEST_ONLY_SLOT_FEATURE_INT64(slot, vec, feature) \
  TEST_SLOT_FEATURE(slot, int64_t, signs, vec, feature, CMP_EQ, SLOT)

#define TEST_BATCH_SLOT_FEATURES(slot_idx, slot, type_value, type_pb, double_vec, features, CMP, TRAN) { \
  std::vector<std::vector<type_value>> _test_double_v_ = std::vector<std::vector<type_value>>double_vec; \
  uint32_t batch_size = _test_double_v_.size(); \
  REQUIRE(features.size() >= (slot_idx + 1) * batch_size); \
  for (uint32_t idx = 0; idx < batch_size; idx++) { \
    TEST_SLOT_FEATURE(slot, type_value, type_pb, (_test_double_v_[idx]), features.at(slot_idx * batch_size + idx), CMP, TRAN);\
  } \
}

#define TEST_BATCH_SLOT_FEATURES_STR(slot_idx, slot, double_vec, features) \
  TEST_BATCH_SLOT_FEATURES(slot_idx, slot, std::string, bytes_list, double_vec, features, CMP_EQ, ORIGIN)

#define TEST_BATCH_SLOT_FEATURES_FLOAT(slot_idx, slot, double_vec, features) \
  TEST_BATCH_SLOT_FEATURES(slot_idx, slot, float, weights, double_vec, features, CMP_APPROX, ORIGIN)

#define TEST_BATCH_SLOT_FEATURES_INT64(slot_idx, slot, double_vec, features) \
  TEST_BATCH_SLOT_FEATURES(slot_idx, slot, int64_t, signs, double_vec, features, CMP_EQ, ORIGIN)

#define TEST_BATCH_HASH_SLOT_FEATURES_INT64(slot_idx, slot, double_vec, features) \
  TEST_BATCH_SLOT_FEATURES(slot_idx, slot, int64_t, signs, double_vec, features, CMP_EQ, HASH_SLOT)

#define TEST_BATCH_HASH_SLOT_FEATURES_STR(slot_idx, slot, double_vec, features) \
  TEST_BATCH_SLOT_FEATURES(slot_idx, slot, std::string, signs, double_vec, features, CMP_EQ, HASH_SLOT)

#define TEST_BATCH_ONLY_SLOT_FEATURE_INT64(slot_idx, slot, double_vec, features) \
  TEST_BATCH_SLOT_FEATURES(slot_idx, slot, int64_t, signs, double_vec, features, CMP_EQ, SLOT)

#define TEST_EXTRA_FEATURE(feature_name, type_value, type_pb, vec, extra_feature, CMP, TRAN) { \
  CHECK_EQ(feature_name, extra_feature.name()); \
  std::vector<type_value> _test_v_ = std::vector<type_value>vec; \
  REQUIRE_EQ(_test_v_.size(), extra_feature.feature().type_pb##_size()); \
  \
  for(uint32_t i = 0; i < _test_v_.size(); i++) { \
    CMP(TRAN(slot, _test_v_[i]), extra_feature.feature().type_pb(i)); \
  } \
}

#define TEST_EXTRA_FEATURE_STR(feature_name, vec, feature) \
  TEST_EXTRA_FEATURE(feature_name, std::string, bytes_list, vec, feature, CMP_EQ, ORIGIN)

#define TEST_EXTRA_FEATURE_FLOAT(feature_name, vec, feature) \
  TEST_EXTRA_FEATURE(feature_name, float, weights, vec, feature, CMP_APPROX, ORIGIN)

#define TEST_EXTRA_FEATURE_INT64(feature_name, vec, feature) \
  TEST_EXTRA_FEATURE(feature_name, int64_t, signs, vec, feature, CMP_EQ, ORIGIN)

#define TEST_BATCH_EXTRA_FEATURES(feature_idx, feature_name, type_value, type_pb, double_vec, extra_features, CMP, TRAN) { \
  std::vector<std::vector<type_value>> _test_double_v_ = std::vector<std::vector<type_value>>double_vec; \
  uint32_t batch_size = _test_double_v_.size(); \
  REQUIRE(extra_features.size() >= (feature_idx + 1) * batch_size); \
  for (uint32_t idx = 0; idx < batch_size; idx++) { \
    TEST_EXTRA_FEATURE(feature_name, type_value, type_pb, (_test_double_v_[idx]), extra_features.at(feature_idx * batch_size + idx), CMP, TRAN);\
  } \
}

#define TEST_BATCH_EXTRA_FEATURES_STR(feature_idx, feature_name, double_vec, extra_features) \
  TEST_BATCH_EXTRA_FEATURES(feature_idx, feature_name, std::string, bytes_list, double_vec, extra_features, CMP_EQ, ORIGIN)

#define TEST_BATCH_EXTRA_FEATURES_FLOAT(feature_idx, feature_name, double_vec, extra_features) \
  TEST_BATCH_EXTRA_FEATURES(feature_idx, feature_name, float, weights, double_vec, extra_features, CMP_APPROX, ORIGIN)

#define TEST_BATCH_EXTRA_FEATURES_INT64(feature_idx, feature_name, double_vec, extra_features) \
  TEST_BATCH_EXTRA_FEATURES(feature_idx, feature_name, int64_t, signs, double_vec, extra_features, CMP_EQ, ORIGIN)


template<typename T>
class range {
public:
    class iterator {
        T val_;
        T end_;
        int step_;
    public:
        explicit iterator(T val, T end) 
            : val_(val), end_(end), step_(1) {}

        T operator*() const { return val_; }
        iterator& operator++() {
            val_ += step_;
            return *this;
        }
        bool operator!=(const iterator& other) const {
            return val_ < end_;
        }
    };

    range(T start, T end) 
        : start_(start), end_(end) {}

    [[nodiscard]] iterator begin() const { 
        return iterator(start_, end_); 
    }
    [[nodiscard]] iterator end() const { 
        return iterator(end_, end_); 
    }

private:
    T start_;
    T end_;
};

range<int> times(int n) {
    return range<int>(0, n);
}

// 北京时间是UTC+8
constexpr int SECONDS_PER_DAY = 86400;
constexpr int BEIJING_UTC_OFFSET = 8 * 3600;

// 自定义字面量，输入自然天数，返回当前自然天的一个随机的时间戳
int64_t operator"" _calendar_day(unsigned long long day_count) {
    // 计算北京时间0点对应的UTC时间戳
    int64_t beijing_midnight_utc = static_cast<int64_t>(day_count) * SECONDS_PER_DAY - BEIJING_UTC_OFFSET;

    // 生成0到86399之间的随机秒数
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::uniform_int_distribution<int64_t> dis(0, SECONDS_PER_DAY - 1);

    int64_t random_offset = dis(gen);

    return (beijing_midnight_utc + random_offset) * 1000;
}
int64_t operator"" _h(unsigned long long hours) {
    return hours * 60 * 60 * 1000; // 1小时=3600秒=3,600,000ms
}

int64_t operator"" _m(unsigned long long minutes) {
    return minutes * 60 * 1000; // 1分钟=60秒=60,000ms
}

int64_t operator"" _s(unsigned long long seconds) {
    return seconds * 1000; // 1秒=1000ms
}

int64_t operator"" _d(unsigned long long days) {
    return days * 24 * 60 * 60 * 1000; // 1天=86,400,000ms
}




#endif // !PHX_TEST_H