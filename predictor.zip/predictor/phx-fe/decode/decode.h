#ifndef _FE_DECODE_
#define _FE_DECODE_

#include "honoraes.h"
#include "AES.h"
#include "base64.h"
#include "phx-fe/util/calc.h"
#include <iostream>

class Decode {
 public:
  static std::string decode_string(const std::string& data) {
    return decrypt_cbc(data, true);
  }

  static std::string decode_file(const std::string& file_name) {
    return decrypt_cbc(Calc::read_file_to_string(file_name), true);
  }

  static std::string base64_file(const std::string& file_name) {
    return base64_decode(Calc::read_file_to_string(file_name));
  }

 public:
  static std::string encrypt_cbc(const std::string& data, const bool padding = true) {
    honoraes::Error e;
    const unsigned char key[16] = "honor";
    const unsigned char iv[16] = "magic7";

    const std::size_t encrypted_size = (padding) ? data.size() + (16 - data.size() % 16) : data.size();
    std::vector<unsigned char> encrypted(encrypted_size);

    e = honoraes::encrypt_cbc((unsigned char*)data.data(), (unsigned long)data.size(), key, 
                              (unsigned long)sizeof(key), &iv, &encrypted[0], 
                              (unsigned long)encrypted.size(), padding);                              
    if (e != honoraes::kErrorOk) {
      THROW_ERROR("encrypt_cbc Error");
      return "";
    }
    std::string ret(encrypted.begin(), encrypted.end());

    return base64_encode(ret);
  }

  static std::string decrypt_cbc(const std::string& data, const bool padding = true) {
    std::string encrypted = base64_decode(data);

    honoraes::Error e;
    const unsigned char key[16] = "honor";
    const unsigned char iv[16] = "magic7";

    std::vector<unsigned char> decrypted(encrypted.size());
    unsigned long padded = 0;
    if (padding) {
      e = honoraes::decrypt_cbc((unsigned char*)encrypted.data(), 
                                (unsigned long)encrypted.size(), 
                                key, 
                                (unsigned long)sizeof(key), 
                                &iv, 
                                decrypted.data(), 
                                (unsigned long)decrypted.size(), 
                                &padded);
    } else {
      e = honoraes::decrypt_cbc((unsigned char*)encrypted.data(), 
                                (unsigned long)encrypted.size(), 
                                key, 
                                (unsigned long)sizeof(key), 
                                &iv, 
                                decrypted.data(), 
                                (unsigned long)decrypted.size(), 
                                0);
    }

    if (e != honoraes::kErrorOk) {
      if (data.empty()) {
        THROW_ERROR("decrypt_cbc Error, string is empty");
        return "";
      }
      THROW_ERROR("decrypt_cbc Error");
      return "";
    }

    return std::string(decrypted.begin(), decrypted.end() - padded);
  }

};

#endif // _FE_DECODE_