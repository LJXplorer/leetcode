#ifndef FE_XML_CONFIG_MGR
#define FE_XML_CONFIG_MGR

#include "common/hidict/dict_manager.h"
#include "config_mgr.h"
#include "phx-fe/util/calc.h"
#include "phx-fe/util/log.h"
#include "phx-fe/util/util.h"
#include <unordered_map>

struct DictConfigPlainText {
  std::string name;
  std::string path;
  std::string partition;
  std::string value_proto;
  std::string class_name;
};

class XmlConfigMgr : public ConfigMgr {
 public:

  static std::vector<DictConfigPlainText> get_dict_configs_from_string(const std::string& xml_str, const std::string& version_name) {
    // 创建XMLDocument实例
    tinyxml2::XMLDocument doc;

    // 从字符串解析XML数据
    tinyxml2::XMLError eResult = doc.Parse(xml_str.c_str());

    // 检查解析是否成功
    if (tinyxml2::XML_SUCCESS != eResult) {
      THROW_ERROR("xml parse failed");
      return {};
    }
    return get_dict_configs(doc, version_name);
  }

  static std::vector<DictConfigPlainText> get_dict_configs(tinyxml2::XMLDocument& doc, const std::string& version_name) {
    std::vector<std::string> dict_names_of_version{};
    std::vector<DictConfigPlainText> dict_config_of_version{};
    tinyxml2::XMLElement* config_element = doc.FirstChildElement("config");
    if (unlikely(config_element == nullptr)) {
      THROW_ERROR("parse failed, <config> element has no name");
    }
    std::unordered_map<std::string, DictConfigPlainText> all_dicts_map{};
    for (tinyxml2::XMLElement* dict = config_element->FirstChildElement("dict"); dict != nullptr; dict = dict->NextSiblingElement("dict")) {
      const char* name_element = dict->Attribute("name");
      const char* path_element = dict->Attribute("path");
      const char* partition_element = dict->Attribute("partition");
      const char* proto_element = dict->Attribute("value_proto");
      const char* class_name_element = dict->Attribute("class_name");
      if (unlikely(name_element == nullptr || path_element == nullptr || class_name_element == nullptr)) {
        THROW_ERROR("parse failed, [name] or [path] or [class_name] is null!");
      }
      DictConfigPlainText dict_config_plaintext{};
      dict_config_plaintext.name = name_element;
      dict_config_plaintext.partition = partition_element;
      dict_config_plaintext.path = path_element;
      dict_config_plaintext.value_proto = proto_element;
      dict_config_plaintext.class_name = class_name_element;
      all_dicts_map.emplace(name_element, dict_config_plaintext);
    }

    if (!version_name.empty()) {
      tinyxml2::XMLElement* versions_element = doc.FirstChildElement("versions");
      if (unlikely(!versions_element)) {
        THROW_ERROR("<versions> element not found!");
        return {};
      }
      for (tinyxml2::XMLElement* version = versions_element->FirstChildElement("version"); version != nullptr; version = version->NextSiblingElement("version")) {
        const char* name_c_str = version->Attribute("name");
        if (unlikely(nullptr == name_c_str)) {
          THROW_ERROR("parse failed, <version> element has no name");
          return {};
        }
        if (version_name == name_c_str) {
            const char* dict_c_str = version->Attribute("dict");
            if(dict_c_str != nullptr) {
              dict_names_of_version = Calc::split_string(dict_c_str, ",");
            }
            break;
        }
      }
    }
    if (!dict_names_of_version.empty()) {
      for(const auto& name : dict_names_of_version) {
        auto iter = all_dicts_map.find(name);
        if(iter == all_dicts_map.end()) {
          THROW_ERROR("dict not found! version name = " + version_name + ";dict name = " + name);
          return {};
        } else {
          dict_config_of_version.emplace_back(iter->second);
        }
        
      }
    } else {
      for (const auto& pair : all_dicts_map) {
        dict_config_of_version.emplace_back(pair.second);
      }
    }

    return dict_config_of_version;
  }

  static void parse_from_file(const std::string& file_name,
                              const std::string& dict_path,
                              const std::string& version_name,
                              ConfigInfo& config_info) {
    tinyxml2::XMLDocument doc;
    doc.LoadFile(file_name.c_str());

    if (unlikely(doc.Error())) {
      THROW_ERROR("xml load file failed:" + file_name);
      return;
    }

    // dict_path补一个/，防止传进来的路径缺少，多/不影响
    parse_xml_new_sample(doc, dict_path + "/", version_name, config_info, 0);
  }

  static void parse_from_string(const std::string& xml_str,
                                const std::string& version_name,
                                ConfigInfo& config_info,
                                long dicts_handle,
                                FEDictMap* fe_dict_map = nullptr) {
    // 创建XMLDocument实例
    tinyxml2::XMLDocument doc;

    // 从字符串解析XML数据
    tinyxml2::XMLError eResult = doc.Parse(xml_str.c_str());

    // 检查解析是否成功
    if (tinyxml2::XML_SUCCESS != eResult) {
      THROW_ERROR("xml parse failed");
      return;
    }

    // dict_path补一个/，防止传进来的路径缺少，多/不影响
    parse_xml_new_sample(doc, config_info.dict_path_ + "/", version_name, config_info, dicts_handle, fe_dict_map);
  }

  //当前实现和parse_xml没有区别
  static void parse_xml_new_sample(tinyxml2::XMLDocument& doc,
                        const std::string& archived_dict_path,
                        const std::string& version_name,
                        ConfigInfo& config_info,
                        long dicts_handle,
                        FEDictMap* fe_dict_map = nullptr) {
    config_info.dict_collector_ = reinterpret_cast<hidict::DictCollector*>(dicts_handle);
    auto& vec = config_info.configs_;
    auto& name2config = config_info.name2config_;
    auto& slot2config = config_info.slot2config_;
    vec.clear(); //清空vec，重新初始化
    name2config.clear();
    slot2config.clear();
    // 获取 <config> 节点
    tinyxml2::XMLElement* config_element = doc.FirstChildElement("config");
    if (unlikely(!config_element)) {
      THROW_ERROR( "<config> element not found!");
      return;
    }

    // 如果version_name不为空，筛选指定版本所需的特征
    std::map<std::string, VersionInfo> version_map;
    VersionInfo* version_info = nullptr;
    if (!version_name.empty()) {
      tinyxml2::XMLElement* versions_element = doc.FirstChildElement("versions");
      if (unlikely(!versions_element)) {
        THROW_ERROR("<versions> element not found!");
        return;
      }

      for (tinyxml2::XMLElement* version = versions_element->FirstChildElement("version"); version != nullptr; version = version->NextSiblingElement("version")) {
        const char* name_c_str = version->Attribute("name");
        if (unlikely(nullptr == name_c_str)) {
          THROW_ERROR("parse failed, <version> element has no name");
          return;
        }

        const char* value_c_str = version->Attribute("value");
        if (unlikely(nullptr == value_c_str)) {
          THROW_ERROR("parse failed, <version> element has no value, name:" + std::string(name_c_str));
          return;
        }

        // 非必填配置 可为nullptr
        const char* label_c_str = version->Attribute("labels");
        const char* weight_c_str = version->Attribute("weights");

        // 迁移后删除
        const char* extra_int64_c_str = version->Attribute("extras_int64");
        const char* extra_float_c_str = version->Attribute("extras_float");
        const char* extra_bytes_c_str = version->Attribute("extras_bytes");

        const char* user_extra_int64_c_str = version->Attribute("user_extras_int64");
        const char* user_extra_float_c_str = version->Attribute("user_extras_float");
        const char* user_extra_bytes_c_str = version->Attribute("user_extras_bytes");
        const char* item_extra_int64_c_str = version->Attribute("item_extras_int64");
        const char* item_extra_float_c_str = version->Attribute("item_extras_float");
        const char* item_extra_bytes_c_str = version->Attribute("item_extras_bytes");

        // 迁移后删除
        version_map.emplace(name_c_str, VersionInfo(value_c_str, label_c_str, weight_c_str, extra_int64_c_str, extra_float_c_str, extra_bytes_c_str, user_extra_int64_c_str, user_extra_float_c_str, user_extra_bytes_c_str, item_extra_int64_c_str, item_extra_float_c_str, item_extra_bytes_c_str));
        // version_map.emplace(name_c_str, VersionInfo(value_c_str, label_c_str, weight_c_str, user_extra_int64_c_str, user_extra_float_c_str, user_extra_bytes_c_str, item_extra_int64_c_str, item_extra_float_c_str, item_extra_bytes_c_str));
      }

      auto itr = version_map.find(version_name);
      // 如果没找对对应的version，默认获取全部特征
      if (itr != version_map.end()) {
        version_info = &itr->second;
        config_info.labels_ = itr->second.labels;
        config_info.weights_ = itr->second.weights;
        config_info.user_extras_int64_ = itr->second.user_extras_int64;
        config_info.user_extras_float_ = itr->second.user_extras_float;
        config_info.user_extras_bytes_ = itr->second.user_extras_bytes;

        config_info.item_extras_int64_ = itr->second.item_extras_int64;
        config_info.item_extras_float_ = itr->second.item_extras_float;
        config_info.item_extras_bytes_ = itr->second.item_extras_bytes;
      }
    }

    AllDicts dicts; //词典路径宏替换存储在dicts中
    std::map<std::string, std::string> source_map;
    // 遍历 <source> 节点
    for (tinyxml2::XMLElement* source = config_element->FirstChildElement("source"); source != nullptr; source = source->NextSiblingElement("source")) {
      const char* name = source->Attribute("name");
      const char* dict_name = source->Attribute("dict_name");
      const char* value = source->Attribute("value");

      if (unlikely(!value)) {
        THROW_ERROR("<source> element has no value attribute!");
        return;
      }

      if (name) {
        if (unlikely(!source_map.emplace(name, value).second)) {
          THROW_ERROR("<source> element has repeated name:" + std::string(name));
          return;
        }
      } else if (dict_name) {
        if (unlikely(!dicts.macros_.emplace(dict_name, value).second)) {
          THROW_ERROR("<source> element has repeated dict_name:" + std::string(dict_name));
          return;
        }
      }
    }

    // appid-三级类目
    dicts.id_123class_dict_ptr.reset(new std::unordered_map<std::string, AllClasses>());
    dicts.id_dict_ptr.reset(new std::unordered_map<std::string, AllClasses>());
    dicts.pack_dict_ptr.reset(new std::unordered_map<std::string, AllClasses>());
    dicts.appname_dict_ptr.reset(new std::unordered_map<std::string, AllClasses>());
    dicts.dicts_handle = dicts_handle;


    // 默认值  不使用default_value_map
    // std::map<std::string, DefaultValue> default_value_map;
    // load_defalt_value(config_element, source_map, default_value_map);

    // hash_slot开关
    tinyxml2::XMLElement* hash_slot_element = doc.FirstChildElement("hash_slot");
    bool slot_flag = true;

    if (hash_slot_element != nullptr) {
      const char* flag_c_str = hash_slot_element->Attribute("flag");
      if (flag_c_str != nullptr) {
        slot_flag = (XmlMgr::convert<bool>(flag_c_str));
      }
    }

    // 获取 <features> 节点
    tinyxml2::XMLElement* features = config_element->FirstChildElement("features");
    if (unlikely(!features)) {
      THROW_ERROR("<features> element not found!");
      return;
    }

    int64_t public_default_input_int = 0;
    const char* default_input_int_c_str = features->Attribute("default_input_int64");
    if (default_input_int_c_str != nullptr) {
      if (!Calc::convert_int64(default_input_int_c_str, public_default_input_int)) {
        THROW_ERROR("<features> attribute trans failed, default_input_int64:" + std::string(default_input_int_c_str));
      }
    }

    float public_default_input_float = 0;
    const char* default_input_float_c_str = features->Attribute("default_input_float");
    if (default_input_float_c_str != nullptr) {
      if (!Calc::convert_float(default_input_float_c_str, public_default_input_float)) {
        THROW_ERROR("<features> attribute trans failed, default_input_float:" + std::string(default_input_float_c_str));
      }
    }

    std::string public_default_input_str = "";
    const char* default_input_str_c_str = features->Attribute("default_input_str");
    if (default_input_str_c_str != nullptr) {
      public_default_input_str = std::string(default_input_str_c_str);
    }

    // 解析特征列表
    Config* config = nullptr;
    std::set<uint16_t> slot_set; //slot重复检测

    // 遍历 <feature> 节点
    for (tinyxml2::XMLElement* feature = features->FirstChildElement("feature"); feature != nullptr; feature = feature->NextSiblingElement("feature")) {
      const char* name_c_str = feature->Attribute("name");
      if (unlikely(nullptr == name_c_str)) {
        THROW_ERROR("parse failed, <feature> element has no name");
        return;
      }

      const char* type_c_str = feature->Attribute("type");
      if (unlikely(nullptr == type_c_str)) {
        THROW_ERROR("parse failed, <feature> element has no fe_type, name:" + std::string(name_c_str));
        return;
      }
      std::string config_type = std::string(type_c_str);

      const char* source_c_str = feature->Attribute("source");
      if (unlikely(nullptr == source_c_str)) {
        THROW_ERROR("parse failed, <feature> element has no source, name:" + std::string(name_c_str));
        return;
      }
      std::vector<std::string> source = Calc::split_string(source_c_str, ",");

      // source宏替换
      for (uint32_t i = 0; i < source.size(); ++i) {
        source_replace(source_map, source[i]);
      }

      //direct_to_feature
      if ("direct_to_feature" == config_type) {
        load_direct_to_feature(source, config_type, name_c_str);
      }

      std::vector<std::string> strategy;
      strategy.emplace_back("auto_type");   //xml默认启动auto_type策略
      strategy.emplace_back("empty");       //所有算子都允许为空

      const char* strategy_c_str = feature->Attribute("strategy");
      if (strategy_c_str) {
        auto split_result = Calc::split_string(strategy_c_str, ",");
        strategy.insert(strategy.end(), split_result.begin(), split_result.end());
      }

      uint16_t maybe_slot = 0;
      const char* maybe_slot_c_str = feature->Attribute("slot");
      if (maybe_slot_c_str != nullptr && Calc::convert_uint16(maybe_slot_c_str, maybe_slot)) {
        //配置了slot的算子特征自动添加feature
        strategy.emplace_back("feature");
      }

      FEA_ATTR_TYPE attr_type = ATTR_TYPE_UNKNOWN;
      const char *attr_c_str = feature->Attribute("attr");
      if (nullptr != attr_c_str) {
        std::string attr_str = std::string(attr_c_str);
        if (attr_str == "user") {
          attr_type = ATTR_TYPE_USER;
        } else if (attr_str == "item") {
          attr_type = ATTR_TYPE_ITEM;
        } else if (attr_str == "cross") {
          attr_type = ATTR_TYPE_CROSS;
        } else {
          THROW_ERROR("invaild attr_type:" + attr_str);
          return;
        }
      }

      bool public_defalut = true;

      int64_t default_input_int = 0;
      const char* default_input_int_c_str = feature->Attribute("default_input_int64");
      if (default_input_int_c_str != nullptr) {
        public_defalut = false;
        if (!Calc::convert_int64(default_input_int_c_str, default_input_int)) {
          THROW_ERROR("<features> attribute trans failed, default_input_int:" + std::string(default_input_int_c_str));
        }
      } else {
        default_input_int = public_default_input_int;
      }

      float default_input_float = 0;
      const char* default_input_float_c_str = feature->Attribute("default_input_float");
      if (default_input_float_c_str != nullptr) {
        public_defalut = false;
        if (!Calc::convert_float(default_input_float_c_str, default_input_float)) {
          THROW_ERROR("<features> attribute trans failed, default_input_float:" + std::string(default_input_float_c_str));
        }
      } else {
        default_input_float = public_default_input_float;
      }

      std::string default_input_str = "";
      const char* default_input_str_c_str = feature->Attribute("default_input_str");
      if (default_input_str_c_str != nullptr) {
        public_defalut = false;
        default_input_str = std::string(default_input_str_c_str);
      } else {
        default_input_str = public_default_input_str;
      }
  
      DefaultValue dv;
      dv.value_string =  default_input_str;
      dv.value_int64 =  default_input_int;
      dv.value_float =  default_input_float;
      dv.input_public = public_defalut;

      config = create_config(config_type, feature, name_c_str, source, dv, strategy, dicts, archived_dict_path);

      if (unlikely(nullptr == config)) {
        THROW_ERROR("create failed, config_type:" + config_type + ", name:" + std::string(name_c_str));
        return;
      }
      config->set_operator_type(config_type);
      config->set_attr_type(attr_type);

      if (slot_flag) {
        for (const auto& strategy : config->strategy_) {
          auto hash_strategy_ptr = std::dynamic_pointer_cast<HashStrategy>(strategy);
          auto hash_slot_strategy_ptr = std::dynamic_pointer_cast<HashSlotStrategy>(strategy);

          // 检查至少一个指针有效
          if (hash_strategy_ptr == nullptr && hash_slot_strategy_ptr == nullptr) {
            continue; // 如果两个指针都无效，跳过当前循环
          }

          // 添加 slot 到策略
          auto add_slot = [&](uint16_t s) {
            if (hash_strategy_ptr) {
              hash_strategy_ptr->slots_.push_back(static_cast<uint64_t>(s) << 48);
            }
            if (hash_slot_strategy_ptr) {
              hash_slot_strategy_ptr->slots_.push_back(static_cast<uint64_t>(s) << 48);
            }
          };

          uint16_t slot = 0;
          uint16_t share_slot = 0;
          const char* slot_c_str = feature->Attribute("slot");
          const char* share_slot_c_str = feature->Attribute("share_slot");
          if (slot_c_str == nullptr) {
            THROW_ERROR("<feature> element has no slot attribute, name:" + std::string(name_c_str));
          }
          if (!Calc::convert_uint16(slot_c_str, slot)) {
            THROW_ERROR("slot convert failed, slot:" + std::string(slot_c_str) + ", name:" + std::string(name_c_str));
          }
          // slot重复检测
          if (!slot_set.insert(slot).second) {
            THROW_ERROR("config have duplicate definition of slot, error happens, slot:" + std::string(slot_c_str) + ", name:" + std::string(name_c_str));
          }
          add_slot(slot);

          if (share_slot_c_str != nullptr) {
            if (Calc::convert_uint16(share_slot_c_str, share_slot)) {
              add_slot(share_slot);
            } else {
              THROW_ERROR("share_solt convert failed, share_slot:" + std::string(share_slot_c_str) + ", name:" + std::string(name_c_str));
            }
          }
        }
      }

      auto config_ptr = std::shared_ptr<Config>(config);
      vec.push_back(config_ptr);
      name2config[config->output_] = config_ptr;
      if (config->slot_id_ > 0) {
        slot2config[std::to_string(config->slot_id_)] = config_ptr;
      }
    }

    if (version_info) {
      select_config(*version_info, vec, slot2config, name2config);
    }

    order(vec);

  }

  static void source_replace(std::map<std::string, std::string>& source_map, std::string& source) {
    std::string new_source;
    // E@开头 
    if (source.size() > 2 && 'E' == source[0] && '@' == source[1]) {
      source.erase(0, 2);
      new_source.append("E@");
    }
    std::vector<std::string> source_part = Calc::split_string(source, ".");

    for (uint32_t j = 0; j < source_part.size(); ++j) {
      auto itr = source_map.find(source_part[j]);
      if (itr != source_map.end()) {
        new_source.append(itr->second).append(".");
      } else {
        new_source.append(source_part[j]).append(".");
      }
    }
    if ('.' == new_source.back()) {
      new_source.pop_back();
    }
    source = new_source;
  }


  static Config* create_config(const std::string& type,
                               tinyxml2::XMLElement* element,
                               const std::string& output,
                               std::vector<std::string>& source,
                               DefaultValue& default_input_value,
                               const std::vector<std::string>& strategy,
                               AllDicts& dicts,
                               const std::string& dict_path);


  protected:
  using XmlConfigCreatorFunc = std::function<Config*(tinyxml2::XMLElement* element,
                                                     const std::string&,
                                                     std::vector<std::string>&,
                                                     DefaultValue&,
                                                     const std::vector<std::string>&,
                                                     AllDicts&,
                                                     const std::string&)>;
  static const std::map<std::string, XmlConfigCreatorFunc> xml_config_creator_map;
};

#endif  // FE_XML_CONFIG_MGR