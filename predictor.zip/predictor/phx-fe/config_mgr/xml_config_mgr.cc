#include "xml_config_mgr.h"
#include "phx-fe/ad_dict/ad_dict_manager.h"
#include "common/hidict/dict_manager.h"
#include "phx-fe/config/config.h"
#include "phx-fe/config/config_base.h"
#include "phx-fe/config/phx_config_dict.h"
#include "phx-fe/config/phx_config_base.h"
#include "phx-fe/config/phx_config_seq.h"
#include "phx-fe/config/phx_config_utf8.h"
#include "phx-fe/util/calc.h"
#include "phx-fe/util/log.h"
#include "phx-fe/util/util.h"
#include "phx-fe/util/xml_mgr.h"

#include <algorithm>
#include <cstdint>
#include <cstdlib>
#include <string>
#include <limits>

static Config* xml_create_bucketize(tinyxml2::XMLElement* element,
                                    const std::string& output,
                                    std::vector<std::string>& source,
                                    DefaultValue& default_input_value,
                                    const std::vector<std::string>& strategy,
                                    AllDicts& dicts,
                                    const std::string& dict_path) {
  std::vector<float> boundaries;
  XmlMgr::get_filed_vector_value<float>(element, "boundary", boundaries);

  if (unlikely(boundaries.empty())) {
    return nullptr;
  }

  return new BucketizedConfig(output, source, default_input_value, true, false, strategy, boundaries);
}

static Config* xml_create_hash(tinyxml2::XMLElement* element,
                               const std::string& output,
                               std::vector<std::string>& source,
                               DefaultValue& default_input_value,
                               const std::vector<std::string>& strategy,
                               AllDicts& dicts,
                               const std::string& dict_path) {
  int64_t bucket_size = XmlMgr::get_filed_value<int64_t>(element, "bucket_size", -1);
  bool concat_with_name = XmlMgr::get_filed_value<bool>(element, "concat_with_name", true);

  if (unlikely(bucket_size <= 0)) {
    return nullptr;
  }

  return new phx_fe::HashBucketConfig(output, source, default_input_value, true, false, strategy, bucket_size, concat_with_name);
}

static Config* xml_create_vocab_list(tinyxml2::XMLElement* element,
                                     const std::string& output,
                                     std::vector<std::string>& source,
                                     DefaultValue& default_input_value,
                                     const std::vector<std::string>& strategy,
                                     AllDicts& dicts,
                                     const std::string& dict_path) {
  std::vector<std::string> vocab_list;
  XmlMgr::get_filed_vector_value<std::string>(element, "vocabs", vocab_list);

  if (unlikely(vocab_list.empty())) {
    return nullptr;
  }

  return new VocabListConfig(output, source, default_input_value, true, false, strategy, vocab_list);
}

static Config* xml_create_vocab_set(tinyxml2::XMLElement* element,
                                    const std::string& output,
                                    std::vector<std::string>& source,
                                    DefaultValue& default_input_value,
                                    const std::vector<std::string>& strategy,
                                    AllDicts& dicts,
                                    const std::string& dict_path) {
  std::shared_ptr<std::unordered_set<std::string>> str_dict(new std::unordered_set<std::string>);
  XmlMgr::get_filed_unordered_set_value<std::string>(element, "dict", *str_dict);

  if (unlikely(str_dict->empty())) {
    return nullptr;
  }

  // 如果只有一个字符串，且有后缀，默认是文件路径
  std::unordered_set<std::string>::iterator itr = str_dict->begin();
  std::string path = *itr;
  dicts.replace(path);  //词典路径宏替换

  if (str_dict->size() == 1 && path.find('.') != std::string::npos) {
    if (!dicts.find_vocab_set(path, str_dict)) {
      std::ifstream file(dict_path + path);
      if (!file.is_open()) {
        return nullptr;
      }

      std::string line;
      str_dict->clear();
      while (std::getline(file, line)) {
        Calc::remove_leading_and_trailing_spaces(line);
        str_dict->insert(line);
      }
      dicts.set_vocab_set(path, str_dict);
    }
  }

  std::vector<std::string> vec_dict;
  XmlMgr::get_filed_vector_value<std::string>(element, "dict", vec_dict);

  return new VocabSetConfig(output, source, default_input_value, true, false, strategy, vec_dict, str_dict);
}

template <typename T>
static Config* create_vocab_map_config(const std::string& output,
                                       std::vector<std::string>& source,
                                       DefaultValue& default_input_value,
                                       const std::vector<std::string>& strategy,
                                       AllDicts& dicts,
                                       const std::string& dict_path,
                                       const std::string& dtype,
                                       std::vector<std::string>& vec_dict) {
  MapDict<T> map_dict;
  std::string path = vec_dict[0];
  dicts.replace(path);  //词典路径宏替换

  if (vec_dict.size() == 1 && path.find('.') != std::string::npos) {
    if (!map_dict.find_map(path, dicts)) {
      map_dict.reset_map();
      std::ifstream file(dict_path + path);
      if (!file.is_open()) {
        return nullptr;
      }

      std::string line;
      std::string key;
      std::string value;
      while (std::getline(file, line)) {
        if (Calc::parse_line(line, ':', key, value)) {
          map_dict.fill_map(key, value);
        }
      }
      map_dict.set_map(path, dicts);
    }
  } else {
    map_dict.reset_map();
    std::vector<std::string> key_value;
    for (auto& str : vec_dict) {
      key_value = Calc::split_string(str, ":");
      if (key_value.size() == 2) {
        map_dict.fill_map(key_value[0], key_value[1]);
      }
    }
  }

  if (likely(!map_dict.map_dict_->empty())) {
    return new VocabMapConfig<T>(output, source, default_input_value, true, false, strategy, dtype, vec_dict, map_dict.map_dict_);
  } else {
    return nullptr;
  }
}

static Config* xml_create_vocab_map(tinyxml2::XMLElement* element,
                                    const std::string& output,
                                    std::vector<std::string>& source,
                                    DefaultValue& default_input_value,
                                    const std::vector<std::string>& strategy,
                                    AllDicts& dicts,
                                    const std::string& dict_path) {
  std::vector<std::string> vec_dict;
  XmlMgr::get_filed_vector_value<std::string>(element, "dict", vec_dict);
  std::string dtype = XmlMgr::get_filed_value<std::string>(element, "dtype", "");

  if (unlikely(vec_dict.empty() || (dtype != "float" && dtype != "int64" && dtype != "string"))) {
    return nullptr;
  }

  if (dtype == "float") {
    return create_vocab_map_config<float>(output, source, default_input_value, strategy, dicts, dict_path, dtype, vec_dict);
  } else if (dtype == "int64") {
    MapDict<int64_t> map_dict;
    return create_vocab_map_config<int64_t>(output, source, default_input_value, strategy, dicts, dict_path, dtype, vec_dict);
  } else if (dtype == "string") {
    MapDict<std::string> map_dict;
    return create_vocab_map_config<std::string>(output, source, default_input_value, strategy, dicts, dict_path, dtype, vec_dict);
  } 

  return nullptr;
}

static Config* xml_create_is_match_str(tinyxml2::XMLElement* element,
                                       const std::string& output,
                                       std::vector<std::string>& source,
                                       DefaultValue& default_input_value,
                                       const std::vector<std::string>& strategy,
                                       AllDicts& dicts,
                                       const std::string& dict_path) {
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "");

  if (unlikely(dicts.appname_dict_ptr->empty())) {
    return nullptr;
  }

  return new IsMatchStrConfig(output, source, default_input_value, true, false, strategy, dicts.appname_dict_ptr, default_value);
}

static Config* xml_create_direct(tinyxml2::XMLElement* element,
                                 const std::string& output,
                                 std::vector<std::string>& source,
                                 DefaultValue& default_input_value,
                                 const std::vector<std::string>& strategy,
                                 AllDicts& dicts,
                                 const std::string& dict_path) {
  bool auto_type = XmlMgr::get_filed_value<bool>(element, "auto_type", false);

  return new phx_fe::DirectConfig(output, source, default_input_value, true, false, strategy, auto_type);
}

static Config* xml_create_filter_appid(tinyxml2::XMLElement* element,
                                       const std::string& output,
                                       std::vector<std::string>& source,
                                       DefaultValue& default_input_value,
                                       const std::vector<std::string>& strategy,
                                       AllDicts& dicts,
                                       const std::string& dict_path) {
  std::vector<int32_t> days;
  XmlMgr::get_filed_vector_value<int32_t>(element, "days", days);
  int32_t max_len = XmlMgr::get_filed_value<int32_t>(element, "max_len", -1);
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");

  if (unlikely(days.empty() || max_len <= 0)) {
    return nullptr;
  }

  return new FilterAppIdConfig(output, source, default_input_value, true, false, strategy, days, max_len, default_value);
}

static Config* xml_create_max_expo_appid(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  return new MaxExpoAppidConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_max_123_class(tinyxml2::XMLElement* element,
                                        const std::string& output,
                                        std::vector<std::string>& source,
                                        DefaultValue& default_input_value,
                                        const std::vector<std::string>& strategy,
                                        AllDicts& dicts,
                                        const std::string& dict_path) {
  std::string dict_type = XmlMgr::get_filed_value<std::string>(element, "dict_type", "item_map");

  if ("item_map" == dict_type && !dicts.id_123class_dict_ptr->empty()) {
    return new Max123ClassConfig(output, source, default_input_value, true, false, strategy, dicts.id_123class_dict_ptr);
  } else if ("appinfo" == dict_type && !dicts.id_dict_ptr->empty()) {
    return new Max123ClassConfig(output, source, default_input_value, true, false, strategy, dicts.id_dict_ptr);
  }

  return nullptr;
}

static Config* xml_create_nearest_expo_appid(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  return new NearestExpoAppidConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_expo_appid_count(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  return new ExpoAppidCountConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_expo_123_count(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  std::string dict_type = XmlMgr::get_filed_value<std::string>(element, "dict_type", "item_map");

  if ("item_map" == dict_type && !dicts.id_123class_dict_ptr->empty()) {
    return new Expo123CountConfig(output, source, default_input_value, true, false, strategy, dicts.id_123class_dict_ptr);
  } else if ("appinfo" == dict_type && !dicts.id_dict_ptr->empty()) {
    return new Expo123CountConfig(output, source, default_input_value, true, false, strategy, dicts.id_dict_ptr);
  }

  return nullptr;
}

static Config* xml_create_expo_123_count_v2(tinyxml2::XMLElement* element,
                                            const std::string& output,
                                            std::vector<std::string>& source,
                                            DefaultValue& default_input_value,
                                            const std::vector<std::string>& strategy,
                                            AllDicts& dicts,
                                            const std::string& dict_path) {
  std::string dict_type = XmlMgr::get_filed_value<std::string>(element, "dict_type", "item_map");

  if ("item_map" == dict_type && !dicts.id_123class_dict_ptr->empty()) {
    return new Expo123CountV2Config(output, source, default_input_value, true, false, strategy, dicts.id_123class_dict_ptr);
  } else if ("appinfo" == dict_type && !dicts.id_dict_ptr->empty()) {
    return new Expo123CountV2Config(output, source, default_input_value, true, false, strategy, dicts.id_dict_ptr);
  }

  return nullptr;
}

static Config* xml_create_nearest_expo_days(tinyxml2::XMLElement* element,
                                            const std::string& output,
                                            std::vector<std::string>& source,
                                            DefaultValue& default_input_value,
                                            const std::vector<std::string>& strategy,
                                            AllDicts& dicts,
                                            const std::string& dict_path) {
  return new NearestExpoDaysConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_appid_cross(tinyxml2::XMLElement* element,
                                      const std::string& output,
                                      std::vector<std::string>& source,
                                      DefaultValue& default_input_value,
                                      const std::vector<std::string>& strategy,
                                      AllDicts& dicts,
                                      const std::string& dict_path) {
  int64_t bucket_size = XmlMgr::get_filed_value<int64_t>(element, "bucket_size", -1);

  if (unlikely(bucket_size <= 0)) {
    return nullptr;
  }

  return new AppidCrossConfig(output, source, default_input_value, true, false, strategy, bucket_size);
}

static Config* xml_create_to_feature(tinyxml2::XMLElement* element,
                                     const std::string& output,
                                     std::vector<std::string>& source,
                                     DefaultValue& default_input_value,
                                     const std::vector<std::string>& strategy,
                                     AllDicts& dicts,
                                     const std::string& dict_path) {
  return new ToFeatureConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_direct_to_feature_v2(tinyxml2::XMLElement* element,
                                               const std::string& output,
                                               std::vector<std::string>& source,
                                               DefaultValue& default_input_value,
                                               const std::vector<std::string>& strategy,
                                               AllDicts& dicts,
                                               const std::string& dict_path) {
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "");
  DataType data_type = XmlMgr::get_filed_dtype(element, "data_type");

  if(unlikely(data_type == DATATYPE_UNKNOWN)) {
    return nullptr;
  }

  return new phx_fe::DirectToFeatureV2Config(output, source, default_input_value, true, false, strategy, data_type, default_value);
}

static Config* xml_create_to_batch_feature(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  return new ToBatchFeatureConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_identity(tinyxml2::XMLElement* element,
                                   const std::string& output,
                                   std::vector<std::string>& source,
                                   DefaultValue& default_input_value,
                                   const std::vector<std::string>& strategy,
                                   AllDicts& dicts,
                                   const std::string& dict_path) {
  int64_t max_value = XmlMgr::get_filed_value<int64_t>(element, "max_value", -1);
  int64_t default_value = XmlMgr::get_filed_value<int64_t>(element, "default_value", 0);

  if (unlikely(max_value <= 0)) {
    return nullptr;
  }

  return new IdentityConfig(output, source, default_input_value, true, false, strategy, max_value, default_value);
}

static Config* xml_create_string_to_int64(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  int64_t default_value = XmlMgr::get_filed_value<int64_t>(element, "default_value", -1);

  return new StringToInt64Config(output, source, default_input_value, true, false, strategy, default_value);
}

static Config* xml_create_appid_to_123_class(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "");
  std::string dict_type = XmlMgr::get_filed_value<std::string>(element, "dict_type", "item_map");
  int64_t class_type = XmlMgr::get_filed_value<int64_t>(element, "class_type", -1);

  if (unlikely(class_type < Class123Type::CLASS_1 || class_type > Class123Type::CLASS_3)) {
    return nullptr;
  }

  if ("item_map" == dict_type && !dicts.id_123class_dict_ptr->empty()) {
    return new AppidTo123ClassConfig(output, source, default_input_value, true, false, strategy, dicts.id_123class_dict_ptr, static_cast<Class123Type>(class_type), default_value);
  } else if ("appinfo" == dict_type && !dicts.id_dict_ptr->empty()) {
    return new AppidTo123ClassConfig(output, source, default_input_value, true, false, strategy, dicts.id_dict_ptr, static_cast<Class123Type>(class_type), default_value);
  }

  return nullptr;
}

static Config* xml_create_trans_type(tinyxml2::XMLElement* element,
                                     const std::string& output,
                                     std::vector<std::string>& source,
                                     DefaultValue& default_input_value,
                                     const std::vector<std::string>& strategy,
                                     AllDicts& dicts,
                                     const std::string& dict_path) {
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "");
  DataType data_type = XmlMgr::get_filed_dtype(element, "data_type");

  if(unlikely(data_type == DATATYPE_UNKNOWN)) {
    return nullptr;
  }

  return new phx_fe::TransTypeConfig(output, source, default_input_value, true, false, strategy, data_type, default_value);
}

static Config* xml_create_fully_cross(tinyxml2::XMLElement* element,
                                      const std::string& output,
                                      std::vector<std::string>& source,
                                      DefaultValue& default_input_value,
                                      const std::vector<std::string>& strategy,
                                      AllDicts& dicts,
                                      const std::string& dict_path) {
  std::string connector = XmlMgr::get_filed_value<std::string>(element, "connector", "_");
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");

  return new phx_fe::FullyCrossConfig(output, source, default_input_value, true, false, strategy, connector, default_value);
}

static Config* xml_create_connect(tinyxml2::XMLElement* element,
                                  const std::string& output,
                                  std::vector<std::string>& source,
                                  DefaultValue& default_input_value,
                                  const std::vector<std::string>& strategy,
                                  AllDicts& dicts,
                                  const std::string& dict_path) {
  std::string connector = XmlMgr::get_filed_value<std::string>(element, "connector", "_");
  std::string tail = XmlMgr::get_filed_value<std::string>(element, "tail", "");

  return new phx_fe::ConnectConfig(output, source, default_input_value, true, false, strategy, connector, tail);
}

static Config* xml_create_connect_all_to_string(tinyxml2::XMLElement* element,
                                                const std::string& output,
                                                std::vector<std::string>& source,
                                                DefaultValue& default_input_value,
                                                const std::vector<std::string>& strategy,
                                                AllDicts& dicts,
                                                const std::string& dict_path) {
  std::string first_connector = XmlMgr::get_filed_value<std::string>(element, "first_connector", "_");
  std::string second_connector = XmlMgr::get_filed_value<std::string>(element, "second_connector", ";");
  std::string tail = XmlMgr::get_filed_value<std::string>(element, "tail", "");

  return new phx_fe::ConnectAllToStringConfig(output, source, default_input_value, true, false, strategy, first_connector, second_connector, tail);
}

static Config* xml_create_cross_hash_bits(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  int32_t clip_size = XmlMgr::get_filed_value<int32_t>(element, "clip_size", -1);

  if (unlikely(0 == clip_size)) {
    return nullptr;
  }

  std::vector<std::string> modified_strategy(strategy);
  modified_strategy.push_back("hash_slot");

  return new CrossHashBitsConfig(output, source, default_input_value, true, false, modified_strategy, clip_size);
}

static Config* xml_create_cross_hash_bits_v2(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  int32_t clip_size = XmlMgr::get_filed_value<int32_t>(element, "clip_size", -1);

  if (unlikely(0 == clip_size)) {
    return nullptr;
  }

  std::vector<std::string> modified_strategy(strategy);
  modified_strategy.push_back("hash_slot");

  return new phx_fe::CrossHashBitsV2Config(output, source, default_input_value, true, false, modified_strategy, clip_size);
}

static Config* xml_create_get_valid_value(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  const auto config = XmlMgr::get_filed_value<int32_t>(element, "config", -1);
  const auto config_int64_value = XmlMgr::get_filed_value<int64_t>(element, "config_int64_value", 0);
  const auto config_float_value = XmlMgr::get_filed_value<float>(element, "config_float_value", 0);
  const auto default_int64_value = XmlMgr::get_filed_value<int64_t>(element, "default_int64_value", -1);
  const auto default_float_value = XmlMgr::get_filed_value<float>(element, "default_float_value", -1.0f);
  const auto precision = XmlMgr::get_filed_value<float>(element, "precision", 1e-6);
  if (unlikely(config < 1 || config > 3)) {
    return nullptr;
  }
  return new phx_fe::GetValidValueConfig(output, source, default_input_value, true, false, strategy, config, config_int64_value, config_float_value, default_int64_value, default_float_value, precision);
}

static Config* xml_create_get_valid_value_v2(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  std::string invalid = XmlMgr::get_filed_value<std::string>(element, "invalid", "");

  return new phx_fe::GetValidValueV2Config(output, source, default_input_value, true, false, strategy, invalid);
}

static Config* xml_create_act_value(tinyxml2::XMLElement* element,
                                    const std::string& output,
                                    std::vector<std::string>& source,
                                    DefaultValue& default_input_value,
                                    const std::vector<std::string>& strategy,
                                    AllDicts& dicts,
                                    const std::string& dict_path) {
  float activation_value = XmlMgr::get_filed_value<float>(element, "activation_value", -1);
  float default_value = XmlMgr::get_filed_value<float>(element, "default_value", -1);

  return new ActValueConfig(output, source, default_input_value, true, false, strategy, activation_value, default_value);
}

static Config* xml_create_int64_offset(tinyxml2::XMLElement* element,
                                       const std::string& output,
                                       std::vector<std::string>& source,
                                       DefaultValue& default_input_value,
                                       const std::vector<std::string>& strategy,
                                       AllDicts& dicts,
                                       const std::string& dict_path) {
  int64_t offset = XmlMgr::get_filed_value<int64_t>(element, "offset", 0);

  return new Int64OffsetConfig(output, source, default_input_value, true, false, strategy, offset);
}

static Config* xml_create_int64_difference(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  return new phx_fe::Int64DifferenceConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_clip(tinyxml2::XMLElement* element,
                               const std::string& output,
                               std::vector<std::string>& source,
                               DefaultValue& default_input_value,
                               const std::vector<std::string>& strategy,
                               AllDicts& dicts,
                               const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0);
  int64_t size = XmlMgr::get_filed_value<int64_t>(element, "size", -1);

  if (unlikely(start < 0 || size < -1)) {
    return nullptr;
  }

  return new phx_fe::ClipConfig(output, source, default_input_value, true, false, strategy, start, size);
}

static Config* xml_create_segment(tinyxml2::XMLElement* element,
                                  const std::string& output,
                                  std::vector<std::string>& source,
                                  DefaultValue& default_input_value,
                                  const std::vector<std::string>& strategy,
                                  AllDicts& dicts,
                                  const std::string& dict_path) {

  std::string dict_name = XmlMgr::get_filed_value<std::string>(element, "dict_name", "");

  if (unlikely(dict_name.empty())) {
    return nullptr;
  }

  auto dicts_collector = reinterpret_cast<AdDict::AdDictCollector*>(dicts.dicts_handle);
  auto* jieba_mix_segment = dicts_collector->get_segment_info(dict_name);
  if (unlikely(jieba_mix_segment == nullptr)) {
    return nullptr;
  }

  return new phx_fe::SegmentConfig(output, source, default_input_value, true, false, strategy,
                           jieba_mix_segment, dict_name);
}

static Config* xml_create_dict_to_attributes(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  std::string connector = XmlMgr::get_filed_value<std::string>(element, "connector", "\002");
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "");
  std::string dict_type = XmlMgr::get_filed_value<std::string>(element, "dict_type", "");

  if (dict_type == "app_id" && !dicts.id_dict_ptr->empty()) {
    return new DictToAttributesConfig(output, source, default_input_value, true, false, strategy, dicts.id_dict_ptr, connector, default_value);
  } else if (dict_type == "package_name" && !dicts.pack_dict_ptr->empty()) {
    return new DictToAttributesConfig(output, source, default_input_value, true, false, strategy, dicts.pack_dict_ptr, connector, default_value);
  } else {
    return nullptr;
  }
}

static Config* xml_create_dict_to_attributes_v2(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  std::string connector = XmlMgr::get_filed_value<std::string>(element, "connector", "");
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "");
  std::string dict_type = XmlMgr::get_filed_value<std::string>(element, "dict_type", "");

  if (dict_type == "app_id" && !dicts.id_dict_ptr->empty()) {
    return new DictToAttributesV2Config(output, source, default_input_value, true, false, strategy, dicts.id_dict_ptr, connector, default_value);
  } else if (dict_type == "package_name" && !dicts.pack_dict_ptr->empty()) {
    return new DictToAttributesV2Config(output, source, default_input_value, true, false, strategy, dicts.pack_dict_ptr, connector, default_value);
  } else {
    return nullptr;
  }
}

static Config* xml_create_conditional_filter(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  std::vector<std::string> filter;
  std::vector<std::set<std::string>> filter_dict;
  std::vector<std::string> fields;

  std::string filter_str = XmlMgr::get_filed_value<std::string>(element, "filter", "");
  std::vector<std::string> vec_str = Calc::split_string(filter_str, ";");
  filter.reserve(vec_str.size());
  filter_dict.resize(vec_str.size());
  for (uint32_t i = 0; i < vec_str.size(); i++) {
    std::vector<std::string> value_str = Calc::split_string(vec_str[i], ",");
    for (uint32_t j = 0; j < value_str.size(); j++) {
      if (0 == j) {
        filter.emplace_back(value_str[j]);
      } else {
        filter_dict[i].insert(value_str[j]);
      }
    }
  }

  XmlMgr::get_filed_vector_value<std::string>(element, "fields", fields);

  if (unlikely(filter.empty() || filter[0].empty() || fields.empty())) {
    return nullptr;
  }

  return new ConditionalFilterConfig(output, source, default_input_value, true, false, strategy, filter, filter_dict, fields);
}

static Config* xml_create_message_filter(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  std::vector<std::string> str_filter;
  std::vector<bool> str_hit;
  std::vector<std::set<std::string>> str_filter_dict;
  std::vector<std::string> int_filter;
  std::vector<bool> int_hit;
  std::vector<std::set<int64_t>> int_filter_dict;
  int64_t filter_int = 0;

  std::string filter_str = XmlMgr::get_filed_value<std::string>(element, "str_filter", "");
  if (!filter_str.empty()) {
    std::vector<std::string> vec_str = Calc::split_string(filter_str, ";");
    str_filter.reserve(vec_str.size());
    str_hit.reserve(vec_str.size());
    str_filter_dict.resize(vec_str.size());
    for (uint32_t i = 0; i < vec_str.size(); i++) {
      std::vector<std::string> value_str = Calc::split_string(vec_str[i], ",");
      if (value_str.size() < 3) {
        return nullptr;
      }
      for (uint32_t j = 0; j < value_str.size(); j++) {
         if (0 == j) {
          str_filter.emplace_back(value_str[j]);
        } else if (1 == j) {
          if (value_str[j] == "hit") {
            str_hit.push_back(true);
          } else {
            str_hit.push_back(false);
          }
        } else {
          str_filter_dict[i].insert(value_str[j]);
        }
      }
    }
  }
  
  filter_str = XmlMgr::get_filed_value<std::string>(element, "int_filter", "");
  if (!filter_str.empty()) {
    std::vector<std::string> vec_str = Calc::split_string(filter_str, ";");
    int_filter.reserve(vec_str.size());
    int_hit.reserve(vec_str.size());
    int_filter_dict.resize(vec_str.size());
    for (uint32_t i = 0; i < vec_str.size(); i++) {
      std::vector<std::string> value_str = Calc::split_string(vec_str[i], ",");
      if (value_str.size() < 3) {
        return nullptr;
      }
      for (uint32_t j = 0; j < value_str.size(); j++) {
        if (0 == j) {
          int_filter.emplace_back(value_str[j]);
        } else if (1 == j) {
          if (value_str[j] == "hit") {
            int_hit.push_back(true);
          } else {
            int_hit.push_back(false);
          }
        } else {
          if (Calc::convert_int64(value_str[j], filter_int)) {
            int_filter_dict[i].insert(filter_int);
          } else {
            return nullptr;
          }
        }
      }
    }
  }

  std::string eventtime_key = XmlMgr::get_filed_value<std::string>(element, "eventtime_key", "");
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start_ms", 0);
  int64_t end_ms = XmlMgr::get_filed_value<int64_t>(element, "end_ms", -1);
  int64_t clip_h = XmlMgr::get_filed_value<int64_t>(element, "clip_h", -1) * 1000 * 60 * 60;

  if (unlikely((end_ms > 0 && clip_h > 0) || end_ms == 0 || clip_h == 0 || (source.size() < 2 && !eventtime_key.empty()))) {
    return nullptr;
  }

  int64_t end = std::max(end_ms, clip_h);

  // message默认不保存
  return new phx_fe::MessageFilterConfig(output, source, default_input_value, false, false, strategy, str_filter, str_hit, str_filter_dict, int_filter, int_hit, int_filter_dict, eventtime_key, start, end);
}

static Config* xml_create_message_filter_v2(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {                         
  const std::string str_filter = XmlMgr::get_filed_value<std::string>(element, "str_filter", "");
  const std::string int_filter = XmlMgr::get_filed_value<std::string>(element, "int_filter", "");

  std::string eventtime_key = XmlMgr::get_filed_value<std::string>(element, "eventtime_key", "");
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start_ms", 0);
  int64_t end_ms = XmlMgr::get_filed_value<int64_t>(element, "end_ms", -1);
  int64_t clip_h = XmlMgr::get_filed_value<int64_t>(element, "clip_h", -1) * 1000 * 60 * 60;

  if (unlikely((end_ms > 0 && clip_h > 0) || end_ms == 0 || clip_h == 0 || (source.size() < 2 && !eventtime_key.empty()))) {
    return nullptr;
  }

  int64_t end = std::max(end_ms, clip_h);

  // message默认不保存
  return new phx_fe::MessageFilterV2Config(output, source, default_input_value, false, false, strategy, str_filter, int_filter, eventtime_key, start, end);
}

// static Config* xml_create_message_filter_v2(tinyxml2::XMLElement* element,
//                                             const std::string& output,
//                                             std::vector<std::string>& source,
//                                             DefaultValue& default_input_value,
//                                             const std::vector<std::string>& strategy,
//                                             AllDicts& dicts,
//                                             const std::string& dict_path) {
//   std::vector<std::string> str_filter;
//   std::vector<bool> str_hit;
//   std::vector<size_t> str_idx;
//   std::vector<std::string> str_value;
//   std::vector<std::string> int_filter;
//   std::vector<bool> int_hit;
//   std::vector<size_t> int_idx;
//   std::vector<int64_t> int_value;
//   int64_t filter_int = 0;

//   std::string filter_str = XmlMgr::get_filed_value<std::string>(element, "filter", "");
//   if (!filter_str.empty()) {
//     std::vector<std::string> vec_str = Calc::split_string(filter_str, ";");
//     for (uint32_t i = 0; i < vec_str.size(); i++) {
//       std::vector<std::string> value_str = Calc::split_string(vec_str[i], ",");
//       if (value_str.size() < 3) {
//         return nullptr;
//       }
//       bool is_str = false;
//       if (value_str[0] == "string" || value_str[0] == "str") {
//         is_str = true;
//         str_idx.push_back(i + 1);
//       } else if (value_str[0] == "int" || value_str[0] == "int64" || value_str[0] == "int32") {
//         is_str = false;
//         int_idx.push_back(i + 1);
//       } else {
//         return nullptr;
//       }
//       for (uint32_t j = 1; j < value_str.size(); j++) {
//         if (is_str) {
//           if (1 == j) {
//             str_filter.push_back(value_str[j]);
//           } else if (2 == j) {
//             if (value_str[j] == "hit") {
//               str_hit.push_back(true);
//             } else {
//               str_hit.push_back(false);
//             }
//           } else {
//             str_value.push_back(value_str[j]);
//           }
//         } else {
//           if (1 == j) {
//             int_filter.push_back(value_str[j]);
//           } else if (2 == j) {
//             if (value_str[j] == "hit") {
//               int_hit.push_back(true);
//             } else {
//               int_hit.push_back(false);
//             }
//           } else {
//             if (Calc::convert_int64(value_str[j], filter_int)) {
//               int_value.push_back(filter_int);
//             } else {
//               return nullptr;
//             }
//           }
//         }
//       }
//     }
//   }

//   if (unlikely((str_filter.empty() && int_filter.empty()) || 
//                (str_value.size() != 0 && str_value.size() != str_filter.size()) || 
//                (int_value.size() != 0 && int_value.size() != int_filter.size()) )) {
//     return nullptr;
//   }

//   std::string eventtime_key = XmlMgr::get_filed_value<std::string>(element, "eventtime_key", "");
//   int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start_ms", 0);
//   int64_t end_ms = XmlMgr::get_filed_value<int64_t>(element, "end_ms", -1);
//   int64_t clip_h = XmlMgr::get_filed_value<int64_t>(element, "clip_h", -1) * 1000 * 60 * 60;

//   if (unlikely((end_ms > 0 && clip_h > 0) || end_ms == 0 || clip_h == 0 || (source.size() < 2 && !eventtime_key.empty()))) {
//     return nullptr;
//   }

//   int64_t end = std::max(end_ms, clip_h);

//   // message默认不保存
//   return new MessageFilterV2Config(output, source, default_input_value, false, false, strategy, str_filter, str_hit,
//                                    str_idx, str_value, int_filter, int_hit, int_idx, int_value, eventtime_key, start, end);
// }

static Config* xml_create_message_select(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  std::string select_option = XmlMgr::get_filed_value<std::string>(element, "select_option", "");
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "");
  int64_t filter_int = 0;

  if (unlikely(select_option.empty())) {
    return nullptr;
  }

  std::vector<std::string> vec_str = Calc::split_string(select_option, ";");
  if (vec_str.size() < 2) {
    return nullptr;
  }

  if (vec_str[0] == "string" || vec_str[0] == "str") {
    std::unordered_map<std::string, std::string> str_map;

    for (uint32_t j = 1; j < vec_str.size(); j++) {
      std::vector<std::string> value_str = Calc::split_string(vec_str[j], ",");
      if (value_str.size() != 2) {
        return nullptr;
      }
      auto itr = str_map.find(value_str[0]);
      if (itr == str_map.end()) {
        str_map[value_str[0]] = value_str[1];
      } else {
        return nullptr;
      }
    }
    // message默认不保存
    return new MessageSelectConfig<std::string>(output, source, default_input_value, false, false, strategy, str_map, default_value);
  } else if (vec_str[0] == "int" || vec_str[0] == "int64" || vec_str[0] == "int32") {
    std::unordered_map<int64_t, std::string> int_map;
    int64_t num = 0;

    for (uint32_t j = 1; j < vec_str.size(); j++) {
      std::vector<std::string> value_str = Calc::split_string(vec_str[j], ",");
      if (value_str.size() != 2) {
        return nullptr;
      }
      if (!Calc::convert_int64(value_str[0], num)) {
        return nullptr;
      }
      auto itr = int_map.find(num);
      if (itr == int_map.end()) {
        int_map[num] = value_str[1];
      } else {
        return nullptr;
      }
    }
    if (!default_value.empty() && !Calc::convert_int64(default_value, filter_int)) {
      return nullptr;
    }
    // message默认不保存
    return new MessageSelectConfig<int64_t>(output, source, default_input_value, false, false, strategy, int_map, default_value);
  }

  return nullptr;
}

static Config* xml_create_repetition_list(tinyxml2::XMLElement* element,
  const std::string& output,
  std::vector<std::string>& source,
  DefaultValue& default_input_value,
  const std::vector<std::string>& strategy,
  AllDicts& dicts,
  const std::string& dict_path) {
    return new RepetitionListConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_exists(tinyxml2::XMLElement* element,
                                 const std::string& output,
                                 std::vector<std::string>& source,
                                 DefaultValue& default_input_value,
                                 const std::vector<std::string>& strategy,
                                 AllDicts& dicts,
                                 const std::string& dict_path) {
  return new phx_fe::ExistsConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_len_diff(tinyxml2::XMLElement* element,
                                   const std::string& output,
                                   std::vector<std::string>& source,
                                   DefaultValue& default_input_value,
                                   const std::vector<std::string>& strategy,
                                   AllDicts& dicts,
                                   const std::string& dict_path) {
  return new phx_fe::LenDiffConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_len_ratio(tinyxml2::XMLElement* element,
                                    const std::string& output,
                                    std::vector<std::string>& source,
                                    DefaultValue& default_input_value,
                                    const std::vector<std::string>& strategy,
                                    AllDicts& dicts,
                                    const std::string& dict_path) {
  int64_t ratio_type = XmlMgr::get_filed_value<int64_t>(element, "ratio_type", 0);
  float default_value = XmlMgr::get_filed_value<float>(element, "default_value", -1);

  phx_fe::LenRatioConfig::LenRatioType lenRatioType;

  switch (ratio_type) {
    case 1: {
      lenRatioType = phx_fe::LenRatioConfig::LenRatioType::Ratio_ADD;
      break;
    }
    case 2: {
      lenRatioType = phx_fe::LenRatioConfig::LenRatioType::Ratio_DEFAULT;
      break;
    }
    default: {
      return nullptr;
    }
  }

  return new phx_fe::LenRatioConfig(output, source, default_input_value, true, false, strategy, lenRatioType, default_value);
}

static Config* xml_create_calc_stats(tinyxml2::XMLElement* element,
                                     const std::string& output,
                                     std::vector<std::string>& source,
                                     DefaultValue& default_input_value,
                                     const std::vector<std::string>& strategy,
                                     AllDicts& dicts,
                                     const std::string& dict_path) {
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "");
  DataType data_type = XmlMgr::get_filed_dtype(element, "data_type");

  if(unlikely(data_type == DATATYPE_UNKNOWN)) {
    return nullptr;
  }

  return new CalcStatsConfig(output, source, default_input_value, true, false, strategy, data_type, default_value);
}

static Config* xml_create_seq_topn(tinyxml2::XMLElement* element,
                                   const std::string& output,
                                   std::vector<std::string>& source,
                                   DefaultValue& default_input_value,
                                   const std::vector<std::string>& strategy,
                                   AllDicts& dicts,
                                   const std::string& dict_path) {
  //配置文件中start单位秒,转换为毫秒
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t topn = XmlMgr::get_filed_value<int64_t>(element, "topn", -1);
  //type默认为1按lastest, type为2按hotest
  int64_t type = XmlMgr::get_filed_value<int64_t>(element, "topn_type", 1);
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");

  if (unlikely(start < 0 || topn < 0 || type < SortType::ByTimestamp || type > SortType::ByCount)) {
    return nullptr;
  }

  return new SeqTopNConfig(output, source, default_input_value, true, false, strategy, start, topn, type, default_value);
}

static Config* xml_create_seq_topn_v2(tinyxml2::XMLElement* element,
                                      const std::string& output,
                                      std::vector<std::string>& source,
                                      DefaultValue& default_input_value,
                                      const std::vector<std::string>& strategy,
                                      AllDicts& dicts,
                                      const std::string& dict_path) {
  int64_t topn = XmlMgr::get_filed_value<int64_t>(element, "topn", -1);
  int64_t type = XmlMgr::get_filed_value<int64_t>(element, "topn_type", 1);   //type默认为1按时间, type为2按次数，type为3按val值
  int64_t reserve = XmlMgr::get_filed_value<int64_t>(element, "reserve", 0);  //默认从大到小

  if (unlikely(topn < 0 || type < SortType::ByTimestamp || type > SortType::ByValue)) {
    return nullptr;
  }

  return new phx_fe::SeqTopNV2Config(output, source, default_input_value, true, false, strategy, topn, type, reserve);
}

static Config* xml_create_seq_appcategory_topn(tinyxml2::XMLElement* element,
                                               const std::string& output,
                                               std::vector<std::string>& source,
                                               DefaultValue& default_input_value,
                                               const std::vector<std::string>& strategy,
                                               AllDicts& dicts,
                                               const std::string& dict_path) {
  //配置文件中start单位秒,转换为毫秒
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t topn = XmlMgr::get_filed_value<int64_t>(element, "topn", -1);
  //type默认为1按lastest, type为2按hotest
  int64_t type = XmlMgr::get_filed_value<int64_t>(element, "topn_type", 1);
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");
  std::string dict_name_elem = XmlMgr::get_filed_value<std::string>(element, "dict_name", "");
  if (dict_name_elem.empty()) {
    return nullptr;
  }

  if (unlikely(start < 0 || topn < 0 || type < SortType::ByTimestamp || type > SortType::ByCount)) {
    return nullptr;
  }
  hidict::DictCollector* dict_collector = reinterpret_cast<hidict::DictCollector*>(dicts.dicts_handle);
  return new phx_fe::SeqAppCategoryTopNConfig(output, source, default_input_value, true, false, strategy, start, topn, type, default_value, dict_collector, dict_name_elem);
}

static Config* xml_create_seq_n(tinyxml2::XMLElement* element,
                                const std::string& output,
                                std::vector<std::string>& source,
                                DefaultValue& default_input_value,
                                const std::vector<std::string>& strategy,
                                AllDicts& dicts,
                                const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t end = XmlMgr::get_filed_value<int64_t>(element, "end", -1) * 1000;
  int32_t clip_size = XmlMgr::get_filed_value<int32_t>(element, "clip_size", -1);
  int64_t default_value = XmlMgr::get_filed_value<int64_t>(element, "default_value", -1);

  if (unlikely(start < 0 || 0 == end)) {
    return nullptr;
  }

  return new phx_fe::SeqNConfig(output, source, default_input_value, true, false, strategy, start, end, clip_size, default_value);
}

static Config* xml_create_seq_n_v2(tinyxml2::XMLElement* element,
                                   const std::string& output,
                                   std::vector<std::string>& source,
                                   DefaultValue& default_input_value,
                                   const std::vector<std::string>& strategy,
                                   AllDicts& dicts,
                                   const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t end = XmlMgr::get_filed_value<int64_t>(element, "end", -1) * 1000;
  int32_t clip_size = XmlMgr::get_filed_value<int32_t>(element, "clip_size", -1);
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");

  if (unlikely(start < 0 || 0 == end)) {
    return nullptr;
  }

  return new SeqNV2Config(output, source, default_input_value, true, false, strategy, start, end, clip_size, default_value);
}

static Config* xml_create_seq_hit_value(tinyxml2::XMLElement* element,
                                        const std::string& output,
                                        std::vector<std::string>& source,
                                        DefaultValue& default_input_value,
                                        const std::vector<std::string>& strategy,
                                        AllDicts& dicts,
                                        const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");

  if (unlikely(start < 0)) {
    return nullptr;
  }

  return new SeqHitValueConfig(output, source, default_input_value, true, false, strategy, start, default_value);
}

static Config* xml_create_seq_hit_count_v1(tinyxml2::XMLElement* element,
                                      const std::string& output,
                                      std::vector<std::string>& source,
                                      DefaultValue& default_input_value,
                                      const std::vector<std::string>& strategy,
                                      AllDicts& dicts,
                                      const std::string& dict_path) {
  if (unlikely(source.size() != 2 && source.size() != 4)) {
    return nullptr;
  }
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int32_t max_num = XmlMgr::get_filed_value<int32_t>(element, "max_num", INT32_MAX);
  int64_t default_value = XmlMgr::get_filed_value<int64_t>(element, "default_value", -1);

  if (unlikely(start < 0 || max_num <= 0)) {
    return nullptr;
  }
  // 没有输入eventtime但是配置了防穿越，错误
  if (unlikely(source.size() == 2 && start > 0)) {
    return nullptr;
  }
  return new phx_fe::SeqHitCountV1Config(output, source, default_input_value, true, false, strategy, start, max_num, default_value);
}

static Config* xml_create_seq_hit_count_v2(tinyxml2::XMLElement* element,
                                      const std::string& output,
                                      std::vector<std::string>& source,
                                      DefaultValue& default_input_value,
                                      const std::vector<std::string>& strategy,
                                      AllDicts& dicts,
                                      const std::string& dict_path) {
  if (source.size() != 2 && source.size() != 4) {
    return nullptr;
  }
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int32_t max_num = XmlMgr::get_filed_value<int32_t>(element, "max_num", INT32_MAX);
  int64_t default_value = XmlMgr::get_filed_value<int64_t>(element, "default_value", -1);

  if (unlikely(start < 0 || max_num <= 0)) {
    return nullptr;
  }
  // 没有输入eventtime但是配置了防穿越，错误
  if (unlikely(source.size() == 2 && start > 0)) {
    return nullptr;
  }

  return new phx_fe::SeqHitCountV2Config(output, source, default_input_value, true, false, strategy, start, max_num, default_value);
}

static Config* xml_create_seq_hit_count_v3(tinyxml2::XMLElement* element,
                                      const std::string& output,
                                      std::vector<std::string>& source,
                                      DefaultValue& default_input_value,
                                      const std::vector<std::string>& strategy,
                                      AllDicts& dicts,
                                      const std::string& dict_path) {
  if (unlikely(source.size() != 2 && source.size() != 4)) {
    return nullptr;
  }
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  const std::string data_type = XmlMgr::get_filed_value<std::string>(element, "data_type", "");
  int32_t max_num = XmlMgr::get_filed_value<int32_t>(element, "max_num", INT32_MAX);
  int64_t default_value = XmlMgr::get_filed_value<int64_t>(element, "default_value", -1);

  if (unlikely(start < 0 || max_num <= 0)) {
    return nullptr;
  }
  // 没有输入eventtime但是配置了防穿越，错误
  if (unlikely(source.size() == 2 && start > 0)) {
    return nullptr;
  }

  phx_fe::SeqHitCountV3Config::DataType dataType;
  if (data_type == "int64") {
    dataType = phx_fe::SeqHitCountV3Config::DataType::int64;
  } else if (data_type == "string") {
    dataType = phx_fe::SeqHitCountV3Config::DataType::string;
  } else {
    return nullptr;
  }

  return new phx_fe::SeqHitCountV3Config(output, source, default_input_value, true, false, strategy, start, dataType, max_num, default_value);
}

static Config* xml_create_seq_hit_interval(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t default_value = XmlMgr::get_filed_value<int64_t>(element, "default_value", -1);

  if (unlikely(start < 0)) {
    return nullptr;
  }

  return new phx_fe::SeqHitIntervalConfig(output, source, default_input_value, true, false, strategy, start, default_value);
}

static Config* xml_create_seq_hit_sum(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  float default_value = XmlMgr::get_filed_value<float>(element, "default_value", -1);
  std::string default_type = XmlMgr::get_filed_value<std::string>(element, "default_type", "int64");
  return new phx_fe::SeqHitSumConfig(output, source, default_input_value, true, false, strategy, start, default_value, default_type);
}

static Config* xml_create_seq_hit_list(tinyxml2::XMLElement* element,
                                       const std::string& output,
                                       std::vector<std::string>& source,
                                       DefaultValue& default_input_value,
                                       const std::vector<std::string>& strategy,
                                       AllDicts& dicts,
                                       const std::string& dict_path) {
  return new phx_fe::SeqHitListConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_seq_hit_list_v2(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  const std::string data_type = XmlMgr::get_filed_value<std::string>(element, "data_type", "");

  phx_fe::SeqHitListV2Config::DataType dataType;
  if (data_type == "int64") {
    dataType = phx_fe::SeqHitListV2Config::DataType::int64;
  } else if (data_type == "string") {
    dataType = phx_fe::SeqHitListV2Config::DataType::string;
  } else {
    return nullptr;
  }
  return new phx_fe::SeqHitListV2Config(output, source, default_input_value, true, false, strategy, dataType);
}

static Config* xml_create_seq_statistics(tinyxml2::XMLElement* element,
                                 const std::string& output,
                                 std::vector<std::string>& source,
                                 DefaultValue& default_input_value,
                                 const std::vector<std::string>& strategy,
                                 AllDicts& dicts,
                                 const std::string& dict_path) {
  const std::string math_type = XmlMgr::get_filed_value<std::string>(element, "math_type", "");
  return new phx_fe::SeqStatisticsConfig(output, source, default_input_value, true, false, strategy, math_type);
}

static Config* xml_create_seq_sort(tinyxml2::XMLElement* element,
                                 const std::string& output,
                                 std::vector<std::string>& source,
                                 DefaultValue& default_input_value,
                                 const std::vector<std::string>& strategy,
                                 AllDicts& dicts,
                                 const std::string& dict_path) {
  const std::string sort_cols = XmlMgr::get_filed_value<std::string>(element, "sort_cols", "");
  const std::string sort_orders = XmlMgr::get_filed_value<std::string>(element, "sort_orders", "");

  return new phx_fe::SeqSortConfig(output, source, default_input_value, true, false, strategy, sort_cols, sort_orders);
}

static Config* xml_create_seq_flatten(tinyxml2::XMLElement* element,
                                 const std::string& output,
                                 std::vector<std::string>& source,
                                 DefaultValue& default_input_value,
                                 const std::vector<std::string>& strategy,
                                 AllDicts& dicts,
                                 const std::string& dict_path) {
  const std::string from_lv1 = XmlMgr::get_filed_value<std::string>(element, "from_lv1", "");
  const std::string from_lv2 = XmlMgr::get_filed_value<std::string>(element, "from_lv2", "");
  const std::string repeated_field = XmlMgr::get_filed_value<std::string>(element, "repeated_field", "");
  if (from_lv1.empty() || from_lv2.empty() || repeated_field.empty())
    return nullptr;

  return new phx_fe::SeqFlattenConfig(output, source, default_input_value, true, false, strategy, from_lv1, from_lv2, repeated_field);
}

static Config* xml_create_seq_arithmetic(tinyxml2::XMLElement* element,
                                 const std::string& output,
                                 std::vector<std::string>& source,
                                 DefaultValue& default_input_value,
                                 const std::vector<std::string>& strategy,
                                 AllDicts& dicts,
                                 const std::string& dict_path) {
  const std::string math_type = XmlMgr::get_filed_value<std::string>(element, "math_type", "");
  if (math_type.empty())
    return nullptr;

  return new phx_fe::SeqArithmeticConfig(output, source, default_input_value, true, false, strategy, math_type);
}

static Config* xml_create_cross2(tinyxml2::XMLElement* element,
                                 const std::string& output,
                                 std::vector<std::string>& source,
                                 DefaultValue& default_input_value,
                                 const std::vector<std::string>& strategy,
                                 AllDicts& dicts,
                                 const std::string& dict_path) {
  int64_t fea1_clip = XmlMgr::get_filed_value<int64_t>(element, "fea1_clip", -1);
  int64_t fea2_clip = XmlMgr::get_filed_value<int64_t>(element, "fea2_clip", -1);
  int64_t clip_size = XmlMgr::get_filed_value<int64_t>(element, "clip_size", -1);
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");

  if (unlikely(0 == fea1_clip || 0 == fea2_clip || 0 == clip_size)) {
    return nullptr;
  }

  return new Cross2Config(output, source, default_input_value, true, false, strategy, fea1_clip, fea2_clip, clip_size, default_value);
}

static Config* xml_create_stat_ctr(tinyxml2::XMLElement* element,
                                   const std::string& output,
                                   std::vector<std::string>& source,
                                   DefaultValue& default_input_value,
                                   const std::vector<std::string>& strategy,
                                   AllDicts& dicts,
                                   const std::string& dict_path) {
  int64_t min_expo = XmlMgr::get_filed_value<int64_t>(element, "min_expo", 1);
  float default_value = XmlMgr::get_filed_value<float>(element, "default_value", -1);

  if (unlikely(min_expo < 1)) {
    return nullptr;
  }

  return new phx_fe::StatCtrConfig(output, source, default_input_value, true, false, strategy, min_expo, default_value);
}

static Config* xml_create_stat_smooth_ctr(tinyxml2::XMLElement* element,
                                   const std::string& output,
                                   std::vector<std::string>& source,
                                   DefaultValue& default_input_value,
                                   const std::vector<std::string>& strategy,
                                   AllDicts& dicts,
                                   const std::string& dict_path) {
  int64_t min_expo = XmlMgr::get_filed_value<int64_t>(element, "min_expo", 1);
  float default_value = XmlMgr::get_filed_value<float>(element, "default_value", -1);
  float alpha = XmlMgr::get_filed_value<float>(element, "alpha", 0.0f);
  float beta = XmlMgr::get_filed_value<float>(element, "beta", 0.0f);
  if (unlikely(min_expo < 1)) {
    return nullptr;
  }
  if (unlikely(alpha < 0 || beta < 0)) {
    return nullptr;
  }

  return new phx_fe::StatSmoothCtrConfig(output, source, default_input_value, true, false, strategy, min_expo, default_value, alpha, beta);
}

static Config* xml_create_stat_ctr_bucket(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  float size = XmlMgr::get_filed_value<float>(element, "size", -1);
  int64_t bucket_type = XmlMgr::get_filed_value<int64_t>(element, "bucket_type", 0);
  float default_value = XmlMgr::get_filed_value<float>(element, "default_value", -1);
  float b = XmlMgr::get_filed_value<float>(element, "b", 1000);
  float a = XmlMgr::get_filed_value<float>(element, "a", 1);
  float k = XmlMgr::get_filed_value<float>(element, "k", 1);

  phx_fe::StatCtrBucketConfig::BucketType type = static_cast<phx_fe::StatCtrBucketConfig::BucketType>(bucket_type);

  if (bucket_type < 1 || bucket_type > 4) {
    return nullptr; // 如果 bucket_type 不在有效范围内，返回 nullptr
  }

  return new phx_fe::StatCtrBucketConfig(output, source, default_input_value, true, false, strategy, size, b, a, k, type, default_value);
}

static Config* xml_create_seq_app2category(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  bool dedup = XmlMgr::get_filed_value<bool>(element, "dedup", false);
  int64_t clip_size = XmlMgr::get_filed_value<int64_t>(element, "clip_size", -1);
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");
  std::string dict_name = XmlMgr::get_filed_value<std::string>(element, "dict_name", "");

  if (unlikely(0 == clip_size || start < 0 || dict_name.empty())) {
    return nullptr;
  }

  return new phx_fe::SeqApp2CategoryConfig(output, source, default_input_value, true, false, strategy, start, dedup, clip_size, default_value, reinterpret_cast<hidict::DictCollector *>(dicts.dicts_handle), dict_name);

  return nullptr;
}

static Config* xml_create_seq_filter(tinyxml2::XMLElement* element,
                                     const std::string& output,
                                     std::vector<std::string>& source,
                                     DefaultValue& default_input_value,
                                     const std::vector<std::string>& strategy,
                                     AllDicts& dicts,
                                     const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t day_n = XmlMgr::get_filed_value<int64_t>(element, "day_n", -1);
  int64_t clip_size = XmlMgr::get_filed_value<int64_t>(element, "clip_size", -1);
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");
  std::vector<std::string> filter_dict;
  const char* filters_c_str = element->Attribute("filters");
  if (filters_c_str != nullptr) {
      filter_dict = Calc::split_string(filters_c_str, ";");
  }

  if (unlikely(start < 0 || 0 == day_n || 0 == clip_size || filter_dict.empty())) {
    return nullptr;
  }

  return new phx_fe::SeqFilterConfig(output, source, default_input_value, true, false, strategy, start, day_n, clip_size, default_value, filter_dict);
}

static Config* xml_create_seq_filter_v2(tinyxml2::XMLElement* element,
                                        const std::string& output,
                                        std::vector<std::string>& source,
                                        DefaultValue& default_input_value,
                                        const std::vector<std::string>& strategy,
                                        AllDicts& dicts,
                                        const std::string& dict_path) {
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");

  return new SeqFilterV2Config(output, source, default_input_value, true, false, strategy, default_value);
}

static Config* xml_create_seq_filter_v3(tinyxml2::XMLElement* element,
                                        const std::string& output,
                                        std::vector<std::string>& source,
                                        DefaultValue& default_input_value,
                                        const std::vector<std::string>& strategy,
                                        AllDicts& dicts,
                                        const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t day_n = XmlMgr::get_filed_value<int64_t>(element, "day_n", -1);
  int64_t clip_size = XmlMgr::get_filed_value<int64_t>(element, "clip_size", -1);
  int64_t reverse = XmlMgr::get_filed_value<int64_t>(element, "reverse", 0);
  std::unordered_set<std::string> filter_dict;
  XmlMgr::get_filed_unordered_set_value<std::string>(element, "filter", filter_dict);

  if (unlikely(start < 0 || 0 == day_n || 0 == clip_size || filter_dict.empty())) {
    return nullptr;
  }
  return new SeqFilterV3Config(output, source, default_input_value, true, false, strategy, start, day_n, clip_size, reverse, filter_dict);
}

static Config* xml_create_seq_diff(tinyxml2::XMLElement* element,
                                   const std::string& output,
                                   std::vector<std::string>& source,
                                   DefaultValue& default_input_value,
                                   const std::vector<std::string>& strategy,
                                   AllDicts& dicts,
                                   const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t day_n = XmlMgr::get_filed_value<int64_t>(element, "day_n", -1);
  int64_t delta_day = XmlMgr::get_filed_value<int64_t>(element, "delta_day", -1);
  int64_t clip_size = XmlMgr::get_filed_value<int64_t>(element, "clip_size", -1);
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");

  if (unlikely(start < 0 || 0 == day_n || delta_day < 0 || 0 == clip_size)) {
    return nullptr;
  }

  return new SeqDiffConfig(output, source, default_input_value, true, false, strategy, start, day_n, delta_day, clip_size, default_value);
}

static Config* xml_create_seq_diff_v2(tinyxml2::XMLElement* element,
                                      const std::string& output,
                                      std::vector<std::string>& source,
                                      DefaultValue& default_input_value,
                                      const std::vector<std::string>& strategy,
                                      AllDicts& dicts,
                                      const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t day_n = XmlMgr::get_filed_value<int64_t>(element, "day_n", -1);
  int64_t delta_day = XmlMgr::get_filed_value<int64_t>(element, "delta_day", 0);
  int64_t clip_size = XmlMgr::get_filed_value<int64_t>(element, "clip_size", -1);
  bool status = XmlMgr::get_filed_value<bool>(element, "status", false);

  if (unlikely(start < 0 || 0 == day_n || delta_day == 0 || 0 == clip_size)) {
    return nullptr;
  }

  return new phx_fe::SeqDiffV2Config(output, source, default_input_value, true, false, strategy, start, day_n, delta_day, status, clip_size);
}

static Config* xml_create_seq_diff_daily(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t day_n = XmlMgr::get_filed_value<int64_t>(element, "day_n", -1);
  int64_t delta_day = XmlMgr::get_filed_value<int64_t>(element, "delta_day", 0);
  int64_t clip_size = XmlMgr::get_filed_value<int64_t>(element, "clip_size", -1);
  bool status = XmlMgr::get_filed_value<bool>(element, "status", false);

  if (unlikely(start < 0 || 0 == day_n || 0 == clip_size)) {
    return nullptr;
  }

  return new phx_fe::SeqDiffDailyConfig(output, source, default_input_value, true, false, strategy, start, day_n, delta_day, status, clip_size);
}

static Config* xml_create_seq_interest(tinyxml2::XMLElement* element,
                                       const std::string& output,
                                       std::vector<std::string>& source,
                                       DefaultValue& default_input_value,
                                       const std::vector<std::string>& strategy,
                                       AllDicts& dicts,
                                       const std::string& dict_path) {
  bool now_hour = XmlMgr::get_filed_value<bool>(element, "now_hour", false);
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t end = XmlMgr::get_filed_value<int64_t>(element, "end", -1) * 1000;
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");

  if (unlikely(start < 0 || 0 == end)) {
    return nullptr;
  }

  return new SeqInterestConfig(output, source, default_input_value, true, false, strategy, now_hour, start, end, default_value);
}

static Config* xml_create_seq_fresh(tinyxml2::XMLElement* element,
                                    const std::string& output,
                                    std::vector<std::string>& source,
                                    DefaultValue& default_input_value,
                                    const std::vector<std::string>& strategy,
                                    AllDicts& dicts,
                                    const std::string& dict_path) {
  bool now_hour = XmlMgr::get_filed_value<bool>(element, "now_hour", false);
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t end = XmlMgr::get_filed_value<int64_t>(element, "end", -1) * 1000;

  if (unlikely(start < 0 || 0 == end )) {
    return nullptr;
  }

  return new SeqFreshConfig(output, source, default_input_value, true, false, strategy, now_hour, start, end);
}

static Config* xml_create_seq_dsp(tinyxml2::XMLElement* element,
                                  const std::string& output,
                                  std::vector<std::string>& source,
                                  DefaultValue& default_input_value,
                                  const std::vector<std::string>& strategy,
                                  AllDicts& dicts,
                                  const std::string& dict_path) {
  bool now_hour = XmlMgr::get_filed_value<bool>(element, "now_hour", false);
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t end = XmlMgr::get_filed_value<int64_t>(element, "end", -1) * 1000;
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "NOT_EXIST");

  if (unlikely(start < 0 || 0 == end)) {
    return nullptr;
  }

  return new SeqDspConfig(output, source, default_input_value, true, false, strategy, now_hour, start, end, default_value);
}

static Config* xml_create_seq_num_convert(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  int64_t type = XmlMgr::get_filed_value<int64_t>(element, "count_type", 0);

  if (unlikely(type != 0 && type != 1 && type != 2)) {
    return nullptr;
  }

  return new SeqNumConvertConfig(output, source, default_input_value, true, false, strategy, type);
}

static Config* xml_create_seq_val_direct(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t day_n = XmlMgr::get_filed_value<int64_t>(element, "day_n", -1);
  int64_t clip_size = XmlMgr::get_filed_value<int64_t>(element, "clip_size", -1);
  float upper_bound = XmlMgr::get_filed_value<float>(element, "upper_bound", -1);
  int64_t hour_n = XmlMgr::get_filed_value<int64_t>(element, "hour_n", -1);
  int64_t second_n = XmlMgr::get_filed_value<int64_t>(element, "second_n", -1);

  int n = 0;
  if (day_n > 0) ++n;
  if (hour_n > 0) ++n;
  if (second_n > 0) ++n;
  if (unlikely(start < 0 || 0 == clip_size || 0 == upper_bound || n > 1)) {
      return nullptr;
  }
  const int64_t micro_second = hour_n > 0 ? hour_n * 60 * 60 * 1000 : second_n * 1000;
  return new phx_fe::SeqValDirectConfig(output, source, default_input_value, true, false, strategy, start, day_n,
                                        micro_second, clip_size, upper_bound);
}

static Config* xml_create_seq_val_direct_v2(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t day_n = XmlMgr::get_filed_value<int64_t>(element, "day_n", -1);
  int64_t clip_size = XmlMgr::get_filed_value<int64_t>(element, "clip_size", -1);
  float upper_bound_value = 0.0f;
  bool upper_bound_exist = XmlMgr::get_filed_value_no_default(element, "upper_bound", &upper_bound_value);
  float lower_bound_value = 0.0f;
  bool lower_bound_exist = XmlMgr::get_filed_value_no_default(element, "lower_bound", &lower_bound_value);
  int64_t hour_n = XmlMgr::get_filed_value<int64_t>(element, "hour_n", -1);

  if (unlikely(start < 0 || 0 == day_n || 0 == hour_n || 0 == clip_size ||
               (day_n > 0 && hour_n > 0))) {
      return nullptr;
  }

  return new phx_fe::SeqValDirectV2Config(output, source, default_input_value, true, false, strategy, start,
                                          day_n, hour_n, clip_size,
                                          phx_fe::SeqValDirectV2Config::Bound(upper_bound_value, upper_bound_exist),
                                          phx_fe::SeqValDirectV2Config::Bound(lower_bound_value, lower_bound_exist));
}

static Config* xml_create_seq_by_inter(tinyxml2::XMLElement* element,
                                       const std::string& output,
                                       std::vector<std::string>& source,
                                       DefaultValue& default_input_value,
                                       const std::vector<std::string>& strategy,
                                       AllDicts& dicts,
                                       const std::string& dict_path) {
  std::string inter_key = XmlMgr::get_filed_value<std::string>(element, "inter_key", "");
  std::vector<std::string> fields;
  XmlMgr::get_filed_vector_value<std::string>(element, "fields", fields);

  if (unlikely(inter_key.empty() || fields.empty())) {
    return nullptr;
  }

  return new phx_fe::SeqByInterConfig(output, source, default_input_value, true, false, strategy, inter_key, fields);
}

static Config* xml_create_seq_topn_direct(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  std::string filter_key = XmlMgr::get_filed_value<std::string>(element, "filter_key", "");
  std::vector<std::string> fields;
  XmlMgr::get_filed_vector_value<std::string>(element, "fields", fields);
  int64_t topn = XmlMgr::get_filed_value<int64_t>(element, "topn", -1);
  int64_t reserve = XmlMgr::get_filed_value<int64_t>(element, "reserve", 0);  //默认从大到小

  if (unlikely(filter_key.empty() || fields.empty() || topn < 0)) {
    return nullptr;
  }

  return new phx_fe::SeqTopnDirectConfig(output, source, default_input_value, true, false, strategy, filter_key, fields, topn, reserve);
}

static Config* xml_create_seq_day_n_direct(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  std::string eventtime_key = XmlMgr::get_filed_value<std::string>(element, "eventtime_key", "");
  std::vector<std::string> fields;
  XmlMgr::get_filed_vector_value<std::string>(element, "fields", fields);
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t day_n = XmlMgr::get_filed_value<int64_t>(element, "day_n", -1);
  int64_t clip_size = XmlMgr::get_filed_value<int64_t>(element, "clip_size", -1);

  if (unlikely(eventtime_key.empty() || fields.empty() || start < 0 || 0 == day_n || 0 == clip_size)) {
    return nullptr;
  }

  return new SeqDayNDirectConfig(output, source, default_input_value, true, false, strategy, eventtime_key, fields, start, day_n, clip_size);
}

static Config* xml_create_seq_n_hour(tinyxml2::XMLElement* element,
                                     const std::string& output,
                                     std::vector<std::string>& source,
                                     DefaultValue& default_input_value,
                                     const std::vector<std::string>& strategy,
                                     AllDicts& dicts,
                                     const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t day_n = XmlMgr::get_filed_value<int64_t>(element, "day_n", -1);
  int64_t hour = XmlMgr::get_filed_value<int64_t>(element, "hour", -1);

  if (unlikely(start < 0 || 0 == day_n || hour < 0)) {
    return nullptr;
  }

  return new phx_fe::SeqNHourConfig(output, source, default_input_value, true, false, strategy, start, day_n, hour);
}

static Config* xml_create_seq_max_value(tinyxml2::XMLElement* element,
  const std::string& output,
  std::vector<std::string>& source,
  DefaultValue& default_input_value,
  const std::vector<std::string>& strategy,
  AllDicts& dicts,
  const std::string& dict_path) {
    int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
    int64_t day_n = XmlMgr::get_filed_value<int64_t>(element, "day_n", -1);
    int64_t default_value = 0;
    bool found_default_value = XmlMgr::get_filed_value_no_default<int64_t>(element, "default_value", &default_value);
    if (unlikely(start < 0 || 0 == day_n || !found_default_value)) {
      return nullptr;
    }

    return new SeqMaxValueConfig(output, source, default_input_value, true, false, strategy, day_n, start, default_value);
}

static Config* xml_create_seq_merge(tinyxml2::XMLElement* element,
                                    const std::string& output,
                                    std::vector<std::string>& source,
                                    DefaultValue& default_input_value,
                                    const std::vector<std::string>& strategy,
                                    AllDicts& dicts,
                                    const std::string& dict_path) {
  std::string eventtime_key = XmlMgr::get_filed_value<std::string>(element, "eventtime_key", "");

  if (unlikely(eventtime_key.empty())) {
    return nullptr;
  }

  // save设置为false，算子结果为message，不可直接输出
  return new phx_fe::SeqMergeConfig(output, source, default_input_value, false, false, strategy, eventtime_key);
}

static Config* xml_create_seq_merge_v2(tinyxml2::XMLElement* element,
                                       const std::string& output,
                                       std::vector<std::string>& source,
                                       DefaultValue& default_input_value,
                                       const std::vector<std::string>& strategy,
                                       AllDicts& dicts,
                                       const std::string& dict_path) {
  std::string appid_key = XmlMgr::get_filed_value<std::string>(element, "appid_key", "");
  std::string eventtime_key = XmlMgr::get_filed_value<std::string>(element, "eventtime_key", "");

  if (unlikely(eventtime_key.empty() || appid_key.empty())) {
    return nullptr;
  }

  // save设置为false，算子结果为message，不可直接输出
  return new SeqMergeV2Config(output, source, default_input_value, false, false, strategy, appid_key, eventtime_key);
}

static Config* xml_create_seq_interval(tinyxml2::XMLElement* element,
                                       const std::string& output,
                                       std::vector<std::string>& source,
                                       DefaultValue& default_input_value,
                                       const std::vector<std::string>& strategy,
                                       AllDicts& dicts,
                                       const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;
  int64_t day_n = XmlMgr::get_filed_value<int64_t>(element, "day_n", -1);
  int64_t clip_size = XmlMgr::get_filed_value<int64_t>(element, "clip_size", -1);
  float default_mean = XmlMgr::get_filed_value<float>(element, "default_mean", -1);
  int64_t default_interval = XmlMgr::get_filed_value<float>(element, "default_interval", -1);

  if (unlikely(start < 0 || 0 == day_n || 0 == clip_size)) {
    return nullptr;
  }

  return new SeqInterval(output, source, default_input_value, true, false, strategy, start, day_n, clip_size, default_mean, default_interval);
}

static Config* xml_create_seq_avg_interval(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  int64_t time_type = XmlMgr::get_filed_value<int64_t>(element, "time_type", 0);
  float one_default_value = XmlMgr::get_filed_value<float>(element, "one_default_value", 0);
  float empty_default_value = XmlMgr::get_filed_value<float>(element, "empty_default_value", -1);

  switch (time_type) {
    case 1:
      return new phx_fe::SeqAvgIntervalConfig(output, source, default_input_value, true, false, strategy, phx_fe::SeqAvgIntervalConfig::TimeType::Day, one_default_value, empty_default_value);

    case 2:
      return new phx_fe::SeqAvgIntervalConfig(output, source, default_input_value, true, false, strategy, phx_fe::SeqAvgIntervalConfig::TimeType::Hour, one_default_value, empty_default_value);

    default:
      return nullptr;
  }
}

static Config* xml_create_seq_back_days(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;

  if (unlikely(start < 0)) {
    return nullptr;
  }
  return new SeqBackDaysConfig(output, source, default_input_value, true, false, strategy, start);
}

static Config* xml_create_seq_interval_days(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  int64_t start = XmlMgr::get_filed_value<int64_t>(element, "start", 0) * 1000;

  if (unlikely(start < 0)) {
    return nullptr;
  }
  return new SeqIntervalDaysConfig(output, source, default_input_value, true, false, strategy, start);
}

static Config *xml_create_seq_priority_merge(tinyxml2::XMLElement *element, const std::string &output,
                                             std::vector<std::string> &source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string> &strategy, AllDicts &dicts,
                                             const std::string &dict_path) {
    int64_t illegal_int = XmlMgr::get_filed_value<int64_t>(element, "illegal_int", 0);
    float illegal_float = XmlMgr::get_filed_value<float>(element, "illegal_float", 0.0);
    std::string illegal_string = XmlMgr::get_filed_value<std::string>(element, "illegal_string", "");

    return new phx_fe::SeqPriorityMergeConfig(output, source, default_input_value, true, false, strategy, illegal_int,
                                              illegal_float, illegal_string);
}

static Config* xml_create_utf8_distance(tinyxml2::XMLElement* element,
                                        const std::string& output,
                                        std::vector<std::string>& source,
                                        DefaultValue& default_input_value,
                                        const std::vector<std::string>& strategy,
                                        AllDicts& dicts,
                                        const std::string& dict_path) {
  bool cross = XmlMgr::get_filed_value<bool>(element, "cross", false);

  return new phx_fe::Utf8DistanceConfig(output, source, default_input_value, true, false, strategy, cross);
}

static Config* xml_create_utf8_is_contains(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  bool cross = XmlMgr::get_filed_value<bool>(element, "cross", false);

  return new phx_fe::Utf8IsContainsConfig(output, source, default_input_value, true, false, strategy, cross);
}

static Config* xml_create_utf8_is_equal(tinyxml2::XMLElement* element,
                                        const std::string& output,
                                        std::vector<std::string>& source,
                                        DefaultValue& default_input_value,
                                        const std::vector<std::string>& strategy,
                                        AllDicts& dicts,
                                        const std::string& dict_path) {
  bool cross = XmlMgr::get_filed_value<bool>(element, "cross", false);

  return new phx_fe::Utf8IsEqualConfig(output, source, default_input_value, true, false, strategy, cross);
}

static Config* xml_create_utf8_is_prefix(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  bool cross = XmlMgr::get_filed_value<bool>(element, "cross", false);

  return new phx_fe::Utf8IsPrefixConfig(output, source, default_input_value, true, false, strategy, cross);
}

static Config* xml_create_utf8_join(tinyxml2::XMLElement* element,
                                    const std::string& output,
                                    std::vector<std::string>& source,
                                    DefaultValue& default_input_value,
                                    const std::vector<std::string>& strategy,
                                    AllDicts& dicts,
                                    const std::string& dict_path) {
  std::string delimiter = XmlMgr::get_filed_value<std::string>(element, "delimiter", "");
  bool cross = XmlMgr::get_filed_value<bool>(element, "cross", false);

  return new Utf8JoinConfig(output, source, default_input_value, true, false, strategy, delimiter, cross);
}

static Config* xml_create_utf8_public_prefix_length(tinyxml2::XMLElement* element,
                                                    const std::string& output,
                                                    std::vector<std::string>& source,
                                                    DefaultValue& default_input_value,
                                                    const std::vector<std::string>& strategy,
                                                    AllDicts& dicts,
                                                    const std::string& dict_path) {
  bool cross = XmlMgr::get_filed_value<bool>(element, "cross", false);

  return new phx_fe::Utf8PublicPrefixLengthConfig(output, source, default_input_value, true, false, strategy, cross);
}

static Config* xml_create_utf8_prefix_repetition_string(tinyxml2::XMLElement* element,
                                                    const std::string& output,
                                                    std::vector<std::string>& source,
                                                    DefaultValue& default_input_value,
                                                    const std::vector<std::string>& strategy,
                                                    AllDicts& dicts,
                                                    const std::string& dict_path) {
  bool cross = XmlMgr::get_filed_value<bool>(element, "cross", false);

  return new Utf8PrefixRepetitionStringConfig(output, source, default_input_value, true, false, strategy, cross);
}

static Config* xml_create_utf8_length(tinyxml2::XMLElement* element,
                                      const std::string& output,
                                      std::vector<std::string>& source,
                                      DefaultValue& default_input_value,
                                      const std::vector<std::string>& strategy,
                                      AllDicts& dicts,
                                      const std::string& dict_path) {
  return new Utf8LengthConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_utf8_preprocess(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  return new Utf8PreprocessConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_utf8_split(tinyxml2::XMLElement* element,
                                     const std::string& output,
                                     std::vector<std::string>& source,
                                     DefaultValue& default_input_value,
                                     const std::vector<std::string>& strategy,
                                     AllDicts& dicts,
                                     const std::string& dict_path) {
  int64_t split_width = XmlMgr::get_filed_value<int64_t>(element, "split_width", -1);

  if (unlikely(split_width < 1)) {
    return nullptr;
  }

  return new Utf8SplitConfig(output, source, default_input_value, true, false, strategy, split_width);
}

static Config* xml_create_utf8_split_to_list(tinyxml2::XMLElement* element,
                                     const std::string& output,
                                     std::vector<std::string>& source,
                                     DefaultValue& default_input_value,
                                     const std::vector<std::string>& strategy,
                                     AllDicts& dicts,
                                     const std::string& dict_path) {
  std::string sep = XmlMgr::get_filed_value<std::string>(element, "sep", "");
  std::string filters = XmlMgr::get_filed_value<std::string>(element, "filters", "");
  if (unlikely(sep.empty())) {
    return nullptr;
  }

  return new Utf8SplitToListConfig(output, source, default_input_value, true, false, strategy, sep, filters);
}

static Config* xml_create_utf8_coincide(tinyxml2::XMLElement* element,
                                        const std::string& output,
                                        std::vector<std::string>& source,
                                        DefaultValue& default_input_value,
                                        const std::vector<std::string>& strategy,
                                        AllDicts& dicts,
                                        const std::string& dict_path) {
  bool cross = XmlMgr::get_filed_value<bool>(element, "cross", false);

  return new phx_fe::Utf8CoincideConfig(output, source, default_input_value, true, false, strategy, cross);
}

static Config* xml_create_utf8_filter(tinyxml2::XMLElement* element,
                                      const std::string& output,
                                      std::vector<std::string>& source,
                                      DefaultValue& default_input_value,
                                      const std::vector<std::string>& strategy,
                                      AllDicts& dicts,
                                      const std::string& dict_path) {
  int64_t length = XmlMgr::get_filed_value<int64_t>(element, "length", -1);

  if (unlikely(length < 0)) {
    return nullptr;
  }

  return new Utf8FilterConfig(output, source, default_input_value, true, false, strategy, length);
}

static Config* xml_create_utf8_get_prefix(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  int64_t max_size = XmlMgr::get_filed_value<int64_t>(element, "max_size", -1);

  if (unlikely(max_size < 0)) {
    return nullptr;
  }

  return new phx_fe::Utf8GetPrefixConfig(output, source, default_input_value, true, false, strategy, max_size);
}

static Config* xml_create_utf8_sub_str(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  int64_t len = XmlMgr::get_filed_value<int64_t>(element, "len", -1);
  if (unlikely(len < 0)) {
    return nullptr;
  }
  return new phx_fe::Utf8SubStrConfig(output, source, default_input_value, true, false, strategy, len);
}

static Config* xml_create_utf8_ip_to_list(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  const std::string sep = XmlMgr::get_filed_value<std::string>(element, "sep", "");
  if (unlikely(sep.empty())) {
    return nullptr;
  }
  return new phx_fe::Utf8IpToListConfig(output, source, default_input_value, true, false, strategy, sep);
}

static Config* xml_create_utf8_get_re_result(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  return new phx_fe::Utf8GetReresultConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_utf8_repetition_string(tinyxml2::XMLElement* element,
                                                 const std::string& output,
                                                 std::vector<std::string>& source,
                                                 DefaultValue& default_input_value,
                                                 const std::vector<std::string>& strategy,
                                                 AllDicts& dicts,
                                                 const std::string& dict_path) {
  return new Utf8RepetitionStringConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_time_hour(tinyxml2::XMLElement* element,
                                    const std::string& output,
                                    std::vector<std::string>& source,
                                    DefaultValue& default_input_value,
                                    const std::vector<std::string>& strategy,
                                    AllDicts& dicts,
                                    const std::string& dict_path) {
  return new phx_fe::TimeHourConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_time_hour_scope(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  std::vector<int64_t> hour_boundaries;
  std::vector<std::string> name_boundaries;
  XmlMgr::get_filed_vector_value<int64_t>(element, "hour_boundary", hour_boundaries);
  XmlMgr::get_filed_vector_value<std::string>(element, "name_boundary", name_boundaries);

  if (unlikely(hour_boundaries.size() + 1 != name_boundaries.size())) {
    return nullptr;
  }

  return new phx_fe::TimeHourScopeConfig(output, source, default_input_value, true, false, strategy, hour_boundaries, name_boundaries);
}

static Config* xml_create_time_day(tinyxml2::XMLElement* element,
                                   const std::string& output,
                                   std::vector<std::string>& source,
                                   DefaultValue& default_input_value,
                                   const std::vector<std::string>& strategy,
                                   AllDicts& dicts,
                                   const std::string& dict_path) {
  return new phx_fe::TimeDayConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_time_day_scope(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  std::vector<int64_t> day_boundaries;
  std::vector<std::string> name_boundaries;
  XmlMgr::get_filed_vector_value<int64_t>(element, "day_boundary", day_boundaries);
  XmlMgr::get_filed_vector_value<std::string>(element, "name_boundary", name_boundaries);

  if (unlikely(day_boundaries.size() + 1 != name_boundaries.size())) {
    return nullptr;
  }

  return new phx_fe::TimeDayScopeConfig(output, source, default_input_value, true, false, strategy, day_boundaries, name_boundaries);
}

static Config* xml_create_time_week(tinyxml2::XMLElement* element,
                                    const std::string& output,
                                    std::vector<std::string>& source,
                                    DefaultValue& default_input_value,
                                    const std::vector<std::string>& strategy,
                                    AllDicts& dicts,
                                    const std::string& dict_path) {
  return new phx_fe::TimeWeekConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_time_week_scope(tinyxml2::XMLElement* element,
                                          const std::string& output,
                                          std::vector<std::string>& source,
                                          DefaultValue& default_input_value,
                                          const std::vector<std::string>& strategy,
                                          AllDicts& dicts,
                                          const std::string& dict_path) {
  std::vector<int64_t> week_boundaries;
  std::vector<std::string> name_boundaries;
  XmlMgr::get_filed_vector_value<int64_t>(element, "week_boundary", week_boundaries);
  XmlMgr::get_filed_vector_value<std::string>(element, "name_boundary", name_boundaries);

  if (unlikely(week_boundaries.size() + 1 != name_boundaries.size())) {
    return nullptr;
  }

  return new phx_fe::TimeWeekScopeConfig(output, source, default_input_value, true, false, strategy, week_boundaries, name_boundaries);
}

static Config* xml_create_time_month(tinyxml2::XMLElement* element,
                                     const std::string& output,
                                     std::vector<std::string>& source,
                                     DefaultValue& default_input_value,
                                     const std::vector<std::string>& strategy,
                                     AllDicts& dicts,
                                     const std::string& dict_path) {
  return new phx_fe::TimeMonthConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_time_month_scpoe(tinyxml2::XMLElement* element,
                                           const std::string& output,
                                           std::vector<std::string>& source,
                                           DefaultValue& default_input_value,
                                           const std::vector<std::string>& strategy,
                                           AllDicts& dicts,
                                           const std::string& dict_path) {
  std::vector<int64_t> month_boundaries;
  std::vector<std::string> name_boundaries;
  XmlMgr::get_filed_vector_value<int64_t>(element, "month_boundary", month_boundaries);
  XmlMgr::get_filed_vector_value<std::string>(element, "name_boundary", name_boundaries);

  if (unlikely(month_boundaries.size() + 1 != name_boundaries.size())) {
    return nullptr;
  }

  return new phx_fe::TimeMonthScopeConfig(output, source, default_input_value, true, false, strategy, month_boundaries, name_boundaries);
}

static Config* xml_create_time_holiday_scope(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  std::map<std::string, std::vector<int64_t>> holiday_boundaries;
  std::vector<std::string> name_boundaries;
  XmlMgr::get_filed_map_value<int64_t>(element, "holiday_boundary", holiday_boundaries);
  XmlMgr::get_filed_vector_value<std::string>(element, "name_boundary", name_boundaries);
  std::string default_value = XmlMgr::get_filed_value<std::string>(element, "default_value", "");

  for (auto& pair : holiday_boundaries) {
    if (unlikely(pair.second.size() / 4 != name_boundaries.size())) {
      return nullptr;
    }
  }

  return new phx_fe::TimeHolidayScopeConfig(output, source, default_input_value, true, false, strategy, holiday_boundaries, name_boundaries, default_value);
}

static Config* xml_create_cross_by_grams_seg(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  if (unlikely(source.size() < 2)) {
    return nullptr;
  }
  std::vector<std::string> segment_source;
  segment_source.push_back(source[0]);

  std::vector<std::string> get_first_source;
  get_first_source.push_back("temp:0");

  std::vector<std::string> fully_cross_source;
  fully_cross_source.push_back("temp:0");
  fully_cross_source.push_back(source[1]);

  std::shared_ptr<Config> segment = std::shared_ptr<Config>(xml_create_segment(element, output, segment_source, default_input_value, {}, dicts, dict_path));
  std::shared_ptr<Config> utf8_filter = std::shared_ptr<Config>(xml_create_utf8_filter(element, output, get_first_source, default_input_value, {}, dicts, dict_path));
  std::shared_ptr<Config> clip = std::shared_ptr<Config>(xml_create_clip(element, output, get_first_source, default_input_value, {}, dicts, dict_path));
  std::shared_ptr<Config> fully_cross = std::shared_ptr<Config>(xml_create_fully_cross(element, output, fully_cross_source, default_input_value, {}, dicts, dict_path));
  std::shared_ptr<Config> vocab_map = std::shared_ptr<Config>(xml_create_vocab_map(element, output, get_first_source, default_input_value, {}, dicts, dict_path));

  if (unlikely(!segment || !utf8_filter || !clip || !fully_cross || !vocab_map)) {
    return nullptr;
  }
  return new CrossByGramsSegConfig(output, source, default_input_value, true, false, strategy, {segment, utf8_filter, clip, fully_cross, vocab_map});
}
static Config* xml_create_seq_cross_hash_bits(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  int64_t clip_size = XmlMgr::get_filed_value(element, "clip_size", std::numeric_limits<int32_t>::max());
  if (clip_size <= 0) {
    clip_size = std::numeric_limits<int32_t>::max();
  }
  std::vector<std::string> modified_strategy(strategy);
  modified_strategy.emplace_back("hash_slot");
  return new phx_fe::SeqCrossHashBits(output, source, default_input_value, true, false, strategy, (int32_t)clip_size);
}

static Config* xml_create_query_dict(tinyxml2::XMLElement* element,
                                             const std::string& output,
                                             std::vector<std::string>& source,
                                             DefaultValue& default_input_value,
                                             const std::vector<std::string>& strategy,
                                             AllDicts& dicts,
                                             const std::string& dict_path) {
  std::string dict_name = XmlMgr::get_filed_value<std::string>(element, "dict_name", "");
  std::string output_fields = XmlMgr::get_filed_value<std::string>(element, "output_fields", "");
  std::string default_int64_value = XmlMgr::get_filed_value<std::string>(element, "default_int64_value", "");
  std::string default_float_value = XmlMgr::get_filed_value<std::string>(element, "default_float_value", "");
  auto default_string_value_c = element->Attribute("default_string_value");
  if (default_string_value_c == nullptr) {
    return nullptr;
  }

  if (unlikely(dict_name.empty() || output_fields.empty() || default_int64_value.empty() || default_float_value.empty())) {
    return nullptr;
  }
  auto handler = dicts.dicts_handle;
  if (handler == 0) {
    return nullptr;
  }
  int64_t default_int64 = 0;
  if(!Calc::convert_int64(default_int64_value, default_int64)) {
    return nullptr;
  };

  float default_float = 0;
  if(!Calc::convert_float(default_float_value, default_float)) {
    return nullptr;
  };
  return new phx_fe::QueryDictConfig(output, source, default_input_value, true, false, strategy, 
    reinterpret_cast<hidict::DictCollector *>(handler), dict_name, output_fields, default_int64, default_float, default_string_value_c);
}

static Config* xml_pre_connect_to_string(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  std::string connector = XmlMgr::get_filed_value<std::string>(element, "connector", "_");
  std::vector<std::string> prefixs;
  XmlMgr::get_filed_vector_value<std::string>(element, "prefixs", prefixs);

  if (unlikely(source.size() != prefixs.size())) {
    return nullptr;
  }

  return new phx_fe::PreConnectToStringConfig(output, source, default_input_value, true, false, strategy, connector, prefixs);
}

static Config* xml_create_seq_coalesce(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  if (source.size() < 2) return nullptr;
  return new phx_fe::SeqCoalesceConfig(output, source, default_input_value, true, false, strategy);
}

static Config* xml_create_seq_pb_clip(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
    std::string event_time_key = XmlMgr::get_filed_value<std::string>(element, "eventtime_key", "");
    if (unlikely(event_time_key.empty())) {
      return nullptr;
    }
    int64_t start_day = XmlMgr::get_filed_value<int64_t>(element, "start_day", int64_t(-1));
    int64_t end_day = XmlMgr::get_filed_value<int64_t>(element, "end_day", int64_t(999));
    if (start_day > end_day) {
      return nullptr;
    }
    return new phx_fe::SeqPbClip(output, source, default_input_value, true, false, strategy, start_day, end_day, event_time_key); 

 }

static Config* xml_create_seq_ratio(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  if (source.size() != 1) return nullptr;
  float default_value = XmlMgr::get_filed_value<float>(element, "default_value", -1);
  return new phx_fe::SeqRatioConfig(output, source, default_input_value, true, false, strategy, default_value);
}

static Config* xml_create_seq_div(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  if (source.size() != 2) return nullptr;
  float default_value = XmlMgr::get_filed_value<float>(element, "default_value", -1);
  return new phx_fe::SeqDivConfig(output, source, default_input_value, true, false, strategy, default_value);
}

static Config* xml_create_seq_hit_value_v2(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  if (source.size() < 2) return nullptr;
  int64_t default_int64_value = XmlMgr::get_filed_value<int64_t>(element, "default_int64_value", -1);
  float default_float_value = XmlMgr::get_filed_value<float>(element, "default_float_value", -1);
  std::string default_string_value = XmlMgr::get_filed_value<std::string>(element, "default_string_value", "NOT_EXIST");
  return new phx_fe::SeqHitValueV2Config(output, source, default_input_value, true, false, strategy, default_int64_value, default_float_value, default_string_value);
}

static Config* xml_create_combine(tinyxml2::XMLElement* element,
                                         const std::string& output,
                                         std::vector<std::string>& source,
                                         DefaultValue& default_input_value,
                                         const std::vector<std::string>& strategy,
                                         AllDicts& dicts,
                                         const std::string& dict_path) {
  int max_size = XmlMgr::get_filed_value<int>(element, "max_size", -1);
  if (max_size < 0) {
    max_size = std::numeric_limits<int>::max();
  }
  return new phx_fe::CombineConfig(output, source, default_input_value, true, false, strategy, max_size);
}

static Config* xml_create_query_stats_dict(tinyxml2::XMLElement* element,
                                                   const std::string& output,
                                                   std::vector<std::string>& source,
                                                   DefaultValue& default_input_value,
                                                   const std::vector<std::string>& strategy,
                                                   AllDicts& dicts,
                                                   const std::string& dict_path) {
  std::string dict_name = XmlMgr::get_filed_value<std::string>(element, "dict_name", "");
  std::string output_fields = XmlMgr::get_filed_value<std::string>(element, "output_fields", "");
  std::string keys = XmlMgr::get_filed_value<std::string>(element, "keys", "");
  std::string types = XmlMgr::get_filed_value<std::string>(element, "types", "");
  std::string default_int64_value = XmlMgr::get_filed_value<std::string>(element, "default_int64_value", "");
  std::string default_float_value = XmlMgr::get_filed_value<std::string>(element, "default_float_value", "");
  auto default_string_value_c = element->Attribute("default_string_value");

  if (default_string_value_c == nullptr) {
    return nullptr;
  }

  if (unlikely(dict_name.empty() || output_fields.empty() || keys.empty() || types.empty() || default_int64_value.empty() || default_float_value.empty())) {
    return nullptr;
  }
  auto handler = dicts.dicts_handle;
  if (handler == 0) {
    return nullptr;
  }
  int64_t default_int64 = 0;
  if(!Calc::convert_int64(default_int64_value, default_int64)) {
    return nullptr;
  };

  float default_float = 0;
  if(!Calc::convert_float(default_float_value, default_float)) {
    return nullptr;
  };
  return new phx_fe::QueryStatsDictConfig(output, source, default_input_value, true, false, strategy, 
    reinterpret_cast<hidict::DictCollector *>(handler), dict_name, output_fields, keys, types,
    default_int64, default_float, default_string_value_c);
}

static Config* xml_create_query_custom_dict(tinyxml2::XMLElement* element,
                                            const std::string& output,
                                            std::vector<std::string>& source,
                                            DefaultValue& default_input_value,
                                            const std::vector<std::string>& strategy,
                                            AllDicts& dicts,
                                            const std::string& dict_path) {
  std::string dict_name = XmlMgr::get_filed_value<std::string>(element, "dict_name", "");
  std::string prefix = XmlMgr::get_filed_value<std::string>(element, "prefix", "");

  int data_type = -1;

  int64_t default_int64_value = -1;
  bool has_default_int64 = XmlMgr::get_filed_value_no_default(element, "default_int64_value", &default_int64_value);

  float default_float_value = -1.0f;
  bool has_default_float = XmlMgr::get_filed_value_no_default(element, "default_float_value", &default_float_value);

  std::string default_string_value;
  bool has_default_string = XmlMgr::get_filed_value_no_default(element, "default_string_value", &default_string_value);

  std::string key_type;
  if (!XmlMgr::get_filed_value_no_default(element, "key_type", &key_type)) {
    THROW_ERROR("key_type not found! config name = [" + output + "]");
    return nullptr;
  }

  if (unlikely(dict_name.empty())) {
    return nullptr;
  }

  if (static_cast<int>(has_default_int64) + static_cast<int>(has_default_float) + static_cast<int>(has_default_string) != 1) {
    return nullptr;
  }

  auto handler = dicts.dicts_handle;
  if (handler == 0) {
    return nullptr;
  }
  if (has_default_int64) data_type = 0;
  if (has_default_string) data_type = 1;
  if (has_default_float) data_type = 2;

  return new phx_fe::QueryCustomDictConfig(output, source, default_input_value, true, false, strategy, 
    reinterpret_cast<hidict::DictCollector *>(handler), dict_name, prefix,
    default_int64_value, default_string_value, default_float_value, data_type, key_type);
}

/*
  新加一个提取类只需要三步：
  1 继承Config实现一个提取子类 XxxConfig
  2 实现从xml提取属性的函数xml_create_xxx
  3 将特征类名称和xml_create_xxx添加到xml_config_creator_map定义中
*/
Config* XmlConfigMgr::create_config(const std::string& type,
                                    tinyxml2::XMLElement* element,
                                    const std::string& output,
                                    std::vector<std::string>& source,
                                    DefaultValue& default_input_value,
                                    const std::vector<std::string>& strategy,
                                    AllDicts& dicts,
                                    const std::string& dict_path) {
  auto itr = xml_config_creator_map.find(type);
  Config* config = nullptr;
  if (itr != xml_config_creator_map.end()) {
    config = itr->second(element, output, source, default_input_value, strategy, dicts, dict_path);
  }
  if (config == nullptr) {
    return config;
  }
  config->slot_id_ = -1;
  uint16_t u16_slot_id = 0;
  const char* slot_c_str = element->Attribute("slot");
  if (slot_c_str != nullptr) {
    if (!Calc::convert_uint16(slot_c_str, u16_slot_id)) {
      THROW_ERROR("slot convert failed, slot:" + std::string(slot_c_str) + ", name:" +  config->output_);
    }
    if (u16_slot_id == 0) {
      THROW_ERROR("slot convert failed, slot shoud not be 0, name:" +  config->output_);
    }
    config->slot_id_ = u16_slot_id;
  }
  return config;
}

const std::map<std::string, XmlConfigMgr::XmlConfigCreatorFunc> XmlConfigMgr::xml_config_creator_map = {
  {"bucketize",                 xml_create_bucketize},
  {"hash",                      xml_create_hash},
  {"vocab_list",                xml_create_vocab_list},
  {"vocab_set",                 xml_create_vocab_set},
  {"vocab_map",                 xml_create_vocab_map},
  {"is_match_str",              xml_create_is_match_str},
  {"combine",                   xml_create_combine},
  {"direct",                    xml_create_direct},
  {"filter_appid",              xml_create_filter_appid},
  {"max_expo_appid",            xml_create_max_expo_appid},
  {"max_123_class",             xml_create_max_123_class},
  {"nearest_expo_appid",        xml_create_nearest_expo_appid},
  {"expo_appid_count",          xml_create_expo_appid_count},
  {"expo_123_count",            xml_create_expo_123_count},
  {"expo_123_count_v2",         xml_create_expo_123_count_v2},
  {"nearest_expo_days",         xml_create_nearest_expo_days},
  {"appid_cross",               xml_create_appid_cross},
  {"to_feature",                xml_create_to_feature},
  {"direct_to_feature_v2",      xml_create_direct_to_feature_v2},
  {"to_batch_feature",          xml_create_to_batch_feature},
  {"identity",                  xml_create_identity},
  {"string_to_int64",           xml_create_string_to_int64},
  {"appid_to_123_class",        xml_create_appid_to_123_class},
  {"trans_type",                xml_create_trans_type},
  {"fully_cross",               xml_create_fully_cross},
  {"connect",                   xml_create_connect},
  {"connect_all_to_string",     xml_create_connect_all_to_string},
  {"cross_hash_bits",           xml_create_cross_hash_bits},
  {"cross_hash_bits_v2",        xml_create_cross_hash_bits_v2},
  {"get_valid_value",           xml_create_get_valid_value},
  {"get_valid_value_v2",        xml_create_get_valid_value_v2},
  {"act_value",                 xml_create_act_value},
  {"int64_offset",              xml_create_int64_offset},
  {"int64_difference",          xml_create_int64_difference},
  {"clip",                      xml_create_clip},
  {"segment",                   xml_create_segment},
  {"dict_to_attributes",        xml_create_dict_to_attributes},
  {"dict_to_attributes_v2",     xml_create_dict_to_attributes_v2},
  {"conditional_filter",        xml_create_conditional_filter},
  {"message_filter",            xml_create_message_filter},
  {"message_filter_v2",         xml_create_message_filter_v2},
  {"message_select",            xml_create_message_select},
  {"exists",                    xml_create_exists},
  {"len_diff",                  xml_create_len_diff},
  {"len_ratio",                 xml_create_len_ratio},
  {"calc_stats",                xml_create_calc_stats},
  {"seq_topn",                  xml_create_seq_topn},
  {"seq_topn_v2",               xml_create_seq_topn_v2},
  {"seq_appcategory_topn",      xml_create_seq_appcategory_topn},
  {"seq_n",                     xml_create_seq_n},
  {"seq_n_v2",                  xml_create_seq_n_v2},
  {"seq_hit_count_v1",          xml_create_seq_hit_count_v1},
  {"seq_hit_count_v2",          xml_create_seq_hit_count_v2},
  {"seq_hit_count_v3",          xml_create_seq_hit_count_v3},
  {"seq_hit_value",             xml_create_seq_hit_value},
  {"seq_hit_interval",          xml_create_seq_hit_interval},
  {"seq_hit_sum",               xml_create_seq_hit_sum},
  {"seq_hit_list",              xml_create_seq_hit_list},
  {"seq_hit_list_v2",           xml_create_seq_hit_list_v2},
  {"cross2",                    xml_create_cross2},
  {"stat_ctr",                  xml_create_stat_ctr},
  {"stat_smooth_ctr",           xml_create_stat_smooth_ctr},
  {"stat_ctr_bucket",           xml_create_stat_ctr_bucket},
  {"seq_app2category",          xml_create_seq_app2category},
  {"seq_filter",                xml_create_seq_filter},
  {"seq_filter_v2",             xml_create_seq_filter_v2},
  {"seq_filter_v3",             xml_create_seq_filter_v3},
  {"seq_diff",                  xml_create_seq_diff},
  {"seq_diff_v2",               xml_create_seq_diff_v2},
  {"seq_diff_daily",            xml_create_seq_diff_daily},
  {"seq_interest",              xml_create_seq_interest},
  {"seq_fresh",                 xml_create_seq_fresh},
  {"seq_dsp",                   xml_create_seq_dsp},
  {"seq_cross_hash_bits",       xml_create_seq_cross_hash_bits},
  {"seq_num_convert",           xml_create_seq_num_convert},
  {"seq_val_direct",            xml_create_seq_val_direct},
  {"seq_val_direct_v2",         xml_create_seq_val_direct_v2},
  {"seq_by_inter",              xml_create_seq_by_inter},
  {"seq_topn_direct",           xml_create_seq_topn_direct},
  {"seq_day_n_direct",          xml_create_seq_day_n_direct},
  {"seq_n_hour",                xml_create_seq_n_hour},
  {"seq_max_value",             xml_create_seq_max_value},
  {"seq_merge",                 xml_create_seq_merge},
  {"seq_merge_v2",              xml_create_seq_merge_v2},
  {"seq_interval",              xml_create_seq_interval},
  {"seq_avg_interval",          xml_create_seq_avg_interval},
  {"seq_back_days",             xml_create_seq_back_days},
  {"seq_interval_days",         xml_create_seq_interval_days},
  {"seq_pb_clip",               xml_create_seq_pb_clip},
  {"seq_priority_merge",        xml_create_seq_priority_merge},
  {"uft8_distance",             xml_create_utf8_distance},
  {"uft8_is_contains",          xml_create_utf8_is_contains},
  {"uft8_is_equal",             xml_create_utf8_is_equal},
  {"uft8_is_prefix",            xml_create_utf8_is_prefix},
  {"uft8_join",                 xml_create_utf8_join},
  {"uft8_public_prefix_length", xml_create_utf8_public_prefix_length},
  {"uft8_length",               xml_create_utf8_length},
  {"uft8_preprocess",           xml_create_utf8_preprocess},
  {"uft8_split",                xml_create_utf8_split},
  {"uft8_coincide",             xml_create_utf8_coincide},
  {"uft8_filter",               xml_create_utf8_filter},
  {"utf8_distance",             xml_create_utf8_distance},
  {"utf8_is_contains",          xml_create_utf8_is_contains},
  {"utf8_is_equal",             xml_create_utf8_is_equal},
  {"utf8_is_prefix",            xml_create_utf8_is_prefix},
  {"utf8_join",                 xml_create_utf8_join},
  {"utf8_public_prefix_length", xml_create_utf8_public_prefix_length},
  {"utf8_length",               xml_create_utf8_length},
  {"utf8_preprocess",           xml_create_utf8_preprocess},
  {"utf8_split",                xml_create_utf8_split},
  {"utf8_split_to_list",        xml_create_utf8_split_to_list},
  {"utf8_ip_to_list",           xml_create_utf8_ip_to_list},
  {"utf8_coincide",             xml_create_utf8_coincide},
  {"utf8_filter",               xml_create_utf8_filter},
  {"utf8_get_prefix",           xml_create_utf8_get_prefix},
  {"utf8_sub_str",              xml_create_utf8_sub_str},
  {"utf8_get_re_result",        xml_create_utf8_get_re_result},
  {"utf8_repetition_string",    xml_create_utf8_repetition_string},
  {"utf8_prefix_repetition_string", xml_create_utf8_prefix_repetition_string},
  {"time_hour",                 xml_create_time_hour},
  {"time_hour_scope",           xml_create_time_hour_scope},
  {"time_day",                  xml_create_time_day},
  {"time_day_scope",            xml_create_time_day_scope},
  {"time_week",                 xml_create_time_week},
  {"time_week_scope",           xml_create_time_week_scope},
  {"time_month",                xml_create_time_month},
  {"time_month_scope",          xml_create_time_month_scpoe},
  {"time_holiday_scope",        xml_create_time_holiday_scope},
  {"cross_by_grams_seg",        xml_create_cross_by_grams_seg},
  {"repetition_list",           xml_create_repetition_list},
  {"query_dict",                xml_create_query_dict},
  {"query_stats_dict",          xml_create_query_stats_dict},
  {"query_custom_dict",         xml_create_query_custom_dict},
  {"pre_connect_to_string",     xml_pre_connect_to_string},
  {"seq_coalesce",              xml_create_seq_coalesce},
  {"seq_ratio",                 xml_create_seq_ratio},
  {"seq_div",                   xml_create_seq_div},
  {"seq_hit_value_v2",          xml_create_seq_hit_value_v2},
  {"seq_statistics",            xml_create_seq_statistics},
  {"seq_sort",                  xml_create_seq_sort},
  {"seq_flatten",               xml_create_seq_flatten},
  {"seq_arithmetic",            xml_create_seq_arithmetic}
};