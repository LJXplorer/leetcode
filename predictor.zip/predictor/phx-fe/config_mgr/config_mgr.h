#ifndef FE_CONFIG_MGR
#define FE_CONFIG_MGR

#include "phx-fe/config/config_seq.h"
#include "phx-fe/config/config_base.h"
#include "phx-fe/config/config_utf8.h"
#include "phx-fe/config/phx_config_time.h"
#include "phx-fe/config/config_gather.h"
#include "phx-fe/config/phx_config_seq.h"
#include "phx-fe/config/phx_config_base.h"
#include "phx-fe/config/config.h"

struct ConfigWithFlag {
  std::shared_ptr<Config> config;
  bool flag;
};

class ConfigMgr {
 public:
  #if FASTFLOW_DEBUG_ENABLE
  static void display(std::vector<std::shared_ptr<Config>>& vec) {
    LogDebug("display:");

    for (uint32_t i = 0; i < vec.size(); i++) {
      for (auto& input : vec[i]->inputs_) {
        LogDebug("input name:{} idx:{}", input.name, input.idx);
      }

      LogDebug("output:{}", vec[i]->output_);
      LogDebug("save:{}", vec[i]->save_);
    }
  }
  #endif

 protected:
  static bool all_inputs_have_meet(const std::vector<Input>& inputs,
                                   const std::set<std::string>& set) {
    for (auto& input : inputs) {
      if (input.from_request == false && input.from_userction == false && !input.name_parts.empty() && set.count(input.name_parts[0]) == 0) {
        return false;
      }
    }
    return true;
  }

  static void order(std::vector<std::shared_ptr<Config>>& all_config) {
    std::vector<ConfigWithFlag> all_config_with_flag;
    for (auto config : all_config) {
      all_config_with_flag.push_back({config, false});
    }
    const uint32_t size = all_config_with_flag.size();
    std::set<std::string> set = {};

    all_config.clear();

    while (true) {
      uint32_t count = 0;
      for (auto& config_with_flag : all_config_with_flag) {
        auto config = config_with_flag.config;
        bool have_met = all_inputs_have_meet(config->inputs_, set);

        if (!config_with_flag.flag && have_met) {
          all_config.push_back(config);
          config_with_flag.flag = true;
          if (unlikely(!set.insert(config->output_).second)) {
            THROW_ERROR("config have duplicate definition of name, error happens, name:" + config->output_);
          }
          count++;
        }
      }
      if (size == all_config.size()) {
        break;
      }
      if (count == 0) {
        std::string unkonw_names;
        for (auto& config_with_flag : all_config_with_flag) {
          if (!config_with_flag.flag) {
            unkonw_names.append(config_with_flag.config->output_).append(",");
          }
        }
        if (',' == unkonw_names.back()) {
          unkonw_names.pop_back();
        }
        THROW_ERROR("count = 0, config have unkonw input, error happens, name:" + unkonw_names);
      }
    }
  }

  static void select_config(std::vector<std::string>& version_values,
                            std::vector<std::shared_ptr<Config>>& configs) {
    std::map<std::string, std::shared_ptr<Config>> name2config;
    for (auto& config : configs) {
      name2config[config->output_] = config;
    }

    std::set<std::string> filter_set;
    std::queue<const std::string*> queue;
    for (auto& str : version_values) {
      auto iter = name2config.find(str);
      if (iter != name2config.end()) {
        queue.push(&str);
      } else {
        THROW_ERROR("config not find, value_name:" + str);
        return;
      }
    }

    while (!queue.empty()) {
      const std::string& name = *queue.front();
      queue.pop();
      auto iter = name2config.find(name);
      //检测set中是否已有对应的config_name，避免重复加载相同的input
      auto set_iter = filter_set.find(name);
      if (iter != name2config.end() && set_iter == filter_set.end()) {
        auto& config = iter->second;
        for (Input& input : config->inputs_) {
          queue.push(&input.name);
          if (!input.from_request && !input.name_parts.empty()) {
            queue.push(&input.name_parts[0]);
          }
          LogDebug("push {}", input.name);
        }
        filter_set.insert(name);

        LogDebug("insert {}", name);
      }
    }

    std::vector<std::shared_ptr<Config>> all_configs;
    all_configs.swap(configs);

    for (auto& config : all_configs) {
      if (filter_set.find(config->output_) != filter_set.end()) {
        configs.push_back(config);
      }
    }
  }

  static void select_config(VersionInfo& version_info,
                            std::vector<std::shared_ptr<Config>>& configs,
                            const std::unordered_map<std::string, std::shared_ptr<Config>>& slot_config,
                            const std::unordered_map<std::string, std::shared_ptr<Config>>& name_config) {
    std::set<std::string> filter_set;
    std::queue<const std::string*> queue;

    //先插入slot_id
    auto pushConfigQueue = [&](const std::vector<std::string>& name_list) -> bool {
      for (const auto& str : name_list) {
        auto iter = slot_config.find(str);
        if (iter != slot_config.end()) {
          queue.push(&str);
        } else {
          THROW_ERROR("config not find, value_name:" + str);
          return false;
        }
      }
      return true;
    };

    //再插入name
    auto pushConfig2Queue = [&](const std::vector<std::string>& name_list) -> bool {
      for (const auto& str : name_list) {
        auto iter = name_config.find(str);
        if (iter != name_config.end()) {
          queue.push(&str);
        } else {
          THROW_ERROR("config not find, value_name:" + str);
          return false;
        }
      }
      return true;
    };

    if (unlikely(!pushConfigQueue(version_info.values))) return;
    if (unlikely(!pushConfig2Queue(version_info.labels))) return;
    if (unlikely(!pushConfig2Queue(version_info.weights))) return;
    // 迁移后删除
    if (unlikely(!pushConfig2Queue(version_info.extras_int64))) return;
    if (unlikely(!pushConfig2Queue(version_info.extras_float))) return;
    if (unlikely(!pushConfig2Queue(version_info.extras_bytes))) return;

    if (unlikely(!pushConfig2Queue(version_info.user_extras_int64))) return;
    if (unlikely(!pushConfig2Queue(version_info.user_extras_float))) return;
    if (unlikely(!pushConfig2Queue(version_info.user_extras_bytes))) return;
    if (unlikely(!pushConfig2Queue(version_info.item_extras_int64))) return;
    if (unlikely(!pushConfig2Queue(version_info.item_extras_float))) return;
    if (unlikely(!pushConfig2Queue(version_info.item_extras_bytes))) return;

    while (!queue.empty()) {
      const std::string& name = *queue.front();
      queue.pop();
      auto iter = slot_config.find(name);
      auto iter2 = name_config.find(name);
      // 检测相同的slot_id和name是否存在非同一个特征
      if (iter != slot_config.end() && iter2 != name_config.end() && iter->second !=iter2->second) {
        THROW_ERROR("another config name equal slot , name:" + name);
        return;
      }
      //检测set中是否已有对应的config_name，避免重复加载相同的input
      auto set_iter = filter_set.find(name);
      if (set_iter == filter_set.end()) {
        std::shared_ptr<Config> config = nullptr;
        if (iter != slot_config.end()) {
          config = iter->second;
        } else if (iter2 != name_config.end()) {
          config = iter2->second;
        }
        // 如果input是特征
        if (config) {
          for (Input& input : config->inputs_) {
            queue.push(&input.name);
            if (!input.from_request && !input.name_parts.empty()) {
              queue.push(&input.name_parts[0]);
            }
            LogDebug("push {}", input.name);
          }
          filter_set.insert(name);
          //尝试插入output，在name为slot时会成功
          filter_set.insert(config->output_);
        }
        LogDebug("insert {}", name);
      }
    }

    std::vector<std::shared_ptr<Config>> all_configs;
    all_configs.swap(configs);

    for (auto& config : all_configs) {
      if (filter_set.find(config->output_) != filter_set.end()) {
        configs.push_back(config);
      }
    }
  }

  static void load_direct_to_feature(const std::vector<std::string>& source, std::string& config_type, const std::string& output) {
    static const std::string direct_name = "direct";
    static const std::string to_feature_name = "to_feature";

    Input input(source[0], {}, output);
    if (0 == input.repeated_count) {
      config_type = direct_name;
    } else {
      config_type = to_feature_name;
    }
  }
};

#endif  // FE_CONFIG_MGR