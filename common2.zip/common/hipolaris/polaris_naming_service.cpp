#include "polaris_naming_service.h"
#include <brpc/server.h>
#include <brpc/global.h>
#include <brpc/server_node.h>
#include <gflags/gflags.h>
#include <iostream>
#include <polaris/config.h>
#include <polaris/consumer.h>
#include <string>
#include <system_error>
#include "polaris_instance.h"

namespace brpc {
namespace policy {

DECLARE_int32(polaris_timeout_ms);
DECLARE_int32(polaris_refresh_ms);

PolarisNamingService::PolarisNamingService(){}

PolarisNamingService::~PolarisNamingService() {
}

bool PolarisNamingService::ParsePolarisName(const char* service_name,
                                          std::string& namespace_name,
                                          std::string& real_service_name) {
    butil::StringPiece sp(service_name);
    size_t pos = sp.find('/');
    if (pos == butil::StringPiece::npos) {
        namespace_name = "default";
        real_service_name = sp.as_string();
    } else {
        namespace_name = sp.substr(0, pos).as_string();
        real_service_name = sp.substr(pos + 1).as_string();
    }
    return true;
}

int PolarisNamingService::GetServers(const char* service_name,
                                   std::vector<ServerNode>* servers) {                              
    std::string real_service_name;
    std::string real_name_space;
    ParsePolarisName(service_name, real_name_space,real_service_name);
    polaris::ServiceKey service_key{real_name_space, real_service_name};
    polaris::GetInstancesRequest req(service_key);
    req.SetTimeout(FLAGS_polaris_timeout_ms);
    req.SetSkipRouteFilter(true);

    polaris::InstancesResponse* resp = nullptr;
    polaris::ConsumerApi* consumer = nullptr;
    consumer = PolarisInstace::instance().get_consumer();
    if (consumer == nullptr) {
        LOG(ERROR) << "consumer null! ";
        return -1;
    }
    polaris::ReturnCode ret = consumer->GetInstances(req, resp);
    if (ret != polaris::kReturnOk) {
        LOG(ERROR) << "GetInstances from polaris failed: " << polaris::ReturnCodeToMsg(ret);
        return -1;
    }

    servers->clear();
    for (const auto& instance : resp->GetInstances()) {
        if (!instance.isHealthy()) continue;

        butil::EndPoint endpoint;
        if (butil::str2endpoint(instance.GetHost().c_str(), instance.GetPort(), &endpoint) != 0) {
            continue;
        }
        ServerNode sid(endpoint, instance.GetCampus());
        // std::cout<< "[ poliaris ] get ip from polaris,pod ip: "<< sid.addr << "campus: " << sid.tag << std::endl;
        servers->push_back(sid);
    }

    if (servers->empty()) {
        LOG_EVERY_N(WARNING, 10) << "No healthy instances for " << service_name;
    }

    return 0;
}

void PolarisNamingService::Describe(std::ostream &os,
    const DescribeOptions &) const {
    os << "polaris";
}

int PolarisNamingService::GetNamingServiceAccessIntervalMs() const{
    if (0 < FLAGS_polaris_refresh_ms) {
        return FLAGS_polaris_refresh_ms;
    }
    return PeriodicNamingService::GetNamingServiceAccessIntervalMs();};

}// namespace policy

} // namespace brpc