#include "common/monitor/prometheus_pusher.h"
#include "common/hilog/log_helper.h"
#include <brpc/controller.h>
#include <chrono>
#include <new>

namespace push {
std::atomic<bool> PushConfig::push_enable_{false};    // bvar监控数据上报推送开关
std::shared_ptr<const std::string> PushConfig::prometheus_url_;
std::shared_ptr<const std::string> PushConfig::prometheus_uri_;
std::atomic<int32_t> PushConfig::batch_size_{4500};
std::atomic<uint64_t> PushConfig::push_timeout_ms_{120000};
std::atomic<int32_t> PushConfig::max_queue_size_{45000};

void PushConfig::set(bool enable, const std::string& url, const std::string& uri, int32_t size, uint64_t time, int32_t max_size) {
    if (!enable) {
        HILOG_APP(INFO) << "Push disabled by config";
        PrometheusPusher::SetEnabled(false);
        push_enable_.store(false, std::memory_order_release);
        return;
    }
    if (url.empty() || uri.empty()) {
        HILOG_APP(ERROR) << "Prometheus URL and URI cannot be empty";
        PrometheusPusher::SetEnabled(false);
        push_enable_.store(false, std::memory_order_release);
        return;
    }
    if (size <= 0 || size > 10000 || time == 0 || time > 600000) {
        HILOG_APP(ERROR) << "Invalid batch_size: " << size << ", should be between 1 and 10000"
                            << " or Invalid push_timeout_ms: " << time << ", should be between 1 and 600000";
        PrometheusPusher::SetEnabled(false);
        push_enable_.store(false, std::memory_order_release);
        return;
    }
    if (max_size < size * 10) {
        max_size = size * 10;   // 建议max_size至少是batch_size的10倍
    }

    std::atomic_store_explicit(&prometheus_url_, std::make_shared<const std::string>(url), std::memory_order_release);
    std::atomic_store_explicit(&prometheus_uri_, std::make_shared<const std::string>(uri), std::memory_order_release);
    batch_size_.store(size, std::memory_order_relaxed);
    push_timeout_ms_.store(time, std::memory_order_relaxed);
    max_queue_size_.store(max_size, std::memory_order_relaxed);
    push_enable_.store(true, std::memory_order_release);
    HILOG_APP(INFO) << "PushConfig set successfully: url = " << url << ", uri = " << uri 
             << ", batch_size = " << size << ", timeout = " << time << "ms, max_queue_size = " << max_size;

    PrometheusPusher::SetEnabled(true);
}

// 初始化
std::atomic<bool> PrometheusPusher::accepting_{false};
std::atomic<bool> PrometheusPusher::channel_initialized_{false};
std::mutex PrometheusPusher::init_mutex_;
std::shared_ptr<brpc::Channel> PrometheusPusher::channel_;
std::shared_ptr<const std::string> PrometheusPusher::current_url_;
// 批量数据管理
std::unique_ptr<boost::lockfree::queue<std::string*>> PrometheusPusher::push_queue_;
std::atomic<size_t> PrometheusPusher::queue_size_{0};
// 线程生命周期管理器
PrometheusPusher::PusherManager PrometheusPusher::manager_;

// --- PusherManager 实现 ---
PrometheusPusher::PusherManager::PusherManager() {}
PrometheusPusher::PusherManager::~PusherManager() { stop(); }

void PrometheusPusher::PusherManager::start(int thread_count) {
    std::lock_guard<std::mutex> lk(manager_mutex_);
    if (!push_threads_.empty()) { return; }
    stop_flag_.store(false, std::memory_order_release);
    if (thread_count <= 0)  thread_count = 2;
    for (int i = 0; i < thread_count; ++i) {
        ThreadHandle handle;
        handle.stop_token = std::make_shared<std::atomic<bool>>(false);
        handle.thread = std::make_unique<std::thread>(&PrometheusPusher::PushWorker, handle.stop_token);
        push_threads_.emplace_back(std::move(handle));
    }
    HILOG_APP(INFO) << "PrometheusPusher threads: " << thread_count;
}

void PrometheusPusher::PusherManager::stop() {
    std::vector<ThreadHandle> local_threads;
    {
        std::lock_guard<std::mutex> lk(manager_mutex_);
        if (push_threads_.empty()) { return; }
        stop_flag_.store(true, std::memory_order_release);
        local_threads = std::move(push_threads_);
    }
    for (auto &handle : local_threads) {
        if (handle.stop_token) {
            handle.stop_token->store(true);
        }
        if (handle.thread && handle.thread->joinable()) {
            handle.thread->join();   // 等待线程处理完剩余数据后退出
        }
    }
    HILOG_APP(INFO) << "PrometheusPusher thread pool stopped safely";
}

// --- PrometheusPusher 实现 ---
PrometheusPusher::PrometheusPusher() {}
PrometheusPusher::~PrometheusPusher() {}    // 由PusherManager管理生命周期

void PrometheusPusher::SetEnabled(bool enable) {
    if (enable) {
        if (!EnsureChannelInitialized()) {
            accepting_.store(false, std::memory_order_relaxed);
            return;
        }
        manager_.start(GetConsumerThreadCount());   // 幂等启动后台线程
        accepting_.store(true, std::memory_order_relaxed);
    } else {
        if (!accepting_.load(std::memory_order_relaxed)) { return; }
        accepting_.store(false, std::memory_order_relaxed); // 停止接收新数据
        manager_.stop();                                    // 停止并回收线程
        std::string* dropped_ptr = nullptr; // 清空已在队列和缓存中的数据
        if (push_queue_) {
            while (push_queue_->pop(dropped_ptr)) {
                queue_size_.fetch_sub(1, std::memory_order_acquire);
                if (dropped_ptr) {
                    RecycleString(dropped_ptr);  // 归还到对象池
                }
                dropped_ptr = nullptr;
            }
        }
        butil::clear_objects<std::string>();  // 清理 brpc 对象池
    }
}

bool PrometheusPusher::IsEnabled() {
    return PushConfig::push_enable_.load(std::memory_order_acquire) && accepting_.load(std::memory_order_relaxed);
}

int32_t PrometheusPusher::GetConsumerThreadCount() {
    unsigned hc = std::thread::hardware_concurrency();
    unsigned suggested = (hc + 15) / 16; // <=32C：2个线程，>48C：4个线程，向上取整，范围:[2, 4]
    if (suggested < 2) suggested = 2;
    if (suggested > 4) suggested = 4;
    return static_cast<int32_t>(suggested);
}

bool PrometheusPusher::EnsureChannelInitialized() {
    auto url_ptr = std::atomic_load_explicit(&current_url_, std::memory_order_acquire);
    auto config_url = std::atomic_load_explicit(&PushConfig::prometheus_url_, std::memory_order_acquire);
    if (channel_initialized_.load(std::memory_order_acquire) && url_ptr && config_url && *url_ptr == *config_url) {
        return true;
    }
    std::lock_guard<std::mutex> lk(init_mutex_);
    url_ptr = std::atomic_load_explicit(&current_url_, std::memory_order_acquire);
    config_url = std::atomic_load_explicit(&PushConfig::prometheus_url_, std::memory_order_acquire);
    if (channel_initialized_.load(std::memory_order_relaxed) && url_ptr && config_url && *url_ptr == *config_url) {
        return true;
    }

    try {
        brpc::ChannelOptions options;
        options.protocol = "http";
        options.connection_type = "pooled"; // 连接池

        std::shared_ptr<brpc::Channel> new_channel = std::make_shared<brpc::Channel>();
        if (new_channel->Init(config_url->c_str(), &options) != 0) {
            HILOG_APP(ERROR) << "Failed to initialize channel to prometheus";
            return false;
        }

        // 初始化无锁 MPMC 队列
        if (!push_queue_) {
            int32_t max_size = PushConfig::max_queue_size_.load(std::memory_order_relaxed);
            size_t init_capacity = static_cast<size_t>(max_size > 0 ? max_size : 45000);
            push_queue_ = std::make_unique<boost::lockfree::queue<std::string*>>(init_capacity);
            if (!push_queue_) {
                HILOG_APP(ERROR) << "Failed to create push queue";
                return false;
            }
        }

        std::atomic_store_explicit(&channel_, new_channel, std::memory_order_release);
        std::atomic_store_explicit(&current_url_, config_url, std::memory_order_release);
        channel_initialized_.store(true, std::memory_order_release);
        HILOG_APP(INFO) << "PrometheusPusher channel and resources initialized successfully, url= " << *config_url;
        return true;
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << "Exception during PrometheusPusher initialization: " << e.what();
        return false;
    } catch (...) {
        HILOG_APP(ERROR) << "Unknown exception during PrometheusPusher initialization";
        return false;
    }
}

void PrometheusPusher::RecycleString(std::string* ptr) {
    if (!ptr) { return; }
    constexpr size_t MAX_STRING_CAPACITY = 1024;    // 对于过大的 string，手动删除，避免内存浪费
    if (ptr->capacity() > MAX_STRING_CAPACITY) {
        delete ptr;
        return;
    }
    butil::return_object(ptr);  // 归还到 brpc 的对象池
}

void PrometheusPusher::AddData(std::string&& prometheus_data) {
    if (!IsEnabled()) return;
    auto url_ptr = std::atomic_load_explicit(&current_url_, std::memory_order_acquire);
    auto config_url = std::atomic_load_explicit(&PushConfig::prometheus_url_, std::memory_order_acquire);
    if (!channel_initialized_.load(std::memory_order_acquire) || !url_ptr || !config_url || *url_ptr != *config_url) {
        if (!EnsureChannelInitialized()) {  // 惰性重试初始化
            HILOG_APP(ERROR) << "PrometheusPusher not initialized, data dropped.";
            return;
        }
        manager_.start(GetConsumerThreadCount());   // 确保线程已启动
    }

    std::string* data_ptr = nullptr;
    try {
        if (!push_queue_) {
            HILOG_APP(WARNING) << "Push queue not ready, drop one item.";
            return;
        }
        
        data_ptr = butil::get_object<std::string>();   // 使用对象池分配 string 对象
        if (!data_ptr) {
            HILOG_APP(ERROR) << "Allocation failed for prometheus data, drop one item.";
            return;
        }
        data_ptr->clear();  // 清空复用对象的内容
        *data_ptr = std::move(prometheus_data); // 移动赋值数据到池对象中
        if (!push_queue_->push(data_ptr)) {
            RecycleString(data_ptr);  // push失败，归还到对象池
            data_ptr = nullptr;
            HILOG_APP(WARNING) << "Push queue push failed unexpectedly, dropping one item.";
            return;
        }
        data_ptr = nullptr;
        queue_size_.fetch_add(1, std::memory_order_release);    // 成功入队后更新近似队列长度
    } catch (const std::exception& e) {
        if (data_ptr) { RecycleString(data_ptr); }
        HILOG_APP(ERROR) << "Exception in AddData: " << e.what() << ", data dropped.";
    } catch (...) {
        if (data_ptr) { RecycleString(data_ptr); }
        HILOG_APP(ERROR) << "Unknown exception in AddData, data dropped.";
    }
}

void PrometheusPusher::PushWorker(std::shared_ptr<std::atomic<bool>> stop_token) {   // 独立的后台线程
    while (!manager_.stop_flag_.load(std::memory_order_acquire) 
            && stop_token && !stop_token->load(std::memory_order_acquire)) {
        ProcessBatches();
    }
}

void PrometheusPusher::ProcessBatches() {
    try {
        if (!push_queue_) {
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
            return;
        }

        thread_local std::vector<std::string> batch_cache;
        thread_local uint64_t last_push_time_ms = GetCurrentTimeMs();

        // 若开关关闭：丢弃队列中的数据，避免任何HTTP推送
        if (!PushConfig::push_enable_.load(std::memory_order_acquire)) {
            std::string* dropped_ptr = nullptr;
            while (push_queue_->pop(dropped_ptr)) {
                queue_size_.fetch_sub(1, std::memory_order_acquire);
                if (dropped_ptr) {
                    RecycleString(dropped_ptr);  // 归还到对象池
                }
                dropped_ptr = nullptr;
            }
            batch_cache.clear(); // 清空当前线程的本地缓存，防止开关重启后推送旧数据
            last_push_time_ms = GetCurrentTimeMs(); // 重置时间戳，避免误触发超时推送
            std::this_thread::sleep_for(std::chrono::milliseconds(5));
            return;
        }

        // 消费者侧超限丢最旧：当近似队列长度超过上限的95%（limit）时，丢弃上限的5%（最旧元素）
        int32_t max_size = PushConfig::max_queue_size_.load(std::memory_order_relaxed);
        const size_t limit = static_cast<size_t>(max_size) * 95 / 100; // 取limit为队列长度上限的95%
        size_t current_size = queue_size_.load(std::memory_order_acquire);
        if (current_size > limit && current_size < (UINT64_MAX / 2)) {  // 避免处理已下溢的异常值
            const size_t batch_drop = std::max<size_t>(1, static_cast<size_t>(max_size) * 5 / 100); // 丢弃上限的5%
            size_t actually_dropped = 0;
            std::string* to_drop = nullptr;
            for (; actually_dropped < batch_drop && push_queue_->pop(to_drop); ++actually_dropped) {
                queue_size_.fetch_sub(1, std::memory_order_acquire);
                if (to_drop) {
                    RecycleString(to_drop);  // 归还到对象池
                }
                to_drop = nullptr;
            }
            size_t remain = queue_size_.load(std::memory_order_acquire);
            if (actually_dropped > 0) {
                HILOG_APP(ERROR) << "PrometheusPusher Queue overflow: dropped " << actually_dropped << " items in batch, approx remain: " << remain;
            }
        }

        thread_local unsigned backoff_ms = 100; // 失败退避时长
        // 1. 从队列拉取数据并在消费者线程凑批
        std::string* data_ptr = nullptr;
        bool popped_any = false; // 标志位，记录这一轮循环是否成功取到了数据
        int32_t batch_size = PushConfig::batch_size_.load(std::memory_order_relaxed);
        while (push_queue_->pop(data_ptr)) {
            popped_any = true;
            if (batch_cache.empty()) {
                batch_cache.reserve(batch_size + batch_size / 2); // 预留1.5个批次的容量
            }
            queue_size_.fetch_sub(1, std::memory_order_acquire);    // 出队成功，更新近似队列长度
            if (data_ptr) {
                batch_cache.emplace_back(std::move(*data_ptr));
                RecycleString(data_ptr);  // 归还到对象池
                data_ptr = nullptr;
            }
            if (batch_cache.size() >= static_cast<size_t>(batch_size)) {
                // 组装批量文本并推送
                thread_local std::string batch_buffer;
                batch_buffer.clear();
                size_t estimated_size = batch_cache.size() * 300; // 一条数据大概200多字节
                batch_buffer.reserve(estimated_size);
                for (const auto& item : batch_cache) {
                    batch_buffer.append(item);
                    batch_buffer.push_back('\n');
                }
                int32_t normal_size = static_cast<int32_t>(batch_cache.size());
                if (ExecuteHttpPush(batch_buffer)) {
                    // 每100个批次打印一次成功日志
                    thread_local uint64_t normal_success_count = 0;
                    ++normal_success_count;
                    if (normal_success_count % 100 == 1) {
                        HILOG_APP(INFO) << "PrometheusPusher Full batch pushed successfully, items: " << normal_size
                                        << ", total full batch success count: " << normal_success_count;
                    }
                } else {
                    std::this_thread::sleep_for(std::chrono::milliseconds(backoff_ms));
                    HILOG_APP(WARNING) << "PrometheusPusher Full batch post failed, retry once";
                    if (!ExecuteHttpPush(batch_buffer)) {
                        HILOG_APP(ERROR) << "PrometheusPusher Full Batch push failed after retry, items dropped: " << normal_size;
                    }
                }
                batch_cache.clear();
                last_push_time_ms = GetCurrentTimeMs();
            }
        }

        if (!popped_any) {  // 若本轮没有取到任何数据，短暂休眠以降低空转
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }

        // 2. 检查并处理超时批次
        if (!batch_cache.empty()) {
            uint64_t now = GetCurrentTimeMs();
            uint64_t timeout_ms = PushConfig::push_timeout_ms_.load(std::memory_order_relaxed);
            if (now > last_push_time_ms && (now - last_push_time_ms > timeout_ms)) {
                thread_local std::string timeout_buffer;
                timeout_buffer.clear();
                size_t estimated_size = batch_cache.size() * 300;
                timeout_buffer.reserve(estimated_size);
                for (const auto& item : batch_cache) {
                    timeout_buffer.append(item);
                    timeout_buffer.push_back('\n');
                }
                int32_t timeout_size = static_cast<int32_t>(batch_cache.size());
                if (ExecuteHttpPush(timeout_buffer)) {
                    // 每10个超时批次打印一次日志
                    thread_local uint64_t timeout_success_count = 0;
                    ++timeout_success_count;
                    if (timeout_success_count % 10 == 1) {
                        HILOG_APP(INFO) << "PrometheusPusher Timeout batch pushed successfully, items: " << timeout_size
                                        << ", total timeout success count: " << timeout_success_count;
                    }
                } else {
                    std::this_thread::sleep_for(std::chrono::milliseconds(backoff_ms));
                    HILOG_APP(WARNING) << "PrometheusPusher Timeout batch post failed, retry once";
                    if (!ExecuteHttpPush(timeout_buffer)) {
                        HILOG_APP(ERROR) << "PrometheusPusher Timeout batch push failed after retry, items dropped: " << timeout_size;
                    }
                }
                batch_cache.clear();
                last_push_time_ms = GetCurrentTimeMs();
            }
        }
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << "Exception in ProcessBatches: " << e.what();
    } catch (...) {
        HILOG_APP(ERROR) << "Unknown exception in ProcessBatches";
    }
}

bool PrometheusPusher::ExecuteHttpPush(const std::string& data) {
    if (!PushConfig::push_enable_.load(std::memory_order_acquire)) {
        return true;
    }
    if (data.empty()) {
        HILOG_APP(WARNING) << "No data to push to Prometheus";
        return true;
    }
    
    auto config_url = std::atomic_load_explicit(&PushConfig::prometheus_url_, std::memory_order_acquire);
    auto config_uri = std::atomic_load_explicit(&PushConfig::prometheus_uri_, std::memory_order_acquire);
    if (!config_url || !config_uri || config_url->empty() || config_uri->empty()) {
        HILOG_APP(WARNING) << "Prometheus url/uri is not configured, skip push.";
        return false;
    }

    try {
        brpc::Controller cntl;
        cntl.http_request().uri() = *config_uri;
        cntl.http_request().set_method(brpc::HTTP_METHOD_POST);
        cntl.http_request().set_content_type("text/plain; version=0.0.4");
        cntl.http_request().SetHeader("Content-Encoding", "gzip");
        cntl.set_timeout_ms(1000);
        cntl.request_attachment().append(data);

        std::shared_ptr<brpc::Channel> channel = std::atomic_load_explicit(&channel_, std::memory_order_acquire);
        if (!channel) {
            HILOG_APP(ERROR) << "Channel is not initialized";
            return false;
        }
        channel->CallMethod(NULL, &cntl, NULL, NULL, NULL);
        if (cntl.Failed()) {
            HILOG_APP(ERROR) << "Failed to push data to Prometheus, brpc error: " << cntl.ErrorText();
            return false;
        }

        long status_code = cntl.http_response().status_code();
        bool success = (status_code >= 200 && status_code < 300);
        if (!success) {
            HILOG_APP(ERROR) << "Failed to push data to Prometheus, response code: " << status_code
                             << ", error text: " << cntl.response_attachment().to_string();
        }
        return success;
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << "Exception in ExecuteHttpPush: " << e.what();
        return false;
    } catch (...) {
        HILOG_APP(ERROR) << "Unknown exception in ExecuteHttpPush";
        return false;
    }
}

uint64_t PrometheusPusher::GetCurrentTimeMs() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
}
} // namespace push 