#include "offline_item_emb_dict_loader.h"
#include "common/comm/file_scanner.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/prerank/embedding_cache/feature_cache.h"
#include "core/utils/defs.h"
#include "core/utils/error.h"
#include "core/utils/monitor_mgr.h"
#include "prerank/prerank_embedding.pb.h"
#include <climits>
#include <dirent.h>
#include <fcntl.h>
#include <fstream>
#include <google/protobuf/io/coded_stream.h>
#include <google/protobuf/io/zero_copy_stream_impl.h>
#include <log_helper.h>
#include <nlohmann/json.hpp>
#include <sstream>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

namespace Core {
    namespace prerank {

        namespace {
            // 解析 TASK_INFO 第二行，取 version 字段
            static int32_t ReadTaskInfoVersion(const std::string &dir_path, std::string &model_name_out,
                                               int32_t &version_out, int32_t &item_count_out) {
                std::string file_path = dir_path + Core::PATH_SEPARATOR + Core::task_info_file;
                int fd = open(file_path.c_str(), O_RDONLY);
                if (fd == -1) {
                    LOG_WARNING << "TASK_INFO not found: " << file_path;
                    return -1;
                }
                struct stat sb{};
                if (fstat(fd, &sb) == -1) {
                    close(fd);
                    return -1;
                }
                int32_t length = static_cast<int32_t>(sb.st_size);
                const char *p_buf = static_cast<const char *>(mmap(NULL, length, PROT_READ, MAP_PRIVATE, fd, 0));
                if (p_buf == nullptr || p_buf == MAP_FAILED) {
                    close(fd);
                    return -1;
                }
                const char *start = p_buf;
                const char *end = p_buf + length;
                int line_count = 0;
                const char *line_start = nullptr;
                const char *line_end = nullptr;
                for (const char *it = start; it < end; ++it) {
                    if (*it == '\n') {
                        ++line_count;
                        if (line_count == 1) {
                            line_start = it + 1;
                        } else if (line_count == 2) {
                            line_end = it;
                            break;
                        }
                    }
                }
                std::string second_line;
                if (line_start && line_end && line_start < line_end) {
                    second_line.assign(line_start, line_end);
                }
                munmap((void *) p_buf, length);
                close(fd);
                if (second_line.empty())
                    return -1;
                // 格式: {model_name},{model_version},{item_count}
                std::istringstream iss(second_line);
                std::string tok;
                std::vector<std::string> parts;
                while (std::getline(iss, tok, ','))
                    parts.emplace_back(tok);
                if (parts.size() < 3)
                    return -1;
                model_name_out = parts[0];
                try {
                    version_out = std::stoi(parts[1]);
                    item_count_out = std::stoi(parts[2]);
                } catch (...) {
                    return -1;
                }
                return 0;
            }

            // 读取 itemEmb.txt 每行的 protobuf 二进制，填充到 FeatureCache 的备份缓冲
            static int LoadItemEmbFile(const std::string &dir_path, const std::string &model_name,
                                       int32_t model_version, bool is_version_update) {
                std::string path = dir_path + Core::PATH_SEPARATOR + Core::ad_embedding_file;

                std::ifstream in(path, std::ios::in | std::ios::binary);
                if (!in.is_open()) {
                    LOG_ERROR << "LoadItemEmb: Failed to open itemEmb.txt: " << path;
                    return -1;
                }
                
                int parsed = 0;
                int failed = 0;
                int insert_success = 0;
                int insert_failed = 0;

                while (in.good() && !in.eof()) {
                    uint32_t net_size = 0;
                    in.read(reinterpret_cast<char *>(&net_size), sizeof(net_size));
                    if (in.eof()) { break; }
                    // 读取记录长度失败
                    if (!in.good()) {
                        ++failed;
                        break;
                    }

                    uint32_t size = ntohl(net_size);
                    if (size == 0 || size > 500 * 1024 * 1024) {
                        LOG_ERROR << "LoadItemEmb: version " << model_version << " 非法记录长度: " << size;
                        ++failed;
                        break;
                    }

                    std::string serialized_data(size, '\0');
                    in.read(&serialized_data[0], size);
                    if (!in.good()) {
                        ++failed;
                        break;
                    }

                    phx::ItemEmbeddingInfo item;
                    if (!item.ParseFromString(serialized_data)) {
                        ++failed;
                        continue;
                    }

                    ++parsed;

                    // 提取creative_id和float_val向量
                    int64_t creative_id = item.cid();
                    std::vector<float> feature_vec;
                    feature_vec.reserve(item.float_val_size());
                    for (int i = 0; i < item.float_val_size(); ++i) {
                        feature_vec.push_back(item.float_val(i));
                    }

                    // 逐条插入到FeatureCache
                    int32_t ret = Core::prerank::FeatureCache::get_instance().insert_feature(
                            model_name, model_version, creative_id, feature_vec, is_version_update);

                    if (ret == ERROR_SUCCESS) {
                        ++insert_success;
                    } else {
                        ++insert_failed;
                    }
                }
                
                LOG_ERROR << "INFO: LoadItemEmb: Load completed - 读取: " << parsed << ", failed: " << failed 
                         << ", insert_success: " << insert_success << ", insert_failed: " << insert_failed
                         << ", model: " << model_name << ", version: " << model_version;
                // 上报读取条数监控
                // MonitorMgr::common_report_model(model_name, context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()), "default", 0,
                //                                       "offline_item_emb_read_rows", static_cast<double>(parsed));
                return 0;
            }
        }// namespace

        int LoadLatestEmbeddingFromGoose(const std::string &model_name_cfg, int32_t model_version_cfg, const std::string &base_dir, 
                                        bool is_version_update, bool is_first_rotate, bool is_read_obj) {

            LOG_ERROR << "INFO: ScanItemEmb: Loading embedding from base_dir, model: " << model_name_cfg 
                            << ", base_dir: " << base_dir << ", is_version_update: " << is_version_update << ", is_first_rotate: " << is_first_rotate 
                            << ", version: " << model_version_cfg << ", is_read_obj: " << is_read_obj;

            // 读取 TASK_INFO 校验 model_name 与 version
            std::string task_model_name;
            int32_t task_version = 0;
            int32_t task_item_cnt = 0;
            LOG_ERROR << "开始读取TASK_INFO文件, 路径=" << base_dir;
            if (ReadTaskInfoVersion(base_dir, task_model_name, task_version, task_item_cnt) != 0) {
                LOG_WARNING << "ScanItemEmb: TASK_INFO parse failed, path: " << base_dir;
            }

            const std::string &model_name = !task_model_name.empty() ? task_model_name : model_name_cfg;
            int32_t model_version = task_version > 0 ? task_version : model_version_cfg;

            if (is_version_update || (!is_version_update && is_read_obj)) {
                // 预分配写入对象
                Core::prerank::FeatureCache::get_instance().pre_allocate(model_name, model_version, is_read_obj);
            }
            Core::prerank::FeatureCache::get_instance().clear_double_buffer(model_name, model_version, is_version_update);

            // 加载 itemEmb.txt
            if (LoadItemEmbFile(base_dir, model_name, model_version, is_version_update) != 0) {
                LOG_ERROR << "ScanItemEmb: Failed to load itemEmb.txt";
                return -1;
            }
            
            // 切换buffer
            Core::prerank::FeatureCache::get_instance().commit_buffer(model_name, model_version, is_version_update,
                                                                      is_first_rotate);
            LOG_ERROR << "INFO: ScanItemEmb: FeatureCache buffer 切换完成, model: " << model_name << ", version: " << model_version;
            return 0;
        }

    }// namespace prerank
}// namespace Core
