#pragma once
#include <string>

namespace Core {
namespace prerank {

// 读取最新 item embedding，加载到 FeatureCache 并切换buffer
// 返回值：0 表示成功，负数表示失败或无可加载内容
int LoadLatestEmbeddingFromGoose(const std::string &model_name, int32_t model_version, const std::string &base_dir,
                                 bool is_version_update, bool is_first_rotate, bool is_read_obj);

} // namespace prerank
} // namespace Core