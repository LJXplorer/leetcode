#include "offline_embedding_start_service.h"
#include "common/dictionary_reader/dictionary_reader.h"
#include "core/core_context/monitor_context.h"
#include "core/core_services/fe/fe_service.h"
#include "hlframe/gtransport_manager.h"
#include "phx-fe/ad_dict/ad_dict_manager.h"
#include <cstddef>
#include <debug_utils.h>
#include <log_helper.h>
#include <string>
#include <utility>
namespace Core {
    SERVICE_REGISTER(EmbeddingStartService);
    int EmbeddingStartService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int32_t ret = 0;
        try {
            ctx->gen_log_head();
            ret = process(ctx);
        } catch (const std::exception &e) {
            LOG_ERROR << LOG_HEAD(ctx) << get_name() << "do service fail: " << ret << "," << e.what();
        }
        return ret;
    }

    void EmbeddingStartService::initialize(ConfigXmlPtr xml) {
        xml->attr<int32_t>("split_size", _split_size);
        initialize_xml(xml);
    }

    void EmbeddingStartService::initialize_xml(ConfigXmlPtr xml) {
    }

    template<typename MapType>
    void processItemMap(const MapType &item_map, phx::PredictorSlotInfo *ad_data, const std::string &model_name) {
        for (const auto &[material_id, item_info]: item_map) {
            auto *item = ad_data->add_predictoriteminfos();
            // 从 AdInfoDict 中获取 creativeId和appid 并设置到 item 中
            item->set_creativeid(item_info->creative_id());
            item->set_appid(item_info->app_id());
        }

        LOG_ERROR << "processItemMap end, model_name: " << model_name << "item size"
                        << ad_data->predictoriteminfos_size();

    }

    void EmbeddingStartService::GetItemFromDict(const std::string &dict_name, phx::PredictorSlotInfo *ad_data,
                                                const std::string &model_name) {

        auto model_info_ptr = Info::ModelInfoManager::instance().get_model_info(model_name);
        if (!model_info_ptr) {
            LOG_ERROR << "Failed to get ModelInfo for model: " << model_name;
            return;
        }
        auto iter = AdDict::AdDictCollectorInstance::instance().get_dict(dict_name);
        if (iter == nullptr) {
            LOG_ERROR << "Failed to get AdInfoDict dictInfo, dict: " << dict_name;
            return;
        }
        auto adinfo_dict_map = iter->get_data<AdDict::adinfo_dict_type>();

        if (!adinfo_dict_map) {
            LOG_ERROR << "Failed to get AdInfoDict map for dict: " << dict_name;
            return;
        }

        LOG_ERROR << "ItemFromDict size: " << adinfo_dict_map->size() <<" ,dict name:" << dict_name;
        // 处理 adinfo_dict_map
        processItemMap(*adinfo_dict_map, ad_data, model_name);
    }
    int EmbeddingStartService::process(CoreContextPtr context) {
        BizLatency *lat = get_node_stat(context)->get_lat();
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);
            phx::PredictorRequest *predcit_request = context->mutable_rank_request();

            GetItemFromDict(context->get_prerank_context()->item_dict_name_, predcit_request->mutable_predictorslotinfo(),
                            context->_offline_item_emb_model);
            context->_bak_request.CopyFrom(*predcit_request);
            if (predcit_request->predictorslotinfo().predictoriteminfos_size() == 0) {
                return ERROR_EMBEDDING_ITEMS_EMPTY;
            }
            auto predictor_item_infos = predcit_request->mutable_predictorslotinfo()->mutable_predictoriteminfos();

            LOG_INFO << "model name: " << context->_offline_item_emb_model;
            context->get_prerank_context()->_offline_item_model_info =
                    Info::ModelInfoManager::instance().get_model_info(context->_offline_item_emb_model);

            if (context->get_prerank_context()->_offline_item_model_info == nullptr) {
                LOG_ERROR << "item model info null ";
            } else {
                LOG_ERROR << "model name: " + context->get_prerank_context()->_offline_item_model_info->_model_name<< "item model fe_config,size: "
                            << context->get_prerank_context()->_offline_item_model_info->get_fe_config().size()<< "predcit_request predictoriteminfos_size: "
                            << predcit_request->predictorslotinfo().predictoriteminfos_size();
            }

            int32_t chunk_index = 0;

            std::vector<ItemWrapper> chunk;

            // 遍历 predictor_item_infos
            for (const auto &predictor_item_info: *predictor_item_infos) {
                // 创建 ItemWrapper 对象
                ItemWrapper item_wrapper(&predictor_item_info);
                chunk.push_back(item_wrapper);
                if (chunk.size() == static_cast<size_t>(_split_size)) {
                    context->get_prerank_context()->_offline_item_embedding_map[chunk_index] = std::move(chunk);
                    chunk_index++;// 增加分片索引
                    chunk.clear();// 清空当前分包
                }
            }

            if (!chunk.empty()) {
                context->get_prerank_context()->_offline_item_embedding_map[chunk_index] = std::move(chunk);
            }
        }
        BizLatencyGaurd lat_guard(lat, LAT_STAGE_DESTROY);
        return ERROR_SUCCESS;
    }

}// namespace Core