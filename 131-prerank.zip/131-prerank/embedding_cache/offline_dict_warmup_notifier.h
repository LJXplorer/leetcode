#pragma once
#include <string>

namespace Core {
namespace prerank {
// 上报至词典模块
int NotifyDictWarmup(const std::string& base_dir);

} // namespace prerank
} // namespace Core