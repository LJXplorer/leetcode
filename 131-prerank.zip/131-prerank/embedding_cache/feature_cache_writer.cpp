#include "feature_cache_writer.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/defs.h"
#include "offline_dict_warmup_notifier.h"
#include "prerank/prerank_embedding.pb.h"
#include <arpa/inet.h>
#include <log_helper.h>
#include <sys/stat.h>
#include <wrapper_time.h>
FeatureCacheWriter g_feature_cache_writer;
namespace fs = std::filesystem;

static std::string normalizeDir(const std::string &dir) {
    std::string res = dir;
    while (!res.empty() && (res.back() == '/' || res.back() == '\\')) {
        res.pop_back();
    }
    return res;
}

FeatureCacheWriter::FeatureCacheWriter(int wait_timeout_ms) : wait_timeout_ms_(wait_timeout_ms) {
}

FeatureCacheWriter::~FeatureCacheWriter() {
    LOG_ERROR << "FeatureCacheWriter destructor called";

    std::vector<std::shared_ptr<ModelWriter>> writers;
    {
        std::unique_lock<std::mutex> lock(map_mutex_);
        writers.reserve(model_writers_.size());
        for (auto &[key, writer]: model_writers_) {
            writers.push_back(writer);
        }
        model_writers_.clear();
    }

    // 通知所有 writer 停止
    for (auto &writer: writers) {
        writer->stop_flag.store(true, std::memory_order_release);
        writer->cond_var.notify_all();
    }

    // 等待所有线程结束
    for (auto &writer: writers) {
        writer->join_thread();
    }

    LOG_ERROR << "All writer threads stopped";
}

static bool checkDirectories(const std::string &dir) {
    if (fs::exists(dir))
        return true;
    try {
        if (!fs::create_directories(dir)) {
            LOG_ERROR << "create directories failed: " << dir;
            return false;
        }
    } catch (const fs::filesystem_error &e) {

        LOG_ERROR << "create directories filesystem error: " << e.what();
        return false;
    } catch (const std::exception &e) {
        LOG_ERROR << "create directories unknown error: " << e.what();
        return false;
    }
    return true;
}

void FeatureCacheWriter::enqueue_batch(const EmbeddingBatch &batch) {
    std::string model_key = normalizeDir(batch.base_dir);
    std::shared_ptr<ModelWriter> writer;

    // 1. 查找或创建 writer
    {
        std::unique_lock<std::mutex> lock(map_mutex_);
        auto it = model_writers_.find(model_key);
        if (it != model_writers_.end()) {
            writer = it->second;
        } else {
            writer = std::make_shared<ModelWriter>();
            model_writers_[model_key] = writer;
        }
    }

    // 2. 如果是新创建的 writer，启动线程（锁外执行）
    if (!writer->thread_started.exchange(true)) {// 原子标志，防止重复启动
        std::weak_ptr<ModelWriter> weak_writer = writer;
        writer->writer_thread = std::thread([this, model_key, weak_writer]() {
            if (auto shared_writer = weak_writer.lock()) {
                this->write_loop(model_key, shared_writer);// 修改后的签名
            } else {
                LOG_ERROR << "ModelWriter destroyed, exiting thread for: " << model_key;
            }
        });
    }

    // 3. 推入队列
    {
        std::unique_lock<std::mutex> lock(writer->mutex);
        writer->batch_queue.push(batch);
        writer->task_count++;
    }
    writer->cond_var.notify_one();
}

int FeatureCacheWriter::write_embedding(const std::string &dir,
                                        const std::vector<phx::ItemEmbeddingInfo> &embedding_items) {
    if (!checkDirectories(dir)) {
        return -1;
    }

    std::string path = dir;
    if (!path.empty() && path.back() != Core::PATH_SEPARATOR) {
        path += Core::PATH_SEPARATOR;
    }
    path += Core::ad_embedding_file;

    // 使用二进制模式
    std::ofstream output_file(path, std::ios::app | std::ios::binary);
    if (!output_file.is_open()) {
        LOG_ERROR << "Failed to open file: " << path;
        return -1;
    }

    for (const auto &item: embedding_items) {
        std::string serialized;
        if (!item.SerializeToString(&serialized)) {
            LOG_ERROR << "Failed to serialize ItemEmbeddingInfo, cid=" << item.cid();
            continue;
        }

        // 1. 先写入消息长度（4字节，网络字节序）
        uint32_t size = static_cast<uint32_t>(serialized.size());
        uint32_t net_size = htonl(size);// 转换为网络字节序

        if (!output_file.write(reinterpret_cast<const char *>(&net_size), sizeof(net_size))) {
            LOG_ERROR << "Failed to write size for cid=" << item.cid();
            return -1;
        }

        // 2. 再写入消息内容
        if (!output_file.write(serialized.data(), serialized.size())) {
            LOG_ERROR << "Failed to write data for cid=" << item.cid();
            return -1;
        }
    }

    output_file.flush();

    if (!output_file.good()) {
        LOG_ERROR << "Write operation failed for file: " << path;
        return -1;
    }

    LOG_INFO << "Successfully wrote " << embedding_items.size() << " ItemEmbeddingInfo records to: " << path;
    return 0;
}

size_t FeatureCacheWriter::getFileLineCount(const std::string &filepath) {
    std::ifstream file(filepath);
    if (!file.is_open())
        return 0;
    size_t count = 0;
    std::string line;
    while (std::getline(file, line)) {
        ++count;
    }
    return count;
}

void FeatureCacheWriter::writeTaskInfoFile(const std::string &base_dir, const std::string &model_name,
                                           int64_t model_version, size_t item_count) {
    std::string file_path = base_dir + Core::PATH_SEPARATOR + Core::task_info_file;
    std::ofstream ofs(file_path, std::ios::out | std::ios::trunc);
    if (!ofs.is_open()) {
        LOG_ERROR << "Failed to open TASK_INFO file: " << file_path;
        return;
    }
    ofs << model_name << "," << model_version << "," << item_count << std::endl;
    ofs.close();
    LOG_ERROR << "TASK_INFO file generated at: " << file_path;
}

void FeatureCacheWriter::generateSuccessFile(const std::string &base_dir) {
    std::string success_file_path = base_dir;
    if (!success_file_path.empty() && success_file_path.back() != Core::PATH_SEPARATOR) {
        success_file_path += Core::PATH_SEPARATOR;
    }
    success_file_path += Core::success_file;

    LOG_ERROR << "GENERATING SUCCESS file for: " << success_file_path;

    std::ofstream success_file(success_file_path, std::ios::out | std::ios::trunc);
    if (success_file.is_open()) {
        success_file.close();
        LOG_ERROR << "SUCCESS file CREATED: " << success_file_path;
    } else {
        LOG_ERROR << "FAILED to create SUCCESS file: " << success_file_path;
    }
}

void moveFileCrossDevice(const fs::path &source, const fs::path &target) {
    try {
        // 如果目标文件已存在，先删除
        if (fs::exists(target)) {
            fs::remove(target);
        }

        // 复制文件
        fs::copy_file(source, target, fs::copy_options::overwrite_existing);

        // 删除源文件
        fs::remove(source);

        LOG_ERROR << "已移动文件: " << source.string() << " -> " << target.string();
    } catch (const fs::filesystem_error &e) {
        LOG_ERROR << "文件移动错误: " << e.what();
        throw;
    }
}

void moveFiles(const fs::path &sourceDir, const fs::path &targetDir) {
    try {
        // 检查源目录是否存在
        if (!fs::exists(sourceDir)) {
            LOG_ERROR << "错误：源目录 " << sourceDir.string() << " 不存在。";
            return;
        }

        if (!fs::is_directory(sourceDir)) {
            LOG_ERROR << "错误： " << sourceDir.string() << " 不是一个目录。";
            return;
        }

        // 创建目标目录（包括所有父目录）
        if (!fs::exists(targetDir)) {
            fs::create_directories(targetDir);
            LOG_ERROR << "已创建目标目录: " << targetDir.string();
        }

        // 移动三个指定文件
        std::vector<std::string> filesToMove = {"_SUCCESS", "TASK_INFO", "itemEmb.txt"};
        bool allFilesMoved = true;

        for (const auto &fileName: filesToMove) {
            fs::path sourceFile = sourceDir / fileName;
            fs::path targetFile = targetDir / fileName;

            if (fs::exists(sourceFile)) {
                try {
                    moveFileCrossDevice(sourceFile, targetFile);
                } catch (const std::exception &e) {
                    LOG_ERROR << "移动文件失败: " << sourceFile.string() << " -> " << targetFile.string();
                    allFilesMoved = false;
                }
            } else {
                LOG_ERROR << "警告：文件 " << sourceFile.string() << " 不存在，跳过。";
                allFilesMoved = false;
            }
        }

        // 如果所有文件都成功移动，且源目录为空，则删除源目录
        if (allFilesMoved && fs::is_empty(sourceDir)) {
            fs::remove(sourceDir);
            LOG_ERROR << "已删除空源目录: " << sourceDir.string() << std::endl;
        }

    } catch (const fs::filesystem_error &e) {
        LOG_ERROR << "文件系统错误: " << e.what() << std::endl;
    } catch (const std::exception &e) {
        LOG_ERROR << "标准异常: " << e.what() << std::endl;
    }
}

bool FeatureCacheWriter::fetch_batch(std::shared_ptr<ModelWriter> writer, EmbeddingBatch &batch) {
    std::unique_lock<std::mutex> lock(writer->mutex);

    // 如果队列为空，等待任务或超时
    if (writer->batch_queue.empty()) {
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - writer->last_task_time);

        if (elapsed.count() >= wait_timeout_ms_) {
            LOG_ERROR << "Timeout reached for model_key";
            return false;// 超时退出
        }

        auto remaining_time = std::chrono::milliseconds(wait_timeout_ms_ - elapsed.count());
        writer->cond_var.wait_for(lock, remaining_time, [&writer] {
            return writer->stop_flag.load(std::memory_order_acquire) || !writer->batch_queue.empty();
        });

        if (writer->stop_flag.load(std::memory_order_acquire)) {
            LOG_ERROR << "Stop flag detected";
            return false;
        }

        if (writer->batch_queue.empty()) {
            LOG_ERROR << "Wait timeout";
            return false;
        }
    }

    // 队列非空，取任务
    batch = std::move(writer->batch_queue.front());
    writer->batch_queue.pop();
    writer->last_task_time = std::chrono::steady_clock::now();
    return true;
}

void FeatureCacheWriter::write_loop(const std::string &model_key, std::shared_ptr<ModelWriter> writer) {

    if (writer->stop_flag.load(std::memory_order_acquire)) {
        LOG_ERROR << "Stop flag set immediately, exiting: " << model_key;
        return;
    }

    std::string last_model_url;
    int64_t last_model_version = 0;
    bool has_processed_any = false;

    try {
        EmbeddingBatch batch;
        while (fetch_batch(writer, batch)) {
            int ret = write_embedding(batch.base_dir, batch.embedding_info);
            if (ret == 0) {
                last_model_url = batch.model_url;
                last_model_version = batch.model_version;
                has_processed_any = true;
            }
        }
    } catch (const std::exception &e) {
        LOG_ERROR << "Exception in write_loop for " << model_key << ": " << e.what();
    }

    if (has_processed_any) {
        finalize_model_files(model_key, last_model_url, last_model_version);
    }

    // 从 map 中移除
    {
        std::unique_lock<std::mutex> lock(map_mutex_);
        model_writers_.erase(model_key);
    }

    LOG_ERROR << "WRITE_LOOP ENDED: " << model_key;
}

void FeatureCacheWriter::finalize_model_files(const std::string &model_key, const std::string &last_model_url,
                                              int64_t last_model_version) {
    size_t current_lines = getFileLineCount(model_key + Core::PATH_SEPARATOR + Core::ad_embedding_file);
    writeTaskInfoFile(model_key, last_model_url, last_model_version, current_lines);
    generateSuccessFile(model_key);
    checkDirectories(Core::ServerConfig::_emb_cos_path);

    std::string relative_path = model_key.substr(Core::ServerConfig::_emb_path.length());
    if (!relative_path.empty() && relative_path[0] == '/') {
        relative_path = relative_path.substr(1);
    }
    fs::path targetDir = fs::path(Core::ServerConfig::_emb_cos_path) / relative_path;
    moveFiles(model_key, targetDir);

    if (!targetDir.empty() && last_model_version > 0) {
        LOG_ERROR << "INFO: FeatureWriter::loop: 通知词典预热, base_dir: " << targetDir.string();
        (void) Core::prerank::NotifyDictWarmup(targetDir);
    }
}