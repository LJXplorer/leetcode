#include "offline_dict_warmup_notifier.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/defs.h"
#include "common/hilog/log_helper.h"
#include <nlohmann/json.hpp>
#include <brpc/channel.h>
#include <brpc/controller.h>
#include <filesystem>
#include <fstream>
#include <sys/stat.h>

namespace Core {
namespace prerank {

int NotifyDictWarmup(const std::string& base_dir) {
    if (ServerConfig::_dict_warmup_url.empty() || ServerConfig::_dict_warmup_uri.empty()) {
        LOG_WARNING << "Dict warmup url/uri empty, skip notify";
        return 0;
    }

    // 通知前检查 _SUCCESS 与 itemEmb.txt 是否存在，并打印 itemEmb.txt 大小
    std::string data_dir = base_dir;
    if (!data_dir.empty() && data_dir.back() == Core::PATH_SEPARATOR) {
        data_dir.pop_back();
    }
    std::string success_file_path = data_dir + Core::PATH_SEPARATOR + Core::success_file;
    std::string item_emb_path = data_dir + Core::PATH_SEPARATOR + Core::ad_embedding_file;

    struct stat st_success{};
    if (stat(success_file_path.c_str(), &st_success) != 0) {
        LOG_ERROR << "DictWarmNotify: 未找到 _SUCCESS, 路径: " << success_file_path << ", 跳过预热通知";
        return 0;
    }
    struct stat st_item{};
    if (stat(item_emb_path.c_str(), &st_item) != 0) {
        LOG_ERROR << "DictWarmNotify: 未找到 itemEmb.txt, 路径: " << item_emb_path << ", 跳过预热通知";
        return 0;
    }

    // HTTP POST
    nlohmann::json body;
    const std::string cos_name = "/ai-modeldict-prod-1311258067";
    body["cosPath"] = cos_name + base_dir + Core::PATH_SEPARATOR;
    body["serviceCode"] = "item_embeding";

    try {
        brpc::Channel channel;
        brpc::ChannelOptions options;
        options.protocol = "http";
        options.connection_type = "pooled";
        if (channel.Init(ServerConfig::_dict_warmup_url.c_str(), &options) != 0) {
            LOG_ERROR << "Warmup notify: init channel failed";
            return -1;
        }

        std::string json_body = body.dump();
        brpc::Controller cntl;
        cntl.http_request().uri() = ServerConfig::_dict_warmup_uri;
        cntl.http_request().set_method(brpc::HTTP_METHOD_POST);
        cntl.http_request().set_content_type("application/json; charset=utf-8");
        cntl.set_timeout_ms(2000);
        cntl.request_attachment().append(json_body);
        channel.CallMethod(NULL, &cntl, NULL, NULL, NULL);
        if (cntl.Failed()) {
            LOG_ERROR << "Warmup notify failed, brpc error: " << cntl.ErrorText();
            return -1;
        }
        long status = cntl.http_response().status_code();
        if (status < 200 || status >= 300) {
            LOG_ERROR << "Warmup notify failed, response code: " << status
                             << ", error: " << cntl.response_attachment().to_string();
            return -1;
        }
        LOG_ERROR << "INFO: DictWarmNotify: 通知词典预热成功: cosPath: " << body["cosPath"].get<std::string>();
        return 0;
    } catch (const std::exception& e) {
        LOG_ERROR << "Warmup notify exception: " << e.what();
        return -1;
    } catch (...) {
        LOG_ERROR << "Warmup notify unknown exception";
        return -1;
    }
}

} // namespace prerank
} // namespace Core