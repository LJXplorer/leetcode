#pragma once
#include "common/comm/concurrent_map.h"
#include "common_tbuffer.h"
#include "core/core_context/core_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/defs.h"
#include "double_buffer.h"
#include <chrono>
#include <memory>
#include <shared_mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace Core {
    namespace prerank {

        struct FeatureStruct {
            int64_t version;
            std::string model_url;
            std::chrono::system_clock::time_point timestamp;
            DBuffer<std::unordered_map<int64_t, std::vector<float>>> featureVectors;

            FeatureStruct() : version(0), timestamp(std::chrono::system_clock::now()) {
            }

            FeatureStruct(int64_t ver, const std::string &url, std::chrono::system_clock::time_point ts,
                          std::unordered_map<int64_t, std::vector<float>> fvs)
                : version(ver), model_url(url), timestamp(ts) {
                featureVectors.get_current_obj()->swap(fvs);
            }
            int64_t get_version() const {
                return version;
            }
        };

        class FeatureCache {
        public:
            static FeatureCache &get_instance();

            int32_t batch_insert_feature(const std::string &model_url, int64_t model_version,
                                         const std::vector<int64_t> &creative_id, const float *vec, int32_t batch_size,
                                         int32_t vec_size, bool is_version_update);

            int32_t insert_feature(const std::string &model_url, int64_t model_version,
                                   int64_t creative_id, const std::vector<float> &feature_vec, bool is_version_update);

            int32_t get_feature(const std::string &model_url, int64_t model_version,
                                std::unordered_map<int64_t, Core::AdsPairPtr> &ads_map,
                                ExperimentModelType &predict_type);

            int32_t get_model_time(const std::string &model_url, int64_t model_version,
                                   std::chrono::system_clock::time_point &timestamp);

            int64_t get_feature_vectors_size(const std::string &url, int64_t model_version);

            void pre_allocate(const std::string &model_url, int64_t model_version, bool is_read_obj);

            int32_t commit_buffer(const std::string &model_url, int64_t model_version, bool is_version_update,
                                  bool is_first_rotate);

            int32_t clear_double_buffer(const std::string &model_url, int64_t model_version, bool is_version_update);

            std::vector<std::shared_ptr<TBuffer<FeatureStruct>>> data{
                    static_cast<size_t>(ServerConfig::_prerank_max_tuffer_size)};
            std::atomic<int64_t> index{0};
            std::mutex mtx;

            TBuffer<FeatureStruct> *append(const std::shared_ptr<TBuffer<FeatureStruct>> &newBuffer) {
                std::lock_guard<std::mutex> lck(mtx);

                // 添加到数组
                TBuffer<FeatureStruct> *result = nullptr;
                int64_t current_index = index.load();

                if (current_index < static_cast<int64_t>(data.size())) {
                    data[current_index] = newBuffer;
                    result = data[current_index].get();
                    index.fetch_add(1);
                    LOG_ERROR << "Appended new buffer.";
                    return result;
                } else {
                    LOG_ERROR << "TBuffer<FeatureStruct> is full " << ServerConfig::_prerank_max_tuffer_size
                                     << "!!!";
                    return nullptr;
                }
            }

            TBuffer<FeatureStruct> *find(const std::string &model_url) {
                auto size = index.load(std::memory_order_acquire);
                for (int64_t i = 0; i < size; ++i) {
                    // 遍历所有 TBuffer 对象
                    for (const auto &buffer: data) {
                        if (buffer) {
                            auto current_write_obj = buffer->get_current_write_obj();
                            auto active_read_obj = buffer->get_active_read_obj();
                            auto other_read_obj = buffer->get_other_read_obj();

                            if ((current_write_obj && model_url == current_write_obj->model_url) ||
                                (active_read_obj && model_url == active_read_obj->model_url) ||
                                (other_read_obj && model_url == other_read_obj->model_url)) {
                                return buffer.get();
                            }
                        }
                    }
                }
                return nullptr;
            }

        private:
            FeatureCache();
            ~FeatureCache();
        };

    }// namespace prerank
}// namespace Core
