#pragma once
#include "core/core_context/core_context.h"
#include "core/core_services/predict/predict_service.h"
#include "core/core_services/base_service/service_info.h"
#include "core/utils/error.h"
#include <brpc/options.pb.h>
#include <debug_utils.h>
#include <log_helper.h>
#include <utility>
namespace Core {
    struct PrerankUserCallBack : public google::protobuf::Closure {
        PrerankUserCallBack(::proto::flow::PredictRequest *req, ::proto::flow::PredictResponse *res,
                       Node *node, CoreContextPtr ctx, std::string channel_name, brpc::CompressType request_compress_type, ExperimentModelType model_type)
            : request(req), response(res), node(node), cntl(), context(std::move(ctx)), channel_name(std::move(channel_name)) ,model_type(model_type) {
            cntl.set_request_compress_type(request_compress_type);
        }
        ::proto::flow::PredictRequest *request;
        ::proto::flow::PredictResponse *response;
        Node *node;
        brpc::Controller cntl;
        CoreContextPtr context;
        std::string channel_name;
        ExperimentModelType model_type;

        int32_t code = 0;
        int64_t lat = 0;
        int64_t flow_cost = 0;
        void Run() override {
            LOG_INFO << "PrerankUserCallBack::Run start";
            lat = cntl.latency_us();
            code = cntl.ErrorCode();
            if (cntl.Failed()) {
                LOG_ERROR << node->get_name() << ",_channel_name:" << channel_name << ":"
                                 << cntl.ErrorText() << ",lat:" << lat;
            }

            if (response->responses_size() > 0) {
                const auto &tf_rsp = response->responses(0);
                //LOG_INFO << "model_type: " << experimentModelTypeToString(model_type) << ", tf_response: " << debug::printer::ToString(tf_rsp);
                const int32_t &error_code = tf_rsp.error_code();
                const std::string &error_message = tf_rsp.error_message();
                if (error_code != 10000) {
                    //模型返回 存在问题
                    LOG_ERROR << "model: " << channel_name << ", response error_code: " << error_code << ", error_message: " << error_message;
                } else {
                    flow_cost = tf_rsp.cost();
                    const auto &tf_rsp_outputs = tf_rsp.outputs();
                    for (const auto& output: tf_rsp_outputs) {
                        if (output.name() == "user_vec") {
                            const auto &user_embedding_vec = output.values();
                            switch(model_type) {
                                case(ExperimentModelType::USER_EMBEDDING) : {
                                    // ctr
                                    context->get_prerank_context()->MutableUserEmbeddingVec()->insert(
                                    context->get_prerank_context()->MutableUserEmbeddingVec()->end(),
                                    user_embedding_vec.float_val().data(),
                                    user_embedding_vec.float_val().data() + user_embedding_vec.float_val_size());
                                    // LOG_INFO << "ctr user embedding result = "
                                    //         << debug::printer::ToString(context->get_prerank_context()->UserEmbeddingVec());
                                    break;
                                }
                                case(ExperimentModelType::CVR_USER_EMBEDDING) : {
                                    // cvr
                                    context->get_prerank_context()->MutableCvrUserEmbeddingVec()->insert(
                                    context->get_prerank_context()->MutableCvrUserEmbeddingVec()->end(),
                                    user_embedding_vec.float_val().data(),
                                    user_embedding_vec.float_val().data() + user_embedding_vec.float_val_size());
                                    // LOG_INFO << "cvr user embedding result = "
                                    //         << debug::printer::ToString(context->get_prerank_context()->CvrUserEmbeddingVec());
                                    break;
                                }
                                default: {
                                    LOG_ERROR << "set user embedding result false, model_type:" << experimentModelTypeToString(model_type);
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
            } else {
                LOG_ERROR << "user embedding has no response: model_type: " << experimentModelTypeToString(model_type) << ", predict_response: " << debug::printer::ToString(response);
            }
            
            auto *base_service_ptr = dynamic_cast<ServiceBaseInfo *>(node);
            if (base_service_ptr != nullptr) {
                BizLatency *lat = base_service_ptr->get_node_stat(context)->get_lat();
                lat->_rsp_end_tm = get_cur_time_us();
            }
            node->run_output_nodes_if_ready(context);

            LOG_INFO << "PrerankUserCallBack::Run end";
            delete this;
        }

        void report() {
            MonitorMgr::percent_report_model(channel_name, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), code, "predict_time", lat);
            MonitorMgr::percent_report_model(channel_name,
                                                     context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()), 0, "predict_io", lat - (flow_cost * 1000));
            MonitorMgr::percent_report_model(channel_name,
                                                     context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()), 0, "model_time", flow_cost*1000);
            MonitorMgr::common_report_model(channel_name, context->GetUploadSlotName(), std::to_string(context->get_algo_scene_id()),
                                            "default", code, "req_num", 1);
       
        }
        virtual ~PrerankUserCallBack() {
            report();
        }
    };

}// namespace Core