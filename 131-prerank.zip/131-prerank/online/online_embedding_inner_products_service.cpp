#include "online_embedding_inner_products_service.h"
#include "core/core_services/prerank/truncation/include/Config.h"
#include "core/utils/monitor_mgr.h"
#include <debug_utils.h>
#include <glog/logging.h>
#include <log_helper.h>
#include <ostream>
#include <random>
namespace Core {
    constexpr static int status = 1;
    constexpr static int not_calculate_status = 2;
    SERVICE_REGISTER(OnlineEmbeddingInnerProductsService);

    bool OnlineEmbeddingInnerProductsService::skip(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        if (ctx == nullptr || ctx->_prerank_context_ptr == nullptr || !ctx->_prerank_context_ptr->GetUsePrerank()) {

            LOG_INFO << "OnlineEmbeddingInnerProductsService::skip: true";
            return true;
        }
        LOG_INFO << "OnlineEmbeddingInnerProductsService::skip: false";
        return false;
    }
    int OnlineEmbeddingInnerProductsService::do_service(GraphContextPtr context) {
        //   std::cout
        //       << "===========================OnlineEmbeddingInnerProductsService start============================================================="
        //       << std::endl;
        LOG_INFO << "OnlineEmbeddingInnerProductsService::do_service start";
        auto core_context = std::dynamic_pointer_cast<CoreContext>(context);
        BizLatency *lat = get_node_stat(core_context)->get_lat();
        BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);

        auto prerank_context = core_context->get_prerank_context();
        const std::vector<float> &user_embedding_vec = prerank_context->UserEmbeddingVec();
        LOG_INFO << "user_embedding_vec: " << debug::printer::ToString(user_embedding_vec);
        const std::vector<float> &cvr_user_embedding_vec = prerank_context->CvrUserEmbeddingVec();
        LOG_INFO << "cvr_user_embedding_vec: " << debug::printer::ToString(cvr_user_embedding_vec);
        // const std::unordered_map<std::string, std::vector<float>>
        //     &item_embedding_map = prerank_context->ItemEmbeddingVecs();

        // debug::file::WriteToFile(debug::printer::ToString(item_embedding_map),"./item_embedding_map");
        // debug::file::WriteToFile(debug::printer::ToString(user_embedding_vec),"./user_embedding_vec");

        // dtr
        int32_t pdtr_num = 0;
        float pdtr_sum = 0;
        float default_pdtr = -99999999.0;
        // cvr
        int32_t pcvr_num = 0;
        float pcvr_sum = 0;
        float default_pcvr = -99999999.0;
        if (std::shared_ptr<prerank::Config> prerank_config_ptr = prerank_context->GetConfigPtr();
            prerank_config_ptr != nullptr) {
            default_pdtr = prerank_config_ptr->prerank_default_value;
            // todo
            // default_pcvr = prerank_config_ptr->prerank_default_value;
        }
        float item_abs_avg = 0;
        size_t item_size_sum = 0;
        // 遍历物品嵌入向量映射
        for (const auto &item_ads: core_context->_ads_map) {
            const auto item_ads_pair = item_ads.second;
            if (core_context->get_prerank_context()->is_cvr_prerank_req) {
                set_prerank_ctr_score(core_context, item_ads_pair, user_embedding_vec, default_pdtr, pdtr_num,
                                      pdtr_sum);
                set_prerank_cvr_score(core_context, item_ads_pair, cvr_user_embedding_vec, default_pcvr, pcvr_num,
                                      pcvr_sum);
            } else {
                set_prerank_ctr_score(core_context, item_ads_pair, user_embedding_vec, default_pdtr, pdtr_num,
                                      pdtr_sum);
            }

            float abs_avg = item_ads_pair->get_embedding_abs_avg();// 绝对值总和
            size_t size = item_ads_pair->get_embedding_size();    // 元素个数
            item_abs_avg += abs_avg;
            item_size_sum += size;
        }
        MonitorMgr::common_report_model(
                prerank_context->item_emb_model_name_, core_context->GetUploadSlotName(),
                std::to_string(core_context->get_algo_scene_id()), "default", 0, "pdtr_number", pdtr_num);
        MonitorMgr::common_report_model(
                prerank_context->item_emb_model_name_, core_context->GetUploadSlotName(),
                std::to_string(core_context->get_algo_scene_id()), "default", 0, "pdtr", pdtr_sum);

        MonitorMgr::common_report_model(
                prerank_context->item_emb_model_name_, core_context->GetUploadSlotName(),
                std::to_string(core_context->get_algo_scene_id()), "default", 0, "item_emb_abs_avg", item_abs_avg);

        MonitorMgr::common_report_model(
                prerank_context->item_emb_model_name_, core_context->GetUploadSlotName(),
                std::to_string(core_context->get_algo_scene_id()), "default", 0, "item_emb_size", item_size_sum);

        // std::cout
        //     << "===========================OnlineEmbeddingInnerProductsService end============================================================="
        //     << std::endl;
        BizLatencyGaurd lat_guard_dst(lat, LAT_STAGE_DESTROY);
        LOG_INFO << "OnlineEmbeddingInnerProductsService::do_service end";
        return ERROR_SUCCESS;// 返回成功状态
    }

    void OnlineEmbeddingInnerProductsService::set_prerank_ctr_score(shared_ptr<CoreContext> core_context,
                                                                    const AdsPairPtr &item_ads_pair,
                                                                    const std::vector<float> &user_embedding_vec,
                                                                    float default_pdtr, int32_t &pdtr_num,
                                                                    float &pdtr_sum) {
        if (item_ads_pair->_item_embedding_vec_ == nullptr || user_embedding_vec.empty()) {
            // dtr
            item_ads_pair->_response_dump_adv->set_creativeid(item_ads_pair->get_creative_id());
            item_ads_pair->_response_dump_adv->set_prerankstatus(not_calculate_status);
            item_ads_pair->_response_dump_adv->set_prerankrawscore(default_pdtr);
            item_ads_pair->_response_dump_adv->set_prerankscore(default_pdtr);
            LOG_INFO << "ctr default status : " << status << ",inner_product:" << default_pdtr << endl;

        } else {
            // ctr
            // 计算内积
            float inner_product = cblas_sdot(user_embedding_vec.size(), user_embedding_vec.data(), 1,
                                             item_ads_pair->_item_embedding_vec_->data(), 1);
            ++pdtr_num;
            pdtr_sum = pdtr_sum + inner_product;
            item_ads_pair->_response_dump_adv->set_creativeid(item_ads_pair->get_creative_id());
            item_ads_pair->_response_dump_adv->set_prerankstatus(status);
            item_ads_pair->_response_dump_adv->set_prerankrawscore(inner_product);
            item_ads_pair->_response_dump_adv->set_prerankscore(inner_product);

            if (core_context->get_rank_request()->debuglevel() == DebugLevel::kPrerank) {
                std::ostringstream oss;

                // 拼接 creativeId
                oss << "creativeId: " << item_ads_pair->get_creative_id() << std::endl;

                // 拼接 user_embedding_vec 并添加标识
                oss << "user: ";
                for (size_t i = 0; i < user_embedding_vec.size(); ++i) {
                    oss << user_embedding_vec[i];
                    if (i < user_embedding_vec.size() - 1) {
                        oss << ",";// 用逗号分隔，最后一个值不加逗号
                    }
                }
                oss << std::endl << "score" << inner_product << std::endl;// 换行

                // 写入文件
                debug::file::WriteToFile(core_context->get_req_id() + "_inner.json", oss.str());
            }
        }
    }

    void OnlineEmbeddingInnerProductsService::set_prerank_cvr_score(shared_ptr<CoreContext> core_context,
                                                                    const AdsPairPtr &item_ads_pair,
                                                                    const std::vector<float> &cvr_user_embedding_vec,
                                                                    float default_pcvr, int32_t &pcvr_num,
                                                                    float &pcvr_sum) {
        if (core_context->get_prerank_context()->enable_skip_cvr_prerank) {
            LOG_INFO << "enable_skip_cvr_prerank is ture";
            return;
        }

        if (item_ads_pair->_cvr_item_embedding_vec_ == nullptr || cvr_user_embedding_vec.empty()) {
            // cvr
            item_ads_pair->_preRankingScore_cvr_status = not_calculate_status;
            item_ads_pair->_preRankingScore_cvr_score = default_pcvr;
            item_ads_pair->_preRankingScore_cvr_score_raw = default_pcvr;

        } else {
            // 计算内积
            float inner_product = cblas_sdot(cvr_user_embedding_vec.size(), cvr_user_embedding_vec.data(), 1,
                                             item_ads_pair->_cvr_item_embedding_vec_->data(), 1);
            ++pcvr_num;
            pcvr_sum = pcvr_sum + inner_product;
            item_ads_pair->_preRankingScore_cvr_status = status;
            item_ads_pair->_preRankingScore_cvr_score = inner_product;
            item_ads_pair->_preRankingScore_cvr_score_raw = inner_product;
            LOG_INFO << "cvr status: " << status << ",inner_product:" << inner_product << endl;
        }
    }
}// namespace Core