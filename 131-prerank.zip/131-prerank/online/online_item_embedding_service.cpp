#include "online_item_embedding_service.h"
#include "core/core_services/prerank/embedding_cache/feature_cache.h"
#include "core/utils/defs.h"
#include "core/utils/error.h"
#include "core/utils/monitor_mgr.h"
#include "core/core_services/predict/utils/model_version.h"
#include <debug_utils.h>
#include <log_helper.h>
namespace Core {
SERVICE_REGISTER(OnlineItemEmbeddingService);
void OnlineItemEmbeddingService::initialize(ConfigXmlPtr xml) {
  initialize_xml(xml);
}

void OnlineItemEmbeddingService::initialize_xml(ConfigXmlPtr xml) {}

void OnlineItemEmbeddingService::initialize(GraphContextPtr context) {
  auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
  ctx->get_monitor_context()->alloc_node(get_name());
}
bool OnlineItemEmbeddingService::skip(GraphContextPtr context) {
  auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
  if (ctx == nullptr || ctx->_prerank_context_ptr == nullptr ||
      !ctx->_prerank_context_ptr->GetUsePrerank()) {
    return true;
  }
  return false;
}
int OnlineItemEmbeddingService::do_service(GraphContextPtr context) {
  LOG_INFO << "OnlineItemEmbeddingService::do_service start";
  
  // std::cout<<"==================OnlineItemEmbeddingService start================"<<std::endl;
  auto core_context = std::dynamic_pointer_cast<CoreContext>(context);
  BizLatency* lat = get_node_stat(core_context)->get_lat();
  BizLatencyGaurd lat_guard(lat,LAT_STAGE_CREATE);

  auto prerank_context = core_context->get_prerank_context();
  int ret = 0;
  ExperimentModelType predict_type = get_predict_type();
  if (predict_type == ExperimentModelType::ITEM_EMBEDDING) {
    // ctr
    ret = prerank::FeatureCache::get_instance().get_feature(
      prerank_context->item_emb_model_name_,
      prerank_context->max_common_version_,
      core_context->_ads_map,
      predict_type);
    LOG_INFO << "PREDICT_TYPE_ITEM_EMBEDDING ret: " << ret << ",model url: "<< prerank_context->item_emb_model_name_ << ",model_version: " << prerank_context->max_common_version_;

    // 上报item总数
    MonitorMgr::common_report_model(prerank_context->item_emb_model_name_, core_context->GetUploadSlotName() ,std::to_string(core_context->get_algo_scene_id()), "default",0, "item_quantity", static_cast<double>(core_context->_ads_map.size()));
    //上报查找到的数量: 不等于ERROR_FEATURE_CACHE_NOT_VERSION时, ret为没找到的item的数量，上报找到的数量，否则上报0，也就是不上报
    if (ret != ERROR_FEATURE_CACHE_NOT_VERSION) {
      MonitorMgr::common_report_model(prerank_context->item_emb_model_name_, core_context->GetUploadSlotName() ,std::to_string(core_context->get_algo_scene_id()), "default", 0, "item_found_quantity", static_cast<double>(core_context->_ads_map.size() - ret));
    }
    //上报版本不一致的数量
    if (ret == ERROR_FEATURE_CACHE_NOT_VERSION)
    {
      MonitorMgr::common_report_model(prerank_context->item_emb_model_name_, core_context->GetUploadSlotName() ,std::to_string(core_context->get_algo_scene_id()), "default", 0, "item_cache_version_inconsistency", static_cast<int>(core_context->_ads_map.size()));
      MonitorMgr::common_report_model(prerank_context->item_emb_model_name_, core_context->GetUploadSlotName() , std::to_string(core_context->get_algo_scene_id()), "default", 0, "model_version_diff", 1.0);

    }
    auto now_time = std::chrono::system_clock::now();
    std::chrono::system_clock::time_point model_time;
    prerank::FeatureCache::get_instance().get_model_time(prerank_context->item_emb_model_name_, prerank_context->max_common_version_, model_time);
    if (std::chrono::duration_cast<std::chrono::hours>(now_time - model_time).count() > 2)
    {
      MonitorMgr::common_report_model(prerank_context->item_emb_model_name_, core_context->GetUploadSlotName() ,std::to_string(core_context->get_algo_scene_id()), "default", 0,"item_cache_query_time_exceed_threshold", 1);
    }
  }

  BizLatencyGaurd lat_guard_dst(lat,LAT_STAGE_DESTROY);
  LOG_INFO << "OnlineItemEmbeddingService::do_service end";
  return ERROR_SUCCESS;
}

} // namespace Core