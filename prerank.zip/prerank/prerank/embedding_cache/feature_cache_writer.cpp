#include "feature_cache_writer.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/defs.h"
#include "prerank/prerank_embedding.pb.h"
#include <arpa/inet.h>
#include <iostream>
#include <log_helper.h>
#include <sys/stat.h>
#include <wrapper_time.h>
FeatureCacheWriter g_feature_cache_writer;
namespace fs = std::filesystem;

static std::string normalizeDir(const std::string &dir) {
    std::string res = dir;
    while (!res.empty() && (res.back() == '/' || res.back() == '\\')) {
        res.pop_back();
    }
    return res;
}

FeatureCacheWriter::FeatureCacheWriter(int wait_timeout_ms) : wait_timeout_ms_(wait_timeout_ms) {
}

FeatureCacheWriter::~FeatureCacheWriter() {
    HILOG_APP(ERROR) << "FeatureCacheWriter destructor called";

    std::vector<std::shared_ptr<ModelWriter>> writers;
    {
        std::unique_lock<std::mutex> lock(map_mutex_);
        writers.reserve(model_writers_.size());
        for (auto &[key, writer]: model_writers_) {
            writers.push_back(writer);
        }
        model_writers_.clear();
    }

    // 通知所有 writer 停止
    for (auto &writer: writers) {
        writer->stop_flag.store(true, std::memory_order_release);
        writer->cond_var.notify_all();
    }

    // 等待所有线程结束
    for (auto &writer: writers) {
        writer->join_thread();
    }

    HILOG_APP(ERROR) << "All writer threads stopped";
}

static bool checkDirectories(const std::string &dir) {
    if (fs::exists(dir))
        return true;
    try {
        if (!fs::create_directories(dir)) {
            HILOG_APP(ERROR) << "create directories failed: " << dir;
            return false;
        }
    } catch (const fs::filesystem_error &e) {
        HILOG_APP(ERROR) << "create directories filesystem error: " << e.what();
        return false;
    } catch (const std::exception &e) {
        HILOG_APP(ERROR) << "create directories unknown error: " << e.what();
        return false;
    }
    return true;
}

void FeatureCacheWriter::enqueue_batch(const EmbeddingBatch &batch) {
    std::string model_key = normalizeDir(batch.base_dir);
    std::shared_ptr<ModelWriter> writer;

    {
        std::unique_lock<std::mutex> lock(map_mutex_);
        auto it = model_writers_.find(model_key);
        if (it == model_writers_.end()) {
            writer = std::make_shared<ModelWriter>();
            model_writers_[model_key] = writer;
            // 使用 lambda 确保正确的生命周期管理
            writer->writer_thread = std::thread([this, model_key, writer]() { this->write_loop(model_key); });
        } else {
            writer = it->second;
        }
    }

    {
        std::unique_lock<std::mutex> lock(writer->mutex);
        writer->batch_queue.push(batch);
        writer->task_count++;
    }
    writer->cond_var.notify_one();
}

int FeatureCacheWriter::write_embedding(const std::string &dir,
                                        const std::vector<phx::ItemEmbeddingInfo> &embedding_items) {
    if (!checkDirectories(dir)) {
        return -1;
    }

    std::string path = dir;
    if (!path.empty() && path.back() != Core::PATH_SEPARATOR) {
        path += Core::PATH_SEPARATOR;
    }
    path += Core::ad_embedding_file;

    // 使用二进制模式
    std::ofstream output_file(path, std::ios::app | std::ios::binary);
    if (!output_file.is_open()) {
        HILOG_APP(ERROR) << "Failed to open file: " << path;
        return -1;
    }

    for (const auto &item: embedding_items) {
        std::string serialized;
        if (!item.SerializeToString(&serialized)) {
            HILOG_APP(ERROR) << "Failed to serialize ItemEmbeddingInfo, cid=" << item.cid();
            continue;
        }

        // 1. 先写入消息长度（4字节，网络字节序）
        uint32_t size = static_cast<uint32_t>(serialized.size());
        uint32_t net_size = htonl(size);// 转换为网络字节序

        if (!output_file.write(reinterpret_cast<const char *>(&net_size), sizeof(net_size))) {
            HILOG_APP(ERROR) << "Failed to write size for cid=" << item.cid();
            return -1;
        }

        // 2. 再写入消息内容
        if (!output_file.write(serialized.data(), serialized.size())) {
            HILOG_APP(ERROR) << "Failed to write data for cid=" << item.cid();
            return -1;
        }
    }

    output_file.flush();

    if (!output_file.good()) {
        HILOG_APP(ERROR) << "Write operation failed for file: " << path;
        return -1;
    }

    HILOG_APP(ERROR) << "Successfully wrote " << embedding_items.size() << " ItemEmbeddingInfo records to: " << path;
    output_file.close();

    try {
        fs::rename(path, Core::ServerConfig::_emb_cos_path);
        HILOG_APP(INFO) << "File successfully moved from '" << path << "' to '" << Core::ServerConfig::_emb_cos_path
                        << "'";
    } catch (const fs::filesystem_error &e) {
        HILOG_APP(ERROR) << "Failed to move file: " << e.what();
        return -1;
    }
    HILOG_APP(ERROR) << "File mv completed: " << path;
    return 0;
}

size_t FeatureCacheWriter::getFileLineCount(const std::string &filepath) {
    std::ifstream file(filepath);
    if (!file.is_open())
        return 0;
    size_t count = 0;
    std::string line;
    while (std::getline(file, line)) {
        ++count;
    }
    return count;
}

void FeatureCacheWriter::writeTaskInfoFile(const std::string &base_dir, const std::string &model_name,
                                           int64_t model_version, size_t item_count) {
    std::string file_path = base_dir + Core::PATH_SEPARATOR + Core::task_info_file;
    std::ofstream ofs(file_path, std::ios::out | std::ios::trunc);
    if (!ofs.is_open()) {
        HILOG_APP(ERROR) << "Failed to open TASK_INFO file: " << file_path;
        return;
    }
    ofs << model_name << "," << model_version << "," << item_count << std::endl;
    ofs.close();
    HILOG_APP(ERROR) << "TASK_INFO file generated at: " << file_path;
}

void FeatureCacheWriter::generateSuccessFile(const std::string &base_dir) {
    std::string success_file_path = base_dir;
    if (!success_file_path.empty() && success_file_path.back() != Core::PATH_SEPARATOR) {
        success_file_path += Core::PATH_SEPARATOR;
    }
    success_file_path += Core::success_file;

    HILOG_APP(ERROR) << "GENERATING SUCCESS file for: " << success_file_path;

    std::ofstream success_file(success_file_path, std::ios::out | std::ios::trunc);
    if (success_file.is_open()) {
        success_file.close();
        HILOG_APP(ERROR) << "SUCCESS file CREATED: " << success_file_path;
    } else {
        HILOG_APP(ERROR) << "FAILED to create SUCCESS file: " << success_file_path;
    }
}

void FeatureCacheWriter::write_loop(const std::string &model_key) {
    std::ostringstream oss;
    oss << std::this_thread::get_id();
    std::string thread_id = oss.str();
    HILOG_APP(ERROR) << "WRITE_LOOP STARTED for model_key: " << model_key << ", thread_id: " << thread_id;

    // 获取 writer 实例
    std::shared_ptr<ModelWriter> writer;
    {
        std::unique_lock<std::mutex> lock(map_mutex_);
        auto it = model_writers_.find(model_key);
        if (it == model_writers_.end()) {
            HILOG_APP(ERROR) << "Writer not found in map, exiting: " << model_key;
            return;
        }
        writer = it->second;
    }

    // 立即检查停止标志
    if (writer->stop_flag.load(std::memory_order_acquire)) {
        HILOG_APP(ERROR) << "Stop flag set immediately, exiting: " << model_key;
        return;
    }

    std::string last_model_url;
    int64_t last_model_version = 0;
    bool has_processed_any = false;
    auto last_task_time = std::chrono::steady_clock::now();

    try {
        while (true) {
            EmbeddingBatch batch;
            bool has_task = false;

            {
                std::unique_lock<std::mutex> lock(writer->mutex);

                // 检查停止标志
                if (writer->stop_flag.load(std::memory_order_acquire)) {
                    HILOG_APP(ERROR) << "Stop flag detected in main loop: " << model_key;
                    break;
                }

                // 尝试获取任务
                if (!writer->batch_queue.empty()) {
                    batch = std::move(writer->batch_queue.front());
                    writer->batch_queue.pop();
                    has_task = true;
                    last_task_time = std::chrono::steady_clock::now();
                } else {
                    // 等待任务或超时
                    auto now = std::chrono::steady_clock::now();
                    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - last_task_time);

                    if (elapsed.count() >= wait_timeout_ms_) {
                        HILOG_APP(ERROR) << "Timeout reached: " << model_key;
                        break;
                    }

                    auto remaining_time = std::chrono::milliseconds(wait_timeout_ms_ - elapsed.count());

                    // 使用条件变量等待
                    if (writer->cond_var.wait_for(lock, remaining_time, [&writer] {
                            return writer->stop_flag.load(std::memory_order_acquire) || !writer->batch_queue.empty();
                        })) {
                        // 被唤醒，检查原因
                        if (writer->stop_flag.load(std::memory_order_acquire)) {
                            HILOG_APP(ERROR) << "Woken by stop flag: " << model_key;
                            break;
                        }

                        if (!writer->batch_queue.empty()) {
                            batch = std::move(writer->batch_queue.front());
                            writer->batch_queue.pop();
                            has_task = true;
                            last_task_time = std::chrono::steady_clock::now();
                        }
                    } else {
                        // 超时
                        HILOG_APP(ERROR) << "Wait timeout: " << model_key;
                        break;
                    }
                }
            }

            // 处理任务
            if (has_task) {
                int ret = write_embedding(batch.base_dir, batch.embedding_info);
                if (ret == 0) {
                    last_model_url = batch.model_url;
                    last_model_version = batch.model_version;
                    has_processed_any = true;
                }
            }
        }
    } catch (const std::exception &e) {
        HILOG_APP(ERROR) << "Exception in write_loop for " << model_key << ": " << e.what();
    }

    // 生成最终文件
    if (has_processed_any) {
        size_t current_lines = getFileLineCount(model_key + Core::PATH_SEPARATOR + Core::ad_embedding_file);
        writeTaskInfoFile(model_key, last_model_url, last_model_version, current_lines);
        generateSuccessFile(model_key);
    }

    // 从 map 中移除
    {
        std::unique_lock<std::mutex> lock(map_mutex_);
        model_writers_.erase(model_key);
        HILOG_APP(ERROR) << "Removed from map: " << model_key;
    }

    HILOG_APP(ERROR) << "WRITE_LOOP ENDED: " << model_key << ", thread: " << thread_id;
}
