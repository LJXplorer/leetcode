#ifndef FEATURE_CACHE_WRITER_H
#define FEATURE_CACHE_WRITER_H

#include "prerank/prerank_embedding.pb.h"
#include <atomic>
#include <condition_variable>
#include <fstream>
#include <memory>
#include <mutex>
#include <queue>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

struct EmbeddingBatch {
    std::string model_url;
    int64_t model_version;
    std::vector<int64_t> creative_ids;
    std::vector<phx::ItemEmbeddingInfo> embedding_info;
    bool is_version_update;
    std::string base_dir;// 作为模型唯一标识
};

struct ModelWriter {
    std::mutex mutex;
    std::condition_variable cond_var;
    std::queue<EmbeddingBatch> batch_queue;
    std::thread writer_thread;
    std::atomic<bool> stop_flag{false};
    std::atomic<bool> thread_joined{false};
    bool done_flag = false;
    int task_count = 0;

    ModelWriter() = default;

    // 关键：禁用拷贝构造和赋值
    ModelWriter(const ModelWriter&) = delete;
    ModelWriter& operator=(const ModelWriter&) = delete;

    ~ModelWriter() {
        
        // 设置停止标志
        stop_flag.store(true, std::memory_order_release);
        cond_var.notify_all();
        
        // 安全地 join 线程
        join_thread();
    }

    void join_thread() {
        if (!thread_joined.load(std::memory_order_acquire) && 
            writer_thread.joinable()) {
            try {
                writer_thread.join();
                thread_joined.store(true, std::memory_order_release);
            } catch (const std::system_error& e) {
                // 如果 join 失败，尝试 detach 来避免 terminate
                if (writer_thread.joinable()) {
                    writer_thread.detach();
                }
            }
        }
    }
};

class FeatureCacheWriter {
public:
    explicit FeatureCacheWriter(int wait_timeout_ms = 30000);
    ~FeatureCacheWriter();

    void enqueue_batch(const EmbeddingBatch &batch);

private:
    void write_loop(const std::string &model_key);
    int write_embedding(const std::string &dir, const std::vector<phx::ItemEmbeddingInfo> &embedding_items);
    void generateSuccessFile(const std::string &base_dir);
    size_t getFileLineCount(const std::string &filepath);
    void writeTaskInfoFile(const std::string &base_dir, const std::string &model_name, int64_t model_version,
                           size_t item_count);

    std::unordered_map<std::string, std::shared_ptr<ModelWriter>> model_writers_;
    std::mutex map_mutex_;
    int wait_timeout_ms_ = 30000;
};

extern FeatureCacheWriter g_feature_cache_writer;

#endif// FEATURE_CACHE_WRITER_H
