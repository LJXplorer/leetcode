#include "feature_cache.h"
#include "common_tbuffer.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/defs.h"
#include "core/utils/error.h"
#include <algorithm>
#include <asm-generic/errno.h>
#include <chrono>
#include <log_helper.h>
#include <memory>

namespace Core {
    namespace prerank {

        FeatureCache::FeatureCache() {
        }
        FeatureCache::~FeatureCache() {
        }

        FeatureCache &FeatureCache::get_instance() {
            static FeatureCache instance;
            return instance;
        }

        void FeatureCache::pre_allocate(const std::string &model_url, int64_t model_version, bool is_read_obj) {

            TBuffer<FeatureStruct> *found_buffer = find(model_url);

            if (found_buffer == nullptr) {
                auto featureStruct = std::make_shared<FeatureStruct>(
                        model_version,                                   // 初始版本号
                        model_url,                                       // model_url
                        std::chrono::system_clock::now(),                // 时间戳
                        std::unordered_map<int64_t, std::vector<float>>()// 空的特征向量映射
                );

                // 创建新的 TBuffer
                auto newBuffer = std::make_shared<TBuffer<FeatureStruct>>();
                newBuffer->get_current_write_obj() = featureStruct;

                found_buffer = append(newBuffer);
                if (found_buffer == nullptr) {
                    HILOG_APP(ERROR) << "FeatureCache::pre_allocate — Failed to append new buffer for model: "
                                     << model_url;
                    return;
                }
            }

            // 更新当前写入对象的版本和时间戳
            std::shared_ptr<FeatureStruct> opt_obj =
                    is_read_obj ? found_buffer->get_active_read_obj() : found_buffer->get_current_write_obj();
            opt_obj->version = model_version;
            opt_obj->model_url = model_url;
            opt_obj->timestamp = std::chrono::system_clock::now();

            // 清空特征向量，准备接收新数据
            auto &featureVectors = *opt_obj->featureVectors.get_current_obj();
            featureVectors.clear();
        }

        int32_t FeatureCache::batch_insert_feature(const std::string &model_url, int64_t model_version,
                                                   const std::vector<int64_t> &creative_id, const float *vec,
                                                   int32_t batch_size, int32_t vec_size, bool is_version_update) {
            if (batch_size <= 0 || batch_size != static_cast<int32_t>(creative_id.size()) || vec == nullptr) {
                HILOG_APP(ERROR) << "FeatureCache::batch_insert_feature — Invalid parameters: batch_size="
                                 << batch_size;
                return ERROR_FEATURE_CACHE_PARAMETER;
            }

            TBuffer<FeatureStruct> *buffer = find(model_url);
            if (buffer == nullptr) {
                HILOG_APP(ERROR) << "FeatureCache::batch_insert_feature — Cache not found for model: " << model_url;
                return ERROR_FEATURE_CACHE_PARAMETER;
            }
            std::shared_ptr<FeatureStruct> opt_obj =
                    is_version_update ? buffer->get_current_write_obj() : buffer->get_obj_by_version(model_version);

            if (opt_obj == nullptr) {
                HILOG_APP(ERROR) << "FeatureCache::batch_insert_feature — Cache not found for model: " << model_url
                                 << "model_version" << model_version;
                return ERROR_FEATURE_CACHE_NOT_VERSION;
            }

            auto &featureVectorsBak = *opt_obj->featureVectors.get_bak_obj();
            for (size_t i = 0; i < static_cast<size_t>(batch_size); i++) {
                featureVectorsBak[creative_id[i]] = std::vector<float>(vec + i * vec_size, vec + (i + 1) * vec_size);
            }

            return ERROR_SUCCESS;
        }

        int32_t FeatureCache::commit_buffer(const std::string &model_url, int64_t model_version, bool is_version_update,
                                            bool is_first_rotate) {
            TBuffer<FeatureStruct> *buffer = find(model_url);
            if (buffer == nullptr) {
                HILOG_APP(ERROR) << "FeatureCache::commit_buffer — Cache not found for model: " << model_url;
                return ERROR_FEATURE_CACHE_PARAMETER;
            }

            std::shared_ptr<FeatureStruct> opt_obj =
                    is_version_update ? buffer->get_current_write_obj() : buffer->get_obj_by_version(model_version);

            if (opt_obj == nullptr) {
                HILOG_APP(ERROR) << "FeatureCache::commit_buffer — Cache not found for model: " << model_url
                                 << "model_version" << model_version;
                return ERROR_FEATURE_CACHE_NOT_VERSION;
            }

            // 切双缓冲
            opt_obj->featureVectors.change();
            opt_obj->timestamp = std::chrono::system_clock::now();

            if (is_first_rotate) {
                buffer->first_rotate_buffers();
            } else if (is_version_update) {
                buffer->rotate_buffers();
            }

            HILOG_APP(INFO) << "FeatureCache::commit_buffer — committed for model: " << model_url;
            return ERROR_SUCCESS;
        }

        int32_t FeatureCache::clear_double_buffer(const std::string &model_url, int64_t model_version,
                                                  bool is_version_update) {
            TBuffer<FeatureStruct> *buffer = find(model_url);
            if (buffer == nullptr) {
                HILOG_APP(ERROR) << "FeatureCache::clear_double_buffer — Cache not found for model: " << model_url;
                return ERROR_FEATURE_CACHE_PARAMETER;
            }

            if (!is_version_update) {
                std::shared_ptr<FeatureStruct> opt_obj = buffer->get_obj_by_version(model_version);
                auto &featureVectorsBak = *opt_obj->featureVectors.get_bak_obj();
                featureVectorsBak.clear();
            }
            return ERROR_SUCCESS;
        }

        int32_t FeatureCache::get_feature(const std::string &model_url, int64_t model_version,
                                          std::unordered_map<int64_t, Core::AdsPairPtr> &ads_map,
                                          ExperimentModelType &predict_type) {
            TBuffer<FeatureStruct> *buffer = find(model_url);
            if (buffer == nullptr) {
                HILOG_APP(ERROR) << "FeatureCache::get_feature — Cache not found for model: " << model_url
                                 << "model_version" << model_version;
                return ERROR_FEATURE_CACHE_NOT_VERSION;
            }

            auto obj = buffer->get_obj_by_version(model_version);
            if (obj == nullptr) {
                HILOG_APP(ERROR) << "FeatureCache::get_feature — Version not found: " << model_version;
                return ERROR_FEATURE_CACHE_NOT_VERSION;
            }

            auto &featureVectors = *obj->featureVectors.get_current_obj();

            HILOG_APP(ERROR) << "古古古古娜拉黑暗之神：FeatureCache::get_feature — featureVectors size: " << featureVectors.size();

            int32_t not_found_ids = 0;
            for (const auto &ads: ads_map) {
                auto featureIt = featureVectors.find(ads.first);
                if (featureIt != featureVectors.end()) {
                    switch (predict_type) {
                        case ExperimentModelType::ITEM_EMBEDDING:
                            ads.second->_item_embedding_vec_ = std::make_shared<std::vector<float>>(featureIt->second);
                            break;
                        case ExperimentModelType::CVR_ITEM_EMBEDDING:
                            ads.second->_cvr_item_embedding_vec_ =
                                    std::make_shared<std::vector<float>>(featureIt->second);
                            break;
                        default:
                            break;
                    }
                } else {
                    not_found_ids++;
                    //HILOG_APP(ERROR) << "FeatureCache::not_found_ids " << ads.first;
                }
            }
            return not_found_ids;
        }

        int32_t FeatureCache::get_model_time(const std::string &model_url, int64_t model_version,
                                             std::chrono::system_clock::time_point &timestamp) {
            TBuffer<FeatureStruct> *buffer = find(model_url);
            if (buffer == nullptr) {
                return ERROR_FEATURE_CACHE_NOT_VERSION;
            }

            // 使用新的 get_obj_by_version() 方法
            auto obj = buffer->get_obj_by_version(model_version);
            if (obj == nullptr) {
                return ERROR_FEATURE_CACHE_NOT_VERSION;
            }

            timestamp = obj->timestamp;
            return ERROR_SUCCESS;
        }

        int64_t FeatureCache::get_feature_vectors_size(const std::string &model_url, int64_t model_version) {
            TBuffer<FeatureStruct> *buffer = find(model_url);
            if (buffer == nullptr) {
                return 0;
            }

            // 使用新的 get_obj_by_version() 方法
            auto obj = buffer->get_obj_by_version(model_version);
            if (obj == nullptr) {
                return 0;
            }

            auto &feature_map = *obj->featureVectors.get_current_obj();
            return static_cast<int64_t>(feature_map.size());
        }
    }// namespace prerank
}// namespace Core
