#include "core/core_services/prerank/offline/offline_embedding_fe_service.h"
#include "core/core_context/core_context.h"
#include "core/core_services/fe/fe_service.h"
#include "core/utils/error.h"
#include "offline_emb_common.h"
#include "phx-fe/src/framework.h"
#include <exception>
#include <google/protobuf/arena.h>
#include <latch.h>
#include <lockfree_threadpool.h>
#include <log_helper.h>
#include <memory>

namespace Core {
    SERVICE_REGISTER(OfflineEmbeddingFeService);
    common::lockfree_threadpool::Executor OfflineEmbeddingFeService::s_offline_itemembedding_fe_executor =
            common::lockfree_threadpool::Executor(5, 10240, "o_item_emb", 1000 * 100);
    phx::UserAction OfflineEmbeddingFeService::s_empty_user_action = {};
    int OfflineEmbeddingFeService::do_service(GraphContextPtr context) {
        auto core_context = dynamic_pointer_cast<CoreContext>(context);
        auto prerank_context = core_context->get_prerank_context();
        int64_t split_size = static_cast<int64_t>(prerank_context->_offline_item_embedding_map.size());
        common::SimpleLatch latch{split_size};
        std::vector<ExtractorArgs> args_vec{};
        BizLatency *lat = get_node_stat(core_context)->get_lat();
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);
            for (const auto &[index, items]: prerank_context->_offline_item_embedding_map) {
                HILOG_APP(INFO)<< "femap size: " << items.size();
                auto *extractor_response =
                        google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(core_context->get_context_arena());

                prerank_context->_offline_item_embedding_fe_response_map.insert({index, extractor_response});
                ExtractorArgs arg{};
                arg.extractor_result = prerank_context->_offline_item_embedding_fe_response_map[index];
                arg.arena = core_context->get_context_arena();
                arg.split_index = index;
                arg.fe_request = BuildOfflineFeRequest(arg.arena, items);
                arg.item_emb_model_info = prerank_context->_offline_item_model_info;
                arg.latch = &latch;
                args_vec.emplace_back(std::move(arg));
            }
        }
        {
            BizLatencyGaurd lat_guard_dst(lat, LAT_STAGE_DESTROY);
            for (auto &args: args_vec) {
                common::lockfree_threadpool::TaskWrapper task_wrapper{};
                task_wrapper.args = (void *) (&args);
                task_wrapper.t = OfflineEmbeddingFeService::Extract;
                OfflineEmbeddingFeService::s_offline_itemembedding_fe_executor.enqueue(task_wrapper);
            }
            latch.Wait();
        }
        

        HILOG_APP(INFO)<< "fe result size: " << prerank_context->_offline_item_embedding_fe_response_map.size() ;
        return ERROR_SUCCESS;
    }
    phx::FeRequest *OfflineEmbeddingFeService::BuildOfflineFeRequest(google::protobuf::Arena *arena,
                                                                     const std::vector<ItemWrapper> &items) {
        auto *fe_request = google::protobuf::Arena::CreateMessage<phx::FeRequest>(arena);
        for (const auto &item: items) {
            auto prerank_item_fea = fe_request->add_prerank_item_fea();
            prerank_item_fea->mutable_prerank_item_info()->set_appid(item.item->appid());
            prerank_item_fea->mutable_prerank_item_info()->set_creative_id(item.item->creativeid());
        }

        return fe_request;
    }
    void *OfflineEmbeddingFeService::Extract(void *arg) {
        ExtractorArgs *fe_arg = (ExtractorArgs *) (arg);
        try {
            toExtractorResponse(fe_arg->arena, *(fe_arg->fe_request), s_empty_user_action,
                                fe_arg->item_emb_model_info->get_config_info(), *fe_arg->extractor_result, true);
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "fe extract failed! msg = " << e.what();
        } catch (...) {
            HILOG_APP(ERROR) << "fe extract failed! unknown exception";
        }
        fe_arg->latch->CountDown();
        return nullptr;
    }

}// namespace Core