#include "offline_emb_common.h"
namespace Core::prerank {
     common::ThreadPool g_offline_emb_executor{4, "offline_emb"};
}