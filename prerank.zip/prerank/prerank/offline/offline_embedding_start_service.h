#pragma once
#include "core/core_context/core_context.h"
#include "core/core_context/fs_context.h"
#include "core/core_services/base_service/service_info.h"
#include "common/comm/debug_utils.h"
#include <memory>
namespace Core {
class EmbeddingStartService : public ServiceBaseInfo {
public:
  EmbeddingStartService() {}

  ~EmbeddingStartService() {}

  virtual void initialize(ConfigXmlPtr xml) override ;
  virtual void initialize_xml(ConfigXmlPtr xml);
  virtual void initialize(GraphContextPtr context) {
    auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
  };
  virtual int do_service(GraphContextPtr context) override;
  virtual int process(CoreContextPtr context);

private:
  void GetItemFromDict(const std::string& dict_name, phx::PredictorSlotInfo *ad_data, const std::string& model_name);
  int _split_size = 40;
};
} // namespace Core