#pragma once
#include "common/comm/lockfree_threadpool.h"
#include "core/core_context/context_defs.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/fe/fe_service.h"
#include "phx-fe/util/util.h"
#include <google/protobuf/arena.h>
#include <latch.h>
namespace Core {
    class OfflineEmbeddingFeService : public ServiceBaseInfo {
    public:
        struct ExtractorArgs {
            google::protobuf::Arena *arena;
            int32_t split_index;
            phx::ExtractorResponse *extractor_result;
            phx::FeRequest *fe_request;
            std::shared_ptr<Info::ModelInfo> item_emb_model_info;
            common::SimpleLatch *latch;
        };
        int do_service(GraphContextPtr context) override;
        phx::FeRequest *BuildOfflineFeRequest(google::protobuf::Arena *arena, const std::vector<ItemWrapper> &items);

    private:
        static common::lockfree_threadpool::Executor s_offline_itemembedding_fe_executor;
        static void *Extract(void *arg);
        static phx::UserAction s_empty_user_action;
    };
}// namespace Core