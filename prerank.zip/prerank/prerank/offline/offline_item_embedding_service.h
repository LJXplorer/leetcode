#pragma once

#include "common/comm/thread_pool.h"
#include "core/core_services/predict/predict_service.h"
#include "tf/flow.pb.h"
#include <memory>

namespace Core {

class OfflineItemEmbeddingService : public ServiceBaseInfo {

private:
  void get_item_slot_data_types(const phx::ExtractorResponse * extractor_responses,
                                const size_t &slot_num,std::vector<SlotDataType>& slot_data_type);
  void parse_item_list_item_embedding(const phx::ExtractorResponse *extractor_response, const size_t &item_slot_num,
                                const std::vector<SlotDataType> &item_slot_data_types, CoreContextPtr &context,
                                const std::string &model_name, std::vector<SlotInfo>& item_slot_list);
public:
  OfflineItemEmbeddingService() =default;
  void initialize_xml(ConfigXmlPtr xml) ;
  ~OfflineItemEmbeddingService() {}
  bool skip(GraphContextPtr context) override;
  virtual int do_service(GraphContextPtr context) override;
  virtual int process(CoreContextPtr context) override;
 
  virtual  int process_embeddings(std::shared_ptr<CoreContext> context,
                                                              const std::string &model_url, int64_t model_version,
                                                              const std::vector<int64_t> &creative_ids,
                                                              const float *embedding_result, int32_t batch_size,
                                                              int32_t single_vector_size);
  virtual void process_prediction(std::shared_ptr<CoreContext> &context, brpc::Channel *channel,
                                        const ::proto::flow::PredictRequest *request,
                                       ::proto::flow::PredictResponse *response,
                                       std::shared_ptr<Info::ModelInfo> experiment_model_info,int32_t index);

  std::vector<ItemWrapper> *get_item_wrappers(CoreContextPtr &context, int32_t index) {
    std::vector<ItemWrapper> *item_vec = nullptr;
    if(context->get_prerank_context()->_offline_item_embedding_map.size() == 0) {
      return nullptr;
    }
    return item_vec;
  }
private:
  bool CheckIsEmbeddingShape(const ::proto::flow::TensorProto &shape);
  std::string dest_;
  common::ThreadPool single_thread_pool_{1};
};

} // namespace Core
