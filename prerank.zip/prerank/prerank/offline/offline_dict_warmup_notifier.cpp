#include "offline_dict_warmup_notifier.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/defs.h"
#include "common/comm/wrapper_time.h"
#include "common/hilog/log_helper.h"
#include <nlohmann/json.hpp>
#include <brpc/channel.h>
#include <brpc/controller.h>
#include <filesystem>
#include <fstream>
#include <sys/stat.h>

namespace Core {
namespace prerank {

namespace fs = std::filesystem;

static void write_model_base_dir_marker(const std::string& base_dir) {
    try {
        // 解析base_dir，获取date、time、model_name
        fs::path base_path(base_dir);
        std::string time_str = base_path.filename().string();
        std::string date_str = base_path.parent_path().filename().string();
        fs::path model_name_path = base_path.parent_path().parent_path().parent_path();
        std::string model_name = model_name_path.filename().string();

        HILOG_APP(ERROR) << "古娜拉黑暗之神：正在把base_dir写入model_name目录下, model=" << model_name
                         << ", date=" << date_str << ", time=" << time_str;

        fs::path model_dir = fs::path(ServerConfig::_emb_path) / model_name;
        std::error_code ec;
        fs::create_directories(model_dir, ec);

        // 删除旧的包含 "base_dir" 的标记文件，避免读取端误读
        for (const auto& entry : fs::directory_iterator(model_dir)) {
            const auto& p = entry.path();
            if (!fs::is_regular_file(p)) {
                continue;
            }
            std::string filename = p.filename().string();
            if (filename.find("base_dir") != std::string::npos) {
                std::error_code remove_ec;
                fs::remove(p, remove_ec);
            }
        }

        // 创建 {date}_{time}_base_dir_tmp.txt 写入后原子替换为 {date}_{time}_base_dir.txt
        std::string marker_prefix = date_str + "_" + time_str + "_base";
        fs::path final_path = model_dir / (marker_prefix + "_dir.txt");
        fs::path tmp_path = model_dir / (marker_prefix + "_tmp.txt");

        {
            std::ofstream ofs(tmp_path.string(), std::ios::out | std::ios::trunc);
            if (!ofs.is_open()) {
                HILOG_APP(ERROR) << "古娜拉黑暗之神：Failed to open temp base_dir file: " << tmp_path.string();
                return;
            }
            ofs << base_dir;
            ofs.flush();
        }
        HILOG_APP(ERROR) << "古娜拉黑暗之神：打开base_dir成功";

        std::error_code rename_ec;
        fs::rename(tmp_path, final_path, rename_ec);
        if (rename_ec) {
            std::ofstream ofs(final_path.string(), std::ios::out | std::ios::trunc);
            if (!ofs.is_open()) {
                HILOG_APP(ERROR) << "古娜拉黑暗之神：Failed to write base_dir file: " << final_path.string();
                return;
            }
            ofs << base_dir;
        }

        HILOG_APP(ERROR) << "古娜拉黑暗之神：写入成功Wrote base_dir marker for model " << model_name
                         << ", file=" << final_path.string() << ", value=" << base_dir;
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << "Exception writing base_dir marker: " << e.what();
    }
}

int NotifyDictWarmup(const std::string& base_dir) {
    if (ServerConfig::_dict_warmup_url.empty() || ServerConfig::_dict_warmup_uri.empty()) {
        HILOG_APP(WARNING) << "Dict warmup url/uri empty, skip notify";
        return 0;
    }

    HILOG_APP(ERROR) << "古娜拉黑暗之神：NotifyDictWarmup, cos桶路径=" << base_dir;

    // 通知前检查 _SUCCESS 与 itemEmb.txt 是否存在，并打印 itemEmb.txt 大小
    std::string data_dir = base_dir;
    if (!data_dir.empty() && data_dir.back() == Core::PATH_SEPARATOR) {
        data_dir.pop_back();
    }
    std::string success_file_path = data_dir + Core::PATH_SEPARATOR + Core::success_file;
    std::string item_emb_path = data_dir + Core::PATH_SEPARATOR + Core::ad_embedding_file;

    struct stat st_success{};
    if (stat(success_file_path.c_str(), &st_success) != 0) {
        HILOG_APP(ERROR) << "古娜拉黑暗之神：未找到_SUCCESS文件, 路径=" << success_file_path << ", 跳过预热通知";
        return 0;
    }
    struct stat st_item{};
    if (stat(item_emb_path.c_str(), &st_item) != 0) {
        HILOG_APP(ERROR) << "古娜拉黑暗之神：未找到itemEmb.txt, 路径=" << item_emb_path << ", 跳过预热通知";
        return 0;
    }
    HILOG_APP(ERROR) << "古娜拉黑暗之神：itemEmb.txt存在，大小=" << static_cast<long long>(st_item.st_size) << " 字节, 路径=" << item_emb_path;

    // HTTP POST
    nlohmann::json body;
    const std::string cos_name = "/ai-modeldict-prod-1311258067";
    body["cosPath"] = cos_name + base_dir + Core::PATH_SEPARATOR;
    body["serviceCode"] = "ad-phx-predictor";

    try {
        brpc::Channel channel;
        brpc::ChannelOptions options;
        options.protocol = "http";
        options.connection_type = "pooled";
        if (channel.Init(ServerConfig::_dict_warmup_url.c_str(), &options) != 0) {
            HILOG_APP(ERROR) << "Warmup notify: init channel failed";
            return -1;
        }

        std::string json_body = body.dump();
        brpc::Controller cntl;
        cntl.http_request().uri() = ServerConfig::_dict_warmup_uri;
        cntl.http_request().set_method(brpc::HTTP_METHOD_POST);
        cntl.http_request().set_content_type("application/json; charset=utf-8");
        cntl.set_timeout_ms(2000);
        cntl.request_attachment().append(json_body);
        channel.CallMethod(NULL, &cntl, NULL, NULL, NULL);
        if (cntl.Failed()) {
            HILOG_APP(ERROR) << "Warmup notify failed, brpc error: " << cntl.ErrorText();
            return -1;
        }
        long status = cntl.http_response().status_code();
        if (status < 200 || status >= 300) {
            HILOG_APP(ERROR) << "Warmup notify failed, response code: " << status
                             << ", error: " << cntl.response_attachment().to_string();
            return -1;
        }
        HILOG_APP(ERROR) << "古娜拉黑暗之神：通知词典预热成功，Warmup notify success, cosPath=" << body["cosPath"].get<std::string>();
        // 预热成功后写入 base_dir 标记文件
        write_model_base_dir_marker(base_dir);

        // 通知后检查 SUCCESS 文件是否存在
        std::string success_file_after_path = data_dir + Core::PATH_SEPARATOR + std::string("SUCCESS");
        struct stat st_success_after{};
        if (stat(success_file_after_path.c_str(), &st_success_after) == 0) {
            HILOG_APP(ERROR) << "古娜拉黑暗之神：预热成功，检测到SUCCESS文件存在，路径=" << success_file_after_path;
        } else {
            HILOG_APP(ERROR) << "古娜拉黑暗之神：预热失败，未检测到SUCCESS文件存在，路径=" << success_file_after_path;
        }
        return 0;
    } catch (const std::exception& e) {
        HILOG_APP(ERROR) << "Warmup notify exception: " << e.what();
        return -1;
    } catch (...) {
        HILOG_APP(ERROR) << "Warmup notify unknown exception";
        return -1;
    }
}

} // namespace prerank
} // namespace Core