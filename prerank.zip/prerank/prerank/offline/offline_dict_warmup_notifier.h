#pragma once
#include <string>

namespace Core {
namespace prerank {
int NotifyDictWarmup(const std::string& base_dir); // 上报至词典模块

} // namespace prerank
} // namespace Core