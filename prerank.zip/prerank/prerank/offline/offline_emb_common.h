#pragma once
#include <thread_pool.h>
namespace Core::prerank {
    extern common::ThreadPool g_offline_emb_executor;
}