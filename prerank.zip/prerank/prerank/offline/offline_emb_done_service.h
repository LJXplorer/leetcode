#pragma once
#include "core/core_services/base_service/service_info.h"
#include "core/core_context/core_context.h"

namespace Core {
    class OfflineItemEmbeddingDoneService : public ServiceBaseInfo {
        public:
            int do_service(GraphContextPtr context) override;

    };

}