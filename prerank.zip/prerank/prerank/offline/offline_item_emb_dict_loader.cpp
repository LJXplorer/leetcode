#include "offline_item_emb_dict_loader.h"
#include "prerank/prerank_embedding.pb.h"
#include "core/core_services/prerank/embedding_cache/feature_cache.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/monitor_mgr.h"
#include "core/utils/defs.h"
#include "common/comm/file_scanner.h"
#include <dirent.h>
#include <fcntl.h>
#include <log_helper.h>
#include <nlohmann/json.hpp>
#include <google/protobuf/io/coded_stream.h>
#include <google/protobuf/io/zero_copy_stream_impl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fstream>
#include <sstream>
#include <climits>

namespace Core {
namespace prerank {

namespace {
    // 解析 TASK_INFO 第二行，取 version 字段
    static int32_t ReadTaskInfoVersion(const std::string &dir_path, std::string &model_name_out, int32_t &version_out, int32_t &item_count_out) {
        std::string file_path = dir_path + Core::PATH_SEPARATOR + Core::task_info_file;
        int fd = open(file_path.c_str(), O_RDONLY);
        if (fd == -1) {
            HILOG_APP(WARNING) << "TASK_INFO not found: " << file_path;
            return -1;
        }
        struct stat sb{};
        if (fstat(fd, &sb) == -1) {
            close(fd);
            return -1;
        }
        int32_t length = static_cast<int32_t>(sb.st_size);
        const char *p_buf = static_cast<const char *>(mmap(NULL, length, PROT_READ, MAP_PRIVATE, fd, 0));
        if (p_buf == nullptr || p_buf == MAP_FAILED) {
            close(fd);
            return -1;
        }
        const char *start = p_buf;
        const char *end = p_buf + length;
        int line_count = 0;
        const char *line_start = nullptr;
        const char *line_end = nullptr;
        for (const char *it = start; it < end; ++it) {
            if (*it == '\n') {
                ++line_count;
                if (line_count == 1) {
                    line_start = it + 1;
                } else if (line_count == 2) {
                    line_end = it;
                    break;
                }
            }
        }
        std::string second_line;
        if (line_start && line_end && line_start < line_end) {
            second_line.assign(line_start, line_end);
        }
        munmap((void *) p_buf, length);
        close(fd);
        if (second_line.empty()) return -1;
        // 格式: {model_name},{model_version},{item_count}
        std::istringstream iss(second_line);
        std::string tok;
        std::vector<std::string> parts;
        while (std::getline(iss, tok, ',')) parts.emplace_back(tok);
        if (parts.size() < 3) return -1;
        model_name_out = parts[0];
        try {
            version_out = std::stoi(parts[1]);
            item_count_out = std::stoi(parts[2]);
        } catch (...) {
            return -1;
        }
        return 0;
    }

    // 读取 itemEmb.txt 每行的 protobuf 二进制，填充到 FeatureCache 的备份缓冲
    static int LoadItemEmbFile(const std::string &dir_path, const std::string &model_name, int32_t model_version) {
        std::string path = dir_path + Core::PATH_SEPARATOR + Core::ad_embedding_file;
        HILOG_APP(ERROR) << "巴啦啦能量 开始读取文件: " << path << ", model_name: " << model_name << ", model_version: " << model_version;
        
        std::ifstream in(path, std::ios::in | std::ios::binary);
        if (!in.is_open()) {
            HILOG_APP(ERROR) << "巴啦啦能量 Failed to open itemEmb.txt: " << path;
            return -1;
        }
        HILOG_APP(ERROR) << "巴啦啦能量 文件打开成功, good=" << in.good() << ", eof=" << in.eof() << ", fail=" << in.fail();
        // 预分配写入对象
        Core::prerank::FeatureCache::get_instance().pre_allocate(model_name, model_version, false);
        HILOG_APP(ERROR) << "巴啦啦能量 pre_allocate完成, model_name=" << model_name << ", model_version=" << model_version;

        std::vector<int64_t> creative_ids;
        std::vector<float> vec_buffer;
        const int kBatch = 4096;
        int parsed = 0;
        int failed = 0;

        // 采样前10条
        std::vector<int64_t> sample_cids;
        std::vector<std::vector<float>> sample_float_vals;

        HILOG_APP(ERROR) << "巴啦啦能量 开始按记录(4字节长度前缀 + Protobuf)读取与解析...";
        while (in.good() && !in.eof()) {
            uint32_t net_size = 0;
            in.read(reinterpret_cast<char *>(&net_size), sizeof(net_size));
            if (in.eof()) break;
            if (!in.good()) {
                HILOG_APP(ERROR) << "巴啦啦能量 读取记录长度失败";
                ++failed;
                break;
            }

            uint32_t size = ntohl(net_size);
            if (size == 0 || size > 500 * 1024 * 1024) {
                HILOG_APP(ERROR) << "巴啦啦能量 非法记录长度: " << size;
                ++failed;
                break;
            }

            std::string serialized_data(size, '\0');
            in.read(&serialized_data[0], size);
            if (!in.good()) {
                HILOG_APP(ERROR) << "巴啦啦能量 读取记录内容失败, 期望字节: " << size;
                ++failed;
                break;
            }

            phx::ItemEmbeddingInfo item;
            if (!item.ParseFromString(serialized_data)) {
                HILOG_APP(ERROR) << "巴啦啦能量 解析 Protobuf 失败";
                ++failed;
                continue;
            }

            // 采样
            if (static_cast<int>(sample_cids.size()) < 10) {
                sample_cids.push_back(item.cid());
                std::vector<float> vals;
                vals.reserve(item.float_val_size());
                for (int i = 0; i < item.float_val_size(); ++i) vals.push_back(item.float_val(i));
                sample_float_vals.emplace_back(std::move(vals));
            }

            // 缓存批量数据
            creative_ids.push_back(item.cid());
            for (int i = 0; i < item.float_val_size(); ++i) {
                vec_buffer.push_back(item.float_val(i));
            }

            if (static_cast<int>(creative_ids.size()) >= kBatch) {
                int32_t dim = item.float_val_size();
                Core::prerank::FeatureCache::get_instance().batch_insert_feature(
                        model_name, model_version, creative_ids, vec_buffer.data(), creative_ids.size(), dim, true);
                creative_ids.clear();
                vec_buffer.clear();
            }

            ++parsed;
            if (parsed % 1000 == 0) {
                HILOG_APP(ERROR) << "巴啦啦能量 进度: 已解析 " << parsed << " 条";
            }
        }
        HILOG_APP(ERROR) << "巴啦啦能量 读取循环结束, good=" << in.good() << ", eof=" << in.eof() << ", fail=" << in.fail();

        // 处理剩余数据
        if (!creative_ids.empty()) {
            int32_t dim = vec_buffer.empty() ? 0 : static_cast<int32_t>(vec_buffer.size() / creative_ids.size());
            if (dim > 0) {
                Core::prerank::FeatureCache::get_instance().batch_insert_feature(
                        model_name, model_version, creative_ids, vec_buffer.data(), creative_ids.size(), dim, true);
            }
            creative_ids.clear();
            vec_buffer.clear();
        }

        // 打印统计与样例
        HILOG_APP(ERROR) << "巴啦啦能量 读取的行数: " << parsed;
        if (!sample_cids.empty()) {
            HILOG_APP(ERROR) << "巴啦啦能量 creative_ids 样例(最多10行):";
            for (size_t i = 0; i < sample_cids.size(); ++i) {
                HILOG_APP(ERROR) << "  [" << i << "] " << sample_cids[i];
            }
        }
        if (!sample_float_vals.empty()) {
            HILOG_APP(ERROR) << "巴啦啦能量 float_val 样例(最多10行，每行前10个值):";
            for (size_t i = 0; i < sample_float_vals.size(); ++i) {
                const auto &vals = sample_float_vals[i];
                std::ostringstream oss;
                oss << "  [" << i << "] dim=" << vals.size() << " vals=[";
                int show = static_cast<int>(std::min<size_t>(10, vals.size()));
                for (int j = 0; j < show; ++j) {
                    if (j > 0) oss << ", ";
                    oss << vals[j];
                }
                if (static_cast<int>(vals.size()) > show) oss << ", ...";
                oss << "]";
                HILOG_APP(ERROR) << oss.str();
            }
        }

        HILOG_APP(ERROR) << "巴啦啦能量 加载完成 - 成功: " << parsed << " 行, 失败: " << failed << " 行, dir: " << dir_path;
        // 上报读取条数监控
        Core::MonitorMgr::common_report_model(model_name, "default", "default", "default", 0,
                                              "offline_item_emb_read_rows", static_cast<double>(parsed));
        HILOG_APP(ERROR) << "巴啦啦能量 监控上报 offline_item_emb_read_rows=" << parsed
                         << ", model=" << model_name << ", version=" << model_version;
        return 0;
    }
}

int LoadLatestEmbeddingFromGoose(const std::string &model_name_cfg, int32_t model_version_cfg, const std::string &base_dir) {
    HILOG_APP(ERROR) << "古娜拉黑暗之神：开始根据base_dir加载embedding, model_name=" << model_name_cfg << ", model_version=" <<         
                    model_version_cfg << ", base_dir=" << base_dir;

    // 直接使用传入的 base_dir，不再扫描日期/时间目录
    std::string data_dir = base_dir;
    if (!data_dir.empty() && data_dir.back() == Core::PATH_SEPARATOR) {
        data_dir.pop_back();
    }

    // 在 base_dir 下查找 _SUCCESS 文件
    std::string success_file_path = data_dir + Core::PATH_SEPARATOR + Core::success_file;
    struct stat st;
    if (stat(success_file_path.c_str(), &st) != 0) {
        HILOG_APP(ERROR) << "古娜拉黑暗之神：未找到_SUCCESS文件, 路径=" << success_file_path;
        return -2;
    }
    HILOG_APP(ERROR) << "古娜拉黑暗之神：找到_SUCCESS文件！路径=" << success_file_path;

    // 读取 TASK_INFO 校验 model_name 与 version
    std::string task_model_name;
    int32_t task_version = 0;
    int32_t task_item_cnt = 0;
    HILOG_APP(ERROR) << "古娜拉黑暗之神：开始读取TASK_INFO文件, 路径=" << data_dir;
    if (ReadTaskInfoVersion(data_dir, task_model_name, task_version, task_item_cnt) != 0) {
        HILOG_APP(WARNING) << "古娜拉黑暗之神：TASK_INFO解析失败, 路径=" << data_dir;
    } else {
        HILOG_APP(ERROR) << "古娜拉黑暗之神：TASK_INFO解析成功, task_model_name=" << task_model_name 
                        << ", task_version=" << task_version << ", task_item_cnt=" << task_item_cnt;
    }

    const std::string &model_name = !task_model_name.empty() ? task_model_name : model_name_cfg;
    int32_t model_version = task_version > 0 ? task_version : model_version_cfg;

    HILOG_APP(ERROR) << "古娜拉黑暗之神：最终使用的模型信息, model_name=" << model_name << ", model_version=" << model_version;

    // 加载 itemEmb.txt
    HILOG_APP(ERROR) << "古娜拉黑暗之神：开始加载itemEmb.txt文件, 路径=" << data_dir << Core::PATH_SEPARATOR << Core::ad_embedding_file;
    if (LoadItemEmbFile(data_dir, model_name, model_version) != 0) {
        HILOG_APP(ERROR) << "古娜拉黑暗之神：itemEmb.txt加载失败";
        return -1;
    }
    HILOG_APP(ERROR) << "古娜拉黑暗之神：itemEmb.txt加载成功";

    // 切换buffer
    HILOG_APP(ERROR) << "古娜拉黑暗之神：开始提交FeatureCache buffer切换";
    Core::prerank::FeatureCache::get_instance().commit_buffer(model_name, model_version, true, false);
    HILOG_APP(ERROR) << "古娜拉黑暗之神：FeatureCache buffer切换完成！model=" << model_name << ", version=" << model_version
                    << ", path=" << data_dir;
    return 0;
}

} // namespace prerank
} // namespace Core
