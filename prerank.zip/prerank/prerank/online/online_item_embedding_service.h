#pragma once
#include "core/core_context/prerank_context.h"
#include "core/core_services/base_service/service_info.h"
namespace Core {
class OnlineItemEmbeddingService : public ServiceBaseInfo {
public:
  OnlineItemEmbeddingService() {}

  ~OnlineItemEmbeddingService() {}
  virtual void initialize(ConfigXmlPtr xml);
  virtual void initialize_xml(ConfigXmlPtr xml);
  virtual void initialize(GraphContextPtr context);
  virtual int do_service(GraphContextPtr context);
  bool skip(GraphContextPtr context) override;
  
};

} // namespace Core