#pragma once

#include "core/core_services/base_service/service_info.h"
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "core/core_context/prerank_context.h"
#include "core/core_services/predict/predict_service.h"
#include <memory>
namespace Core {
class PrerankUserEmbeddingService : public ServiceBaseInfo {
private:
  ExperimentModelType model_type_;

public:
  PrerankUserEmbeddingService() = default;
  ~PrerankUserEmbeddingService() {}
  void initialize(ConfigXmlPtr xml) override;
  virtual void initialize(GraphContextPtr context);
  virtual int do_service(GraphContextPtr context) override;
  bool skip(GraphContextPtr context) override;
  const Node_Type type() override{
      return HLframe::NODE_TYPE_IO ;
  }

  void set_model_type(ExperimentModelType model_type) {
      model_type_ = model_type;
  }

  const ExperimentModelType &get_model_type() {
      return model_type_;
  }

public:
  // int process(CoreContextPtr context) override;
  int extractor(CoreContextPtr context);
  int inference(CoreContextPtr context, std::shared_ptr<Info::ModelInfo> model_info, phx::ExtractorResponse* extractor_response);
  void get_fe_model_info(CoreContextPtr& context, std::string& model_name, std::shared_ptr<Info::ModelInfo>& model_info);
  int64_t get_emb_model_version(CoreContextPtr& context);
  phx::FeRequest *build_user_embedding_fe_request(CoreContextPtr core_context);
  void get_user_slot_data_types(const phx::ExtractorResponse *extractor_response, std::vector<SlotDataType> &slot_data_types);
  void process_predict_response(CoreContextPtr context, const ::proto::flow::PredictResponse& predict_response);

  
};
} // namespace Core