#include "prerank_user_embedding_service.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/core_context.h"
#include "core/core_services/fe/model_info/model_info_manager.h"
#include "core/core_services/predict/utils/ragged_tensor_util.h"
#include "core/core_services/prerank/online/prerank_user_callback.h"
#include "core/utils/error.h"
#include "phx-fe/src/framework.h"
#include <debug_utils.h>
#include <json2pb/pb_to_json.h>
#include <log_helper.h>

namespace Core {
    SERVICE_REGISTER(PrerankUserEmbeddingService);

    void PrerankUserEmbeddingService::initialize(ConfigXmlPtr xml) {
        std::string model_type;
        xml->attr("predict", model_type);
        if (!model_type.empty()) {
            this->model_type_ = stringToExperimentModelType(model_type);
        }
    }

    void PrerankUserEmbeddingService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
    }

    bool PrerankUserEmbeddingService::skip(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        HILOG_APP(INFO) << "ctx == nullptr: " << (ctx == nullptr) << std::endl;
        HILOG_APP(INFO) << "ctx->_prerank_context_ptr == nullptr: " << (ctx->_prerank_context_ptr == nullptr)
                        << std::endl;
        HILOG_APP(INFO) << "ctx->_prerank_context_ptr->GetUsePrerank(): "
                        << (ctx->_prerank_context_ptr->GetUsePrerank()) << std::endl;
        if (ctx == nullptr || ctx->_prerank_context_ptr == nullptr || !ctx->_prerank_context_ptr->GetUsePrerank()) {
            return true;
        }

        if (get_predict_type() == ExperimentModelType::USER_EMBEDDING) {
            if (ctx->get_prerank_context()->user_emb_model_name_.empty()) {
                HILOG_APP(INFO) << "skip PrerankUserEmbeddingService with PREDICT_TYPE_USER_EMBEDDING, "
                                   "user_emb_model_name_.empty(): "
                                << ctx->get_prerank_context()->user_emb_model_name_.empty();
                return true;
            }
        } else if (get_predict_type() == ExperimentModelType::CVR_USER_EMBEDDING) {
            if (ctx->get_prerank_context()->cvr_user_emb_model_name_.empty() ||
                ctx->get_prerank_context()->enable_skip_cvr_prerank) {
                HILOG_APP(INFO) << "skip PrerankUserEmbeddingService with PREDICT_TYPE_CVR_USER_EMBEDDING, "
                                   "cvr_user_emb_model_name_.empty(): "
                                << ctx->get_prerank_context()->cvr_user_emb_model_name_.empty()
                                << ", enable_skip_cvr_prerank: " << ctx->get_prerank_context()->enable_skip_cvr_prerank;
                ctx->_is_skip_prerank_cvr = true;
                return true;
            }
        }
        return false;
    }

    int PrerankUserEmbeddingService::do_service(GraphContextPtr context) {
        auto core_context = std::dynamic_pointer_cast<CoreContext>(context);
        BizLatency *lat = get_node_stat(core_context)->get_lat();
        BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);
        if (ERROR_SUCCESS != extractor(core_context)) {
            run_output_nodes_if_ready(context);
            return ERROR_EMBEDDING_USER_PRERNAK_EMPTY;
        }
        return ERROR_SUCCESS;
    }

    void PrerankUserEmbeddingService::get_fe_model_info(CoreContextPtr &context, std::string &model_name,
                                                        std::shared_ptr<Info::ModelInfo> &model_info) {
        switch (model_type_) {
            case ExperimentModelType::USER_EMBEDDING:
                model_name = context->get_prerank_context()->user_emb_model_name_;
                break;
            case ExperimentModelType::CVR_USER_EMBEDDING:
                model_name = context->get_prerank_context()->cvr_user_emb_model_name_;
                break;
            default:
                HILOG_APP(ERROR) << " get_fe_model_info error, model_type:" << experimentModelTypeToString(model_type_)
                                 << "model_name" << model_name;
                break;
        }
        model_info = Info::ModelInfoManager::instance().get_model_info(model_name);
        HILOG_APP(INFO) << "model_name: " << model_name;
    }

    int64_t PrerankUserEmbeddingService::get_emb_model_version(CoreContextPtr &context) {
        int64_t model_version = -1;
        std::string model_name;
        switch (model_type_) {
            case ExperimentModelType::USER_EMBEDDING:
                model_version = context->get_prerank_context()->max_common_version_;
                model_name = context->get_prerank_context()->user_emb_model_name_;
                break;
            case ExperimentModelType::CVR_USER_EMBEDDING:
                model_version = context->get_prerank_context()->cvr_emb_model_version_;
                model_name = context->get_prerank_context()->cvr_user_emb_model_name_;
                break;
            default:
                HILOG_APP(ERROR) << " get_emb_model_version error, model_type:"
                                 << experimentModelTypeToString(model_type_) << "model_name" << model_name;
                break;
        }
        return model_version;
    }

    phx::FeRequest *PrerankUserEmbeddingService::build_user_embedding_fe_request(CoreContextPtr core_context) {
        phx::FeRequest *full_fe_request = core_context->get_fs_context()->feature_dump;
        auto user_embedding_fe_request =
                google::protobuf::Arena::CreateMessage<phx::FeRequest>(core_context->get_context_arena());
        const google::protobuf::Reflection *reflection = phx::FeRequest::GetReflection();
        const google::protobuf::Descriptor *descriptor = phx::FeRequest::GetDescriptor();
        for (int32_t i = 0; i < descriptor->field_count(); i++) {
            const google::protobuf::FieldDescriptor *field = descriptor->field(i);
            if (field->is_repeated()) {
                if (reflection->FieldSize(*full_fe_request, field) == 0) {
                    continue;
                }
            } else {
                if (!reflection->HasField(*full_fe_request, field)) {
                    continue;
                }
            }
            if (!field->is_repeated()) {
                switch (field->cpp_type()) {
                    case (protobuf::FieldDescriptor::CPPTYPE_MESSAGE): {
                        reflection->SetAllocatedMessage(user_embedding_fe_request,
                                                        reflection->MutableMessage(full_fe_request, field), field);
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_INT32): {
                        reflection->SetInt32(user_embedding_fe_request, field,
                                             reflection->GetInt32(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_INT64): {
                        reflection->SetInt64(user_embedding_fe_request, field,
                                             reflection->GetInt64(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_FLOAT): {
                        reflection->SetFloat(user_embedding_fe_request, field,
                                             reflection->GetFloat(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_DOUBLE): {
                        reflection->SetDouble(user_embedding_fe_request, field,
                                              reflection->GetDouble(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_STRING): {
                        reflection->SetString(user_embedding_fe_request, field,
                                              reflection->GetString(*full_fe_request, field));
                        break;
                    }
                    default:
                        break;
                }
            }
        }
        // mock一个粗排item
        user_embedding_fe_request->add_prerank_item_fea();
        user_embedding_fe_request->add_item_fea();
        return user_embedding_fe_request;
    }

    void PrerankUserEmbeddingService::get_user_slot_data_types(const phx::ExtractorResponse *extractor_response,
                                                               std::vector<SlotDataType> &user_slot_data_types) {
        // 处理 user 特征
        for (int slot_index = 0; slot_index < user_slot_data_types.size(); ++slot_index) {
            auto &user_features = extractor_response->user_features();
            auto &feature = user_features.at(slot_index);//(slot_i,1)处的Feature
            if (feature.signs().size() > 0) {
                // 这个特征是 int
                user_slot_data_types[slot_index] = SlotDataType::INT_64;
            } else if (feature.weights().size() > 0) {
                // 这个特征是 float
                user_slot_data_types[slot_index] = SlotDataType::FLOAT;
            } else if (feature.bytes_list().size() > 0) {
                // 这个特征是 string
                user_slot_data_types[slot_index] = SlotDataType::STRING;
            }
            // 获取下一个 slot_index 的 DATA_TYPE
        }
    }

    int PrerankUserEmbeddingService::extractor(CoreContextPtr context) {
        int ret = ERROR_SUCCESS;
        std::string user_model_name;
        std::shared_ptr<Info::ModelInfo> model_info;
        get_fe_model_info(context, user_model_name, model_info);
        if (model_info == nullptr) {
            HILOG_APP(ERROR) << " not found config :" << user_model_name;
            return ERROR_EMBEDDING_USER_PRERNAK_EMPTY;
        }
        HILOG_APP(INFO) << user_model_name << " user model version:" << model_info->_model_name;
        auto user_embedding_fe_request = build_user_embedding_fe_request(context);
        if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
            std::string json_predict;
            json2pb::ProtoMessageToJson(*user_embedding_fe_request, &json_predict);
            debug::file::WriteToFile(json_predict, experimentModelTypeToString(model_type_) + "_" +
                                                           model_info->_model_name +
                                                           "_"
                                                           "prerank_user_ferequest.json");
        }
        phx::ExtractorResponse *user_embedding_extractor_response =
                google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(context->get_context_arena());
        auto *empty_user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(context->get_context_arena());

        toExtractorResponse(context->get_context_arena(), *user_embedding_fe_request, *empty_user_action,
                            model_info->get_config_info(), *user_embedding_extractor_response, true);

        auto prerank_context = context->get_prerank_context();
        prerank_context->user_extractor_response = user_embedding_extractor_response;

        BizLatency *lat = get_node_stat(context)->get_lat();
        int64_t now = get_cur_time_us();
        lat->_req_end_tm = now;
        lat->_rsp_begin_tm = now;
        ret = inference(context, model_info, user_embedding_extractor_response);
        if (ERROR_SUCCESS != ret) {
            HILOG_APP(ERROR) << " PrerankUserEmbeddingService inference ERROR";
        }
        return ret;
    }

    int PrerankUserEmbeddingService::inference(CoreContextPtr context, std::shared_ptr<Info::ModelInfo> model_info,
                                               phx::ExtractorResponse *extractor_response) {
        if (extractor_response == nullptr) {
            HILOG_APP(ERROR) << "model name: " << model_info->_model_name << ", extractor_responses is nullptr";
            return ERROR_EMBEDDING_USER_PRERNAK_EMPTY;
        }
        auto &user_features = extractor_response->user_features();
        const size_t user_slot_num = user_features.size();
        auto user_slot_data_types = std::vector<SlotDataType>(user_slot_num, SlotDataType::UNKNOWN);
        get_user_slot_data_types(extractor_response, user_slot_data_types);
        HILOG_APP(INFO) << "get_user_slot_data_types end";

        std::vector<SlotInfo> user_slot_list(user_slot_num);

        //处理 user 特征
        for (int i = 0; i < user_slot_num; ++i) {
            auto& feature = user_features.at(i);//(slot_i,1)处的Feature
            SlotDataType &data_type = user_slot_data_types[i];
            user_slot_list[i].slot_id = feature.slot_id();
            switch (data_type) {
                case SlotDataType::INT_64: {
                    if (!user_slot_list[i].int_values_repeated) {
                        user_slot_list[i].int_values_repeated =
                                std::make_shared<std::vector<const google::protobuf::RepeatedField<int64_t> *>>();
                    }
                    user_slot_list[i].slot_data_type = SlotDataType::INT_64;
                    user_slot_list[i].slot_id = feature.slot_id();
                    auto &slot_features = *user_slot_list[i].int_values_repeated;
                    slot_features.push_back(&feature.signs());
                    break;
                }
                case SlotDataType::FLOAT: {
                    if (!user_slot_list[i].float_values_repeated) {
                        user_slot_list[i].float_values_repeated =
                                std::make_shared<std::vector<const google::protobuf::RepeatedField<float> *>>();
                    }
                    user_slot_list[i].slot_data_type = SlotDataType::FLOAT;
                    user_slot_list[i].slot_id = feature.slot_id();
                    auto &slot_features = *user_slot_list[i].float_values_repeated;
                    slot_features.push_back(&feature.weights());
                    break;
                }
                case SlotDataType::STRING: {
                    if (!user_slot_list[i].string_values_repeated) {
                        user_slot_list[i].string_values_repeated = std::make_shared<
                                std::vector<const google::protobuf::RepeatedPtrField<std::string> *>>();
                    }
                    user_slot_list[i].slot_data_type = SlotDataType::STRING;
                    user_slot_list[i].slot_id = feature.slot_id();
                    auto &slot_features = *user_slot_list[i].string_values_repeated;
                    slot_features.push_back(&feature.bytes_list());
                    break;
                }
                default: {
                    // HILOG_APP(INFO) << "user feature 具有未知的 data type";
                    user_slot_list[i].slot_data_type = SlotDataType::UNKNOWN;
                    break;
                }
            }
        }

        // 写 user_slot_list 到文件 predict_type + model_name + user_slot_list.txt
        // debug::file::WriteToFile(debug::printer::ToString(user_slot_list),
        //                          experimentModelTypeToString(get_predict_type()) + model_info->_model_name +
        //                                  "user_slot_list.txt");

        // user embedding 不用item分包
        // std::vector<std::vector<SlotInfo>> item_splited_batches(1, std::vector<SlotInfo>(item_slot_num));

        auto predict_request =
                google::protobuf::Arena::CreateMessage<::proto::flow::PredictRequest>(context->get_context_arena());
        ::proto::flow::ModelPredictRequest *model_request = predict_request->add_model_requests();
        model_request->set_model_name(model_info->_model_name);
        model_request->set_model_version(get_emb_model_version(context));// 如果版本不对？

        //处理 user特征
        for (const auto &user_slot_info: user_slot_list) {
            auto *user_input = model_request->add_inputs();
            user_input->set_name(user_slot_info.slot_id);
            user_input->set_type(0);// 0表示user 1表示item

            //填充 user 特征到 inputs
            switch (user_slot_info.get_data_type()) {
                case SlotDataType::INT_64: {
                    ::proto::flow::RaggedTensorProto *rt(RaggedTensorUtil::FromValues(*user_slot_info.int_values_repeated));
                    user_input->set_allocated_values(rt);
                    break;
                }
                case SlotDataType::FLOAT: {
                    ::proto::flow::RaggedTensorProto *rt(RaggedTensorUtil::FromValues(*user_slot_info.float_values_repeated));
                    user_input->set_allocated_values(rt);
                    break;
                }
                case SlotDataType::STRING: {
                    ::proto::flow::RaggedTensorProto *rt(RaggedTensorUtil::FromValues(*user_slot_info.string_values_repeated));
                    user_input->set_allocated_values(rt);
                    break;
                }
                default: {
                    ::proto::flow::RaggedTensorProto *rt(
                            RaggedTensorUtil::FromValues(std::vector<std::vector<int64_t>>()));
                    user_input->set_allocated_values(rt);
                    break;
                }
            }
        }

        // 调tfserving
        brpc::Channel *channel = model_info->get_channel();
        ::proto::flow::PredicterService_Stub stub(channel);
        auto predict_response =
                google::protobuf::Arena::CreateMessage<::proto::flow::PredictResponse>(context->get_context_arena());

        if (context->get_rank_request()->debuglevel() == DebugLevel::kDumpPredictService) {
            std::string json_predict;
            json2pb::ProtoMessageToJson(*predict_request, &json_predict);
            debug::file::WriteToFile(json_predict, experimentModelTypeToString(model_type_) + "_" +
                                                           model_info->_model_name +
                                                           "_"
                                                           "predict_request.json");
        }
        auto *prerank_user_callback =
                new PrerankUserCallBack(predict_request, predict_response, this, context, model_info->_model_name,
                                        model_info->_request_compress_type, model_type_);
        stub.Predict(&prerank_user_callback->cntl, prerank_user_callback->request, prerank_user_callback->response,
                     prerank_user_callback);
        return ERROR_SUCCESS;
    }

}// namespace Core
