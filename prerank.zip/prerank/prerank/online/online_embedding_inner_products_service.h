#pragma once

#include <memory>
#include <unordered_map>
#include <vector>
#include <cblas.h>
#include <cmath>
#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"


namespace Core {
class OnlineEmbeddingInnerProductsService : public ServiceBaseInfo {
public:
  OnlineEmbeddingInnerProductsService() {}
  ~OnlineEmbeddingInnerProductsService() {}
  virtual int do_service(GraphContextPtr context) override;
  void initialize(GraphContextPtr context) override {
      // std::cout << "OnlineEmbeddingInnerProductsService init called " <<std::endl;
      auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
      ctx->get_monitor_context()->alloc_node(get_name());
      return;
  }
  virtual bool skip(GraphContextPtr context) override;
  void set_prerank_ctr_score(shared_ptr<CoreContext> core_context, const AdsPairPtr& item_ads_pair, const std::vector<float> &user_embedding_vec, float default_pdtr, int32_t& pdtr_num, float& pdtr_sum);
  void set_prerank_cvr_score(shared_ptr<CoreContext> core_context, const AdsPairPtr& item_ads_pair, const std::vector<float> &cvr_user_embedding_vec, float default_pcvr, int32_t& pcvr_num, float& pcvr_sum);
private:

};
} // namespace Core