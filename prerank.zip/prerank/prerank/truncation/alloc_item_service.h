#pragma once

#include "core/core_context/core_context.h"
#include "core/core_services/prerank/truncation/prerank_truncation_service.h"
#include "hlframe/graph_context.h"
#include <config_xml.h>
namespace Core {

class AllocItemService : public TruncationService {
public:
    AllocItemService() = default;
    virtual ~AllocItemService() = default;
public:
    void item_model_list(
        CoreContextPtr context,
        const ::phx::PredictorItemInfo& item,
        ::phx::PredictorItemData& item_data
    ) override;
};

}