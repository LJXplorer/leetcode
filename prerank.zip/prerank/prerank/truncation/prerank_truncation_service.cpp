#include "core/core_services/prerank/truncation/prerank_truncation_service.h"
#include "common/comm/wrapper_time.h"
#include "common/hilog/log_helper.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/core_context.h"
#include "core/core_services/prerank/truncation/include/TruncationLogic.h"
#include "core/core_services/start/start_service.h"
#include "core/utils/error.h"
#include "core/utils/monitor_mgr.h"
#include "core/utils/util.h"
#include <boost/algorithm/string.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/property_tree/ptree.hpp>
#include <bvar/latency_recorder.h>
#include <debug_utils.h>
#include <exception>
#include <log.h>
#include <memory>
#include <string>
namespace Core {

    SERVICE_REGISTER(TruncationService);

    void TruncationService::initialize(ConfigXmlPtr xml) {
        initialize_xml(xml);
    }

    void TruncationService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
        return;
    }

    void TruncationService::initialize_xml(ConfigXmlPtr xml) {
        xml->attr<int32_t>("split_size", _split_size);//convert_proto中会使用
        std::string return_discarded_ads;
        xml->attr<std::string>("return_discarded_ads",
                               return_discarded_ads);//配置服务响应体中是否会包含被丢弃广告 默认为 true
        // _return_discarded_ads = (return_discarded_ads == "true");
        _return_discarded_ads = (return_discarded_ads != "false");
        xml->attr<int>("truncation_dump_end_policy", _truncation_dump_end_policy);
        xml->attr<int>("retain_return_end_policy", _retain_return_end_policy);
        //粗排截断
        std::string is_truncation;
        xml->attr<std::string>("is_truncation", is_truncation, "false");
        if (!is_truncation.empty() && is_truncation == "true") {
            _is_truncation = true;
        } else {
            _is_truncation = false;
        }
    }

    bool TruncationService::skip(GraphContextPtr context) {
        return false;
    }

    int TruncationService::do_service(GraphContextPtr context) {
        HILOG_APP(INFO) << "TruncationService::do_service(GraphContextPtr context) start";
        // int64_t truncation_service_start = gettimeofday_us();
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int32_t ret = 0;

        try {
            ret = process(ctx);

        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << LOG_HEAD(ctx) << get_name() << "do service fail: " << ret << "," << e.what();
        }

        // int64_t truncation_service_end = gettimeofday_us();

        // g_truncation_total << truncation_service_end - truncation_service_start;
        HILOG_APP(INFO) << "TruncationService::do_service(GraphContextPtr context) end";
        return ret;
    }

    int TruncationService::process(CoreContextPtr context) {
        HILOG_APP(INFO) << "===========================TruncationService::process "
                           "start============================================================="
                        << std::endl;

        BizLatency *lat = get_node_stat(context)->get_lat();

        std::vector<AdsPairPtr> _ads;
        auto config_ptr = context->get_prerank_context()->GetConfigPtr();
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);
            for (const auto &pair: context->_ads_map) {
                _ads.push_back(pair.second);
            }
        }

        int ret = 0;
        std::unordered_map<std::string, std::shared_ptr<std::vector<::Core::AdsPairPtr>>> &result =
                context->_prerank_context_ptr->truncated_results;
        {
            BizLatencyGaurd lat_guard_dst(lat, LAT_STAGE_DESTROY);
            if (config_ptr != nullptr) {
                config_ptr->dict_name = context->get_prerank_context()->item_dict_name_;
                config_ptr->cvr_dict_name = context->get_prerank_context()->cvr_item_dict_name_;

                HILOG_APP(INFO) << "config_ptr->dict_name: " << config_ptr->dict_name;
                HILOG_APP(INFO) << "config_ptr->cvr_dict_name: " << config_ptr->cvr_dict_name;
                prerank::TruncationLogic truncation_logic(_ads, config_ptr, context);
                //执行截断模块逻辑
                truncation_logic.execute(context,result);
            } else {
                result["truncated_ads"] = std::make_shared<std::vector<::Core::AdsPairPtr>>(std::move(_ads));
                result["discarded_ads"] = std::make_shared<std::vector<::Core::AdsPairPtr>>();
            }

            ret = convert_proto(context);
            if (ret != ERROR_SUCCESS) {
                HILOG_APP(ERROR) << LOG_HEAD(context) << get_name() << "TruncationService::convert_proto fail: " << ret;
                return ret;
            }

            HILOG_APP(INFO) << LOG_HEAD(context)
                            << "truncation finished. truncated_ads.size(): " << result["truncated_ads"]->size()
                            << std::endl;

            context->get_prerank_context()->prerank_end_ts_ = gettimeofday_ms();

            //毫秒级别
            // g_prerank_total << (context->get_prerank_context()->prerank_end_ts_ - context->_begin_ts)*1000;

            HILOG_APP(INFO) << "===========================TruncationService::process "
                               "end============================================================="
                            << std::endl;
        }

        return ERROR_SUCCESS;
    }

    int TruncationService::convert_proto(CoreContextPtr context) {
        HILOG_APP(INFO) << "===========================TruncationService::convert_proto "
                           "start============================================================="
                        << std::endl;

        auto &truncated_results = context->get_prerank_context()->truncated_results;
        int32_t item_size = truncated_results["truncated_ads"]->size();
        if (context->get_rank_request()->debuglevel() == DebugLevel::kPrerank) {
            std::ofstream outfile("truncated_results.txt");
            if (outfile.is_open()) {
                outfile << "truncated_results: " << debug::printer::ToString(truncated_results) << std::endl;
                outfile << "truncated_results[\"truncated_ads\"]->size(): "
                        << truncated_results["truncated_ads"]->size() << std::endl;
                outfile << "truncated_results[\"discarded_ads\"]->size(): "
                        << truncated_results["discarded_ads"]->size() << std::endl;
                outfile.close();
            } else {
                HILOG_APP(INFO) << "Unable to open file";
            }
        }

        //被截断的广告无需返回 直接从精排输入中移除
        context->_bak_response->mutable_predictslotdata()->mutable_predictoritemdatas()->Clear();

        if (item_size == 0)
            return ERROR_BIZ_PROTO_ADS_EMPTY;

        for (int32_t i = 0; i < item_size; i++) {
            ::phx::PredictorItemInfo *item = (*truncated_results["truncated_ads"])[i]->_reqeust_adv;
            auto &item_data = context->_creative_id_item_score_map[item->creativeid()];
            item_data.set_creativeid(item->creativeid());
            item_model_list(context, *item, item_data);
        }
        auto *fe_split = context->get_fe_context()->MutableSplit();
        if (!context->_model_predict_cpc_ctr_map.empty()) {
            fe_split->insert({ExperimentModelType::CPC_CTR, {}});
            for (const auto &[model_info, _]: context->_model_predict_cpc_ctr_map) {
                fe_split->at(ExperimentModelType::CPC_CTR).insert({model_info, {}});
            }
        }
        if (!context->_model_predict_cpc_cvr_map.empty()) {
            fe_split->insert({ExperimentModelType::CPC_CVR, {}});
            for (const auto &[model_info, _]: context->_model_predict_cpc_cvr_map) {
                fe_split->at(ExperimentModelType::CPC_CVR).insert({model_info, {}});
            }
        }
        if (!context->_model_predict_cpd_ctr_map.empty()) {
            fe_split->insert({ExperimentModelType::CPD_CTR, {}});
            for (const auto &[model_info, _]: context->_model_predict_cpd_ctr_map) {
                fe_split->at(ExperimentModelType::CPD_CTR).insert({model_info, {}});
            }
        }
        if (!context->_cpd_cvr_model_map.empty()) {
            fe_split->insert({ExperimentModelType::CPD_CVR, {}});
            for (const auto &[model_info, _]: context->_model_predict_cpd_cvr_map) {
                fe_split->at(ExperimentModelType::CPD_CVR).insert({model_info, {}});
            }
        }
        if(!context->_model_predict_ltv_map.empty()) {
            fe_split->insert({ExperimentModelType::LTV, {}});
            for(const auto& [model_info, _] : context->_model_predict_ltv_map) {
                fe_split->at(ExperimentModelType::LTV).insert({model_info, {}});
            }
        }
        HILOG_APP(INFO) << "context->get_fe_context()->_fe_split: "
                        << debug::printer::ToString(context->get_fe_context()->fe_split_);
        HILOG_APP(INFO) << "===========================TruncationService::convert_proto "
                           "end============================================================="
                        << std::endl;
        return ERROR_SUCCESS;
    }
    void TruncationService::item_model_list(Core::CoreContextPtr context, const ::phx::PredictorItemInfo &item,
                                            ::phx::PredictorItemData &item_data) {
        BillingMode billing_mode = context->to_billing_mode(item.billingmode());
        std::vector<int> conv_types;
        if (item.convtype() > 0) {
            conv_types.push_back(item.convtype());
        }
        if (item.deepconvtype() > 0) {
            conv_types.push_back(item.deepconvtype());
        }
        if (item.enhanceconvtype() > 0) {
            conv_types.push_back(item.enhanceconvtype());
        }

        bool is_cpc = billing_mode <= 4;
        auto &model_map = is_cpc ? context->_cpc_cvr_model_map : context->_cpd_cvr_model_map;
        auto &predict_map = is_cpc ? context->_model_predict_cpc_cvr_map : context->_model_predict_cpd_cvr_map;

        auto &ctr_model_map = is_cpc ? context->_cpc_ctr_model_map : context->_cpd_ctr_model_map;
        auto &predict_ctr_map = is_cpc ? context->_model_predict_cpc_ctr_map : context->_model_predict_cpd_ctr_map;

        std::vector<ExperimentModelInfo *> all_models;
        std::unordered_set<std::string> model_names_set;

        for (int conv_type: conv_types) {
            if (auto it = model_map.find(conv_type); it != model_map.end()) {
                ExperimentModelInfo *model_info = it->second;
                const std::string &name = model_info->_model_name;
                if (model_names_set.insert(name).second) {
                    all_models.push_back(model_info);
                }
            }
        }

        if (auto it = ctr_model_map.find(0); it != ctr_model_map.end()) {
            all_models.push_back(it->second);
        }

        std::unordered_set<ExperimentModelInfo *> model_set;

        for (int conv_type: conv_types) {
            if (auto it = model_map.find(conv_type); it != model_map.end()) {
                ExperimentModelInfo *model_info = it->second;
                if (model_set.insert(model_info).second) {
                    predict_map[model_info].emplace_back(&item, &item_data, all_models);
                }
            }
        }

        if (auto it = ctr_model_map.find(0); it != ctr_model_map.end()) {
            ExperimentModelInfo *ctr_model_info = it->second;
            predict_ctr_map[ctr_model_info].emplace_back(&item, &item_data, all_models);
        }
    }


}// namespace Core