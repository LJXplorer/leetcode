#include "TruncationLogic.h"
#include "common/hilog/log_helper.h"
#include "core/core_context/prerank_context.h"
#include "template/ClassifyTemplate.h"
#include <algorithm>
#include <cstdint>
#include <debug_utils.h>
#include <future>
#include <glog/logging.h>
#include <memory>
#include <template/BeforeAfterFactory.h>
#include <thread>
#include <wrapper_time.h>
#include "common/comm/debug_utils.h"

namespace Core {
    namespace prerank {

        // bvar::LatencyRecorder g_dict_latency("cy_truncation_sort_search_dict");

        // bvar::LatencyRecorder g_prerank_sort_wait("cy_truncation_sort_wait");
        void TruncationLogic::execute(CoreContextPtr &ctx,
                std::unordered_map<std::string, std::shared_ptr<std::vector<::Core::AdsPairPtr>>> &ret) {
            HILOG_APP(INFO) << "Truncation: logic start";
           ctx->_report_info->prerank_candidate_num = _ads->size();

            if (_config_ptr == nullptr) {
                HILOG_APP(INFO) << "Truncation: " << "skip truncation logic.";
                ctx->_report_info = nullptr;
                ret["truncated_ads"] = this->_ads;
                ret["discarded_ads"] = std::make_shared<std::vector<::Core::AdsPairPtr>>();
                return;
            }

            //同时 force prerank必须为false，如果为true，不允许跳过
            if (_config_ptr->skip_prerank_ && !_config_ptr->prerank_force) {
                HILOG_APP(INFO) << "Truncation: " << "skip truncation logic.";
                ctx->_report_info = nullptr;
                ret["truncated_ads"] = this->_ads;
                ret["discarded_ads"] = std::make_shared<std::vector<::Core::AdsPairPtr>>();
                return;
            }

            HILOG_APP(INFO) << "Truncation Input Info: ";
            if (_ctx->get_rank_request()->debuglevel() == kPrerank) {
                    debug::file::WriteToFile("Truncation_ad_info_list.txt", debug::printer::ToString(*_ads));
            }

            // 先处理保送
            std::vector<::Core::AdsPairPtr> not_guaranteed_ads;
            std::vector<::Core::AdsPairPtr> guaranteed_ads;
            _gt->execute(_ads,not_guaranteed_ads,guaranteed_ads);

            //分类
            // int64_t classify_start = gettimeofday_us();
            HILOG_APP(INFO) << "Truncation: " << "classification start";
            std::shared_ptr<std::vector<AdGroup>> adg_list = _ct->execute(_ads);
            HILOG_APP(INFO) << "Truncation: " << "classification end";
            // int64_t classify_end = gettimeofday_us();
            // _config_ptr->truncation_cost_ptr->classify_time = classify_end - classify_start;

            //多分组 并行 排序
            //由于每个分组及排序模板不共享数据，故不存在线程不安全的情况
            // int64_t sort_start = gettimeofday_us();
            HILOG_APP(INFO) << "Truncation: " << "sorting start";

           

            for (AdGroup &adg: *adg_list) {
                auto st = std::make_unique<SortTemplate>(_ctx);
                st->execute(adg);
                if (adg._ss) {
                } else {
                    HILOG_APP(ERROR) << "排序策略为空！";
                }
            }
          

            HILOG_APP(INFO) << "Truncation: " << "sorting end";
            HILOG_APP(INFO) << "Truncation Sort Result: ";
            // print_adg_list(adg_list);

            //合并
            // int64_t merge_start = gettimeofday_us();
            HILOG_APP(INFO) << "Truncation: merging start";
            AdGroup adg_ret = _mt->execute(adg_list);
            HILOG_APP(INFO) << "Truncation: merging end";

            HILOG_APP(INFO) << "Truncation Merge Result: ";
          
            //截断
            // int64_t truncation_start = gettimeofday_us();
            HILOG_APP(INFO) << "Truncation: truncation start";
            _tt->execute(adg_ret);
            HILOG_APP(INFO) << "Truncation: truncation end";

            ctx->_report_info->reserved_after_truncate_num = adg_ret._truncated_ads->size();
            ctx->_report_info->discarded_after_truncate_num = adg_ret._discarded_ads->size();

            HILOG_APP(INFO) << "Truncation jump_rank: " << (_config_ptr->jump_rank ? "true" : "false");

            HILOG_APP(INFO) << "Truncation Truncate Result: ";
            // print_adg(adg_ret);

            if (_ctx->get_rank_request()->debuglevel() == kPrerank) {
                    debug::file::WriteToFile("truncation_truncate_result.txt", debug::printer::ToString(adg_ret));
            }

            //保送监控上报
            ctx->_report_info->new_ads_added_num = guaranteed_ads.size();
            ctx->_report_info->new_ads_not_added_num = not_guaranteed_ads.size();

            // 将保送队列中的广告直接加在截断后选中广告列表中
            adg_ret._truncated_ads->insert(adg_ret._truncated_ads->end(),
                                           std::make_move_iterator(guaranteed_ads.begin()),
                                           std::make_move_iterator(guaranteed_ads.end()));
            guaranteed_ads.clear();
            // 需要将保送标识的广告补充回被丢弃广告，用于兜底
            adg_ret._discarded_ads->insert(adg_ret._discarded_ads->end(),
                                           std::make_move_iterator(not_guaranteed_ads.begin()),
                                           std::make_move_iterator(not_guaranteed_ads.end()));

            not_guaranteed_ads.clear();
            // 重新排序 用于后续根据分数来兜底
            std::sort(adg_ret._discarded_ads->begin(), adg_ret._discarded_ads->end(),
                      [](const ::Core::AdsPairPtr &lhs, const ::Core::AdsPairPtr &rhs) {
                          return lhs->get_inner_score() > rhs->get_inner_score();
                      });

            HILOG_APP(INFO) << "Truncation before fallback: ";
            // // print_adg(adg_ret);
            if (_ctx->get_rank_request()->debuglevel() == kPrerank) {
                    debug::file::WriteToFile("truncation_before_fallback.txt", debug::printer::ToString(adg_ret));
            }

            //修改在线监控:保位的保留和丢弃监控改为兜底前的保留和丢弃监控
            ctx->_report_info->reserved_after_hold_num = adg_ret._truncated_ads->size();
            ctx->_report_info->discarded_after_hold_num = adg_ret._discarded_ads->size();

            //兜底
            // int64_t fallback_start = gettimeofday_us();
            HILOG_APP(INFO) << "Truncation: fallback start";
            _ft->execute(adg_ret);
            HILOG_APP(INFO) << "Truncation: fallback end";
            if (_ft->_fs) {
                ctx->_report_info->fallback_added_num = _ft->_fs->_context.fallback_added_num;
            } else {
                HILOG_APP(ERROR) << "兜底策略为空！";
            }

            ctx->_report_info->reserved_after_fallback_num = adg_ret._truncated_ads->size();
            ctx->_report_info->discarded_after_fallback_num = adg_ret._discarded_ads->size();

            HILOG_APP(INFO) << "Truncation Fallback Result: ";
            // // print_adg(adg_ret);
            if (_ctx->get_rank_request()->debuglevel() == kPrerank) {
                    debug::file::WriteToFile("truncation_fallback_result.txt", debug::printer::ToString(adg_ret));
            }

         
            //将 adg_ret 转化为更通用的对象，原对象不再可用
            // int64_t convert_start = gettimeofday_us();
            HILOG_APP(INFO) << "Truncation: convert start";
            convert_return_to_common_form(adg_ret, ret);

            HILOG_APP(INFO) << "Truncation: convert end";

            HILOG_APP(INFO) << "Truncation Convert Result: ";
            // print_execute_result(ret);
            if (_ctx->get_rank_request()->debuglevel() == kPrerank) {
                    debug::file::WriteToFile("Truncation_Convert_Result.txt", debug::printer::ToString(ret));
            }

            ctx->_report_info->truncated_ads_num = ret["truncated_ads"]->size();
            ctx->_report_info->discarded_ads_num = ret["discarded_ads"]->size();

            HILOG_APP(INFO) << "Truncation: logic end: \n"
                            << ("Truncation: truncated ads num : " + std::to_string(ret["truncated_ads"]->size()) +
                                "\n")
                            << ("Truncation: discarded ads num : " + std::to_string(ret["discarded_ads"]->size()) +
                                "\n")
                            << ("Truncation: total ads num : " +
                                std::to_string(ret["truncated_ads"]->size() + ret["discarded_ads"]->size()) + "\n");

            // int64_t convert_end = gettimeofday_us();
            // _config_ptr->truncation_cost_ptr->convert_ans_time = convert_end - convert_start;
        }

        /// @brief TODO 转换外部数据输入 为 模块内部使用数据类型
        /// @param input 模块外部输入的 广告类别名（字符串）和排序上下文（键值对信息）的 map
        /// @return 模块内部使用的 广告类别名（字符串）和排序上下文（SortContext）的 map
        std::unordered_map<std::string, SortContext> TruncationLogic::convert_input_to_internal_form(
                const std::unordered_map<std::string, std::unordered_map<std::string, std::string>> &input) {
            std::unordered_map<std::string, SortContext> ret;

            // 遍历输入的 map
            for (const auto &entry: input) {
                const std::string &category_name = entry.first;                                // 广告类别名
                const std::unordered_map<std::string, std::string> &context_map = entry.second;// 排序上下文

                SortContext sort_context(context_map,
                                         _config_ptr);// 假设 SortContext 可以接受一个 map 作为参数

                ret[category_name] = sort_context;
            }

            return ret;
        }

        // 将AdGroup对象转换为std::unordered_map<std::string, std::vector<::Core::AdsPairPtr>>对象
        // 转换方式：
        // 创建一个std::unordered_map<std::string, std::vector<::Core::AdsPairPtr>>变量用于返回
        // 在该 unordered_map 中添加一个键值对：键为 "truncated_ads" ，值为 AdGroup 的成员 std::shared_ptr<std::vector<::Core::AdsPairPtr>> _truncated_ads
        // 在该 unordered_map 中添加一个键值对：键为 "discarded_ads" ，值为 AdGroup 的成员 std::shared_ptr<std::vector<::Core::AdsPairPtr>> _discarded_ads
        // 此时 unordered_map 中有两个键值对；原对象adg_ret不再可用。转换结束
        void TruncationLogic::convert_return_to_common_form(
                AdGroup &adg_ret,
                std::unordered_map<std::string, std::shared_ptr<std::vector<::Core::AdsPairPtr>>> &result) {

            // int64_t swap_start = gettimeofday_us();
            result["truncated_ads"] = std::move(adg_ret._truncated_ads);//移动 _truncated_ads
            result["discarded_ads"] = std::move(adg_ret._discarded_ads);//移动 _discarded_ads

            // int64_t swap_stop = gettimeofday_us();

            // g_truncation_convert_swap << swap_stop - swap_start;

            HILOG_APP(INFO) << "Truncation: convert_return_to_common_form: "
                            << "truncated ads num : " + std::to_string(result["truncated_ads"]->size());
            HILOG_APP(INFO) << "Truncation: convert_return_to_common_form: "
                            << "discarded ads num : " + std::to_string(result["discarded_ads"]->size());
            HILOG_APP(INFO) << "Truncation: convert_return_to_common_form: "
                            << "total ads num : " + std::to_string(result["truncated_ads"]->size() +
                                                                   result["discarded_ads"]->size());
        }

    
    }// namespace prerank
}// namespace Core
