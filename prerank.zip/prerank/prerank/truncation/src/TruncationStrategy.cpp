#include "strategy/TruncationStrategy.h"
#include "AdGroup.h"
#include "core/core_context/prerank_context.h"
#include <algorithm>
#include <log_helper.h>
#include <stdexcept>

namespace Core {
    namespace prerank {
        void TruncationStrategy::check_if_truncated(const AdGroup &adg) {
            if (adg._is_truncated) {
                //截断过的广告组不可再次截断
                // throw std::runtime_error("AdGroup has already been truncated.");
                HILOG_APP(ERROR) << "AdGroup has already been truncated.";
                return;
            }
        }

        //直接将AdGroup中std::shared_ptr<std::vector<::Core::AdsPairPtr>> _ads的前 Config::prerank_model_count 个元素转移到
        //std::shared_ptr<std::vector<::Core::AdsPairPtr>> _truncated_ads
        //并将剩余元素转移到std::shared_ptr<std::vector<::Core::AdsPairPtr>> _discarded_ads;
        //如果 N 大于等于 std::vector<::Core::AdsPairPtr>大小 则_ads全部转移到_truncated_ads
        //执行完毕后_ads应为空 vector
        void TopMTruncation::do_operation(AdGroup &adg) {
            HILOG_APP(INFO) << "TopMTruncation::do_operation start";
            check_if_truncated(adg);

            auto &ads = adg._ads;
            auto &truncated_ads = adg._truncated_ads;
            auto &discarded_ads = adg._discarded_ads;

            //计算实际转移的数量
            size_t num_to_move = std::min(static_cast<size_t>(_context.config_ptr->prerank_model_count), ads->size());
            //转移前 N 个元素到 _truncated_ads
            truncated_ads->insert(truncated_ads->end(), ads->begin(), ads->begin() + num_to_move);
            //转移剩余元素到 _discarded_ads
            if (num_to_move < ads->size()) {
                discarded_ads->insert(discarded_ads->end(), ads->begin() + num_to_move, ads->end());
            }
            //清空 _ads
            ads->clear();

            //设置标记位为已截断
            adg._is_truncated = true;
            HILOG_APP(INFO) << "TopMTruncation::do_operation end";
        };

        //逻辑上同上面的TopMTruncation的类似，仍然是给已倒序排序的ads进行前M个广告的截断。
        //但是额外增加一个新逻辑：使用了 _context.prerank_pk_candidate 来限制 同 package name 的广告出现在_truncated_ads 中的次数：
        //使用一个unordered map ：pkgname_cnt_map ，键为 package_name ，值为当前truncated_ads中已经有了该 package name 的广告的个数
        //遍历整个ads，当 pkgname_cnt_map[当前遍历到的广告的package_name] < _context.prerank_pk_candidate 时，就将当前广告加入 truncated_ads
        //否则当 pkgname_cnt_map[当前遍历到的广告的package_name] >= _context.prerank_pk_candidate 时，将当前广告加入 discarded_ads
        void TopMAndLimitAppIdTruncation::do_operation(AdGroup &adg) {
            HILOG_APP(INFO) << "TopMAndLimitAppIdTruncation::do_operation start";
            check_if_truncated(adg);
            auto &ads = adg._ads;
            auto &truncated_ads = adg._truncated_ads;
            auto &discarded_ads = adg._discarded_ads;

            // 记录对应每个包名的广告在 truncated_ads 中出现的次数
            std::unordered_map<int32_t, int> appid_cnt_map;

            size_t truncated_count = 0;

            for (const AdsPairPtr &adptr: *ads) {
                int app_id = adptr->get_appid();

                // 如果当前包名的广告数量小于限制，则添加到 truncated_ads
                if (appid_cnt_map[app_id] < _context.config_ptr->prerank_pk_candidate &&
                    truncated_count < static_cast<size_t>(_context.config_ptr->prerank_model_count)) {
                    truncated_ads->push_back(adptr);
                    appid_cnt_map[app_id]++;
                    truncated_count++;
                } else {
                    // 否则添加到 discarded_ads
                    discarded_ads->push_back(adptr);
                }
            }

            ads->clear();
            adg._is_truncated = true;
            HILOG_APP(INFO) << "TopMAndLimitAppIdTruncation::do_operation end";
        }

        /// @brief 不可调用，无需实现
        AdGroup TopMTruncation::do_operation(std::shared_ptr<std::vector<AdGroup>> &adg_list) {
            return {};
        }

        /// @brief 不可调用，无需实现
        std::shared_ptr<std::vector<AdGroup>>
        TopMTruncation::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads) {
            return nullptr;
        }
        /// @brief 不调用，无需实现
        void TopMTruncation::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                                          std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                                          std::vector<::Core::AdsPairPtr> &guaranteed_ads) {};

        /// @brief 不可调用，无需实现
        AdGroup TopMAndLimitAppIdTruncation::do_operation(std::shared_ptr<std::vector<AdGroup>> &adg_list) {
            return {};
        }

        /// @brief 不可调用，无需实现
        std::shared_ptr<std::vector<AdGroup>>
        TopMAndLimitAppIdTruncation::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads) {
            return nullptr;
        }

        /// @brief 不调用，无需实现
        void TopMAndLimitAppIdTruncation::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                                                       std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                                                       std::vector<::Core::AdsPairPtr> &guaranteed_ads) {};

    }// namespace prerank
}// namespace Core
