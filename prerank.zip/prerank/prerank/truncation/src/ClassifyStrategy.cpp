#include "strategy/ClassifyStrategy.h"
#include "AdGroup.h"
#include "strategy/StrategyFactory.h"

#include <unordered_map>
namespace Core {
    namespace prerank {
        /// @brief 基础的分类逻辑，根据ad_info.item->category中不同的值进行分类
        std::shared_ptr<std::vector<AdGroup>> CommonClassify::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ad_info_list) {

            std::unordered_map<std::string, std::shared_ptr<std::vector<::Core::AdsPairPtr>>> categoryMap;

            //auto filter = std::make_unique<AttributeCondition>();

            // 遍历原始广告 vector
            for (const auto& ad_info : *ad_info_list) {
                if (/*filter->matches(ad)*/true) {
                    // 假设我们根据 ad.category 进行拆分
                    if (categoryMap.find(ad_info->get_category()) == categoryMap.end()) {
                        categoryMap[ad_info->get_category()] = std::make_shared<std::vector<::Core::AdsPairPtr>>();
                    }
                    categoryMap[ad_info->get_category()]->push_back(ad_info);
                }
            }

            auto result = std::make_shared<std::vector<AdGroup>>();

            // 根据分类结果创建 AdGroup
            for (const auto& pair : categoryMap) {
                const std::string& category = pair.first;
                const auto& ads = pair.second;
                const auto& ss_name = (*_context._category_sort_strategy_map)[category];
                auto& sc = (*_context._category_sort_context_map)[category];
                StrategyFactory& factory = StrategyFactory::getInstance();
                // 创建 AdGroup，并将分类后的 ::Core::AdsPairPtr 添加到其中
                result->emplace_back(AdGroup(ads, std::move(factory.create_sort_strategy(ss_name, sc))));
            }
            return result;
        }

        /// @brief 不调用，无需实现
        void CommonClassify::do_operation(AdGroup& adg) {}
        /// @brief 不调用，无需实现
        AdGroup CommonClassify::do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) { return {}; }
        /// @brief 不调用，无需实现
        void CommonClassify::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                                          std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                                          std::vector<::Core::AdsPairPtr> &guaranteed_ads) {};
    }
}