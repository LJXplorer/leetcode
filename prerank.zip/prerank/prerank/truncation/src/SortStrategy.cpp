#include "strategy/SortStrategy.h"
#include "AdGroup.h"
#include <algorithm>
#include <bvar/latency_recorder.h>
#include <wrapper_time.h>
namespace Core {

    // bvar::LatencyRecorder g_ecpm_sort_latency("cy_truncation_ecpm_sort");
    namespace prerank {
        /// @brief 根据 before() 中已经计算好的 eCPM 进行 倒序排序
        /// @param ads
        void ScoreSort::sort_ads(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads) {
            // int64_t sort_start = gettimeofday_us();
            //已经判断过ads非空
            if (!ads->empty()) {
                std::sort(ads->begin(), ads->end(), [](const ::Core::AdsPairPtr &a, const ::Core::AdsPairPtr &b) {
                    return a->get_inner_score() > b->get_inner_score();// 倒序排序
                });
            }
            // int64_t sort_end = gettimeofday_us();
            // g_ecpm_sort_latency << sort_end - sort_start;
        }

        void ScoreSort::do_operation(AdGroup &adg) {
            auto &ads = adg._ads;
            //检查 _ads 是否为空
            if (!ads || ads->empty()) {
                // TODO 广告组中没有广告，直接返回 或者 记录日志 或者 报错
                return;
            }

            //对 _ads 进行排序
            sort_ads(ads);
        }

        void NewOldAdScoreSort::sort_ads(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads) {
            if (!ads->empty()) {
                auto mid = std::partition(ads->begin(), ads->end(), [](const ::Core::AdsPairPtr &ad) {
                    return !ad->is_new();// false 在前
                });

                std::sort(ads->begin(), mid, [](const ::Core::AdsPairPtr &a, const ::Core::AdsPairPtr &b) {
                    return a->get_inner_score() > b->get_inner_score();
                });

                std::sort(mid, ads->end(), [](const ::Core::AdsPairPtr &a, const ::Core::AdsPairPtr &b) {
                    return a->get_inner_score() > b->get_inner_score();
                });
            }
        }

        void NewOldAdScoreSort::do_operation(AdGroup &adg) {
            auto &ads = adg._ads;
            //检查 _ads 是否为空
            if (!ads || ads->empty()) {
                // TODO 广告组中没有广告，直接返回 或者 记录日志 或者 报错
                return;
            }

            //对 _ads 进行排序
            sort_ads(ads);
        }

        /// @brief 不调用，无需实现
        AdGroup ScoreSort::do_operation(std::shared_ptr<std::vector<AdGroup>> &adg_list) {
            return {};
        }

        /// @brief 不调用，无需实现
        std::shared_ptr<std::vector<AdGroup>>
        ScoreSort::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads) {
            return nullptr;
        }
        /// @brief 不调用，无需实现
        void ScoreSort::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                                     std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                                     std::vector<::Core::AdsPairPtr> &guaranteed_ads) {};

        /// @brief 不调用，无需实现
        AdGroup NewOldAdScoreSort::do_operation(std::shared_ptr<std::vector<AdGroup>> &adg_list) {
            return {};
        }

        /// @brief 不调用，无需实现
        std::shared_ptr<std::vector<AdGroup>>
        NewOldAdScoreSort::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads) {
            return nullptr;
        }
        /// @brief 不调用，无需实现
        void NewOldAdScoreSort::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                                             std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                                             std::vector<::Core::AdsPairPtr> &guaranteed_ads) {};
    }// namespace prerank
}// namespace Core