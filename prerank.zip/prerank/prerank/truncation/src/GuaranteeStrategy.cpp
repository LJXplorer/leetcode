#include "strategy/GuaranteeStrategy.h"
#include "AdGroup.h"
#include "common/comm/debug_utils.h"
#include <algorithm>
#include <glog/logging.h>
#include <iterator>
#include <log_helper.h>
namespace Core {
    namespace prerank {

        void RandomGuaranteeNAdsStrategy::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                                                       std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                                                       std::vector<::Core::AdsPairPtr> &guaranteed_ads) {
            //实现随机截断保送逻辑
            HILOG_APP(INFO) << "RandomGuaranteeNAdsStrategy::do_operation start";
            if (!ads || ads->empty()) {
                HILOG_APP(ERROR) << "ads is null or empty";
                return;
            }

            // 将ads中 满足以下条件的元素 移到 guaranteed_ads 中
            // recall_type != 0 或 guaranteed == true
            // (*ads)[i]->is_new() == true || (*ads)[i]->_reqeust_adv->guaranteed() == true
            guaranteed_ads.reserve(ads->size());

            size_t j = 0;
            for (size_t i = 0; i < ads->size(); ++i) {
                auto &ad = (*ads)[i];
                if (ad->is_new() == true || ad->_reqeust_adv->guaranteed() == true) {
                    guaranteed_ads.push_back(std::move(ad));
                } else {
                    if (j != i) {
                        (*ads)[j] = std::move(ad);
                    }
                    ++j;
                }
            }
            ads->resize(j);

            HILOG_APP(INFO) << "ads is new or with guarantee flag (new_or_guarantee_ads): "
                            << debug::printer::ToString(guaranteed_ads);

            if (_ctx->get_rank_request()->debuglevel() == kPrerank) {
                debug::file::WriteToFile("new_or_guarantee_ads.txt", debug::printer::ToString(guaranteed_ads));
            }

            const size_t keep_count =
                    std::min(_ctx->get_prerank_context()->GetConfigPtr()->prerank_new_count, guaranteed_ads.size());
                    
            //如果数量不多于 prerank_new_count,那么就不需要打乱和随机截断,直接返回
            if (keep_count >= guaranteed_ads.size()) {
                not_guaranteed_ads.clear();
                HILOG_APP(INFO) << "No truncation needed. Skipping shuffle.";
                HILOG_APP(INFO) << "guaranteed_ads: " << debug::printer::ToString(guaranteed_ads);
                if (_ctx->get_rank_request()->debuglevel() == kPrerank) {
                    debug::file::WriteToFile("guaranteed_ads.txt", debug::printer::ToString(guaranteed_ads));
                    debug::file::WriteToFile("not_guaranteed_ads.txt", debug::printer::ToString(not_guaranteed_ads));
                }
                HILOG_APP(INFO) << "RandomGuaranteeNAdsStrategy::do_operation end";
                return;
            }

            // 随机截断 guaranteed_ads 中的 _ctx->get_prerank_context()->GetConfigPtr()->prerank_new_count 个新广告，被丢弃的广告移到 not_guaranteed_ads 中
            // 即 guaranteed_ads 大小 <= _ctx->get_prerank_context()->GetConfigPtr()->prerank_new_count
            // not_guaranteed_ads 大小 >= 0 且 <= ads->size() - _ctx->get_prerank_context()->GetConfigPtr()->prerank_new_count
            static thread_local std::mt19937 rng(std::random_device{}());
            std::shuffle(guaranteed_ads.begin(), guaranteed_ads.end(), rng);

            HILOG_APP(INFO) << "keep_count: " << keep_count;

            //直接把尾部不保留部分移动到 not_guaranteed_ads

            not_guaranteed_ads.assign(std::make_move_iterator(guaranteed_ads.begin() + keep_count),
                                      std::make_move_iterator(guaranteed_ads.end()));

            HILOG_APP(INFO) << "not_guaranteed_ads: " << debug::printer::ToString(not_guaranteed_ads);
            if (_ctx->get_rank_request()->debuglevel() == kPrerank) {
                debug::file::WriteToFile("not_guaranteed_ads.txt", debug::printer::ToString(not_guaranteed_ads));
            }

            //原地截断 guaranteed_ads，只保留前 keep_count 个
            guaranteed_ads.resize(keep_count);
            HILOG_APP(INFO) << "guaranteed_ads: " << debug::printer::ToString(guaranteed_ads);
            if (_ctx->get_rank_request()->debuglevel() == kPrerank) {
                debug::file::WriteToFile("guaranteed_ads.txt", debug::printer::ToString(guaranteed_ads));
            }

            HILOG_APP(INFO) << "RandomGuaranteeNAdsStrategy::do_operation end";
        };
        /// @brief 不调用，无需实现
        AdGroup RandomGuaranteeNAdsStrategy::do_operation(std::shared_ptr<std::vector<AdGroup>> &adg_list) {
            return {};
        }

        /// @brief 不调用，无需实现
        void RandomGuaranteeNAdsStrategy::do_operation(AdGroup &adg) {
        }
        /// @brief 不调用，无需实现
        std::shared_ptr<std::vector<AdGroup>>
        RandomGuaranteeNAdsStrategy::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads) {
            return nullptr;
        }

    }// namespace prerank
}// namespace Core