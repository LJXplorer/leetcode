#include "strategy/StrategyFactory.h"
#include <log_helper.h>
#include <memory>
#include <strategy/FallbackStrategy.h>
#include <strategy/GuaranteeStrategy.h>
#include <strategy/TruncationStrategy.h>

namespace Core {
    namespace prerank {
        std::unique_ptr<ClassifyStrategy> StrategyFactory::create_classify_strategy(const std::string &strategy_name,
                                                                                    const ClassifyContext &context) {
            if (strategy_name == "common") {
                return std::make_unique<CommonClassify>(context);
            }
            log_error("classify", strategy_name);
            return nullptr;
        }

        std::unique_ptr<SortStrategy> StrategyFactory::create_sort_strategy(const std::string &strategy_name,
                                                                            const SortContext &context) {

            if (strategy_name == "ltr") {
                return std::make_unique<ScoreSort>(context);
            } else if (strategy_name == "ltr-new-old-ad") {
                return std::make_unique<NewOldAdScoreSort>(context);
            }
            log_error("sort", strategy_name);
            return nullptr;
        }

        std::unique_ptr<TruncationStrategy>
        StrategyFactory::create_truncation_strategy(const std::string &strategy_name,
                                                    const TruncationContext &context) {
            if (strategy_name == "topM") {
                return std::make_unique<TopMTruncation>(context);
            } else if (strategy_name == "topM-LimitAppId") {
                return std::make_unique<TopMAndLimitAppIdTruncation>(context);
            }
            log_error("truncation", strategy_name);
            return nullptr;
        }
        std::unique_ptr<MergeStrategy> StrategyFactory::create_merge_strategy(const std::string &strategy_name,
                                                                              const MergeContext &context) {
            if (strategy_name == "singleSequential") {
                return std::make_unique<SingleSequentialMerge>(context);
            }
            log_error("merge", strategy_name);
            return nullptr;
        }

        std::unique_ptr<GuaranteeStrategy> StrategyFactory::create_guarantee_strategy(const std::string &strategy_name,
                                                                                      CoreContextPtr &ctx) {
            if (strategy_name == "randomGuaranteeNAds") {
                return std::make_unique<RandomGuaranteeNAdsStrategy>(ctx);
            }
            return nullptr;
        }

        std::unique_ptr<FallbackStrategy> StrategyFactory::create_fallback_strategy(const std::string &strategy_name,
                                                                                    const FallbackContext &context) {
            if (strategy_name == "append") {
                return std::make_unique<AppendFallback>(context);
            }
            log_error("fallback", strategy_name);
            return nullptr;
        }
    }// namespace prerank
}// namespace Core
