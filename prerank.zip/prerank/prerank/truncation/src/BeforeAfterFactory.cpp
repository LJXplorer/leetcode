#include "template/BeforeAfterFactory.h"
#include "template/SortTemplate.h"
#include <log_helper.h>
#include <memory>

namespace Core {
    namespace prerank {
        std::unique_ptr<SortBefore> BeforeAfterFactory::create_sort_before(const std::string &sort_before_strategy_name,
                                                                           CoreContextPtr &ctx) {
            
            return std::make_unique<ScoreSortBefore>(ctx);
            
            log_error("sort before");
            return nullptr;
        }
    }// namespace prerank
}// namespace Core