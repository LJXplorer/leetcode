#include "strategy/MergeStrategy.h"
#include "AdGroup.h"

namespace Core {
    namespace prerank {
        //循环遍历整个广告组的vector，
//每次遍历到一个广告组时，将_ads中的一个对象添加进返回的res中，
//最开始添加第一个对象，然后在每次遍历到该广告组时，添加下一个对象。通过下标+1的方式代替删除以提高效率
//直到所有广告组的_ads都为空，返回res。
//如果遍历到某一广告组_ads已经为空，则跳过该广告组
        AdGroup SingleSequentialMerge::do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) {
            AdGroup res;

            //创建一个索引来跟踪每个 AdGroup 的当前处理位置
            std::vector<size_t> indices(adg_list->size(), 0);

            while (true) {
                bool any_added = false;

                for (size_t i = 0; i < adg_list->size(); ++i) {
                    auto& ad_group = (*adg_list)[i];

                    //检查当前索引是否在范围内
                    if (indices[i] < ad_group._ads->size()) {
                        //将当前广告添加到 res 中
                        res._ads->push_back(ad_group._ads->at(indices[i]));
                        //移动索引
                        indices[i]++;
                        any_added = true;
                    }
                }

                //如果没有广告被添加，说明所有广告组的 _ads 都为空，退出循环
                if (!any_added) {
                    break;
                }
            }

            return res;
        }

        /// @brief 不调用，无需实现
        void SingleSequentialMerge::do_operation(AdGroup& adg) {}
        /// @brief 不调用，无需实现
        std::shared_ptr<std::vector<AdGroup>> SingleSequentialMerge::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) { return nullptr; }
        /// @brief 不调用，无需实现
        void SingleSequentialMerge::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                                                 std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                                                 std::vector<::Core::AdsPairPtr> &guaranteed_ads) {};
    }
}