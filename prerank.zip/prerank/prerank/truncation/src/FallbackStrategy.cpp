#include "strategy/FallbackStrategy.h"
#include "AdGroup.h"
#include <algorithm>

namespace Core {
    namespace prerank {
        //如果truncated_ads中的精排候选数不足Config::prerank_trunc_keep_min_count个，
//则需要再从AdGroup的std::shared_ptr<std::vector<::Core::AdsPairPtr>> _discarded_ads中筛选出广告，
//并转移到std::shared_ptr<std::vector<::Core::AdsPairPtr>> _truncated_ads中进行补足。
        void AppendFallback::do_operation(AdGroup& adg) {
            HILOG_APP(INFO) << "AppendFallback::do_operation start";
            //检查 _truncated_ads 中的广告数量
            size_t current_count = adg._truncated_ads->size();
            size_t min_count = 0;
            HILOG_APP(INFO) << "_context.config_ptr->is_cvr_prerank_req: " << _context.config_ptr->is_cvr_prerank_req;
            if(_context.config_ptr->is_cvr_prerank_req){
                //个性化cvr模型
                HILOG_APP(INFO) << "_context.config_ptr->jump_rank: " << _context.config_ptr->jump_rank;
                if(_context.config_ptr->jump_rank){
                    //达不到阈值，跳过粗排，截断数为 rank_request 
                    min_count = _context.config_ptr->rank_request;
                } else{
                    //超过阈值，不跳过粗排，截断数为 rank_item 
                    min_count = _context.config_ptr->rank_item;
                }
            } else {
                //保留原ctr逻辑
                min_count = _context.config_ptr->prerank_trunc_count;
            }
            HILOG_APP(INFO) << "min_count: " << min_count;
            
            size_t num_to_move = 0;

            //如果当前数量不足，则需要从 _discarded_ads 中补充
            if (current_count < min_count) {
                //计算需要补充的数量
                size_t needed_count = min_count - current_count;

                //从 _discarded_ads 中获取可用的广告数量
                size_t available_count = adg._discarded_ads->size();

                //计算实际转移的数量
                num_to_move = std::min(needed_count, available_count);

                //将广告从 _discarded_ads 转移到 _truncated_ads
                if (num_to_move > 0) {
                    adg._truncated_ads->insert(adg._truncated_ads->end(),
                        adg._discarded_ads->begin(),
                        adg._discarded_ads->begin() + num_to_move);

                    //从 _discarded_ads 中移除已转移的广告
                    adg._discarded_ads->erase(adg._discarded_ads->begin(),
                        adg._discarded_ads->begin() + num_to_move);
                }
            }

            _context.fallback_added_num = num_to_move;
            HILOG_APP(INFO) << "AppendFallback::do_operation end";
        }

        void DoNothingFallback::do_operation(AdGroup& adg){
            HILOG_APP(INFO) << "DoNothingFallback::do_operation run";
        }

    

        /// @brief 不调用，无需实现
        AdGroup AppendFallback::do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) { return {}; }
        /// @brief 不调用，无需实现
        std::shared_ptr<std::vector<AdGroup>> AppendFallback::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) { return nullptr; }
        /// @brief 不调用，无需实现
        void AppendFallback::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                                          std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                                          std::vector<::Core::AdsPairPtr> &guaranteed_ads) {};

        /// @brief 不调用，无需实现
        AdGroup DoNothingFallback::do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) { return {}; }
        /// @brief 不调用，无需实现
        std::shared_ptr<std::vector<AdGroup>> DoNothingFallback::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) { return nullptr; }
        /// @brief 不调用，无需实现
        void DoNothingFallback::do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                                             std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                                             std::vector<::Core::AdsPairPtr> &guaranteed_ads) {};
    }
}