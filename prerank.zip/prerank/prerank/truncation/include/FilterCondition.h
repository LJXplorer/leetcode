#ifndef FILTER_CONDITION_H
#define FILTER_CONDITION_H

#include "core/core_context/core_context.h"
#include <memory>
#include <vector>
namespace Core {
    namespace prerank {
        /// @brief 目前代码中未使用到 过滤器
        class FilterCondition {
        public:
            virtual bool matches(const ::Core::AdsPairPtr &ad) = 0;
            std::shared_ptr<std::vector<::Core::AdsPairPtr>>
            matches(const std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads) {
                auto result = std::make_shared<std::vector<::Core::AdsPairPtr>>();
                for (const auto &ad: *ads) {
                    //仅当两个条件都匹配时，才将广告添加到结果中
                    if (matches(ad)) {
                        result->push_back(ad);
                    }
                }
                return result;
            };
        };

        //与条件
        class AndCondition : public FilterCondition {
        private:
            std::unique_ptr<FilterCondition> _first;
            std::unique_ptr<FilterCondition> _second;

        public:
            AndCondition(std::unique_ptr<FilterCondition> first, std::unique_ptr<FilterCondition> second)
                : _first(std::move(first)), _second(std::move(second)) {
            }
            inline bool matches(const ::Core::AdsPairPtr &ad) override;
        };
        //或条件
        class OrCondition : public FilterCondition {
        private:
            std::unique_ptr<FilterCondition> _first;
            std::unique_ptr<FilterCondition> _second;

        public:
            OrCondition(std::unique_ptr<FilterCondition> first, std::unique_ptr<FilterCondition> second)
                : _first(std::move(first)), _second(std::move(second)) {
            }
            inline bool matches(const ::Core::AdsPairPtr &ad) override;
        };

        inline bool AndCondition::matches(const ::Core::AdsPairPtr &ad) {
            return _first->matches(ad) && _second->matches(ad);
        };

        inline bool OrCondition::matches(const ::Core::AdsPairPtr &ad) {
            return _first->matches(ad) || _second->matches(ad);
        };

        template<typename T>
        class AttributeCondition : public FilterCondition {
        private:
            std::string _attribute_name;
            T _value;

        public:
            AttributeCondition(const std::string &attribute_name, const T &value)
                : _attribute_name(attribute_name), _value(value) {
            }
            inline bool matches(const ::Core::AdsPairPtr &ad) override {
                //目前还未使用该功能
                throw std::logic_error("function: " + std::string(__func__) + " should not be called!");
                //判断 ad中的某属性值是否和 _type_name 匹配
                if (_attribute_name == "category") {

                } else if (_attribute_name == "convertion") {

                } else {
                    //TODO 未识别的属性，需要抛出异常
                }
            };
        };
    }// namespace prerank
}// namespace Core

#endif