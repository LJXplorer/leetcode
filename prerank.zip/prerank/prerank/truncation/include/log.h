#ifndef TRUNCATION_LOG_H
#define TRUNCATION_LOG_H

#include <iostream>

// #define ENABLE_DEBUG //允许输出 简单的调试信息（单行字符串）
// #define ENABLE_PRINT_INFO //允许打印模块中间过程的数据信息（类对象或 vector 对象或 map 对象） 用于观察每一流程的结果是否正确 打印的时间消耗较大 400ms
// #define ENABLE_PRINT_RESULT //允许调试时打印最终返回结果（包含两个 vector 的 map 对象） 会消耗少量时间 5ms

#ifndef ENABLE_DEBUG
#define DEBUG_LOG(msg) do {} while(0)
#define ERROR_LOG(msg) do {} while(0)
#define FUNC_TEST_START() do {} while(0)
#define FUNC_TEST_END() do {} while(0)

#else // defined ENABLE_DEBUG
#define DEBUG_LOG(msg) do { \
    std::cout << "[DEBUG] " << msg << " (File: " << __FILE__ << ", Line: " << __LINE__ << ")" << std::endl; \
} while(0)

#define ERROR_LOG(msg) do { \
    std::cerr << "[ERROR] " << msg << " (File: " << __FILE__ << ", Line: " << __LINE__ << ")" << std::endl; \
} while(0)

#define FUNC_TEST_START() std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ -------------- START -------------- ]" << std::endl
#define FUNC_TEST_END()   std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ -------------- END -------------- ]" << std::endl
#endif // defined ENABLE_DEBUG

#endif // undefined TRUNCATION_LOG_H