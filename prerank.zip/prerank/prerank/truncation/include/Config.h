#ifndef CONFIG_H
#define CONFIG_H

#include "common/comm/debug_utils.h"
#include "common/hilog/log_helper.h"
#include "core/utils/defs.h"
#include "nlohmann/json.hpp"
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <glog/logging.h>
#include <iostream>
#include <memory>
#include <nlohmann/json_fwd.hpp>
#include <ostream>
#include <string>
#include <unordered_map>

namespace Core {
    namespace prerank {
        //us 单位
        // class TruncationCost {
        // public:
        //     int64_t classify_time;
        //     int64_t sort_time;
        //     int64_t merge_time;
        //     int64_t truncation_time;
        //     int64_t hold_time;
        //     int64_t fallback_time;
        //     int64_t convert_ans_time;
        //     int64_t convert_proto_time;
        //     int64_t dump_truncation_time;
        // };
        struct MatchRule {
            std::vector<std::string> media_ids;
            std::vector<std::string> slot_ids;
            int priority;
        };
        
        class Config {
        public:
            Config()
                : prerank_trunc_count(600), prerank_model_count(580), prerank_pk_candidate(1000),
                  prerank_new_count(20), prerank_default_value( -99999999.0),
                  skip_prerank_(false) {
            }

            static bool is_match(const MatchRule &rule, int32_t media_id, int64_t slot_id) {
                //检查 media_ids
                if (!rule.media_ids.empty()) {
                    for (const auto &id: rule.media_ids) {
                        if (std::stoi(id) == media_id) {
                            HILOG_APP(INFO) << "media_id 匹配成功";
                            return true;// media_id 匹配
                        }
                    }
                }

                //检查 slot_ids
                if (!rule.slot_ids.empty()) {
                    for (const auto &id: rule.slot_ids) {
                        if (std::stol(id) == slot_id) {
                            HILOG_APP(INFO) << "slot_id 匹配成功";
                            return true;// slot_id 匹配
                        }
                    }
                }

                //如果都没有匹配 返回 false
                HILOG_APP(INFO) << "没有匹配成功";
                return false;
            }

            int parse(nlohmann::json &json, int32_t media_id, int64_t slot_id,int max_depth = 0, int current_depth = 0) {
                HILOG_APP(INFO) << "max_depth: " <<max_depth << ", current_depth: " << current_depth;
                try {
                    // 使用 JSON 数据更新类成员变量

                    if (auto it = json.find(PRERANK_TRUNC_KEEP_MIN_COUNT); it != json.end()) {
                        if (it->is_number_integer()) {
                            prerank_trunc_count = it->get<int32_t>();
                        } else {
                            HILOG_APP(ERROR) << "Key '" << PRERANK_TRUNC_KEEP_MIN_COUNT
                                               << "' type mismatch, expected integer. Using default "
                                               << prerank_trunc_count << "." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << PRERANK_TRUNC_KEEP_MIN_COUNT << "' not found in JSON."
                                        << std::endl;
                    }

                    if (auto it = json.find(PRERANK_TRUNC_MODEL_COUNT); it != json.end()) {
                        if (it->is_number_integer()) {
                            prerank_model_count = it->get<int32_t>();
                        } else {
                            HILOG_APP(ERROR) << "Key '" << PRERANK_TRUNC_MODEL_COUNT
                                               << "' type mismatch, expected integer. Using default "
                                               << prerank_model_count << "." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << PRERANK_TRUNC_MODEL_COUNT << "' not found in JSON. Using default "
                                        << prerank_model_count << "." << std::endl;
                    }

                    if (auto it = json.find(PRERANK_PK_CANDIDATE); it != json.end()) {
                        if (it->is_number_integer()) {
                            prerank_pk_candidate = it->get<int32_t>();
                        } else {
                            HILOG_APP(ERROR) << "Key '" << PRERANK_PK_CANDIDATE
                                               << "' type mismatch, expected integer. Using default "
                                               << prerank_pk_candidate << "." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << PRERANK_PK_CANDIDATE << "' not found in JSON. Using default "
                                        << prerank_pk_candidate << "." << std::endl;
                    }

                    if (auto it = json.find(PRERANK_TRUNC_NEW_COUNT); it != json.end()) {
                        if (it->is_number_integer()) {
                            prerank_new_count = it->get<size_t>();
                        } else {
                            HILOG_APP(ERROR) << "Key '" << PRERANK_TRUNC_NEW_COUNT
                                               << "' type mismatch, expected integer. Using default "
                                               << prerank_new_count << "." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << PRERANK_TRUNC_NEW_COUNT << "' not found in JSON. Using default "
                                        << prerank_new_count << "." << std::endl;
                    }

                    if(auto it = json.find(PRERANK_TRUNC_DEFAULT_PDTR); it != json.end()){
                        if (it->is_number()) {
                            prerank_default_value = it->get<double>();
                        } else {
                            HILOG_APP(ERROR) << "Key '" << PRERANK_TRUNC_DEFAULT_PDTR
                                               << "' type mismatch, expected double. Using default "
                                               << prerank_default_value << "." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << PRERANK_TRUNC_DEFAULT_PDTR << "' not found in JSON. Using default "
                                        << prerank_default_value << "." << std::endl;
                    }

                    // PRERANK_COUNT
                    if (auto it = json.find(PRERANK_COUNT); it != json.end()) {
                        if (it->is_number_integer()) {
                            prerank_count = it->get<int32_t>();
                        } else {
                            HILOG_APP(ERROR)
                                    << "Key '" << PRERANK_COUNT << "' type mismatch, expected integer. Using default "
                                    << prerank_count << "." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << PRERANK_COUNT << "' not found in JSON. Using default "
                                        << prerank_count << "." << std::endl;
                    }

                    // PRERANK_TRUNC_MEDIA_IDS
                    if (auto it = json.find(PRERANK_TRUNC_MEDIA_IDS); it != json.end()) {
                        if (it->is_string()) {
                            prerank_trunc_media_ids = it->get<std::string>();
                        } else {
                            HILOG_APP(ERROR) << "Key '" << PRERANK_TRUNC_MEDIA_IDS
                                            << "' type mismatch, expected string. Keeping default." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << PRERANK_TRUNC_MEDIA_IDS << "' not found in JSON. Keeping default."
                                        << std::endl;
                    }

                    // CATEGORY_SORT_STRATEGY_MAP
                    if (auto it = json.find(CATEGORY_SORT_STRATEGY_MAP); it != json.end()) {
                        if (it->is_object()) {
                            try {
                                category_sort_strategy_map = it->get<std::unordered_map<std::string, std::string>>();
                            } catch (const nlohmann::json::type_error &e) {
                                HILOG_APP(ERROR) << "Key '" << CATEGORY_SORT_STRATEGY_MAP
                                                << "' structure mismatch. Keeping default." << std::endl;
                            }
                        } else {
                            HILOG_APP(ERROR) << "Key '" << CATEGORY_SORT_STRATEGY_MAP
                                            << "' type mismatch, expected object. Keeping default." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << CATEGORY_SORT_STRATEGY_MAP
                                        << "' not found in JSON. Keeping default." << std::endl;
                    }

                    // CATEGORY_SORT_CONTEXT_MAP
                    if (auto it = json.find(CATEGORY_SORT_CONTEXT_MAP); it != json.end()) {
                        if (it->is_object()) {
                            try {
                                category_sort_context_map =
                                        it->get<std::unordered_map<std::string,
                                                                   std::unordered_map<std::string, std::string>>>();
                            } catch (const nlohmann::json::type_error &e) {
                                HILOG_APP(ERROR) << "Key '" << CATEGORY_SORT_CONTEXT_MAP
                                                << "' structure mismatch. Keeping default." << std::endl;
                            }
                        } else {
                            HILOG_APP(ERROR) << "Key '" << CATEGORY_SORT_CONTEXT_MAP
                                            << "' type mismatch, expected object. Keeping default." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << CATEGORY_SORT_CONTEXT_MAP
                                        << "' not found in JSON. Keeping default." << std::endl;
                    }

                    // CLASSIFY_STRATEGY_NAME
                    if (auto it = json.find(CLASSIFY_STRATEGY_NAME); it != json.end()) {
                        if (it->is_string()) {
                            classify_strategy_name = it->get<std::string>();
                        } else {
                            HILOG_APP(ERROR) << "Key '" << CLASSIFY_STRATEGY_NAME
                                            << "' type mismatch, expected string. Keeping default." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << CLASSIFY_STRATEGY_NAME << "' not found in JSON. Keeping default."
                                        << std::endl;
                    }

                    // MERGE_STRATEGY_NAME
                    if (auto it = json.find(MERGE_STRATEGY_NAME); it != json.end()) {
                        if (it->is_string()) {
                            merge_strategy_name = it->get<std::string>();
                        } else {
                            HILOG_APP(ERROR) << "Key '" << MERGE_STRATEGY_NAME
                                            << "' type mismatch, expected string. Keeping default." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << MERGE_STRATEGY_NAME << "' not found in JSON. Keeping default."
                                        << std::endl;
                    }

                    // TRUNCATION_STRATEGY_NAME
                    if (auto it = json.find(TRUNCATION_STRATEGY_NAME); it != json.end()) {
                        if (it->is_string()) {
                            truncation_strategy_name = it->get<std::string>();
                        } else {
                            HILOG_APP(ERROR) << "Key '" << TRUNCATION_STRATEGY_NAME
                                            << "' type mismatch, expected string. Keeping default." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << TRUNCATION_STRATEGY_NAME
                                        << "' not found in JSON. Keeping default." << std::endl;
                    }

                    // HOLD_STRATEGY_NAME
                    if (auto it = json.find(HOLD_STRATEGY_NAME); it != json.end()) {
                        if (it->is_string()) {
                            hold_strategy_name = it->get<std::string>();
                        } else {
                            HILOG_APP(ERROR) << "Key '" << HOLD_STRATEGY_NAME
                                            << "' type mismatch, expected string. Keeping default." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << HOLD_STRATEGY_NAME << "' not found in JSON. Keeping default."
                                        << std::endl;
                    }

                    // FALLBACK_STRATEGY_NAME
                    if (auto it = json.find(FALLBACK_STRATEGY_NAME); it != json.end()) {
                        if (it->is_string()) {
                            fallback_strategy_name = it->get<std::string>();
                        } else {
                            HILOG_APP(ERROR) << "Key '" << FALLBACK_STRATEGY_NAME
                                            << "' type mismatch, expected string. Keeping default." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key '" << FALLBACK_STRATEGY_NAME << "' not found in JSON. Keeping default."
                                        << std::endl;
                    }

                    // "prerank_adjust_file"
                    if (auto it = json.find("prerank_adjust_file"); it != json.end()) {
                        if (it->is_string()) {
                            prerank_adjust_file = it->get<std::string>();
                        } else {
                            HILOG_APP(ERROR) << "Key 'prerank_adjust_file'"
                                            << " type mismatch, expected string. Keeping default." << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key 'prerank_adjust_file' not found in JSON. Keeping default." << std::endl;
                    }

                    if (json.contains("custom_config") && (max_depth == 0 || current_depth < max_depth)) {
                        parse_custom_config(json["custom_config"], media_id, slot_id, max_depth, current_depth);
                    } else {
                        HILOG_APP(INFO) << "Key '"
                                        << "custom_config"
                                        << "' not found in JSON." << std::endl;
                    }

                    if (auto it = json.find("prerank_force"); it != json.end()) {
                        if (it->is_boolean()) {
                            prerank_force = it->get<bool>();
                        } else {
                            HILOG_APP(ERROR) << "Key 'prerank_force' type mismatch, expected boolean. "
                                               << "Using default: " << (prerank_force ? "true" : "false") << std::endl;
                        }
                    } else {
                        HILOG_APP(INFO) << "Key 'prerank_force' not found in JSON. "
                                        << "Default is: " << (prerank_force ? "true" : "false") << std::endl;
                    }

                    HILOG_APP(INFO) << "prerank_force: " << (prerank_force ? "true" : "false") << std::endl;

                } catch (const nlohmann::json::exception &e) {
                    HILOG_APP(ERROR) << "JSON parsing error: " << e.what();
                    return 0;
                } catch (const std::exception &e) {
                    HILOG_APP(ERROR) << "Error happened in prerank::Config::parse: " << e.what();
                    return 0;
                } catch (...) {
                    HILOG_APP(ERROR) << "Some error happened in prerank::Config::parse";
                    return 0;
                }
                return 1;
            }

            void parse_custom_config(nlohmann::json &configs, int32_t media_id, int64_t slot_id,
                                     int max_depth = 0, int current_depth = 0) {
                try {
                    std::vector<std::pair<int, nlohmann::json>> matched_configs;
                    matched_configs.reserve(configs.size());//预分配内存
                    HILOG_APP(INFO) << "media_id: " << media_id;
                    HILOG_APP(INFO) << "slot_id: " << slot_id;

                    for (auto &entry: configs) {
                        // 解析 match_rule
                        MatchRule rule;
                        if (entry.contains("match_rule")) {
                            const auto &match_rule = entry["match_rule"];
                            if (match_rule.contains("media_ids")) {
                                rule.media_ids = match_rule["media_ids"].get<std::vector<std::string>>();
                            } else {
                                HILOG_APP(INFO) << "Key '"
                                                << "media_ids"
                                                << "' not found in JSON." << std::endl;
                            }
                            if (match_rule.contains("slot_ids")) {
                                rule.slot_ids = match_rule["slot_ids"].get<std::vector<std::string>>();
                            } else {
                                HILOG_APP(INFO) << "Key '"
                                                << "slot_ids"
                                                << "' not found in JSON." << std::endl;
                            }
                            if (match_rule.contains("priority")) {
                                rule.priority = match_rule["priority"].get<int>();
                            } else {
                                HILOG_APP(INFO)
                                        << "Key 'priority' not found in JSON for entry: " << entry.dump() << std::endl;
                                //配置一个默认值，默认为很大，使得优先级最低
                                rule.priority = std::numeric_limits<int>::max();
                                HILOG_APP(INFO) << "Set priority of this config as default: " << rule.priority;
                            }
                        } else {
                            HILOG_APP(INFO)
                                    << "Key 'match_rule' not found in JSON for entry: " << entry.dump() << std::endl;
                        }

                        if (is_match(rule, media_id, slot_id)) {
                            matched_configs.emplace_back(rule.priority, std::move(entry["config"]));
                        }
                    }

                    std::sort(matched_configs.begin(), matched_configs.end(),
                              [](const auto &a, const auto &b) { return a.first < b.first; });

                    HILOG_APP(INFO) << debug::printer::ToString(matched_configs);
                    for (const auto &config: matched_configs) {
                        int key = config.first;
                        nlohmann::json value = config.second;
                        HILOG_APP(INFO) << "Key: " << key << ", Value: " << value.dump();
                    }

                    if (!matched_configs.empty()) {
                        this->parse(matched_configs.front().second, media_id, slot_id, max_depth, current_depth + 1);
                        HILOG_APP(INFO) << "finally use: " << to_string() << std::endl;
                    }
                } catch (const nlohmann::json::exception &e) {
                    HILOG_APP(ERROR) << "JSON parsing error: " << e.what();
                } catch (const std::exception &e) {
                    HILOG_APP(ERROR) << "Error happened in prerank::Config::parse_custom_config: " << e.what();
                } catch (...) {
                    HILOG_APP(ERROR) << "Some error happened in prerank::Config::parse_custom_config";
                }
            }

            bool parse_custom_cvr_params(nlohmann::json &configs, int32_t media_id, int64_t slot_id) {
                try {
                    std::vector<std::pair<int, nlohmann::json>> matched_configs;
                    matched_configs.reserve(configs.size());//预分配内存

                    for (auto &entry: configs) {
                        // 解析 match_rule
                        MatchRule rule;
                        if (entry.contains("match_rule")) {
                            const auto &match_rule = entry["match_rule"];
                            if (match_rule.contains("media_ids")) {
                                rule.media_ids = match_rule["media_ids"].get<std::vector<std::string>>();
                            } else {
                                HILOG_APP(INFO) << "Key '"
                                                << "media_ids"
                                                << "' not found in JSON." << std::endl;
                            }
                            if (match_rule.contains("slot_ids")) {
                                rule.slot_ids = match_rule["slot_ids"].get<std::vector<std::string>>();
                            } else {
                                HILOG_APP(INFO) << "Key '"
                                                << "slot_ids"
                                                << "' not found in JSON." << std::endl;
                            }
                            if (match_rule.contains("priority")) {
                                rule.priority = match_rule["priority"].get<int>();
                            } else {
                                HILOG_APP(INFO)
                                        << "Key 'priority' not found in JSON for entry: " << entry.dump() << std::endl;
                                //配置一个默认值，默认为很大，使得优先级最低
                                rule.priority = std::numeric_limits<int>::max();
                                HILOG_APP(INFO) << "Set priority of this config as default: " << rule.priority;
                            }
                        } else {
                            HILOG_APP(INFO)
                                    << "Key 'match_rule' not found in JSON for entry: " << entry.dump() << std::endl;
                        }

                        if (is_match(rule, media_id, slot_id)) {
                            matched_configs.emplace_back(rule.priority, std::move(entry["config"]));
                        }
                    }

                    std::sort(matched_configs.begin(), matched_configs.end(),
                              [](const auto &a, const auto &b) { return a.first < b.first; });


                    if (!matched_configs.empty()) {
                        bool ret = parse_cvr_params(matched_configs.front().second);
                        HILOG_APP(INFO) << "finally use: " << to_string() << std::endl;
                        return ret;
                    }
                } catch (const nlohmann::json::exception &e) {
                    HILOG_APP(ERROR) << "JSON parsing error: " << e.what();
                } catch (const std::exception &e) {
                    HILOG_APP(ERROR) << "Error happened in prerank::Config::parse_custom_config: " << e.what();
                } catch (...) {
                    HILOG_APP(ERROR) << "Some error happened in prerank::Config::parse_custom_config";
                }
                return false;
            }

            bool parse_cvr_params(nlohmann::json &config) {
                try {
                    if(config.contains("rank_item")){
                        rank_item = config["rank_item"].get<int32_t>();
                    } else {
                        HILOG_APP(ERROR) << "config.contains(rank_item): false";
                        return false;
                    }
                    if(config.contains("rank_request")){
                        rank_request = config["rank_request"].get<int32_t>();
                    } else {
                        rank_request = rank_item;
                    }
                    if(config.contains("N")){
                        cvr_param_n = config["N"].get<int32_t>();
                    } else {
                        HILOG_APP(ERROR) << "config.contains(N): false";
                        return false;
                    }
                    if(config.contains("ecpm_threshold")){
                        ecpm_threshold = config["ecpm_threshold"].get<double>();
                    } else {
                        HILOG_APP(ERROR) << "config.contains(ecpm_threshold): false";
                        return false;
                    }

                   
                    
                } catch (const nlohmann::json::exception &e) {
                    HILOG_APP(ERROR) << "JSON parsing error: " << e.what();
                    return false;
                } catch (const std::exception &e) {
                    HILOG_APP(ERROR) << "Error happened in prerank::Config::parse_cvr_default_params: " << e.what();
                    return false;
                } catch (...) {
                    HILOG_APP(ERROR) << "Some error happened in prerank::Config::parse_cvr_default_params";
                    return false;
                }
                return true;
            }

            // 打印配置（用于测试）
            void print_config() const {
                std::cout << to_string() << std::endl;
            }

            std::string to_string() const {
                std::ostringstream oss;
                oss << "Config Info: \n"
                    << "prerank_trunc_count: " << prerank_trunc_count << "\n"
                    << "prerank_model_count: " << prerank_model_count << "\n"
                    << "prerank_pk_candidate: " << prerank_pk_candidate << "\n"
                    << "prerank_new_count: " << prerank_new_count << "\n"
                    << "prerank_default_value: " << prerank_default_value << "\n"
                    << "prerank_count: " << prerank_count << "\n"
                    << "category_sort_context_map: " << debug::printer::ToString(category_sort_context_map) << "\n"
                    << "category_sort_strategy_map: " << debug::printer::ToString(category_sort_strategy_map) << "\n"
                    << "classify_strategy_name: " << classify_strategy_name << "\n"
                    << "merge_strategy_name: " << merge_strategy_name << "\n"
                    << "truncation_strategy_name: " << truncation_strategy_name << "\n"
                    << "hold_strategy_name: " << hold_strategy_name << "\n"
                    << "fallback_strategy_name: " << fallback_strategy_name << "\n"
                    << "category_sort_strategy_map: " << debug::printer::ToString(category_sort_strategy_map) << "\n"
                    << "category_sort_context_map: " << debug::printer::ToString(category_sort_context_map) << "\n"
                    << "dict_name: " << dict_name << "\n"
                    << "cvr_dict_name: " << cvr_dict_name << "\n"
                    << "prerank_force: " << (prerank_force ? "true" : "false") << "\n"
                    << "jump_rank: " << (jump_rank ? "true" : "false") << "\n"
                    << "is_cvr_prerank_req: " << (is_cvr_prerank_req? "true" : "false") << "\n"
                    << "use_cvr: " << (use_cvr ? "true" : "false") << "\n"
                    << "rank_item: " << rank_item << "\n"
                    << "rank_request: " <<rank_request << "\n"
                    << "cvr_param_n: " << cvr_param_n << "\n"
                    << "ecpm_threshold: " << ecpm_threshold;

                return oss.str();
            }

            // 粗排截断后保留的候选数（走精排的候选数）                    用于兜底补全
            int32_t prerank_trunc_count;

            // 粗排模型排序截断数                                        用于截断
            int32_t prerank_model_count;
            // 粗排截断 同一 package name 的候选个数上限                  用于截断
            int32_t prerank_pk_candidate;

            // 保送队列大小                                              用于保位
            size_t prerank_new_count;

            // 粗排pdtr默认值（部分候选预估失败时填充，比如找不到向量）
            // 用于输入参数为空时的默认值
            double prerank_default_value;



            // 粗排候选数（走粗排的候选数） 输入的广告数量 注意，该字段目前无效
            int32_t prerank_count;

            std::string prerank_trunc_media_ids;

            std::unordered_map<std::string, std::string> category_sort_strategy_map;
            std::unordered_map<std::string, std::unordered_map<std::string, std::string>> category_sort_context_map;
            std::string classify_strategy_name;
            std::unordered_map<std::string, std::string> classify_context;
            std::string merge_strategy_name;
            std::unordered_map<std::string, std::string> merge_context;
            std::string truncation_strategy_name;
            std::unordered_map<std::string, std::string> truncation_context;
            std::string hold_strategy_name;
            std::unordered_map<std::string, std::string> hold_context;
            std::string fallback_strategy_name;
            std::unordered_map<std::string, std::string> fallback_context;

            std::string dict_name;//广告词典名，用于获取到bid信息
            std::string cvr_dict_name;//需要使用的cvr词典名
            // std::shared_ptr<TruncationCost> truncation_cost_ptr;

            //个性化cvr模型 超参
            int32_t rank_item;
            int32_t rank_request;
            int32_t cvr_param_n;
            double ecpm_threshold;

            bool jump_rank = false;//是否跳过精排

            bool prerank_force = false;//是否强制走粗排
            bool use_cvr = false;
            bool is_cvr_prerank_req = false;
            bool skip_prerank_;

            std::string prerank_adjust_file;
         
        };
    }// namespace prerank
}// namespace Core

#endif