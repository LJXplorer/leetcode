#ifndef CLASSIFY_CONTEXT_H
#define CLASSIFY_CONTEXT_H

#include <unordered_map>
#include "context/SortContext.h"

namespace Core {
    namespace prerank {
        struct ClassifyContext {
            std::shared_ptr<std::unordered_map<std::string, std::string>> _category_sort_strategy_map;
            std::shared_ptr<std::unordered_map<std::string, SortContext>> _category_sort_context_map;

            /// @brief 
            /// @param context 
            /// @param category_sort_strategy_map 
            /// @param category_sort_context_map 
            ClassifyContext(const std::unordered_map<std::string, std::string>& context,
                const std::shared_ptr<std::unordered_map<std::string, std::string>>& category_sort_strategy_map,
                const std::shared_ptr<std::unordered_map<std::string, SortContext>>& category_sort_context_map)
                :_category_sort_strategy_map(category_sort_strategy_map),
                _category_sort_context_map(category_sort_context_map) {
                //TODO 将 std::shared_ptr<std::unordered_map<std::string, std::string>> 中的键值对 转换成 自己其他属性
            }
            ClassifyContext() {}
        };
    }
}


#endif