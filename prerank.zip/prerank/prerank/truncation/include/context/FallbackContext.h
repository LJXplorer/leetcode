#ifndef FALLBACK_CONTEXT_H
#define FALLBACK_CONTEXT_H

#include <Config.h>
#include <memory>
#include <unordered_map>

namespace Core {
    namespace prerank {
        struct FallbackContext {

            size_t fallback_added_num = 0;

            std::shared_ptr<Config> config_ptr;

            FallbackContext(const std::unordered_map<std::string, std::string>& context,std::shared_ptr<Config> config_ptr)
            : config_ptr(config_ptr){
                // TODO  将 std::shared_ptr<std::unordered_map<std::string, std::string>> 中的键值对 转换成 自己其他属性
            }
            FallbackContext() {}
        };
    }
}


#endif