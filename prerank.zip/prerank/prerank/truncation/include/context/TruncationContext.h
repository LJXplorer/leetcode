#ifndef TRUNCATION_CONTEXT
#define TRUNCATION_CONTEXT

#include <Config.h>
#include <memory>
#include <string>
#include <cstddef>
#include <unordered_map>
namespace Core {
    namespace prerank {
        struct TruncationContext {
            
            std::shared_ptr<Config> config_ptr;

            TruncationContext(const std::unordered_map<std::string, std::string> &context,
                              std::shared_ptr<Config> config_ptr)
                : config_ptr(config_ptr){
                // TODO 将 std::shared_ptr<std::unordered_map<std::string, std::string>> 中的键值对 转换成 自己其他属性
            }
            TruncationContext() {
            }
            //int top_n;//prerank_model_count
        };
    }// namespace prerank
}// namespace Core

#endif