#ifndef SORT_CONTEXT_H
#define SORT_CONTEXT_H

#include <Config.h>
#include <memory>
#include <string>
#include <unordered_map>
namespace Core {
    namespace prerank {
        struct SortContext {
            std::shared_ptr<Config> config_ptr;

            //上报参数：单次请求中使用字典中单价次数
            size_t count_found_prices = 0;
            //上报参数：单次请求中使用默认单价次数
            size_t count_default_prices = 0;

            std::string sort_before_strategy_name;
            SortContext(){}
            SortContext(const std::unordered_map<std::string, std::string> &context, std::shared_ptr<Config> config_ptr)
                : config_ptr(config_ptr) {
                //TODO  将 std::shared_ptr<std::unordered_map<std::string, std::string>> 中的键值对 转换成 自己其他属性
                auto it = context.find("score_calculator");
                sort_before_strategy_name = (it != context.end()) ? it->second : "";
            }

        };
    }// namespace prerank
}// namespace Core

#endif