#ifndef MERGE_CONTEXT_H
#define MERGE_CONTEXT_H

#include <unordered_map>
namespace Core {
    namespace prerank {
        struct MergeContext {
            MergeContext(const std::unordered_map<std::string, std::string>& context) {
                //TODO  将 std::shared_ptr<std::unordered_map<std::string, std::string>> 中的键值对 转换成 自己其他属性
            }
            MergeContext() {}
        };
    }
}


#endif