#pragma once

#include "common/hilog/log_helper.h"
#include "core/core_context/core_context.h"

namespace Core {
    namespace prerank {
        class SortBefore;
        /// @brief 策略工厂类，使用静态成员函数生成对应的策略类
        class BeforeAfterFactory {
        public:
            // 获取单例实例
            static BeforeAfterFactory& getInstance() {
                static BeforeAfterFactory instance; // 局部静态变量，保证线程安全
                return instance;
            }

            static std::unique_ptr<SortBefore> create_sort_before(const std::string &sort_before_strategy_name,
                                                                  CoreContextPtr &ctx);

        private:
            BeforeAfterFactory() = default;

            BeforeAfterFactory(const BeforeAfterFactory&) = delete;
            BeforeAfterFactory& operator=(const BeforeAfterFactory&) = delete;

            static void log_error(const std::string &type) {
                HILOG_APP(ERROR) << "prerank " << type << " BeforeAfterFactory " << __func__ << " error";
            }
        };
    }
}