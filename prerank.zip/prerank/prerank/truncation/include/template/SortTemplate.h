#ifndef SORT_TEMPLATE_H
#define SORT_TEMPLATE_H

#include "core/core_context/core_context.h"
#include "strategy/SortStrategy.h"
#include "strategy/StrategyFactory.h"
#include "AdGroup.h"
#include <cstdint>
#include <debug_utils.h>
#include <log_helper.h>
#include <memory>
#include <template/BeforeAfterFactory.h>
#include <variant>
#include <wrapper_time.h>
namespace Core {
    namespace prerank {
        // extern bvar::LatencyRecorder g_dict_latency; // 声明

        class SortBefore {
        public:
            CoreContextPtr _ctx;
            virtual void do_before(const AdGroup &ad) {
                HILOG_APP(INFO) << "run SortBefore::do_before";
            }
        };

        class ScoreSortBefore : public SortBefore {
        public:
            ScoreSortBefore() = default;
            explicit ScoreSortBefore(CoreContextPtr &ctx) {
                this->_ctx = ctx;
            }
            void do_before(const AdGroup &adg) override {
        
            }
            
            
        };

        class SortTemplate {
        public:
            std::unique_ptr<SortBefore> _sb;

            SortTemplate() = default;
            explicit SortTemplate(CoreContextPtr &ctx) {
                this->_ctx = ctx;
            }

            void execute(AdGroup &adg) {
                if (!adg._ss) {
                    //  DEBUG_LOG("未配置该类别的排序策略，跳过排序。");
                    HILOG_APP(ERROR) << "Truncation SortTemplate: 未配置该类别的排序策略，跳过排序。";
                    return;
                }
                BeforeAfterFactory &factory = BeforeAfterFactory::getInstance();
                _sb = factory.create_sort_before(adg._ss->_context.sort_before_strategy_name, _ctx);
                before(adg);
                adg._ss->do_operation(adg);
                after(adg);
            }

        protected:
            void before(AdGroup &adg) {
                _sb->do_before(adg);
            }
            void after(AdGroup &adg) {
            }

        private:
            CoreContextPtr _ctx;
        };
    }// namespace prerank
}// namespace Core

#endif