#ifndef CLASSIFY_TEMPLATE_H
#define CLASSIFY_TEMPLATE_H

#include "strategy/ClassifyStrategy.h"

#include <memory>
namespace Core {
    namespace prerank {
        class ClassifyTemplate{
        public:
            std::shared_ptr<std::vector<AdGroup>>
            execute(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads) {
                if (!_cs) {
                    //  DEBUG_LOG("未配置该类别的分类策略，跳过分类。");
                    HILOG_APP(ERROR) << "未配置该类别的分类策略，跳过分类。";
                    return std::make_shared<std::vector<AdGroup>>();
                }
                before(ads);
                auto adg_list = _cs->do_operation(ads);
                after(adg_list);
                return adg_list;
            }

            ClassifyTemplate() {
            }
            ClassifyTemplate(std::unique_ptr<ClassifyStrategy> cs) : _cs(std::move(cs)) {
            }

            std::unique_ptr<ClassifyStrategy> _cs;

        protected:
            void before(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads) {
            }
            void after(std::shared_ptr<std::vector<AdGroup>> &adg_list) {
            }
        };
    }// namespace prerank
}// namespace Core

#endif