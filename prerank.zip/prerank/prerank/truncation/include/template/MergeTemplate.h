#ifndef MERGE_TEMPLATE_H
#define MERGE_TEMPLATE_H

#include "strategy/MergeStrategy.h"
#include "AdGroup.h"
#include <memory>
namespace Core {
    namespace prerank {
        class MergeTemplate {
        public:
            AdGroup execute(std::shared_ptr<std::vector<AdGroup>> &adg_list) {
                if (!_ms) {
                    //  DEBUG_LOG("未配置该类别的合并策略，跳过合并。");
                    HILOG_APP(ERROR) << "Truncation MergeTemplate: 未配置该类别的合并策略，跳过合并。";
                    return {};
                }
                before(adg_list);
                auto adg = _ms->do_operation(adg_list);
                after(adg);
                return adg;
            }

            MergeTemplate() {
            }
            MergeTemplate(std::unique_ptr<MergeStrategy> ms) : _ms(std::move(ms)) {
            }

            std::unique_ptr<MergeStrategy> _ms;

        protected:
            void before(std::shared_ptr<std::vector<AdGroup>> &adg_list) {
            }
            void after(AdGroup &adg) {
            }
        };
    }// namespace prerank
}// namespace Core

#endif