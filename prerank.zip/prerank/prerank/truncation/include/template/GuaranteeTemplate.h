#pragma once

#include "AdGroup.h"
#include "core/core_context/core_context.h"
#include "strategy/GuaranteeStrategy.h"
#include <cstddef>
#include <glog/logging.h>
#include <log_helper.h>
#include <memory>
#include <vector>

namespace Core {
    namespace prerank {
        class GuaranteeTemplate {
        public:
            void execute(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                         std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                         std::vector<::Core::AdsPairPtr> &guaranteed_ads) {
                if (!_gs) {
                    HILOG_APP(INFO) << "Truncation GuaranteeTemplate:未配置该类别的保位策略，跳过保位。";
                    return;
                }
                before(ads, not_guaranteed_ads, guaranteed_ads);
                _gs->do_operation(ads, not_guaranteed_ads, guaranteed_ads);
                after(ads, not_guaranteed_ads, guaranteed_ads);
                return;
            }

            GuaranteeTemplate() {
            }
            GuaranteeTemplate(std::unique_ptr<GuaranteeStrategy> gs) : _gs(std::move(gs)) {
            }

            std::unique_ptr<GuaranteeStrategy> _gs;

        protected:
            void before(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                        std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                        std::vector<::Core::AdsPairPtr> &guaranteed_ads) {
            }
            void after(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                       std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                       std::vector<::Core::AdsPairPtr> &guaranteed_ads) {
            }
        };
    }// namespace prerank
}// namespace Core