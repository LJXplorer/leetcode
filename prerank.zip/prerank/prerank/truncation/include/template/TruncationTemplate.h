#ifndef TRUNCATION_TEMPLATE_H
#define TRUNCATION_TEMPLATE_H

#include "AdGroup.h"
#include "core/core_context/core_context.h"
#include "strategy/TruncationStrategy.h"
#include "template/MergeTemplate.h"
#include "template/SortTemplate.h"
#include <memory>
#include <vector>
namespace Core {
    namespace prerank {
        class TruncationTemplate {
        public:
            void execute(AdGroup &adg) {
                if (!_ts) {
                    //  DEBUG_LOG("未配置该类别的截断策略，跳过截断。");
                    HILOG_APP(ERROR) << "Truncation TruncationTemplate: 未配置该类别的截断策略，跳过截断。";
                    return;
                }
                before(adg);
                _ts->do_operation(adg);
                after(adg);
            }

            TruncationTemplate() {
            }
            TruncationTemplate(std::unique_ptr<TruncationStrategy> ts) : _ts(std::move(ts)) {
            }
            std::unique_ptr<TruncationStrategy> _ts;

        protected:
            void before(AdGroup &adg) {
            }
            void after(AdGroup &adg) {
            }
        };
    }// namespace prerank
}// namespace Core

#endif