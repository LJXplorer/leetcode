#ifndef FALLBACK_TEMPLATE_H
#define FALLBACK_TEMPLATE_H

#include "strategy/FallbackStrategy.h"
namespace Core {
    namespace prerank {
        class FallbackTemplate {
        public:
            void execute(AdGroup &adg) {
                if (!_fs) {
                    //  DEBUG_LOG("未配置该类别的兜底策略，跳过兜底。");
                    HILOG_APP(ERROR) << "Truncation FallbackTemplate: 未配置该类别的兜底策略，跳过兜底。";
                    return;
                }
                before(adg);
                _fs->do_operation(adg);
                after(adg);
            }

            FallbackTemplate() {
            }
            FallbackTemplate(std::unique_ptr<FallbackStrategy> fs) : _fs(std::move(fs)) {
            }
            std::unique_ptr<FallbackStrategy> _fs;

        protected:
            void before(AdGroup &adg) {
            }
            void after(AdGroup &adg) {
            }
        };
    }// namespace prerank
}// namespace Core

#endif