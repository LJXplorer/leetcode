#ifndef AD_GROUP_H
#define AD_GROUP_H

#include <vector>
#include <memory>
#include "core/core_context/core_context.h"
#include "strategy/SortStrategy.h"
namespace Core {
    namespace prerank {
        class AdGroup {
        public:
            std::shared_ptr<std::vector<::Core::AdsPairPtr>> _ads; //用于存储截断前的广告信息
            std::shared_ptr<std::vector<::Core::AdsPairPtr>> _truncated_ads; //用于存储截断后 被选中的广告信息
            std::shared_ptr<std::vector<::Core::AdsPairPtr>> _discarded_ads; //用于存储截断后 被丢弃的广告信息
            std::unique_ptr<SortStrategy> _ss; //用于存储该广告组的 排序策略
            bool _is_truncated;//标志位，表示是否已截断

            AdGroup()
                :_ads(std::make_shared<std::vector<::Core::AdsPairPtr>>()),
                _truncated_ads(std::make_shared<std::vector<::Core::AdsPairPtr>>()),
                _discarded_ads(std::make_shared<std::vector<::Core::AdsPairPtr>>()),
                _is_truncated(false) {}

            AdGroup(std::shared_ptr<std::vector<::Core::AdsPairPtr>> ads)
                :_ads(ads),
                _truncated_ads(std::make_shared<std::vector<::Core::AdsPairPtr>>()),
                _discarded_ads(std::make_shared<std::vector<::Core::AdsPairPtr>>()),
                _is_truncated(false) {}

            AdGroup(std::shared_ptr<std::vector<::Core::AdsPairPtr>> ads, std::unique_ptr<SortStrategy> ss)
                : _ads(ads),
                _truncated_ads(std::make_shared<std::vector<::Core::AdsPairPtr>>()),
                _discarded_ads(std::make_shared<std::vector<::Core::AdsPairPtr>>()),
                _ss(std::move(ss)),
                _is_truncated(false) {}

            /// @brief 删除拷贝构造
            AdGroup(const AdGroup&) = delete;

            /// @brief 移动构造函数
            AdGroup(AdGroup&& other) noexcept
                : _ads(std::move(other._ads)),
                _truncated_ads(std::move(other._truncated_ads)),
                _discarded_ads(std::move(other._discarded_ads)),
                _ss(std::move(other._ss)),
                _is_truncated(other._is_truncated) {
                //将 other 的标志位设置为 false
                other._is_truncated = false;
            }

            std::string to_string() const {
                std::string result = "Truncation AdGroup {\n";
                result += "Truncation   Is Truncated: " + std::string(_is_truncated ? "true" : "false") + "\n";

                result += "Truncation   Ads: [\n";
                for (const auto& ad : *_ads) {
                    result += "Truncation     " + ad->to_string() + "\n";
                }
                result += "Truncation   ],\n";

                result += "Truncation   Truncated Ads: [\n";
                for (const auto& ad : *_truncated_ads) {
                    result += "Truncation     " + ad->to_string() + "\n";
                }
                result += "Truncation   ],\n";

                result += "Truncation   Discarded Ads: [\n";
                for (const auto& ad : *_discarded_ads) {
                    result += "Truncation     " + ad->to_string() + "\n";
                }
                result += "Truncation   ]\n";

                result += "Truncation }";
                return result;
            }
        };
    }
}


#endif