#ifndef TRUNCATION_LOGIC_H
#define TRUNCATION_LOGIC_H

#include <Config.h>
#include <cstddef>
#include <debug_utils.h>
#include <glog/logging.h>
#include <log_helper.h>
#include <memory>
#include <ostream>
#include <string>
#include <template/GuaranteeTemplate.h>
#include <unordered_map>
#include <vector>

#include "AdGroup.h"
#include "core/core_context/core_context.h"

#include "strategy/StrategyFactory.h"
#include "template/BeforeAfterFactory.h"

#include "template/ClassifyTemplate.h"
#include "template/FallbackTemplate.h"
#include "template/GuaranteeTemplate.h"
#include "template/SortTemplate.h"
#include "template/TruncationTemplate.h"

#include "FilterCondition.h"

#include "log.h"
namespace Core {
    namespace prerank {
        /// @brief 截断模块 主逻辑
        class TruncationLogic {
        public:
            
            TruncationLogic(std::vector<::Core::AdsPairPtr> ads, std::shared_ptr<Config> &config_ptr,
                            CoreContextPtr &ctx)
                : _ads(std::make_shared<std::vector<::Core::AdsPairPtr>>(ads)),
                  _category_sort_strategy_map(std::make_shared<std::unordered_map<std::string, std::string>>(
                          config_ptr->category_sort_strategy_map)),
                  _config_ptr(config_ptr), _ctx(ctx) {

                ctx->_report_info = std::make_shared<ReportInfo>();
                StrategyFactory &factory = StrategyFactory::getInstance();

                // 在这里转换外部输入 std::unordered_map<std::string, std::unordered_map<std::string, std::string>> 为
                // 模块内使用的 std::unordered_map<std::string, SortContext>
                _category_sort_context_map = std::make_shared<std::unordered_map<std::string, SortContext>>(
                        convert_input_to_internal_form(config_ptr->category_sort_context_map));

                //创建策略内使用的 上下文
                ClassifyContext cc(config_ptr->classify_context, _category_sort_strategy_map,
                                   _category_sort_context_map);
                MergeContext mc(config_ptr->merge_context);
                TruncationContext tc(config_ptr->truncation_context, _config_ptr);
                FallbackContext fc(config_ptr->fallback_context, _config_ptr);

                //创建策略
                auto cs = factory.create_classify_strategy(config_ptr->classify_strategy_name, cc);
                auto ms = factory.create_merge_strategy(config_ptr->merge_strategy_name, mc);
                auto ts = factory.create_truncation_strategy(config_ptr->truncation_strategy_name, tc);
                auto gs = factory.create_guarantee_strategy(config_ptr->hold_strategy_name,_ctx);
                auto fs = factory.create_fallback_strategy(config_ptr->fallback_strategy_name, fc);

                //生成模板并配置对应策略
                _ct = std::make_unique<ClassifyTemplate>(std::move(cs));
                _mt = std::make_unique<MergeTemplate>(std::move(ms));
                _tt = std::make_unique<TruncationTemplate>(std::move(ts));
                _gt = std::make_unique<GuaranteeTemplate>(std::move(gs));
                _ft = std::make_unique<FallbackTemplate>(std::move(fs));
            };

            std::unordered_map<std::string, SortContext> convert_input_to_internal_form(
                    const std::unordered_map<std::string, std::unordered_map<std::string, std::string>> &input);

            /// @brief 将AdGroup类型转换为更加通用的数据形式，供模块外部使用。由于需要使用移动语义，原对象adg_ret不再可用
            /// @param adg_ret 模块最后的处理结果
            /// @return 更加通用的数据形式
            
            void convert_return_to_common_form(AdGroup& adg_ret,std::unordered_map<std::string, std::shared_ptr<std::vector<::Core::AdsPairPtr>>>& result);

            void execute(CoreContextPtr &ctx,std::unordered_map<std::string, std::shared_ptr<std::vector<::Core::AdsPairPtr>>> &result);

            /// @brief 输出截断模块的返回内容，以查看内部信息。用于调试
            /// @param result execute()函数的返回 包含 精排候选列表（truncated_ads） 及 丢弃广告列表（discarded_ads）
            void print_execute_result(
                    const std::unordered_map<std::string, std::shared_ptr<std::vector<::Core::AdsPairPtr>>> &result) {
#ifdef ENABLE_PRINT_RESULT
                for (const auto &entry: result) {
                    const std::string &category = entry.first;
                    const std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ad_info_vector = entry.second;

                    std::cout << "Truncation Category: " << category << std::endl;

                    if (ad_info_vector) {
                        for (const auto &ad_info: *ad_info_vector) {
                            std::cout << "Truncation   ::Core::AdsPairPtr: " << ad_info->to_string()
                                      << std::endl;// 假设 ::Core::AdsPairPtr 有 toString() 方法
                        }
                    } else {
                        std::cout << "Truncation   No ::Core::AdsPairPtr available." << std::endl;
                    }
                }
#endif
                std::ostringstream oss;
                oss << "Truncation print_execute_result:\n";

                for (const auto &entry: result) {
                    const std::string &category = entry.first;
                    const std::shared_ptr<std::vector<Core::AdsPairPtr>> &ad_info_vector = entry.second;

                    oss << "Truncation  Category: " << category << "\n";

                    if (ad_info_vector) {
                        for (const auto &ad_info: *ad_info_vector) {
                            oss << "Truncation     AdsPairPtr: " << ad_info->to_string() << "\n";
                        }
                    } else {
                        oss << "Truncation     No AdsPairPtr available.\n";
                    }
                }

                HILOG_APP(INFO) << oss.str();
            }

            static void print_adg(const AdGroup &adg) {
                if (hilog::global_helper().getAppLog()->isNeedLog(INFO)) {
                    const std::string &fallback_res = debug::printer::ToString(adg);
                    for (size_t pos = 0; pos < fallback_res.size(); pos += 4096) {
                        size_t chunk_size = std::min(static_cast<std::size_t>(4096), fallback_res.size() - pos);
                        HILOG_APP(INFO) << "[DATA_CHUNK " << pos << "] " << fallback_res.substr(pos, chunk_size);
                    }
                }
            }

            static void print_adg_list(const std::shared_ptr<std::vector<AdGroup>> &adg_list) {
#ifdef ENABLE_PRINT_INFO
                if (adg_list) {
                    for (const auto &adg: *adg_list) {
                        std::cout << adg.to_string() << std::endl;
                    }
                } else {
                    std::cout << "Ad group list is null." << std::endl;
                }
#endif
                if (adg_list) {
                    std::ostringstream oss;
                    oss << "Truncation print_adg_list:\n";
                    for (const auto &adg: *adg_list) {
                        oss << "Truncation  " << adg.to_string() << "\n";
                    }
                    HILOG_APP(INFO) << oss.str();
                } else {
                    HILOG_APP(INFO) << "Truncation print_adg_list: Ad group list is null.";
                }
            }

            static void print_ad_info_list(std::vector<::Core::AdsPairPtr> ads) {
#ifdef ENABLE_PRINT_INFO
                for (const auto &ad: ads) {
                    std::cout << ad->to_string() << std::endl;
                }
#endif

                std::ostringstream oss;
                oss << "Truncation print_ad_info_list:\n";

                for (const auto &ad: ads) {
                    oss << "Truncation  " << ad->to_string() << "\n";
                }

                HILOG_APP(INFO) << oss.str();
            }

        private:
            std::shared_ptr<std::vector<::Core::AdsPairPtr>> _ads;
            std::shared_ptr<std::unordered_map<std::string, std::string>> _category_sort_strategy_map;
            std::shared_ptr<std::unordered_map<std::string, SortContext>> _category_sort_context_map;

            std::unique_ptr<ClassifyTemplate> _ct;
            std::unique_ptr<MergeTemplate> _mt;
            std::unique_ptr<TruncationTemplate> _tt;
            std::unique_ptr<GuaranteeTemplate> _gt;
            std::unique_ptr<FallbackTemplate> _ft;

            std::shared_ptr<Config> _config_ptr;

            CoreContextPtr _ctx;

        };
    }// namespace prerank
}// namespace Core

#endif