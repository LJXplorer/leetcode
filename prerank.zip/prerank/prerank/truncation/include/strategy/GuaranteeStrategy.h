#pragma once
#include "strategy/BasicStrategy.h"

namespace Core {
    namespace prerank {
        /// @brief <<abstract>> 保送策略
        class GuaranteeStrategy : public BasicStrategy {
        public:
            GuaranteeStrategy() = default;
            ~GuaranteeStrategy() = default;
        };

        class RandomGuaranteeNAdsStrategy : public GuaranteeStrategy {
        public:
            RandomGuaranteeNAdsStrategy(CoreContextPtr &ctx) {
                this->_ctx = ctx;
            }
            ~RandomGuaranteeNAdsStrategy() = default;

            void do_operation(AdGroup &adg) override;
            AdGroup do_operation(std::shared_ptr<std::vector<AdGroup>> &adg_list) override;
            std::shared_ptr<std::vector<AdGroup>>
            do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads) override;
            void do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                              std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                              std::vector<::Core::AdsPairPtr> &guaranteed_ads) override;
        };
    }// namespace prerank
}// namespace Core