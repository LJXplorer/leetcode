#ifndef TRUNCATION_STRATEGY_H
#define TRUNCATION_STRATEGY_H

#include "context/TruncationContext.h"
#include "strategy/BasicStrategy.h"

#include <vector>
#include <memory>
namespace Core {
    namespace prerank {
        /// @brief <<abstract>> 截断策略
        class TruncationStrategy :public BasicStrategy {
        public:
            explicit TruncationStrategy(TruncationContext context) :_context(context) {};
            ~TruncationStrategy() = default;
            TruncationContext _context;
        protected:
            static void check_if_truncated(const AdGroup& adg);
        };

        /// @brief 前M个广告元素 截断策略
        class TopMTruncation : public TruncationStrategy {
        public:
            TopMTruncation(TruncationContext context) :TruncationStrategy(context) {};
            ~TopMTruncation() = default;

            /// @brief 截断前M个广告
            /// @param adg 未执行截断的广告组
            void do_operation(AdGroup& adg) override;

            /// @brief 不调用，无需实现
            AdGroup do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) override;

            /// @brief 不调用，无需实现
            std::shared_ptr<std::vector<AdGroup>> do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) override;
            /// @brief 不调用，无需实现
            void do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                              std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                              std::vector<::Core::AdsPairPtr> &guaranteed_ads) override;
        };

        class TopMAndLimitAppIdTruncation : public TruncationStrategy {
        public:
            explicit TopMAndLimitAppIdTruncation(TruncationContext context) :TruncationStrategy(context) {};
            ~TopMAndLimitAppIdTruncation() = default;

            /// @brief 截断前M个广告，同时限制同package name广告出现的次数
            /// @param adg 未执行截断的广告组
            void do_operation(AdGroup& adg) override;

            /// @brief 不调用，无需实现
            AdGroup do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) override;

            /// @brief 不调用，无需实现
            std::shared_ptr<std::vector<AdGroup>> do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) override;
            /// @brief 不调用，无需实现
            void do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                              std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                              std::vector<::Core::AdsPairPtr> &guaranteed_ads) override;
        };
    }
}

#endif