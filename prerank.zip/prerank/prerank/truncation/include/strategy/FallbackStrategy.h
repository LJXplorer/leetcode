#ifndef FALLBACK_STRATEGY_H
#define FALLBACK_STRATEGY_H

#include "strategy/BasicStrategy.h"
#include "context/FallbackContext.h"

namespace Core {
    namespace prerank {
        /// @brief <<abstract>> 最终广告兜底策略
        class FallbackStrategy :public BasicStrategy {
        public:
            FallbackStrategy(FallbackContext context) :_context(context) {}
            ~FallbackStrategy() = default;

            FallbackContext _context;
        };

        /// @brief 在丢弃广告数组中选出广告并转移到选中广告数组，来补充截断输出的广告数量
        class AppendFallback :public FallbackStrategy {
        public:
            AppendFallback(FallbackContext context) :FallbackStrategy(context) {}
            ~AppendFallback() = default;

            void do_operation(AdGroup& adg) override;
            AdGroup do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) override;
            std::shared_ptr<std::vector<AdGroup>> do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) override;
            void do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                              std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                              std::vector<::Core::AdsPairPtr> &guaranteed_ads) override;
        };

        /// @brief 直接跳过兜底
        class DoNothingFallback :public FallbackStrategy {
        public:
            DoNothingFallback(FallbackContext context) :FallbackStrategy(context) {}
            ~DoNothingFallback() = default;

            void do_operation(AdGroup& adg) override;
            AdGroup do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) override;
            std::shared_ptr<std::vector<AdGroup>> do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) override;
            void do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                              std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                              std::vector<::Core::AdsPairPtr> &guaranteed_ads) override;
        };

    
    }
}



#endif