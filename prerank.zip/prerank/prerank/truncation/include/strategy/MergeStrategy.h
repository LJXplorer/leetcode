#ifndef MERGE_STRATEGY_H
#define MERGE_STRATEGY_H

#include <memory>
#include <vector>
#include "strategy/BasicStrategy.h"
#include "context/MergeContext.h"

namespace Core {
    namespace prerank {
        /// @brief <<abstract>> 合并策略
        class MergeStrategy : public BasicStrategy {
        public:
            MergeStrategy(MergeContext context) :_context(context) {}
            ~MergeStrategy() = default;
        protected:
            MergeContext _context;
        };


        /// @brief 
        class SingleSequentialMerge :public MergeStrategy {
        public:
            SingleSequentialMerge(MergeContext context) :MergeStrategy(context) {};
            ~SingleSequentialMerge() = default;

            /// @brief 不调用，无需实现
            void do_operation(AdGroup& adg) override;

            /// @brief 顺序遍历多个广告组，每次遍历都会转移每个广告组中的一个广告到合并结果中。对于广告组，广告是从头到尾依次转移的。
            /// @param adg_list 多个广告组
            /// @return 合并成的一个广告组
            AdGroup do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) override;
            /// @brief 不调用，无需实现
            std::shared_ptr<std::vector<AdGroup>> do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) override;
            void do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                              std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                              std::vector<::Core::AdsPairPtr> &guaranteed_ads) override;
        };

    }
}



#endif