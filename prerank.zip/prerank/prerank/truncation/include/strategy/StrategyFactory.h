#ifndef STRATEGY_FACTORY_H
#define STRATEGY_FACTORY_H

#include <memory>
#include <strategy/GuaranteeStrategy.h>

#include "ClassifyStrategy.h"
#include "MergeStrategy.h"
#include "SortStrategy.h"
#include "GuaranteeStrategy.h"
#include "TruncationStrategy.h"
#include "FallbackStrategy.h"
namespace Core {
    namespace prerank {
        /// @brief 策略工厂类，使用静态成员函数生成对应的策略类
        class StrategyFactory {
        public:
            // 获取单例实例
            static StrategyFactory& getInstance() {
                static StrategyFactory instance; // 局部静态变量，保证线程安全
                return instance;
            }

            static std::unique_ptr<ClassifyStrategy> create_classify_strategy(
                const std::string& strategy_name, const ClassifyContext& context);
            static std::unique_ptr<SortStrategy> create_sort_strategy(
                const std::string& strategy_name, const SortContext& context);
            static std::unique_ptr<TruncationStrategy> create_truncation_strategy(
                const std::string& strategy_name, const TruncationContext& context);
            static std::unique_ptr<MergeStrategy> create_merge_strategy(
                const std::string& strategy_name, const MergeContext& context);
            static std::unique_ptr<GuaranteeStrategy> create_guarantee_strategy(const std::string &strategy_name,
                                                                                CoreContextPtr &ctx);
            static std::unique_ptr<FallbackStrategy> create_fallback_strategy(
                const std::string& strategy_name, const FallbackContext& context);

        private:
            StrategyFactory() = default;

            StrategyFactory(const StrategyFactory&) = delete;
            StrategyFactory& operator=(const StrategyFactory&) = delete;

            static void log_error(const std::string &type,const std::string &strategy_name) {
                HILOG_APP(ERROR) << "prerank " << type << " StrategyFactory " << __func__ << " error: " << strategy_name;
            }
        };
    }
}



#endif