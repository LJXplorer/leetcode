#ifndef SORT_STRATEGY_H
#define SORT_STRATEGY_H

#include <memory>
#include <vector>
#include <string>

#include "context/SortContext.h"
#include "strategy/BasicStrategy.h"

namespace Core {
    namespace prerank {
        /// @brief <<abstract>> 排序策略
        class SortStrategy : public BasicStrategy {
        public:
            SortStrategy(SortContext context) :_context(context) {}
            ~SortStrategy() = default;
        
            SortContext _context;
        };

        /// @brief 
        class ScoreSort :public SortStrategy {
        public:
            ScoreSort(SortContext context) :SortStrategy(context) {}
            ~ScoreSort() = default;

            /// @brief 根据 eCpm 降序排序
            /// @param adg 待排序的广告组
            void do_operation(AdGroup& adg) override;

            /// @brief 不调用，无需实现
            AdGroup do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) override;
            /// @brief 不调用，无需实现
            std::shared_ptr<std::vector<AdGroup>> do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) override;
            void do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                              std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                              std::vector<::Core::AdsPairPtr> &guaranteed_ads) override;

        private:
            void sort_ads(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads);
        };


        class NewOldAdScoreSort :public SortStrategy {
        public:
            NewOldAdScoreSort(SortContext context) :SortStrategy(context) {}
            ~NewOldAdScoreSort() = default;

            /// @brief 根据 eCpm 降序排序
            /// @param adg 待排序的广告组
            void do_operation(AdGroup& adg) override;

            /// @brief 不调用，无需实现
            AdGroup do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) override;
            /// @brief 不调用，无需实现
            std::shared_ptr<std::vector<AdGroup>> do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) override;
            void do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                              std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                              std::vector<::Core::AdsPairPtr> &guaranteed_ads) override;

        private:
            void sort_ads(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads);
        };
    }
}

#endif