#ifndef BASIC_STRATEGY_H
#define BASIC_STRATEGY_H

#include <memory>
#include <vector>

#include "core/core_context/core_context.h"
namespace Core {
    namespace prerank {
        class AdGroup;

        /// @brief <<abstract>> 策略
        class BasicStrategy {
        public:
            /// @brief 处理 单个广告组的 策略逻辑 用于 排序、截断、保位、兜底
            /// @param adg 单个广告组
            virtual void do_operation(AdGroup& adg) = 0;

            /// @brief 针对 多个广告组的 策略逻辑 用于 合并
            /// @param adg_list 多个广告组
            /// @return 合并成的 单个广告组
            virtual AdGroup do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) = 0;

            /// @brief 针对 粗排输入的广告列表的 策略逻辑 用于 分类
            /// @param ads 广告数组
            /// @return 多个广告组
            virtual std::shared_ptr<std::vector<AdGroup>> do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) = 0;

            /// @brief 针对 粗排输入的广告列表的 策略逻辑 用于 保送
            /// @param ads 广告数组 未进入保送队列的广告 进入保送队列的广告
            virtual void do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                                      std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                                      std::vector<::Core::AdsPairPtr> &guaranteed_ads) = 0;
            virtual ~BasicStrategy() = default;

            CoreContextPtr _ctx;
        };
    }
}



#endif