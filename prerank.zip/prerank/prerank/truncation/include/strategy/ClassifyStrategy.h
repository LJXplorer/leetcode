#ifndef CLASSIFY_STRATEGY_H
#define CLASSIFY_STRATEGY_H

#include <memory>
#include <vector>
#include "strategy/BasicStrategy.h"
#include "context/ClassifyContext.h"
namespace Core {
    namespace prerank {
        /// @brief <<abstract>> 分类策略
        class ClassifyStrategy : public BasicStrategy {
        public:
            ClassifyStrategy(ClassifyContext context) :_context(context) {}
            ~ClassifyStrategy() = default;
        protected:
            ClassifyContext _context;
        };

        class CommonClassify :public ClassifyStrategy {
        public:
            CommonClassify(ClassifyContext context) :ClassifyStrategy(context) {};
            ~CommonClassify() = default;

            /// @brief 不调用，无需实现
            void do_operation(AdGroup& adg) override;
            /// @brief 不调用，无需实现
            AdGroup do_operation(std::shared_ptr<std::vector<AdGroup>>& adg_list) override;
            std::shared_ptr<std::vector<AdGroup>> do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>>& ads) override;
            void do_operation(std::shared_ptr<std::vector<::Core::AdsPairPtr>> &ads,
                              std::vector<::Core::AdsPairPtr> &not_guaranteed_ads,
                              std::vector<::Core::AdsPairPtr> &guaranteed_ads) override;
        };
    }
}


#endif