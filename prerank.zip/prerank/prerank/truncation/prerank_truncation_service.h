#ifndef TRUNCATION_SERVICE_H
#define TRUNCATION_SERVICE_H

#include "core/core_context/core_context.h"
#include "core/core_services/base_service/service_info.h"
#include <TruncationLogic.h>
#include <bvar/latency_recorder.h>
#include <cstdint>
#include <memory>
#include <unordered_map>

namespace Core {

    class TruncationService : public ServiceBaseInfo {
    public:
        TruncationService() {
            // truncation_cost_ptr = std::make_shared<prerank::TruncationCost>();
        }
        virtual ~TruncationService() {
        }

        void initialize(ConfigXmlPtr xml) override;
        void initialize(GraphContextPtr context) override;
        virtual void initialize_xml(ConfigXmlPtr xml);
        int do_service(GraphContextPtr context) override;
        bool skip(GraphContextPtr context) override;
        bool is_dump_truncation(const std::string &oaid) {
            int32_t hash_res = get_hash(oaid);
            return hash_res < _truncation_dump_end_policy;
        }

        bool is_retain_return(const std::string &oaid) {
            int32_t hash_res = get_hash(oaid);
            return hash_res < _retain_return_end_policy;
        }

        int32_t get_hash(const std::string &salt_str) {
            uint32_t out;
            butil::MurmurHash3_x86_32(salt_str.c_str(), salt_str.length(), _SEED, &out);
            return out % _ONE_HUNDRED;
        }

    private:
        int32_t _split_size = 40;
        bool _return_discarded_ads = true;
        bool _is_truncation = false;
        int32_t _truncation_dump_end_policy = 5;
        int32_t _retain_return_end_policy = 0;
        int32_t _ONE_HUNDRED = 100;
        int32_t _SEED = 0x7f3a21eaL;
        int process(CoreContextPtr context);

        int parse_json_params(std::unordered_map<std::string, std::string> &result, const std::string &json_string);

        int
        parse_nested_json_params(std::unordered_map<std::string, std::unordered_map<std::string, std::string>> &result,
                                 const std::string &json_string);

        int convert_proto(CoreContextPtr context);

        int down_grade(CoreContextPtr context);

        void get_batch_size_map(CoreContextPtr context, std::unordered_map<int32_t, std::string> &batch_map);
        int32_t get_batch_size(int32_t model_type, std::unordered_map<int32_t, std::string> &batch_size_map);
    public:
        virtual void item_model_list(Core::CoreContextPtr context, const ::phx::PredictorItemInfo &item,
                             ::phx::PredictorItemData &item_data);
        // std::shared_ptr<prerank::TruncationCost> truncation_cost_ptr;
    };
}// namespace Core
#endif