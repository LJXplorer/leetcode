# 截断模块设计

线上文档：https://elink.e.hihonor.com/wiki/PQTvwc925if3hUkjd7BlQFj2rWg

## 主要功能

将输入的广告列表根据具体的分组逻辑进行分组，然后每个广告分组各自使用自己的排序策略进行倒序排序。接着将已排好序的所有广告分组合并成完整的广告列表。再在后面进行截断、保位、兜底动作。最终返回被截断选出的精排候选，以及被丢弃的广告列表。
## 功能图示

![功能示意图](imgs/image001.png "功能示意图")

设计时考虑到模块的灵活性，故将所有的功能拆分成最小的模块，如：分类、排序、合并、截断、保位、兜底，来保证单一职责。又使用模板模式固定每个功能模块主要以 before()、execute()、after()三个函数的先后顺序执行逻辑，实现功能可扩展及流程清晰。其中的execute()函数还可以根据不同模块的模板调用对应的策略，实现实际功能的动态配置以及复用。

## 基本数据结构

### AdItem
即广告对象，目前使用自定义的简单结构代替。实际会用更复杂的pb定义的数据结构。待接入predictor后替换。
### AdInfo
广告对象 + pdtr + bid + 权重 + eCPM 等信息组成的信息对象
### AdGroup
广告组-- 该对象 及 该种对象的vector对象 会贯穿整个截断模块始终，所有的策略都直接应用在这两种数据结构上，以确保输入输出结构的统一。
#### 主要成员对象
- 广告信息列表
- 用于存储精排候选的广告信息列表
- 用于存储丢弃的广告信息列表
- 该广告组应该使用的排序策略
#### 主要成员函数
#### 类图

![类图](imgs/image002.png "AdGroup")

### Config
单例
#### 成员对象
属性
描述
默认值
prerank_trunc_count
粗排截断后保留的候选数（走精排的候选数）
700
prerank_model_count
粗排模型排序截断数
680
prerank_new_count
新广告保位数
20
prerank_default_value
粗排pdtr默认值（部分候选预估失败时填充，比如找不到向量）
0.0001
prerank_trunc_default_stat_down_price
粗排统计下载单价默认值（候选找不到统计值时填充）
0.01
prerank_trunc_default_pred
未进入精排的候选默认值（这部分填充精排的ctr，cvr，deepcvr）
0.0001
prerank_trunc_aduint_ids
支持的广告位（""，slot_id，空表示不走粗排）
""
prerank_pd_factor
粗排加权因子（以package_name为粒度，格式为"package_name1:factor1,package_name2:factor2"）
"1:1"
prerank_model_name
粗排模型名（""，空表示不走粗排）
""
prerank_count
粗排候选数（走粗排的候选数）
800
#### 类图
![类图](imgs/image003.png "Config")
## 主逻辑（TruncationLogic）
### 介绍
模块外创建 TruncationLogic类并提供必要的参数后，即可调用成员函数execute()执行主逻辑，执行完毕后会返回精排候选列表以及被丢弃的广告列表。
### 类图
![类图](imgs/image004.png "TruncationLogic")
### 子模块
各功能的模板类图：
![类图](imgs/image005.png "Template")
各功能的策略类图：
![类图](imgs/image006.png "Strategy")
策略工厂类：
![类图](imgs/image007.png "Factory")
### 分类（Classify）
根据给出的特定条件，将输入的广告列表分类到多个广告组。注意：同一广告可能被分到不同的广告组（AdGroup）中，即广告组之间并不是互斥的，且合并时可能会出现重复的广告元素。逻辑可能较复杂，

#### common
目前实现了根据广告信息中某一属性进行分类的逻辑。

初步计划使用哈希表来实现根据 某一 或 多个特定属性的组合 给广告列表中的广告分类。如果需要，可配合使用过滤器模式来生成具体的条件，对整个广告列表进行过滤。
过滤器类图：

![类图](imgs/image008.png "Filter")

### 排序（Sort）
根据某种指标或某几种指标实现对一个广告列表的降序排序。排序逻辑需要可配置可替换。
排序的具体逻辑在排序策略类的do_operation()成员函数中实现，在排序模板类的execute()成员函数中调用。
排序模板中不存储具体的策略，而是让每个AdGroup来存储本组将使用的排序策略。具体的排序策略在上游分类（Classify）中使用工厂模式创建并存储进AdGroup中。
除排序外其他模板需要存储具体的策略，因为整个逻辑中仅会使用一种截断或保位或兜底的策略。
#### eCPM
目前已经实现了该策略，即根据每个广告的eCPM大小来倒序排序。
$$eCPM = pdtr \times bid$$
### 合并（Merge）
合并策略可能比较复杂。
初步考虑的方案：逐个在每个广告组中取出第一个广告，添加进合并结果中，直到所有的广告组都被选空为止。
这里也可以不按广告组的排列顺序，而是根据权重或概率进行选择。

#### singleSequentialMerge
目前已经实现了该策略，顺序遍历多个广告组，每次遍历都会转移每个广告组中的一个广告到合并结果中。对于广告组，广告是从头到尾依次转移的。
### 截断（Truncation）
根据某种策略，对AdGroup的广告列表ads进行截断，截断执行完毕后ads将为空。被选中的广告将存储在成员truncated_ads中，被丢弃的广告将存储在成员discarded_ads
#### topM
目前已经实现了该策略，即保留广告组前M个广告，丢弃后面的广告。
### 保位（Hold）
仅针对新广告。截断后，根据某种策略，进行对于新广告的保位。在AdGroup的成员discarded_ads中挑选新广告，并转移到成员truncated_ads中，以实现保位逻辑。
#### nextN
目前已经实现了该策略，即在discarded_ads中选出前N个新广告，转移到truncated_ads中。
### 兜底（Fallback）
在模块最后，如果truncated_ads中的精排候选数不足，则需要再从discarded_ads中筛选出广告，并转移到truncated_ads中进行补足。
#### append
目前已经实现了该策略，即使用discarded_ads中靠前的广告，来补充truncated_ads，以保证精排候选的数量.