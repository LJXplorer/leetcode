
#include "core/core_services/prerank/truncation/alloc_item_service.h"
#include "core/core_context/context_defs.h"
#include "hlframe/register.h"
#include <log_helper.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>
namespace Core {
SERVICE_REGISTER(AllocItemService);

void AllocItemService::item_model_list(
    CoreContextPtr context,
    const ::phx::PredictorItemInfo& item,
    ::phx::PredictorItemData& item_data
) {
    item_data.set_appid(item.appid()); // set appid
    std::vector<ExperimentModelInfo*> all_models;
    std::unordered_set<std::string> model_name_set;
    // cvr
    std::vector<int> cvr_types;
    std::vector<ExperimentModelInfo*> cvr_models;
    if(item.cvr1target()>0) {
        cvr_types.emplace_back(item.cvr1target());
    }
    if(item.cvr2target()>0) {
        cvr_types.emplace_back(item.cvr2target());
    }
    for(const int cvr_type : cvr_types) {
        auto it = context->_cpc_cvr_model_map.find(cvr_type);
        if(it != context->_cpc_cvr_model_map.end()) {
            ExperimentModelInfo* model_info = it->second;
            if(model_name_set.insert(model_info->_model_name).second) {
                all_models.emplace_back(model_info);
                cvr_models.emplace_back(model_info);
            }
        }
    }
    
    // ltv
    std::vector<int> ltv_types;
    std::vector<ExperimentModelInfo*> ltv_models;
    if(item.ltv1target()>0) {
        ltv_types.emplace_back(item.ltv1target());
    }
    if(item.ltv2target()>0) {
        ltv_types.emplace_back(item.ltv2target());
    }
    for(const int ltv_type : ltv_types) {
        auto it = context->_ltv_model_map.find(ltv_type);
        if(it != context->_ltv_model_map.end()) {
            ExperimentModelInfo* model_info = it->second;
            if(model_name_set.insert(model_info->_model_name).second) {
                all_models.emplace_back(model_info);
                ltv_models.emplace_back(model_info);
            }
        }
    }

    for(int i=0; i<cvr_models.size(); ++i) {
        context->_model_predict_cpc_cvr_map[cvr_models[i]].emplace_back(&item, &item_data, all_models);
    }

    for(int i=0; i<ltv_models.size(); ++i) {
        context->_model_predict_ltv_map[ltv_models[i]].emplace_back(&item, &item_data, all_models);
    }
}

}