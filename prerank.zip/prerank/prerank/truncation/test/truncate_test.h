#ifndef TRUNCATE_TEST_H
#define TRUNCATE_TEST_H

#include "test_util.h"
#include "template/TruncationTemplate.h"
#include "core/core_context/core_context.h"
#include "TruncationLogic.h"

using Core::prerank::Config;
using Core::prerank::AdGroup;
using Core::prerank::StrategyFactory;
using Core::prerank::FallbackContext;
using Core::prerank::ClassifyContext;
using Core::prerank::TruncationContext;
using Core::prerank::TruncationTemplate;

void test_topm_truncate() {
    FUNC_TEST_START();

    Config& cfg = Config::getInstance();
    cfg.prerank_model_count = 5;

    TruncationContext tc;

    StrategyFactory& sf = StrategyFactory::getInstance();
    auto ts = sf.create_truncation_strategy("topM", tc);
    TruncationTemplate tt(std::move(ts));
    std::shared_ptr<std::vector<::Core::AdsPairPtr>> ads = std::make_shared<std::vector<::Core::AdsPairPtr>>();

    for (int i = 0; i < 10; ++i) {
        std::string category = get_random_category();
        ads->emplace_back(std::make_shared<::Core::AdsPair>(get_random_category(), generate_random_double(30, 100), generate_random_double(0.01, 3), get_random_is_new(0.1)));
    }

    AdGroup adg(ads);
    TruncationLogic::print_adg(adg);
    auto start_time = std::chrono::high_resolution_clock::now();
    tt.execute(adg);
    //计时结束
    auto end_time = std::chrono::high_resolution_clock::now();
    //计算 耗时（ms）
    std::chrono::duration<double, std::milli> duration = end_time - start_time;

    TruncationLogic::print_adg(adg);
    DEBUG_LOG("Execution time: " << duration.count() << " ms");

    FUNC_TEST_END();
}


#endif