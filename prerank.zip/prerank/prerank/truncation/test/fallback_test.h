#ifndef FALLBACK_TEST_H
#define FALLBACK_TEST_H

#include "test_util.h"
#include "template/FallbackTemplate.h"
#include "core/core_context/core_context.h"
#include "TruncationLogic.h"

using Core::prerank::Config;
using Core::prerank::AdGroup;
using Core::prerank::StrategyFactory;
using Core::prerank::FallbackContext;
using Core::prerank::FallbackTemplate;

void test_append_fallback() {
    FUNC_TEST_START();
    using Core::prerank::Config;
    using Core::prerank::AdGroup;
    using Core::prerank::StrategyFactory;
    using Core::prerank::FallbackContext;

    Config& config = Config::getInstance();
    //实际添加个数 = 精排候选数 - 当前截断个数
    config.prerank_trunc_count = 12;//即 12-10=2

    AdGroup adg;
    auto truncated_ads = std::make_shared<std::vector<::Core::AdsPairPtr>>();
    auto discarded_ads = std::make_shared<std::vector<::Core::AdsPairPtr>>();
    for (int i = 0; i < 10; ++i) {
        std::string category = get_random_category();
        truncated_ads->emplace_back(std::make_shared<::Core::AdsPair>(get_random_category(), generate_random_double(30, 100), generate_random_double(0.01, 3), get_random_is_new(0.1)));
    }
    for (int i = 0; i < 5; ++i) {
        std::string category = get_random_category();
        discarded_ads->emplace_back(std::make_shared<::Core::AdsPair>(get_random_category(), generate_random_double(30, 100), generate_random_double(0.01, 3), get_random_is_new(0.1)));
    }
    adg._truncated_ads = truncated_ads;
    adg._discarded_ads = discarded_ads;
    adg._is_truncated = true;

    StrategyFactory& sf = StrategyFactory::getInstance();
    FallbackContext fc;
    auto fs = sf.create_fallback_strategy("append", fc);
    FallbackTemplate ft(std::move(fs));
    TruncationLogic::print_adg(adg);
    ft.execute(adg);
    TruncationLogic::print_adg(adg);
    DEBUG_LOG("truncated ads num : " + std::to_string(adg._truncated_ads->size()));
    DEBUG_LOG("discarded ads num : " + std::to_string(adg._discarded_ads->size()));
    DEBUG_LOG("total ads num : " + std::to_string(adg._truncated_ads->size() + adg._discarded_ads->size()));
    FUNC_TEST_END();
}


#endif