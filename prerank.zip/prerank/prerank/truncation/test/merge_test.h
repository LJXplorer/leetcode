#ifndef MERGE_TEST
#define MERGE_TEST

#include "test_util.h"
#include <memory>
#include "template/MergeTemplate.h"
#include "core/core_context/core_context.h"
#include "TruncationLogic.h"

using Core::prerank::Config;
using Core::prerank::AdGroup;
using Core::prerank::StrategyFactory;
using Core::prerank::FallbackContext;
using Core::prerank::ClassifyContext;
using Core::prerank::MergeContext;
using Core::prerank::MergeTemplate;
using Core::prerank::TruncationLogic;

void test_single_sequential_merge() {
    FUNC_TEST_START();

    auto adg_list = std::make_shared<std::vector<AdGroup>>();

    for (int i = 0;i < 5;++i) {
        std::shared_ptr<std::vector<::Core::AdsPairPtr>> ads = std::make_shared<std::vector<::Core::AdsPairPtr>>();
        for (int i = 0; i < 10; ++i) {
            std::string category = get_random_category();
            ads->emplace_back(std::make_shared<::Core::AdsPair>(get_random_category(), generate_random_double(30, 100), generate_random_double(0.01, 3), get_random_is_new(0.1)));
        }
        adg_list->emplace_back(AdGroup(ads));
    }

    TruncationLogic::print_adg_list(adg_list);

    MergeContext mc;
    StrategyFactory& sf = StrategyFactory::getInstance();
    auto ss = sf.create_merge_strategy("singleSequential", mc);
    MergeTemplate mt(std::move(ss));
    AdGroup ret = mt.execute(adg_list);
    TruncationLogic::print_adg(ret);
    FUNC_TEST_END();
}


#endif