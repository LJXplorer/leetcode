#ifndef TEST_UTIL_H
#define TEST_UTIL_H

#include <random>
#include <chrono>
#include "log.h"

double generate_random_double(double min, double max) {
    std::random_device rd; //获取随机数种子
    std::mt19937 gen(rd()); //使用梅森旋转算法生成随机数
    std::uniform_real_distribution<> dis(min, max); //定义均匀分布

    return dis(gen);
}

std::string get_random_category() {
    std::vector<std::string> categories = { "游戏", "体育", "公益", "其他" };
    std::vector<double> weights = { 0.5, 0.3, 0.05, 0.15 }; // 权重总和应为 1.0

    double total_weight = std::accumulate(weights.begin(), weights.end(), 0.0);

    if (std::abs(total_weight - 1.0) > 1e-6) {
        throw std::runtime_error("Weights must sum to 1.0. Current sum: " + std::to_string(total_weight));
    }

    //计算累积和
    std::vector<double> cumulative_weights(weights.size());
    cumulative_weights[0] = weights[0];
    for (size_t i = 1; i < weights.size(); ++i) {
        cumulative_weights[i] = cumulative_weights[i - 1] + weights[i];
    }

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(0.0, 1.0);
    double random_value = dis(gen);

    //根据随机数选择类别
    for (size_t i = 0; i < cumulative_weights.size(); ++i) {
        if (random_value < cumulative_weights[i]) {
            return categories[i];
        }
    }

    return categories.back();
}

bool get_random_is_new(double probability) {
    // 生成一个随机数并与概率进行比较
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(0.0, 1.0);  //生成 [0.0, 1.0) 的随机数

    return dis(gen) < probability;
}

#endif