#ifndef HOLD_TEST_H
#define HOLD_TEST_H

#include "test_util.h"
#include "template/HoldTemplate.h"
#include "core/core_context/core_context.h"
#include "TruncationLogic.h"

using Core::prerank::Config;
using Core::prerank::AdGroup;
using Core::prerank::StrategyFactory;
using Core::prerank::FallbackContext;
using Core::prerank::ClassifyContext;
using Core::prerank::HoldContext;
using Core::prerank::HoldTemplate;

void test_nextn_hold() {
    FUNC_TEST_START();

    Config& config = Config::getInstance();
    config.prerank_new_count = 3;

    AdGroup adg;
    auto truncated_ads = std::make_shared<std::vector<::Core::AdsPairPtr>>();
    auto discarded_ads = std::make_shared<std::vector<::Core::AdsPairPtr>>();
    for (int i = 0; i < 10; ++i) {
        std::string category = get_random_category();
        truncated_ads->emplace_back(std::make_shared<::Core::AdsPair>(get_random_category(), generate_random_double(30, 100), generate_random_double(0.01, 3), get_random_is_new(0.1)));
    }
    for (int i = 0; i < 5; ++i) {
        std::string category = get_random_category();
        discarded_ads->emplace_back(std::make_shared<::Core::AdsPair>(get_random_category(), generate_random_double(30, 100), generate_random_double(0.01, 3), get_random_is_new(0.1)));
    }
    adg._truncated_ads = truncated_ads;
    adg._discarded_ads = discarded_ads;
    adg._is_truncated = true;

    StrategyFactory& sf = StrategyFactory::getInstance();
    HoldContext hc;
    auto hs = sf.create_hold_strategy("nextN", hc);
    HoldTemplate ht(std::move(hs));
    TruncationLogic::print_adg(adg);
    ht.execute(adg);
    TruncationLogic::print_adg(adg);

    DEBUG_LOG("truncated ads num : " + std::to_string(adg._truncated_ads->size()));
    DEBUG_LOG("discarded ads num : " + std::to_string(adg._discarded_ads->size()));
    DEBUG_LOG("total ads num : " + std::to_string(adg._truncated_ads->size() + adg._discarded_ads->size()));

    FUNC_TEST_END();
}


#endif