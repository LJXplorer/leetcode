#include "strategy/SortStrategy.h"
#include "template/SortTemplate.h"
#include "context/SortContext.h"

#include <unordered_map>
#include "Config.h"
#include "TruncationLogic.h"
#include "test_util.h"
#include "classify_test.h"
#include "fallback_test.h"
#include "hold_test.h"
#include "sort_test.h"
#include "merge_test.h"
#include "truncate_test.h"

using Core::prerank::TruncationLogic;

std::unordered_map<std::string, std::string> category_sort_strategy_map{
    {"游戏","eCPM"},
    {"其他","eCPM"},
    {"体育","eCPM"},
    {"公益","eCPM"},
};

std::unordered_map<std::string, std::unordered_map<std::string, std::string>> category_sort_context_map{
    {"游戏",{}},
    {"其他",{}},
    {"体育",{}},
    {"公益",{}},
};

std::shared_ptr<std::vector<::Core::AdsPairPtr>> ads = std::make_shared<std::vector<::Core::AdsPairPtr>>();

void prepare() {
    // 使用默认配置

    DEBUG_LOG("prepare test data start");
    for (int i = 0; i < 800; ++i) {
        std::string category = get_random_category();
        ads->emplace_back(std::make_shared<::Core::AdsPair>(get_random_category(), generate_random_double(30, 100), generate_random_double(0.01, 3), get_random_is_new(0.1)));
    }
    DEBUG_LOG("prepare test data end");
}

//供复制使用
void test_() {
    FUNC_TEST_START();



    FUNC_TEST_END();
}

void test_all() {
    FUNC_TEST_START();
    Config& config = Config::getInstance();
    config.print_config();

    //开始计时
    auto start_time = std::chrono::high_resolution_clock::now();

    TruncationLogic truncation_logic(*ads, category_sort_strategy_map, category_sort_context_map,
        "common", {}, "singleSequential", {}, "topM", {}, "nextN", {}, "append", {});

    truncation_logic.execute();

    //计时结束
    auto end_time = std::chrono::high_resolution_clock::now();

    //计算 耗时（ms）
    std::chrono::duration<double, std::milli> duration = end_time - start_time;
    DEBUG_LOG("Execution time: " << duration.count() << " ms");

    FUNC_TEST_END();
}




int main() {
    prepare();//构造测试数据

    // test_ecpm_sort();

    // test_common_classify();

    // test_single_sequential_merge();

    // test_topm_truncate();

    // test_nextn_hold();

    // test_append_fallback();

    test_all();
}