#ifndef CLASSIFY_TEST_H
#define CLASSIFY_TEST_H

#include "core/core_context/core_context.h"
#include "template/ClassifyTemplate.h"
#include "strategy/StrategyFactory.h"
#include "TruncationLogic.h"
#include "test_util.h"

using Core::prerank::Config;
using Core::prerank::AdGroup;
using Core::prerank::StrategyFactory;
using Core::prerank::FallbackContext;
using Core::prerank::ClassifyContext;
using Core::prerank::SortContext;
using Core::prerank::ClassifyTemplate;
using Core::prerank::TruncationLogic;

extern std::unordered_map<std::string, std::string> category_sort_strategy_map;

extern std::unordered_map<std::string, std::unordered_map<std::string, std::string>> category_sort_context_map;

extern std::shared_ptr<std::vector<::Core::AdsPairPtr>> ads;

void test_common_classify() {
    FUNC_TEST_START();

    std::unordered_map<std::string, std::string> context;

    //分类时需要配置 排序策略
    auto category_sort_strategy_map_ptr = std::make_shared<std::unordered_map<std::string, std::string>>(category_sort_strategy_map);
    auto _category_sort_context_map = std::make_shared<std::unordered_map<std::string, SortContext>>(
        TruncationLogic::convert_input_to_internal_form(category_sort_context_map));

    ClassifyContext cc(context, category_sort_strategy_map_ptr, _category_sort_context_map);

    StrategyFactory& factory = StrategyFactory::getInstance();
    ClassifyTemplate ct(std::move(factory.create_classify_strategy("common", cc)));

    auto ads_copy = std::make_shared<std::vector<::Core::AdsPairPtr>>(*ads);
    auto res = ct.execute(ads_copy);
    TruncationLogic::print_adg_list(res);

    int sum = 0;
    for (const auto& adg : *res) {
        sum += adg._ads->size();
        DEBUG_LOG("adg._ads->size(): "<<adg._ads->size());
    }
    DEBUG_LOG("sum: " << sum);
    FUNC_TEST_END();
}


#endif