#ifndef SORT_TEST_H
#define SORT_TEST_H

#include "template/SortTemplate.h"
#include "test_util.h"
#include "TruncationLogic.h"
#include "core/core_context/core_context.h"

using Core::prerank::Config;
using Core::prerank::AdGroup;
using Core::prerank::StrategyFactory;
using Core::prerank::FallbackContext;
using Core::prerank::ClassifyContext;
using Core::prerank::SortContext;
using Core::prerank::SortTemplate;

extern std::shared_ptr<std::vector<::Core::AdsPairPtr>> ads;

void test_ecpm_sort() {
    FUNC_TEST_START();
    SortTemplate st;
    SortContext sc;

    StrategyFactory& sf = StrategyFactory::getInstance();
    auto ss = sf.create_sort_strategy("eCPM", sc);

    // std::shared_ptr<std::vector<::Core::AdsPairPtr>> ads = std::make_shared<std::vector<::Core::AdsPairPtr>>();

    // for (int i = 0; i < 10; ++i) {
    //     std::string category = get_random_category();
    //     ads->emplace_back(std::make_shared<::Core::AdsPair>(AdItem(category), generate_random_double(30, 100), generate_random_double(0.01, 3), get_random_is_new(0.1)));
    // }
    auto ads_copy = std::make_shared<std::vector<::Core::AdsPairPtr>>(*ads);
    AdGroup adg(ads_copy, std::move(ss));
    auto start_time = std::chrono::high_resolution_clock::now();
    st.execute(adg);
    //计时结束
    auto end_time = std::chrono::high_resolution_clock::now();
    //计算 耗时（ms）
    std::chrono::duration<double, std::milli> duration = end_time - start_time;

    TruncationLogic::print_adg(adg);
    DEBUG_LOG("Execution time: " << duration.count() << " ms");
    FUNC_TEST_END();
}

#endif