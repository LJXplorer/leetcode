#include "ad_store_server.h"
#include "common/hidict/dict_counters_provider.h"
#include "core/core_context/core_context.h"
#include "core/core_server/server_config/server_config.h"
#include "core/core_services/dict/dict_mgr.h"
#include "core/core_services/dict/metrics_flusher.h"
#include "core/core_services/dump/dump_redis_manager/dump_redis_manager.h"
#include "core/core_services/predict/utils/model_version.h"
#include "core/core_services/prerank/embedding_cache/feature_cache.h"
#include "core/core_services/prerank/offline/offline_item_emb_dict_loader.h"
#include "hlframe/graph_manager.h"
#include <bthread/types.h>
#include <chrono>
#include <debug_utils.h>
#include <filesystem>
#include <fstream>
#include <memory>
#include <string>
#include <vector>
#include <unordered_map>
namespace fs = std::filesystem;

using namespace Core;
static AdDict::MetricsFlusher g_flusher(60);
extern hidict::RealCounters g_real;

namespace ADStore {
    static std::unordered_map<std::string, std::string> g_last_marker_filename;

    ADStoreServer::ADStoreServer() {
    }

    ADStoreServer::~ADStoreServer() {
        g_flusher.stop();
    }

    int ADStoreServer::initialize(int argc, char *argv[]) {
        config::ConfigServiceCfg cfg{.server_adder = ServerConfig::_server_adder,
                                     .auth_user_name = ServerConfig::_auth_user_name,
                                     .auth_passwd = ServerConfig::_auth_passwd,
                                     .name_space = ServerConfig::_name_space};

        // 在线时才会创建
        hidict::g_counters = &hidict::g_real;

        if (Core::AdDictConfigMgr::instance().init(cfg, ServerConfig::_dict_group_id, ServerConfig::_dict_data_id) !=
            ERROR_SUCCESS) {
            std::cerr << "dict xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        }

        // 这里已经词典计数器已经注册完成
        g_flusher.start();

        if (Core::Info::ModelInfoManager::instance().init(cfg, ServerConfig::_model_info_group_id,
                                                          ServerConfig::_model_info_data_id) != ERROR_SUCCESS) {
            std::cerr << "model_info xml parse fail" << std::endl;
            return ERROR_SYS_NOT_FIND_CONFIG_PATH;
        } else {
            std::cerr << "ModelInfoManager init success" << std::endl;
        }
        ModelVersion::instance().new_init();

        Core::DumpRedisManager::instance().init();
        if (ServerConfig::_feature_report_enable.load()) {
            feature_report_task_run();
        }
        start_offline_embedding_loader_task();
        return 0;
    }

    void ADStoreServer::feature_report_task_run() {
        auto feature_report_start_task = []() {
            HILOG_APP(ERROR) << "[feature_report] feature_report_start_task";
            if (ServerConfig::_feature_report_enable.load()) {
                ServerConfig::_feature_report_running.store(true);
            }
        };

        auto feature_report_end_task = []() {
            HILOG_APP(ERROR) << "[feature_report] feature_report_end_task";
            ServerConfig::_feature_report_running.store(false);
        };

        int32_t start_h = ServerConfig::_feature_report_start_h;
        int32_t end_h = (start_h + ServerConfig::_feature_report_period_h) % 24;
        _feature_report_start_task =
                common::g_backgroud_task_executor.PostPeriodicCron(1, 0, start_h, feature_report_start_task);
        _feature_report_start_task->Start();

        _feature_report_end_task =
                common::g_backgroud_task_executor.PostPeriodicCron(0, 0, end_h, feature_report_end_task);
        _feature_report_end_task->Start();
    }

    void ADStoreServer::start_offline_embedding_loader_task() {
        auto task = []() {
            try {
                HILOG_APP(ERROR) << "古娜拉黑暗之神：开始定时每分钟扫描";
                auto &model_info_manager = Core::Info::ModelInfoManager::instance();
                auto &channel_map = model_info_manager.get_model_infos();
                for (const auto &channel_pair : channel_map) {
                    if (channel_pair.second->_model_type != Core::Info::ModelType::ITEM_EMBEDDING) {
                        continue;
                    }
                    const std::string &model_name = channel_pair.first;
                    auto model_dir = fs::path(ServerConfig::_emb_path) / model_name;

                    auto pick_marker = [&](std::string &out_base_dir, std::string &out_marker_filename) -> bool {
                        std::error_code ec;
                        if (!fs::exists(model_dir, ec) || !fs::is_directory(model_dir, ec)) {
                            return false;
                        }
                        fs::path marker_path;
                        bool found = false;
                        std::string chosen_name;
                        fs::path chosen_path;
                        for (const auto &entry : fs::directory_iterator(model_dir)) {
                            const auto &p = entry.path();
                            if (!fs::is_regular_file(p)) { continue; }
                            std::string filename = p.filename().string();
                            if (filename.find("base_dir") == std::string::npos) { continue; }
                            if (!found || filename > chosen_name) {
                                chosen_name = filename;
                                chosen_path = p;
                                found = true;
                            }
                        }
                        if (!found) { return false; }
                        marker_path = chosen_path;
                        std::ifstream ifs(marker_path.string());
                        if (!ifs.is_open()) { return false; }
                        std::string base_dir;
                        std::getline(ifs, base_dir);
                        ifs.close();
                        if (base_dir.empty()) { return false; }
                        out_base_dir = base_dir;
                        out_marker_filename = marker_path.filename().string();
                        HILOG_APP(ERROR) << "古娜拉黑暗之神：找到base_dir了！file=" << marker_path.string();
                        return true;
                    };

                    std::string base_dir;
                    std::string marker_filename;
                    bool ok = pick_marker(base_dir, marker_filename);
                    if (!ok) { ok = pick_marker(base_dir, marker_filename); } // 重试一次，避免写入端在删除/写入的窗口期
                    if (!ok) {
                        HILOG_APP(ERROR) << "古娜拉黑暗之神：base_dir marker not found or unreadable for model: " << model_name;
                        continue;
                    }
                    bool should_load = false;
                    std::string prev_marker;
                    auto it = g_last_marker_filename.find(model_name);
                    if (it == g_last_marker_filename.end()) {
                        should_load = true;
                        g_last_marker_filename[model_name] = marker_filename;
                        prev_marker = "";
                    } else {
                        prev_marker = it->second;
                        if (prev_marker != marker_filename) {
                            should_load = true;
                            it->second = marker_filename;
                        } else {
                            should_load = false;
                        }
                    }
                    if (!should_load) {
                        HILOG_APP(ERROR) << "古娜拉黑暗之神 base_dir 标记未变化，跳过加载。model="
                                         << model_name << ", marker_file=" << marker_filename;
                        continue;
                    } else {
                        HILOG_APP(ERROR) << "古娜拉黑暗之神：base_dir 标记发生变化，执行加载。model="
                                         << model_name << ", prev_marker_file=" << prev_marker
                                         << ", curr_marker_file=" << marker_filename;
                    }
                    int32_t current_version = ModelVersion::instance().get_model_version(model_name);
                    HILOG_APP(ERROR) << "古娜拉黑暗之神：loading from base_dir for model " << model_name
                                     << ", version=" << current_version << ", base_dir=" << base_dir;
                    int ret = Core::prerank::LoadLatestEmbeddingFromGoose(model_name, current_version, base_dir);
                    if (ret != 0) {
                        HILOG_APP(ERROR) << "古娜拉黑暗之神：LoadLatestEmbeddingFromGoose failed for model "
                                         << model_name << ", ret=" << ret;
                    }
                }
            } catch (const std::exception &e) {
                HILOG_APP(ERROR) << "[offline_loader] exception: " << e.what();
            }
        };

        _offline_loader_task = common::g_backgroud_task_executor.PostPeriodic(std::chrono::minutes(1), task);
        _offline_loader_task->Start();
    }

}// namespace ADStore
