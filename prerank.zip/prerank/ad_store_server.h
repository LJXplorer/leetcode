#ifndef _AD_STORE_SERVER_H
#define _AD_STORE_SERVER_H
#include "core/core_server/core_server.h"
#include "core/core_context/prerank_context.h"

namespace ADStore {

class ADStoreServer : public Core::CoreServer {
public:
  ADStoreServer();
  ~ADStoreServer();
  virtual int initialize(int argc, char *argv[]);
private:
  std::shared_ptr<common::PeriodicCronTask> _feature_report_start_task;
  std::shared_ptr<common::PeriodicCronTask> _feature_report_end_task;
  void feature_report_task_run();
  void start_offline_embedding_loader_task();
  std::shared_ptr<common::PeriodicTask> _offline_loader_task;
};

} // namespace ADStore

#endif
