#ifndef BRPC_POLARIS_NAMING_SERVICE_H
#define BRPC_POLARIS_NAMING_SERVICE_H

#include <brpc/periodic_naming_service.h>
#include <brpc/server.h>
#include <brpc/server_id.h>
#include <brpc/server_node.h>
#include <polaris/consumer.h>
#include <polaris/provider.h>
#include <butil/synchronization/lock.h>
#include <set>

namespace brpc {
namespace policy {

class PolarisNamingService : public PeriodicNamingService {
public:
    PolarisNamingService();
    ~PolarisNamingService();

    int GetServers(const char* service_name, std::vector<ServerNode>* servers) override;

    void Describe(std::ostream& os, const DescribeOptions&) const override;

    NamingService* New() const override {return new PolarisNamingService;};

    void Destroy() override {delete this;};

    int GetNamingServiceAccessIntervalMs() const override ;


private:
    bool ParsePolarisName(const char* service_name,
                         std::string& namespace_name,
                         std::string& real_service_name);
};
}// namespace policy

} // namespace brpc

#endif // BRPC_POLARIS_NAMING_SERVICE_H