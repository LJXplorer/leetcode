#include "polaris_instance.h"
#include <gflags/gflags_declare.h>
#include <glog/logging.h>
#include <iostream>
#include <string>
#include <iostream>
#include <gflags/gflags.h>

namespace brpc {
namespace policy {

DECLARE_string(polaris_cluster);
DECLARE_int32(polaris_timeout_ms);
DECLARE_string(polaris_name_space);
DECLARE_string(polaris_cache);
DECLARE_string(polaris_service_refresh_interval);   //# 范围:[1s:...]# polaris-cpp默认值:2s
DECLARE_string(polaris_service_expire_time);        //# 范围:[1m:...] # polaris-cpp默认值:24h

PolarisInstace& PolarisInstace::instance() {
    static PolarisInstace inst;
    return inst;
};

PolarisInstace::PolarisInstace(){
    
    std::string config_str = 
        "global:\n"
        "  serverConnector:\n"
        "    addresses: [" + FLAGS_polaris_cluster + "]\n"
        "    connectTimeout: " + std::to_string(FLAGS_polaris_timeout_ms) + "\n"
        "consumer:\n"
        "  localCache:\n"
        "    serviceRefreshInterval: "+ FLAGS_polaris_service_refresh_interval + "\n"
        "    serviceExpireTime: "+ FLAGS_polaris_service_expire_time + "\n"
        "    persistDir: "+ FLAGS_polaris_cache + "\n"
        ; 
    std::string errorMsg;
    polaris::Config* config = polaris::Config::CreateFromString(config_str, errorMsg);

    polaris::Context* context = polaris::Context::Create(config);
    delete config;  

    if (!context) {
        std::cout<< "error create consumer context: " << std::endl;
        LOG(FATAL) << "Config parse failed. Input config:\n" << config_str;
    }
    _consumer = polaris::ConsumerApi::Create(context);

};

polaris::ConsumerApi* PolarisInstace::get_consumer(){
    return _consumer;
}

}
}
