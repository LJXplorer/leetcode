#include <memory>
#include <polaris/consumer.h>
namespace brpc {
    namespace policy {
        class PolarisInstace {
            private:
                polaris::ConsumerApi* _consumer;
            public:
            static PolarisInstace& instance();
            PolarisInstace();
            polaris::ConsumerApi* get_consumer();
        };
    };
};