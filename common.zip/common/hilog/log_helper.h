#ifndef _HI_LOG_HELPER_H_
#define _HI_LOG_HELPER_H_

#include <glog/logging.h>
#include <gflags/gflags.h>
#include <boost/noncopyable.hpp>
//#include <boost/filesystem.hpp>
#include <filesystem>
#include <string>
#include <mutex>
#include <stdio.h>
#include <time.h>
#include <thread>
#include <list>
#include <chrono>
#include <condition_variable>
#include <map>

namespace hilog {

using namespace std;
using namespace google;


struct LogMessage
{
    string       _log_msg;
    struct ::tm  _tm;
    int64_t      _time_ms;
};

class DayLogSink : public google::LogSink
{
public:
    explicit DayLogSink(const std::string&path,const string &strFileName, const string &strExt, int max_file_num = 5);

    virtual ~DayLogSink();

    virtual void send(LogSeverity severity, const char* full_filename,
                       const char* base_filename, int line,
                       const struct ::tm* tm_time,
                       const char* message, size_t message_len);

    virtual void send(LogSeverity severity, const char* full_filename,
                       const char* base_filename, int line,
                       const struct ::tm* tm_time,
                       const char* message, size_t message_len, int32 usecs);
    
    void setMaxFileSize(long maxFileSize);

    void setMaxFileNum(int fileNum);

    void Terminate();

    void addErrorLogNum(LogSeverity severity) {
        if (severity < google::GLOG_ERROR) {
            return;
        }
        //_error_log_num->operator<<(1);
    }

    int64_t getErrorLogNum() {
        return 0;
        //return _error_log_num->qps();
    }

    bool isNeedLog(LogSeverity severity) {
        addErrorLogNum(severity);
        return severity >= _log_level;
    }


    void setLogLevel(LogSeverity severity){ _log_level = severity; }

private:
    void PushData(const LogMessage &logMsg);

    void AsyncWriteData();

    void Write(const LogMessage &logMsg);

    void Flush(int64_t time_ms);

    void openLogFile(const struct ::tm* tm_time, int64_t time_ms);

    void shift(const struct ::tm* tm_time, int64_t time_ms);

    string fileName(int index);

    int cmpDayTime(const struct ::tm* left, const struct ::tm* right);
    string       _path = "./log/";
    string       _file_name;
    string       _file_ext;
    FILE*        _file;
    struct tm    _tm_day;

    long         _file_size;
    int          _max_file_num;
    long         _max_file_size;
    long         _bytes_since_flush;
    int64_t      _last_flush_time;

    volatile bool       _terminate;
    thread              _async_work;
    
    int                 _max_msg_size;
    mutex               _mtx;
    condition_variable  _cond;
    list<LogMessage>    _msg_list;
    LogSeverity         _log_level;
    //std::shared_ptr<bvar::LatencyRecorder> _error_log_num;
};

class LogHelper : public boost::noncopyable
{
public:
    explicit LogHelper() {
        _sys_log = NULL;
        _app_log = NULL;
        //_monitor_log = NULL;
    }
    
    virtual ~LogHelper() {
        google::ShutdownGoogleLogging();
        if(_sys_log)      delete _sys_log;
        if(_app_log)      delete _app_log;
        //if(_monitor_log)  delete _monitor_log;
    }

    void initialize(const std::string&appName,const std::string&_p){
        _path = _p;
        google::InitGoogleLogging(appName.c_str());
        
        filesystem::path p(_path);
        if (!filesystem::exists(p)) {
            filesystem::create_directory(p);
            CHECK(filesystem::exists(p)) <<
            "create log directory: " << _path << " failed.";
        }

        _sys_log = new DayLogSink(_path,appName, "sys");
        _app_log = new DayLogSink(_path,appName, "app");
        //_monitor_log = new DayLogSink(_path,appName, "monitor");
    }

    void setSysLogLevel(LogSeverity severity){ _sys_log->setLogLevel(severity); }
    void setAppLogLevel(LogSeverity severity){ _app_log->setLogLevel(severity); }
    //void setMonitorLogLevel(LogSeverity severity){ _monitor_log->setLogLevel(severity); }

    DayLogSink* getSystemLog() { return _sys_log; }
    DayLogSink* getAppLog() { return _app_log; }
    //DayLogSink* getMonitorLog() { return _monitor_log; }

    void Terminate()
    {
        if(_sys_log)       _sys_log->Terminate();
        if(_app_log)       _app_log->Terminate();
        //if(_monitor_log)   _monitor_log->Terminate();
    }

protected:
    DayLogSink*   _sys_log;
    DayLogSink*   _app_log;
    //DayLogSink*   _monitor_log;
    std::string _path;
};


inline LogHelper& global_helper()
{
    static LogHelper logHelper;
    return logHelper;
}

inline std::map<std::string, int>& global_log_level() {
    static std::map<std::string, int> a =
        {{"INFO", google::GLOG_INFO}, {"WARNING", google::GLOG_WARNING},
         {"ERROR", google::GLOG_ERROR}, {"FATAL", google::GLOG_FATAL}};
    return a;
}

};


#define HILOG_SYS(severity)          \
static_cast<void>(0),                   \
!(hilog::global_helper().getSystemLog()->isNeedLog(google::severity)) ? (void) 0 : \
google::LogMessageVoidify() & LOG_TO_SINK_BUT_NOT_TO_LOGFILE(hilog::global_helper().getSystemLog(), severity)

#define HILOG_APP(severity)          \
static_cast<void>(0),                   \
!(hilog::global_helper().getAppLog()->isNeedLog(google::severity)) ? (void) 0 : \
google::LogMessageVoidify() & LOG_TO_SINK_BUT_NOT_TO_LOGFILE(hilog::global_helper().getAppLog(), severity)


/*
#define HILOG_MONITOR(severity)      \
static_cast<void>(0),                   \
!(hilog::global_helper().getMonitorLog()->isNeedLog(google::severity)) ? (void) 0 : \
google::LogMessageVoidify() & LOG_TO_SINK_BUT_NOT_TO_LOGFILE(hilog::global_helper().getMonitorLog(), severity)
*/
#endif
