#include "dictionary_reader.h"
#include <charconv>
#include <glog/logging.h>
#include <log_helper.h>
#include <vector>

std::string trimQuotes(const std::string& input) {
    std::string result = input;

    // 如果字符串非空并且首尾都是双引号，则去除之
    if (!result.empty() && result.front() == '"' && result.back() == '"') {
        result = result.substr(1, result.size() - 2);
    }
    
    return result;
}

bool DictionaryReader::start() {
    std::thread backgroundThread(&DictionaryReader::run, this);
    backgroundThread.detach();
    std::this_thread::sleep_for(std::chrono::seconds(2));
    return true;
}

std::string getMaxSubDirectory(const std::string& dirPath) {
    std::string maxSubDir;
    DIR* dir;
    struct dirent* ent;
    if ((dir = opendir(dirPath.c_str())) != nullptr) {
        while ((ent = readdir(dir)) != nullptr) {
            if (strcmp(ent->d_name, ".") != 0 && strcmp(ent->d_name, "..") != 0) {
                std::string subDirPath = dirPath + "/" + ent->d_name;
                struct stat st;
                if (stat(subDirPath.c_str(), &st) == 0 && (st.st_mode & S_IFDIR)) {
                    if (subDirPath > maxSubDir) {
                        maxSubDir = subDirPath;
                    }
                }
            }
        }
        closedir(dir);
    }

    return maxSubDir;
}

bool DictionaryReader::run() {
    HILOG_APP(INFO) << "start load dict";
    while (true) {
        newDictionary = std::make_shared<std::unordered_map<std::string, DictionaryWithMaxDir>>();

        int result = loadConfig();
        if (result != 0) {
            HILOG_APP(ERROR) << "Error loading configuration.";
            std::this_thread::sleep_for(std::chrono::seconds(timerInterval));
            continue;
        }
        std::vector<std::string> update_dic_name_vec;

        for (const auto& config : configVector) {
            std::string dictionaryName = config.dictionaryName;
            std::string dictionaryPath = config.dictionaryPath;
            std::string dictionaryType = config.dictionaryType;
            DictionaryMap dictionaryMap = InitializeMap(dictionaryType);
            bool flag = false; //记录是否为某个字段的第一次更新
            // 获取当前的最大子目录
            std::string currentMaxSubDir = getMaxSubDirectory(dictionaryPath);
            HILOG_APP(ERROR)<<"get Max dir: "<<currentMaxSubDir<<std::endl;
            newDictionary->insert(std::make_pair(dictionaryName, DictionaryWithMaxDir{std::make_shared<DictionaryMap>(dictionaryMap), currentMaxSubDir}));

            // 检查最大子目录是否发生变化
            if (activeDictionary && activeDictionary->count(dictionaryName) > 0) {
                if ((*activeDictionary)[dictionaryName].maxSubDir != currentMaxSubDir) {
                    HILOG_APP(ERROR) << "Max subdirectory has changed. update for dictionary: " << dictionaryName;
                    flag = true;
                }
                else HILOG_APP(ERROR)<<"Skip update!"<<std::endl;
            }

            int result = readDirectory(config, *(*newDictionary)[dictionaryName].dictionaryMap);
            if (result != 0) {
                // 如果读取失败，则保留旧的字典内容
                newDictionary->erase(dictionaryName);
                // 从旧的字典中复制旧的条目到新的字典
                if (activeDictionary && activeDictionary->count(dictionaryName) > 0) {
                    (*newDictionary)[dictionaryName] = (*activeDictionary)[dictionaryName];
                }
                // 可以选择记录日志或进行其他错误处理
                HILOG_APP(ERROR) << "Error reading directory for dictionary: " << dictionaryName;
            }

            if (flag) //字典更新且不是首次更新，则做item embedding
            {
                update_dic_name_vec.push_back(dictionaryName);
            }
            HILOG_APP(INFO) << "load dict over";
        }
        //修改指向当前词典内容的shared_ptr 需要上读锁
        {
            std::unique_lock<std::shared_mutex> lock(rwMutex);
            activeDictionary = newDictionary;
            _load_ready.store(true);
            HILOG_APP(ERROR) << "更新词典";
        }

        for (const auto dic: update_dic_name_vec) {
            notifyUpdate(dic);
            HILOG_APP(ERROR) << "dict update, proceed item embedding";
        }
        update_dic_name_vec.clear();
        std::this_thread::sleep_for(std::chrono::seconds(timerInterval));
    }
    return true;
}

bool checkSuccessFileExists(const std::string& dirPath) {
    DIR* dir = opendir(dirPath.c_str());
    if (dir == nullptr) {
        return false;
    }

    dirent* ent;
    while ((ent = readdir(dir)) != nullptr) {
        if (strcmp(ent->d_name, "SUCCESS") == 0) {
            closedir(dir);
            return true;
        }
    }

    closedir(dir);
    return false;
}
int DictionaryReader::readDirectory(DictionaryConfig config, DictionaryMap& dictionary) {
    std::string dirPath = config.dictionaryPath;
    std::string kvSplitor = config.kvSplitter;
    std::string valueSplitor = config.valueSplitter;
    HILOG_APP(ERROR) << "Reading directory: " << dirPath;

    // 获取所有子目录
    std::string maxSubDir = getMaxSubDirectory(dirPath);

    // 校验目录中是否存在_SUCCESS文件
    bool hasSuccessFile = checkSuccessFileExists(maxSubDir);
    if (!hasSuccessFile) {
        HILOG_APP(ERROR) << "No SUCCESS file found in the largest subdirectory." << maxSubDir;
        return 1;
    }

    int item_sum = 0;
    if (!maxSubDir.empty()) {

        // 遍历最大子目录中的所有文件
        DIR* dir;
        struct dirent* ent;
        if ((dir = opendir(maxSubDir.c_str())) != nullptr) {
            while ((ent = readdir(dir)) != nullptr) {
                if (strcmp(ent->d_name, ".") != 0 && strcmp(ent->d_name, "..") != 0 && strcmp(ent->d_name, "SUCCESS") != 0) {
                    std::string filePath = maxSubDir + "/" + ent->d_name;
                    struct stat st;
                    if (stat(filePath.c_str(), &st) == 0) {
                        if (st.st_mode & S_IFREG) {
                            int ret = readFile(filePath, dictionary, kvSplitor, valueSplitor);
                            item_sum += ret;
                        }
                    } else {
                        HILOG_APP(ERROR) << "Failed to stat file: " << filePath;
                    }
                }
            }
            closedir(dir);
        } else {
            HILOG_APP(ERROR) << "Failed to open directory: " << maxSubDir;
            return 2;
        }
        HILOG_APP(ERROR) << "Processing largest subdirectory: " << maxSubDir << ",item sum: "<< item_sum;
    } else {
        HILOG_APP(ERROR) << "No subdirectories found.";
        return 3;
    }
    return 0;
}

int DictionaryReader::readFile(const std::string& filePath, DictionaryMap& dictionary, const std::string& kvSplitor, const std::string& valueSplitor) {
    std::ifstream file(filePath);

    // 添加打开文件前的调试信息
    //std::cerr << "Attempting to open file: " << filePath << std::endl;
    int item_num = 0;
    if (file.is_open()) {
        std::string line;
        int lineNumber = 0;

        //std::cerr << "Successfully opened file: " << filePath << std::endl;

        while (std::getline(file, line)) {
            lineNumber++;

            //std::cerr << "Processing line number: " << lineNumber << ", content: \"" << line << "\"" << std::endl;

            std::istringstream iss(line);
            std::string key, rawValue;

            auto delimiterPos = line.find(kvSplitor);

            if (delimiterPos != std::string::npos) {
                key = line.substr(0, delimiterPos);
                rawValue = line.substr(delimiterPos + kvSplitor.size());
                // 如果从文件读取的value收尾存在双引号，则需要把双引号删除
                std::string value = trimQuotes(rawValue);
                if (!value.empty() && value.front() == '"' && value.back() == '"') {
                    value = value.substr(1, value.size() - 2);
                }
                item_num++;
                //std::cerr << "Inserting key: " << key << ", value: " << value << " into dictionary." << std::endl;

                insertIntoDictionary(dictionary, key, value, valueSplitor);
            } else {
                HILOG_APP(ERROR) << "Invalid line format at line number: " << lineNumber << " in file: " << filePath;
            }
        }

        file.close();
        return item_num;
        //HILOG_APP(ERROR) << "read file name: "<<filePath<<", item num: "<<item_num;
        //std::cerr << "Closed file: " << filePath << std::endl;
    } else {
        HILOG_APP(ERROR) << "Unable to open file: " << filePath;
        return 0;
    }
}

void split_recursive(const std::string& src, std::vector<std::string>& out, 
                    size_t start_pos = 0, char delim = ',') 
{
    size_t pos = src.find(delim, start_pos);
    out.emplace_back(trimQuotes(src.substr(start_pos, pos - start_pos)));
    
    if (pos != std::string::npos) {
        split_recursive(src, out, pos + 1, delim); // 传递新起始位置
    }
}


void DictionaryReader::insertIntoDictionary(DictionaryMap& dictionary, const std::string& key, const std::string& value, const std::string& valueSplitor) {
    std::visit(
        [&key, &value, &valueSplitor](auto& map) {
            using MapType = std::decay_t<decltype(map)>;
            if constexpr (std::is_same_v<MapType, std::unordered_map<std::string, DictionaryInfo>>) {
                //原始ctr 词典
                std::vector<std::string> fields;
                fields.reserve(3);
                split_recursive(value,fields);

                DictionaryInfo info;
                info.package_name = fields.at(0);
                if (info.package_name.empty()) {
                    HILOG_APP(INFO) << "Empty package name for key: " << key;
                }

                //bid
                try {
                    info.bid = std::stof(fields.at(1));
                } catch (const std::exception &e) {
                    HILOG_APP(ERROR) << "Bid conversion failed, use default 0. Key: " << key << ", Error: " << e.what();
                    info.bid = 0.0;//默认值
                }

                //ad_bid
                if (fields.size() > 2) {
                    try {
                        info.ad_bid = std::stof(fields.at(2));
                    } catch (const std::exception &e) {
                        HILOG_APP(ERROR) << "AdBid conversion failed, use default 0. Key: " << key
                                         << ", Error: " << e.what();
                        info.ad_bid = 0.0;//默认值
                    }
                } else {
                    HILOG_APP(WARNING) << "fields.size() <= 2, info.ad_bid: " << info.ad_bid;
                }

                map[key] = info;
            }
            else if constexpr (std::is_same_v<MapType, std::unordered_map<std::string, CvrDictionaryInfo>>){
                //cvr 词典
                std::vector<std::string> fields;
                fields.reserve(2);
                split_recursive(value,fields);

                CvrDictionaryInfo info;

                //提取并验证package_name
                info.package_name = fields[0];
                if (info.package_name.empty()) {
                    HILOG_APP(INFO) << "Empty package name for key: " << key;
                }

                //ocpx_sbp解析
                try {
                    info.ocpx_sbp = std::stof(fields[1]);
                } catch (const std::exception &e) {
                    HILOG_APP(ERROR) << "ocpx_sbp conversion failed, use default 0. Key: " << key << ", Error: " << e.what();
                    info.ocpx_sbp = 0.0;//默认值
                }

                map[key] = info;//仅当package有效时才插入
            }
            else if constexpr (std::is_same_v<MapType, std::unordered_map<std::string, std::vector<std::string>>> || std::is_same_v<MapType, std::unordered_map<int, std::vector<std::string>>>) {
                std::vector<std::string> values;
                size_t start = 0;
                size_t end = value.find(valueSplitor);
                while (end != std::string::npos) {
                    std::string subValue = trimQuotes(value.substr(start, end - start));
                    values.push_back(subValue);
                    start = end + valueSplitor.size();
                    end = value.find(valueSplitor, start);
                }
                std::string subValue = trimQuotes(value.substr(start));
                values.push_back(subValue);
                if constexpr (std::is_same_v<MapType, std::unordered_map<int, std::vector<std::string>>>) {
                    int intKey = std::stoi(key);
                    map[intKey] = values;
                } else {
                    map[key] = values;
                }
            } else if constexpr (std::is_same_v<MapType, std::unordered_map<std::string, int>>) {
                int intValue = std::stoi(value);
                map[key] = intValue;
            } else if constexpr (std::is_same_v<MapType, std::unordered_map<std::string, std::string>>) {
                map[key] = value;
            } else if constexpr (std::is_same_v<MapType, std::unordered_map<int, std::string>>) {
                int intKey = std::stoi(key);
                map[intKey] = value;
            } else if constexpr (std::is_same_v<MapType, std::unordered_map<int, int>>) {
                int intKey = std::stoi(key);
                int intValue = std::stoi(value);
                map[intKey] = intValue;
            }
        },
        dictionary
    );
}



void printDictionaryMap(const DictionaryMap& dictionaryMap) {
    std::visit([](auto&& arg) {
        using T = std::decay_t<decltype(arg)>;
        if constexpr (std::is_same_v<T, std::unordered_map<std::string, DictionaryInfo>>) {
            //TODO
        }
        else if constexpr (std::is_same_v<T, std::unordered_map<std::string, CvrDictionaryInfo>>) {
            //TODO
        }
        else if constexpr (std::is_same_v<T, std::unordered_map<std::string, std::vector<std::string>>>) {
            for (const auto& [key, values] : arg) {
                std::cout << key << ": ";
                for (const auto& value : values) {
                    std::cout << value << ", ";
                }
                std::cout << std::endl;
            }
        } else if constexpr (std::is_same_v<T, std::unordered_map<int, std::vector<std::string>>>) {
            for (const auto& [key, values] : arg) {
                std::cout << key << ": ";
                for (const auto& value : values) {
                    std::cout << value << ", ";
                }
                std::cout << std::endl;
            }
        } else {
            for (const auto& [key, value] : arg) {
                std::cout << key << ": " << value << std::endl;
            }
        } 
    }, dictionaryMap);
}
void DictionaryReader::printActiveDictionary() {
    HILOG_APP(INFO) << "Active Dictionary:";
    if (!activeDictionary) {
        HILOG_APP(ERROR) << "Active dictionary is empty or not initialized.";
        return;
    }
    HILOG_APP(INFO) << "activeDictionary size = " << activeDictionary->size();
    for (const auto& [key, dictMapPtr] : *activeDictionary) {
        HILOG_APP(ERROR) << "Dictionary: " << key;
        if (dictMapPtr.dictionaryMap) {
            printDictionaryMap(*dictMapPtr.dictionaryMap);
        } else {
            std::cout << "  (null dictionary map)";
        }
    }
}

std::string unescapeString(const std::string &input) {
    std::string result;

    bool isEscape = false;
    for (auto it = input.begin(); it != input.end(); ++it) {
        if (*it == '\\') {
            isEscape = true;
            continue;
        }

        if (isEscape) {
            switch (*it) {
                case 't': result += '\t'; break;
                case 'n': result += '\n'; break;
                case 'r': result += '\r'; break;
                case 'b': result += '\b'; break;
                case 'f': result += '\f'; break;
                case '"': result += '\"'; break;
                case '\'': result += '\''; break;
                case '\\': result += '\\'; break;
                default:
                    // If the character after \ is not recognized,
                    // just add the original backslash and the unrecognized char
                    result += '\\';
                    result += *it;
            }
            isEscape = false;
        } else {
            result += *it;
        }
    }

    return result;
}
int DictionaryReader::loadConfig() {
    XMLDocument doc;
    XMLError e = doc.LoadFile("conf/dict_config.xml");

    // 增加加载XML文件结果的日志
    if (e != XML_SUCCESS) {
        HILOG_APP(ERROR) << "Failed to load XML file: " << doc.ErrorStr();
        return -1;
    } else {
        HILOG_APP(INFO) << "XML file loaded successfully.";
    }

    // 加载计时器间隔
    XMLElement* timerElement = doc.FirstChildElement("timerInterval");
    if (timerElement) {
        try {
            timerInterval = std::stoi(timerElement->GetText());
            HILOG_APP(INFO) << "Timer Interval set to: " << timerInterval;
        } catch (const std::invalid_argument&) {
            HILOG_APP(ERROR) << "Invalid argument for timer interval.";
            return -1;
        } catch (const std::out_of_range&) {
            HILOG_APP(ERROR) << "Out of range exception for timer interval.";
            return -1;
        }
    } else {
        HILOG_APP(ERROR) << "'timerInterval' element not found.";
    }

    XMLElement* root = doc.FirstChildElement("dictionary");
    if (root == nullptr) {
        HILOG_APP(ERROR) << "Root element 'dictionary' not found.";
        return -1;
    }
    // 清除之前的配置
    configVector.clear();
    HILOG_APP(INFO)<< "Clearing previous configuration data.";

    // 遍历所有 'item' 元素
    for (XMLElement* item = root->FirstChildElement("item"); item != nullptr; item = item->NextSiblingElement("item")) {
        DictionaryConfig dictConfig;
        XMLElement* nameElem = item->FirstChildElement("dictionaryName");
        dictConfig.dictionaryName = nameElem ? nameElem->GetText() : "";

        XMLElement* typeElem = item->FirstChildElement("dictionaryType");
        dictConfig.dictionaryType = typeElem ? typeElem->GetText() : "";

        XMLElement* pathElem = item->FirstChildElement("dictionaryPath");
        dictConfig.dictionaryPath = pathElem ? pathElem->GetText() : "";

        XMLElement* kvSplitterElem = item->FirstChildElement("kvSplitter");
        dictConfig.kvSplitter = kvSplitterElem ? unescapeString(kvSplitterElem->GetText()) : "\t";

        XMLElement* valueSplitterElem = item->FirstChildElement("valueSplitter");
        dictConfig.valueSplitter = valueSplitterElem ? unescapeString(valueSplitterElem->GetText()) : ",";

        HILOG_APP(INFO) << "Adding new dictionary configuration:";
        HILOG_APP(ERROR) << "  Dictionary Name: " << dictConfig.dictionaryName << ",Dictionary Type: " << dictConfig.dictionaryType 
        <<",Dictionary Path: " << dictConfig.dictionaryPath << ",KV Splitor: " << dictConfig.kvSplitter <<",Value Splitor: " 
        << dictConfig.valueSplitter;

        configVector.push_back(dictConfig);
    }

    return 0;
}


DictionaryMap DictionaryReader::InitializeMap(const std::string& dictionaryType) {
    auto it = mapCreators.find(dictionaryType);
    if (it != mapCreators.end()) {
        return it->second();
    } else {
        throw std::runtime_error("Unsupported dictionary type");
    }
}