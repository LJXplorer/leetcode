#include <iostream>
#include <thread>
#include <chrono>
#include "dictionary_reader.h"

int main() {
    DictionaryReader& reader = DictionaryReader::getInstance();
    reader.start();

    // for (int i=0; i<120; i++) {
    //     std::this_thread::sleep_for(std::chrono::seconds(1));
    //     reader.printActiveDictionary();
    //     std::this_thread::sleep_for(std::chrono::seconds(30));
    // }

    // std::string test1Result;
    // std::cout << "errcode:" << reader.lookup<std::string, std::string>("test1", "1", test1Result) << std::endl;
    // std::cout << test1Result << std::endl;

    // std::string test2Result;
    // std::cout << "errcode:" << reader.lookup<int, std::string>("test2", 235, test2Result) << std::endl;
    // std::cout << test2Result << std::endl;

    // std::vector<std::string> test4Result;
    // std::cout << "errcode:" << reader.lookup<std::string, std::vector<std::string>>("test4", "1", test4Result) << std::endl;
    // std::cout << test4Result[0] << std::endl;

    // std::map<std::string, std::vector<std::string>> test4MapResult;
    // std::cout << "errcode:" << reader.lookupAll<std::string, std::vector<std::string>>("test4", test4MapResult) << std::endl;
    // std::cout << test4MapResult["1"][0] << std::endl;

    std::vector<std::string> test3Result;
    // std::cout << "errcode:" << reader.lookup<std::string, std::vector<std::string>>("test3", "0bb3ae0a43aa43f38805e8f6271e4a75", test3Result) << std::endl;
    // std::cout << test3Result[0] << std::endl;
    return 0;
}

