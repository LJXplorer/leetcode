#ifndef ERROR_CODES_HPP
#define ERROR_CODES_HPP

namespace ErrorCode {

// Success code
const int SUCCESS = 0;

// General failure code
const int FAILURE = -1;

// Specific error codes
const int DICT_NOT_FOUND = 1;      // Dictionary not found
const int MAP_IS_NULL = 2;         // Map pointer is null
const int KEY_NOT_FOUND = 3;       // Key was not found in the dictionary
const int TYPE_MISMATCH = 4;       // Type mismatch between expected and actual data types
const int DICT_IS_EMPTY = 5;       // ActiveDictionary is empty

}

#endif // ERROR_CODES_HPP