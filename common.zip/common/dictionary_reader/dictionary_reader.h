#ifndef FILE_DICTIONARY_READER_H
#define FILE_DICTIONARY_READER_H

#include <iostream>
#include <memory>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <string>
#include <filesystem>
#include <shared_mutex>
#include <mutex>
#include <atomic>
#include <any>
#include <thread>
#include <chrono>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <vector>
#include <algorithm>
#include <cstring>
#include "tinyxml2.h"
#include "error_code.h"
#include <variant>
#include <map>
#include <functional>
#include <log_helper.h>

using namespace tinyxml2;

struct DictionaryInfo {
    std::string package_name;
    float bid;//原粗排逻辑中使用的bid，乘上了pcvr
    float ad_bid;//个性化cvr模型 新增的原始出价信息
    DictionaryInfo() : bid(0.0f),ad_bid(0.0f) {}
    std::string to_string() const {
        std::ostringstream oss;
        oss << "package_name: " << package_name << ", bid: " << bid << ", ad_bid: " << ad_bid;
        return oss.str();
    }
};

struct CvrDictionaryInfo {
    std::string package_name;
    float ocpx_sbp;//二阶段出价
    CvrDictionaryInfo() : ocpx_sbp(0.0f) {}
    std::string to_string() const {
        std::ostringstream oss;
        oss << "package_name: " << package_name << ", ocpx_sbp: " << ocpx_sbp;
        return oss.str();
    }
};

class DictionaryConfig {
public:
    std::string dictionaryName;
    std::string dictionaryType;
    std::string dictionaryPath;
    std::string kvSplitter;
    std::string valueSplitter;
};

using DictionaryMap = std::variant<
    std::unordered_map<int, std::string>,
    std::unordered_map<int, int>,
    std::unordered_map<std::string, std::vector<std::string>>,
    std::unordered_map<int, std::vector<std::string>>,
    std::unordered_map<std::string, int>,
    std::unordered_map<std::string, std::string>,
    std::unordered_map<std::string, DictionaryInfo>,
    // std::unordered_map<std::string, CtrDictionaryInfo>,
    std::unordered_map<std::string, CvrDictionaryInfo>
>;

struct DictionaryWithMaxDir {
    std::shared_ptr<DictionaryMap> dictionaryMap;
    std::string maxSubDir; // 保存当前字典读取的最大目录名
};

static const std::unordered_map<std::string, std::function<DictionaryMap()>> mapCreators = {
    {"int->string", []() -> DictionaryMap { return std::unordered_map<int, std::string>{}; }},
    {"int->int", []() -> DictionaryMap { return std::unordered_map<int, int>{}; }},
    {"string->vector(string)", []() -> DictionaryMap { return std::unordered_map<std::string, std::vector<std::string>>{}; }},
    {"int->vector(string)", []() -> DictionaryMap { return std::unordered_map<int, std::vector<std::string>>{}; }},
    {"string->string", []() -> DictionaryMap { return std::unordered_map<std::string, std::string>{}; }},
    {"string->int", []() -> DictionaryMap { return std::unordered_map<std::string, int>{}; }},
    {"string->ItemInfo",[]()-> DictionaryMap { return std::unordered_map<std::string, DictionaryInfo>{};}},
    // {"string->CtrItemInfo",[]()-> DictionaryMap {return std::unordered_map<std::string, CtrDictionaryInfo>{};}},
    {"string->CvrItemInfo",[]()-> DictionaryMap {return std::unordered_map<std::string, CvrDictionaryInfo>{};}}
};

class DictionaryReader {
public:
    static DictionaryReader& getInstance() {
        static DictionaryReader instance;
        return instance;
    }

    bool start();
    std::atomic_bool _load_ready = true;

    void printActiveDictionary();

    // template<typename KeyType, typename ValueType>
    // const ValueType* lookup(const std::string& dictionaryName, const KeyType& key,const ValueType*) {
    //     if (!activeDictionary) {
    //         HILOG_APP(ERROR) << "[ERROR] Active dictionary is empty or not initialized." << std::endl;
    //         return nullptr;
    //     }

    //     // std::cout << "Looking up key '" << key << "' in dictionary '" << dictionaryName << "'." << std::endl;

    //     auto dictIt = activeDictionary->find(dictionaryName);//找到指定名字 对应的字典
    //     if (dictIt == activeDictionary->end()) {
    //         // std::cout << "[ERROR] Dictionary not found: " << dictionaryName << std::endl;
    //         return nullptr;
    //     }

    //     const auto& dictionaryWithMaxDir = dictIt->second;//找到指定名字 对应的字典
    //     const auto& dictionaryMap = dictionaryWithMaxDir.dictionaryMap;
    //     if (!dictionaryMap) {
    //         HILOG_APP(ERROR) << "[ERROR] Dictionary map is null." << std::endl;
    //         return nullptr;
    //     }

    //     if (auto* mapPtr = std::get_if<std::unordered_map<KeyType, ValueType>>(&(*dictionaryMap))) {
    //         auto it = mapPtr->find(key);
    //         return (it != mapPtr->end()) ? &it->second : nullptr;
    //     } else {
    //         HILOG_APP(ERROR) << "Dictionary does not contain a map of the expected type." << std::endl;
    //         return nullptr;
    //     }
    // }

    int lookupAll(const std::string& dictionaryName, std::shared_ptr<DictionaryMap>& outputMap) {
        std::shared_lock lock(rwMutex);
        if (!activeDictionary) {
            HILOG_APP(ERROR) << "[ERROR] Active dictionary is empty or not initialized." << std::endl;
            return ErrorCode::DICT_IS_EMPTY;
        }

        // std::cout << "Looking up all dictionary '" << dictionaryName << "'." << std::endl;

        // 查找字典
        auto dictIt = activeDictionary->find(dictionaryName);
        if (dictIt == activeDictionary->end()) {
            HILOG_APP(ERROR) << "[ERROR] Dictionary not found: " << dictionaryName << std::endl;
            return ErrorCode::DICT_NOT_FOUND;
        }
        
        DictionaryWithMaxDir& dictionaryWithMaxDir = dictIt->second;
        outputMap = dictionaryWithMaxDir.dictionaryMap;//dictionaryMap始终非空
        lock.unlock();//已经读完
        return ErrorCode::SUCCESS;
    }

        // 字典更新回调
    using UpdateCallback = std::function<void(const std::string&)>;

    // 注册回调函数
    void registerUpdateCallback(UpdateCallback callback) {
        std::lock_guard<std::mutex> lock(mtx);
        HILOG_APP(ERROR)<<"Register callback functions"<<std::endl;
        updateCallbacks.push_back(callback);
    }

private:
    DictionaryReader() {
        activeDictionary = std::make_shared<std::unordered_map<std::string, DictionaryWithMaxDir>>();
        // newDictionary = std::make_shared<std::unordered_map<std::string, DictionaryWithMaxDir>>();
    }
    // 正在使用的字典对象
    std::shared_ptr<std::unordered_map<std::string, DictionaryWithMaxDir>> activeDictionary;

    // 刷新字典时使用的字典对象
    std::shared_ptr<std::unordered_map<std::string, DictionaryWithMaxDir>> newDictionary;

    // 字典名与字典要扫描的路径
    std::vector<DictionaryConfig> configVector;

    // 锁
    std::mutex mtx;

    //读写锁，用于new和active交换时保证读写任务的线程安全
    std::shared_mutex rwMutex;

    // 默认刷新时间，可从配置文件修改
    int timerInterval = 600;

    // 默认配置文件路径
    std::string configFilePath = "config.xml";

    // 读取目录
    int readDirectory(const DictionaryConfig config, DictionaryMap& dictionary);

    // 读取字典文件
    int readFile(const std::string& filePath, DictionaryMap& dictionary, const std::string& kvSplitor, const std::string& valueSplitor);

    bool run();

    int loadConfig();

    DictionaryMap InitializeMap(const std::string& dictionaryType);

    void insertIntoDictionary(DictionaryMap& dictionary, const std::string& key, const std::string& value, const std::string& valueSplitor);

    // 存储回调函数
    std::vector<UpdateCallback> updateCallbacks;

    // 在字典更新时调用回调
    void notifyUpdate(const std::string &dictionaryName) {
        std::lock_guard<std::mutex> lock(mtx);
        for (const auto &callback: updateCallbacks) {
            try {
                callback(dictionaryName);
            } catch (const std::exception &e) {
                HILOG_APP(ERROR) << "Callback failed: " << e.what();
            }
        }
    }
};

#endif // FILE_DICTIONARY_READER_H