#ifndef __CACHEHELPER_H_
#define __CACHEHELPER_H_

#include <iostream>
#include <string>
#include <boost/container/flat_map.hpp>
#include <chrono>
#include <thread>
#include <tinyxml2.h>
#include <google/protobuf/message.h>
#include <thread>
#include <brpc/redis.h>

#include "common/comm/double_buffer.h"

namespace hicache {
    using namespace std;
    using namespace boost;
    using namespace tinyxml2;
    using namespace google;
    using namespace brpc;

    //缓存
    class CacheInstance {
        private:
            std::string _name;
            std::shared_ptr<DBuffer<boost::container::flat_map<std::string, std::shared_ptr<google::protobuf::Message>>>> _double_buffer;

        public: 
            explicit CacheInstance(const tinyxml2::XMLElement& cacheConf) {
                //获取配置中cache的名字
                _name = cacheConf.Attribute("name");
            }
            ~CacheInstance();

            const std::string& getName() const;
            std::shared_ptr<google::protobuf::Message> find(const std::string& key) {
                auto it = _double_buffer->get_current_obj()->find(key);
                if(it != _double_buffer->get_current_obj()->end()) {
                    return it->second;
                }
                return nullptr;
            }

            bool insert(const std::string& key, std::shared_ptr<google::protobuf::Message> value) {
                try {
                     _double_buffer->get_current_obj()->insert_or_assign(key, value);
                     return true;
                } catch(...) {
                    return false;
                }                          
            }

            void swapPtr() {
               _double_buffer->change();
            }

            bool deleteKey(const std::string& key) {
                try {
                     _double_buffer->get_current_obj()->erase(key);
                     return true;
                } catch(...) {
                    return false;
                }
            }

            void refresh() {
                this->swapPtr();
                std::this_thread::sleep_for(std::chrono::seconds(10));
            }

            bool getBackUpPtr(std::shared_ptr<boost::container::flat_map<std::string, std::shared_ptr<google::protobuf::Message>>> backPtr) {
                backPtr = _double_buffer->get_bak_obj();
                if (backPtr) {
                    return true;
                }
                return false;
            }
    };

    //缓存处理
    class CacheHelper {
        private:
            std::shared_ptr<boost::container::flat_map<std::string, std::shared_ptr<hicache::CacheInstance>>> _cache_pool;

        public:
            CacheHelper() = default; 
            CacheHelper(const tinyxml2::XMLDocument& cacheConf){
                const tinyxml2::XMLElement* rootElement = cacheConf.FirstChildElement();
                for (const tinyxml2::XMLElement* child = rootElement->FirstChildElement(); child != nullptr; child = child->NextSiblingElement()) {
                    string name = child->Attribute("name");
                    addCache(name, CacheInstance(*child));
                }
            }
            ~CacheHelper();
            static CacheHelper& getInstance() {
                static CacheHelper instance;
                return instance;
            }
            void addCache(const string cacheName, const CacheInstance& cacheInstance) {
                 _cache_pool->operator[](cacheName) = std::make_shared<hicache::CacheInstance>(cacheInstance);
            }
            
            std::shared_ptr<google::protobuf::Message> get(const string& cacheName, const string& key) {
                auto it = _cache_pool->find(cacheName);
                if(it != _cache_pool->end()) {
                    return it->second->find(key);
                }
                return nullptr;
            }

            bool set(const string& cacheName, const string& key, const std::shared_ptr<google::protobuf::Message>& value) {
                auto it = _cache_pool->find(cacheName);
                if(it != _cache_pool->end()) {
                    return it->second->insert(key, value);
                }
                return false;
            }

            bool deleteKey(const string& cacheName, const string& key) {
                auto it = _cache_pool->find(cacheName);
                if(it != _cache_pool->end()) {
                    return it->second->deleteKey(key);
                }
                return false;
            }

            bool refreshCache(const string& cacheName) {
                auto it = _cache_pool->find(cacheName);
                if(it != _cache_pool->end()) {
                    it->second->refresh();
                    return true;
                }
                return false;
            }

            bool getCacheBackUpPtr(const string& cacheName, std::shared_ptr<boost::container::flat_map<std::string, std::shared_ptr<google::protobuf::Message>>>& backUpPtr) {
                auto it = _cache_pool->find(cacheName);
                if(it != _cache_pool->end()) {
                    return it->second->getBackUpPtr(backUpPtr);
                }
                return false;
            }
    };

};

#endif
