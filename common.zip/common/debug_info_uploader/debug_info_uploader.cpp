#include "common/debug_info_uploader/debug_info_uploader.h"

LogUploader* LogUploader::instance_ = nullptr;