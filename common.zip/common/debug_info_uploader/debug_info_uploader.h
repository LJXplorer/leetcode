#pragma once

#include "common/hilog/log_helper.h"
#include "common/tencent_cos_client/tencent_cos.h"
#include <atomic>
#include <chrono>
#include <ctime>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <json2pb/pb_to_json.h>
#include <log_helper.h>
#include <memory>
#include <random>
#include <sstream>
#include <string>

namespace fs = std::filesystem;

class DebugInfoWriter {
public:
    DebugInfoWriter(const std::string &reqid, const std::string &prefix, const std::string &file_type)
        : reqid_(reqid), target_prefix_(prefix), file_type_(file_type) {
    }

    std::string writeDebugInfo(const std::string &content) {
        // 获取当前时间
        auto now = std::chrono::system_clock::now();
        std::time_t now_c = std::chrono::system_clock::to_time_t(now);
        std::tm *now_tm = std::localtime(&now_c);

        // 生成秒级别时间戳
        std::string timestamp = generateTimestamp(now_tm);

        // 创建目录
        fs::path dirPath = fs::path("debug_info") / reqid_ / timestamp;// reqid 文件夹下的时间戳子文件夹
        fs::create_directories(dirPath);                               // 创建多级目录

        // 生成唯一文件名
        std::string filename = generateUniqueFilename(now_tm);
        // std::cout << "生成唯一文件名:" << filename << std::endl;

        // 写入文件
        fs::path filePath = dirPath / filename;// 在时间戳文件夹下写入文件
        std::ofstream debugFile(filePath);     // 确保包含 <fstream> 头文件
        if (debugFile.is_open()) {
            debugFile << content;
            debugFile.close();
            // std::cout << "Debug info written to: " << filePath << std::endl;
            HILOG_APP(INFO) << "Debug info written to: " << filePath;
            return filePath.string();// 返回实际文件路径
        } else {
            // std::cerr << "Failed to create debug info file." << std::endl;
            HILOG_APP(ERROR) << "Failed to create debug info file.";
            return "";// 返回空字符串表示失败
        }
    }

    std::string writeDebugInfo(const std::string &content, const std::string &req_time) {

        // 创建目录
        fs::path dirPath = fs::path("debug_info") / reqid_ / req_time;// reqid 文件夹下的时间戳子文件夹
        fs::create_directories(dirPath);                              // 创建多级目录

        // 生成唯一文件名
        std::string filename = generateUniqueFilename(req_time);
        // std::cout << "生成唯一文件名:" << filename << std::endl;

        // 写入文件
        fs::path filePath = dirPath / filename;// 在时间戳文件夹下写入文件
        std::ofstream debugFile(filePath);     // 确保包含 <fstream> 头文件
        if (debugFile.is_open()) {
            debugFile << content;
            debugFile.close();
            // std::cout << "Debug info written to: " << filePath << std::endl;
            HILOG_APP(INFO) << "Debug info written to: " << filePath;
            return filePath.string();// 返回实际文件路径
        } else {
            // std::cerr << "Failed to create debug info file." << std::endl;
            HILOG_APP(ERROR) << "Failed to create debug info file.";
            return "";// 返回空字符串表示失败
        }
    }

    std::string writeDebugInfo(const google::protobuf::Message &message) {
        HILOG_APP(INFO) << "writeDebugInfo start";
        // std::cout << "writeDebugInfo start" << std::endl;
        std::string data, err;
        json2pb::Pb2JsonOptions opt;
        opt.bytes_to_base64 = false;
        json2pb::ProtoMessageToJson(message, &data, opt, &err);
        HILOG_APP(INFO) << "writeDebugInfo end";
        // std::cout << "writeDebugInfo end" << std::endl;
        return writeDebugInfo(data);
    }

    std::string writeDebugInfo(const google::protobuf::Message &message, const std::string &req_time) {
        HILOG_APP(INFO) << "writeDebugInfo start";
        // std::cout << "writeDebugInfo start" << std::endl;
        std::string data, err;
        json2pb::Pb2JsonOptions opt;
        opt.bytes_to_base64 = false;
        json2pb::ProtoMessageToJson(message, &data, opt, &err);
        HILOG_APP(INFO) << "writeDebugInfo end";
        // std::cout << "writeDebugInfo end" << std::endl;
        return writeDebugInfo(data, req_time);
    }

    std::string writePbDebugInfo(const google::protobuf::Message &message) {
        // 获取当前时间
        auto now = std::chrono::system_clock::now();
        std::time_t now_c = std::chrono::system_clock::to_time_t(now);
        std::tm *now_tm = std::localtime(&now_c);

        // 生成秒级别时间戳
        std::string timestamp = generateTimestamp(now_tm);

        // 创建目录
        fs::path dirPath = fs::path("debug_info") / reqid_ / timestamp;
        fs::create_directories(dirPath);

        // 生成唯一文件名
        std::string filename = generateUniqueFilename(now_tm);
        // std::cout << "生成唯一文件名:" << filename << std::endl;

        // 写入文件
        fs::path filePath = dirPath / filename;
        std::ofstream debugFile(filePath, std::ios::binary);
        if (!message.SerializeToOstream(&debugFile)) {
            std::cerr << "Failed to write protobuf message" << std::endl;
            HILOG_APP(ERROR) << "Failed to write protobuf message";
            return "";
        } else {
            // std::cout << "Protobuf message written to: " << filePath.string() << std::endl;
            HILOG_APP(INFO) << "Protobuf message written to: " << filePath.string();
            return filePath.string();
        }
    }

    std::string writePbDebugInfo(const google::protobuf::Message &message, const std::string &req_time) {

        // 创建目录
        fs::path dirPath = fs::path("debug_info") / reqid_ / req_time;
        fs::create_directories(dirPath);

        // 生成唯一文件名
        std::string filename = generateUniqueFilename(req_time);
        // std::cout << "生成唯一文件名:" << filename << std::endl;

        // 写入文件
        fs::path filePath = dirPath / filename;
        std::ofstream debugFile(filePath, std::ios::binary);
        if (!message.SerializeToOstream(&debugFile)) {
            std::cerr << "Failed to write protobuf message" << std::endl;
            HILOG_APP(ERROR) << "Failed to write protobuf message";
            return "";
        } else {
            // std::cout << "Protobuf message written to: " << filePath.string() << std::endl;
            HILOG_APP(INFO) << "Protobuf message written to: " << filePath.string();
            return filePath.string();
        }
    }

private:
    static std::string generateTimestamp(std::tm *now_tm) {
        // 格式化时间戳为字符串
        std::ostringstream oss;
        oss << std::setw(4) << now_tm->tm_year + 1900 << std::setw(2) << std::setfill('0') << now_tm->tm_mon + 1
            << std::setw(2) << std::setfill('0') << now_tm->tm_mday << "_" << std::setw(2) << std::setfill('0')
            << now_tm->tm_hour << std::setw(2) << std::setfill('0') << now_tm->tm_min << std::setw(2)
            << std::setfill('0') << now_tm->tm_sec;
        return oss.str();
    }

    std::string generateUniqueFilename(std::tm *now_tm) {
        // 生成随机数
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<uint64_t> uid_distribution(1, std::numeric_limits<uint64_t>::max());

        // 格式化时间戳
        std::ostringstream oss;
        oss << std::setw(4) << now_tm->tm_year + 1900 << std::setw(2) << std::setfill('0') << now_tm->tm_mon + 1
            << std::setw(2) << std::setfill('0') << now_tm->tm_mday << "_" << std::setw(2) << std::setfill('0')
            << now_tm->tm_hour << std::setw(2) << std::setfill('0') << now_tm->tm_min << std::setw(2)
            << std::setfill('0') << now_tm->tm_sec;

        // 生成文件名
        std::string filename =
                target_prefix_ + "_" + oss.str() + "_" + std::to_string(uid_distribution(gen)) + "." + file_type_;
        return filename;
    }

    std::string generateUniqueFilename(const std::string &req_time) {
        // 生成随机数
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<uint64_t> uid_distribution(1, std::numeric_limits<uint64_t>::max());

        // 生成文件名
        std::string filename =
                target_prefix_ + "_" + req_time + "_" + std::to_string(uid_distribution(gen)) + "." + file_type_;
        return filename;
    }

    std::string reqid_;
    std::string target_prefix_;
    std::string file_type_;
};

class LogUploader {
private:
    LogUploader(const std::string &cos_client_config_path, const std::string &bucket_name,
                const std::string &path_prefix, uint64_t expiration_days)
        : bucket_name_(bucket_name), path_prefix_(path_prefix), expiration_days_(expiration_days), stop_flag_(false) {
        try {
            cos_client_ptr_ = std::make_shared<TencentCOSClient>(cos_client_config_path);
            checkAndSetLifecycleRules();
            startCleanupThread();// 启动定期清理本地文件线程
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "Debug info COS init failed: " << e.what();
        }
    }

    ~LogUploader() {
        stop_flag_ = true;// 设置停止标志
        if (cleanup_thread_.joinable()) {
            cleanup_thread_.join();// 等待线程结束
        }
    }

public:
    void checkAndSetLifecycleRules() {
        // 查询当前生命周期规则
        auto rules = cos_client_ptr_->getBucketLifecycle(bucket_name_);

        // 检查是否存在指定前缀的生命周期规则
        bool hasLifecycleRule = false;
        for (const auto &rule: rules) {
            if (rule.GetFilter().GetPrefix() == path_prefix_ && rule.GetExpiration().GetDays() == expiration_days_) {
                hasLifecycleRule = true;
                break;
            }
        }

        // 如果没有规则，则设置新的生命周期规则
        if (!hasLifecycleRule) {
            qcloud_cos::LifecycleRule new_rule;
            new_rule.SetIsEnable(true);

            qcloud_cos::LifecycleFilter filter;
            filter.SetPrefix(path_prefix_);
            new_rule.SetFilter(filter);

            qcloud_cos::LifecycleExpiration life_expiration;
            life_expiration.SetDays(expiration_days_);

            new_rule.SetExpiration(life_expiration);

            if (cos_client_ptr_->setBucketLifecycle(bucket_name_, {new_rule})) {
                std::cout << "Lifecycle rule set for prefix: " << path_prefix_ << std::endl;
                HILOG_APP(INFO) << "Lifecycle rule set for prefix: " << path_prefix_;
            } else {
                std::cerr << "Failed to set lifecycle rule for prefix: " << path_prefix_ << std::endl;
                HILOG_APP(ERROR) << "Failed to set lifecycle rule for prefix: " << path_prefix_;
            }
        } else {
            std::cout << "Lifecycle rule already exists for prefix: " << path_prefix_ << std::endl;
            HILOG_APP(INFO) << "Lifecycle rule already exists for prefix: " << path_prefix_;
        }
    }

    void deleteExpiredFiles() {
        auto now = std::chrono::system_clock::now();
        auto expiration_duration = std::chrono::hours(24 * expiration_days_);

        // 检查目标前缀路径是否存在
        if (!fs::exists(path_prefix_)) {
            // std::cout << "Target prefix path does not exist: " << path_prefix_ << ". Skipping cleanup." << std::endl;
            HILOG_APP(INFO) << "Target prefix path does not exist: " << path_prefix_ << ". Skipping cleanup.";
            return;// 路径不存在，直接返回
        }

        // 遍历目标前缀下的所有文件夹
        for (const auto &entry: fs::directory_iterator(path_prefix_)) {
            if (entry.is_directory()) {
                // 获取文件夹的创建时间并转换为 system_clock::time_point
                auto folder_creation_time = fs::last_write_time(entry.path());
                auto folder_creation_time_sys = std::chrono::time_point_cast<std::chrono::system_clock::duration>(
                        folder_creation_time - std::filesystem::file_time_type::clock::now() +
                        std::chrono::system_clock::now());

                auto folder_age = now - folder_creation_time_sys;

                // 如果文件夹的年龄超过设定的过期时间，则删除该文件夹
                if (folder_age > expiration_duration) {
                    fs::remove_all(entry.path());// 递归删除文件夹及其内容
                    // std::cout << "Deleted expired folder: " << entry.path() << std::endl;
                    HILOG_APP(INFO) << "Deleted expired folder: " << entry.path();
                }
            }
        }
    }

    void startCleanupThread() {
        cleanup_thread_ = std::thread([this]() {
            while (!stop_flag_) {
                deleteExpiredFiles();                              // 删除过期文件夹
                std::this_thread::sleep_for(std::chrono::hours(1));// 每小时检查一次
            }
        });
    }

    static void init(const std::string &cos_client_config_path, const std::string &bucket_name,
                     const std::string &path_prefix, uint64_t expiration_days = 7) {
        if (!instance_) {
            instance_ = new LogUploader(cos_client_config_path, bucket_name, path_prefix, expiration_days);
        }
    }

    static LogUploader &getInstance() {
        if (!instance_) {
            throw std::runtime_error("LogUploader has not been initialized. Call init() first.");
        }
        return *instance_;
    }

    void uploadLogFile(const std::string &file_path) {
        if (file_path.empty()) {
            HILOG_APP(INFO) << "文件路径为空，跳过上传。" << std::endl;
            return;
        }
        try {
            // 上传文件到 COS
            cos_client_ptr_->uploadObject(bucket_name_, file_path, file_path);
            HILOG_APP(INFO) << "文件 " << file_path << " 上传成功。" << std::endl;
        } catch (const std::exception &e) {
            HILOG_APP(ERROR) << "上传文件 " << file_path << " 失败: " << e.what() << std::endl;
        }
    }

private:
    std::string bucket_name_;
    std::string path_prefix_;// e.g. "log/" or "debug_info/"
    uint64_t expiration_days_;
    std::shared_ptr<TencentCOSClient> cos_client_ptr_;
    std::thread cleanup_thread_;
    std::atomic<bool> stop_flag_;
    static LogUploader *instance_;
};
