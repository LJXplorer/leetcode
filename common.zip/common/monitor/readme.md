# 示例代码
```c++
#include "monitor_manager.h"
#include "monitors.h"
#include "named_monitor.h"
#include <chrono>
#include <random>
#include <thread>
void mock_monitor_data() {
  std::random_device rd; // 非确定性随机数生成器
  std::mt19937 gen(rd());
  std::uniform_int_distribution<> distrib(20, 150);

  monitor::CommonMonitor<long> common_monitor{monitor::CollectRule::GLOBAL,
                                              {"url", "algoName"},
                                              monitor::MAXER | monitor::AVGER};
  monitor::PercentileMonitor percent_monitor{monitor::CollectRule::GLOBAL,
                                             {"url", "algoName"}};
  monitor::MonitorManager::getInstance().StartDump();
  for (int i = 0; i < 360; i++) {
    int val = distrib(gen);
    if (i % 2 == 0) {
      common_monitor.push({"10.3.4.2", "sdws1s"}, "req_cost", val);
     // percent_monitor.push({"10.3.4.2", "sdws1s"}, "req_cost", val);
    } else {
      common_monitor.push({"10.3.177.83", "desf22"}, "req_cost", val);
      //percent_monitor.push({"10.3.177.83", "desf22"}, "req_cost", val);
    }
    std::this_thread::sleep_for(std::chrono::seconds(1));
  }
  std::getchar();
}

int main() {
  mock_monitor_data();
}
```