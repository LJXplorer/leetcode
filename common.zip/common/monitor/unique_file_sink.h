#pragma once

#include <chrono>
#include <ctime>
#include <iomanip>
#include <log_helper.h>
#include <mutex>
#include <random>
#include <spdlog/details/file_helper.h>
#include <spdlog/sinks/base_sink.h>
#include <spdlog/spdlog.h>
#include <sstream>
#include <string>

namespace spdlog {
    namespace sinks {

        template<typename Mutex>
        class unique_file_sink final : public base_sink<Mutex> {
        public:
            inline unique_file_sink(filename_t base_filename, std::size_t max_files,
                                    const file_event_handlers &event_handlers = {})
                : base_filename_(std::move(base_filename)), max_files_(max_files), file_helper_{event_handlers} {
            }

            static filename_t calc_filename(const filename_t &basename) {
                // 生成基于时间戳和随机数的唯一文件名
                auto now = std::chrono::system_clock::now();
                std::time_t time = std::chrono::system_clock::to_time_t(now);
                std::tm *local_time = std::localtime(&time);

                std::random_device rd;
                std::mt19937 gen(rd());
                std::uniform_int_distribution<uint64_t> uid_distribution(1, std::numeric_limits<uint64_t>::max());

                std::ostringstream oss;
                oss << basename << "_" << std::setw(4) << local_time->tm_year + 1900 << std::setw(2)
                    << std::setfill('0') << local_time->tm_mon + 1 << std::setw(2) << std::setfill('0')
                    << local_time->tm_mday << "_" << std::setw(2) << std::setfill('0') << local_time->tm_hour
                    << std::setw(2) << std::setfill('0') << local_time->tm_min << std::setw(2) << std::setfill('0')
                    << local_time->tm_sec << "_" << uid_distribution(gen) << ".json";

                return oss.str();
            }

            filename_t filename() {
                std::lock_guard<Mutex> lock(base_sink<Mutex>::mutex_);
                return file_helper_.filename();
            }

        protected:
            void sink_it_(const details::log_msg &msg) override {
                memory_buf_t formatted;
                base_sink<Mutex>::formatter_->format(msg, formatted);

                // 生成唯一文件名
                std::string filename = calc_filename(base_filename_);

                // 打开或创建新文件
                file_helper_.open(filename);
                // 将日志消息写入文件
                file_helper_.write(formatted);
                file_helper_.flush();
                file_helper_.close();
            }

            void flush_() override {
                file_helper_.flush();
            }

        private:
            filename_t base_filename_;
            std::size_t max_files_;
            details::file_helper file_helper_;
        };

        using unique_file_sink_mt = unique_file_sink<std::mutex>;
        using unique_file_sink_st = unique_file_sink<details::null_mutex>;

    }// namespace sinks

    // 工厂函数
    template<typename Factory = spdlog::synchronous_factory>
    inline std::shared_ptr<logger> unique_file_logger_mt(const std::string &logger_name, const filename_t &filename,
                                                         const file_event_handlers &event_handlers = {}) {
        return Factory::template create<sinks::unique_file_sink_mt>(logger_name, filename, event_handlers);
    }

    template<typename Factory = spdlog::synchronous_factory>
    inline std::shared_ptr<logger> unique_file_logger_st(const std::string &logger_name, const filename_t &filename,
                                                         const file_event_handlers &event_handlers = {}) {
        return Factory::template create<sinks::unique_file_sink_st>(logger_name, filename, event_handlers);
    }

}// namespace spdlog
