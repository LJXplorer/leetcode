#pragma once

#include "common/monitor/aiops_common_dumper.h"
#include "debug_utils.h"
#include <bvar/latency_recorder.h>
#include <bvar/multi_dimension.h>
#include <bvar/recorder.h>
#include <bvar/reducer.h>
#include <bvar/variable.h>
#include <bvar/window.h>
#include <glog/logging.h>
#include <iostream>
#include <log_helper.h>
#include <memory>
#include <shared_mutex>
#include <spdlog/spdlog.h>
#include <sstream>
#include <unordered_map>
namespace monitor {
constexpr long AVGER = 1;
constexpr long ADDER = 1 << 1;
constexpr long MINER = 1 << 2;
constexpr long MAXER = 1 << 3;
constexpr int kWindowsSize = 60;

struct MonitorConfig {
  std::string service_name;
  std::list<std::string> dimention_keys;
  std::string metirc_name;
  long mask;
};

template <typename T> class NamedCommonMonitor {
public:
  NamedCommonMonitor(const std::string &service_name,
                     const std::list<std::string> &dimention_keys,
                     const std::string &metrics_name, long mask)
      : dimention_keys_(dimention_keys) {
    HILOG_APP(INFO) << "NamedCommonMonitor create: service_name = "
                    << service_name << ", metrics_name = " << metrics_name
                    << ", dimention keys = "
                    // << debug_utils::ToString(dimention_keys)
                    << ", mask = " << mask;
    if (mask & ADDER) {
      adder_ = std::make_unique<
          bvar::MultiDimension<bvar::WindowEx<bvar::Adder<T>, kWindowsSize>>>(
          service_name, metrics_name + "_sum", dimention_keys);
    }

    if (mask & MINER) {
      miner_ = std::make_unique<
          bvar::MultiDimension<bvar::WindowEx<bvar::Miner<T>, kWindowsSize>>>(
          service_name, metrics_name + "_min", dimention_keys);
    }

    if (mask & MAXER) {
      maxer_ = std::make_unique<
          bvar::MultiDimension<bvar::WindowEx<bvar::Maxer<T>, kWindowsSize>>>(
          service_name, metrics_name + "_max", dimention_keys);
    }
  }

  void push(const std::list<std::string> &label, T val) {
    if (adder_.get() != nullptr) {
      auto adder_ptr = adder_->get_stats(label);
      (*adder_ptr) << val;
    }

    if (miner_.get() != nullptr) {
      auto miner_ptr = miner_->get_stats(label);
      *miner_ptr << val;
    }

    if (maxer_.get() != nullptr) {
      auto maxer_ptr = maxer_->get_stats(label);
      *maxer_ptr << val;
    }
  }

private:
  std::unique_ptr<
      bvar::MultiDimension<bvar::WindowEx<bvar::Adder<T>, kWindowsSize>>>
      adder_;
  std::unique_ptr<
      bvar::MultiDimension<bvar::WindowEx<bvar::Miner<T>, kWindowsSize>>>
      miner_;
  std::unique_ptr<
      bvar::MultiDimension<bvar::WindowEx<bvar::Maxer<T>, kWindowsSize>>>
      maxer_;
  std::list<std::string> dimention_keys_;
};

template <> class NamedCommonMonitor<long> {
public:
  NamedCommonMonitor(const std::string &service_name,
                     const std::list<std::string> &dimention_keys,
                     const std::string &metrics_name, long mask)
      : dimention_keys_(dimention_keys) {
    HILOG_APP(INFO) << "NamedCommonMonitor create: service_name = "
                    << service_name << ", metrics_name = " << metrics_name
                    << ", dimention keys = "
                    // << debug_utils::ToString(dimention_keys)
                    << ", mask = " << mask;
    if (mask & ADDER) {
      adder_ = std::make_unique<bvar::MultiDimension<
          bvar::WindowEx<bvar::Adder<long>, kWindowsSize>>>(
          service_name, metrics_name + "_sum", dimention_keys);
    }

    if (mask & MINER) {
      miner_ = std::make_unique<bvar::MultiDimension<
          bvar::WindowEx<bvar::Miner<long>, kWindowsSize>>>(
          service_name, metrics_name + "_min", dimention_keys);
    }

    if (mask & MAXER) {
      maxer_ = std::make_unique<bvar::MultiDimension<
          bvar::WindowEx<bvar::Maxer<long>, kWindowsSize>>>(
          service_name, metrics_name + "_max", dimention_keys);
    }

    if (mask & AVGER) {
      avger_ = std::make_unique<bvar::MultiDimension<
          bvar::WindowEx<bvar::IntRecorder, kWindowsSize>>>(
          service_name, metrics_name + "_avg", dimention_keys);
    }
  }

  void push(const std::list<std::string> &label, long val) {
    if (adder_.get() != nullptr) {
      auto adder_ptr = adder_->get_stats(label);
      (*adder_ptr) << val;
    }

    if (avger_.get() != nullptr) {
      auto avg_ptr = avger_->get_stats(label);
      *avg_ptr << val;
    }

    if (miner_.get() != nullptr) {
      auto miner_ptr = miner_->get_stats(label);
      *miner_ptr << val;
    }

    if (maxer_.get() != nullptr) {
      auto maxer_ptr = maxer_->get_stats(label);
      *maxer_ptr << val;
    }
  }

  void Dump(bvar::Dumper *dumper, const bvar::DumpOptions &options = {}) {
    if (adder_.get() != nullptr) {
      adder_->dump(dumper, &options);
    }

    if (avger_.get() != nullptr) {
      avger_->dump(dumper, &options);
    }

    if (miner_.get() != nullptr) {
      miner_->dump(dumper, &options);
    }

    if (maxer_.get() != nullptr) {
      maxer_->dump(dumper, &options);
    }
  }

private:
  std::unique_ptr<
      bvar::MultiDimension<bvar::WindowEx<bvar::Adder<long>, kWindowsSize>>>
      adder_;
  std::unique_ptr<
      bvar::MultiDimension<bvar::WindowEx<bvar::IntRecorder, kWindowsSize>>>
      avger_;

  std::unique_ptr<
      bvar::MultiDimension<bvar::WindowEx<bvar::Miner<long>, kWindowsSize>>>
      miner_;
  std::unique_ptr<
      bvar::MultiDimension<bvar::WindowEx<bvar::Maxer<long>, kWindowsSize>>>
      maxer_;
  std::list<std::string> dimention_keys_;
};

template <> class NamedCommonMonitor<double> {
public:
  NamedCommonMonitor(const std::string &service_name,
                     const std::list<std::string> &dimention_keys,
                     const std::string &metrics_name, long mask)
      : dimention_keys_(dimention_keys), metrics_name_(metrics_name) {

    HILOG_APP(INFO) << "NamedCommonMonitor create: service_name = "
                    << service_name << ", metrics_name = " << metrics_name
                    << ", dimention keys = "
                    // << debug_utils::ToString(dimention_keys)
                    << ", mask = " << mask;

    if (mask & ADDER) {
      adder_ = std::make_unique<bvar::MultiDimension<
          bvar::WindowEx<bvar::Adder<double>, kWindowsSize>>>(
          service_name, metrics_name + "_sum", dimention_keys);
    }

    if (mask & MINER) {
      miner_ = std::make_unique<bvar::MultiDimension<
          bvar::WindowEx<bvar::Miner<double>, kWindowsSize>>>(
          service_name, metrics_name + "_min", dimention_keys);
    }

    if (mask & MAXER) {
      maxer_ = std::make_unique<bvar::MultiDimension<
          bvar::WindowEx<bvar::Maxer<double>, kWindowsSize>>>(
          service_name, metrics_name + "_max", dimention_keys);
    }

    if (mask & AVGER) {
      counter_ = std::make_unique<bvar::MultiDimension<
          bvar::WindowEx<bvar::Adder<long>, kWindowsSize>>>(
          service_name, metrics_name + "_cnt", dimention_keys);
      if (adder_ == nullptr) {
        adder_ = std::make_unique<bvar::MultiDimension<
            bvar::WindowEx<bvar::Adder<double>, kWindowsSize>>>(
            service_name, metrics_name + "_sum", dimention_keys);
      }
    }
  }

  void push(const std::list<std::string> &label, double val) {
    if (adder_.get() != nullptr) {
      auto adder_ptr = adder_->get_stats(label);
      (*adder_ptr) << val;
    }

    if (counter_.get() != nullptr) {
      auto counter_ptr = counter_->get_stats(label);
      *counter_ptr << 1;
    }

    if (miner_.get() != nullptr) {
      auto miner_ptr = miner_->get_stats(label);
      *miner_ptr << val;
    }

    if (maxer_.get() != nullptr) {
      auto maxer_ptr = maxer_->get_stats(label);
      *maxer_ptr << val;
    }
  }

  void Dump(bvar::Dumper *dumper, const bvar::DumpOptions &options = {}) {
    if (adder_.get() != nullptr) {
      adder_->dump(dumper, &options);
    }

    if (counter_.get() != nullptr) {
      counter_->dump(dumper, &options);
    }

    if (miner_.get() != nullptr) {
      miner_->dump(dumper, &options);
    }

    if (maxer_.get() != nullptr) {
      maxer_->dump(dumper, &options);
    }
  }

  std::string DebugString() {
    std::ostringstream oss;
    oss << "metrics name = [" << metrics_name_
        << "]; dimentions = ";
    return oss.str();
  }

private:
  std::unique_ptr<
      bvar::MultiDimension<bvar::WindowEx<bvar::Adder<double>, kWindowsSize>>>
      adder_;
  std::unique_ptr<
      bvar::MultiDimension<bvar::WindowEx<bvar::Adder<long>, kWindowsSize>>>
      counter_;

  std::unique_ptr<
      bvar::MultiDimension<bvar::WindowEx<bvar::Miner<double>, kWindowsSize>>>
      miner_;
  std::unique_ptr<
      bvar::MultiDimension<bvar::WindowEx<bvar::Maxer<double>, kWindowsSize>>>
      maxer_;
  std::list<std::string> dimention_keys_;
  std::string metrics_name_;
};

using NamePercentileMonitor = bvar::MultiDimension<bvar::LatencyRecorder>;
using NamedDoubleMonitor = NamedCommonMonitor<double>;
using NamedLongMonitor = NamedCommonMonitor<long>;

} // namespace monitor
  // bazel build  //common/monitor:monitor  -c dbg