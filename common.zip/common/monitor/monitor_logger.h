#pragma once
#include "common/hilog/log_helper.h"
#include "minute_file_sink.h"
#include "unique_file_sink.h"
#include "spdlog/async.h"
#include "spdlog/async_logger.h"
#include "spdlog/sinks/rotating_file_sink.h"
#include <array>
#include <boost/uuid/uuid.hpp>
#include <boost/uuid/uuid_generators.hpp>
#include <boost/uuid/uuid_io.hpp>
#include <bvar/mvariable.h>
#include <bvar/variable.h>
#include <chrono>
#include <memory>
#include <unistd.h>
#include <json2pb/pb_to_json.h>
#include <unordered_map>
#include <vector>
namespace monitor {
namespace details {

inline std::string GetFormattedTimeStamp() {
  auto now = std::chrono::system_clock::now();
  auto now_c = std::chrono::system_clock::to_time_t(now);
  tm now_tm = *localtime(&now_c);

  auto duration = now.time_since_epoch();
  auto nanos =
      std::chrono::duration_cast<std::chrono::nanoseconds>(duration).count() %
      1'000'000'000;

  std::array<char, 64> buffer;

  std::snprintf(buffer.data(), buffer.size(),
                "%04d-%02d-%02dT%02d:%02d:%02d.%09ld+08:00",
                now_tm.tm_year + 1900, now_tm.tm_mon + 1, now_tm.tm_mday,
                now_tm.tm_hour, now_tm.tm_min, now_tm.tm_sec, nanos);

  return std::string(buffer.data());
}
class MonitorLogger {
public:
  MonitorLogger(const MonitorLogger &) = delete;
  MonitorLogger &operator=(const MonitorLogger &) = delete;

  static MonitorLogger &getInstance() {
    static MonitorLogger instance;
    return instance;
  }

  inline static std::string monitor_log_path =
      "/opt/hihonor/ai-logs/aiops/predictor";

  inline static std::string bigdata_log_path = 
      "./";

  void WriteToGeneralLogger(const std::string &message) {
    monitor_file_logger->info(message);
  }

  void WriteToInterfaceLogger(const std::string &message) {
    interface_file_logger->info(message);
  }

  void WriteToBigdataLogger(const std::string &message) {
    bigdata_file_logger->info(message);
  }

private:
  MonitorLogger() {
    spdlog::init_thread_pool(8192, 2);
    std::string monitor_file_log_full_path{monitor_log_path};
    std::string bigdata_log_path_full_path{bigdata_log_path};
    monitor_file_log_full_path.append("/ai-logs-monitor-");
    bigdata_log_path_full_path.append("/bigdata-");

    std::array<char, 512> host_name;
    host_name[host_name.max_size() - 1] = '\0';
    int ret = gethostname(host_name.data(), host_name.max_size() - 1);
    if (ret == -1) {
      boost::uuids::random_generator rget;
      boost::uuids::uuid r_uuid = rget();
      monitor_file_log_full_path.append(boost::uuids::to_string(r_uuid));
      bigdata_log_path_full_path.append(boost::uuids::to_string(r_uuid));
      HILOG_APP(WARNING) << "do not find host name, use uuid ["
                         << boost::uuids::to_string(r_uuid) << "]instead";
    } else {
      monitor_file_log_full_path.append(host_name.data());
      bigdata_log_path_full_path.append(host_name.data());
    }
    // 初始化监控的logger
    auto monitor_file_sink =
        std::make_shared<spdlog::sinks::minute_file_sink_mt>(
            monitor_file_log_full_path + "-general.log", false, 10);
    monitor_file_logger = std::make_shared<spdlog::async_logger>(
        "monitor_logger", spdlog::sinks_init_list{monitor_file_sink},
        spdlog::thread_pool(), spdlog::async_overflow_policy::block);
    monitor_file_logger->set_level(spdlog::level::info);
    monitor_file_logger->set_pattern("%v");

    // 初始化interface logger
    auto interface_log_sink =
        std::make_shared<spdlog::sinks::minute_file_sink_mt>(
            monitor_file_log_full_path + "-interface.log", false, 10);
    interface_file_logger = std::make_shared<spdlog::async_logger>(
        "interface_logger", spdlog::sinks_init_list{interface_log_sink},
        spdlog::thread_pool(), spdlog::async_overflow_policy::block);
    interface_file_logger->set_level(spdlog::level::info);
    interface_file_logger->set_pattern("%v");

    // 初始化bigdata logger
    auto bigdata_log_sink =
        std::make_shared<spdlog::sinks::minute_file_sink_mt>(
            bigdata_log_path_full_path + "-bigdata.log", false, 30);
    bigdata_file_logger = std::make_shared<spdlog::async_logger>(
        "bigdata_logger", spdlog::sinks_init_list{bigdata_log_sink},
        spdlog::thread_pool(), spdlog::async_overflow_policy::block);
    bigdata_file_logger->set_level(spdlog::level::info);
    bigdata_file_logger->set_pattern("%v");

  }
  std::shared_ptr<spdlog::async_logger> monitor_file_logger;
  std::shared_ptr<spdlog::async_logger> interface_file_logger;
  std::shared_ptr<spdlog::async_logger> bigdata_file_logger;
};

} // namespace details
} // namespace monitor