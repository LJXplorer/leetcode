#pragma once

#include "monitor_manager.h"
#include "named_monitor.h"
#include <memory>
#include <string>
namespace monitor {

struct Factory {
  template <typename T>
  static std::shared_ptr<NamedCommonMonitor<T>>
  CreateCommonMonitor(const std::string& service_name,
                      const std::list<std::string> &dimention_keys,
                      const std::string &metric_name, long mask) {

    auto monitor_ptr = std::make_shared<NamedCommonMonitor<T>>(
        service_name, dimention_keys,
        metric_name, mask);
    return monitor_ptr;
  }

  template <typename T>
  static std::shared_ptr<NamedCommonMonitor<T>>
  CreateCommonMonitor(const MonitorConfig &config) {
    auto monitor_ptr = std::make_shared<NamedCommonMonitor<T>>(
        config.service_name,
        config.dimention_keys, config.metirc_name, config.mask);
    return monitor_ptr;
  }

  static std::shared_ptr<NamePercentileMonitor>
  CreatePercentileMonitor(const std::string& service_name,
                          const std::list<std::string> &dimention_keys,
                          const std::string &metric_name) {
    auto monitor_ptr = std::make_shared<NamePercentileMonitor>(
        service_name, metric_name,
        dimention_keys);
    // 注册到manager
    MonitorManager::getInstance().Register(service_name, dimention_keys, metric_name,
                                           monitor_ptr);
    return monitor_ptr;
  }

  static std::shared_ptr<NamePercentileMonitor>
  CreatePercentileMonitor(const MonitorConfig &config) {
    return CreatePercentileMonitor(config.service_name, config.dimention_keys,
                                   config.metirc_name);
  }
};

template <>
inline std::shared_ptr<NamedCommonMonitor<double>>
Factory::CreateCommonMonitor<double>(
    const std::string& service_name, const std::list<std::string> &dimention_keys,
    const std::string &metric_name, long mask) {
  auto monitor_ptr = std::make_shared<NamedDoubleMonitor>(
      service_name, dimention_keys,
      metric_name, mask);
  MonitorManager::getInstance().Register(service_name, dimention_keys, metric_name,
                                         monitor_ptr);
  return monitor_ptr;
}

template <>
inline std::shared_ptr<NamedCommonMonitor<long>>
Factory::CreateCommonMonitor<long>(const std::string& service_name, 
                                   const std::list<std::string> &dimention_keys,
                                   const std::string &metric_name, long mask) {
  auto monitor_ptr = std::make_shared<NamedCommonMonitor<long>>(
      service_name, dimention_keys,
      metric_name, mask);
  MonitorManager::getInstance().Register(service_name, dimention_keys, metric_name,
                                         monitor_ptr);
  return monitor_ptr;
}

template <>
inline std::shared_ptr<NamedCommonMonitor<double>>
Factory::CreateCommonMonitor<double>(const MonitorConfig &config) {
  auto monitor_ptr = std::make_shared<NamedDoubleMonitor>(
      config.service_name,
      config.dimention_keys, config.metirc_name, config.mask);
  MonitorManager::getInstance().Register(config.service_name,
                                         config.dimention_keys,
                                         config.metirc_name, monitor_ptr);
  return monitor_ptr;
}

template <>
inline std::shared_ptr<NamedCommonMonitor<long>>
Factory::CreateCommonMonitor<long>(const MonitorConfig &config) {
  auto monitor_ptr = std::make_shared<NamedCommonMonitor<long>>(
      config.service_name,
      config.dimention_keys, config.metirc_name, config.mask);
  MonitorManager::getInstance().Register(config.service_name,
                                         config.dimention_keys,
                                         config.metirc_name, monitor_ptr);
  return monitor_ptr;
}
} // namespace monitor
