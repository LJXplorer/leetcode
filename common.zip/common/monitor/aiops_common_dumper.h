#pragma once
#include "nlohmann/json.hpp"
#include "common/monitor/prometheus_pusher.h"
#include <bvar/variable.h>
#include <string_view>
#include <unordered_map>
#include <memory>

namespace monitor {
class AiopsCommonDumper : public bvar::Dumper {
public:
  AiopsCommonDumper();
  bool dump(const std::string &name,
            const butil::StringPiece &description) override;
  std::unordered_map<std::string, nlohmann::json>& GetDumpedJsonMap();
  ~AiopsCommonDumper() {}

private:
  std::unordered_map<std::string, nlohmann::json> json_container_map_;
  static std::vector<std::string_view> split(const std::string_view &str,
                                             char delimiter);

  std::unique_ptr<push::PrometheusPusher> pusher_;  // 推送器
  uint64_t GetCurrentTimeMs() const;                // 获取当前时间戳(毫秒)
};
} // namespace monitor
