#pragma once
#include "aiops_common_dumper.h"
#include "common/comm/thread_pool.h"
#include "common/hilog/log_helper.h"
#include "monitor_logger.h"
#include "named_monitor.h"
#include <array>
#include <bvar/mvariable.h>
#include <bvar/variable.h>
#include <chrono>
#include <cstdio>
#include <debug_utils.h>
#include <gflags/gflags.h>
#include <glog/logging.h>
#include <iostream>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
namespace monitor {
inline static const std::string kInterfaceLogDelemiter{"|"};

struct InterfaceLogEntity {
  std::string version;
  long start_time;
  std::string type;
  std::string interface_name;
  std::string source_id;
  std::string destination_id;
  std::string flag;
  std::string return_code;
  std::string translocation_id;
  std::string return_info;
  int size;
  std::string grey_tag;
  std::string addition_info;

  std::string ToString() const {
    std::string msg{};
    // 获取当前时间点
    auto now = std::chrono::system_clock::now();
    // 转换为时间戳（自1970年1月1日以来的毫秒数）
    long curr_timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
                              now.time_since_epoch())
                              .count();
    msg.append(version)
        .append(kInterfaceLogDelemiter)
        .append(details::GetFormattedTimeStamp())
        .append(kInterfaceLogDelemiter)
        .append(type)
        .append(kInterfaceLogDelemiter)
        .append(interface_name)
        .append(kInterfaceLogDelemiter)
        .append(source_id)
        .append(kInterfaceLogDelemiter)
        .append(destination_id)
        .append(kInterfaceLogDelemiter)
        .append(std::to_string(curr_timestamp - start_time))
        .append(kInterfaceLogDelemiter)
        .append(flag)
        .append(kInterfaceLogDelemiter)
        .append(return_code)
        .append(kInterfaceLogDelemiter)
        .append(translocation_id)
        .append(kInterfaceLogDelemiter)
        .append(return_info)
        .append(kInterfaceLogDelemiter)
        .append(std::to_string(size))
        .append(kInterfaceLogDelemiter)
        .append(grey_tag)
        .append(kInterfaceLogDelemiter)
        .append(addition_info);
    return msg;
  }
};

class MonitorManager {
public:
  // 获取单例对象的引用
  static MonitorManager &getInstance() {
    static MonitorManager instance; // 局部静态变量
    return instance;
  }
  static void SetMonitorLogFilePath(const std::string &path) {
    if (!path.empty()) {
      details::MonitorLogger::monitor_log_path = path;
    }
  }

  // 禁止拷贝构造函数和拷贝赋值操作符
  MonitorManager(const MonitorManager &) = delete;
  MonitorManager &operator=(const MonitorManager &) = delete;

  inline static std::string project_id = "ai_ad";

  // 注册分位数监控器到manager中,只有注册到manager中的分位数监控才能被dump到日志中
  void Register(const std::string &service_name,
                const std::list<std::string> &dimention_keys,
                const std::string &metric_name,
                std::shared_ptr<NamePercentileMonitor> monitor) {
    std::lock_guard lock_guard(percentile_map_mtx_);
    percentiles_map_.insert({metric_name, monitor});
  }

  void Register(const std::string &service_name,
                const std::list<std::string> &dimention_keys,
                const std::string &metric_name,
                std::shared_ptr<NamedDoubleMonitor> monitor) {
    std::lock_guard lock_guard(double_map_mtx_);
    common_double_monitor_map_.insert({metric_name, monitor});
  }

  void Register(const std::string &service_name,
                const std::list<std::string> &dimention_keys,
                const std::string &metric_name,
                std::shared_ptr<NamedLongMonitor> monitor) {
    std::lock_guard lock_guard(long_map_mtx_);
    common_long_monitor_map_.insert({metric_name, monitor});
  }

  std::shared_ptr<NamedDoubleMonitor>
  GetNamedDoubleMonitor(const std::string &service_name,
                        const std::list<std::string> &dimention_keys,
                        const std::string &metric_name) {
    auto iter = common_double_monitor_map_.find(metric_name);
    if (iter == common_double_monitor_map_.end()) {
      return nullptr;
    }
    return iter->second;
  }

  std::shared_ptr<NamedLongMonitor>
  GetNamedLongMonitor(const std::string &service_name,
                      const std::list<std::string> &dimention_keys,
                      const std::string &metric_name) {
    auto iter = common_long_monitor_map_.find(metric_name);
    if (iter == common_long_monitor_map_.end()) {
      return nullptr;
    }
    return iter->second;
  }

  std::shared_ptr<NamePercentileMonitor>
  GetNamedPercentileMonitor(const std::string &service_name,
                            const std::list<std::string> &dimention_keys,
                            const std::string &metric_name) {
    auto iter = percentiles_map_.find(metric_name);
    if (iter == percentiles_map_.end()) {
      return nullptr;
    }
    return iter->second;
  }

  void InterfaceLog(const InterfaceLogEntity &message_entity) {

    details::MonitorLogger::getInstance().WriteToInterfaceLogger(
        message_entity.ToString());
  }

  void InterfaceSvrSuccess(long start_time, const std::string &interface_name,
                           const std::string &source_id,
                           const std::string &return_code,
                           const std::string &return_info,
                           const std::string &translocation_id, int size,
                           const std::string &grey_tag,
                           const std::string &addition_info) {
    InterfaceLogEntity interface_log_entity{
        "V1.1", start_time, "svr",        interface_name,   source_id,
        "",     "T",        return_code,  translocation_id, return_info,
        size,   grey_tag,   addition_info};
    InterfaceLog(interface_log_entity);
  }

  void InterfaceSvrError(long start_time, const std::string &interface_name,
                         const std::string &source_id,
                         const std::string &return_code,
                         const std::string &return_info,
                         const std::string &translocation_id, int size,
                         const std::string &grey_tag,
                         const std::string &addition_info) {
    InterfaceLogEntity interface_log_entity{
        "V1.1", start_time, "svr",        interface_name,   source_id,
        "",     "F",        return_code,  translocation_id, return_info,
        size,   grey_tag,   addition_info};
    InterfaceLog(interface_log_entity);
  }

  void InterfaceCliSuccess(long start_time, const std::string &interface_name,
                           const std::string &destination_id,
                           const std::string &return_code,
                           const std::string &translocation_id, int size,
                           const std::string &grey_tag,
                           const std::string &addition_info) {
    InterfaceLogEntity interface_log_entity{
        "V1.1",         start_time, "cli",        interface_name,   "",
        destination_id, "T",        return_code,  translocation_id, "",
        size,           grey_tag,   addition_info};
    InterfaceLog(interface_log_entity); // 使用 info 级别日志
  }

  void InterfaceCliError(long start_time, const std::string &interface_name,
                         const std::string &destination_id,
                         const std::string &return_code,
                         const std::string &translocation_id, int size,
                         const std::string &grey_tag,
                         const std::string &addition_info) {
    InterfaceLogEntity interface_log_entity{
        "V1.1",         start_time, "cli",        interface_name,   "",
        destination_id, "F",        return_code,  translocation_id, "",
        size,           grey_tag,   addition_info};
    InterfaceLog(interface_log_entity); // 使用 info 级别日志
  }
  /**
   * 定时dump
   * bvar到日志中，需要在所有的monitor构造好后再调用该接口，否则会存在多线程问题
   *
   */
  void StartDump() {
    std::cout << "dump_task start!" << std::endl;
    dump_task_->Start();
  }

private:
  std::mutex long_map_mtx_;
  std::mutex double_map_mtx_;
  std::mutex percentile_map_mtx_;
  bvar::DumpOptions default_options_;
  // 私有构造函数
  MonitorManager() : default_options_(), monitor_thread_pool_(2
  ) {
    auto dump_task = [this]() {
      AiopsCommonDumper dumper{};
      for (const auto &[metircs_name, named_monitor] :
           common_double_monitor_map_) {
        named_monitor->Dump(&dumper);
      }

      for (const auto &[metircs_name, named_monitor] :
           common_long_monitor_map_) {
        named_monitor->Dump(&dumper);
      }

      for (const auto &[metircs_name, named_monitor] : percentiles_map_) {
        named_monitor->dump(&dumper, {});
      }

      auto &json_log_container = dumper.GetDumpedJsonMap();
      for (auto &[ignored, json_log] : json_log_container) {
        HILOG_APP(INFO) << "dumped map metrics name = [" << ignored << "];"; 
        json_log["p"] = project_id;
        json_log["t"] = details::GetFormattedTimeStamp();
        details::MonitorLogger::getInstance().WriteToGeneralLogger(
            json_log.dump());
      }

      // size_t dumped_num = bvar::MVariable::dump_exposed(&dumper,
      // &default_options_);
      // HILOG_APP(INFO) << "dumped num = [" << dumped_num << "]";
      // auto& dumped_map = dumper.GetDumpedJsonMap();
      // for(auto&[ignored, json_log_container] : dumped_map) {
      //     json_log_container["p"] = project_id;
      //     json_log_container["t"] = details::GetFormattedTimeStamp();
      //     json_log_container["version"] = "V1.0";
      //     details::MonitorLogger::getInstance().WriteToGeneralLogger(json_log_container.dump());
      // }
    };
    dump_task_ = monitor_thread_pool_.PostPeriodicCron(30, dump_task);
    if (google::SetCommandLineOption("bvar_dump_interval", "60").empty()) {
         std::cerr << "Fail to set mbvar_dump_format"<< std::endl;
    }
  }

  // 私有析构函数
  ~MonitorManager() { HILOG_APP(INFO) << "MonitorManager destructed."; }
  std::unordered_map<std::string, std::shared_ptr<NamePercentileMonitor>>
      percentiles_map_;
  std::unordered_map<std::string, std::shared_ptr<NamedDoubleMonitor>>
      common_double_monitor_map_;
  std::unordered_map<std::string, std::shared_ptr<NamedLongMonitor>>
      common_long_monitor_map_;
  common::ThreadPool monitor_thread_pool_;
  std::shared_ptr<common::PeriodicCronTask> dump_task_;
};

} // namespace monitor
