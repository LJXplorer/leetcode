#pragma once
#include "monitor_factory.h"
#include "named_monitor.h"
#include <memory>
namespace monitor {
// aiops日志中的s,对应service_name
inline const std::string kDefaultServiceName = "Predictor";

const static std::string kCollectRuleIdAiopsKey{"id"};
template <typename T> class CommonMonitor {
public:
  CommonMonitor(const std::string &service_name,
                const std::string &collect_rule_id,
                const std::list<std::string> &dimention_keys, long mask)
      : service_name_(service_name), collect_rule_id_(collect_rule_id),
        dimention_keys_(dimention_keys), mask_(mask) {
    dimention_keys_.emplace_front(kCollectRuleIdAiopsKey);
    std::cout << "common monitor create, service_name = " << service_name_ << "; collect_rule_id = " << collect_rule_id_ <<std::endl;
  }

public:
  void push(std::list<std::string> &labels, const std::string &metrics_name,
            T val) {
    labels.emplace_front(collect_rule_id_);
    std::shared_lock<std::shared_mutex> read_lock(rd_mtx_);
    auto it = monitor_map_.find(metrics_name);
    if (it != monitor_map_.end()) {
      it->second->push(labels, val);
      read_lock.unlock();
      return;
    }
    read_lock.unlock();

    std::unique_lock<std::shared_mutex> write_lock(rd_mtx_);
    it = monitor_map_.find(metrics_name);
    if (it != monitor_map_.end()) {
      it->second->push(labels, val);
      write_lock.unlock();
      return;
    }

    auto new_monitor = Factory::CreateCommonMonitor<T>(
        service_name_, dimention_keys_, metrics_name, mask_);
    monitor_map_[metrics_name] = new_monitor;
    write_lock.unlock();
    
    spdlog::info("named CommonMonitor create: metrics_name = {}", metrics_name);
    new_monitor->push(labels, val);
  }

public:
  std::string service_name_;
  std::string collect_rule_id_;
  std::list<std::string> dimention_keys_;
  long mask_;
  std::unordered_map<std::string, std::shared_ptr<NamedCommonMonitor<T>>>
      monitor_map_{};
  std::shared_mutex rd_mtx_{};
};

class PercentileMonitor {
public:
  PercentileMonitor(const std::string &service_name,
                    const std::string &collect_rule_id,
                    const std::list<std::string> &dimention_keys)
      :  service_name_(service_name), collect_rule_id_(collect_rule_id),
        dimention_keys_(dimention_keys) {
    dimention_keys_.emplace_front(kCollectRuleIdAiopsKey);
    std::cout << "percent monitor create, service_name = " << service_name_ << "; collect_rule_id = " << collect_rule_id_ <<std::endl;
  }

  void push(std::list<std::string> &labels, const std::string &metrics_name,
            long val) {
    if (val < 0) {
      return;
    }
    labels.emplace_front(collect_rule_id_);
    std::shared_lock<std::shared_mutex> read_lock(rd_mtx_);
    auto it = recorder_map_.find(metrics_name);
    if (it != recorder_map_.end()) {
      bvar::LatencyRecorder *ptr = it->second->get_stats(labels);
      if (ptr != nullptr) {
        *ptr << val;
      }
      read_lock.unlock();
      return;
    }
    read_lock.unlock();

    std::unique_lock<std::shared_mutex> write_lock(rd_mtx_);
    it = recorder_map_.find(metrics_name);
    if (it != recorder_map_.end()) {
      auto ptr = it->second->get_stats(labels);
      *ptr << val;
      write_lock.unlock();
      return;
    }

    auto new_monitor = Factory::CreatePercentileMonitor(
        service_name_, dimention_keys_, metrics_name);
    recorder_map_[metrics_name] = new_monitor;
    write_lock.unlock();

    spdlog::info("named PercentileMonitor create: metrics_name = {}", metrics_name);
    bvar::LatencyRecorder *latency_recorder_this_label =
        new_monitor->get_stats(labels);
    if (latency_recorder_this_label != nullptr) {
      *latency_recorder_this_label << val;
    }
  }

private:
  std::string service_name_;
  std::string collect_rule_id_;
  std::list<std::string> dimention_keys_;
  std::unordered_map<
      std::string, std::shared_ptr<bvar::MultiDimension<bvar::LatencyRecorder>>>
      recorder_map_;
  std::shared_mutex rd_mtx_;
};

using LongCommonMonitor = CommonMonitor<long>;
using DoubleCommonMonitor = CommonMonitor<double>;
} // namespace monitor
