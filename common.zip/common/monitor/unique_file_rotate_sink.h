#pragma once

#include <spdlog/common.h>
#include <spdlog/details/file_helper.h>
#include <spdlog/details/null_mutex.h>
#include <spdlog/details/os.h>
#include <spdlog/details/synchronous_factory.h>
#include <spdlog/fmt/fmt.h>
#include <spdlog/sinks/base_sink.h>

#include <mutex>
#include <string>

namespace spdlog {
    namespace sinks {
        //每次写日志都会写在一个新文件中
        template<typename Mutex>
        class unique_file_rotate_sink final : public base_sink<Mutex> {
        public:
            inline unique_file_rotate_sink(filename_t base_filename, std::size_t max_files, bool rotate_on_open = false,
                                    const file_event_handlers &event_handlers = {})
                : base_filename_(std::move(base_filename)), max_files_(max_files), file_helper_{event_handlers} {

                if (max_files > 200000) {
                    throw_spdlog_ex("rotating sink constructor: max_files arg cannot exceed 200000");
                }
                file_helper_.open(calc_filename(base_filename_, 0));
                if (rotate_on_open) {
                    rotate_();
                }
            }

            static filename_t calc_filename(const filename_t &filename, std::size_t index) {
                if (index == 0u) {
                    return filename;
                }

                filename_t basename, ext;
                std::tie(basename, ext) = details::file_helper::split_by_extension(filename);
                return fmt_lib::format(SPDLOG_FILENAME_T("{}.{}{}"), basename, index, ext);
            }
            filename_t filename() {
                std::lock_guard<Mutex> lock(base_sink<Mutex>::mutex_);
                return file_helper_.filename();
            }

        protected:
            void sink_it_(const details::log_msg &msg) override {
                //每次写入都会轮转
                memory_buf_t formatted;
                base_sink<Mutex>::formatter_->format(msg, formatted);

                file_helper_.write(formatted);
                rotate_();
            }
            void flush_() override {
                file_helper_.flush();
            }

        private:
            void rotate_() {
                using details::os::filename_to_str;
                using details::os::path_exists;

                file_helper_.close();
                for (auto i = max_files_; i > 0; --i) {
                    filename_t src = calc_filename(base_filename_, i - 1);
                    if (!path_exists(src)) {
                        continue;
                    }
                    filename_t target = calc_filename(base_filename_, i);

                    if (!rename_file_(src, target)) {
                        // if failed try again after a small delay.
                        // this is a workaround to a windows issue, where very high rotation
                        // rates can cause the rename to fail with permission denied (because of antivirus?).
                        details::os::sleep_for_millis(100);
                        if (!rename_file_(src, target)) {
                            file_helper_.reopen(
                                    true);// truncate the log file anyway to prevent it to grow beyond its limit!
                            
                            throw_spdlog_ex("rotating_file_sink: failed renaming " + filename_to_str(src) + " to " +
                                                    filename_to_str(target),
                                            errno);
                        }
                    }
                }
                file_helper_.reopen(true);
            }

            // delete the target if exists, and rename the src file  to target
            // return true on success, false otherwise.
            bool rename_file_(const filename_t &src_filename, const filename_t &target_filename) {
                // try to delete the target file in case it already exists.
                (void) details::os::remove(target_filename);
                return details::os::rename(src_filename, target_filename) == 0;
            }

            filename_t base_filename_;
            std::size_t max_files_;
            details::file_helper file_helper_;
        };

        using unique_file_rotate_sink_mt = unique_file_rotate_sink<std::mutex>;
        using unique_file_rotate_sink_st = unique_file_rotate_sink<details::null_mutex>;

    }// namespace sinks

    //
    // factory functions
    //

    template<typename Factory = spdlog::synchronous_factory>
    inline std::shared_ptr<logger> unique_file_logger_mt(const std::string &logger_name, const filename_t &filename,
                                                         size_t max_files, bool rotate_on_open = false,
                                                         const file_event_handlers &event_handlers = {}) {
        return Factory::template create<sinks::unique_file_rotate_sink>(logger_name, filename, max_files, rotate_on_open,
                                                                      event_handlers);
    }

    template<typename Factory = spdlog::synchronous_factory>
    inline std::shared_ptr<logger> unique_file_logger_st(const std::string &logger_name, const filename_t &filename,
                                                         size_t max_files, bool rotate_on_open = false,
                                                         const file_event_handlers &event_handlers = {}) {
        return Factory::template create<sinks::unique_file_rotate_sink>(logger_name, filename, max_files, rotate_on_open,
                                                                      event_handlers);
    }
}// namespace spdlog