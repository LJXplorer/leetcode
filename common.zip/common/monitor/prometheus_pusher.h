#ifndef PUSH_CONFIG_H_
#define PUSH_CONFIG_H_

#include <string>
#include <atomic>
#include <brpc/channel.h>
#include <butil/object_pool.h>
#include <boost/lockfree/queue.hpp>
#include <thread>
#include <mutex>
#include <memory>
#include <vector>

namespace push {
class PrometheusPusher;

class PushConfig {
public:
    static std::atomic<bool> push_enable_;                      // bvar监控数据上报推送开关
    static std::shared_ptr<const std::string> prometheus_url_;  // 推送地址
    static std::shared_ptr<const std::string> prometheus_uri_;  // 推送路径
    static std::atomic<int32_t> batch_size_;                    // 批量大小
    static std::atomic<uint64_t> push_timeout_ms_;              // 推送超时时间(ms)
    static std::atomic<int32_t> max_queue_size_;                // 最大排队数据条数（<=0 表示不限制；超限在消费者侧丢弃最旧）
    static void set(bool enable, const std::string& url, const std::string& uri, int32_t size, uint64_t time, int32_t max_size);
};

class PrometheusPusher {
public:
    PrometheusPusher();
    ~PrometheusPusher();

    static void SetEnabled(bool enable);    // 运行时开关
    static bool IsEnabled();
    void AddData(std::string&& prometheus_data);
private:
    static int32_t GetConsumerThreadCount();                                // 计算消费者线程数
    static bool EnsureChannelInitialized();                                 // 确保通道与资源初始化（可重试）
    static void RecycleString(std::string* ptr);                            // 归还 string 对象到对象池
    static void PushWorker(std::shared_ptr<std::atomic<bool>> stop_token);  // 核心推送逻辑（支持逐线程优雅停止）
    static void ProcessBatches();                                           // 批处理和超时检查逻辑（空闲时短暂休眠）
    static bool ExecuteHttpPush(const std::string& data);                   // 执行HTTP推送
    static uint64_t GetCurrentTimeMs();                                     // 获取当前时间戳
    
    // 初始化
    static std::atomic<bool> accepting_;                    // 写入开关：停止阶段拒绝新写入，避免停机期堆积
    static std::atomic<bool> channel_initialized_;          // 通道与资源是否准备就绪
    static std::mutex init_mutex_;                          // 初始化互斥保护
    static std::shared_ptr<brpc::Channel> channel_;         // brpc HTTP 客户端通道（共享指针便于热切换原子替换）
    static std::shared_ptr<const std::string> current_url_; // 当前通道使用的URL（用于判断是否需要重建）
    // 批量数据管理
    static std::unique_ptr<boost::lockfree::queue<std::string*>> push_queue_;   // 无锁MPMC队列
    static std::atomic<size_t> queue_size_;                                     // 当前近似排队条数（生产者入队+1，消费者出队-1）

    // 线程和生命周期管理
    class PusherManager {
        friend class PrometheusPusher;
    public:
        PusherManager();
        ~PusherManager();
        void start(int thread_count);
        void stop();
    private:
        struct ThreadHandle {
            std::unique_ptr<std::thread> thread;           // 线程对象
            std::shared_ptr<std::atomic<bool>> stop_token; // 逐线程停止令牌
        };
        std::mutex manager_mutex_;                  // 串行化 start/stop
        std::atomic<bool> stop_flag_{false};        // 通知全局推送线程需要停止
        std::vector<ThreadHandle> push_threads_;    // 推送线程池（带逐线程停止令牌）
    };
    static PusherManager manager_;
};
} // namespace push

#endif // PUSH_CONFIG_H_ 