#pragma once
#include <algorithm>
#include <string>
#include <string_view>
#include <vector>
namespace ai_common {
namespace utils {

inline bool IsOnlyBlank(const std::string &str) {
  if (str.empty()) {
    return true;
  }
  return std::all_of(str.begin(), str.end(),
                     [](unsigned char c) { return std::isspace(c); });
}
inline bool IsOnlyBlank(std::string_view str) {
  if (str.empty()) {
    return true;
  }
  return std::all_of(str.begin(), str.end(),
                     [](unsigned char c) { return std::isspace(c); });
}

inline std::vector<std::string_view> split(const std::string_view &str,
                                           char delimiter) {
  std::vector<std::string_view> result;
  size_t start = 0;
  size_t end = 0;

  while ((end = str.find(delimiter, start)) != std::string_view::npos) {
    if (end > start) { // 只在非空部分添加
      result.emplace_back(str.data() + start, end - start);
    }
    start = end + 1; // Move past the delimiter
  }
  // Add the last segment if it's not empty
  if (start < str.size()) {
    result.emplace_back(str.data() + start, str.size() - start);
  }

  return result;
}

inline std::vector<std::string_view> split(const std::string &str,
                                           char delimiter) {
  std::vector<std::string_view> result;
  size_t start = 0;
  size_t end = 0;

  while ((end = str.find(delimiter, start)) != std::string::npos) {
    if (end > start) { // 只在非空部分添加
      result.emplace_back(str.data() + start, end - start);
    }
    start = end + 1; // Move past the delimiter
  }
  // Add the last segment if it's not empty
  if (start < str.size()) {
    result.emplace_back(str.data() + start, str.size() - start);
  }

  return result;
}

// 去除字符串左端的空白字符
inline std::string ltrim(const std::string &s) {
  size_t start = s.find_first_not_of(" \t\n\r\f\v");
  return (start == std::string::npos) ? "" : s.substr(start);
}

// 去除字符串右端的空白字符
inline std::string rtrim(const std::string &s) {
  size_t end = s.find_last_not_of(" \t\n\r\f\v");
  return (end == std::string::npos) ? "" : s.substr(0, end + 1);
}

// 去除字符串两端的空白字符
inline std::string trim(const std::string &s) { return rtrim(ltrim(s)); }

// 去除字符串左端的空白字符（原址修改）
inline void ltrim_in_place(std::string &s) {
  s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](unsigned char ch) {
            return !std::isspace(ch);
          }));
}

// 去除字符串右端的空白字符（原址修改）
inline void rtrim_in_place(std::string &s) {
  s.erase(std::find_if(s.rbegin(), s.rend(),
                       [](unsigned char ch) { return !std::isspace(ch); })
              .base(),
          s.end());
}

// 去除字符串两端的空白字符（原址修改）
inline void trim_in_place(std::string &s) {
  ltrim_in_place(s);
  rtrim_in_place(s);
}

// 去除字符串视图左端的空白字符
inline std::string_view ltrim(std::string_view sv) {
  size_t start = 0;
  while (start < sv.size() &&
         std::isspace(static_cast<unsigned char>(sv[start]))) {
    ++start;
  }
  return sv.substr(start);
}

// 去除字符串视图右端的空白字符
inline std::string_view rtrim(std::string_view sv) {
  size_t end = sv.size();
  while (end > 0 && std::isspace(static_cast<unsigned char>(sv[end - 1]))) {
    --end;
  }
  return sv.substr(0, end);
}

// 去除字符串视图两端的空白字符
inline std::string_view trim(std::string_view sv) { return rtrim(ltrim(sv)); }

} // namespace utils

} // namespace ai_common