#pragma once
#include <boost/asio.hpp>
#include <chrono>
#include <functional>
#include <iomanip>
#include <iostream>
namespace {
std::string GetCurrentTime() {
  // 获取当前时间点
  auto now = std::chrono::system_clock::now();

  // 转换为时间_t 类型
  std::time_t now_time = std::chrono::system_clock::to_time_t(now);

  // 转换为本地时间
  std::tm *local_time = std::localtime(&now_time);

  // 使用 stringstream 格式化时间
  std::ostringstream oss;
  // 格式化字符串调整为 "%Y-%m-%d %H:%M:%S" 以输出年-月-日 时:分:秒
  oss << std::put_time(local_time, "%Y-%m-%d %H:%M:%S");

  return oss.str();
}
} // namespace
namespace common{
class PeriodicCronTask {
public:
  PeriodicCronTask(boost::asio::io_context &io_context, int second, int minute, int hour)
      : timer_(io_context), cron_hour_(hour), cron_minute_(minute), cron_second_(second) {}
  template <typename F, typename... Args> void SetTask(F &&f, Args &&...args) {
    task_ = [f, args...]() mutable { f(args...); };
    // 小时设置有效，但分钟设置为无效
    if (IsHourSet(cron_hour_) && !IsSet(cron_minute_)) {
      cron_minute_ = 0;
    }
    // 分钟设置有效，但秒设置为无效
    if (IsSet(cron_minute_) && !IsSet(cron_second_)) {
      cron_second_ = 0;
    }
  }

  bool Start() {
    if (!IsHourSet(cron_hour_) && !IsSet(cron_minute_) && !IsSet(cron_second_)) {
      return false;
    }
    const std::chrono::seconds duration = NextCronTimePointFromNow();
    std::cout << "next cron seconds = " << duration.count() << std::endl;
    timer_.expires_after(duration);
    // 设置定时器的异步等待处理程序
    timer_.async_wait([this](const boost::system::error_code &error) {
      this->OnTimerExprie(error);
    });
    return true;
  }

private:
  bool IsSet(int time) { return time < 60 && time >= 0; }
  bool IsHourSet(int time) { return time < 24 && time >= 0; }

  std::chrono::seconds NextCronTimePoint() {
    if (IsHourSet(cron_hour_)) {
      return std::chrono::seconds(86400); // 每天执行一次
    } else if (IsSet(cron_minute_)) {
      return std::chrono::seconds(3600);
    } else {
      return std::chrono::seconds(60);
    }
  }
  std::chrono::seconds NextCronTimePointFromNow() {
    // 获取当前时间点
    auto now = std::chrono::system_clock::now();

    // 将当前时间点转换为时间_t
    std::time_t now_time_t = std::chrono::system_clock::to_time_t(now);

    // 将时间_t 转换为 tm 结构
    std::tm *now_tm = std::localtime(&now_time_t);

    // 获取时、分、秒
    int hours = now_tm->tm_hour;
    int minutes = now_tm->tm_min;
    int seconds = now_tm->tm_sec;

    std::tm next_tm{};
    // 只设置了秒
    if (IsSet(cron_second_) && !IsSet(cron_minute_) && !IsSet(cron_hour_)) {
      // 如果当前时间恰好相等，那么推到下一个周期执行，即:设置cron_minute = 0,
      // 在57:00提交的任务，会在58:00执行
      if (cron_second_ > seconds) {
        next_tm = *now_tm;
        next_tm.tm_sec = cron_second_;
      } else if (cron_second_ >= 0 && cron_second_ < 60) {
        auto one_minute_later = now + std::chrono::minutes(1);
        std::time_t one_minute_later_t =
            std::chrono::system_clock::to_time_t(one_minute_later);
        std::tm *one_minute_later_tm = std::localtime(&one_minute_later_t);
        next_tm = *one_minute_later_tm;
        next_tm.tm_sec = cron_second_;
      }
      // 设置了秒和分
    } else if (IsSet(cron_minute_) && IsSet(cron_second_) && !IsSet(cron_hour_)) {
      if (cron_minute_ > minutes ||
          (cron_minute_ == minutes && cron_second_ > seconds)) {
        next_tm = *now_tm;
        next_tm.tm_min = cron_minute_;
        next_tm.tm_sec = cron_second_;
      } else {
        auto one_hour_later = now + std::chrono::hours(1);
        std::time_t one_hour_later_t =
            std::chrono::system_clock::to_time_t(one_hour_later);
        std::tm *one_hour_later_tm = std::localtime(&one_hour_later_t);
        next_tm = *one_hour_later_tm;
        next_tm.tm_min = cron_minute_;
        next_tm.tm_sec = cron_second_;
      }
      // 设置了时、分、秒
    } else if (IsSet(cron_hour_) && IsSet(cron_minute_) && IsSet(cron_second_)) {
      if (cron_hour_ > hours || 
        (cron_hour_ == hours && (cron_minute_ > minutes || 
        (cron_minute_ == minutes && cron_second_ > seconds)))) {
        next_tm = *now_tm;
        next_tm.tm_hour = cron_hour_;
        next_tm.tm_min = cron_minute_;
        next_tm.tm_sec = cron_second_;
      } else {
        auto one_day_later = now + std::chrono::hours(24);
        std::time_t one_day_later_t = std::chrono::system_clock::to_time_t(one_day_later);
        std::tm *one_day_later_tm = std::localtime(&one_day_later_t);
        next_tm = *one_day_later_tm;
        next_tm.tm_hour = cron_hour_;
        next_tm.tm_min = cron_minute_;
        next_tm.tm_sec = cron_second_;
      }
    }

    // 将 std::tm 转换为 time_t
    std::time_t next_tm_t = std::mktime(&next_tm);

    // 将 time_t 转换为 time_point
    auto next_time_point = std::chrono::system_clock::from_time_t(next_tm_t);
    auto duration = next_time_point - std::chrono::system_clock::now();
    return std::chrono::duration_cast<std::chrono::seconds>(duration) +
           std::chrono::seconds(1);
  }
  void OnTimerExprie(const boost::system::error_code &error) {
    if (!error) {
      // 定时器未被取消，任务正常执行
      if (task_) {
        std::cout << "time = " << GetCurrentTime()
                  << "; Periodic cron-like task is executed." << std::endl;
        task_();
      } else {
        std::cout << "Periodic cron-like task is null." << std::endl;
      }
      // 重置定时器，准备下一次执行
      auto duration = NextCronTimePoint();
      timer_.expires_at(timer_.expiry() + duration);
      // 重新启动定时器等待下一次过期
      timer_.async_wait([this](const boost::system::error_code &error) {
        this->OnTimerExprie(error);
      });
    } else if (error == boost::asio::error::operation_aborted) {
      // 定时器被取消
      std::cout << "Periodic cron-like task was cancelled." << std::endl;
    }
  }

  boost::asio::steady_timer timer_;
  int cron_hour_;
  int cron_minute_;
  int cron_second_;
  std::function<void()> task_;
};
}