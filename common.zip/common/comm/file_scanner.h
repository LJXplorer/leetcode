#pragma once

#include <functional>
#include <string>
#include <thread_pool.h>
namespace common {
    class FileScanner {
    public:
        explicit FileScanner(const std::string &folder_path, const std::string &success_token = "_SUCCESS");
        bool SafeScan(long* version, std::string* scanned_abs_path, long cur_version = -1);
    private:
        std::string folder_path_;
        std::string success_token_;
    };
}// namespace common