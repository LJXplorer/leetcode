// #include "segment_hash_map.h"
// #include <butil/containers/flat_map.h>
// #include <gtest/gtest.h>
// #include <memory>
// #include <thread>
// #include <vector>
// #include <atomic>

// // 测试并发安全性的模拟测试
// TEST(SegmentedHashMapConcurrencyTest, ConcurrentForEachWithInsert) {
//     using MapType = SegmentedHashMap<int, int, std::hash<int>, std::equal_to<int>,
//         std::unordered_map<int, int>, LockType::READ_WRITE_LOCK>;
//     MapType map;

//     constexpr int kTestSize = 1000;
//     std::atomic<int> read_count{0};

//     // 启动读线程
//     auto reader = std::thread([&]() {
//         map.ForEach([&](const int& k, const int& v) {
//             ++read_count;
//             ASSERT_TRUE(k >= 0 && k < kTestSize);
//         });
//     });

//     // 主线程写入数据
//     for (int i = 0; i < kTestSize; ++i) {
//         map.Insert(i, i);
//     }

//     reader.join();
//     ASSERT_GE(read_count.load(), 0);
// }
// // 测试无锁版本的基础功能
// TEST(SegmentedHashMapTest, BasicOperationsNoLock) {
//     SegmentedHashMap<int, std::string> map;

//     // 测试插入和查找
//     map.Insert(1, "one");
//     auto *value = map.Find(1);
//     ASSERT_NE(value, nullptr);
//     EXPECT_EQ(*value, "one");

//     // 测试重复插入
//     map.Insert(1, "new_one");
//     EXPECT_EQ(*map.Find(1), "new_one");

//     // 测试删除
//     bool erased = map.Erase(1);
//     EXPECT_TRUE(erased);
//     EXPECT_EQ(map.Find(1), nullptr);

//     // 测试不存在的键
//     EXPECT_EQ(map.Find(2), nullptr);
// }

// // 测试读写锁版本
// TEST(SegmentedHashMapTest, ReadWriteLockVersion) {
//     using RWMap = SegmentedHashMap<int, int, std::hash<int>, std::equal_to<int>, std::unordered_map<int, int>,
//                                    LockType::READ_WRITE_LOCK>;
//     RWMap map;

//     // 测试并发读写
//     constexpr int N = 1000;
//     std::vector<std::thread> threads;

//     // 写线程
//     threads.emplace_back([&]() {
//         for (int i = 0; i < N; ++i) {
//             map.Insert(i, i * 10);
//         }
//     });

//     // 读线程
//     threads.emplace_back([&]() {
//         for (int i = 0; i < N; ++i) {
//             auto *val = map.Find(i);
//             if (val)
//                 ASSERT_EQ(*val, i * 10);
//         }
//     });

//     for (auto &t: threads)
//         t.join();
// }

// // 测试批量插入功能
// TEST(SegmentedHashMapTest, BatchInsert) {
//     std::unordered_map<int, std::string> input{{1, "a"}, {2, "b"}, {3, "c"}, {4, "d"}};

//     SegmentedHashMap<int, std::string> map;
//     map.Insert(input);

//     for (const auto &[k, v]: input) {
//         auto *value = map.Find(k);
//         ASSERT_NE(value, nullptr);
//         EXPECT_EQ(*value, v);
//     }
// }

// // 测试FlatMap版本
// TEST(SegmentedHashMapTest, FlatMapVersion) {
//     using FlatMapType = butil::FlatMap<int, std::string>;
//     SegmentedHashMap<int, std::string, std::hash<int>, std::equal_to<int>, FlatMapType> map(17, 97, 0.7);

//     map.Insert(1, "test");
//     auto *value = map.Find(1);
//     ASSERT_NE(value, nullptr);
//     EXPECT_EQ(*value, "test");
// }

// // 测试operator[]功能
// TEST(SegmentedHashMapTest, SubscriptOperator) {
//     SegmentedHashMap<std::string, int> map;

//     map["a"] = 1;
//     map["b"] = 2;

//     EXPECT_EQ(map["a"], 1);
//     EXPECT_EQ(map["b"], 2);

//     map["a"] = 10;
//     EXPECT_EQ(map["a"], 10);
// }

// // 测试Clear功能
// TEST(SegmentedHashMapTest, ClearOperation) {
//     SegmentedHashMap<int, int> map;

//     map.Insert(1, 1);
//     map.Insert(2, 2);
//     map.Clear();

//     EXPECT_EQ(map.Find(1), nullptr);
//     EXPECT_EQ(map.Find(2), nullptr);
// }

// int main(int argc, char **argv) {
//     testing::InitGoogleTest(&argc, argv);
//     return RUN_ALL_TESTS();
// }