#pragma once

#include <atomic>
#include <thread>


namespace common{
    class RateLimiter {
    private:
        /* data */
        std::atomic<double> _capacity;
       

        std::atomic<double> _tokens;
        std::atomic<bool> _running;
        std::atomic<double> _rate;
        std::thread _t;
        const double _qps_ratio = 1.2;

        void refill();
        void periodic_task();
    public:
        bool tryAcquire(double tokens);
        bool update_rate(double qps);
        double get_rate();
        

    public:
        RateLimiter(double qps): _tokens(0), _running(true), _rate(qps) {
           _capacity.store(_qps_ratio * qps);
           refill();
           _t = std::thread(&RateLimiter::periodic_task, this);
        }
        ~RateLimiter() {
            _running.store(false);
            if (_t.joinable()) {
                _t.join();
            }
        }
    };
    
  
    
}