#ifndef _HLFRAME_CURRENT_MAP_H_
#define _HLFRAME_CURRENT_MAP_H_
#include <mutex>
#include <map>
#include <unordered_map>
#include <vector>
#include <memory>
#include <functional>
#include <atomic>
#include <set>
#include <butil/time.h>
#include "boost/thread/shared_mutex.hpp"
#include <iostream>
template<typename Val>
struct CacheValue{
    Val value;
    int64_t timestamp = 0;
    int32_t ret = 0;

    Val& get_val(){
        return value;
    }

    int64_t expire(){
        return timestamp;
    }
    CacheValue(){

    }
    CacheValue(const Val &v,int32_t expire = 0) : value(v) {
        timestamp = expire > 0?butil::gettimeofday_s() + expire:0;
    }
};


template <typename Key, typename Value >
class ConcurrentMap {
private:
    using CacheValuePtr = std::shared_ptr< CacheValue<Value>  >;
    std::vector<std::unordered_map<Key, CacheValuePtr > > _map_vec;
    std::vector<std::shared_ptr<boost::shared_mutex>> _mtx_vec;
    int retry_time = 10;
public:
    ConcurrentMap(int seg_size = 997) {
        _map_vec.resize(seg_size);
        for (int i = 0; i < seg_size; i++) {
            _mtx_vec.push_back(std::make_shared<boost::shared_mutex>());
        }
    }

    void put(const Key &key,std::shared_ptr< CacheValue<Value> >& v){
        size_t index = std::hash<Key>{}(key) % _map_vec.size();
        auto & target_map = _map_vec[index];
        auto mtx_ptr = _mtx_vec[index];
        mtx_ptr->lock();
        target_map[key] = v;
        mtx_ptr->unlock();
    }

    void put(const std::unordered_map<Key, std::shared_ptr< CacheValue<Value>  > >& map) {
        std::vector<std::unordered_map<Key, std::shared_ptr< CacheValue<Value>  > > > tmp_map_vec;
        tmp_map_vec.resize(_map_vec.size());
        for (auto & pair : map) {
            const Key& k = pair.first;
            const std::shared_ptr< CacheValue<Value> >& v = pair.second;
            size_t map_index = std::hash<Key>{}(k) % _map_vec.size();
            tmp_map_vec[map_index][k] = v ;
        }
        
        for (size_t i = 0; i < tmp_map_vec.size(); ++i) {
            auto & tmp_map = tmp_map_vec[i];
            if (tmp_map.size() == 0) {
                continue;
            }
            auto mtx_ptr = _mtx_vec[i];
            mtx_ptr->lock();
            auto& target_map = _map_vec[i];
            for (auto & pair : tmp_map) {
                target_map[pair.first] = pair.second;
            }
            mtx_ptr->unlock();

        }
    }

    std::shared_ptr< CacheValue<Value>  > get(const Key &key){
        //std::shared_ptr< CacheValue<Value>  > ret = nullptr;
        std::shared_ptr< CacheValue<Value>  > ret = std::make_shared< CacheValue<Value> >();
        size_t index = std::hash<Key>{}(key) % _map_vec.size();
        auto & map = _map_vec[index];
        auto it = map.find(key);
        if (it == map.end()) {
            return ret;
        }
        auto mtx_ptr = _mtx_vec[index];
        int try_time = 0;
        bool got_lock = mtx_ptr->try_lock_shared();
        while(!got_lock && try_time < retry_time) {
            ++try_time;
            got_lock = mtx_ptr->try_lock_shared();
        }
        int64_t cur_tm =  butil::gettimeofday_s();
        if (got_lock) {
            if(it->second->expire() == 0 || it->second->expire() > cur_tm){
               ret = it->second;
            }
            mtx_ptr->unlock_shared();
        }
        
        return ret;
    }

    std::shared_ptr<std::unordered_map<Key, Value>> get(const std::vector<Key>& key_vec,std::vector<Key>& timeout_vec) {
        std::vector<std::vector<Key> > tmp_key_vec;
        tmp_key_vec.resize(_map_vec.size());
        for (const Key& key : key_vec) {
            size_t index = std::hash<Key>{}(key) % _map_vec.size();
            auto & vec = tmp_key_vec[index];
            if (vec.size() == 0) {
                vec.reserve(key_vec.size() / 2);
            }
            vec.push_back(key);
        }
        
        std::unordered_map<Key, Value> ret;
        for (size_t i = 0; i < tmp_key_vec.size(); ++i) {
            auto & k_vec = tmp_key_vec[i];
            if (k_vec.size() == 0) {
                continue;
            }
            auto & map = _map_vec[i];
            if (map.size() == 0) {
                continue;
            }
            auto mtx_ptr = _mtx_vec[i];
            int try_time = 0;
            bool got_lock = mtx_ptr->try_lock_shared();
            while(!got_lock && try_time < retry_time) {
                ++try_time;
                got_lock = mtx_ptr->try_lock_shared();
            }
            
            if (got_lock) {
                for (auto & k : k_vec) {
                    auto it = map.find(k);
                    if (it == map.end()) {
                        continue;
                    }
                    int64_t cur_tm =  butil::gettimeofday_s();
                    if(it->second->expire() && it->second->expire() < cur_tm){
                        timeout_vec.emplace_back(it->first);
                    }
                    ret.insert({it->first, it->second->get_val()});
                }
                mtx_ptr->unlock_shared();
            }
        }
 
        return std::make_shared<std::unordered_map<Key, Value>>(std::move(ret));
    }
    
    void del(const Key &key){
        size_t index = std::hash<Key>{}(key) % _map_vec.size();
        auto & target_map = _map_vec[index];
        auto mtx_ptr = _mtx_vec[index];
        int try_time = 0;
        mtx_ptr->lock();
        target_map.del(key);
        mtx_ptr->unlock();
    }

    void expire_keys(std::map<size_t ,std::vector<Key>>&expire_keys){
       for (size_t i = 0; i < _map_vec.size(); ++i) {
            auto & map = _map_vec[i];
            if (map.size() == 0) {
                continue;
            }
            auto&keys = expire_keys[i];
            auto mtx_ptr = _mtx_vec[i];
            int64_t cur_tm =  butil::gettimeofday_s();
            if(mtx_ptr->try_lock_shared())
            {
                for (auto & k_v : map) { 
                    if(k_v.second->expire() && k_v.second->expire() < cur_tm){
                        keys.emplace_back(k_v.first);
                    }
                }
                mtx_ptr->unlock_shared();
            }
        }
    }

    void keys(std::map<size_t ,std::vector<Key>>&valide_keys,std::map<size_t ,std::vector<Key>>&expire_keys){
       for (size_t i = 0; i < _map_vec.size(); ++i) {
            auto & map = _map_vec[i];
            if (map.size() == 0) {
                continue;
            }
            auto&v_keys = valide_keys[i];
            auto&e_keys = expire_keys[i];
            auto mtx_ptr = _mtx_vec[i];
            int64_t cur_tm =  butil::gettimeofday_s();
            if(mtx_ptr->try_lock_shared())
            {
                for (auto & k_v : map) { 
                    if(k_v.second->expire() && k_v.second->expire() < cur_tm){
                        e_keys.emplace_back(k_v.first);
                    }else{
                        v_keys.emplace_back(k_v.first);
                    }
                }
                mtx_ptr->unlock_shared();
            }
        }
    }

    void expire(const std::map<size_t ,std::vector<Key>>&expire_keys){
       for (const auto &expire :expire_keys) {
            auto & target_map = _map_vec[expire.first];
            if (target_map.size() == 0) {
                continue;
            }
            auto&keys = expire.second;
            auto mtx_ptr = _mtx_vec[expire.first];
            
            {
                mtx_ptr->lock();
                for (auto & k : keys) { 
                    target_map.erase(k);
                }
                mtx_ptr->unlock();
            }
        }
    }

    int size() {
        int size = 0;
        for (int i = 0; i < _map_vec.size(); i++) {
            auto mtx_ptr = _mtx_vec[i];
            if(mtx_ptr->try_lock_shared()){
                size += _map_vec[i].size();
                mtx_ptr->unlock_shared();
            }
        }
        return size;
    }
};

#endif