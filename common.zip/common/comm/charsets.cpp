#include "charsets.h"
#include <string>
namespace charsets {
    int to_88591(const char* src,int32_t src_size,std::string &dst){
        iconv_t cd = iconv_open("ISO-8859-1", "UTF-8");
        if (cd == (iconv_t)(-1)) {
            return -1;
        }
        size_t inBytesLeft = src_size;
        size_t outBytesLeft = inBytesLeft * 2; 
        char* inBuf = const_cast<char*>(src);
        char* outBuf = new char[outBytesLeft];
        char* outPtr = outBuf;

        if (iconv(cd, &inBuf, &inBytesLeft, &outPtr, &outBytesLeft) == (size_t)(-1)) {
            delete[] outBuf;
            iconv_close(cd);
            return -2;
        }
        dst.assign(outBuf, outPtr - outBuf);
        delete[] outBuf;
        iconv_close(cd);
        return 0;
    };
}