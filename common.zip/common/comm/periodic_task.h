#pragma once
#include <boost/asio.hpp>
#include <functional>
#include <iostream>
#include "common/hilog/log_helper.h"

namespace common {

class PeriodicTask {
public:
  PeriodicTask(boost::asio::io_context &io_context,
               std::chrono::steady_clock::duration interval)
      : timer_(io_context, interval), interval_(interval) {}
  template <typename F, typename... Args> void SetTask(F &&f, Args &&...args) {
    task_ = [f, args...]() mutable { f(args...); };
  }

  void Start() {
    // 设置定时器的异步等待处理程序
    timer_.async_wait([this](const boost::system::error_code &error) {
      this->OnTimerExprie(error);
    });
  }

private:
  void OnTimerExprie(const boost::system::error_code &error) {
    if (!error) {
      if (task_) {
        task_();
      } else {
        HILOG_APP(ERROR) << "Periodic task is null.";
      }
      timer_.expires_at(timer_.expiry() + interval_);
      Start();
    } else if (error == boost::asio::error::operation_aborted) {
      // 定时器被取消
      HILOG_APP(ERROR) << "Periodic task was cancelled. error: boost::asio::error::operation_aborted";
    } else {
      HILOG_APP(ERROR) << "error: " << error;
    }
  }

  boost::asio::steady_timer timer_;
  std::chrono::steady_clock::duration interval_;
  std::function<void()> task_;
};
} // namespace common