#include "rate_limit.h"
#include <algorithm>
#include <thread>
#include <iostream>



namespace common {


    void RateLimiter::periodic_task() {
        while (_running.load()) {
            refill();
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }


    void RateLimiter::refill() {
        double cur = _tokens.load();
        double new_tokens = std::min(_capacity.load(), cur + _rate.load());
        _tokens.store(new_tokens);
    }

    bool RateLimiter::tryAcquire(double tokens) {
        double cur = _tokens.load();
        while (cur >= tokens) {
            /* code */
            if (_tokens.compare_exchange_weak(cur, cur-tokens)) {
                return true;
            }
        }
        return false;
        
    }

    bool RateLimiter::update_rate(double qps) {
        double cur = _rate.load();
        double cap = _capacity.load();
        while (true) {
            if (_rate.compare_exchange_weak(cur, qps) && _capacity.compare_exchange_weak(cap, _qps_ratio * qps)) {
                return true;
            }
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        return false;
    }

    double RateLimiter::get_rate() {
        return _rate.load();
    }
}