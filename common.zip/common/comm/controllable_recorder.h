#pragma once

#include "common/comm/wrapper_time.h"
#include "third_party/brpc/include/bvar/latency_recorder.h"

template<bool Enabled>
class ControllableLatencyRecorder;

// #define ENABLE_LATENCY_MONITOR

#ifdef ENABLE_LATENCY_MONITOR

#define DECLARE_LATENCY_MONITOR(name)                                                                                  \
    namespace __LATENCY_RECORDER__ {                                                                                   \
        inline ::bvar::LatencyRecorder g_latency_##name(#name);                                                        \
    }

#define MONITOR_POINT_BEGIN(name) const auto __mp_start_##name##__LINE__ = ::gettimeofday_us()

#define MONITOR_POINT_END(name) ::__LATENCY_RECORDER__::g_latency_##name << (gettimeofday_us() - __mp_start_##name##__LINE__)

#define MONITOR_DIRECT(name, value) ::__LATENCY_RECORDER__::g_latency_##name << (value)

#define MONITOR_SCOPE(name) ::ControllableLatencyRecorder<true> _latency_monitor_##__LINE__(&::__LATENCY_RECORDER__::g_latency_##name)

template<bool Enabled>
class ControllableLatencyRecorder {
public:
    explicit ControllableLatencyRecorder(::bvar::LatencyRecorder *recorder)
        : start_(gettimeofday_us()), recorder_(recorder) {
    }

    ~ControllableLatencyRecorder() {
        *recorder_ << (gettimeofday_us() - start_);
    }

private:
    int64_t start_;
    ::bvar::LatencyRecorder *recorder_;
};

#else

#define DECLARE_LATENCY_MONITOR(...)
#define MONITOR_POINT_BEGIN(...)
#define MONITOR_POINT_END(...)
#define MONITOR_DIRECT(...)
#define MONITOR_SCOPE(...)

#endif