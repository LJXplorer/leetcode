#pragma once
#include "periodic_cron_task.h"
#include "periodic_task.h"
#include <boost/asio.hpp>
#include <chrono>
#include <cstdio>
#include <functional>
#include <iostream>
#include <log_helper.h>
#include <memory>
#include <thread>
#include <vector>
#include "common/hilog/log_helper.h"
namespace common {
    class ThreadPool {
    public:
        ThreadPool(std::size_t pool_size = std::thread::hardware_concurrency(), const std::string &name = "common_pool")
            : io_context_(pool_size), work_(boost::asio::make_work_guard(io_context_)) {
            for (std::size_t i = 0; i < pool_size; ++i) {
                workers_.emplace_back([this, name] {
                    pthread_setname_np(pthread_self(), name.c_str());
                    io_context_.run();
                });
            }
        }

        ~ThreadPool() {
            io_context_.stop();
            for (auto &worker: workers_) {
                if (worker.joinable()) {
                    worker.join();
                }
            }
        }

        /**
   * 提交任务到队列中
   *
   * @param f 需要执行的可调用对象
   * @param f的参数,完美转发给f?
   *
   */
        template<typename F, typename... Args>
        void Submit(F &&f, Args &&...args) {
            auto task = std::bind(std::forward<F>(f), std::forward<Args>(args)...);
            boost::asio::post(io_context_, task);
        }

        /**
   * 提交延时任务到线程池中
   *
   * @param delay delay多少后执行
   * @param f 需要执行的可调用对象
   * @param f的参数,完美转发给f?
   *
   */
  template <typename F, typename... Args>
  std::shared_ptr<boost::asio::steady_timer>
  SubmitDelay(std::chrono::steady_clock::duration delay, F &&f,
              Args &&...args) {
    auto timer =
        std::make_shared<boost::asio::steady_timer>(io_context_, delay);
    auto task = std::bind(std::forward<F>(f), std::forward<Args>(args)...);
    timer->async_wait([timer, task](const boost::system::error_code &error) {
      if (!error) {
        HILOG_APP(ERROR) << "start execute delayed task";
        task();
      } else {
        HILOG_APP(ERROR) << "do not execute delayed task; error code = " << error;
      }
    });
    return timer;
  }

        /**
   * 周期性提交任务到线程池中
   *
   * @param interval 执行周期间隔
   * @param f 需要周期执行的可调用对象
   * @param args
   * f的参数,会通过拷贝传递给f,建议参数传递智能指针,注意指针的生命周期
   * @todo: 研究下怎么把参数完美转发到f
   *
   */

        template<typename F, typename... Args>
        [[nodiscard]] std::shared_ptr<PeriodicTask> StartPeriodic(std::chrono::steady_clock::duration period, F &&f,
                                                                  Args &&...args) {
            auto p_task = std::make_shared<PeriodicTask>(io_context_, period);
            p_task->SetTask(std::forward<F>(f), std::forward<Args>(args)...);
            p_task->Start();
            return p_task;
        }

        /**
   * 周期性提交任务到线程池中
   *
   * @param interval 执行周期间隔
   * @param f 需要周期执行的可调用对象
   * @param args
   * f的参数,会通过拷贝传递给f,建议参数传递智能指针,注意指针的生命周期
   * @todo: 研究下怎么把参数完美转发到f
   *
   */
        template<typename F, typename... Args>
        [[nodiscard]] std::shared_ptr<PeriodicTask> PostPeriodic(std::chrono::steady_clock::duration period, F &&f,
                                                                 Args &&...args) {
            auto p_task = std::make_shared<PeriodicTask>(io_context_, period);
            p_task->SetTask(std::forward<F>(f), std::forward<Args>(args)...);
            return p_task;
        }

        /**
   * 简单的cron类型的周期性任务
   *
   * @param second 在每分钟的第多少秒执行
   * @param f 需要周期执行的可调用对象
   * @param args
   * f的参数,会通过拷贝传递给f,建议参数传递智能指针,注意指针的生命周期
   * @todo: 研究下怎么把参数完美转发到f
   *
   */
        template<typename F, typename... Args>
        [[nodiscard]] std::shared_ptr<PeriodicCronTask> PostPeriodicCron(int second, F &&f, Args &&...args) {
            auto p_cron_task = std::make_shared<PeriodicCronTask>(io_context_, second, -1, -1);
            p_cron_task->SetTask(std::forward<F>(f), std::forward<Args>(args)...);
            return p_cron_task;
        }

        /**
   * 简单的cron类型的周期性任务
   *
   * @param second 在每分钟的第多少秒执行
   * @param f 需要周期执行的可调用对象
   * @param args
   * f的参数,会通过拷贝传递给f,建议参数传递智能指针,注意指针的生命周期
   * @todo: 研究下怎么把参数完美转发到f
   *
   */
        template<typename F, typename... Args>
        [[nodiscard]] std::shared_ptr<PeriodicCronTask> StartPeriodicCron(int second, F &&f, Args &&...args) {
            auto p_cron_task = std::make_shared<PeriodicCronTask>(io_context_, second, -1, -1);
            p_cron_task->SetTask(std::forward<F>(f), std::forward<Args>(args)...);
            p_cron_task->Start();
            return p_cron_task;
        }

        /**
   * 简单的cron类型的周期性任务
   * @param minute
   * @param second 在每小时的minute:second的时间执行任务
   * @param f 需要周期执行的可调用对象
   * @param args
   * f的参数,会通过拷贝传递给f,建议参数传递智能指针,注意指针的生命周期
   * @todo: 研究下怎么把参数完美转发到f
   *
   */
        template<typename F, typename... Args>
        std::shared_ptr<PeriodicCronTask> PostPeriodicCron(int second, int minute, F &&f, Args &&...args) {
            auto p_cron_task = std::make_shared<PeriodicCronTask>(io_context_, second, minute, -1);
            p_cron_task->SetTask(std::forward<F>(f), std::forward<Args>(args)...);
            p_cron_task->Start();
            return p_cron_task;
        }
    
         /**
   * 简单的cron类型的周期性任务
   * @param hour
   * @param minute
   * @param second 在每天的hour:minute:second的时间执行任务
   * @param f 需要周期执行的可调用对象
   * @param args
   * f的参数,会通过拷贝传递给f,建议参数传递智能指针,注意指针的生命周期
   * @todo: 研究下怎么把参数完美转发到f
   *
   */
        template<typename F, typename... Args>
        std::shared_ptr<PeriodicCronTask> PostPeriodicCron(int second, int minute, int hour, F &&f, Args &&...args) {
            auto p_cron_task = std::make_shared<PeriodicCronTask>(io_context_, second, minute, hour);
            p_cron_task->SetTask(std::forward<F>(f), std::forward<Args>(args)...);
            p_cron_task->Start();
            return p_cron_task;
        }

    private:
        boost::asio::io_context io_context_;
        boost::asio::executor_work_guard<boost::asio::io_context::executor_type> work_;
        std::vector<std::thread> workers_;
    };

    inline ThreadPool g_backgroud_task_executor{1};

}// namespace common
