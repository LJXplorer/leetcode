#pragma once
#include "common/hilog/log_helper.h"
#include "utils.h"
#include <boost/lockfree/queue.hpp>
#include <chrono>
#include <cstddef>
#include <pthread.h>
#include <thread>
#include <vector>
namespace common::lockfree_threadpool {

    struct TaskWrapper {
        using Task = void *(*) (void *);
        void *args = nullptr;
        Task t = nullptr;
    };
    class Executor {
    public:
        const static size_t kQueueSize = 1024;
        explicit Executor(size_t thread_num = std::thread::hardware_concurrency(), size_t queue_size = kQueueSize,
                          const std::string &executor_name = "default_executor_thread", int32_t inter_time = 1000)
            : queue(kQueueSize), stop(false) {
            for (size_t i = 0; i < thread_num; ++i) {
                workers.emplace_back([this, i, executor_name,inter_time] {
                    // 设置线程名称
                    std::string thread_name = executor_name + "_" + std::to_string(i);
                    pthread_setname_np(pthread_self(), thread_name.c_str());

                    TaskWrapper task_wrapper;
                    while (!this->stop) {
                        if (queue.pop(task_wrapper)) {
                            if (unlikely(task_wrapper.t == nullptr)) {
                                HILOG_APP(ERROR) << "task in wrapper is null! this should not happen";
                            } else {
                                task_wrapper.t(task_wrapper.args);
                            }
                        } else {
                            // 如果队列为空，则让出CPU时间片，减少忙等待
                            std::this_thread::sleep_for(std::chrono::microseconds(inter_time));
                        }
                    }
                });
            }
        }

        ~Executor() {
            stop.store(true);
            for (auto &worker: workers) {
                if (worker.joinable()) {
                    worker.join();
                }
            }
        }

        void enqueue(TaskWrapper task) {
            while (!queue.push(task)) {
                // 如果队列满了，则稍微等待后重试
                std::this_thread::sleep_for(std::chrono::microseconds(1));
            }
        }

    private:
        std::vector<std::thread> workers;
        boost::lockfree::queue<TaskWrapper> queue;
        std::atomic<bool> stop;
    };
}// namespace common::lockfree_threadpool