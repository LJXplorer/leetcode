﻿#include "config_xml.h"
#include <iostream>
#include "glog/logging.h"


void ConfigXml::init(const std::string& path) {
    tinyxml2::XMLError err = _xml.LoadFile(path.c_str());
    if(err != tinyxml2::XML_SUCCESS){
	    std::cerr<<path<<" pares fail";
	    return;
    }
    _node = _xml.RootElement();
}

bool  ConfigXml::parse(const std::string&data){
    tinyxml2::XMLError err = _xml.Parse(data.c_str());
    if(err != tinyxml2::XML_SUCCESS){
	    std::cerr<<data<<" pares fail";
	    return false;
    }
    _node = _xml.RootElement();
    return true;
}

const tinyxml2::XMLElement* ConfigXml::node() const {
    return _node;
}

bool ConfigXml::child(const std::string& name, ConfigXml& out) const {
    tinyxml2::XMLElement* ret = _node->FirstChildElement(name.c_str());
    if (ret) {
        out._node = ret;
        return true;
    }
    return false;
}

bool ConfigXml::next(ConfigXml& out) const {
    tinyxml2::XMLElement* ret = _node->NextSiblingElement();
    if (ret) {
        out._node = ret;
        return true;
    }
    return false;
}

bool ConfigXml::next(const std::string& name, 
        ConfigXml& out) const {
    tinyxml2::XMLElement* ret = _node->NextSiblingElement(name.c_str());
    if (ret) {
        out._node = ret;
        return true;
    }
    return false;
}

bool ConfigXml::find(const std::string& name,
        ConfigXml& conf) const {
    if (_node->Name() == name) {
        conf._node = _node;
        return true;
    }
    return next(name, conf);
}

bool ConfigXml::name(std::string& out) const {
    out = _node->Name();
    return true;
}


