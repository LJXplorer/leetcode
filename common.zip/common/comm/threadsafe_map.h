#ifndef THREAD_SAFE_MAP_H
#define THREAD_SAFE_MAP_H

#include <map>
#include <mutex>
#include <string>
#include <optional>
#include <vector>

template<typename Key, typename Value>
class ThreadSafeMap {
private:
    std::map<Key, Value> data;
    mutable std::mutex mutex;

public:
    // 在 ThreadSafeMap 类中新增方法
    bool put(const Key &key, const Value &value) {
        std::lock_guard<std::mutex> lock(mutex);
        if (data.find(key) == data.end()) {
            data[key] = value;
            return true;
        }
        return false;
    }

    std::optional<Value> get(const Key &key) const {
        std::lock_guard<std::mutex> lock(mutex);
        auto it = data.find(key);
        if (it != data.end()) {
            return it->second;
        }
        return std::nullopt;
    }

    // 检查键是否存在
    bool contains(const Key& key) const {
        std::lock_guard<std::mutex> lock(mutex);
        return data.find(key) != data.end();
    }

    // 删除键值对
    void remove(const Key& key) {
        std::lock_guard<std::mutex> lock(mutex);
        data.erase(key);
    }

    // 获取所有键
    std::vector<Key> keys() const {
        std::lock_guard<std::mutex> lock(mutex);
        std::vector<Key> result;
        for (const auto& pair : data) {
            result.push_back(pair.first);
        }
        return result;
    }

    // 获取map的大小
    size_t size() const {
        std::lock_guard<std::mutex> lock(mutex);
        return data.size();
    }

    // 清空map
    void clear() {
        std::lock_guard<std::mutex> lock(mutex);
        data.clear();
    }
};

#endif // THREAD_SAFE_MAP_H