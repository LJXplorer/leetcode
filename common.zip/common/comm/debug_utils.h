#pragma once
#include "nlohmann/json.hpp"
#include "segment_hash_map.h"
#include "third_party/brpc/include/json2pb/json_to_pb.h"
#include <butil/base64.h>
#include <bvar/latency_recorder.h>
#include <cxxabi.h>
#include <fstream>
#include <functional>
#include <google/protobuf/message.h>
#include <ios>
#include <iostream>
#include <json2pb/pb_to_json.h>
#include <memory>
#include <mutex>
#include <nlohmann/json_fwd.hpp>
#include <shared_mutex>
#include <sstream>
#include <string>
#include <type_traits>
#include <unordered_map>
/**
 * @brief 提供debug用的一些函数,接口随时会发生变化,禁止在release版本中使用!
 *
 */
namespace {

    // 检测是否有begin()和end()方法的辅助模板
    template<typename T, typename = void>
    struct HasBeginEnd : std::false_type {};

    template<typename T>
    struct HasBeginEnd<T, std::void_t<decltype(std::declval<T>().begin()), decltype(std::declval<T>().end())>>
        : std::true_type {};

    // 定义一个辅助模板结构体，用于检测类型T是否为std::string
    template<typename T>
    struct IsStdString : std::false_type {};

    // 特化该模板结构体，当T为std::string时，继承自std::true_type
    template<>
    struct IsStdString<std::string> : std::true_type {};
    template<>
    struct IsStdString<const std::string> : std::true_type {};
    // 检测成员函数ToString，且其返回类型为std::string
    template<typename T, typename = void>
    struct HasToStringReturningString : std::false_type {};

    template<typename T>
    struct HasToStringReturningString<T, std::void_t<decltype(std::declval<T>().ToString())>>
        : std::is_same<decltype(std::declval<T>().ToString()), std::string> {};

    // 检测成员函数to_string，且其返回类型为std::string
    template<typename T, typename = void>
    struct HasToStringReturningStringLowercase : std::false_type {};

    template<typename T>
    struct HasToStringReturningStringLowercase<T, std::void_t<decltype(std::declval<T>().to_string())>>
        : std::is_same<decltype(std::declval<T>().to_string()), std::string> {};

    // 检测成员函数DebugString()，且其返回类型为std::string
    template<typename T, typename = void>
    struct HasDebugStringReturningString : std::false_type {};

    template<typename T>
    struct HasDebugStringReturningString<T, std::void_t<decltype(std::declval<T>().DebugString())>>
        : std::is_same<decltype(std::declval<T>().DebugString()), std::string> {};

    // 检测成员函数str()，且其返回类型为std::string
    template<typename T, typename = void>
    struct HasStrReturningString : std::false_type {};

    template<typename T>
    struct HasStrReturningString<T, std::void_t<decltype(std::declval<T>().str())>>
        : std::is_same<decltype(std::declval<T>().str()), std::string> {};

    // 检测std::to_string的适用性
    template<typename T, typename = void>
    struct IsStdToStringApplicable : std::false_type {};

    template<typename T>
    struct IsStdToStringApplicable<T, std::void_t<decltype(std::to_string(std::declval<T>()))>> : std::true_type {};

    template<typename T>
    struct IsPair : std::false_type {};

    template<typename T1, typename T2>
    struct IsPair<std::pair<T1, T2>> : std::true_type {};

    // 检测是否是std::pair或具有first和second成员变量
    template<typename T, typename = void>
    struct IsPairLike : std::false_type {};

    template<typename T>
    struct IsPairLike<T, std::void_t<decltype(std::declval<T>().first), decltype(std::declval<T>().second)>>
        : std::true_type {};

    // 基本模板，假设T不是指针
    template<typename T>
    struct IsSmartPointer : std::false_type {};

    // 特化版本，用于std::unique_ptr
    template<typename T>
    struct IsSmartPointer<std::unique_ptr<T>> : std::true_type {};

    // 特化版本，用于std::shared_ptr
    template<typename T>
    struct IsSmartPointer<std::shared_ptr<T>> : std::true_type {};

    // 测试函数
    template<typename T>
    bool CheckIsSmartPointer() {
        return IsSmartPointer<T>::value;
    }

    template<typename T>
    struct IsProtobufMessage {
        static constexpr bool value = std::is_base_of<google::protobuf::Message, T>::value;
    };

    template<typename T>
    struct IsNlohmannJson {
        static constexpr bool value = std::is_base_of<nlohmann::json, T>::value;
    };

}// namespace

namespace debug {
    template<typename Func>
    void CallOnce(Func &&func) {
        static std::once_flag flag;
        std::call_once(flag, std::forward<Func>(func));
    }
}// namespace debug
namespace debug::file {
    inline std::string ReadFile(const std::string &filename, std::ios::openmode mode = std::ios::in) {
        std::ifstream file(filename, mode);
        if (!file.is_open()) {
            throw std::runtime_error("Failed to open file: " + filename);
        }

        std::ostringstream content;
        content << file.rdbuf();
        return content.str();
    }

    inline std::vector<std::string> ReadLines(const std::string &filename, std::ios::openmode mode = std::ios::in) {
        std::ifstream file(filename, mode);
        if (!file || !file.is_open()) {
            throw std::runtime_error("无法打开文件: " + filename);
        }

        std::vector<std::string> lines;
        std::string line;
        while (std::getline(file, line)) {
            lines.push_back(line);
        }
        file.close();
        return lines;
    }

    inline void WriteToFile(const std::string &file_name, const std::string &content,
                            std::ios_base::openmode mode = std::ios::out) {
        std::ofstream outfile;
        outfile.open(file_name, std::ios::out | mode);
        outfile << content << std::endl;
    }

}// namespace debug::file

namespace debug::printer {
    template<typename Enumeration>
    auto AsNumber(Enumeration const value) -> typename std::underlying_type<Enumeration>::type {
        return static_cast<typename std::underlying_type<Enumeration>::type>(value);
    }

    inline std::string DemangledName(const char *name) {
        const char *demangled_name = abi::__cxa_demangle(name, nullptr, nullptr, nullptr);
        return std::string{demangled_name};
    }

    /**
     * @brief 编译期获取类型名称的函数,仅用于调试
     * 
     * @tparam T 
     * @return constexpr string_view 
     */
    template<typename T>
    constexpr auto GetTypeName() noexcept {
        std::string_view name, prefix, suffix;
#ifdef __clang__
        name = __PRETTY_FUNCTION__;
        prefix = "auto GetTypeName() [T = ";
        suffix = "]";
#elif defined(__GNUC__)
        name = __PRETTY_FUNCTION__;
        prefix = "constexpr auto GetTypeName() [with T = ";
        suffix = "]";
#elif defined(_MSC_VER)
        name = __FUNCSIG__;
        prefix = "auto __cdecl GetTypeName<";
        suffix = ">(void) noexcept";
#endif
        name.remove_prefix(prefix.size());
        name.remove_suffix(suffix.size());
        return name;
    }
    /**
     * @brief 运行期获取类型名称的函数,仅用于调试
     * 
     * @tparam T 
     * @return 类型名
     */
    template<typename T>
    std::string TypeName(T param) {
        return DemangledName(typeid(T).name());
    }
    template<typename T>
    std::string ToString(T &obj);
    template<typename T>
    nlohmann::json ToJsonObject(T &obj) {
        using PureType = std::remove_cv_t<std::remove_reference_t<T>>;
        if constexpr (IsProtobufMessage<PureType>::value) {
            std::string pb_json_string{};
            json2pb::Pb2JsonOptions opt;
            opt.bytes_to_base64 = false;
            json2pb::ProtoMessageToJson(obj, &pb_json_string, opt, nullptr);
            nlohmann::json json_object = nlohmann::json::parse(pb_json_string);
            return json_object;
        }
        // 处理指针的情况
        else if constexpr (std::is_pointer<PureType>::value) {
            nlohmann::json json_object{};
            const void *address = static_cast<const void *>(obj);
            std::stringstream ss_buffer;
            ss_buffer << DemangledName(typeid(obj).name()) << "@" << address;
            json_object["clazz"] = ss_buffer.str();
            using UnwrapperValue = typename std::remove_pointer<T>::type;
            UnwrapperValue &obj_v = *obj;
            json_object["value"] = ToJsonObject(obj_v);
            return json_object;
        } else if constexpr (IsSmartPointer<PureType>::value) {
            nlohmann::json json_object{};
            const void *address = static_cast<const void *>(obj.get());
            std::stringstream ss_buffer;
            ss_buffer << DemangledName(typeid(obj).name()) << "@" << address;
            json_object["clazz"] = ss_buffer.str();
            json_object["value"] = ToJsonObject(*obj);
            return json_object;
        } else if constexpr (std::is_enum<PureType>::value) {
            nlohmann::json json_object{};
            json_object["enum_clazz"] = DemangledName(typeid(T).name());
            json_object["value"] = AsNumber(obj);
            return json_object;
        } else if constexpr (IsStdString<PureType>::value) {
            nlohmann::json json_object{};
            json_object["value"] = obj;
            return json_object;
        } else if constexpr (IsNlohmannJson<T>::value) {
            return obj;
        } else if constexpr (HasBeginEnd<PureType>::value) {
            auto begin = obj.begin();
            auto end = obj.end();
            nlohmann::json json_array = nlohmann::json::array();

            for (auto it = begin; it != end; ++it) {
                using PureType = std::remove_cv_t<std::remove_reference_t<decltype(*it)>>;
                if constexpr (IsStdString<PureType>::value) {
                    json_array.emplace_back(*it);
                } else if constexpr (HasBeginEnd<PureType>::value || IsPairLike<PureType>::value ||
                                     IsPair<PureType>::value || IsProtobufMessage<PureType>::value) {
                    json_array.emplace_back(ToJsonObject(*it));
                } else if constexpr (std::is_pointer<PureType>::value || IsSmartPointer<PureType>::value) {
                    json_array.emplace_back(ToJsonObject(*it));
                } else if constexpr (IsStdToStringApplicable<decltype(*it)>::value) {
                    json_array.emplace_back(*it);
                } else {
                    json_array.emplace_back(ToString(*it));
                }
            }
            return json_array;
        } else if constexpr (IsPairLike<T>::value) {
            nlohmann::json json_object;
            using PureTypeFirst = std::remove_cv_t<std::remove_reference_t<decltype(obj.first)>>;
            if constexpr (IsStdString<PureTypeFirst>::value) {
                json_object["first"] = obj.first;
            } else if constexpr (HasBeginEnd<PureTypeFirst>::value || IsPairLike<PureTypeFirst>::value ||
                                 IsPair<PureTypeFirst>::value) {
                json_object["first"] = ToJsonObject(obj.first);
            } else if constexpr (IsStdToStringApplicable<decltype(obj.first)>::value) {
                json_object["first"] = obj.first;
            } else {
                json_object["first"] = ToString(obj.first);
            }

            using PureTypeSecond = std::remove_cv_t<std::remove_reference_t<decltype(obj.second)>>;
            if constexpr (IsStdString<PureTypeSecond>::value) {
                json_object["second"] = obj.second;
            } else if constexpr (HasBeginEnd<PureTypeSecond>::value || IsPairLike<PureTypeSecond>::value ||
                                 IsPair<PureTypeSecond>::value || IsProtobufMessage<PureTypeSecond>::value) {
                json_object["second"] = ToJsonObject(obj.second);
            } else if constexpr (std::is_pointer<PureTypeSecond>::value || IsSmartPointer<PureTypeSecond>::value) {
                json_object["second"] = ToJsonObject(obj.second);
            } else if constexpr (IsStdToStringApplicable<decltype(obj.second)>::value) {
                json_object["second"] = obj.second;
            } else {
                json_object["second"] = ToString(obj.second);
            }
            return json_object;
        } else if constexpr (IsPair<T>::value) {
            nlohmann::json json_object;
            using PureTypeFirst = std::remove_cv_t<std::remove_reference_t<decltype(obj.first)>>;
            if constexpr (IsStdString<PureTypeFirst>::value) {
                json_object["first"] = obj.first;
            } else if constexpr (HasBeginEnd<PureTypeFirst>::value || IsPairLike<PureTypeFirst>::value ||
                                 IsPair<PureTypeFirst>::value) {
                json_object["first"] = ToJsonObject(obj.first);
            } else if constexpr (IsStdToStringApplicable<decltype(obj.first)>::value) {
                json_object["first"] = obj.first;
            } else {
                json_object["first"] = ToString(obj.first);
            }

            using PureTypeSecond = std::remove_cv_t<std::remove_reference_t<decltype(obj.second)>>;
            if constexpr (IsStdString<PureTypeSecond>::value) {
                json_object["second"] = obj.second;
            } else if constexpr (HasBeginEnd<PureTypeSecond>::value || IsPairLike<PureTypeSecond>::value ||
                                 IsPair<PureTypeSecond>::value || IsProtobufMessage<PureTypeSecond>::value) {
                json_object["second"] = ToJsonObject(obj.second);
            } else if constexpr (std::is_pointer<PureTypeSecond>::value || IsSmartPointer<PureTypeSecond>::value) {
                json_object["second"] = ToJsonObject(obj.second);
            } else if constexpr (IsStdToStringApplicable<decltype(obj.second)>::value) {
                json_object["second"] = obj.second;
            } else {
                json_object["second"] = ToString(obj.second);
            }
            return json_object;
        } else {
            nlohmann::json json_object{};
            const void *address = static_cast<const void *>(&obj);
            std::stringstream ss_buffer;
            ss_buffer << DemangledName(typeid(obj).name()) << "@";
            ss_buffer << address;
            json_object["clazz"] = ss_buffer.str();
            json_object["value"] = ToString(obj);
            return json_object;
        }
    }

    /**
 * @brief 打印任意对象的debug信息,仅用于调试,不要在正式环境中使用这些代码!
 * 打印规则
 * 1.如果为std::string或能被std::to_string(obj)调用，则返回自身或std::to_string(obj)的结果
 * 2.如果对象拥有obj.to_string()/obj.ToString()/obj.DebugString()/obj.str()方法,
 * 返回这些成员函数返回的std::string
 * 3.如果对象拥有迭代器,则对于迭代器中的每个元素调用ToString()方法,并将结果按照json
 * array的格式返回
 * 4.对于std::pair<>,返回json对象形如{"first":1, second:"a"}
 * 5.对于指针类型,返回ptr#{类型名};value=ToString(指针指向的值)
 * 6.都不满足,返回 地址@{类型名}
 * @tparam T 任意类型T
 * @param obj 要打印的对象
 * @return std::string 转换后的string对象
 */
    template<typename T>
    std::string ToString(T &obj) {
        using PureType = std::remove_cv_t<std::remove_reference_t<T>>;
        // 处理指针的情况
        if constexpr (std::is_pointer<PureType>::value) {
            const void *address = static_cast<const void *>(obj);
            std::stringstream ss_buffer;
            ss_buffer << "[" << DemangledName(typeid(obj).name()) << "@";
            ss_buffer << address << ";value = [";
            using UnwrapperValue = typename std::remove_pointer<T>::type;
            UnwrapperValue &obj_v = *obj;
            ss_buffer << ToString(obj_v);
            ss_buffer << "]";
            return ss_buffer.str();
        }
        // 处理枚举的情况
        if constexpr (std::is_enum<PureType>::value) {
            return "(enum_class:[" + DemangledName(typeid(T).name()) + "];value:[" + std::to_string(AsNumber(obj)) +
                   "])";
        }
        // 是std::string,直接返回obj
        if constexpr (IsStdString<PureType>::value) {
            return obj;
        }
        // 检测是否可以使用std::to_string
        if constexpr (IsStdToStringApplicable<PureType>::value) {
            return std::to_string(obj);
        }
        // 检测是否有成员函数DebugString()，且其返回类型为std::string
        if constexpr (HasDebugStringReturningString<PureType>::value) {
            return obj.DebugString();
        }

        if constexpr (IsNlohmannJson<PureType>::value) {
            return obj.dump();
        }

        // 检测是否有成员函数ToString，且其返回类型为std::string
        else if constexpr (HasToStringReturningString<PureType>::value) {
            return obj.ToString();
        }
        // 检测是否有成员函数to_string，且其返回类型为std::string
        else if constexpr (HasToStringReturningStringLowercase<PureType>::value) {
            return obj.to_string();
        }
        // 检测obj.str()方法
        else if constexpr (HasStrReturningString<PureType>::value) {
            return obj.str();
        } else {
            using PureType = std::remove_cv_t<std::remove_reference_t<decltype(obj)>>;
            if constexpr (HasBeginEnd<PureType>::value || IsPairLike<PureType>::value || IsPair<PureType>::value) {
                return ToJsonObject(obj).dump(2);
            }
            // 默认返回对象地址
            else {
                const void *address = static_cast<const void *>(&obj);
                std::stringstream ss_buffer;
                ss_buffer << DemangledName(typeid(obj).name()) << "@";
                ss_buffer << address;
                return ss_buffer.str();
            }
        }
    }

    // template <typename T> std::string ToString(T *&obj) {
    //   const void *address = static_cast<const void *>(obj);
    //   std::stringstream ss;
    //   ss << "raw_ptr#" << DemangledName(typeid(obj).name()) << "@";
    //   ss << address << ";value = " << ToString(*obj);
    //   return ss.str();
    // }

    template<typename T>
    std::string ToString(const std::shared_ptr<T> &obj) {
        const void *address = static_cast<const void *>(obj.get());
        std::stringstream ss;
        ss << "shared_ptr#" << DemangledName(typeid(obj).name()) << "@";
        ss << address << ";value = " << ToString(*obj);
        return ss.str();
    }

    template<typename T>
    std::string ToString(const std::unique_ptr<T> &obj) {
        const void *address = static_cast<const void *>(obj.get());
        std::stringstream ss;
        ss << "unique_ptr#" << DemangledName(typeid(obj).name()) << "@";
        ss << address << ";value = " << ToString(*obj);
        return ss.str();
    }

}// namespace debug::printer
namespace debug::monitor {
    using MonitorMap =
            SegmentedHashMap<std::string, std::shared_ptr<bvar::LatencyRecorder>, std::hash<std::string>,
                             std::equal_to<>, std::unordered_map<std::string, std::shared_ptr<bvar::LatencyRecorder>>,
                             LockType::READ_WRITE_LOCK>;
    namespace {
        static std::unordered_map<std::string, std::unique_ptr<bvar::LatencyRecorder>> s_map{};
        static std::shared_mutex s_mutex;
    }// namespace

    inline void MonitorPercentile(const std::string &bvar_name, long cost) {
        if (cost < 0) {
            return;
        }
        {
            //拿到读锁且存在该bvar,直接写即可
            std::shared_lock rd_lock(s_mutex);
            auto it = s_map.find(bvar_name);
            if (it != s_map.end()) {
                (*it->second) << cost;
                return;
            }
        }
        {
            //不存在该bvar,新建并写入
            std::unique_lock wr_lock(s_mutex);
            auto it = s_map.find(bvar_name);
            if (it == s_map.end()) {
                auto it = s_map.emplace(bvar_name, std::make_unique<bvar::LatencyRecorder>());
                it.first->second->expose(bvar_name);
            } else {
                (*it->second) << cost;
            }
        }
    }
}// namespace debug::monitor
namespace debug::pb {
    enum class PbFormat {
        kRawBinary,
        kBase64,
        kJson,
    };

    template<typename PbType>
    bool LoadPbFromFile(const std::string &file_path, PbType *pb, PbFormat file_format = PbFormat::kJson) {
        std::ios_base::openmode mode = std::ios::in;
        if (file_format == PbFormat::kRawBinary) {
            mode = std::ios::binary;
        }
        std::string content = file::ReadFile(file_path, mode);

        switch (file_format) {
            case (PbFormat::kRawBinary): {
                return pb->ParseFromString(content);
            }

            case PbFormat::kBase64: {
                butil::StringPiece sp{content};
                std::string decoded_str;
                bool decode_ret = butil::Base64Decode(sp, &decoded_str);
                if (!decode_ret) {
                    std::cerr << "decode base64 failed" << std::endl;
                }
                return pb->ParseFromString(decoded_str);
            }

            case PbFormat::kJson: {
                std::string err_msg{};
                json2pb::Json2PbOptions opts;
                opts.base64_to_bytes = false;
                bool success = json2pb::JsonToProtoMessage(content, pb, opts, &err_msg);
                if (!success) {
                    std::cerr << "json convert to proto failed, error message: " << err_msg << std::endl;
                }
                return success;
            }

            default:
                return false;
        }
    }

    template<typename PbType>
    bool LoadPbFromFile(const std::string &file_path, std::vector<PbType> *parsed_pbs,
                        PbFormat file_format = PbFormat::kJson) {
        std::ios_base::openmode mode = std::ios::in;
        if (file_format == PbFormat::kRawBinary) {
            std::cerr << "can not read raw binary by lines" << std::endl;
            return false;
        }
        std::ifstream file(file_path, mode);
        if (!file || !file.is_open()) {
            throw std::runtime_error("无法打开文件: " + file_path);
        }

        std::vector<std::string> contents = file::ReadLines(file_path);
        if (contents.empty()) {
            std::cerr << "read file failed or file is empty" << std::endl;
            return false;
        }
        parsed_pbs->clear();
        parsed_pbs->reserve(contents.size());

        switch (file_format) {
            case PbFormat::kBase64: {
                for (const auto &content: contents) {
                    PbType pb{};
                    butil::StringPiece sp{content};
                    std::string decoded_str;
                    bool decode_ret = butil::Base64Decode(sp, &decoded_str);
                    if (!decode_ret) {
                        std::cerr << "decode base64 failed" << std::endl;
                    }
                    if (!pb.ParseFromString(decoded_str)) {
                        std::cerr << "parse proto failed" << std::endl;
                        return false;
                    }
                    parsed_pbs->emplace_back(std::move(pb));
                }
                break;
            }

            case PbFormat::kJson: {
                for (const auto &content: contents) {
                    PbType pb{};
                    std::string err_msg{};
                    json2pb::Json2PbOptions opts;
                    opts.base64_to_bytes = false;
                    bool success = json2pb::JsonToProtoMessage(content, &pb, opts, &err_msg);
                    if (!success) {
                        std::cerr << "json convert to proto failed, error message: " << err_msg << std::endl;
                        return false;
                    }
                    parsed_pbs->emplace_back(std::move(pb));
                }
                break;
            }

            default:
                return false;
        }
        return true;
    }

    template<typename PbType>
    bool SavePbToFile(const std::string &file_path, const std::vector<PbType> &pbs,
                      PbFormat file_format = PbFormat::kJson) {
        std::ios_base::openmode mode = std::ios::out;
        if (file_format == PbFormat::kRawBinary) {
            std::cerr << "can not write raw binary by lines" << std::endl;
            return false;
        }
        std::ofstream output_file(file_path, mode);
        if (!output_file.is_open()) {
            std::cerr << "can not open file " << file_path << std::endl;
            return false;
        }
        output_file.clear();

        switch (file_format) {
            case PbFormat::kBase64: {
                for (const auto &pb: pbs) {
                    std::string binary_str;
                    if (!pb.SerializeToString(&binary_str)) {
                        return false;
                    }
                    std::string base64_encoded{};
                    butil::Base64Encode(binary_str, &base64_encoded);
                    output_file << base64_encoded << std::endl;
                }
                break;
            }

            case PbFormat::kJson: {
                for (const auto &pb: pbs) {
                    std::string err;
                    json2pb::Pb2JsonOptions opt;
                    opt.bytes_to_base64 = false;
                    std::string content;
                    bool success = json2pb::ProtoMessageToJson(pb, &content, opt, &err);
                    if (!success) {
                        std::cerr << "proto to json failed, error message: " << err << std::endl;
                        return false;
                    }
                    output_file << content << std::endl;
                }
                break;
            }

            default:
                return false;
        }

        output_file.close();
        return true;
    }

    template<typename PbType>
    bool SavePbToFile(const std::string &file_path, const PbType &pb, PbFormat file_format = PbFormat::kJson) {
        std::ios_base::openmode mode = std::ios::out;
        std::string content;

        switch (file_format) {
            case PbFormat::kRawBinary: {
                mode |= std::ios::binary;
                if (!pb.SerializeToString(&content)) {
                    std::cout << "SerializeToString failed!" << std::endl;
                    return false;
                }
                break;
            }

            case PbFormat::kBase64: {
                std::string binary_str;
                if (!pb.SerializeToString(&binary_str)) {
                    return false;
                }
                std::string base64_encoded{};
                butil::Base64Encode(binary_str, &content);
                break;
            }

            case PbFormat::kJson: {
                std::string data, err;
                json2pb::Pb2JsonOptions opt;
                opt.bytes_to_base64 = false;
                bool success = json2pb::ProtoMessageToJson(pb, &content, opt, &err);
                if (!success) {
                    std::cerr << "proto to json failed, error message: " << err << std::endl;
                    return false;
                }
                break;
            }

            default:
                return false;
        }

        try {
            std::cout << "start write to file; content length = " << content.length() << std::endl;
            file::WriteToFile(file_path, content);
        } catch (const std::exception &exception) {
            std::cerr << std::string{"save file failed: "} + exception.what() << std::endl;
            return false;
        }
        return true;
    }
}// namespace debug::pb