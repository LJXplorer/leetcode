#include "file_scanner.h"
#include <exception>
#include <filesystem>
#include <string>
namespace common {

    FileScanner::FileScanner(const std::string &folder_path, const std::string &success_token)
        : folder_path_(folder_path), success_token_(success_token) {
    }


    bool FileScanner::SafeScan(long *version, std::string *scanned_abs_path, long cur_version) {
        namespace fs = std::filesystem;
        fs::path dir_path(folder_path_);
        long scanned_version = cur_version;
        std::string scanned_version_str;
        if (fs::exists(dir_path) && fs::is_directory(dir_path)) {
            for (const auto &entry: fs::directory_iterator(dir_path)) {
                if (entry.is_directory()) {
                    fs::path success_token_file = entry.path() / success_token_;
                    if (!fs::exists(success_token_file)) {
                        continue;
                    }
                    std::string version_str = entry.path().filename().string();
                    try {
                        long this_dir_version = std::stol(version_str);
                        if (this_dir_version > scanned_version) {
                            scanned_version_str = version_str;
                            scanned_version = this_dir_version;
                        }
                    } catch (const std::exception &ignored) {
                    }
                }
            }
            if (scanned_version > cur_version) {
                auto max_version_path = dir_path / scanned_version_str;
                *version = scanned_version;
                *scanned_abs_path = fs::absolute(max_version_path).string();
                return true;
            }
        } else {
            std::cerr << "folder path = [" << folder_path_ << "] is not exists or is not a directory, just skip\n";
        }
        return false;
    }

}// namespace common