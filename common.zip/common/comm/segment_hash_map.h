#pragma once
// 定义 SegmentedHashMap 类
#include <butil/containers/flat_map.h>
#include <cstddef>
#include <functional>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <unordered_map>
#include <vector>
// 基础模板，默认为 false
template<typename T>
struct is_flat_map : std::false_type {};

// 特化模板，检测 butil::FlatMap
template<typename KeyType, typename ValueType, typename HashFunction, typename KeyEqual>
struct is_flat_map<butil::FlatMap<KeyType, ValueType, HashFunction, KeyEqual>> : std::true_type {};
enum class LockType {
    NOLOCK,
    WRITE_LOCK,
    READ_WRITE_LOCK,
};
/**
 * @brief 分段哈希映射容器（线程安全可选）
 * @tparam Key 键类型
 * @tparam Value 值类型
 * @tparam Hash 哈希函数类型（默认std::hash<Key>）
 * @tparam KeyEqual 键相等判断类型（默认std::equal_to<Key>）
 * @tparam Map 底层容器类型（默认std::unordered_map）
 * @tparam lock_type 锁类型（默认无锁）
 */
template<typename Key, typename Value, typename Hash = std::hash<Key>, typename KeyEqual = std::equal_to<Key>,
         typename Map = std::unordered_map<Key, Value, Hash, KeyEqual>, LockType lock_type = LockType::NOLOCK>
class SegmentedHashMap {
private:
    std::vector<Map> segments_;
    std::vector<std::unique_ptr<std::mutex>> segment_locks_;
    std::vector<std::unique_ptr<std::shared_mutex>> segment_shared_locks_;
    Hash hash_;
    KeyEqual key_equal_;
    size_t segment_count_;
    size_t second_bucket_size_;
    double load_factor_;

public:
    static constexpr size_t kDefaultSegmentCount = 17;
    static constexpr size_t kDefaultSecondBucketSize = 0;
    static constexpr size_t kDefaultFlatmapBucketSize = 97;
    static constexpr double kDefaultLoadFactor = -1.0;
    /**
     * @brief 构造函数
     * @param segment_count 哈希表分段数量（默认17）
     * @param second_bucket_size 二级哈希桶初始大小（默认不设置,对于butil::FlatMap设置为97）
     * @param load_factor 负载因子（默认-1表示不设置）
     * @param hash 哈希函数对象
     * @param eq 键相等比较函数对象
     *
     */
    explicit SegmentedHashMap(size_t segment_count = kDefaultSegmentCount,
                              size_t second_bucket_size = kDefaultSecondBucketSize,
                              double load_factor = kDefaultLoadFactor, const Hash &hash = Hash(),
                              const KeyEqual &eq = KeyEqual())
        : hash_(hash), key_equal_(eq), segment_count_(segment_count), second_bucket_size_(second_bucket_size),
          load_factor_(load_factor) {
        //初始化map
        if constexpr (is_flat_map<Map>::value) {
            segments_.resize(segment_count);
            if (second_bucket_size_ == 0) {
                second_bucket_size_ = kDefaultFlatmapBucketSize;
            }
            int bucket_count = static_cast<int>(second_bucket_size_);
            if (load_factor_ > 0) {
                int load_factor_int = static_cast<int>(100 * load_factor);
                for (auto &seg: segments_) {
                    // 初始化哈希桶数量和负载因子
                    seg.init(bucket_count, load_factor_int);
                }
            } else {
                for (auto &seg: segments_) {
                    // 初始化哈希桶数量
                    seg.init(bucket_count);
                }
            }
        } else {
            if (second_bucket_size != 0) {
                segments_.resize(segment_count, Map(second_bucket_size));
            } else {
                segments_.resize(segment_count, Map());
            }
            
            if (load_factor_ > 0) {
                for (auto &seg: segments_) {
                    // 初始化负载因子
                    seg.max_load_factor(load_factor_);
                }
            }
        }

        //初始化段对应的锁
        if constexpr (lock_type == LockType::WRITE_LOCK) {
            for (size_t i = 0; i < segment_count_; i++) {
                segment_locks_.emplace_back(std::make_unique<std::mutex>());
            }

        } else if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            for (size_t i = 0; i < segment_count_; i++) {
                segment_shared_locks_.emplace_back(std::make_unique<std::shared_mutex>());
            }
        }
    }
    /**
     * @brief 插入或更新键值对
     * @param key 要插入的键
     * @param value 要插入的值
     * @return Value* 指向已存在或新建值的指针
     * @note 线程安全策略：
     *       - WRITE_LOCK模式使用互斥锁
     *       - READ_WRITE_LOCK模式使用写锁
     *       - NOLOCK模式无锁操作
     */
    Value *Insert(const Key &key, const Value &value) {
        if constexpr (lock_type == LockType::WRITE_LOCK) {
            std::lock_guard lock{*(segment_locks_[hash_(key) % segment_count_])};
            return InsertNoLock(key, value);
        } else if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            std::unique_lock write_lock{*(segment_shared_locks_[hash_(key) % segment_count_])};
            return InsertNoLock(key, value);
        } else {
            return InsertNoLock(key, value);
        }
    }

    /**
     * @brief 查找键对应的值（非常量版本）
     * @param key 要查找的键
     * @return Value* 找到的值指针，找不到返回nullptr
     * @note 在READ_WRITE_LOCK模式下使用读锁
     */
    Value *Find(const Key &key) {
        if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            std::shared_lock read_lock{*(segment_shared_locks_[hash_(key) % segment_count_])};
            return FindNolock(key);
        } else {
            return FindNolock(key);
        }
    }
    /**
     * @brief 查找键对应的值（常量版本）
     * @param key 要查找的键
     * @return const Value* 找到的值指针，找不到返回nullptr
     * @note 在READ_WRITE_LOCK模式下使用读锁
     */
    const Value *Find(const Key &key) const {
        if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            std::shared_lock read_lock{*(segment_shared_locks_[hash_(key) % segment_count_])};
            return FindNolock(key);
        } else {
            return FindNolock(key);
        }
    }

    /**
     * @brief 下标运算符重载
     * @param key 要访问的键
     * @return Value& 对应键的引用（不存在时会创建默认值）
     * @warning 可能改变容器结构，在加锁模式下使用写锁
     */
    Value &operator[](const Key &key) {
        auto &segment = GetSegment(key);
        if constexpr (lock_type == LockType::WRITE_LOCK) {
            std::lock_guard<std::mutex> lock{*(segment_locks_[hash_(key) % segment_count_])};
            return segment[key];
        } else if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            std::unique_lock write_lock{*(segment_shared_locks_[hash_(key) % segment_count_])};
            return segment[key];
        } else {
            return segment[key];
        }
    }

    /**
     * @brief 删除指定键的元素
     * @param key 要删除的键
     * @return bool 是否成功删除
     * @note 线程安全策略与Insert()相同
     */
    bool Erase(const Key &key) {
        if constexpr (lock_type == LockType::WRITE_LOCK) {
            std::lock_guard lock{*(segment_locks_[hash_(key) % segment_count_])};
            return EraseNoLock(key);
        } else if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            std::unique_lock write_lock{*(segment_shared_locks_[hash_(key) % segment_count_])};
            return EraseNoLock(key);
        } else {
            return EraseNoLock(key);
        }
    }

    /**
     * @brief 遍历所有元素并对每个键值对执行指定操作（常量版本）
     * @tparam Func 可调用对象类型，需接受(const Key&, const Value&)参数
     * @param func 要执行的可调用对象
     * @note 线程安全策略：
     *  - READ_WRITE_LOCK模式下使用共享读锁分段遍历
     *  - 其他模式直接无锁遍历
     *
     */
    template<typename Func>
    void ForEach(Func &&func) const {
        if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            // 读写锁模式使用共享读锁
            for (size_t i = 0; i < segment_count_; ++i) {
                std::shared_lock<std::shared_mutex> lock(*segment_shared_locks_[i]);
                for (const auto &[key, value]: segments_[i]) {
                    func(key, value);
                }
            }
        } else {
            // 无锁模式直接遍历
            for (const auto &seg: segments_) {
                for (const auto &[key, value]: seg) {
                    func(key, value);
                }
            }
        }
    }

    /**
     * @brief 遍历所有元素并对每个键值对执行指定操作（非常量版本）
     * @tparam Func 可调用对象类型，需接受(const Key&, Value&)参数
     * @param func 要执行的可调用对象
     * @note 线程安全策略：
     *  - WRITE_LOCK模式下使用互斥锁分段遍历
     *  - READ_WRITE_LOCK模式下使用共享读锁分段遍历
     *  - NOLOCK模式直接无锁遍历
     */
    template<typename Func>
    void ForEach(Func &&func) {
        // 根据锁类型进行不同处理
        if constexpr (lock_type == LockType::WRITE_LOCK) {
            // 写锁模式需要获取所有段的互斥锁
            for (size_t i = 0; i < segment_count_; ++i) {
                std::lock_guard<std::mutex> lock(*segment_locks_[i]);
                for (auto &[key, value]: segments_[i]) {
                    const auto &const_key = key;
                    func(const_key, value);
                }
            }
        } else if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            // 读写锁模式使用共享读锁
            for (size_t i = 0; i < segment_count_; ++i) {
                std::shared_lock<std::shared_mutex> lock(*segment_shared_locks_[i]);
                for (auto &[key, value]: segments_[i]) {
                    const auto &const_key = key;
                    func(const_key, value);
                }
            }
        } else {
            // 无锁模式直接遍历
            for (auto &seg: segments_) {
                for (auto &[key, value]: seg) {
                    const auto &const_key = key;
                    func(const_key, value);
                }
            }
        }
    }

    /**
     * @brief 清空所有分段数据
     * @note 在加锁模式下会对每个段依次加锁清空
     * @warning 清空操作期间会逐个锁定段，可能影响并发性能
     */
    void Clear() {
        if constexpr (lock_type == LockType::WRITE_LOCK) {
            for (size_t i = 0; i < segment_count_; i++) {
                std::lock_guard<std::mutex> lock{*(segment_locks_[i])};
                segments_[i].clear();
            }
        } else if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            for (size_t i = 0; i < segment_count_; i++) {
                std::unique_lock write_lock{*(segment_shared_locks_[i])};
                segments_[i].clear();
            }
        } else {
            ClearNolock();
        }
    }

    /**
     * @brief 批量插入容器元素
     * @tparam InputMap 输入容器类型（需支持begin/end迭代器）
     * @param input_map 输入容器的引用
     * @note 采用两阶段插入策略：
     *       1. 无锁预分段：根据哈希值将元素分配到段组
     *       2. 加锁批量插入：对每个非空段组获取锁后批量插入
     * @warning 输入容器的迭代器有效性需自行保证
     */
    template<typename InputMap>
    void Insert(const InputMap &input_map) {
        using IteratorType = decltype(input_map.begin());
        // 第一阶段：输入map分段
        std::vector<std::vector<IteratorType>> segment_groups(segment_count_);
        // 遍历输入map进行分段
        for (auto iter = input_map.begin(); iter != input_map.end(); iter++) {
            const auto &[key, value] = *iter;
            const size_t seg_idx = hash_(key) % segment_count_;
            segment_groups[seg_idx].emplace_back(iter);
        }
        // 第二阶段：获得分段锁后写入
        // case1:只加写锁的情况下写入
        if constexpr (lock_type == LockType::WRITE_LOCK) {
            for (size_t i = 0; i < segment_count_; i++) {
                auto &segment_group_to_add = segment_groups[i];
                if (!segment_group_to_add.empty()) {
                    std::lock_guard<std::mutex> lock{*(segment_locks_[i])};
                    auto &seg = segments_[i];
                    for (const auto &kv: segment_group_to_add) {
                        const auto &[k, v] = *kv;
                        seg[k] = v;
                    }
                }
            }
            // case2: 加读写锁后写入
        } else if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            for (size_t i = 0; i < segment_count_; i++) {
                auto &segment_group_to_add = segment_groups[i];
                if (!segment_group_to_add.empty()) {
                    std::unique_lock lock{*(segment_shared_locks_[i])};
                    auto &seg = segments_[i];
                    for (const auto &kv: segment_group_to_add) {
                        const auto &[k, v] = *kv;
                        seg[k] = v;
                    }
                }
            }
            // 不加锁的话直接写入
        } else {
            for (size_t i = 0; i < segment_count_; i++) {
                auto &segment_group_to_add = segment_groups[i];
                if (!segment_group_to_add.empty()) {
                    auto &seg = segments_[i];
                    for (const auto &kv: segment_group_to_add) {
                        const auto &[k, v] = *kv;
                        seg[k] = v;
                    }
                }
            }
        }
    }

    [[nodiscard]] size_t Size() const noexcept {
        if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            size_t total = 0;
            for (size_t i = 0; i < segment_count_; i++) {
                std::shared_lock read_lock{*(segment_shared_locks_[i])};
                const auto &seg = segments_[i];
                total += seg.size();
            }
            return total;
        } else {
            return SizeNolock();
        }
    }
    [[nodiscard]] bool Empty() const noexcept {
        if constexpr (lock_type == LockType::READ_WRITE_LOCK) {
            for (size_t i = 0; i < segment_count_; i++) {
                std::shared_lock read_lock{*(segment_shared_locks_[i])};
                const auto &seg = segments_[i];
                if (seg.empty()) {
                    return true;
                }
            }
            return false;
        } else {
            return EmptyNolock();
        }
    }

    // 扩展接口
    [[nodiscard]] size_t SegmentCount() const noexcept {
        return segment_count_;
    }

    // 获取对应的哈希段(非const版本)，线程不安全
    Map &GetSegment(const Key &key) {
        size_t hash_value = hash_(key);
        return segments_[hash_value % segment_count_];
    }

    // 获取对应的哈希段（const版本），线程不安全
    const Map &GetSegment(const Key &key) const {
        size_t hash_value = hash_(key);
        return segments_[hash_value % segment_count_];
    }

    // 获取所有哈希段（const版本），线程不安全
    const std::vector<Map> &GetSegment() const {
        return segments_;
    }

private:
    // 插入元素
    Value *InsertNoLock(const Key &key, const Value &value) {
        auto &segment = GetSegment(key);
        Value &old_value = segment[key];
        old_value = value;
        return &old_value;
    }

    // 查找元素（非const版本）
    Value *FindNolock(const Key &key) {
        auto &segment = GetSegment(key);
        if constexpr (is_flat_map<Map>::value) {
            // 针对flat_map的特化查询
            return segment.seek(key);
        } else {
            auto it = segment.find(key);
            return (it != segment.end()) ? &it->second : nullptr;
        }
    }

    const Value *FindNolock(const Key &key) const {
        const auto &segment = GetSegment(key);
        if constexpr (is_flat_map<Map>::value) {
            return const_cast<Map &>(segment).seek(key);
        } else {
            auto it = segment.find(key);
            return (it != segment.end()) ? &it->second : nullptr;
        }
    }

    // 删除元素
    bool EraseNoLock(const Key &key) {
        auto &segment = GetSegment(key);
        return segment.erase(key) > 0;
    }

    void ClearNolock() {
        for (auto &seg: segments_) {
            seg.clear();
        }
    }

    [[nodiscard]] size_t SizeNolock() const noexcept {
        size_t total = 0;
        for (const auto &segment: segments_) {
            total += segment.size();
        }
        return total;
    }
    [[nodiscard]] bool EmptyNolock() const noexcept {
        for (const auto &segment: segments_) {
            if (!segment.empty())
                return false;
        }
        return true;
    }
};