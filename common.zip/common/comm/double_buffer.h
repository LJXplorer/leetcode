#ifndef _COMMON_DBUFFER_H
#define _COMMON_DBUFFER_H
#include <atomic>
#include <memory>
#include <vector>

template<typename T>
class DBuffer {
private:
    std::vector<std::shared_ptr<T>> vec;
    std::atomic<uint8_t> index;
public:
    DBuffer() {
        vec.resize(2);
        vec[0].reset(new T());
        vec[1].reset(new T());
        index = 0;
    }

    std::shared_ptr<T> get_current_obj() {
        return vec[index.load()];
    }

    std::shared_ptr<T> get_bak_obj() {
        return vec[1 - index.load()];
    }

    void change() {
        index.store(1 - index.load());
    }

    std::atomic<uint8_t>* get_index_ptr() {
        return &index;
    }

    int get_cur_index() {
        return index.load();
    }
};

#endif