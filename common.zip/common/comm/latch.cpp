#include "latch.h"
namespace common {
        void SimpleLatch::CountDown() {
            std::unique_lock<std::mutex> lock(mutex_);
            if (count_ > 0) {
                --count_;
                if (count_ <= 0) {
                    cv_.notify_all();
                }
            }
        }
        void SimpleLatch::Wait(){
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait(lock, [this]() { return count_ <= 0; });
        }


}