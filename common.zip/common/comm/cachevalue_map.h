#pragma once

#include "concurrent_map.h"
#include "segment_hash_map.h"
#include <boost/unordered/unordered_flat_map.hpp>
#include <boost/unordered/unordered_flat_map_fwd.hpp>
#include <butil/containers/flat_map.h>
#include <butil/time.h>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <vector>
namespace common {

    template<typename Key, typename Value>
    class CacheValueMap {
        using ValueWrapperPtr = std::shared_ptr<CacheValue<Value>>;

    private:
        /**
         * @brief kDefaultCacheSecondBucketSize与kDefaultCacheSegmentSize的计算过程:
         * cache保存的最大的元素个数为1800000左右, 1361与1327为最接近的两个质数，其乘积为1806047
         * 
         */
        static constexpr size_t kDefaultCacheSecondBucketSize = 1361;
        static constexpr size_t kDefaultCacheSegmentSize = 1327;
        SegmentedHashMap<Key, ValueWrapperPtr, std::hash<Key>, std::equal_to<>, butil::FlatMap<Key, ValueWrapperPtr>,
                         LockType::WRITE_LOCK>
                map_{.segment_count = kDefaultCacheSegmentSize, .second_bucket_size = kDefaultCacheSecondBucketSize};

    public:
        void put(const Key &key, ValueWrapperPtr &v) {
            map_[key] = v;
        }

        void put(const std::unordered_map<Key, ValueWrapperPtr> &map) {
            map_.Insert(map);
        }

        std::shared_ptr<std::unordered_map<Key, Value>> get(const std::vector<Key> &key_vec,
                                                            std::vector<Key> &timeout_vec) const {
            auto result = std::make_shared<std::unordered_map<Key, Value>>(key_vec.size());
            for (const auto &key: key_vec) {
                if (auto it = map_.Find(key); it != nullptr) {
                    auto &value_wrapper = *it;
                    result->insert({key, value_wrapper->get_val()});
                    int64_t cur_tm = butil::gettimeofday_s();
                    if (value_wrapper->expire() && value_wrapper->expire() < cur_tm) {
                        timeout_vec.push_back(key);
                    }
                }
            }
            return result;
        };

        std::shared_ptr<CacheValue<Value>> get(const Key &key) {
            if (auto it = map_.Find(key); it != nullptr) {
                int64_t cur_tm = butil::gettimeofday_s();
                auto &value_wrapper = *it;
                if (value_wrapper->expire() == 0 || value_wrapper->expire() > cur_tm) {
                    return value_wrapper;
                }
                return nullptr;
            }
            return nullptr;
        }

        void keys(std::vector<std::string> &valid_keys, std::vector<std::string> &expire_keys) {
            int64_t cur_tm = butil::gettimeofday_s();
            const auto &segments = map_.GetSegment();
            for (const auto &seg: segments) {
                for (const auto &[key, cahce_value]: seg) {
                    if (cahce_value->timestamp && cahce_value->timestamp < cur_tm) {
                        expire_keys.emplace_back(key);
                    } else {
                        valid_keys.emplace_back(key);
                    }
                }
            }
        };

        [[nodiscard]] size_t size() const {
            return map_.Size();
        }
    };
}// namespace common