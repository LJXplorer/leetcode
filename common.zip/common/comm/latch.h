#pragma once
#include <condition_variable>
#include <cstdint>
#include <mutex>

namespace common {
    class SimpleLatch {
    public:
        explicit SimpleLatch(int64_t count) : count_(count) {
        }

        // 递减计数器，计数器为0时通知所有等待线程
        void CountDown();

        // 等待计数器变为0
        void Wait();

    private:
        int64_t count_;
        std::mutex mutex_;
        std::condition_variable cv_;
    };
}// namespace common
