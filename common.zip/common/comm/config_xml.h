﻿
#ifndef _HLFRAME_CONFIG_XML_H_
#define _HLFRAME_CONFIG_XML_H_

#include <string>
#include "boost/lexical_cast.hpp"
#include "tinyxml2.h"
#include <memory>
#include <vector>
    class ConfigXml {
    private:

        tinyxml2::XMLDocument _xml;//所有_node及其子_node归这个管
        tinyxml2::XMLElement* _node;
    public:
        explicit ConfigXml()
            : _node(NULL) {
        }
        explicit ConfigXml(const std::string& path) {
            init(path);
        }
        explicit ConfigXml(const ConfigXml& para) {
            _node = para._node;
        }
        explicit ConfigXml(ConfigXml&& para) {
            _node = para._node;
            para._node = NULL;
        }

        void init(const std::string& path);
        const tinyxml2::XMLElement* node() const;
        bool child(const std::string& name, ConfigXml& out) const;
        template<class T>
        bool attr(const std::string& name, T& out) const {
            const tinyxml2::XMLAttribute* a = _node->FindAttribute(name.c_str());
            if (a) {
                out = boost::lexical_cast<T>(a->Value());
                return true;
            }
            return false;
        }
        template<class T>
        bool attr(const std::string& name, T& out, const T& default_value) const {
            bool ret = attr(name, out);
            if (!ret) {
                out = default_value;
            }
            return ret;
        }
        bool  parse(const std::string&data);
        bool next(ConfigXml& out) const;
        bool next(const std::string& name, ConfigXml& out) const;
        bool find(const std::string& name, ConfigXml& out) const;
        bool name(std::string& out) const;
	    template<typename T>
        bool Get2dArray(const std::string& prop_name, const std::string& first_level_name, const std::string& second_level_name, std::vector<std::vector<T>>& result) {
            auto* node = _node->FirstChildElement(prop_name.c_str());
            auto* first_level_element = node->FirstChildElement(first_level_name.c_str());
            if (first_level_element == nullptr) {
                return false;
            }
            while(first_level_element) {
                std::vector<T> second_level_vals{};
                auto* second_level_element = first_level_element->FirstChildElement(second_level_name.c_str());
                while(second_level_element) {
                    T val = boost::lexical_cast<T>(second_level_element->Value());
                    second_level_vals.emplace_back(val);
                    second_level_element = first_level_element->NextSiblingElement(second_level_name.c_str());
                }
                first_level_element = first_level_element->NextSiblingElement(first_level_name.c_str());
                if (!second_level_vals.empty()) {
                    result.emplace_back(second_level_vals);
                }
            }
            return !result.empty();
        }

    };

    using ConfigXmlPtr = std::shared_ptr<ConfigXml>;



#endif
