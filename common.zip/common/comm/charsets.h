#pragma once
#include <iostream>
#include <string>
#include <iconv.h>
namespace charsets {
    int to_88591(const char* src,int32_t src_size,std::string &dst);
}