#pragma once

#include "nacos/Nacos.h"
#include <functional>
#include <ostream>
#include <thread>
#include "log_helper.h"
namespace nacos {
class NacosConfigListnerAdapter : public nacos::Listener {
private:
  std::function<void(const std::string &)> updater_;
  std::string data_id_;

public:
  NacosConfigListnerAdapter(std::function<void(const std::string &)> updater, const std::string& data_id)
      : updater_(updater), data_id_(data_id) {}

  void receiveConfigInfo(const NacosString &configInfo) override {

    HILOG_APP(INFO) << "thread_id = " << std::this_thread::get_id()
              << "data_id = " << data_id_  << " receive config info ,start update" ;
    if (updater_) {
      updater_(configInfo);
    } else {
      HILOG_APP(WARNING) << "updater is null! just skip config update";
    }
  }
};
} // namespace nacos