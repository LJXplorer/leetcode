#pragma once
#include <string>
namespace config {
struct ConfigServiceCfg {
  std::string server_adder;
  std::string auth_user_name;
  std::string auth_passwd;
  std::string name_space;

  bool operator==(const ConfigServiceCfg &other) const {
    return server_adder == other.server_adder &&
           auth_user_name == other.auth_user_name &&
           auth_passwd == other.auth_passwd && name_space == other.name_space;
  }
};

struct NacosInitConfigHash {
  std::size_t operator()(const ConfigServiceCfg &config) const {
    return std::hash<std::string>()(config.server_adder) ^
           std::hash<std::string>()(config.auth_user_name) ^
           std::hash<std::string>()(config.auth_passwd) ^
           std::hash<std::string>()(config.name_space);
  }
};

} // namespace config
