#pragma once
#include "base_config.h"
#include "common/hilog/log_helper.h"
#include "error_code.h"
#include "nacos/Nacos.h"
#include "nacos/config/ConfigService.h"
#include "nacos_config_listner_adapter.h"
#include "nlohmann/json.hpp"
#include "service_config.h"
#include <boost/type_index.hpp>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>

namespace {

const std::string kNacosServerAdder{
    "servicecenter-test-drcn.inner.platform.cloud.hihonor.com"};
const std::string kNacosAuthUserName{"SearchRecommend"};
const std::string kNacosAuthPassword{"SearchRecommend@123"};
const std::string kNacosNameSpace{"03d7e4fc-a6c7-4a8a-b696-874d6915bad0"};

} // namespace
namespace config {
namespace fs = std::filesystem;
class ConfigManager {
public:
  ConfigManager(const ConfigManager &) = delete;
  ConfigManager &operator=(const ConfigManager &) = delete;

  static ConfigManager &getInstance() {
    static ConfigManager instance;
    return instance;
  }

  RegisterResponse RegisterConfig(const ConfigServiceCfg &nacos_config,
                      std::shared_ptr<ListenableConfig> listenable_config) {
    if (listenable_config.get() == nullptr) {
      std::cerr << "register config is null"
                       << "error code:"
                       << static_cast<long>(RegisterResponse::kInputConfigIsNull);
      return RegisterResponse::kInputConfigIsNull;
    }
    nacos::ConfigService *config_service = nullptr;
    {
      std::lock_guard<std::mutex> lock(reg_mutex_);
      auto iter = service_map_.find(nacos_config);

      if (iter == service_map_.end()) {
        try {
          auto props = GetProperties(nacos_config);
          
          const auto factory =
              nacos::NacosFactoryFactory::getNacosFactory(props);
          config_service = factory->CreateConfigService();
          if (config_service != nullptr) {
            service_map_.insert({nacos_config, config_service});
          }
        } catch (const nacos::NacosException &e) {
          std::cerr << "get nacos config service failed, exception = "
                           << e.what()
                           << "; nacos excpetion code = " << e.errorcode();
        }
      } else {
        config_service = iter->second;
      }
    }

    if (config_service == nullptr) {
      std::cerr << "nacos config service is null"
                       << "error code:"
                       << static_cast<long>(RegisterResponse::kNacosConfigServiceNull);
      return RegisterResponse::kNacosConfigServiceNull;
    }

    const ConfigSource config_source = listenable_config->GetConfigSource();
    const std::string data_id = config_source.data_id;
    const std::string group_id = config_source.group_id;
    std::string config_content =
        config_service->getConfig(data_id, group_id, 1000);

    //初始化config
    if(listenable_config->OnConfigChanged(config_content) != 0) {
      return RegisterResponse::kInitConfigFailed;
    }

    auto updater = [listenable_config](const std::string &new_config_content) {
      listenable_config->OnConfigChanged(new_config_content);
    };
    nacos::Listener * configListner =
        new nacos::NacosConfigListnerAdapter(updater, data_id);
    {
      std::lock_guard<std::mutex> lock(reg_mutex_);
      config_service->addListener(data_id, group_id, configListner);
    }
    return RegisterResponse::kSuccess;
  }

private:
  ConfigManager() { std::cerr << "ConfigManager initialized!"; }
  bool GetPropertiesFromLocalConfig(nacos::Properties &props) {
    nlohmann::json json_container{};
    fs::path nacos_config_path{"config/nacos_config.json"};
    std::ifstream file_stream(nacos_config_path);
    if (fs::exists(nacos_config_path) &&
        fs::is_regular_file(nacos_config_path) && file_stream) {
      file_stream >> json_container;
      try {
        props[nacos::PropertyKeyConst::SERVER_ADDR] =
            json_container.at("server_adder");
        props[nacos::PropertyKeyConst::AUTH_USERNAME] =
            json_container.at("user_name");
        props[nacos::PropertyKeyConst::AUTH_PASSWORD] =
            json_container.at("password");
        props[nacos::PropertyKeyConst::NAMESPACE] =
            json_container.at("namespace");
        return true;
      } catch (const nlohmann::json::out_of_range& e) {
        std::cerr << "parse json failed, e = " << e.what();
        return false;
      }
    } else {
      std::cerr << "nacos config file not exists; path = "
                         << nacos_config_path;
    }
    return false;
  }
  nacos::Properties GetProperties() {
    nacos::Properties props;
    bool get_config_from_file = GetPropertiesFromLocalConfig(props);
    if (!get_config_from_file) {
      props.clear();
      props[nacos::PropertyKeyConst::SERVER_ADDR] = kNacosServerAdder;
      props[nacos::PropertyKeyConst::AUTH_USERNAME] = kNacosAuthUserName;
      props[nacos::PropertyKeyConst::AUTH_PASSWORD] = kNacosAuthPassword;
      props[nacos::PropertyKeyConst::NAMESPACE] = kNacosNameSpace;
    }
    return props;
  }

  nacos::Properties GetProperties(const ConfigServiceCfg &config) {
    nacos::Properties props;
    props[nacos::PropertyKeyConst::SERVER_ADDR] = config.server_adder;
    props[nacos::PropertyKeyConst::AUTH_USERNAME] = config.auth_user_name;
    props[nacos::PropertyKeyConst::AUTH_PASSWORD] = config.auth_passwd;
    props[nacos::PropertyKeyConst::NAMESPACE] = config.name_space;
    return props;
  }

  ~ConfigManager() { HILOG_APP(INFO) << "ConfigManager destroyed!"; }

  std::unordered_map<ConfigServiceCfg, nacos::ConfigService *,
                     NacosInitConfigHash>
      service_map_;
  std::mutex reg_mutex_{};
};
} // namespace config
