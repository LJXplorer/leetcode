# nacos配置管理器
将需要监听变化的配置注册到ConfigManager中。示例代码如下
```c++
// 需要继承ListenableConfig，并实现监听回调函数和对应的配置文件在nacos上的data_id与group_id
struct TestNacosChangeConfig : public config::ListenableConfig {
  std::string content;
  int OnConfigChanged(const std::string &new_config) {
    spdlog::info("in change callback, new content = {}", new_config);
    content = new_config;
  }

  config::ConfigSource GetConfigSource() {
    return {.group_id = "SIMPLE_SEARCH_RECOMMEND",
            .data_id = "engine_config_test.json"};
  }
};
```
注册TestNacosChangeConfig到ConfigManager中
```c++
  //提供注册到的nacos配置中心的账号密码等参数
  config::ConfigServiceCfg cfg{
      .server_adder =
          "servicecenter-test-drcn.inner.platform.cloud.hihonor.com",
      .auth_user_name = "SearchRecommend",
      .auth_passwd = "SearchRecommend@123",
      .name_space = "03d7e4fc-a6c7-4a8a-b696-874d6915bad0"

  };
  auto ptr = std::make_shared<TestNacosChangeConfig>();
  config::ConfigManager::getInstance().RegisterConfig(cfg, ptr);
```