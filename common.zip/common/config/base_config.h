#pragma once
#include <string>

namespace config {
struct ConfigSource {
  std::string group_id;
  std::string data_id;
};
struct ListenableConfig {
  /**
   * @brief 当nacos配置发生变化时的回调
   *
   * @param new_config 变化后的配置文件内容
   */
  virtual int OnConfigChanged(const std::string &new_config) = 0;
  /**
   * @brief 获得当前配置项在nacos上的dataId和groupId
   * @return 配置项的dataId和groupId
   */
  virtual ConfigSource GetConfigSource() = 0;
};
} // namespace config
