#pragma once
namespace config {
        enum class RegisterResponse : long{
                /**
                 * 注册成功
                 */
                kSuccess = 0,
                /**
                 * 通过注册配置拿到的配置服务为空
                 */
                kNacosConfigServiceNull = 90000, 
                /**
                 * 输入的配置服务指针为空
                 */
                kInputConfigIsNull = 90001, 
                /**
                 * 初始化配置失败
                 */
                kInitConfigFailed = 90002, 

	};
}