#include <tinyxml2.h>
#include <boost/container/flat_map.hpp>
#include "kafka_producer.h"
#include "common/config/base_config.h"
#include "common/config/service_config.h"
#include "log_helper.h"
#include <mutex>

namespace hikafka {
    using namespace std;
    using namespace boost;
    class KafkaHelper {
        public:
            KafkaHelper();
            ~KafkaHelper();

            KafkaProducer* getProducer(const string name);
            bool sendMsg(const string name, const string key, const string value);
            bool sendMsg(const string& name, KafkaMessage* kafkaMessage);
            bool addProducer(const string name, std::shared_ptr<KafkaProducer> kafkaProducer);
            static KafkaHelper& getInstance() {
                static KafkaHelper instance;
                return instance;
            }
            void  createProducer(const tinyxml2::XMLDocument& cacheConf);
            void init(const tinyxml2::XMLDocument& cacheConf) ;

            int new_init(const config::ConfigServiceCfg& cfg,
                        const std::string& group_id,
                        const std::string& data_id);
            int update(const std::string& content);

        private:
             boost::container::flat_map<string, std::shared_ptr<KafkaProducer>> _producer_map;
             std::mutex _mtx;
             
    };


    struct KafkaNacosConfig : public config::ListenableConfig {
        std::string group_id;
        std::string data_id;


        KafkaNacosConfig(const std::string& group_id, const std::string& data_id)
            : group_id(group_id), data_id(data_id) {}

        int OnConfigChanged(const std::string& new_config) override {
            std::cout << "kafka nacos update." << std::endl;
            HILOG_APP(INFO) << "new content: \n" << new_config << std::endl;
            return KafkaHelper::getInstance().update(new_config);
        }

        config::ConfigSource GetConfigSource() override {
            return {
                .group_id = group_id,
                .data_id = data_id
            };
        }
    };

};
