#include <string>
#include "kafka_helper.h"
using namespace std;
using namespace hikafka;

int main() 
{
    XMLDocument xml;
    XMLError xmlError = xml.LoadFile("conf1.xml");

    if(xml.ErrorID() != XML_SUCCESS)
    {
        cerr<<"failed to parse xml " << xmlError << " "<< xml.ErrorName()<< endl;
    }
    hikafka::KafkaHelper* helper = new hikafka::KafkaHelper(xml);
    u_int32_t count =0;
    while(count < 100) 
    {
        helper->sendMsg("bbb","fuck you ","x");
        count++;
        std::cerr << "send: " << std::endl;
    } 
    
    std::cerr << "error" << std::endl;
    return 0;
}