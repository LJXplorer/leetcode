#ifndef __KAFKAPRODUCER_H_
#define __KAFKAPRODUCER_H_

#include <memory>
#include <string>
#include <iostream>
#include "rdkafkacpp.h"
#include <boost/lockfree/queue.hpp>
#include <tinyxml2.h>
#include <vector>

namespace hikafka {
    using namespace std;
    using namespace RdKafka;
    using namespace tinyxml2;
    using namespace boost;

    static const std::string TOPIC_NAME = "topic";
    static const std::string BROKERS = "brokers";
    static const std::string PRODUCER_NAME = "name";
    static const std::string MSG_MAX_BYTES = "msg_max_bytes";
    static const std::string THREAD_NUM = "thread_num";
    static const std::string QUEUE_SIZE = "queue_size";
    static const std::string USER_NAME = "user_name";
    static const std::string USER_PASS = "password";
    static const std::string GROUP_ID = "group_id";

    struct KafkaMessage {
        std::string key;
        std::string value;
    };

    class DeliveryCb : public DeliveryReportCb{
    public:
        std::string _topic;
    public:
        DeliveryCb(const std::string&t){
           _topic = t;
        }

        virtual void dr_cb (Message &message){}
    };

    class KafkaProducer {
        public:
            KafkaProducer(){};
            explicit KafkaProducer(const tinyxml2::XMLElement& kafkaProEle);
            ~KafkaProducer();
            bool addMsg(const string& msg, const string& key);
            bool addMsg(KafkaMessage* kafkaMessage);
        private:
            static void sendMsg(KafkaProducer* myp,Producer* p,Topic* t );
        public:
            string _producerName;
            string _brokers;
            string _topicName;
            string _password;
            string _groupId;
            string _user_name;
            string _msg_max_bytes;
            string _thread_num;
            string _queue_size;
            DeliveryCb* _cb;
            std::vector<Producer*> _producer;
            std::vector<Topic* > _topic;
            int topicConfSet(Conf* topicCof);
            int globalConfSet(Conf* globalCof);
            bool _running;

            //处理队列的线程相关
            std::shared_ptr<boost::lockfree::queue<KafkaMessage*>> _messageQueue;
            //std::unique_ptr<boost::asio::thread_pool> _pool;
    };

};

#endif

