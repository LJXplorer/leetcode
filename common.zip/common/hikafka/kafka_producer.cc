#include "kafka_producer.h"
#include <thread>
#include "common/hilog/log_helper.h"
using namespace hilog;
namespace hikafka {
    KafkaProducer::KafkaProducer(const tinyxml2::XMLElement& kafkaXMLConf) {
        
        //获取配置中kafka的名字
        _producerName = kafkaXMLConf.Attribute(PRODUCER_NAME.c_str());
        //获取配置中kafka的brokers
        _brokers = kafkaXMLConf.Attribute(BROKERS.c_str());
        _topicName = kafkaXMLConf.Attribute(TOPIC_NAME.c_str());
        _msg_max_bytes = kafkaXMLConf.Attribute(MSG_MAX_BYTES.c_str());
        _thread_num = kafkaXMLConf.Attribute(THREAD_NUM.c_str());
        _queue_size = kafkaXMLConf.Attribute(QUEUE_SIZE.c_str());
        _groupId = kafkaXMLConf.Attribute(GROUP_ID.c_str());
        _user_name = kafkaXMLConf.Attribute(USER_NAME.c_str());
        _password = kafkaXMLConf.Attribute(USER_PASS.c_str());

        Conf* gconf = Conf::create(Conf::CONF_GLOBAL);
        if(!globalConfSet(gconf)) {
            HILOG_APP(ERROR) << "Failed to create kafka gconf" << endl;
        }

        string errStr;
        if(gconf == nullptr) {
            HILOG_APP(ERROR) << "Failed to create kafka gconf" << endl ;
        }

        _messageQueue = std::make_shared<boost::lockfree::queue<KafkaMessage*>>(stoi(_queue_size));
        _cb = new DeliveryCb(_topicName);
        int32_t nthrea_num = std::atoi(_thread_num.c_str());
        for(int32_t i = 0;i < nthrea_num;i++){
            Conf* topicCof = Conf::create(Conf::CONF_TOPIC);
            if(!topicConfSet(topicCof)) {
                HILOG_APP(ERROR) << "Failed to create kafka tconf" << endl ;
                return;
            }
            Producer* producer = Producer::create(gconf, errStr);
            if (!producer) {
                HILOG_APP(ERROR) << "Failed to create producer: " << errStr << endl  ;
                return;
            }

            Topic*  topic = Topic::create(producer,_topicName, topicCof, errStr);
            if (!producer) {
                HILOG_APP(ERROR) << "Failed to create topic: " << errStr << endl;
                return;
            }
            _topic.emplace_back(topic);
            _producer.emplace_back(producer);
            std::thread td = std::thread(KafkaProducer::sendMsg, this, producer, topic);
            td.detach();
        }

        _running = true;

    }

    KafkaProducer::~KafkaProducer() {
        for(size_t i = 0; i<_producer.size();i++){
            auto producer = _producer[i];
            while(nullptr != producer && producer->outq_len() > 0) 
            {
                HILOG_APP(ERROR) << "waiting 5000ms to send data before destorying producer"<< endl;
                producer->flush(5000);
            }

            if(nullptr != producer) 
            {
                delete producer;
                producer = nullptr;
            }
        }
    }


    void KafkaProducer::sendMsg(KafkaProducer* myp,Producer* producer,Topic* t) {
        pthread_setname_np(pthread_self(), "kafka_producer");
        while(myp->_running) {
            KafkaMessage* kafkaMessage = nullptr;
            bool get = myp->_messageQueue->pop(kafkaMessage);
            if (get && kafkaMessage != nullptr) {
                void *payload = const_cast<void*>(static_cast<const void*>(kafkaMessage->value.data()));
                ErrorCode errorCode = producer->produce(t, Topic::PARTITION_UA, Producer::RK_MSG_COPY, payload, kafkaMessage->value.length(), &kafkaMessage->key, NULL);
    
                if(errorCode != ERR_NO_ERROR) {
                    HILOG_APP(ERROR)<< "produce msg failed, topic: "<<myp->_topicName<< " error: "<<err2str(errorCode) << " size: "<< kafkaMessage->value.length() << endl;
                }
                if (kafkaMessage != nullptr) {
                    delete kafkaMessage;
                    kafkaMessage = nullptr;
                }
                
            }else{
                usleep(100000);
                continue;
            }
        }  
    }

    bool KafkaProducer::addMsg(const string& msg, const string& key) {
        KafkaMessage* kafkaMessage = new KafkaMessage();
        kafkaMessage->key = key;
        kafkaMessage->value.assign(msg.begin(),msg.end());
        bool ret = _messageQueue->bounded_push(kafkaMessage);
        if(ret == false){
		  HILOG_APP(ERROR)<<_topicName<<" insert queue fail:"<<ret;
		  delete kafkaMessage;
        }

         HILOG_APP(INFO)<<ret<<" _messageQueue empty:"<<_messageQueue->empty();
         return ret;
    }

    bool KafkaProducer::addMsg(KafkaMessage* kafkaMessage){
        if(kafkaMessage == nullptr) return false;
        bool ret = _messageQueue->bounded_push(kafkaMessage);
        if (!ret) {
            HILOG_APP(ERROR)<<_topicName<<" insert queue fail:"<<ret;
            delete kafkaMessage;
        }

        HILOG_APP(INFO)<<ret<<" _messageQueue empty:"<<_messageQueue->empty();
        return ret;
    }

    int KafkaProducer::topicConfSet(Conf* topicCof) {
        string errStr;
        if (topicCof->set("acks", "0", errStr) != Conf::CONF_OK) 
        {
            cerr << errStr << endl;
            return 0;
        }
        return 1;
    }

    int KafkaProducer::globalConfSet(Conf* globalCof) {
        string errStr;
        if (!_groupId.empty() && globalCof->set("group.id", _groupId, errStr) != Conf::CONF_OK) 
        {
            cerr << errStr << endl;
            return -1;
        }

        if (!_brokers.empty() && globalCof->set("bootstrap.servers", _brokers, errStr) != Conf::CONF_OK) 
        {
            cerr << errStr << endl;
            return -1;
        }

        if (!_user_name.empty() && globalCof->set("sasl.username", _user_name, errStr) != Conf::CONF_OK) 
        {
            cerr << errStr << endl;
            return -1;
        }
        
        if (!_password.empty() && globalCof->set("sasl.password", _password, errStr) != Conf::CONF_OK) 
        {
            cerr << errStr << endl;
            return -1;
        }

        //每条消息最大字节数
        if (globalCof->set("message.max.bytes", _msg_max_bytes, errStr) != Conf::CONF_OK) {
            cerr << errStr << endl;
            return -2;
        }

        //每条消息最大字节数
        if (globalCof->set("compression.codec", "gzip", errStr) != Conf::CONF_OK) {
            cerr << errStr << endl;
            return -2;
        }

        return 1;
    }
}