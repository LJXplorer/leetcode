#include "kafka_helper.h"

#include <utility>
#include "common/hilog/log_helper.h"
#include "common/config/service_config.h"
#include "common/config/error_code.h"
#include "common/config/config_manager.h"
#include "core/utils/error.h"
namespace hikafka {

    KafkaHelper::KafkaHelper(){
    }

    KafkaHelper::~KafkaHelper(){

    }
    void KafkaHelper::init(const tinyxml2::XMLDocument& cacheConf) {
        createProducer(cacheConf);
    }


    int KafkaHelper::new_init(const config::ConfigServiceCfg& cfg,
                        const std::string& group_id,
                        const std::string& data_id){
        // 注册nacos
        auto ptr = std::make_shared<KafkaNacosConfig>(group_id, data_id);
        config::RegisterResponse regist_ret = config::ConfigManager::getInstance().RegisterConfig(cfg, ptr);
        
        if(regist_ret != config::RegisterResponse::kSuccess){
            HILOG_APP(ERROR) << "register nacos failed";
            return Core::ERROR_REGISTER_CONFIG_NULL;
        } 
        return Core::ERROR_SUCCESS;

    }

    int KafkaHelper::update(const std::string& content) {
        tinyxml2::XMLDocument kafka_xml;
        tinyxml2::XMLError err = kafka_xml.Parse(content.c_str());
        if (err != tinyxml2::XML_SUCCESS) {
            std::cerr << " kafka xml parse fail";
            return -1;
        }
        createProducer(kafka_xml);
        return 0;
    }
    
    void  KafkaHelper::createProducer(const tinyxml2::XMLDocument& cacheConf){
        const tinyxml2::XMLElement* rootElement = cacheConf.FirstChildElement();
        for (const tinyxml2::XMLElement* child = rootElement->FirstChildElement(); child != nullptr; child = child->NextSiblingElement()) {
            std::lock_guard<std::mutex> lock(_mtx);
            string name = child->Attribute("name");  
            auto it = _producer_map.find(name);
            if (it == _producer_map.end()) {
                if(addProducer(name, std::make_shared<KafkaProducer>(*child))) {
                    HILOG_APP(INFO) << name << " createProducer" << std::endl;
                }
            }

            
        }
        
    }

    bool KafkaHelper::addProducer(const string name, std::shared_ptr<KafkaProducer> kafkaProducer) {
        _producer_map.insert_or_assign(name, kafkaProducer);
        //todo if failed
        return true;
    }

    bool KafkaHelper::sendMsg(const string name, const string key, const string value) {
        std::shared_ptr<KafkaProducer> kafkaProducer;
        auto it = _producer_map.find(name);
        if (it != _producer_map.end()) {
            kafkaProducer = it->second;
        }
        if (!kafkaProducer) {
            HILOG_APP(ERROR)<< "producer: " << name << "key: " << key << endl; 
            return false;
        }
        return kafkaProducer->addMsg(value, key);
    }

    bool KafkaHelper::sendMsg(const string& name, KafkaMessage* kafkaMessage) {
        std::shared_ptr<KafkaProducer> kafkaProducer;
        auto it = _producer_map.find(name);
        if (it != _producer_map.end()) {
            kafkaProducer = it->second;
        }
        if (!kafkaProducer) {
            HILOG_APP(ERROR)<< "producer: " << name << endl; 
            return false;
        }
        return kafkaProducer->addMsg(kafkaMessage);
    }


};
