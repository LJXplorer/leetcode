#include "nacos_client.h"

#define DEBUG_LOG(msg) do { \
    std::cout << "[DEBUG] " << msg << " (File: " << __FILE__ << ", Line: " << __LINE__ << ")" << std::endl; \
} while(0)

NacosClient::NacosClient(const std::string& server_addr, const std::string& namespace_var,
        const std::string& auth_username, const std::string& auth_password) {
    nacos::Properties config_rops;
    config_rops[nacos::PropertyKeyConst::SERVER_ADDR] = server_addr;
    config_rops[nacos::PropertyKeyConst::NAMESPACE] = namespace_var;
    config_rops[nacos::PropertyKeyConst::AUTH_USERNAME] = auth_username;
    config_rops[nacos::PropertyKeyConst::AUTH_PASSWORD] = auth_password;
    ffactory_ = new nacos::NacosFactoryFactory();
    factory_ = ffactory_->getNacosFactory(config_rops);
    namingSvc_ = factory_->CreateNamingService();
}
NacosClient::NacosClient(nacos::Properties& config_rops) {
    ffactory_ = new nacos::NacosFactoryFactory();
    factory_ = ffactory_->getNacosFactory(config_rops);
    namingSvc_ = factory_->CreateNamingService();
}
NacosClient::~NacosClient() {
    // if (namingSvc_ != nullptr) {
    //     delete namingSvc_;
    //     namingSvc_ = nullptr;
    // }不可销毁，该对象已自行销毁，但未赋值为nullptr
    // if (factory_ != nullptr) {
    //     delete factory_;
    //     factory_ = nullptr;
    // }不可销毁，该对象已自行销毁，但未赋值为nullptr
    if (ffactory_ != nullptr) {
        delete ffactory_;
        ffactory_ = nullptr;
    }
}

std::list<std::string> NacosClient::getAllServiceNames() {
    nacos::ResourceGuard <nacos::INacosServiceFactory> _guardFactory(factory_);
    nacos::ResourceGuard <nacos::NamingService> _guardService(namingSvc_);
    nacos::ListView<std::string>service_list = namingSvc_->getServiceList(1, std::numeric_limits<int>::max());
    return service_list.getData();
}
std::list<nacos::Instance> NacosClient::getAllInstances(const std::string& service_name) {
    nacos::ResourceGuard <nacos::INacosServiceFactory> _guardFactory(factory_);
    nacos::ResourceGuard <nacos::NamingService> _guardService(namingSvc_);
    return namingSvc_->getAllInstances(service_name);
}
bool NacosClient::registerInstance(InstanceInfo& instance_info) {
    return NacosClient::registerInstance(instance_info.service_name_, instance_info.instance_details_);
}

bool NacosClient::deregisterInstance(InstanceInfo& instance_info) {
    return NacosClient::deregisterInstance(instance_info.service_name_, instance_info.instance_details_.ip, instance_info.instance_details_.port);
}

bool NacosClient::registerInstances(std::vector<InstanceInfo>& instance_infos) {
    nacos::ResourceGuard <nacos::INacosServiceFactory> _guardFactory(factory_);
    nacos::ResourceGuard <nacos::NamingService> _guardService(namingSvc_);
    try {
        for (InstanceInfo& instance_info : instance_infos) {
            DEBUG_LOG("尝试注册：" << instance_info.service_name_ << "," << instance_info.instance_details_.ip << "," << instance_info.instance_details_.port);
            namingSvc_->registerInstance(instance_info.service_name_, instance_info.instance_details_);
            DEBUG_LOG("注册结束。");
        }
    } catch (nacos::NacosException& e) {
        DEBUG_LOG("注册服务实例时遇到异常，原因：" << e.what());
        return false;
    }
    return true;
}
bool NacosClient::deregisterInstances(std::vector<InstanceInfo>& instance_infos) {
    nacos::ResourceGuard <nacos::INacosServiceFactory> _guardFactory(factory_);
    nacos::ResourceGuard <nacos::NamingService> _guardService(namingSvc_);
    try {
        for (InstanceInfo& instance_info : instance_infos) {
            DEBUG_LOG("尝试反注册：" << instance_info.service_name_ << "," << instance_info.instance_details_.ip << "," << instance_info.instance_details_.port);
            namingSvc_->deregisterInstance(instance_info.service_name_, instance_info.instance_details_.ip, instance_info.instance_details_.port);
            DEBUG_LOG("反注册结束。");
            sleep(1);
        }
    } catch (nacos::NacosException& e) {
        DEBUG_LOG("反注册服务实例时遇到异常，原因：" << e.what());
        return false;
    }
    return true;
}


bool NacosClient::registerInstance(const std::string& service_name, nacos::Instance& instance_details) {
    nacos::ResourceGuard <nacos::INacosServiceFactory> _guardFactory(factory_);
    nacos::ResourceGuard <nacos::NamingService> _guardService(namingSvc_);
    try {
        DEBUG_LOG("尝试注册：" << service_name << "," << instance_details.ip << "," << instance_details.port);
        namingSvc_->registerInstance(service_name, instance_details);
        DEBUG_LOG("注册结束。");
    } catch (nacos::NacosException& e) {
        DEBUG_LOG("注册服务实例时遇到异常，原因：" << e.what());
        return false;
    }
    return true;
}
bool NacosClient::deregisterInstance(const std::string& service_name, const  std::string& ip, const  int& port) {
    nacos::ResourceGuard <nacos::INacosServiceFactory> _guardFactory(factory_);
    nacos::ResourceGuard <nacos::NamingService> _guardService(namingSvc_);
    try {
        DEBUG_LOG("尝试反注册：" << service_name << "," << ip << "," << port);
        namingSvc_->deregisterInstance(service_name, ip, port);
        DEBUG_LOG("反注册结束。");
        sleep(1);
    } catch (nacos::NacosException& e) {
        DEBUG_LOG("反注册服务实例时遇到异常，原因：" << e.what());
        return false;
    }
    return true;
}

bool NacosClient::registerInstance(const std::string& service_name, const std::string& ip, const int& port, const bool& ephemeral) {
    nacos::Instance instance;
    instance.ip = ip;
    instance.port = port;
    instance.instanceId = ip + "_" + std::to_string(port);
    instance.ephemeral = ephemeral;//临时实例
    return registerInstance(service_name, instance);
}