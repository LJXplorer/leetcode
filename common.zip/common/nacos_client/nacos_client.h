#ifndef NACOS_CLIENT_H
#define NACOS_CLIENT_H

#include "Nacos.h"
#include <vector>
#include <list>
#include <limits>
#include <iostream>
#include <unistd.h>

class InstanceInfo {
public:
    NacosString service_name_;//服务名
    nacos::Instance instance_details_;//具体实例
    explicit InstanceInfo(const std::string& service_name, const nacos::Instance& instance_details)
        :service_name_(service_name), instance_details_(instance_details) {}
};

class NacosClient {
public:
    NacosClient(nacos::Properties& config_props);
    NacosClient(const std::string& server_addr, const std::string& namespace_var,
        const std::string& auth_username, const std::string& auth_password);
    ~NacosClient();
    std::list<std::string> getAllServiceNames();
    std::list<nacos::Instance> getAllInstances(const std::string& service_name);

    bool registerInstance(InstanceInfo& instance_info);
    bool deregisterInstance(InstanceInfo& instance_info);

    bool registerInstance(const std::string& service_name, nacos::Instance& instance_details);
    bool registerInstance(const std::string& service_name, const std::string& ip, const int& port, const bool& ephemeral);
    bool deregisterInstance(const std::string& service_name, const std::string& ip, const int& port);

    bool registerInstances(std::vector<InstanceInfo>& instance_infos);
    bool deregisterInstances(std::vector<InstanceInfo>& instance_infos);

private:
    nacos::NacosFactoryFactory* ffactory_;
    nacos::INacosServiceFactory* factory_;//在每次调用成员函数后就会被ResourceGuard 销毁
    nacos::NamingService* namingSvc_;//在每次调用成员函数后就会被ResourceGuard 销毁
};

#endif