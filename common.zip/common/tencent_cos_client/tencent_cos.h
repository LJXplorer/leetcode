#ifndef TENCENT_COS_H
#define TENCENT_COS_H

#include "cos_api.h"
#include "cos_defines.h"
#include "cos_sys_config.h"
#include <iostream>
#include <memory>
#include "common/hilog/log_helper.h"

#ifndef ENABLE_DEBUG
#define DEBUG_LOG(msg)                                                                                                 \
    do {                                                                                                               \
    } while (0)
#define ERROR_LOG(msg)                                                                                                 \
    do {                                                                                                               \
    } while (0)
#define FUNC_TEST_START()                                                                                              \
    do {                                                                                                               \
    } while (0)
#define FUNC_TEST_END()                                                                                                \
    do {                                                                                                               \
    } while (0)

#else// defined ENABLE_DEBUG
#define DEBUG_LOG(msg)                                                                                                 \
    do {                                                                                                               \
        std::cout << "[DEBUG] " << msg << " (File: " << __FILE__ << ", Line: " << __LINE__ << ")" << std::endl;        \
    } while (0)

#define ERROR_LOG(msg)                                                                                                 \
    do {                                                                                                               \
        std::cerr << "[ERROR] " << msg << " (File: " << __FILE__ << ", Line: " << __LINE__ << ")" << std::endl;        \
    } while (0)

#define FUNC_TEST_START()                                                                                              \
    std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ -------------- START -------------- ]"           \
              << std::endl
#define FUNC_TEST_END()                                                                                                \
    std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ -------------- END -------------- ]" << std::endl
#endif// defined ENABLE_DEBUG

class TencentCOSClient {
private:
    std::unique_ptr<qcloud_cos::CosConfig> config_;
    std::unique_ptr<qcloud_cos::CosAPI> cos_;

public:
    TencentCOSClient(const std::string &config_path);
    ~TencentCOSClient();

    bool uploadObject(const std::string& bucket_name, const std::string& object_name, const std::string& local_path);
    bool downloadObject(const std::string& bucket_name, const std::string& object_name, const std::string& local_path);
    bool getObjectByStream(const std::string& bucket_name, const std::string& object_name, std::ostringstream& os);
    bool putObjectByStream(const std::string& bucket_name, const std::string& object_name, std::istringstream& iss);
    bool deleteObject(const std::string& bucket_name, const std::string& object_name);
    std::vector<qcloud_cos::Bucket> findBucketList();
    qcloud_cos::Owner findBucketOwner();
    std::vector<qcloud_cos::Content> findObjectList(const std::string &bucket_name);
    static bool handleResult(const qcloud_cos::CosResult &result);

    bool setBucketLifecycle(const std::string &bucket_name, const std::vector<qcloud_cos::LifecycleRule> &rules);
    std::vector<qcloud_cos::LifecycleRule> getBucketLifecycle(const std::string &bucket_name);
    bool deleteBucketLifecycle(const std::string &bucket_name);
};

#endif