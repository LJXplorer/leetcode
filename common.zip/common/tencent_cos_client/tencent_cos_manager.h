#ifndef _TENCENT_COS_MANEGER_H
#define _TENCENT_COS_MANEGER_H

#include "tencent_cos.h"
#include <filesystem>

namespace CosClient {
namespace fs = std::filesystem;

class TencentCosClientManager {
private:
    std::string _bucket_name = "cloud-ai-pre-1311258067";
    std::string _bucket_config = "./conf/cos_bucket/cloud-ai-pre-1311258067.json";
    std::shared_ptr<TencentCOSClient> _cos_client;
private:
    TencentCosClientManager(){}
public:
    int init(const std::string& path);
    int init();
    std::shared_ptr<TencentCOSClient> get_client();
    const std::string& get_bucket_name();
    static TencentCosClientManager& instance() {
        static TencentCosClientManager inst;
        return inst;
    }
};

} // end of namespace client

#endif
