#include "tencent_cos.h"
#include <chrono>
#include <cstddef>
#include <thread>

#include <iostream>

#define DEBUG_LOG(msg)                                                                                                 \
    do {                                                                                                               \
        std::cout << "[DEBUG] " << msg << " (File: " << __FILE__ << ", Line: " << __LINE__ << ")" << std::endl;        \
    } while (0)

#define ERROR_LOG(msg)                                                                                                 \
    do {                                                                                                               \
        std::cerr << "[ERROR] " << msg << " (File: " << __FILE__ << ", Line: " << __LINE__ << ")" << std::endl;        \
    } while (0)

#define FUNC_TEST_START()                                                                                              \
    std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ -------------- START -------------- ]"           \
              << std::endl
#define FUNC_TEST_END()                                                                                                \
    std::cout << __FILE__ << "[" << __func__ << "]" << __LINE__ << "[ -------------- END -------------- ]" << std::endl

void testFindBucketOwnerAndBucketList() {
    FUNC_TEST_START();

    TencentCOSClient client("/home/congyi/predictor/common/tencent_cos_client/test/tencent_cos_config.json");
    // 3. 获取响应信息
    const qcloud_cos::Owner &owner = client.findBucketOwner();
    const std::vector<qcloud_cos::Bucket> &buckets = client.findBucketList();
    DEBUG_LOG("owner.m_id=" << owner.m_id << ", owner.display_name=" << owner.m_display_name);

    for (const qcloud_cos::Bucket &bucket: buckets) {
        DEBUG_LOG("Bucket Name: " << bucket.m_name << ", Location: " << bucket.m_location
                                  << ", Create Date: " << bucket.m_create_date);
    }
    FUNC_TEST_END();
}

void testUploadObject() {
    FUNC_TEST_START();
    TencentCOSClient client("/home/congyi/predictor/common/tencent_cos_client/test/tencent_cos_config.json");
    // 2. 构造上传文件的请求
    std::string bucket_name =
            "mlops-test-bj-data-1311274267";// 替换为用户的存储桶名，由 bucketname-appid 组成，appid 必须填入，可以在 COS 控制台查看存储桶名称。 https://console.cloud.tencent.com/cos5/bucket
    std::string object_name =
            "tfmodeltool/guide.txt";//exampleobject 即为对象键（Key），是对象在存储桶中的唯一标识。例如，在对象的访问域名 examplebucket-1250000000.cos.ap-guangzhou.myqcloud.com/doc/pic.jpg 中，对象键为 doc/pic.jpg，替换为用户指定的对象名。
    std::string local_path = "guide.txt";

    if (client.uploadObject(bucket_name, object_name, local_path)) {
        DEBUG_LOG("SUCCESS");
    } else {
        DEBUG_LOG("FAIL");
    }
    FUNC_TEST_END();
}

void testFindObjectList() {
    FUNC_TEST_START();
    TencentCOSClient client("/home/congyi/predictor/common/tencent_cos_client/test/tencent_cos_config.json");
    std::string bucket_name = "mlops-test-bj-data-1311274267";

    const std::vector<qcloud_cos::Content> &contents = client.findObjectList(bucket_name);
    for (const qcloud_cos::Content &content: contents) {
        DEBUG_LOG("Key Name: " << content.m_key << ", Last Modified: " << content.m_last_modified
                               << ", Size: " << content.m_size);
    }
    FUNC_TEST_END();
}

void testDownloadObject() {
    FUNC_TEST_START();
    TencentCOSClient client("/home/congyi/predictor/common/tencent_cos_client/test/tencent_cos_config.json");
    std::string bucket_name = "mlops-test-bj-data-1311274267";
    std::string object_name = "tfmodeltool/guide.txt";
    std::string local_path = "/home/congyi/guide.txt";

    if (client.downloadObject(bucket_name, object_name, local_path)) {
        DEBUG_LOG("SUCCESS");
    } else {
        DEBUG_LOG("FAIL");
    }
    FUNC_TEST_END();
}

void testDeleteObject() {
    FUNC_TEST_START();
    TencentCOSClient client("/home/congyi/predictor/common/tencent_cos_client/test/tencent_cos_config.json");
    std::string bucket_name = "mlops-test-bj-data-1311274267";
    std::string object_name = "tfmodeltool/guide.txt";
    // 3. 调用删除对象接口
    if (client.deleteObject(bucket_name, object_name)) {
        DEBUG_LOG("SUCCESS");
    } else {
        DEBUG_LOG("FAIL");
    }
    FUNC_TEST_END();
}

void testGetBucketLifecycle() {
    FUNC_TEST_START();
    TencentCOSClient client("/home/congyi/predictor/common/tencent_cos_client/test/tencent_cos_config.json");
    std::string bucket_name = "mlops-test-bj-data-1311274267";

    std::vector<qcloud_cos::LifecycleRule> rules = client.getBucketLifecycle(bucket_name);

    for (auto rule: rules) {
        std::cout << "id: "<<rule.GetId() << std::endl;
        std::cout << "prefix: " << rule.GetFilter().GetPrefix() << std::endl;
        std::cout << "expire days: " << rule.GetExpiration().GetDays() << std::endl;
    }

    FUNC_TEST_END();
}

void testSetBucketLifecycle() {
    FUNC_TEST_START();
    TencentCOSClient client("/home/congyi/predictor/common/tencent_cos_client/test/tencent_cos_config.json");
    std::string bucket_name = "mlops-test-bj-data-1311274267";

    qcloud_cos::LifecycleRule rule;
    rule.SetIsEnable(true);// 指明规则是否启用，枚举值：Enabled，Disabled
    rule.SetId("delete prefix xxxy after 30 days");// 用于唯一地标识规则，长度不能超过255个字符

    qcloud_cos::LifecycleFilter filter;
    filter.SetPrefix("logs/");
    rule.SetFilter(filter);// 指定规则所适用的前缀。匹配前缀的对象受该规则影响，Prefix最多只能有一个

    // qcloud_cos::LifecycleTransition transition;// 规则转换属性
    // transition.SetDays(30);
    // // transition.SetStorageClass("Standard_IA");
    // rule.AddTransition(transition);
    qcloud_cos::LifecycleExpiration life_expiration;
    life_expiration.SetDays(30);
    
    rule.SetExpiration(life_expiration);

    client.setBucketLifecycle(bucket_name, {rule});

    FUNC_TEST_END();
}

void testDeleteBucketLifecycle(){
    FUNC_TEST_START();
    TencentCOSClient client("/home/congyi/predictor/common/tencent_cos_client/test/tencent_cos_config.json");
    std::string bucket_name = "mlops-test-bj-data-1311274267";
    client.deleteBucketLifecycle(bucket_name);
    FUNC_TEST_END();
}

int main() {

    // testFindBucketOwnerAndBucketList();

    // testUploadObject();

    // std::this_thread::sleep_for(std::chrono::seconds(2));
    // testFindObjectList();
    testGetBucketLifecycle();
    // testSetBucketLifecycle();
    // std::this_thread::sleep_for(std::chrono::seconds(2));
    // testDownloadObject();
    // std::this_thread::sleep_for(std::chrono::seconds(2));
    // testDeleteObject();
}