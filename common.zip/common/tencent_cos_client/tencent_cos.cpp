#include "tencent_cos.h"
#include "common/hilog/log_helper.h"
TencentCOSClient::TencentCOSClient(const std::string &config_path) {
    config_ = std::make_unique<qcloud_cos::CosConfig>(config_path);
    cos_ = std::make_unique<qcloud_cos::CosAPI>(*config_);
}

TencentCOSClient::~TencentCOSClient() {
}
bool TencentCOSClient::uploadObject(const std::string &bucket_name, const std::string &object_name,
                                    const std::string &local_path) {
    qcloud_cos::PutObjectByFileReq req(bucket_name, object_name, local_path);
    qcloud_cos::PutObjectByFileResp resp;
    qcloud_cos::CosResult result = cos_->PutObject(req, &resp);
    return handleResult(result);
}
bool TencentCOSClient::downloadObject(const std::string &bucket_name, const std::string &object_name,
                                      const std::string &local_path) {
    qcloud_cos::GetObjectByFileReq req(bucket_name, object_name, local_path);
    qcloud_cos::GetObjectByFileResp resp;
    qcloud_cos::CosResult result = cos_->GetObject(req, &resp);
    return handleResult(result);
}
bool TencentCOSClient::getObjectByStream(const std::string& bucket_name, const std::string& object_name, std::ostringstream& os) {
    qcloud_cos::GetObjectByStreamReq req(bucket_name, object_name, os);
    qcloud_cos::GetObjectByStreamResp resp;

    qcloud_cos::CosResult result = cos_->GetObject(req, &resp);
    return handleResult(result);
}
bool TencentCOSClient::putObjectByStream(const std::string& bucket_name, const std::string& object_name, std::istringstream& iss) {
    qcloud_cos::PutObjectByStreamReq req(bucket_name, object_name, iss);
    qcloud_cos::PutObjectByStreamResp resp;
    qcloud_cos::CosResult result = cos_->PutObject(req, &resp);
    return handleResult(result);
}
bool TencentCOSClient::deleteObject(const std::string& bucket_name, const std::string& object_name) {
    qcloud_cos::DeleteObjectReq req(bucket_name, object_name);
    qcloud_cos::DeleteObjectResp resp;
    qcloud_cos::CosResult result = cos_->DeleteObject(req, &resp);
    return handleResult(result);
}
std::vector<qcloud_cos::Bucket> TencentCOSClient::findBucketList() {
    qcloud_cos::GetServiceReq req;
    qcloud_cos::GetServiceResp resp;
    qcloud_cos::CosResult result = cos_->GetService(req, &resp);

    if (handleResult(result)) {
        return resp.GetBuckets();
    } else {
        return {};
    }
}

qcloud_cos::Owner TencentCOSClient::findBucketOwner() {
    qcloud_cos::GetServiceReq req;
    qcloud_cos::GetServiceResp resp;
    qcloud_cos::CosResult result = cos_->GetService(req, &resp);

    if (handleResult(result)) {
        return resp.GetOwner();
    } else {
        return {};
    }
}
std::vector<qcloud_cos::Content> TencentCOSClient::findObjectList(const std::string &bucket_name) {
    qcloud_cos::GetBucketReq req(bucket_name);
    qcloud_cos::GetBucketResp resp;
    qcloud_cos::CosResult result = cos_->GetBucket(req, &resp);

    if (handleResult(result)) {
        return resp.GetContents();
    } else {
        return {};
    }
}
bool TencentCOSClient::handleResult(const qcloud_cos::CosResult &result) {
    if (result.IsSucc()) {
        HILOG_APP(INFO) << "Operation succeeded.";
        DEBUG_LOG("Operation succeeded.");
        return true;
    } else {
        ERROR_LOG("HttpStatus: " << result.GetHttpStatus());
        ERROR_LOG("ErrorCode: " << result.GetErrorCode());
        ERROR_LOG("ErrorMsg: " << result.GetErrorMsg());
        ERROR_LOG("ResourceAddr: " << result.GetResourceAddr());
        ERROR_LOG("XCosRequestId: " << result.GetXCosRequestId());
        ERROR_LOG("XCosTraceId: " << result.GetXCosTraceId());

        HILOG_APP(ERROR) << "HttpStatus: " << result.GetHttpStatus();
        HILOG_APP(ERROR) << "ErrorCode: " << result.GetErrorCode();
        HILOG_APP(ERROR) << "ErrorMsg: " << result.GetErrorMsg();
        HILOG_APP(ERROR) << "ResourceAddr: " << result.GetResourceAddr();
        HILOG_APP(ERROR) << "XCosRequestId: " << result.GetXCosRequestId();
        HILOG_APP(ERROR) << "XCosTraceId: " << result.GetXCosTraceId();
        return false;
    }
}

// 设置生命周期规则
bool TencentCOSClient::setBucketLifecycle(const std::string &bucket_name,
                                          const std::vector<qcloud_cos::LifecycleRule> &rules) {
    qcloud_cos::PutBucketLifecycleReq req(bucket_name);
    qcloud_cos::PutBucketLifecycleResp resp;
    for (const auto &rule: rules) {
        req.AddRule(rule);
    }
    qcloud_cos::CosResult result = cos_->PutBucketLifecycle(req, &resp);
    return handleResult(result);
}

// 查询生命周期规则
std::vector<qcloud_cos::LifecycleRule> TencentCOSClient::getBucketLifecycle(const std::string &bucket_name) {
    qcloud_cos::GetBucketLifecycleReq req(bucket_name);
    qcloud_cos::GetBucketLifecycleResp resp;
    qcloud_cos::CosResult result = cos_->GetBucketLifecycle(req, &resp);
    if (handleResult(result)) {
        return resp.GetRules();
    } else {
        return {};
    }
}

// 删除生命周期规则
bool TencentCOSClient::deleteBucketLifecycle(const std::string &bucket_name) {
    qcloud_cos::DeleteBucketLifecycleReq req(bucket_name);
    qcloud_cos::DeleteBucketLifecycleResp resp;
    qcloud_cos::CosResult result = cos_->DeleteBucketLifecycle(req, &resp);
    return handleResult(result);
}
