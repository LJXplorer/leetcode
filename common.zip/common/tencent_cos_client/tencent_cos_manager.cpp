#include "tencent_cos_manager.h"

namespace CosClient {

    int TencentCosClientManager::init(const std::string& config_path) {
        fs::path fs_config_path(config_path);
        if (!fs::exists(fs_config_path)) {
            return -1;
        }
        _cos_client = std::make_shared<TencentCOSClient>(config_path);
        return 0;
    }

    int TencentCosClientManager::init() {
        fs::path fs_config_path(_bucket_config);
        if (!fs::exists(fs_config_path)) {
            return -1;
        }
        _cos_client = std::make_shared<TencentCOSClient>(_bucket_config);
        return 0;
    }

    std::shared_ptr<TencentCOSClient> TencentCosClientManager::get_client() {
        return _cos_client;
    }

    const std::string& TencentCosClientManager::get_bucket_name() {
        return _bucket_name;
    }
}