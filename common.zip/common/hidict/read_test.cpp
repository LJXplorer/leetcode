#include <iostream>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>
#include <cstring>
#include <cstdlib>

// 文件路径
const char* FILE_PATH = "test_file.txt";
const size_t MAP_LENGTH = 20000; // 映射的长度

// SIGBUS 信号处理器
void sigbus_handler(int sig) {
    std::cerr << "Caught SIGBUS (Bus Error) during read!" << std::endl;
    exit(1);
}

int main() {
    // 设置 SIGBUS 信号处理器
    struct sigaction sa;
    sa.sa_handler = sigbus_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGBUS, &sa, NULL);

    // 打开文件
    int fd = open(FILE_PATH, O_RDONLY);
    if (fd == -1) {
        perror("Failed to open file");
        return 1;
    }

    // 映射文件
    const char* p_buf = static_cast<const char*>(mmap(NULL, MAP_LENGTH, PROT_READ, MAP_PRIVATE, fd, 0));
    if (p_buf == MAP_FAILED) {
        perror("Failed to mmap file");
        close(fd);
        return 1;
    }

    std::cout << "File successfully mmap-ed. Reading data..." << std::endl;

    const char* ch = p_buf;
    // 模拟逐字节读取
    for (size_t i = 0; i < MAP_LENGTH; ++i) {
        std::cout << *ch << std::endl; // 可能触发 SIGBUS
        ch++;
        usleep(1000); // 每次读取后稍作延迟 (5ms)，更容易触发竞争条件
        std::cout << "length: "<< i << std::endl;
    }

    std::cout << std::endl;

    // 解除映射并关闭文件
    munmap((void*)p_buf, MAP_LENGTH);
    close(fd);

    return 0;
}