#pragma once

#include <ctime>
#include <string>
namespace hidict {
    class DictInfo;
    struct DictCallback {
        friend DictInfo;
        virtual bool OnLoadFinished(time_t n, bool load_suc) = 0;
        virtual void OnError() = 0;

        virtual ~DictCallback() {};

    protected:
        DictInfo *dict_info_;
    };

    class DictOnlineError{
        virtual void hiLogError(const std::string& msg) =0;
    };
}// namespace hidict