#if __cplusplus >= 201703L
#pragma once
#include "counter.h"
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iostream>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

// 指标清单
#define METRIC_LIST(X)                                                                                                 \
    X(TOTAL)                                                                                                           \
    X(KEY_FOUND)                                                                                                       \
    X(MAP_OR_KEY_EMPTY)                                                                                                \
    X(MAP_NOT_FOUND)                                                                                                   \
    X(KEY_NOT_FOUND)
namespace hidict {

    enum class Metric : uint8_t {
#define ENUM_ELEM(name) name,
        METRIC_LIST(ENUM_ELEM)
#undef ENUM_ELEM
                _COUNT
    };

    static inline constexpr size_t METRICS = static_cast<size_t>(Metric::_COUNT);

    static inline const char *kMetricNames[METRICS] = {
#define NAME_ELEM(name) #name,
            METRIC_LIST(NAME_ELEM)
#undef NAME_ELEM
    };

    struct CounterCell {
        std::array<Counter::ShardedDelta<>, METRICS> metrics{};
        inline void inc(Metric m, uint64_t x = 1) noexcept {
            // std::cout << "m: " << kMetricNames[static_cast<size_t>(m)] << " add" << std::endl; // Ok
            metrics[static_cast<size_t>(m)].add(x);
        }

        inline void drain_into(uint64_t *out) noexcept {
            for (size_t i = 0; i < METRICS; ++i) {
                out[i] = metrics[i].drain();
            }
        }
    };

    struct SimplifyDictInfo {
        std::string path;
        std::string clazz_name;
    };

    struct SvHash {
        using is_transparent = void;
        size_t operator()(std::string_view s) const noexcept {
            return std::hash<std::string_view>{}(s);
        }
    };
    struct SvEq {
        using is_transparent = void;
        bool operator()(std::string_view a, std::string_view b) const noexcept {
            return a == b;
        }
    };

    struct Handle {
        using IncFn = void (*)(void *obj, Metric m, uint64_t x);
        void *obj{nullptr};// 在线：CounterCell*；离线：nullptr
        IncFn inc_fn{nullptr};
        inline void inc(Metric m, uint64_t x = 1) const noexcept {
            // 无需判空：离线时 inc_fn 指向 no-op
            // std::cout << "run inc, m: " << kMetricNames[static_cast<size_t>(m)] << ", x = " << x << ", inc_fn: " << inc_fn << std::endl;
            inc_fn(obj, m, x);
        }
    };

    class DictCountersProvider {
    public:
        virtual ~DictCountersProvider() = default;

        // 重复注册可返回原句柄
        virtual Handle register_cell(std::string path, std::string clazz_name) = 0;

        // 根据路径返回句柄（不存在则返回 no-op 句柄）
        virtual Handle lookup_by_path(std::string_view path) const noexcept = 0;

        template<class Sink>
        void drain_all(Sink &&sink) {
            do_drain_all([&](const std::string &path, const std::string &clazz_name, const std::string &dict_version,
                             const uint64_t *buf,
                             size_t METRICS) { sink(path, clazz_name, dict_version, buf, METRICS); });
        }

        inline void inc(std::string_view path, Metric m, uint64_t x = 1) const noexcept {
            lookup_by_path(path).inc(m, x);
        }

        std::atomic<bool> _dict_not_found_report = false;

    protected:
        virtual void
        do_drain_all(std::function<void(const std::string &path, const std::string &clazz_name,
                                        const std::string &dict_version, const uint64_t *buf, size_t METRICS)>
                             sink) = 0;
    };

    class NoopCounters final : public DictCountersProvider {
    public:
        static NoopCounters &instance() {
            static NoopCounters x;
            return x;
        }

        Handle register_cell(std::string path, std::string clazz_name) override {
            return noop_handle();// 返回 no-op 句柄
        }
        Handle lookup_by_path(std::string_view path) const noexcept override {
            return noop_handle();
        }

    protected:
        void do_drain_all(std::function<void(const std::string &path, const std::string &clazz_name,
                                             const std::string &dict_version, const uint64_t *buf, size_t METRICS)>
                                  sink) override {
            // no-op
        }

    private:
        static void noop_inc(void * /*obj*/, Metric /*m*/, uint64_t /*x*/) noexcept {
            // no-op
        }
        static Handle noop_handle() noexcept {
            return Handle{nullptr, &noop_inc};
        }
        NoopCounters() = default;
    };

    class RealCounters final : public DictCountersProvider {
    public:
        RealCounters() {
            register_cell("default", "default");
        }
        Handle register_cell(std::string path, std::string clazz_name) override {
            auto it = index_.find(path);
            if (it != index_.end()) {
                return handle_for(it->second);
            }
            infos_.push_back({std::move(path), std::move(clazz_name)});
            cells_.push_back(std::make_unique<CounterCell>());
            uint32_t id = static_cast<uint32_t>(cells_.size() - 1);
            index_.emplace(infos_.back().path, id);
            return handle_for(id);
        }

        Handle lookup_by_path(std::string_view path) const noexcept override {
            if (!_dict_not_found_report) {       // 开关关闭时
                return NoopCounters::instance().lookup_by_path(path);// 返回 no-op 句柄
            }
            auto it = index_.find(std::string(path));
            if (it == index_.end()) {
                // std::cout << std::string(path) + " not found in index_" <<std::endl;
                return NoopCounters::instance().lookup_by_path(path);// 返回 no-op 句柄
            }
            
            return handle_for(it->second);
        }

    protected:
        void do_drain_all(std::function<void(const std::string &path, const std::string &clazz_name,
                                             const std::string &dict_version, const uint64_t *buf, size_t METRICS)>
                                  sink) override;

    private:
        static void real_inc(void *obj, Metric m, uint64_t x) noexcept {
            static_cast<CounterCell *>(obj)->inc(m, x);
        }
        Handle handle_for(uint32_t id) const noexcept {
            return Handle{const_cast<CounterCell *>(cells_[id].get()), &real_inc};
        }

        std::vector<std::unique_ptr<CounterCell>> cells_;
        std::vector<SimplifyDictInfo> infos_;
        std::unordered_map<std::string, uint32_t, SvHash, SvEq> index_;// path -> id
    };

    extern DictCountersProvider *g_counters;
    extern hidict::RealCounters g_real;
}// namespace hidict
#endif