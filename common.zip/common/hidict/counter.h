#pragma once

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <shared_mutex>
#include <unordered_map>
#include <iostream>

namespace Counter {

    // 分片计数器 片数设置为 64
    template<size_t Shards = 64>
    struct ShardedDelta {
        struct alignas(64) Cell {
            std::atomic<uint64_t> v{0};
        };
        std::array<Cell, Shards> cells{};

        static inline size_t pick() noexcept {
            static thread_local uint32_t s = 0x9e3779b9u;// xorshift32
            s ^= s << 13;
            s ^= s >> 17;
            s ^= s << 5;
            return s & (Shards - 1);
        }

        inline void add(uint64_t x = 1) noexcept {
            // size_t i = pick();
            cells[pick()].v.fetch_add(x, std::memory_order_relaxed);
            // uint64_t val = cells[i].v.load(std::memory_order_relaxed);
            // std::cout << "Cell[" << i << "] = " << val << std::endl;
        }
        inline uint64_t drain() noexcept {
            uint64_t sum = 0;
            for (auto &c: cells)
                sum += c.v.exchange(0, std::memory_order_relaxed);
            // std::cout << "sum: " << sum << std::endl;
            return sum;
        }
    };
}// namespace Counter
