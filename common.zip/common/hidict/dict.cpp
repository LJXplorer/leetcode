#include "dict.h"
#include <algorithm>
#include <dirent.h>
// #include <filesystem>
#include <exception>
#include <memory>
#include <string>
namespace hidict {
//DEFINE_int32(load_protection_interval, 60, "dict load protection interval in seconds");
const int32_t FLAGS_load_protection_interval = 60;
bool DictInfo::load_by_condition(time_t n, bool is_offline) {
    time_t  mtime = file_mtime(get_dict_file(is_offline));
    if(abs(n - mtime) < FLAGS_load_protection_interval) return false;
    if(m_modify_tm == mtime ) return false;
    m_modify_tm = mtime;
    return true;
}

const std::string& DictInfo::get_dict_file(bool is_offline){
    if(is_offline) {
        return m_path;
    } else {
        //如果没有版本，直接获取该词典根目录
        if(is_no_version) {
            return m_path;
        }
        m_latest_dir = get_latest_directory(m_path);
        if(m_latest_dir.empty()) {
            this->dictErrorManager.setError(DICT_DIR_EMPTY);
        }
        return m_latest_dir;
    }
}

bool DictInfo::load(bool is_offline){
    const std::string& dict_dir = get_dict_file(is_offline);
    if (!is_directory(dict_dir)) {
        LOG_DICT("dict: ["+m_name+"] " +" load failed, class: [" +m_clazz_name+ "], error: not a directory, dir: "+dict_dir);
        dictErrorManager.setError(DICT_DIR_EMPTY);
        return false;
    }
    
    std::string dir_path = dict_dir;
    if (is_symlink(dir_path)) {
        dir_path = get_real_path(dir_path);
    }

    std::vector<std::string> vec_files;
    DIR *dir = opendir(dict_dir.c_str());
    if (dir == nullptr) {
        LOG_DICT("dict: ["+m_name+"] load failed, class: ["+m_clazz_name+"], error: open directory fail, dir: "+dict_dir);
        dictErrorManager.setError(DICT_DIR_EMPTY);
        return false;
    }
    //获取文件
    struct dirent *entry = nullptr;
    bool has_success = false;
    bool load_suc = true;
    while ((entry = readdir(dir)) != nullptr) {

        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0 || strcmp(entry->d_name, "_SUCCESS") == 0){
            continue;
        }else if(strcmp(entry->d_name, "SUCCESS") == 0) {
            has_success = true;
            continue;
        }else if (strcmp(entry->d_name, "_TASK_INFO") == 0) {   //读取task_info文件内容
            continue;
        }else{
            LOG_DICT("dict: ["+m_name+"] "+ " class: ["+m_clazz_name+"], dict file name: ["+entry->d_name+"] begin to load");
            vec_files.emplace_back(entry->d_name);
        }
    }
    closedir(dir);
    if(has_success == false){
        LOG_DICT("dict: ["+m_name+"] "+ " load failed, class: ["+ m_clazz_name +"], error: no success file, dir: " + dict_dir );
        dictErrorManager.setError(DICT_NO_SUCC_FILE);
        return false;
    }
    
    std::sort(vec_files.begin(), vec_files.end(), [](const std::string& x, const std::string& y) { return x < y; });
    auto data_info = get_data_bak_ptr();
    for (auto& file: vec_files) {
       load_suc &= load_from_one_file(dir_path,file,data_info);
    }
    if(this->parse_failed_num > 0 ) {
        LOG_DICT("dict: ["+m_name+"] "+ " load from one file failed, class: ["+ m_clazz_name +"], error: some content parse failed, dir: "+ dir_path+ " [parse failed_num]: " + std::to_string(this->parse_failed_num) );
        load_suc = false;
    }
    if(load_suc) {
        bool set_task_succ = set_task_info(dir_path);
        if(!set_task_succ) {
            LOG_DICT("dict: ["+ m_name+ "] "+ " set task file failed, class: ["+ m_clazz_name +"], task file dir: "+ dir_path );
            load_suc = false;
        }

    }
    
    return load_suc;
}

time_t DictInfo::file_mtime(const std::string& file) {
    if (file.empty()) {
        return 0;
    }
    struct stat st;
    int ret = lstat(file.c_str(), &st);
    if (ret < 0) {
        LOG_DICT(file+ "stat "
            + file + " error:"
            + strerror(errno));
        return 0;
    }
    return st.st_mtime;
}

std::string DictInfo::get_real_path(const std::string& symlink){
    char buf[PATH_MAX] = {0};
    ssize_t len = readlink(symlink.c_str(), buf, sizeof(buf) - 1);
    if (len == -1) {
        return "";
    }
    buf[len] = '\0';

    char real_path[PATH_MAX] = {0};
    if (realpath(buf, real_path) == NULL) {
        return "";
    }

    return std::string(real_path);
}

bool DictInfo::is_symlink(const std::string& path){
    struct stat statbuf;
    if (lstat(path.c_str(), &statbuf) != 0) {
        return false;
    }
    return S_ISLNK(statbuf.st_mode);
}

bool DictInfo::is_directory(const std::string&path){
    struct stat statbuf;
    if (stat(path.c_str(), &statbuf) != 0) {
        return false;
    }
    return  is_directory(statbuf);
}

bool DictInfo::is_file(const std::string&path){
    struct stat statbuf;
    if (stat(path.c_str(), &statbuf) != 0) {
        return false;
    }
    return  is_file(statbuf);
}

bool  DictInfo::is_directory(const struct stat&statbuf){
    return S_ISDIR(statbuf.st_mode);
}

bool  DictInfo::is_file(const struct stat&statbuf){
 return S_ISREG(statbuf.st_mode);
}

bool DictInfo::has_success_file(const std::string& dir_path) {
    const std::string success_file = dir_path + "/SUCCESS";
    struct stat info{};
    return stat(success_file.c_str(), &info) == 0 && S_ISREG(info.st_mode);
}

//get the latest second sub dir that contain success file
std::string DictInfo::get_latest_directory(const std::string& directory) {
    if(!is_directory(directory)) return "";
    std::vector<std::string> first_level_dirs;
    if(!get_sub_dir(directory,first_level_dirs)) return "";

    if (first_level_dirs.empty()) return "";    
    std::sort(first_level_dirs.begin(), first_level_dirs.end(), std::greater<std::string>());
    for (size_t i = 0; i < first_level_dirs.size(); ++i) {
        const std::string& current_first_level_dir = first_level_dirs[i];

        if (!is_directory(current_first_level_dir)) continue;

        std::vector<std::string> second_level_dirs;

        if (!get_sub_dir(current_first_level_dir, second_level_dirs)) continue;
        
        if (second_level_dirs.empty()) continue;

        std::sort(second_level_dirs.begin(), second_level_dirs.end(), std::greater<std::string>());

        for (const std::string& second_level_dir : second_level_dirs) {
            if (has_success_file(second_level_dir)) {
                m_day_version = current_first_level_dir;
                m_minute_version = second_level_dir;
                return second_level_dir; 
            }
        }
    }
    return "";
}

bool DictInfo::get_sub_dir(const std::string& parent_path, std::vector<std::string>& sub_dirs) {
    if(parent_path.empty()) return false;
    DIR* dir = opendir(parent_path.c_str());
    if (dir == nullptr) return false;

    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        if (std::string(entry->d_name) == "." || std::string(entry->d_name) == "..") {
            continue;
        }
        const std::string fullPath = parent_path + "/" + entry->d_name;
        struct stat info{};
        if (lstat(fullPath.c_str(), &info) == 0 && S_ISLNK(info.st_mode)) {
            continue; 
        }
        if (stat(fullPath.c_str(), &info) == 0 && S_ISDIR(info.st_mode)) {
            sub_dirs.emplace_back(fullPath); 
        }
    }

    closedir(dir);
    return true;
}

//get the latest version of dict from m_latest_dir
std::string DictInfo::get_latest_version() {
    std::string combined_time = "";
    size_t last_slash = m_latest_dir.rfind('/');
    if (last_slash == std::string::npos) {
        return "default";
    }
    size_t second_last_slash = m_latest_dir.rfind('/', last_slash - 1);
    if (second_last_slash == std::string::npos) {
        return "default";
    }

    std::string pt_d = m_latest_dir.substr(second_last_slash + 1, last_slash - second_last_slash - 1);
    std::string pt_h = m_latest_dir.substr(last_slash + 1);
    combined_time = pt_d + pt_h;
    
    return combined_time;
}

int64_t DictInfo::get_version(const std::string& version_str) {
    int64_t version = -1;
    size_t last_slash = version_str.rfind('/');
    if (last_slash == std::string::npos) {
        return -1;
    }
    try{
        version = std::stol(version_str.substr(last_slash + 1));
    } catch(const std::exception& e) {
        LOG_DICT( "version tras failed, not a num of str, version_str: "+ version_str );
        return -1;
    }
     
    return version;
}

//DictRegisterMgr
std::shared_ptr<DictRegisterMgr> DictRegisterMgr::instance(){
    static std::shared_ptr<DictRegisterMgr> handle = std::shared_ptr<DictRegisterMgr>(new DictRegisterMgr());
    return handle;
}

}