#include <fcntl.h>
#include <iostream>
#include <sys/stat.h>
#include <unistd.h>
#include <chrono>
#include <thread>

// 文件路径
const char* FILE_PATH = "test_file.txt";
const size_t TRUNCATED_SIZE = 1024; // 截断后的文件大小

int main() {
    // 延迟以确保 `reader` 程序已经开始读取文件
    std::this_thread::sleep_for(std::chrono::seconds(1));

    std::cout << "Truncating file to " << TRUNCATED_SIZE << " bytes..." << std::endl;
    if (truncate(FILE_PATH, TRUNCATED_SIZE) == -1) {
        perror("Failed to truncate file");
        return 1;
    }

    std::cout << "File truncated successfully." << std::endl;

    return 0;
}