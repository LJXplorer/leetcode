#ifndef _HI_DICT_H_
#define _HI_DICT_H_

#include "callback.h"
#include "dict_logger.h"
#include <cstdint>
#include <string>
#include <memory>
#include <atomic>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <vector>
#include <iostream>
#include <dirent.h>
#include <map>
#include <string.h>
#include <limits.h>
#include <fstream>
namespace hidict {
template <class T> 
struct DictDataInfo {
public:
    std::shared_ptr<T> m_dict[2];
    std::atomic<int32_t> m_dict_idx;
public:
    DictDataInfo() : m_dict_idx(0) {
        m_dict[0] = nullptr;
        m_dict[1] = nullptr;
    }
    ~DictDataInfo(){
    }

    virtual void reset(int32_t idx){

    }

};

//从词典中的_TASK_INFO文件中获取的信息
struct TaskInfo {
    std::string table_name = "default_talbe";
    int count = 0;
    std::string version = "default_version";
};
 
enum DictErrorCode {
    DICT_DIR_EMPTY = 1 << 0, 
    DICT_NO_SUCC_FILE = 1 << 1,
    DICT_NO_TASK_INFO = 1 << 2,
    DICT_VALUE_EMPTY = 1 << 3,
    DICT_PARSE_FAILED = 1 << 4,
    DICT_DATA_NULL = 1 << 5,
    DICT_DATA_SIZE_LESS2 = 1 << 5,
    DICT_VALUE_TYPE_UNKNOWN = 1 << 6,
    DICT_REPEATED_KEY = 1 << 7,
};
class DictErrorManager {
private:
    int32_t errorField; 
public:
    DictErrorManager() : errorField(0) {}

    void setError(DictErrorCode error) {
        errorField |= error; 
    }

    void clearError(DictErrorCode error) {
        errorField &= ~error; 
    }

    bool hasError(DictErrorCode error) const {
        return (errorField & error) != 0; 
    }

    void printErrorField() const {
        LOG_DICT( "Error Field (binary): ");
        for (int i = 31; i >= 0; --i) {
            LOG_DICT( std::to_string(((errorField >> i) & 1)));
        }
    }

    void clearAllErrors() {
        errorField = 0; 
    }

    int32_t getErrorField() {
        return errorField;
    }
};

class DictInfo {
 public:
    std::string m_name;
    std::string m_path;
    std::string m_clazz_name;
    int64_t m_last_refresh_tm = 0;
    int64_t m_modify_tm = 0;
    TaskInfo m_task_info;
    std::string m_latest_dir;
    bool is_no_version = false;
    int64_t parse_failed_num = 0;
    DictErrorManager dictErrorManager;
    DictCallback* call_back_ = nullptr;
    std::string m_day_version = "0";
    std::string m_minute_version = "0";
    int32_t data_null_count = 100;
    int32_t data_parse_failed_count = 100;
    int32_t data_value_empty_count = 100;
    int32_t data_value_type_unknown_count = 100;
    int64_t load_time_consuming = 0;
    int32_t load_succ_num = 0;
 public:
    DictInfo() {}
    virtual ~DictInfo() { 
        if (call_back_ != nullptr) {
            delete call_back_;
        }
    }
    void register_callback(DictCallback* dict_callback) {
        this->call_back_ = dict_callback;
        this->call_back_->dict_info_ = this;
    }
    virtual int init(const std::string& dict_name,const std::string& path) = 0;
    virtual bool load(bool is_offline);
    virtual const std::string& get_dict_file(bool is_offline);
    virtual bool pre_free(time_t n) {
        this->dictErrorManager.clearAllErrors();
        this->parse_failed_num = 0;
        this->data_parse_failed_count = 100;
        this->data_null_count = 100;
        this->data_value_empty_count = 100;
        this->load_time_consuming = 0;
        this->load_succ_num = 0;
        return true;
    }

    virtual bool exchange(time_t n) = 0;

    bool post_load(time_t n,bool load_suc) {
        if (this->call_back_ != nullptr) {
            this->call_back_->OnLoadFinished(n, load_suc);
            return true;
        }
        return false;
    };

    void error_call_back(){
        if (this->call_back_ != nullptr) {
            this->call_back_->OnError();
        }
    }

    virtual bool load_by_condition(time_t n, bool is_offline) ;

    inline time_t file_mtime(const std::string& file);
    bool is_symlink(const std::string& path);
    bool is_directory(const std::string&path);
    bool is_file(const std::string&path);
    std::string get_latest_directory(const std::string& directory);
    bool get_sub_dir(const std::string& parent_path, std::vector<std::string>& sub_dirs);
    std::string get_latest_version();
    std::string get_real_path(const std::string& symlink);
    virtual bool load_from_one_file(const std::string& path,const std::string& dict_file,void* data) = 0;
    virtual bool fill_dict_data(const std::vector<std::string>&src,void* data) = 0;
    //data
    virtual void gen_data_info() = 0; 
    virtual const void* get_data_ptr() const = 0;
    virtual void* get_data_bak_ptr() = 0;

    virtual const void* get_value_reflection() const = 0;
    virtual const void* get_value_descriptor() const = 0;
    int64_t  get_version(const std::string& version_str);
    
    template <class T> 
    const T* get_data() const {
        auto info = get_data_ptr() ;
        if(info == nullptr) return nullptr;
        return ((T*)info);
    }

    template <class T>
    T* get_bak_data(){
        auto info = get_data_bak_ptr();
        if(info == nullptr) return nullptr;
        return ((T*)info);
    }

    //获取task_info文件内容
    virtual bool set_task_info(const std::string& path) = 0;
    private:
        bool  is_directory(const struct stat&stat_file);
        bool  is_file(const struct stat&stat_file);
        bool  has_success_file(const std::string& dir_path);
};

template <class T> 
class Dict : public DictInfo,public DictDataInfo<T>  {
 public:
    Dict(){

    }

    virtual ~Dict() {

    }

    virtual bool exchange(time_t n){
        m_last_refresh_tm = n;
        int dict_idx = this->m_dict_idx.load(std::memory_order_relaxed);
        int bg_idx = 1 - dict_idx;
        LOG_DICT("[" +std::to_string(time(NULL)) +"] dict ["+m_name+"]"+" class ["+m_clazz_name+"]"+" exchange dict_idx:"+ std::to_string(dict_idx) +" ,bg_idx: "+std::to_string(bg_idx));
        this->m_dict_idx.compare_exchange_strong(dict_idx, bg_idx, std::memory_order_acq_rel);
        LOG_DICT("[" +std::to_string(time(NULL)) +"] dict ["+m_name+"]"+" class ["+m_clazz_name+"]"+" exchange +2 dict_idx:"+ std::to_string(dict_idx) +" ,bg_idx:"+std::to_string(bg_idx));
        return true;
    }

    virtual void gen_data_info() = 0;

    virtual const void* get_data_ptr() const {
        int dict_idx = this->m_dict_idx.load(std::memory_order_relaxed);
        return (void*)(this->m_dict[dict_idx].get()); 
    }

    virtual void* get_data_bak_ptr(){
        int dict_idx = this->m_dict_idx.load(std::memory_order_relaxed);
        int last_idx = 1 - dict_idx;
        return (void*)(this->m_dict[last_idx].get()); 
    }

    virtual bool pre_free(time_t now) {
        int dict_idx = this->m_dict_idx.load(std::memory_order_relaxed);
        int last_idx = 1 - dict_idx;
        if(m_last_refresh_tm > 0 && now - m_last_refresh_tm > 30 
            && this->m_dict[last_idx].use_count() < 2 ){
                this->reset(last_idx);
        }
        this->dictErrorManager.clearAllErrors();
        this->parse_failed_num = 0;
        this->data_parse_failed_count = 100;
        this->data_null_count = 100;
        this->data_value_empty_count = 100;
        this->load_time_consuming = 0;
        this->load_succ_num = 0;
        return true;
    }

    virtual bool load_from_one_file(const std::string& path,const std::string& dict_file,void* data){

        std::string file_path(path);
        file_path.append("/").append(dict_file);

        std::ifstream infile(file_path, std::ios::in);
        if (!infile.is_open()) {
            LOG_DICT("open file failed, file path: " + file_path);
            return false;
        }

        std::vector<std::string> vec_line;
        std::string line;
        bool load_all_succ = true;

        while (std::getline(infile, line)) {
            vec_line.clear();

            size_t start = 0;
            size_t tab_pos = 0;
            while ((tab_pos = line.find('\t', start)) != std::string::npos) {
                vec_line.emplace_back(line.substr(start, tab_pos - start));
                start = tab_pos + 1;
            }
            vec_line.emplace_back(line.substr(start));

            load_all_succ &= fill_dict_data(vec_line, data);
        }

        infile.close();

        return load_all_succ;
    }

    virtual bool fill_dict_data(const std::vector<std::string>&src,void* data) = 0;

    virtual bool set_task_info(const std::string& path) {
         // open file
        std::string file_path(path);
        file_path.append("/").append("_TASK_INFO");
        int fd = open(file_path.c_str(), O_RDONLY);
        if (-1 == fd) {
            LOG_DICT( "open task info file failed, file path: " + file_path );
            return false;
        }
        // stat file
        struct stat sb;
        if (fstat(fd, &sb) == -1) {
            LOG_DICT( "fstat task info file failed, file path: " + file_path );
            return false;
        }

        // mmap
        int32_t length = sb.st_size;
        const char* p_buf = static_cast<const char*>(mmap(NULL, length, PROT_READ, MAP_PRIVATE, fd, 0));
        if (p_buf == nullptr || p_buf == MAP_FAILED) {
            std::cout << "mmap task info file failed, file path: " << file_path << std::endl;
            return false;
        }

        const char* start = p_buf; 
        const char* end = p_buf + length; 
        int line_count = 0; 

        const char* line_start = nullptr; 
        const char* line_end = nullptr;   

        //读取task_info中第二行的内容
        for (const char* it = start; it < end; ++it) {
            if (*it == '\n') {
                ++line_count;
                if (line_count == 1) {
                    line_start = it + 1;
                } else if (line_count == 2) {
                    line_end = it;
                    break;
                }
            }
        }
        std::string second_line;
        if (line_start && line_end && line_start < line_end) {
            second_line.assign(line_start, line_end);
        } else {
            LOG_DICT( "task info file Second line not found , file path: " + file_path );
            munmap((void*)p_buf, length); 
            close(fd); 
            return false;
        }

        //task_info
        size_t index_start = 0;
        size_t index_end = second_line.find(','); 
        std::vector<std::string> result;

        while (index_end != std::string::npos) {
            result.push_back(second_line.substr(index_start, index_end - index_start));
            index_start = index_end + 1; 
            index_end = second_line.find(',', index_start); 
        }
        result.push_back(second_line.substr(index_start));

        if(result.size() < 3) {
            LOG_DICT( "task info file parse error, size is less than 3, file path: " + file_path );
            return false;
        }

        try {
            m_task_info.table_name = result[0];
            m_task_info.count = std::stoi(result[1]);
            m_task_info.version = result[2];
        }catch (...) {
            LOG_DICT( "set task info failed!, file path: "+ file_path );
            // unmmap
            munmap((void*)p_buf, length);
            // close
            close(fd);
            return false;
        }
        

        // unmmap
        if(munmap((void*)p_buf, length) !=0)
        {
            LOG_DICT( "munmap task info failed! file path: " + file_path );
        }
        // close
        close(fd);

        return true;
    }
    virtual void log_error(DictErrorCode dict_error, const std::string &message) {
        switch (dict_error){
            case DICT_DATA_NULL: {
                //print head 100 data
                if(data_null_count > 0) {
                    LOG_DICT( "[dict class: "+this->m_clazz_name+" ], error: data null. " + message );
                    --data_null_count;
                }
                break;
            }
            case DICT_PARSE_FAILED: {
                if(data_parse_failed_count > 0) {
                    LOG_DICT( "[dict class: "+this->m_clazz_name+" ], error: content parse failed, key: " + 
                            message );
                    --data_parse_failed_count;
                }
                
                break;
            }
            case DICT_VALUE_EMPTY: {
                if(data_value_empty_count > 0) {
                    LOG_DICT( "[dict class: "+this->m_clazz_name+" ], error: content base64 empty, key: " + 
                            message );
                    --data_value_empty_count;
                }
                
                break;
            }
            case DICT_VALUE_TYPE_UNKNOWN: {
                if (data_value_type_unknown_count > 0) {
                    LOG_DICT( "[dict class: "+this->m_clazz_name+" ], path = [" + this->m_path + "]; error: value type unknown, key: " + message);
                }
            }
            default:
                break;
        }   
    }
};

class  DictFactory{
    public:
    DictFactory(){
    }
    virtual DictInfo* create() = 0;
};

class  DictRegisterMgr{
public:
    std::map<std::string, DictFactory*> m_global_dict_map;
    static std::shared_ptr<DictRegisterMgr> instance();
private:
    DictRegisterMgr() = default;
};


#define DICT_REGISTER(DictClass) class DictClass##Factory : public ::hidict::DictFactory { \
public: \
::hidict::DictInfo* create() override { \
    return new DictClass(); \
} \
}; \
class DictClass##Register { \
public: \
DictClass##Register() { \
    ::hidict::DictRegisterMgr::instance()->m_global_dict_map.insert({#DictClass, new DictClass##Factory()}); \
} \
}; \
static DictClass##Register DictClass##_inst_;

#define GET_DICT_FACTORY(DictClassName) ::hidict::DictRegisterMgr::instance()->m_global_dict_map[DictClassName];

} //hidict

#endif