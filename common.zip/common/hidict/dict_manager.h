#ifndef _HI_DICT_MANAGER_H_
#define _HI_DICT_MANAGER_H_

#include <functional>
#include <random>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string>
#include <random>
#include <unordered_map>
#include "common/hidict/callback.h"
#include "dict.h"

namespace hidict {

struct DictConfig{
   std::string m_name;
   std::string m_clazz;
   std::string m_path;
   std::string check_file;
};

class DictCollector {
 private:
    std::string m_name;
    bool is_offline = true;
    pthread_t m_pid = 0;
    std::unordered_map<std::string, DictInfo *> m_dict_hash;   //map: dict_name -> dictInfo 
    bool first_load_done = false;                              //flag of first loading
    bool load_all_succ_flag = false;                          //first loading result , for warning
    
 public:
    using CallbackRegisterFactory = std::function<DictCallback* (const std::string&)>;
    DictCollector()
    {}
    ~DictCollector() {
    }

    
    bool run( bool off = true);
    bool init(const std::string&name,const std::vector<DictConfig>&cfg,bool off = true, CallbackRegisterFactory callback_register_factory = nullptr);

    DictInfo*  register_dict(const std::string &dict_name,
                        const std::string& clazz,
                        const std::string& path);
   
    DictInfo * get_dict(const std::string &dict_name);

    template <class T>
    const T* get_data(const std::string &dict_name){
        auto info = get_dict(dict_name);
        if(info == nullptr){
            return nullptr;
        }
        return info->get_data<T>();
    }
    bool load_dict();
    bool get_first_load_done() { return first_load_done;}
    bool get_load_all_succ_flag() { return load_all_succ_flag;}
 private:
   static void* check(void* arg);
};

class DictCollectorManager{
private:
   std::unordered_map<std::string, std::shared_ptr<DictCollector> > m_dict_coll_hash;
public:
   DictCollectorManager();
   ~DictCollectorManager();
public:
   static DictCollectorManager& get_instance();
   std::shared_ptr<DictCollector> alloc_collector(const std::string&name);
   std::shared_ptr<DictCollector> get_collector(const std::string&name);
};



}  // hidict
#endif