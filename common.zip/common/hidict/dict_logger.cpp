#include "dict_logger.h"
#include "console_dict_logger.h"
#include <memory>

namespace hidict {

std::shared_ptr<DictLogger> DictLogger::dict_logger = nullptr;

void DictLogger::setLogger(std::shared_ptr<DictLogger> loggerInstance) {
    dict_logger = loggerInstance;
}

std::shared_ptr<DictLogger>& DictLogger::getLogger() {
    if (!dict_logger) {
        static auto defaultLogger = std::make_shared<ConsoleDictLogger>();
        dict_logger = std::move(defaultLogger);  
    }
    return dict_logger;
}

} // namespace hidict