#pragma once
#include "dict_logger.h"
#include <iostream>

namespace hidict {

class ConsoleDictLogger : public DictLogger {
public:
    void hiLogWriter(const std::string& message) override {
        std::cout << message << std::endl;
    }
};

} // namespace hidict