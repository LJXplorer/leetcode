#pragma once
#include <memory>
#include <string>

namespace hidict {

class DictLogger {
public:
    virtual ~DictLogger() = default;

    virtual void hiLogWriter(const std::string& message) = 0;

    static void setLogger(std::shared_ptr<DictLogger> loggerInstance);

    static std::shared_ptr<DictLogger>& getLogger();

private:
    static std::shared_ptr<DictLogger> dict_logger;
};

} // namespace hidict
#define LOG_DICT(content) \
    hidict::DictLogger::getLogger()->hiLogWriter(std::string("[") +  __FILE__ + ":" + std::to_string(__LINE__) + "]: " + content)

