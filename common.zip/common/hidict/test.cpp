#include <string>
#include <map>
#include "dict_manager.h"
//#include "common/hilog/log_helper.h"
using namespace std;
using namespace hidict;

using map_dict_type = std::map<string,string>;
class Mapdict : public Dict< map_dict_type > {
public:
    Mapdict(){

    }
    virtual ~Mapdict(){

    }
     virtual int init(const std::string& dict_name,const std::string& path){
        m_name = dict_name;
        m_path = path;
        return 0;
     }
      virtual const void* get_value_reflection() const override {
         return nullptr;
      }
       virtual const void* get_value_descriptor() const override {
         return nullptr;
       }
     
     bool fill_dict_data(const std::vector<std::string>&src,void* data){
        map_dict_type* map_data = (map_dict_type*)data;
        if(src.size() >= 2) map_data->insert({src[0],src[1]});
        std::cout<<"Mapdict: size "<<src.size()<<",item size:"<<map_data->size()<<std::endl;
        return true;
     }
     virtual void gen_data_info() override {};
};
DICT_REGISTER(Mapdict);

int main(int argc,char* argv[]) 
{
    //hilog::global_helper().initialize("dict", "./log/");
   //  DictCollector coll_test;
   //  coll_test.register_dict("map","Mapdict","./test");
   //  coll_test.run(false);
   //  while (true)
   //  {
   //     sleep(30);

   //    const auto map_data = coll_test.get_data<map_dict_type>("map");
   //    if(map_data == nullptr) std::cout<<"map_data nullptr"<<std::endl;
   //    std::cout<<"Mapdict: main size "<<map_data->size()<<std::endl;
   //    for(auto&m : *map_data){
   //       std::cout<<"m "<<m.first<<","<<m.second<<std::endl;

   //    }
   //  }
   Mapdict map_dict;
   std::cout<< " get latest dir from: "<<argv[1] <<" parent dir: " << map_dict.get_latest_directory(argv[1]);

    return 0;
}