#pragma once
#include "counter.h"
#include <cstddef>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

// 指标清单
#define METRIC_LIST(X)                                                                                                 \
    X(TOTAL)                                                                                                           \
    X(KEY_FOUND)                                                                                                       \
    X(MAP_OR_KEY_EMPTY)                                                                                                \
    X(MAP_NOT_FOUND)                                                                                                   \
    X(KEY_NOT_FOUND)
namespace hidict {

    enum class Metric : uint8_t {
#define ENUM_ELEM(name) name,
        METRIC_LIST(ENUM_ELEM)
#undef ENUM_ELEM
                _COUNT
    };

    static inline constexpr size_t METRICS = static_cast<size_t>(Metric::_COUNT);

    static inline const char *kMetricNames[METRICS] = {
#define NAME_ELEM(name) #name,
            METRIC_LIST(NAME_ELEM)
#undef NAME_ELEM
    };

    struct CounterCell {
        std::array<Counter::ShardedDelta<>, METRICS> metrics{};
        inline void inc(Metric m, uint64_t x = 1) noexcept {
            metrics[static_cast<size_t>(m)].add(x);
        }

        inline void drain_into(uint64_t *out) noexcept {
            for (size_t i = 0; i < METRICS; ++i) {
                out[i] = metrics[i].drain();
            }
        }
    };

    struct SimplifyDictInfo {
        std::string path;
        std::string clazz_name;
    };

    struct SvHash {
        using is_transparent = void;
        size_t operator()(std::string_view s) const noexcept {
            return std::hash<std::string_view>{}(s);
        }
    };
    struct SvEq {
        using is_transparent = void;
        bool operator()(std::string_view a, std::string_view b) const noexcept {
            return a == b;
        }
    };

    class DictCounters {
    public:
        DictCounters() {
            register_cell("default", "default");
        }

        struct Handle {
            uint32_t id{0};
            CounterCell *cell{nullptr};
            // 供热路径调用
            inline void inc(Metric m, uint64_t x = 1) const noexcept {
                cell->inc(m, x);
            }
            inline bool valid() const noexcept {
                return cell != nullptr;
            }
        };

        // 供初始化期调用
        Handle register_cell(std::string path, std::string clazz_name) {
            auto it = index_.find(path);
            if (it != index_.end()) {
                uint32_t id = it->second;
                return Handle{id, cells_[id].get()};
            }
            infos_.push_back({std::move(path), std::move(clazz_name)});
            cells_.push_back(std::make_unique<CounterCell>());
            uint32_t id = static_cast<uint32_t>(cells_.size() - 1);
            index_.emplace(infos_.back().path, id);
            return Handle{id, cells_[id].get()};
        }

        Handle lookup_by_path(std::string_view path) const noexcept {
            auto it = index_.find(std::string(path));
            if (it == index_.end())
                return Handle{};// cell==nullptr 无效
            uint32_t id = it->second;
            return Handle{id, cells_[id].get()};
        }

        // clazz_name 在初始化时已经存储了，可以通过path去找
        bool inc(std::string_view path, Metric m, uint64_t x = 1) const noexcept {
            auto h = lookup_by_path(path);
            if (!h.valid())
                return false;
            h.inc(m, x);
            return true;
        }

        // 运行期 定时上报（增量清零）
        template<class Sink>
        void drain_all(Sink &&sink) {
            uint64_t buf[METRICS];
            for (size_t i = 0; i < cells_.size(); ++i) {
                cells_[i]->drain_into(buf);
                sink(infos_[i].path, infos_[i].clazz_name, buf, METRICS);
            }
        }

    private:
        // 启动期 push_back，运行期只读 无需锁
        std::vector<std::unique_ptr<CounterCell>> cells_;
        std::vector<SimplifyDictInfo> infos_;
        std::unordered_map<std::string, uint32_t, SvHash, SvEq> index_;// path -> id
    };

    inline std::unique_ptr<DictCounters> g_counters_ptr = nullptr;
}// namespace hidict