#pragma once

#include "common/comm/config_xml.h"
#include "common/comm/double_buffer.h"
#include "common/config/base_config.h"
#include "common/hilog/log_helper.h"
#include "core/utils/defs.h"
#include "phx-fe/ad_dict/ad_dict_manager.h"
#include "phx-fe/util/item_class.h"
#include "phx-fe/util/util.h"
#include <brpc/channel.h>
#include <cstdint>
#include <log_helper.h>
#include <spdlog_helper.h>
#include <memory>
#include <service_config.h>
#include <shared_mutex>
#include <string>
#include <unordered_map>
namespace Core::Info {

    enum class ModelType {
        UNKNOWN,
        ITEM_EMBEDDING,
        USER_EMBEDDING,
    };

    inline const char *model_type_to_string(ModelType type) {
        switch (type) {
            case ModelType::ITEM_EMBEDDING:
                return "item_embedding";
            case ModelType::USER_EMBEDDING:
                return "user_embedding";
            case ModelType::UNKNOWN:
                return "UNKNOWN";
            default:
                return "INVALID_TYPE";
        }
    }

    class ModelInfo {
    private:
        brpc::Channel _channel;                 //通过北极星获得的信息初始化的channel

        std::shared_ptr<ConfigInfo> _config_info;

        static std::vector<unsigned char> getKey(const std::string &key);
        static std::vector<unsigned char> base64Decode(const std::string &encoded);
        static std::string decrypt(const std::string &base64Str, const std::string &keyStr, const std::string &ivStr);

    public:
        brpc::ChannelOptions _options;
        std::string _model_name;
        int64_t _model_id = -1;
        std::string _model_url;                                               //使用北极星的地址
        std::string _protocol_type = "baidu_std";                             //初始化 Channel 时使用
        brpc::ConnectionType _connection_type;                              //初始化 Channel 时使用
        std::string _lb = "cb";                                               //load_balancer
        std::string _model_config_path;                                       //模型使用的文件所在cos路径
        std::string _fe_config_file_name = "fe_config.xml";                   //fe_config 文件名
        bool _use_encrypted_fe_config = true;                                 //默认使用加密fe_config配置文件
        std::string _model_input_config_file_name = "model_input_config.yaml";//model_input_config 文件名
        std::string _multi_pos_config_file = "";          //多位置预估广告位配置 文件名
        bool _multi_pos_flag = false;

        std::string _fe_config_content;         //fe_config.xml 加密的文件内容
        std::string _model_input_config_content;//model_input_config.xml 明文文件内容
        std::string _fe_config_content_md5;

        ModelType _model_type = ModelType::UNKNOWN;//粗排使用，区分item和model模型

        std::string _pair_model;//粗排使用，用于识别对应的
        std::string _dict_name; //粗排 item 模型使用的 词典名
        std::string _dict_path; //粗排 item 模型使用的 词典路径
        std::unordered_map<int64_t, int64_t> _adunit_pos_info; //多位置预估广告位配置信息
        std::string _emb_name; // 向量召回使用 暴露给商推的模型名，同一对item和user共用一个模型名
        bool _is_ltr = false; // 向量召回使用 是否使用ltr

        brpc::CompressType _request_compress_type = brpc::COMPRESS_TYPE_NONE;
        AdDict::AdDictCollector *_model_dict_collector;
        ModelInfo() {
            // _channel = new brpc::Channel();
            _options.timeout_ms = 80;
            _options.backup_request_ms = -1;
            _options.max_retry = 0;
        }

        ModelInfo(const ModelInfo &) = delete;

        ModelInfo &operator=(const ModelInfo &) = delete;

        ModelInfo(ModelInfo &&other) = delete;
        int init();
        //全部使用北极星的channel
        brpc::Channel *get_channel();
        const std::string &get_name() {
            return _model_name;
        }
        bool load_fe_config();         //解析 fe_config
        bool load_model_input_config();//解析 model_input_config、
        bool load_multi_pos_config();  //解析多位置预估配置文件
        bool read_file(const std::string &file_path, std::string &content);
        bool decrypt_fe_config();
        
        int64_t get_adunit_pos_info(int64_t adunit_id);

        const std::string &get_model_path() {
            return _model_config_path;
        }

        const ConfigInfo &get_config_info() {
            return *_config_info;
        }

        std::shared_ptr<ConfigInfo> get_config_info_ptr() {
            return _config_info;
        }

        void set_config_info(const ConfigInfo &config_info) {
            if (_config_info) {
                *_config_info = config_info;
            } else {
                _config_info = std::make_shared<ConfigInfo>(config_info);
            }
        }

        const std::string &get_dict_name() {
            return _dict_name;
        }
        std::vector<std::shared_ptr<Config>> &get_fe_config();

        std::string to_string() const {
            std::ostringstream oss;
            oss << "model_info ModelInfo {"
                << "\n model_info Model Name: " << _model_name << "\n model_info Model URL: " << _model_url
                << "\n model_info Model Config Path: " << _model_config_path
                << "\n model_info Use Encrypted Fe Config:" << _use_encrypted_fe_config
                << "\n model_info FE Config File Name: " << _fe_config_file_name
                << "\n model_info Model Input Config File Name: "
                << _model_input_config_file_name
                // << "\n model_info FE Config Content: " << _fe_config_content
                // << "\n model_info Model Input Config Content: " << _model_input_config_content
                << "\n model_info Model Type: " << static_cast<int>(_model_type)// 假设 ModelType 是一个枚举
                << "\n model_info Pair Model: " << _pair_model << "\n model_info Dict Name: " << _dict_name
                << "\n model_info Request Compress Type: "
                << static_cast<int>(_request_compress_type)// 假设 CompressType 是一个枚举
                << "\n model_info Connection Type: " << _connection_type
                << "\n model_info Protocol Type: " << _protocol_type
                << "\n model_info Timeout ms: " << _options.timeout_ms
                << "\n model_info Backup Timeout ms: " << _options.backup_request_ms
                << "\n model_info Max Retry: " << _options.max_retry << "\n model_info }";

            return oss.str();
        }
    };

    using model_info_map = std::unordered_map<std::string, std::shared_ptr<ModelInfo>>;
    using emb_model_name_map = std::unordered_map<std::string, std::string>;

    class ModelInfoManager {
    private:
        DBuffer<model_info_map> _model_info_maps;
        DBuffer<emb_model_name_map> _emb_model_name_maps; // 向量召回用，存储商推侧调用的模型名称（item和user共用）和算法内部实际模型名的映射
        std::string _common_model_path;

        void handle_error_on_first_load();
        const std::unordered_set<std::string> _load_balancers = {
            "rr", "cb" 
        };
    public:
        FEDictMap _fe_dict_map;
        static ModelInfoManager &instance();
        std::unordered_map<std::string, std::shared_ptr<ModelInfo>> &get_model_infos();
        brpc::Channel *get_channel(const std::string &model_name);
        std::shared_ptr<ModelInfo> get_model_info(const std::string &model_name);
        void get_emb_model_name(const std::string &emb_name, const ModelType &model_type, std::string &model_name);
        // ModelInfoManager 通过调用 update 来实现初始化和更新，故没有 init 函数
        int update(const std::string &content) noexcept;
        int init(const config::ConfigServiceCfg &cfg, const std::string &group_id, const std::string &data_id);
        int init_model_config();
        const std::string &get_model_path(const std::string &name);

        static std::string
        model_info_map_to_string(const std::unordered_map<std::string, std::shared_ptr<ModelInfo>> &model_info_map) {
            std::ostringstream oss;
            oss << "ModelInfo Map {\n";

            for (const auto &pair: model_info_map) {
                const std::string &key = pair.first;
                const std::shared_ptr<ModelInfo> &modelInfoPtr = pair.second;

                oss << " model_info Key: " << key
                    << ", Value: " << (modelInfoPtr ? modelInfoPtr->to_string() : "nullptr") << "\n";
            }

            oss << "model_info }";
            return oss.str();
        }

        static bool safe_string_to_int(const std::string &str, int &out_value) {
            std::istringstream iss(str);
            iss >> out_value;
            return !iss.fail() && iss.eof();
        }

        static bool safe_read_int_attr(const ConfigXml &xml, const std::string &attr_name, int &out_value) {
            std::string value_str;
            xml.attr<std::string>(attr_name, value_str);
            if (!value_str.empty()) {
                int value = 0;
                if (safe_string_to_int(value_str, value)) {
                    out_value = value;
                    return true;
                } else {
                    LOG_ERROR << "Invalid " << attr_name << " value: " << value_str;
                    return false;
                }
            }
            // 属性为空时不报错，保持原值
            return true;
        }
    };

    struct ModelInfoNacosConfig : public config::ListenableConfig {
        std::string group_id;
        std::string data_id;
        ModelInfoNacosConfig(const std::string &group_id, const std::string &data_id)
            : group_id(group_id), data_id(data_id) {
        }

        int OnConfigChanged(const std::string &new_config) override {

            LOG_INFO << "data id:" << data_id << "new config: \n" << new_config;
            return ModelInfoManager::instance().update(new_config);
        }

        config::ConfigSource GetConfigSource() override {
            return {.group_id = group_id, .data_id = data_id};
        }
    };
}// namespace Core::Info