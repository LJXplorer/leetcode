#include "fe_service.h"
#include "core/core_context/context_defs.h"
#include "core/core_context/core_context.h"
#include "core/core_context/monitor_context.h"
#include "core/core_context/prerank_context.h"
#include "core/utils/error.h"
#include "core/utils/monitor_mgr.h"
#include "hlframe/register.h"
#include "phx-fe/src/framework.h"
#include "phx-fe/src/session.h"
#include "phx-fe/util/util.h"
#include <bthread/bthread.h>
#include <bthread/types.h>
#include <butil/time.h>
#include <bvar/latency_recorder.h>
#include <debug_utils.h>
#include <exception>
#include <glog/logging.h>
#include <google/protobuf/arena.h>
#include <google/protobuf/descriptor.h>
#include <log_helper.h>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
namespace Core {
    SERVICE_REGISTER(FeService);

    bool FeService::skip(GraphContextPtr context) {
        auto core_context = dynamic_pointer_cast<CoreContext>(context);
        if (core_context == nullptr) {
            LOG_ERROR << "context is not core context! node name = [" << this->get_name() << "], skip this node";
        }
        if (extract_type_ == ExtractType::kUser) {
            switch (model_type_) {
                case Core::ExperimentModelType::CPC_CTR:
                    return core_context->_cpc_ctr_model_map.empty();
                case Core::ExperimentModelType::CPC_CVR:
                    return core_context->_cpc_cvr_model_map.empty();
                case Core::ExperimentModelType::CPD_CTR:
                    return core_context->_cpd_ctr_model_map.empty();
                case Core::ExperimentModelType::CPD_CVR:
                    return core_context->_cpd_cvr_model_map.empty();
                case Core::ExperimentModelType::LTV:
                    return core_context->_ltv_model_map.empty();
                default:
                    return true;
            }
        } else {
            switch (model_type_) {
                case Core::ExperimentModelType::CPC_CTR:
                    return core_context->_model_predict_cpc_ctr_map.empty();
                case Core::ExperimentModelType::CPC_CVR:
                    return core_context->_model_predict_cpc_cvr_map.empty();
                case Core::ExperimentModelType::CPD_CTR:
                    return core_context->_model_predict_cpd_ctr_map.empty();
                case Core::ExperimentModelType::CPD_CVR:
                    return core_context->_model_predict_cpd_cvr_map.empty();
                case Core::ExperimentModelType::LTV:
                    return core_context->_model_predict_ltv_map.empty();
                default:
                    return true;
            }
        }

        return false;
    }

    int FeService::ItemFeatureExtract(CoreContextPtr core_context) {
        int ret = SplitExtract(core_context, phx_fe::ItemConfigsGetter, phx_fe::ItemModelSlotsGetter);
        auto &item_extract_rsp_map = core_context->get_fe_context()->MutableSplit()->operator[](this->model_type_);
        auto &user_extract_rsp_map = core_context->get_fe_context()->MutableSessions()->operator[](this->model_type_);
        if (unlikely(item_extract_rsp_map.size() > user_extract_rsp_map.size())) {
            return ERROR_FE_SESSION_NOT_FOUND;
        }
        for (auto &[model_info, item_extract_rsp]: item_extract_rsp_map) {
            auto user_iter = user_extract_rsp_map.find(model_info);
            if (unlikely(user_iter == user_extract_rsp_map.end())) {
                return ERROR_FE_SESSION_NOT_FOUND;
            }
            auto *user_feature_extractor_response = user_iter->second.user_feature_extractor_response;
            if (item_extract_rsp.empty()) {
                continue;
            }

            if (item_extract_rsp[0].extractor_response->user_features_size() > 0) {
                MonitorMgr::common_report_model(model_info->_model_name, "default",
                                                std::to_string(core_context->get_algo_scene_id()), "0", 0,
                                                "if_extract_failed", 1);
                debug::pb::SavePbToFile("failed_item_extract_" + this->get_name() + ".json",
                                        *(item_extract_rsp[0].extractor_response));
                LOG_ERROR << "item_extract_rsp should not have user feature!";
            }
            auto user_feature_size = user_feature_extractor_response->user_features_size();
            item_extract_rsp[0].extractor_response->mutable_user_features()->Reserve(user_feature_size);
            for (int32_t i = 0; i < user_feature_size; ++i) {
                item_extract_rsp[0].extractor_response->mutable_user_features()->AddAllocated(
                        user_feature_extractor_response->mutable_user_features(i));
            }
        }

        return ret;
    }

    int FeService::do_service(GraphContextPtr context) {
        LOG_INFO << "FeService::do_service start";
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        int ret = ERROR_SUCCESS;
        switch (extract_type_) {
            case ExtractType::kUser:
                ret = UserFeatureExtract(ctx);
                break;
            case ExtractType::kItem:
                ret = ItemFeatureExtract(ctx);
                break;
            case ExtractType::kAll:
                ret = SplitExtract(ctx, phx_fe::DefaultConfigsGetter, phx_fe::DefaultModelSlotsGetter);
                break;
        }

        LOG_INFO << "FeService::do_service end";
        return ret;
    }

    int FeService::UserFeatureExtract(CoreContextPtr core_context) {
        int ret = ERROR_SUCCESS;
        auto *fe_request = core_context->get_fs_context()->get_feature_dump();
        auto *user_fe_request =
                google::protobuf::Arena::CreateMessage<::phx::FeRequest>(core_context->get_context_arena());
        // 先加两个防止core dump
        user_fe_request->add_item_fea();
        user_fe_request->add_item_fea();
        auto *empty_user_action =
                google::protobuf::Arena::CreateMessage<phx::UserAction>(core_context->get_context_arena());
        ShallowCopyUserFeature(fe_request, user_fe_request);
        phx_fe::Options user_extract_options;
        user_extract_options.arena = core_context->get_context_arena();
        user_extract_options.expected_batch_size = 1;
        user_extract_options.is_ltr = false;
        user_extract_options.configs_supplier = phx_fe::UserConfigsGetter;
        user_extract_options.model_slots_getter = phx_fe::UserModelSlotsGetter;
        auto &fe_session_map = core_context->get_fe_context()->MutableSessions()->at(this->model_type_);
        for (auto &[exp_model_info, fe_session]: fe_session_map) {
            if (exp_model_info->_model_info->get_config_info_ptr() == nullptr) {
                LOG_ERROR << "model name = [" << exp_model_info->_model_name << "], fe config is null!";
                continue;
            }
            long start_user_fe = butil::gettimeofday_us();
            try {
                std::unordered_map<std::string, Output> inc_cache;
                phx_fe::ToExtractorResponse(*fe_request, *empty_user_action,
                                            exp_model_info->_model_info->get_config_info(), fe_session.session,
                                            user_extract_options, fe_session.user_feature_extractor_response,
                                            &inc_cache);
                fe_session.session.cache.swap(inc_cache);
            } catch (const std::exception &exception) {
                LOG_ERROR << "model name = [" << exp_model_info->_model_name
                                 << "], user feature extraction failed, msg = [" << exception.what() << "]";
                ret = ERROR_FE_UF_EXTRACT_FAILED;
            } catch (...) {
                LOG_ERROR << "model name = [" << exp_model_info->_model_name
                                 << "], user feature extraction failed, unknown exception!";
                ret = ERROR_FE_UF_EXTRACT_FAILED;
            }
            MonitorMgr::percent_report_model(exp_model_info->_model_info->_model_name, "default", "default", 0,
                                                 "single_user_fe_cost", (butil::gettimeofday_us() - start_user_fe));

            if (fe_session.user_feature_extractor_response->item_features_size() != 0) {
                LOG_ERROR << "model name = [" << exp_model_info->_model_name
                                 << "], user feature extracted, but result has item feature!";
                MonitorMgr::common_report_model(exp_model_info->_model_name, "default",
                                                std::to_string(core_context->get_algo_scene_id()), "0", 0,
                                                "uf_extract_failed", 1);
                ret = ERROR_FE_UF_EXTRACT_TYPE_NOT_MATCH;
            }
        }
        if (core_context->get_rank_request()->debuglevel() == DebugLevel::kDumpFeResponse) {
            std::cout << "fe service start dump! node name = [" << this->get_name() << "], model type = ["
                      << static_cast<int64_t>(this->model_type_) << "];\n";
            for (const auto &[exp_model_info, fe_session]: fe_session_map) {
                debug::pb::SavePbToFile(this->get_name() + "_user_" + exp_model_info->_model_name + "_fe_response.json",
                                        *fe_session.user_feature_extractor_response);
            }
            debug::pb::SavePbToFile("user_fe_request.json", *user_fe_request);
            std::cout << "fe_service dump end!" << std::endl;
        }

        return ret;
    }

    void FeService::initialize(ConfigXmlPtr xml) {
        int32_t split_size;
        if (xml->attr("split_size", split_size)) {
            this->split_size_ = split_size;
        }
        std::string model_type;
        if (xml->attr("model_type", model_type)) {
            if (model_type == "CPC_CTR") {
                this->model_type_ = ExperimentModelType::CPC_CTR;
                this->single_fe_cost_ = new bvar::LatencyRecorder{"fe", "cpc_ctr_single_cost"};
                this->node_cost_ = new bvar::LatencyRecorder{"fe", "cpc_ctr_node_cost"};
            } else if (model_type == "CPC_CVR") {
                this->model_type_ = ExperimentModelType::CPC_CVR;
                this->single_fe_cost_ = new bvar::LatencyRecorder{"fe", "cpc_cvr_single_cost"};
                this->node_cost_ = new bvar::LatencyRecorder{"fe", "cpc_cvr_node_cost"};
            } else if (model_type == "CPD_CTR") {
                this->model_type_ = ExperimentModelType::CPD_CTR;
                this->single_fe_cost_ = new bvar::LatencyRecorder{"fe", "cpd_ctr_single_cost"};
                this->node_cost_ = new bvar::LatencyRecorder{"fe", "cpd_ctr_node_cost"};
            } else if (model_type == "CPD_CVR") {
                this->model_type_ = ExperimentModelType::CPD_CVR;
                this->single_fe_cost_ = new bvar::LatencyRecorder{"fe", "cpd_cvr_single_cost"};
                this->node_cost_ = new bvar::LatencyRecorder{"fe", "cpd_cvr_node_cost"};
            } else if (model_type == "ITEM_EMBEDDING") {
                this->model_type_ = ExperimentModelType::ITEM_EMBEDDING;
            } else if (model_type == "LTV") {
                this->model_type_ = ExperimentModelType::LTV;
                this->single_fe_cost_ = new bvar::LatencyRecorder{"fe", "ltv_single_cost"};
                this->node_cost_ = new bvar::LatencyRecorder{"fe", "ltv_node_cost"};
            } else {
                throw std::invalid_argument("model type not support! model type in config = [" + model_type + "]");
            }
        } else {
            throw std::invalid_argument("model type attr read failed!");
        }
        std::string extract_type_str;
        if (xml->attr("extract_type", extract_type_str)) {
            if (extract_type_str == "user") {
                this->extract_type_ = ExtractType::kUser;
            } else if (extract_type_str == "item") {
                this->extract_type_ = ExtractType::kItem;
            }
        }
    }
    void FeService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CoreContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
        return;
    }
    const std::unordered_map<ExperimentModelInfo *, std::vector<ItemWrapper>> *
    FeService::GetItemListsOfThisNode(CoreContextPtr core_context) {
        switch (model_type_) {
            case ExperimentModelType::CPC_CTR:
                return &(core_context->_model_predict_cpc_ctr_map);
            case ExperimentModelType::CPC_CVR:
                return &(core_context->_model_predict_cpc_cvr_map);
            case ExperimentModelType::CPD_CTR:
                return &(core_context->_model_predict_cpd_ctr_map);
            case ExperimentModelType::CPD_CVR:
                return &(core_context->_model_predict_cpd_cvr_map);
            case ExperimentModelType::LTV:
                return &(core_context->_model_predict_ltv_map);
            default:
                return nullptr;
        }
        return nullptr;
    }
    void FeService::ShallowCopyUserFeature(phx::FeRequest *from, phx::FeRequest *to) {
        const google::protobuf::Reflection *reflection = phx::FeRequest::GetReflection();
        const google::protobuf::Descriptor *descriptor = phx::FeRequest::GetDescriptor();
        for (int32_t i = 0; i < descriptor->field_count(); i++) {
            const google::protobuf::FieldDescriptor *field = descriptor->field(i);
            if (!field->is_repeated()) {
                if (!reflection->HasField(*from, field)) {
                    continue;
                }
                switch (field->cpp_type()) {
                    case (protobuf::FieldDescriptor::CPPTYPE_MESSAGE): {
                        reflection->SetAllocatedMessage(to, reflection->MutableMessage(from, field), field);
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_INT32): {
                        reflection->SetInt32(to, field, reflection->GetInt32(*from, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_INT64): {
                        reflection->SetInt64(to, field, reflection->GetInt64(*from, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_FLOAT): {
                        reflection->SetFloat(to, field, reflection->GetFloat(*from, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_DOUBLE): {
                        reflection->SetDouble(to, field, reflection->GetDouble(*from, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_STRING): {
                        reflection->SetString(to, field, reflection->GetString(*from, field));
                        break;
                    }
                    default:
                        break;
                }
            }
        }
    }

    phx::FeRequest *FeService::BuildSplitFeRequest(CoreContextPtr core_context, phx::FeRequest *full_fe_request,
                                                   const std::vector<ItemWrapper> &total_items, size_t item_start_index,
                                                   size_t item_end_index, ExtractorWrapper &ext_wrapper) {
        auto split_fe_request =
                google::protobuf::Arena::CreateMessage<phx::FeRequest>(core_context->get_context_arena());
        const google::protobuf::Reflection *reflection = phx::FeRequest::GetReflection();
        const google::protobuf::Descriptor *descriptor = phx::FeRequest::GetDescriptor();
        for (int32_t i = 0; i < descriptor->field_count(); i++) {
            const google::protobuf::FieldDescriptor *field = descriptor->field(i);
            if (field->is_repeated()) {
                if (reflection->FieldSize(*full_fe_request, field) == 0) {
                    continue;
                }
            } else {
                if (!reflection->HasField(*full_fe_request, field)) {
                    continue;
                }
            }
            if (!field->is_repeated()) {
                switch (field->cpp_type()) {
                    case (protobuf::FieldDescriptor::CPPTYPE_MESSAGE): {
                        reflection->SetAllocatedMessage(split_fe_request,
                                                        reflection->MutableMessage(full_fe_request, field), field);
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_INT32): {
                        reflection->SetInt32(split_fe_request, field, reflection->GetInt32(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_INT64): {
                        reflection->SetInt64(split_fe_request, field, reflection->GetInt64(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_FLOAT): {
                        reflection->SetFloat(split_fe_request, field, reflection->GetFloat(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_DOUBLE): {
                        reflection->SetDouble(split_fe_request, field, reflection->GetDouble(*full_fe_request, field));
                        break;
                    }
                    case (protobuf::FieldDescriptor::CPPTYPE_STRING): {
                        reflection->SetString(split_fe_request, field, reflection->GetString(*full_fe_request, field));
                        break;
                    }
                    default:
                        break;
                }
            }
        }
        for (size_t item_index = item_start_index; item_index < item_end_index; item_index++) {
            auto fs_context = core_context->get_fs_context();
            auto item_feature = fs_context->alloc_item_fea(total_items[item_index].item->creativeid(), false);
            if (unlikely(item_feature == nullptr)) {
                LOG_ERROR << "item feature is null! creative_id = ["
                                 << total_items[item_index].item->creativeid() << "]";
                return nullptr;
            }
            split_fe_request->mutable_item_fea()->AddAllocated(item_feature);
            ext_wrapper.items.push_back(item_feature);
        }
        return split_fe_request;
    }
    int FeService::SplitExtract(CoreContextPtr context, phx_fe::ConfigsGetter config_getter,
                                phx_fe::ModelSlotsGetter model_slots_getter) {
        long node_start = butil::gettimeofday_us();
        auto &fe_split = *context->get_fe_context()->MutableSplit();
        auto &fe_sessions_map = *context->get_fe_context()->MutableSessions();
        auto *empty_user_action = google::protobuf::Arena::CreateMessage<phx::UserAction>(context->get_context_arena());
        auto model_item_lists_ptr = GetItemListsOfThisNode(context);
        if (model_item_lists_ptr == nullptr) {
            LOG_ERROR << "can not find item lists of model type [" << static_cast<int>(this->model_type_)
                             << "], this should not happen!";
            return ERROR_FE_MODEL_TYPE_NOT_FOUND;
        }
        std::vector<BatchFeArgs *> args_vec;
        BizLatency *lat = get_node_stat(context)->get_lat();
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);
            auto &model_item_lists = *model_item_lists_ptr;
            for (const auto &[model_info, items]: model_item_lists) {
                size_t total_items_size = items.size();
                size_t split_num = (total_items_size + split_size_ - 1) / split_size_;
                fe_split[this->model_type_][model_info].resize(split_num);
                auto &fe_session = fe_sessions_map[this->model_type_][model_info];
                auto infer_context = context->get_infer_context();
                infer_context->alloc_model_infer(get_model_type(), model_info);// 预分配
                for (size_t split_index = 0; split_index < split_num; split_index++) {
                    size_t item_start_index = split_index * split_size_;
                    size_t item_end_index = std::min((split_index + 1) * split_size_, total_items_size);
                    auto &extrator_wrapper = fe_split[this->model_type_][model_info][split_index];

                    auto split_fe_request = BuildSplitFeRequest(context, context->get_fs_context()->feature_dump, items,
                                                                item_start_index, item_end_index, extrator_wrapper);
                    phx::ExtractorResponse *split_extractor_response =
                            google::protobuf::Arena::CreateMessage<phx::ExtractorResponse>(
                                    context->get_context_arena());

                    BatchFeArgs *args = new BatchFeArgs();
                    args->session = &(fe_session.session);
                    auto &option = args->option;
                    option.is_ltr = false;
                    option.arena = context->get_context_arena();
                    option.expected_batch_size = (item_end_index - item_start_index);
                    option.configs_supplier = config_getter;
                    option.model_slots_getter = model_slots_getter;

                    args->fe_service = this;
                    args->fe_request = split_fe_request;
                    args->user_action = empty_user_action;
                    args->exp_model_info = model_info;
                    args->split_extractor_response = split_extractor_response;
                    extrator_wrapper.extractor_response = split_extractor_response;
                    args->extrator_wrapper = &extrator_wrapper;
                    args_vec.emplace_back(args);
                    bthread_start_background(&(args->bid), &BTHREAD_ATTR_SMALL, FeService::SplitExtractCStyle,
                                             (void *) (args));
                }
            }
        }
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_DESTROY);
            for (auto &args: args_vec) {
                bthread_join(args->bid, nullptr);
            }
        }

        if (context->get_rank_request()->debuglevel() == kDumpFeResponse) {
            for (size_t i = 0; i < args_vec.size(); i++) {
                const auto &args = args_vec[i];
                std::string split_fe_dump_file_name =
                        this->get_name() + "_" + args->exp_model_info->_model_name + "_" + std::to_string(i);
                debug::pb::SavePbToFile(split_fe_dump_file_name + "_fe_request.json", *args->fe_request);
                debug::pb::SavePbToFile(split_fe_dump_file_name + "_extract_rsp.json", *args->split_extractor_response);
            }
        }

        std::unordered_map<std::string, std::pair<long, long>> model_stats;
        for (auto &args: args_vec) {
            auto &stats = model_stats[args->exp_model_info->_model_name];
            stats.first = std::min(stats.first == 0 ? std::numeric_limits<long>::max() : stats.first, args->start);
            stats.second = std::max(stats.second, args->end);
            delete args;
        }
        //count model max_end - min_start
        for (auto &model_stat: model_stats) {
            MonitorMgr::percent_report_model(model_stat.first, context->GetUploadSlotName(),
                                             std::to_string(context->get_algo_scene_id()), 0, "model_total_fe_cost",
                                             (model_stat.second.second - model_stat.second.first));
        }
        long node_end = butil::gettimeofday_us();
        if (likely(this->node_cost_ != nullptr)) {
            *(this->node_cost_) << (node_end - node_start);
        }
        return 0;
    }

    void FeService::StartBackgroundExtraction(BatchFeArgs &args) {
        bthread_start_background(&(args.bid), &BTHREAD_ATTR_SMALL, FeService::SplitExtractCStyle, (void *) (&args));
    }
    void *FeService::SplitExtractCStyle(void *args_v) {
        long start_fe = butil::gettimeofday_us();
        BatchFeArgs &args = *(BatchFeArgs *) (args_v);
        args.start = start_fe;
        try {
            if (args.exp_model_info->_model_info->get_config_info_ptr() == nullptr) {
                LOG_ERROR << "model name = [" << args.exp_model_info->_model_name
                                 << "]; fe config info is null!";
                return nullptr;
            }
            // 不需要获得抽取结果缓存
            phx_fe::ToExtractorResponse(*args.fe_request, *args.user_action,
                                        args.exp_model_info->_model_info->get_config_info(), *args.session, args.option,
                                        args.split_extractor_response, nullptr);
        } catch (const std::exception &e) {
            LOG_ERROR << "FeService::SplitExtract error: " << e.what();
            args.extrator_wrapper->error_code = FE_SPLIT_EXTRASCTOR_ERROR;
        } catch (...) {
            LOG_ERROR << "FeService::SplitExtract unknown error! ";
            args.extrator_wrapper->error_code = FE_UNKNOWN_ERROR;
        }
        long end_fe = butil::gettimeofday_us();
        args.end = end_fe;
        if (likely(args.fe_service->single_fe_cost_ != nullptr)) {
            *(args.fe_service->single_fe_cost_) << (end_fe - start_fe);
            if (args.fe_service->extract_type_ == FeService::ExtractType::kItem) {
                MonitorMgr::percent_report_model(args.exp_model_info->_model_name, "default", "default", 0,
                                                 "single_item_fe_cost", (end_fe - start_fe));
            } else if (args.fe_service->extract_type_ == FeService::ExtractType::kAll) {
                MonitorMgr::percent_report_model(args.exp_model_info->_model_name, "default", "default", 0,
                                                 "single_fe_cost", (end_fe - start_fe));
            }
        }
        return nullptr;
    }

}// namespace Core