
#pragma once
#include "common/hidict/dict_counters_provider.h"
#include "core/core_server/server_config/server_config.h"
#include "core/utils/monitor_mgr.h"
#include <atomic>
#include <bthread/bthread.h>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <glog/logging.h>
#include <log_helper.h>
#include <string>

namespace AdDict {
    class MetricsFlusher {
    public:
        explicit MetricsFlusher(int interval_sec = 60)
            : interval_us_(interval_sec > 0 ? interval_sec * 1000000LL : 60000000LL) {
        }
        ~MetricsFlusher() {
            stop();
        }

        bool start() {
            LOG_INFO << "MetricsFlusher start";
            bool expected = false;
            if (!running_.compare_exchange_strong(expected, true, std::memory_order_acq_rel))
                return true;
            if (bthread_start_background(&tid_, nullptr, &MetricsFlusher::thread_main, this) != 0) {
                running_.store(false, std::memory_order_release);
                return false;
            }
            return true;
        }

        void stop() {
            bool expected = true;
            if (!running_.compare_exchange_strong(expected, false, std::memory_order_acq_rel))
                return;
            void *ret = nullptr;
            bthread_join(tid_, &ret);
            LOG_INFO << "MetricsFlusher stop";
        }

    private:
        static void *thread_main(void *arg) {
            auto *self = static_cast<MetricsFlusher *>(arg);
            self->run_loop();
            return nullptr;
        }

        void run_loop() {
            while (running_.load(std::memory_order_acquire)) {
                if (Core::ServerConfig::_dict_not_found_report == false) {
                    bthread_usleep(interval_us_);
                    continue;
                }
                LOG_INFO << "run flusher task";
                hidict::g_counters->drain_all([&](const std::string &path, const std::string &clazz_name,
                                                  const std::string &dict_version, const uint64_t *buf,
                                                  size_t METRICS) {
                    if (buf[static_cast<size_t>(hidict::Metric::TOTAL)] == 0) {
                        LOG_INFO << path << ", " << clazz_name << " TOTAL is 0";
                        return;
                    }

                    for (size_t j = 0; j < METRICS; ++j) {
                        if (buf[j] == 0) {
                            LOG_INFO << path << ", " << clazz_name << " " << hidict::kMetricNames[j] << " is 0";
                            continue;// 0 不用上报
                        }
                        LOG_INFO << path << ", " << clazz_name << " " << dict_version << " "
                                        << hidict::kMetricNames[j] << " is " << buf[j];
                        ::Core::MonitorMgr::common_report_dict(clazz_name, path, dict_version, 0,
                                                               hidict::kMetricNames[j], buf[j]);
                    }
                    return;
                });
                bthread_usleep(interval_us_);
            }
        }

        bthread_t tid_{0};
        std::atomic<bool> running_{false};
        int64_t interval_us_;
    };
}// namespace AdDict
