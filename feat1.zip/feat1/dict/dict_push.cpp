#include "core/core_services/dict/dict_push.h"
#include "common/hilog/log_helper.h"
#include <ctime>
#include <iomanip>
#include <sstream>
#include <unistd.h>
#include <cstdlib>
#include <brpc/controller.h>
#include <gflags/gflags_declare.h>
#include "common/hilog/spdlog_helper.h"

namespace Core {
    DECLARE_string(pod_name);
    DECLARE_string(pod_ip);
}

namespace dictpush {
// --- DictPushConfig ---
std::atomic<bool> DictPushConfig::dict_push_enable_{false};
std::string DictPushConfig::push_url_;
std::string DictPushConfig::push_uri_;

void DictPushConfig::set(bool enable, const std::string& url, const std::string& uri) {
    if (!enable) {
        LOG_INFO << "DictPush disabled by config";
        DictPushConfig::dict_push_enable_.store(false, std::memory_order_relaxed);
        return;
    }
    if (url.empty() || uri.empty()) {
        LOG_ERROR << "DictPush url and uri cannot be empty";
        DictPushConfig::dict_push_enable_.store(false, std::memory_order_relaxed);
        return;
    }
    DictPushConfig::push_url_ = url;
    DictPushConfig::push_uri_ = uri;
    LOG_INFO << "DictPush set: url=\"" << url << "\", uri=\"" << uri << "\"";
    DictPushConfig::dict_push_enable_.store(true, std::memory_order_release);
}

// --- DictPusher ---
std::atomic<bool> DictPusher::channel_initialized_{false};
std::mutex DictPusher::init_mutex_;
brpc::Channel DictPusher::channel_;
std::string DictPusher::current_channel_url_;

bool DictPusher::EnsureChannelInitialized() {
    if (channel_initialized_.load(std::memory_order_acquire) && current_channel_url_ == DictPushConfig::push_url_) {
        return true;
    }
    std::lock_guard<std::mutex> lk(init_mutex_);
    if (channel_initialized_.load(std::memory_order_relaxed) && current_channel_url_ == DictPushConfig::push_url_) {
        return true;
    }

    try {
        brpc::ChannelOptions options;
        options.protocol = "http";
        options.connection_type = "pooled";

        if (channel_initialized_.load(std::memory_order_relaxed) && 
        current_channel_url_ != DictPushConfig::push_url_) {    // 运行时URL发生变化，重建通道
            channel_.~Channel();
            new (&channel_) brpc::Channel();
        }
        if (channel_.Init(DictPushConfig::push_url_.c_str(), &options) != 0) {
            LOG_ERROR << "DictPusher: init channel failed";
            return false;
        }
        current_channel_url_ = DictPushConfig::push_url_;
        channel_initialized_.store(true, std::memory_order_release);
        return true;
    } catch (const std::exception &e) {
        LOG_ERROR << "DictPusher init exception: " << e.what();
        return false;
    } catch (...) {
        LOG_ERROR << "DictPusher init unknown exception";
        return false;
    }
}

void DictPusher::Post(nlohmann::json&& payload_json) {
    if (!DictPushConfig::dict_push_enable_.load(std::memory_order_acquire)) return;
    if (!EnsureChannelInitialized()) {
        LOG_ERROR << "DictPusher not initialized, data dropped";
        return;
    }
    try {
        std::string body = payload_json.dump();
        if (!ExecuteHttpPost(body)) {
            LOG_WARNING << "DictPusher post failed, retry once";
            (void)EnsureChannelInitialized();
            if (!ExecuteHttpPost(body)) {   // 重试一次
                LOG_ERROR << "DictPusher post failed twice, data dropped: " << body;
            } 
        }
    } catch (const std::exception &e) {
        LOG_ERROR << "DictPusher post exception: " << e.what();
    } catch (...) {
        LOG_ERROR << "DictPusher post unknown exception";
    }
}

bool DictPusher::ExecuteHttpPost(const std::string& json_body) {
    if (!DictPushConfig::dict_push_enable_.load(std::memory_order_acquire)) {
        return true;
    }
    if (json_body.empty()) {
        return true;
    }
    if (DictPushConfig::push_url_.empty()) {
        LOG_WARNING << "DictPusher url empty, skip";
        return false;
    }

    try {
        brpc::Controller cntl;
        cntl.http_request().uri() = DictPushConfig::push_uri_;
        cntl.http_request().set_method(brpc::HTTP_METHOD_POST);
        cntl.http_request().set_content_type("application/json; charset=utf-8");
        cntl.set_timeout_ms(2000);
        cntl.request_attachment().append(json_body);

        channel_.CallMethod(NULL, &cntl, NULL, NULL, NULL);
        if (cntl.Failed()) {
            LOG_ERROR << "DictPusher post failed, brpc error: " << cntl.ErrorText();
            return false;
        }

        long status = cntl.http_response().status_code();
        bool success = (status >= 200 && status < 300);
        if (!success) {
            LOG_ERROR << "DictPusher post failed, response code: " << status
                            << ", error text: " << cntl.response_attachment().to_string();
        }
        return success;
    } catch (const std::exception &e) {
        LOG_ERROR << "DictPusher post exception: " << e.what();
        return false;
    } catch (...) {
        LOG_ERROR << "DictPusher post unknown exception";
        return false;
    }
}

// --- PodMeta & time format ---
PodMeta GetPodMeta() {
    static std::once_flag init_flag;
    static PodMeta cached_meta;
    std::call_once(init_flag, []() {
        PodMeta m;
        if (!::Core::FLAGS_pod_name.empty()) {
            m.pod_name = ::Core::FLAGS_pod_name;
        } else if (const char* pn = std::getenv("POD_NAME"); pn && *pn) {
            m.pod_name = pn;
        } else {
            char host[256] = {0};
            if (gethostname(host, sizeof(host) - 1) == 0) {
                m.pod_name = host;
            } else {
                m.pod_name = "unknown";
            }
        }
        if (!::Core::FLAGS_pod_ip.empty()) {
            m.pod_ip = ::Core::FLAGS_pod_ip;
        } else if (const char* pi = std::getenv("POD_IP"); pi && *pi) {
            m.pod_ip = pi;
        } else {
            m.pod_ip = "unknown";
        }
        cached_meta = m;
    });
    return cached_meta;
}

std::string FormatTimeYmdHMS(time_t t) {
    std::tm tm_buf;
#if defined(_WIN32)
    localtime_s(&tm_buf, &t);
#else
    localtime_r(&t, &tm_buf);
#endif
    std::ostringstream oss;
    oss << std::put_time(&tm_buf, "%Y-%m-%d %H:%M:%S");
    return oss.str();
}

} // namespace dictpush