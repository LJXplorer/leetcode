#include "dict_mgr.h"
#include "common/comm/config_xml.h"
#include "common/config/config_manager.h"
#include "common/config/error_code.h"
#include "common/hidict/callback.h"
#include "common/hidict/dict_logger.h"
#include "common/hidict/dict_manager.h"
#include "common/hilog/log_helper.h"
#include "core/core_services/dict/ad_dict_callback.h"
#include "phx-fe/ad_dict/ad_dict_manager.h"
#include "phx-fe/ad_dict/adinfo_dict.h"
#include "phx-fe/ad_dict/adquerycrossapp_dict.h"
#include "phx-fe/ad_dict/adquerystatsinfo_dict.h"
#include "phx-fe/ad_dict/adstat_dict.h"
#include "phx-fe/ad_dict/adunit_dict.h"
#include "phx-fe/ad_dict/appinfo_dict.h"
#include "phx-fe/ad_dict/jieba_dict.h"
#include "phx-fe/ad_dict/packagename2appid_dict.h"
#include "dict_hilogger.h"
#include <cstdlib>
#include <memory>
#include <string>

namespace Core {
    int AdDictConfigMgr::init(const config::ConfigServiceCfg &cfg, const std::string &group_id,
                              const std::string &data_id) {
        hidict::DictLogger::setLogger(std::make_shared<Core::DictHilogger>());
        auto ptr = std::make_shared<DicthNacosConfig>(group_id, data_id);
        config::RegisterResponse regist_ret = config::ConfigManager::getInstance().RegisterConfig(cfg, ptr);
        if (regist_ret != config::RegisterResponse::kSuccess) {
            std::cerr << "register dict nacos failed" << std::endl;
            LOG_ERROR << "register dict nacos failed";
            return -1;
        }
        is_first_load = false;
        return 0;
    }

    int AdDictConfigMgr::update(const std::string &content) {
        if(!is_first_load) {
            LOG_ERROR << "dict.xml not support hot reload" ;;
            return -1;
        }
        ConfigXml xml_conf;
        bool parse_succ = xml_conf.parse(content);
        if (!parse_succ) {
            LOG_ERROR << "parse dict.xml failed, conent: " << content;
            return -1;
        }
        ConfigXml main;
        if (!xml_conf.find("main", main)) {
            LOG_ERROR << "main not found in dict.xml on Nacos ";
            return -1;
        }

        ConfigXml dict_conf;
        if (!main.child("dict", dict_conf)) {
            LOG_ERROR << "dict not exist in dict.xml on Nacos ";
            return -2;
        }
        bool has_next = false;

        std::vector<hidict::DictConfig> hidict_configs;
        do {
            std::string dict_path = "";
            dict_conf.attr<std::string>("dict_path", dict_path);
            std::string dict_class = "";
            dict_conf.attr<std::string>("dict_class", dict_class);

            if (dict_path.empty() || dict_class.empty())
                continue;
            hidict::DictConfig hidict_config{};
            hidict_config.m_name = dict_path;
            hidict_config.m_path = dict_path;
            hidict_config.m_clazz = dict_class;
            hidict_configs.emplace_back(hidict_config);

            has_next = dict_conf.next("dict", dict_conf);
        } while (has_next);
        long handle = reinterpret_cast<long>(&hidict_configs);
        auto register_dict_callback_factory = [](const std::string& dict_clazz_name)->hidict::DictCallback* {
             if (dict_clazz_name == "AdinfoDict") {
                    return new AdDictCallback<AdDict::AdinfoDict>();
                } else if (dict_clazz_name == "AdQueryCrossAppInfoDict") {
                    return new AdDictCallback<AdDict::AdQueryCrossAppInfoDict>();
                } else if (dict_clazz_name == "AdQueryStatsInfoDict") {
                    return new AdDictCallback<AdDict::AdQueryStatsInfoDict>();
                } else if (dict_clazz_name == "AdStatDict") {
                    return new AdDictCallback<AdDict::AdStatDict>();
                } else if (dict_clazz_name == "AdunitDict") {
                    return new AdDictCallback<AdDict::AdunitDict>();
                } else if (dict_clazz_name == "AppinfoDict") {
                    return new AdDictCallback<AdDict::AppinfoDict>();
                } else if (dict_clazz_name == "PackageName2AppIdInfoDict") {
                    return new AdDictCallback<AdDict::PackageName2AppIdInfoDict>();
                } else if (dict_clazz_name == "JieBaDict") {
                    return new AdDictCallback<AdDict::JieBaDict>();
                } else if (dict_clazz_name == "GameStatsDict") {
                    return new AdDictCallback<AdDict::GameStatsDict>();
                }
                return nullptr;
        };

        bool init_dict_succ = AdDict::AdDictCollectorInstance::instance().init(std::to_string(handle), hidict_configs, false, register_dict_callback_factory);

        if(!init_dict_succ) {
            LOG_ERROR << " Dict init failed, please handle it ";
            Core::MonitorMgr::common_report_dict("ALL_DICT","DEFAULT", "DEFAULT", -1,
                                                    "dict_load_status", 1);
        } 

        //waiting for first time done of loading dict
        while (is_first_load && !AdDict::AdDictCollectorInstance::instance().get_first_load_done()) {
            std::cout <<"[" <<time(NULL) <<"]"<< " Wating for all dict loading done..." << std::endl;
            sleep(1);
        }

        if(!AdDict::AdDictCollectorInstance::instance().get_load_all_succ_flag()) {
            Core::MonitorMgr::common_report_dict("ALL_DICT","DEFAULT", "DEFAULT", -1,
                                                    "dict_load_status", 1);
            LOG_ERROR <<" Dict init error";
        } 
        std::cout <<"[" <<time(NULL) <<"]"<< " All dict loading finished. Please check dict loading result." << std::endl;
        LOG_ERROR <<" All dict loading finished. Please check dict loading result.";

        return 0;
    }
};// namespace Core
