#include "c_adapter.h"
namespace HLframe::c_adapter {
    void incr_batch_count(Node *node, Core::CoreContextPtr context, size_t n) {
        auto it = context->_node_split_num_map.find(node);
        if (it == context->_node_split_num_map.end()) {
            LOG_ERROR << LOG_HEAD(context) << node->get_name() << " incr_batch_count not find node";
            return;
        }
        int old = it->second->fetch_add(n);
        LOG_INFO << LOG_HEAD(context) << node->get_name() << " old:" << old
                        << " incr_batch_count:" << it->second->load() << ",add :" << n;
    }
    bool is_split_finish(Node *node, std::shared_ptr<Core::CoreContext> ctx) {
        auto it = ctx->_node_split_num_map.find(node);
        if (it == ctx->_node_split_num_map.end()) {
            LOG_ERROR << LOG_HEAD(ctx) << node->get_name()
                             << " not found in _node_split_num_map, this should not happen";
            return true;
        }

        auto input_num = it->second;
        int old_value = input_num->fetch_sub(1);
        LOG_INFO << LOG_HEAD(ctx) << node->get_name() << " old_value:" << old_value
                        << ", store:" << input_num->load();
        if (old_value == 1) {
            return true;
        } else if (old_value <= 0) {
            LOG_ERROR << LOG_HEAD(ctx) << node->get_name() << "too many notify, old_value: " << old_value
                             << ", this should not happen";
            return true;
        }
        return false;
    }

    bool is_split_finish(Node *node,
                         std::unordered_map<Node *, std::shared_ptr<std::atomic<int>>> *node_split_num_map) {
        auto it = node_split_num_map->find(node);
        if (it == node_split_num_map->end()) {
            LOG_ERROR << node->get_name() << " not found in _node_split_num_map, this should not happen";
            return true;
        }

        auto input_num = it->second;
        int old_value = input_num->fetch_sub(1);
        LOG_INFO << node->get_name() << " old_value:" << old_value << ", store:" << input_num->load();
        if (old_value == 1) {
            return true;
        } else if (old_value <= 0) {
            LOG_ERROR << node->get_name() << "too many notify, old_value: " << old_value
                             << ", this should not happen";
            return true;
        }
        return false;
    }

    void incr_batch_count(Node *node, std::unordered_map<Node *, std::shared_ptr<std::atomic<int>>> *node_split_num_map,
                          size_t n) {
        auto it = node_split_num_map->find(node);
        if (it == node_split_num_map->end()) {
            LOG_ERROR << node->get_name() << " incr_batch_count not find node";
            return;
        }
        int old = it->second->fetch_add(n);
        LOG_INFO << node->get_name() << " old:" << old << " incr_batch_count:" << it->second->load()
                        << ",add :" << n;
    }
}// namespace HLframe::c_adapter