#ifndef _CORE_CALL_BACK_H
#define _CORE_CALL_BACK_H
#include "brpc/controller.h"
#include "butil/endpoint.h"
#include "core/core_context/core_context.h"
#include "core/utils/monitor_mgr.h"
#include "core/core_server/server_config/server_config.h"
namespace Core {
    template<typename REQ,typename RSP>
    class Service ;

    class CallBack :  public google::protobuf::Closure{
    protected:
        brpc::Controller _cntl;
        std::string _local_ip_port;
        std::string _remote_ip_port;
        int64_t _lat = 0;
    public:
        CallBack();
        virtual ~CallBack();
        virtual void Run() = 0;
    public:
        int32_t error_code();
        void set_local_info();
        const std::string& get_local_info();
        void set_remote_info();
        const std::string& get_remote_info();
        brpc::Controller* get_controller();
    };
    

    template<typename REQ,typename RSP>
    class ServiceCallBack : public CallBack {
    private:
        CoreContextPtr _ctx;
        std::string _key;
        std::string _channel_name;
        ServiceRequestResponsePair_Arena<REQ,RSP>* _serivce_pair = nullptr;
        Service<REQ,RSP>* _node = nullptr;
        int64_t _code = 0;
    public:
        ServiceCallBack(CoreContextPtr context,const std::string&key,ServiceRequestResponsePair_Arena<REQ,RSP>* p,Service<REQ,RSP>*n):
            _ctx(context),_key(key),_serivce_pair(p),_node(n){

        }

        virtual ~ServiceCallBack(){
            report();
        }

        void Run() {
            _lat = _cntl.latency_us();
            _code = error_code();
            set_local_info();
            set_remote_info();
            if(_cntl.Failed()){
                exception();
            }else{
                success();
            }
            
            if(_node->is_split_finish(_ctx)){//分包处理完成
                BizLatency* bizlat = _node->get_node_stat(_ctx)->get_lat();
                {
                    BizLatencyGaurd lat_guard(bizlat,LAT_STAGE_DESTROY);
                }
                _node->run_output_nodes_if_ready(_ctx);
            }

            delete this;
        }

        void set_channel_name(const std::string&ch_name){
            _channel_name = ch_name;
        }
    public:
        
        int32_t exception(){
            LOG_ERROR<<_node->get_name()<<",key:"<<_key<<",_channel_name:"<<_channel_name<<":"<<_cntl.ErrorText()
                <<",lat:"<<_lat;
            return _node->process_response(_ctx,_key,error_code(),_lat,_serivce_pair->get_service_request(),_serivce_pair->get_service_response());
        }

        int32_t success(){
            return _node->process_response(_ctx,_key,error_code(),_lat,_serivce_pair->get_service_request(),_serivce_pair->get_service_response());
        }

        void report(){
            const std::string& policy_id = _ctx->_experiment_model_name[_channel_name];
            MonitorMgr::percent_report_model(_channel_name + "_" + policy_id,_code,"_model_cost",_lat);
            LOG_WARNING<<_node->get_name()<<" report key:"<<_key<<",_channel_name:"<<_channel_name<<":"<<_cntl.ErrorText()
                <<",lat:"<<_lat;
        }
    };
    
}

#endif
