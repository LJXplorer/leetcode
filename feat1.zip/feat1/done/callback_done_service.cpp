#include "core/core_services/done/callback_done_service.h"
#include "common/monitor/monitor_manager.h"
#include "core/core_context/callback_context.h"

namespace Core {

    SERVICE_REGISTER(CallbackDoneService);

    void CallbackDoneService::initialize(ConfigXmlPtr xml) {
        initialize_xml(xml);
    }

    void CallbackDoneService::initialize_xml(ConfigXmlPtr xml) {
    }

    void CallbackDoneService::initialize(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CallbackContext>(context);
        ctx->get_monitor_context()->alloc_node(get_name());
    }

    int CallbackDoneService::do_service(GraphContextPtr context) {
        auto ctx = std::dynamic_pointer_cast<CallbackContext>(context);
        int32_t ret = 0;
        BizLatency *lat = get_node_stat(ctx)->get_lat();
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_CREATE);
            try {
                ret = assembly_response(ctx);
                ctx->_callback_bak_response.CopyFrom(*(ctx->get_raw_callback_response()));
                ctx->_end_ts = gettimeofday_ms();
                ctx->set_predicttime(ctx->_end_ts - ctx->_begin_ts);
            } catch (const std::exception &e) {
                LOG_ERROR << LOG_HEAD(ctx) << get_name() << "callback do service fail: " << ret << ","
                                 << e.what();
            }
        }
        LOG_INFO << LOG_HEAD(ctx) << get_name() << "callback do_service ret:" << ret;
        {
            BizLatencyGaurd lat_guard(lat, LAT_STAGE_DESTROY);
            ctx->get_request_context()->done();
            monitor::MonitorManager::getInstance().InterfaceSvrSuccess(
                    ctx->_begin_ts, "/CallbackService", ctx->get_callback_request()->reqid(), "200", "", "", 0, "", "");
        }
        return ret;
    }

    int CallbackDoneService::assembly_response(CallbackContextPtr context) {
        auto response = context->get_raw_callback_response();
        response->set_code(context->_response_code);
        return ERROR_SUCCESS;
    }

}// namespace Core
