#pragma once
#include <brpc/channel.h>
#include "ranking/predict_service.pb.h"
#include <butil/time.h>
#include <google/protobuf/stubs/callback.h>
#include <log_helper.h>

namespace debug {
    constexpr int kChannelTimeout = 300;
    constexpr int kBackupRequestMs = 500;
    struct RankingCallback : public google::protobuf::Closure {
        explicit RankingCallback(const ::phx::PredictorRequest *request_ptr) : request(), response(), cntl() {
            request.CopyFrom(*request_ptr);
            cntl.Reset();
        }
        void Run() override {
            if (cntl.Failed()) {
                //抽样打日志
                long now = butil::gettimeofday_us();
                if ((now % 100) == 50) {
                    LOG_ERROR << " predictor server failed: " << cntl.ErrorText() << std::endl;
                }
            }
            delete this;
        }
        ::phx::PredictorRequest request;
        ::phx::PredictorResponse response;
        brpc::Controller cntl;
    };


    class RankingClient {
    private:
        std::string _server_addr;
        brpc::Channel _channel;
        brpc::ChannelOptions _options;
        std::string fake_request_id_;

    public:
        explicit RankingClient(const std::string &server_addr) : _server_addr(server_addr) {
            _options.timeout_ms = kChannelTimeout;
            _options.backup_request_ms = kBackupRequestMs;
            _options.max_retry = 3;
            _options.protocol = "http";
            if (_channel.Init(_server_addr.c_str(), &_options) != 0) {
                LOG_ERROR << "channel init failed! server_addr = [" << server_addr << "]" << std::endl;
            }
            fake_request_id_.append("predictor_fake_req_id");
            std::array<char, 512> host_name{};
            host_name[host_name.max_size() - 1] = '\0';
            int ret = gethostname(host_name.data(), host_name.max_size() - 1);
            if (ret != -1) {
                fake_request_id_.append("_").append(host_name.data());
            }

        }

        int SendRequest(const phx::PredictorRequest *request_ptr) {
            ::phx::PredictorServer_Stub stub(&_channel);
            auto *callback = new RankingCallback{request_ptr};
            std::string fake_req_id = fake_request_id_ + "_" + request_ptr->reqid();
            callback->request.set_reqid(fake_req_id);
            stub.PredictorService(&callback->cntl, &callback->request, &callback->response, callback);

            return 0;
        }
    };
}// namespace debug
