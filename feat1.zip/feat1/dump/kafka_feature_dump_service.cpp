#include "core/core_services/dump/kafka_feature_dump_service.h"
#include "common/hikafka/kafka_producer.h"
#include "common/hikafka/kafka_helper.h"
#include "core/core_context/core_context.h"
#include "core/utils/monitor_mgr.h"
#include "hlframe/register.h"
#include <config_xml.h>
#include <cstdint>
#include <string>
namespace Core {
SERVICE_REGISTER(KafkaDumpFeatureService);

void KafkaDumpFeatureService::initialize_xml(ConfigXmlPtr xml) {
    xml->attr<std::string>("dump_kafka_name", _dump_kafka_name, "");
    xml->attr<std::string>("dump_kafka_key", _dump_kafka_key, "");
    xml->attr<std::string>("send_kafka", _send_kafka, "true");
}

int KafkaDumpFeatureService::dump_sink(CoreContextPtr context) {
    if(context->get_rank_request()->debuglevel() == 111 || "false" == _send_kafka) {
        return 0;
    }

    auto fs_ctx = context->get_fs_context();
    ::phx::FeRequest* fe_request = fs_ctx->get_feature_dump();

    ::phx::FeRequest fe_request_dump;
    fe_request_dump.CopyFrom(*fe_request);
    fe_request_dump.clear_app_fea();
    fe_request_dump.clear_item_fea();
    
    int32_t route = context->get_rank_request()->predictorslotinfo().route();
    const std::string& algo_sceneId = std::to_string(context->get_algo_scene_id());

    MonitorMgr::common_report_stage(std::to_string(route), algo_sceneId, "default", get_name(), "game_default", 0, "total_dump_kafka_count", 1);
    hikafka::KafkaMessage* kafka_message = new hikafka::KafkaMessage();
    kafka_message->key = _dump_kafka_key;
    fe_request_dump.SerializeToString(&kafka_message->value);
    if(!hikafka::KafkaHelper::getInstance().sendMsg(_dump_kafka_name, kafka_message)) {
        LOG_ERROR << "kafka input queue fail "<< _dump_kafka_name;
        MonitorMgr::common_report_stage(std::to_string(route), algo_sceneId, "default", get_name(), "game_default", 0, "dump_kafka_fail_count", 1);
        delete kafka_message;
    }
    return 0;
}


}