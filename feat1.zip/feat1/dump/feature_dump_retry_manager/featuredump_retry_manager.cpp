#include "featuredump_retry_manager.h"
#include "core/core_context/callback_context.h"
#include "core/core_services/dump/feature_dump_retry_manager/featuredump_retry_manager.h"
#include <log_helper.h>
#include <zstd.h>
#include "hlframe/graph_manager.h"
#include "hlframe/gtransport_manager.h"
#include "core/core_server/server_config/server_config.h"
namespace Core {
    DEFINE_int32(featuredump_retry_thread_num, 1, "featuredump_retry_thread_num");
    FeatureDumpRetryManager::FeatureDumpRetryManager(){ _featuredump_retry_thread_ids.resize(FLAGS_featuredump_retry_thread_num);}
    FeatureDumpRetryManager::~FeatureDumpRetryManager(){}

    void FeatureDumpRetryManager::init(){
        _featuredump_queue = std::make_shared<boost::lockfree::queue<FeatureDumpContextInfo*>>(100000);
        for(int32_t i = 0;i < FLAGS_featuredump_retry_thread_num;i++){
            _featuredump_retry_thread_ids[i] = std::thread(FeatureDumpRetryManager::handle, this);
            _featuredump_retry_thread_ids[i].detach();
        }  
    }

    void FeatureDumpRetryManager::handle(FeatureDumpRetryManager* featuredump_retry_manager) {
        while (true) {
            FeatureDumpContextInfo* first_featuredump_context_info = nullptr;
            if (featuredump_retry_manager->_featuredump_queue->pop(first_featuredump_context_info)) {
                // 获取第一个元素的间隔时间
                auto now = std::chrono::steady_clock::now();
                auto diff = now - first_featuredump_context_info->time_stamp;
                int retry_time = ServerConfig::_featuredump_retry_time;

                // 获取对应重试次数的重试时间
                try{
                    int retry_index = first_featuredump_context_info->context->origin_retry_cnt - first_featuredump_context_info->context->retry_cnt;
                    if(!ServerConfig::_featuredump_retry_time_list.empty() && retry_index >= 0 && retry_index < ServerConfig::_featuredump_retry_time_list.size()) {
                        retry_time = ServerConfig::_featuredump_retry_time_list[retry_index];
                    }
                } catch (const std::exception &e){
                    LOG_ERROR << "get retry_index failed, exception: "<< e.what();
                }
                
                if (std::chrono::duration_cast<std::chrono::milliseconds>(diff).count() >= retry_time) {
                    // 更新重试次数并重试
                    int cur_retry_cnt = first_featuredump_context_info->context->retry_cnt - 1;
                    first_featuredump_context_info->context->set_retry_cnt(cur_retry_cnt);
                    retry(first_featuredump_context_info->context);  

                    // 删除当前元素
                    if (first_featuredump_context_info != nullptr) {
                        delete first_featuredump_context_info;
                        first_featuredump_context_info = nullptr;
                    }   
                } else {
                    while (!featuredump_retry_manager->_featuredump_queue->push(first_featuredump_context_info)) {
                        std::this_thread::yield();
                    }
                    std::this_thread::sleep_for(std::chrono::milliseconds(10));
                }

            }else{
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            }
        }
    }

    
    void FeatureDumpRetryManager::retry(std::shared_ptr<CallbackContext> context){
        auto graph = GraphManager::instance().get_graph("CallbackRetry");
        if(graph == nullptr){
            LOG_ERROR <<LOG_HEAD(context)<< "featuredump_start no find in retry";
            //report
            return;
        }

        for (const auto& pair : context->_node_input_num_map) {
            Node* node = pair.first;
            if(node->get_name() == "fea_snapshot") continue;
            std::atomic<int>& input_num = *pair.second;
            int current_value = input_num.load(); 
            if(current_value != 1) {
                input_num.store(1);    
            }
        }
        //执行调度
        try{
            graph->run(context,nullptr,context->get_callback_request(),context->get_callback_response(),nullptr);
        }
        catch(const std::exception& e){
            LOG_ERROR << " retry exception "<<e.what();
            //report
            return;
        }
    }

    bool FeatureDumpRetryManager::push_to_featuredump_queue(FeatureDumpContextInfo* data_info){
        if(data_info == nullptr){
            LOG_INFO<<"arg,push_dump_to_queue null";
            return false;
        }
        bool ret = _featuredump_queue->push(data_info);
        return ret;
    }
}